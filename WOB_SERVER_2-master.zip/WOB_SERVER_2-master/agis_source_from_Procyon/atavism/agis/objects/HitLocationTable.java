// 
// Decompiled by Procyon v0.5.30
// 

package atavism.agis.objects;

public class HitLocationTable
{
    public static HitLocation getHitLocation() {
        return null;
    }
}
