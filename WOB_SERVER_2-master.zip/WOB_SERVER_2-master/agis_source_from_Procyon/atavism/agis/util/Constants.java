// 
// Decompiled by Procyon v0.5.30
// 

package atavism.agis.util;

public class Constants
{
    public static String[] EQUIPMENT_SLOTS;
    
    static {
        Constants.EQUIPMENT_SLOTS = new String[] { "primaryWeapon", "secondaryWeapon", "rangedWeapon", "headItem", "shoulderItem", "chestItem", "handItem", "waistItem", "legItem", "footItem", "backItem", "neckItem", "primaryRing", "secondaryRing", "shirtItem" };
    }
}
