// 
// Decompiled by Procyon v0.5.30
// 

package atavism.management;

import atavism.msgsys.MessageType;

public class Management
{
    public static final MessageType MSG_TYPE_GET_PLUGIN_STATUS;
    
    static {
        MSG_TYPE_GET_PLUGIN_STATUS = MessageType.intern("ao.GET_PLUGIN_STATUS");
    }
}
