// 
// Decompiled by Procyon v0.5.30
// 

package atavism.server.math;

public class Flags
{
    public static short SHORT_FLAG;
    public static int INT_FLAG;
    public static long LONG_FLAG;
    
    static {
        Flags.SHORT_FLAG = -1;
        Flags.INT_FLAG = -1;
        Flags.LONG_FLAG = -1L;
    }
}
