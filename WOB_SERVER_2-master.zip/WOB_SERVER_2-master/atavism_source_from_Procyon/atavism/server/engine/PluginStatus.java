// 
// Decompiled by Procyon v0.5.30
// 

package atavism.server.engine;

public class PluginStatus
{
    public String world_name;
    public String agent_name;
    public String plugin_name;
    public String plugin_type;
    public String host_name;
    public int pid;
    public long run_id;
    public int percent_cpu_load;
    public long last_update_time;
    public long next_update_time;
    public String status;
    public String info;
}
