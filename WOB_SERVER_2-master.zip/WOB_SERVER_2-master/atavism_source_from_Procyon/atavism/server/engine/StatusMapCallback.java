// 
// Decompiled by Procyon v0.5.30
// 

package atavism.server.engine;

import java.util.Map;

public interface StatusMapCallback
{
    Map<String, String> getStatusMap();
}
