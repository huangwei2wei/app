// 
// Decompiled by Procyon v0.5.30
// 

package atavism.server.engine;

public interface EventHandler
{
    String getName();
    
    boolean handleEvent(final Event p0);
}
