// 
// Decompiled by Procyon v0.5.30
// 

package atavism.server.engine;

public interface MatcherFactory
{
    Matcher createMatcher(final SearchClause p0);
}
