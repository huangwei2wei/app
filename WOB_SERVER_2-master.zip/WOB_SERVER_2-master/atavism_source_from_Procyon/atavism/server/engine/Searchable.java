// 
// Decompiled by Procyon v0.5.30
// 

package atavism.server.engine;

import java.util.Collection;

public interface Searchable
{
    Collection runSearch(final SearchClause p0, final SearchSelection p1);
}
