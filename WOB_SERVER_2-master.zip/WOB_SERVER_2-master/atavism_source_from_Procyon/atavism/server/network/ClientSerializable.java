// 
// Decompiled by Procyon v0.5.30
// 

package atavism.server.network;

public interface ClientSerializable
{
    void encodeObject(final AOByteBuffer p0);
}
