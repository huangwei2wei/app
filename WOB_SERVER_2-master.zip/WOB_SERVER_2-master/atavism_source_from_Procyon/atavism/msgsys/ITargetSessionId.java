// 
// Decompiled by Procyon v0.5.30
// 

package atavism.msgsys;

public interface ITargetSessionId
{
    String getTargetSessionId();
    
    void setTargetSessionId(final String p0);
}
