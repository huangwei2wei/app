// 
// Decompiled by Procyon v0.5.30
// 

package atavism.msgsys;

public interface MessageDispatch
{
    void dispatchMessage(final Message p0, final int p1, final MessageCallback p2);
}
