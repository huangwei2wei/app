// 
// Decompiled by Procyon v0.5.30
// 

package atavism.msgsys;

import atavism.server.engine.OID;

public interface HasTarget
{
    OID getTarget();
    
    void setTarget(final OID p0);
}
