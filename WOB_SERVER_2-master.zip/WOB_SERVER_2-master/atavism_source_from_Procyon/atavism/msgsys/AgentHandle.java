// 
// Decompiled by Procyon v0.5.30
// 

package atavism.msgsys;

public abstract class AgentHandle
{
    public abstract String getAgentName();
}
