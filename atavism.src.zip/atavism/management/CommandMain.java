/*     */ package atavism.management;
/*     */ 
/*     */ import gnu.getopt.Getopt;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXConnectorFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import sun.jvmstat.monitor.HostIdentifier;
/*     */ import sun.jvmstat.monitor.MonitorException;
/*     */ import sun.jvmstat.monitor.MonitoredHost;
/*     */ import sun.management.ConnectorAddressLink;
/*     */ 
/*     */ public class CommandMain
/*     */ {
/* 240 */   static Set activeVms = null;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  28 */     Getopt g = new Getopt("CommandMain", args, "p:f:s:d:q");
/*  29 */     List scripts = new LinkedList();
/*  30 */     List scriptNames = new LinkedList();
/*  31 */     List processes = new LinkedList();
/*  32 */     String pidDir = null;
/*  33 */     boolean quiet = false;
/*     */     int c;
/*  36 */     while ((c = g.getopt()) != -1)
/*     */     {
/*     */       String script;
/*  38 */       switch (c)
/*     */       {
/*     */       case 112:
/*  41 */         processes.add(g.getOptarg());
/*  42 */         break;
/*     */       case 102:
/*  45 */         String fileName = g.getOptarg();
/*  46 */         scriptNames.add(fileName);
/*  47 */         script = readFile(fileName);
/*  48 */         if (script == null)
/*  49 */           System.exit(1);
/*  50 */         scripts.add(script);
/*  51 */         break;
/*     */       case 115:
/*  54 */         script = g.getOptarg();
/*  55 */         scripts.add(script);
/*  56 */         scriptNames.add(script);
/*  57 */         break;
/*     */       case 100:
/*  60 */         pidDir = g.getOptarg();
/*  61 */         break;
/*     */       case 113:
/*  64 */         quiet = true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  69 */     if ((processes.size() == 0) || (scripts.size() == 0)) {
/*  70 */       System.err.println("Usage: aom [-q] [-d <pid-dir>] -p <pid|agent-name> -s <script> -f <script-file>");
/*  71 */       System.exit(1);
/*     */     }
/*     */ 
/*  74 */     if (pidDir != null) {
/*  75 */       processes = resolveProcesses(pidDir, processes);
/*     */     }
/*     */ 
/*  78 */     String argvString = "argv = [\"<string>\"";
/*  79 */     int arg = 0;
/*  80 */     for (int ii = g.getOptind(); ii < args.length; ii++) {
/*  81 */       argvString = argvString + ",\"" + args[ii] + "\"";
/*  82 */       arg++;
/*     */     }
/*  84 */     argvString = argvString + "]\n";
/*     */ 
/*  86 */     boolean ok = true;
/*  87 */     for (Iterator i$ = processes.iterator(); i$.hasNext(); ) { process = (String)i$.next();
/*  88 */       ss = 0;
/*  89 */       for (String script : scripts) {
/*  90 */         if (!quiet)
/*  91 */           System.out.println("Process " + process + ": " + (String)scriptNames.get(ss));
/*  92 */         ss++;
/*  93 */         ok = (ok) && (execScript(process, argvString + script));
/*     */       }
/*     */     }
/*     */     String process;
/*     */     int ss;
/*  96 */     if (ok)
/*  97 */       System.exit(0);
/*     */     else
/*  99 */       System.exit(1);
/*     */   }
/*     */ 
/*     */   static String readFile(String fileName)
/*     */   {
/* 104 */     File scriptFile = new File(fileName);
/* 105 */     if (!scriptFile.exists()) {
/* 106 */       System.err.println(fileName + ": file does not exist");
/* 107 */       return null;
/*     */     }
/*     */ 
/* 110 */     char[] data = new char[(int)scriptFile.length()];
/*     */     try {
/* 112 */       FileReader reader = new FileReader(scriptFile);
/* 113 */       reader.read(data, 0, (int)scriptFile.length());
/* 114 */       reader.close();
/*     */     }
/*     */     catch (IOException e) {
/* 117 */       System.err.println(fileName + ": " + e);
/* 118 */       return null;
/*     */     }
/* 120 */     return new String(data);
/*     */   }
/*     */ 
/*     */   static boolean execScript(String process, String script)
/*     */   {
/* 125 */     int vmid = -1;
/*     */     try {
/* 127 */       vmid = Integer.parseInt(process);
/*     */     }
/*     */     catch (NumberFormatException e) {
/* 130 */       vmid = findVmid(process);
/*     */     }
/* 132 */     if (vmid == -1) {
/* 133 */       System.err.println(process + ": Could not find process");
/* 134 */       return false;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 141 */       String address = ConnectorAddressLink.importFrom(vmid);
/*     */ 
/* 143 */       System.out.println("vmid: " + vmid + "; address: " + address);
/* 144 */       JMXServiceURL jmxUrl = new JMXServiceURL(address);
/* 145 */       JMXConnector jmxc = JMXConnectorFactory.connect(jmxUrl);
/* 146 */       MBeanServerConnection server = jmxc.getMBeanServerConnection();
/* 147 */       Object[] parameters = { script };
/* 148 */       String[] signature = { "java.lang.String" };
/*     */ 
/* 150 */       Object result = server.invoke(new ObjectName("net.atavism:type=Engine"), "runPythonScript", parameters, signature);
/*     */ 
/* 152 */       System.out.println(result.toString());
/* 153 */       jmxc.close();
/*     */     }
/*     */     catch (IOException e) {
/* 156 */       System.err.println("Unable to attach to " + vmid + ": " + e.getMessage());
/*     */ 
/* 158 */       return false;
/*     */     }
/*     */     catch (MalformedObjectNameException e) {
/* 161 */       System.err.println("Internal error: " + e.getMessage());
/* 162 */       return false;
/*     */     }
/*     */     catch (InstanceNotFoundException e) {
/* 165 */       System.err.println("Process " + vmid + " is not a Atavism engine");
/* 166 */       return false;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 171 */       System.err.println("Error: " + e);
/* 172 */       return false;
/*     */     }
/* 174 */     return true;
/*     */   }
/*     */ 
/*     */   static int findVmid(String agentName)
/*     */   {
/* 180 */     if (activeVms == null) {
/*     */       try {
/* 182 */         MonitoredHost host = MonitoredHost.getMonitoredHost(new HostIdentifier((String)null));
/* 183 */         activeVms = host.activeVms();
/*     */       } catch (URISyntaxException e) {
/* 185 */         throw new InternalError(e.getMessage());
/*     */       } catch (MonitorException e) {
/* 187 */         throw new InternalError(e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/* 191 */     for (Iterator i$ = activeVms.iterator(); i$.hasNext(); ) { Object vm = i$.next();
/*     */       try {
/* 193 */         String address = ConnectorAddressLink.importFrom(((Integer)vm).intValue());
/* 194 */         if (address == null)
/*     */         {
/*     */           continue;
/*     */         }
/* 198 */         JMXServiceURL jmxUrl = new JMXServiceURL(address);
/* 199 */         JMXConnector jmxc = JMXConnectorFactory.connect(jmxUrl);
/* 200 */         MBeanServerConnection server = jmxc.getMBeanServerConnection();
/*     */ 
/* 202 */         Object result = server.getAttribute(new ObjectName("net.atavism:type=Engine"), "AgentName");
/*     */ 
/* 204 */         jmxc.close();
/* 205 */         if ((result != null) && (result.toString().equals(agentName)))
/* 206 */           return ((Integer)vm).intValue();
/*     */       }
/*     */       catch (IOException e) {
/* 209 */         System.err.println("Unable to attach to " + (Integer)vm + ": " + e.getMessage());
/*     */       }
/*     */       catch (InstanceNotFoundException e)
/*     */       {
/*     */       }
/*     */       catch (JMException e)
/*     */       {
/* 216 */         System.err.println("Unable to attach to " + (Integer)vm + ": " + e);
/*     */       }
/*     */     }
/*     */ 
/* 220 */     return -1;
/*     */   }
/*     */ 
/*     */   static List<String> resolveProcesses(String pidDir, List<String> processes) {
/* 224 */     List processIds = new LinkedList();
/* 225 */     for (String processName : processes) {
/* 226 */       String pidFile = null;
/* 227 */       File scriptFile = new File(pidDir + File.separator + processName + ".winpid");
/* 228 */       if (scriptFile.exists())
/* 229 */         pidFile = pidDir + File.separator + processName + ".winpid";
/*     */       else {
/* 231 */         pidFile = pidDir + File.separator + processName + ".pid";
/*     */       }
/* 233 */       String fileContents = readFile(pidFile);
/* 234 */       fileContents = fileContents.trim();
/* 235 */       processIds.add(fileContents);
/*     */     }
/* 237 */     return processIds;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.management.CommandMain
 * JD-Core Version:    0.6.0
 */