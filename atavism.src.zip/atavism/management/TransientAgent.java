/*    */ package atavism.management;
/*    */ 
/*    */ import atavism.msgsys.MessageAgent;
/*    */ import atavism.server.engine.ScriptManager;
/*    */ import atavism.server.util.Log;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class TransientAgent
/*    */ {
/*    */   private String agentName;
/*    */   private String domainServer;
/*    */   private int domainPort;
/*    */   private MessageAgent agent;
/*    */   private ScriptManager scriptManager;
/*    */ 
/*    */   public TransientAgent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TransientAgent(String agentName, String domainServer, int domainPort)
/*    */   {
/* 20 */     this.agentName = agentName;
/* 21 */     this.domainServer = domainServer;
/* 22 */     this.domainPort = domainPort;
/* 23 */     this.agent = new MessageAgent(agentName);
/* 24 */     this.agent.setDomainFlags(1);
/* 25 */     this.agent.setAdvertisements(new ArrayList());
/*    */   }
/*    */ 
/*    */   public MessageAgent agent()
/*    */   {
/* 30 */     return this.agent;
/*    */   }
/*    */ 
/*    */   public void connect()
/*    */     throws IOException
/*    */   {
/* 36 */     this.agent.openListener();
/* 37 */     this.agent.connectToDomain(this.domainServer, Integer.valueOf(this.domainPort));
/* 38 */     this.agent.waitForRemoteAgents();
/*    */   }
/*    */ 
/*    */   public boolean runScript(String fileName)
/*    */   {
/* 43 */     if (this.scriptManager == null) {
/* 44 */       this.scriptManager = new ScriptManager();
/* 45 */       org.python.core.Options.verbose = 0;
/* 46 */       this.scriptManager.init();
/*    */     }
/*    */     try
/*    */     {
/* 50 */       this.scriptManager.runFileWithThrow(fileName);
/*    */     }
/*    */     catch (Exception e) {
/* 53 */       Log.exception(fileName, e);
/* 54 */       return false;
/*    */     }
/* 56 */     return true;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */     throws IOException
/*    */   {
/* 68 */     String agentName = args[2];
/* 69 */     String domainServer = args[3];
/* 70 */     int domainPort = Integer.parseInt(args[4]);
/*    */ 
/* 72 */     Log.init();
/* 73 */     TransientAgent tagent = new TransientAgent(agentName, domainServer, domainPort);
/*    */ 
/* 75 */     tagent.connect();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.management.TransientAgent
 * JD-Core Version:    0.6.0
 */