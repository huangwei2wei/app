/*   */ package atavism.management;
/*   */ 
/*   */ import atavism.msgsys.MessageType;
/*   */ 
/*   */ public class Management
/*   */ {
/* 7 */   public static final MessageType MSG_TYPE_GET_PLUGIN_STATUS = MessageType.intern("ao.GET_PLUGIN_STATUS");
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.management.Management
 * JD-Core Version:    0.6.0
 */