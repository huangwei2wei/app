/*     */ package atavism.management;
/*     */ 
/*     */ import atavism.msgsys.GenericResponseMessage;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageAgent.DomainClient;
/*     */ import atavism.msgsys.ResponseCallback;
/*     */ import atavism.msgsys.ResponseMessage;
/*     */ import atavism.server.util.InitLogAndPid;
/*     */ import atavism.server.util.Log;
/*     */ import gnu.getopt.Getopt;
/*     */ import gnu.getopt.LongOpt;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class PluginStatusCheck extends TransientAgent
/*     */   implements ResponseCallback
/*     */ {
/*     */   public static final int TIMEOUT = 5000;
/* 124 */   int responders = 0;
/*     */   int expectedResponders;
/* 126 */   List<String> pluginStatus = new LinkedList();
/* 127 */   LinkedHashMap<String, Serializable> rollup = new LinkedHashMap();
/*     */ 
/*     */   public PluginStatusCheck(String agentName, String domainServer, int domainPort)
/*     */   {
/*  23 */     super(agentName, domainServer, domainPort);
/*  24 */     agent().addAdvertisement(Management.MSG_TYPE_GET_PLUGIN_STATUS);
/*     */   }
/*     */ 
/*     */   public void connect()
/*     */     throws IOException
/*     */   {
/*  30 */     super.connect();
/*  31 */     agent().getDomainClient().awaitPluginDependents("Domain", "PluginStatusCheck");
/*     */   }
/*     */ 
/*     */   public List<String> getPluginStatus()
/*     */   {
/*  37 */     Message request = new Message(Management.MSG_TYPE_GET_PLUGIN_STATUS);
/*  38 */     this.expectedResponders = agent().sendBroadcastRPC(request, this);
/*  39 */     synchronized (this) {
/*  40 */       this.responders += this.expectedResponders;
/*  41 */       long startTime = System.currentTimeMillis();
/*  42 */       while (this.responders != 0)
/*     */         try {
/*  44 */           wait(5000L);
/*  45 */           if (System.currentTimeMillis() - startTime > 5000L)
/*  46 */             break;
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/*     */         }
/*     */     }
/*  52 */     return this.pluginStatus;
/*     */   }
/*     */ 
/*     */   public synchronized void handleResponse(ResponseMessage rr)
/*     */   {
/*  57 */     this.responders -= 1;
/*     */ 
/*  59 */     GenericResponseMessage response = (GenericResponseMessage)rr;
/*  60 */     LinkedHashMap status = (LinkedHashMap)response.getData();
/*     */ 
/*  63 */     String statusString = "";
/*  64 */     String pluginName = (String)status.get("plugin");
/*  65 */     if (pluginName == null) {
/*  66 */       pluginName = response.getSenderName();
/*     */     }
/*  68 */     for (Map.Entry ss : status.entrySet()) {
/*  69 */       if (((String)ss.getKey()).equals("plugin"))
/*     */         continue;
/*  71 */       statusString = statusString + pluginName + "." + (String)ss.getKey() + "=" + ss.getValue() + " ";
/*  72 */       rollupValue((String)ss.getKey(), (Serializable)ss.getValue());
/*     */     }
/*  74 */     this.pluginStatus.add(statusString);
/*     */ 
/*  76 */     if (this.responders == 0)
/*  77 */       notify();
/*     */   }
/*     */ 
/*     */   private void rollupValue(String key, Serializable value)
/*     */   {
/*  82 */     Serializable current = (Serializable)this.rollup.get(key);
/*  83 */     if ((value instanceof Integer)) {
/*  84 */       if (current == null)
/*  85 */         current = new Integer(0);
/*  86 */       current = Integer.valueOf(((Integer)current).intValue() + ((Integer)value).intValue());
/*  87 */       this.rollup.put(key, current);
/*     */     }
/*  89 */     else if ((value instanceof Long)) {
/*  90 */       if (current == null)
/*  91 */         current = new Long(0L);
/*  92 */       current = Long.valueOf(((Long)current).longValue() + ((Long)value).longValue());
/*  93 */       this.rollup.put(key, current);
/*     */     }
/*  95 */     else if ((value instanceof Float)) {
/*  96 */       if (current == null)
/*  97 */         current = new Float(0.0F);
/*  98 */       current = Float.valueOf(((Float)current).floatValue() + ((Float)value).floatValue());
/*  99 */       this.rollup.put(key, current);
/*     */     }
/* 101 */     else if ((value instanceof Double)) {
/* 102 */       if (current == null)
/* 103 */         current = new Double(0.0D);
/* 104 */       current = Double.valueOf(((Double)current).doubleValue() + ((Double)value).doubleValue());
/* 105 */       this.rollup.put(key, current);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMissingResponders()
/*     */   {
/* 111 */     return this.responders;
/*     */   }
/*     */ 
/*     */   public int getExpectedResponders()
/*     */   {
/* 116 */     return this.expectedResponders;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getRollup()
/*     */   {
/* 121 */     return this.rollup;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/* 133 */     InitLogAndPid.initLogAndPid(args);
/*     */ 
/* 135 */     LongOpt[] longopts = new LongOpt[3];
/* 136 */     longopts[0] = new LongOpt("port", 1, null, 2);
/* 137 */     longopts[1] = new LongOpt("keys", 1, null, 3);
/* 138 */     longopts[2] = new LongOpt("host", 1, null, 4);
/* 139 */     Getopt g = new Getopt("PluginStatusCheck", args, "s:a:m:t:", longopts);
/*     */ 
/* 141 */     String agentName = "PluginStatusCheck";
/* 142 */     String domainServer = "localhost";
/* 143 */     int domainPort = 20374;
/* 144 */     List scripts = new LinkedList();
/*     */ 
/* 147 */     String[] keys = null;
/*     */     int c;
/* 148 */     while ((c = g.getopt()) != -1) {
/* 149 */       switch (c) {
/*     */       case 115:
/* 151 */         scripts.add(g.getOptarg());
/* 152 */         break;
/*     */       case 97:
/* 154 */         agentName = g.getOptarg();
/* 155 */         break;
/*     */       case 109:
/*     */       case 116:
/* 158 */         break;
/*     */       case 2:
/* 161 */         domainPort = Integer.parseInt(g.getOptarg());
/* 162 */         break;
/*     */       case 3:
/* 164 */         keys = g.getOptarg().split(",");
/* 165 */         break;
/*     */       case 4:
/* 167 */         domainServer = g.getOptarg();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 172 */     Log.init();
/*     */ 
/* 174 */     PluginStatusCheck tagent = new PluginStatusCheck(agentName, domainServer, domainPort);
/*     */ 
/* 176 */     for (String scriptFileName : scripts) {
/* 177 */       tagent.runScript(scriptFileName);
/*     */     }
/* 179 */     tagent.agent().setDomainConnectRetries(0);
/* 180 */     tagent.connect();
/* 181 */     List status = tagent.getPluginStatus();
/*     */     int exitCode;
/*     */     String statusText;
/*     */     int exitCode;
/* 184 */     if (tagent.getMissingResponders() == 0) {
/* 185 */       String statusText = "OK " + tagent.getExpectedResponders() + " plugins responding";
/*     */ 
/* 187 */       exitCode = 0;
/*     */     }
/*     */     else {
/* 190 */       statusText = "WARN missing " + tagent.getMissingResponders() + " out of " + tagent.getExpectedResponders() + " plugins";
/*     */ 
/* 193 */       exitCode = 1;
/*     */     }
/*     */ 
/* 196 */     String perfData = "|";
/* 197 */     if (keys != null) {
/* 198 */       for (String key : keys) {
/* 199 */         Object value = tagent.getRollup().get(key);
/* 200 */         if (value != null)
/* 201 */           perfData = perfData + key + "=" + value + " ";
/*     */         else {
/* 203 */           perfData = perfData + key + "=U ";
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 208 */       for (Map.Entry ss : tagent.getRollup().entrySet()) {
/* 209 */         perfData = perfData + (String)ss.getKey() + "=" + ss.getValue() + " ";
/*     */       }
/*     */     }
/*     */ 
/* 213 */     if (keys == null) {
/* 214 */       for (String ss : status) {
/* 215 */         perfData = perfData + ss;
/*     */       }
/*     */     }
/*     */ 
/* 219 */     System.out.println(statusText + perfData);
/*     */ 
/* 221 */     System.exit(exitCode);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.management.PluginStatusCheck
 * JD-Core Version:    0.6.0
 */