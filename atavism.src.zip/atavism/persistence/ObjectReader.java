/*     */ package atavism.persistence;
/*     */ 
/*     */ import atavism.server.engine.Namespace;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ObjectReader
/*     */ {
/*     */   private String input;
/*     */   private static Map<String, Class> typeMap;
/*     */   private static Set<Class> primitiveBoxTypes;
/*     */   private Reader reader;
/*     */   private PackageAliases aliases;
/*     */ 
/*     */   public ObjectReader(String input)
/*     */   {
/* 500 */     typeMap = new HashMap();
/* 501 */     typeMap.put("long", Long.TYPE);
/* 502 */     typeMap.put("int", Integer.TYPE);
/* 503 */     typeMap.put("boolean", Boolean.TYPE);
/* 504 */     typeMap.put("short", Short.TYPE);
/* 505 */     typeMap.put("byte", Byte.TYPE);
/* 506 */     typeMap.put("char", Character.TYPE);
/* 507 */     typeMap.put("double", Double.TYPE);
/* 508 */     typeMap.put("float", Float.TYPE);
/*     */ 
/* 510 */     typeMap.put("String", String.class);
/* 511 */     typeMap.put("null", NullClass.class);
/*     */ 
/* 513 */     typeMap.put("Long", Long.class);
/* 514 */     typeMap.put("Integer", Integer.class);
/* 515 */     typeMap.put("Boolean", Boolean.class);
/* 516 */     typeMap.put("Short", Short.class);
/* 517 */     typeMap.put("Byte", Byte.class);
/* 518 */     typeMap.put("Character", Character.class);
/* 519 */     typeMap.put("Double", Double.class);
/* 520 */     typeMap.put("Float", Float.class);
/*     */ 
/* 522 */     primitiveBoxTypes = new HashSet();
/* 523 */     primitiveBoxTypes.add(Long.class);
/* 524 */     primitiveBoxTypes.add(Integer.class);
/* 525 */     primitiveBoxTypes.add(Boolean.class);
/* 526 */     primitiveBoxTypes.add(Short.class);
/* 527 */     primitiveBoxTypes.add(Byte.class);
/* 528 */     primitiveBoxTypes.add(Character.class);
/* 529 */     primitiveBoxTypes.add(Double.class);
/* 530 */     primitiveBoxTypes.add(Float.class);
/*     */ 
/*  25 */     this.input = input;
/*  26 */     this.reader = new StringReader(input);
/*  27 */     this.aliases = new PackageAliases();
/*     */   }
/*     */ 
/*     */   public ObjectReader(String input, PackageAliases aliases)
/*     */   {
/* 500 */     typeMap = new HashMap();
/* 501 */     typeMap.put("long", Long.TYPE);
/* 502 */     typeMap.put("int", Integer.TYPE);
/* 503 */     typeMap.put("boolean", Boolean.TYPE);
/* 504 */     typeMap.put("short", Short.TYPE);
/* 505 */     typeMap.put("byte", Byte.TYPE);
/* 506 */     typeMap.put("char", Character.TYPE);
/* 507 */     typeMap.put("double", Double.TYPE);
/* 508 */     typeMap.put("float", Float.TYPE);
/*     */ 
/* 510 */     typeMap.put("String", String.class);
/* 511 */     typeMap.put("null", NullClass.class);
/*     */ 
/* 513 */     typeMap.put("Long", Long.class);
/* 514 */     typeMap.put("Integer", Integer.class);
/* 515 */     typeMap.put("Boolean", Boolean.class);
/* 516 */     typeMap.put("Short", Short.class);
/* 517 */     typeMap.put("Byte", Byte.class);
/* 518 */     typeMap.put("Character", Character.class);
/* 519 */     typeMap.put("Double", Double.class);
/* 520 */     typeMap.put("Float", Float.class);
/*     */ 
/* 522 */     primitiveBoxTypes = new HashSet();
/* 523 */     primitiveBoxTypes.add(Long.class);
/* 524 */     primitiveBoxTypes.add(Integer.class);
/* 525 */     primitiveBoxTypes.add(Boolean.class);
/* 526 */     primitiveBoxTypes.add(Short.class);
/* 527 */     primitiveBoxTypes.add(Byte.class);
/* 528 */     primitiveBoxTypes.add(Character.class);
/* 529 */     primitiveBoxTypes.add(Double.class);
/* 530 */     primitiveBoxTypes.add(Float.class);
/*     */ 
/*  32 */     this.input = input;
/*  33 */     this.reader = new StringReader(input);
/*  34 */     this.aliases = aliases;
/*     */   }
/*     */ 
/*     */   public Object readObject()
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  40 */     TypedObject typedObject = readTypedObject();
/*  41 */     if (typedObject == null)
/*  42 */       return null;
/*  43 */     return typedObject.value;
/*     */   }
/*     */ 
/*     */   public TypedObject readTypedObject()
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  49 */     Class c = readType();
/*  50 */     if (c == null)
/*  51 */       return null;
/*  52 */     int size = readSize();
/*  53 */     this.reader.mark(2147483647);
/*  54 */     char ch = (char)this.reader.read();
/*  55 */     System.out.println(ch);
/*  56 */     if (ch == '=') {
/*  57 */       return new TypedObject(c, readValue(c, size));
/*     */     }
/*  59 */     this.reader.reset();
/*  60 */     return new TypedObject(c, null);
/*     */   }
/*     */ 
/*     */   private Class readType()
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  67 */     String primitive = readIdentifier();
/*  68 */     Class c = (Class)typeMap.get(primitive);
/*  69 */     if (c != null)
/*  70 */       return c;
/*  71 */     if (primitive.equals("array")) {
/*  72 */       readWhiteSpace();
/*  73 */       c = readClass();
/*  74 */       if (c.isPrimitive())
/*  75 */         return primitiveArrayType(c);
/*  76 */       return Class.forName(new StringBuilder().append("[L").append(c.getName()).append(";").toString());
/*     */     }
/*  78 */     if ((primitive.equals("map")) || (primitive.equals("list")) || (primitive.equals("set")) || (primitive.equals("object")))
/*     */     {
/*  80 */       readWhiteSpace();
/*  81 */       return readClass();
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   private Class readClass()
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  89 */     String className = readFullIdentifier();
/*  90 */     System.out.println(className);
/*  91 */     Class c = (Class)typeMap.get(className);
/*  92 */     if (c != null)
/*  93 */       return c;
/*  94 */     int dot = className.lastIndexOf(46);
/*  95 */     if (dot != -1) {
/*  96 */       String alias = this.aliases.getPackage(className.substring(0, dot));
/*  97 */       if (alias != null)
/*  98 */         return Class.forName(new StringBuilder().append(alias).append(className.substring(dot)).toString());
/*     */     }
/* 100 */     return Class.forName(className);
/*     */   }
/*     */ 
/*     */   private String readIdentifier()
/*     */     throws IOException
/*     */   {
/* 106 */     StringBuilder buf = new StringBuilder();
/*     */     while (true) {
/* 108 */       this.reader.mark(2147483647);
/* 109 */       char ch = (char)this.reader.read();
/* 110 */       if ((Character.isLetter(ch)) || (Character.isDigit(ch)) || (ch == '_')) {
/* 111 */         buf.append(ch);
/*     */       } else {
/* 113 */         this.reader.reset();
/* 114 */         break;
/*     */       }
/*     */     }
/* 117 */     return new String(buf);
/*     */   }
/*     */ 
/*     */   private String readFullIdentifier()
/*     */     throws IOException
/*     */   {
/* 123 */     StringBuilder buf = new StringBuilder();
/*     */     while (true) {
/* 125 */       this.reader.mark(2147483647);
/* 126 */       char ch = (char)this.reader.read();
/* 127 */       if ((Character.isLetter(ch)) || (Character.isDigit(ch)) || (ch == '_') || (ch == '.') || (ch == '$'))
/*     */       {
/* 129 */         buf.append(ch);
/*     */       } else {
/* 131 */         this.reader.reset();
/* 132 */         break;
/*     */       }
/*     */     }
/* 135 */     return new String(buf);
/*     */   }
/*     */ 
/*     */   private int readSize()
/*     */     throws IOException
/*     */   {
/* 141 */     this.reader.mark(2147483647);
/* 142 */     char ch = (char)this.reader.read();
/* 143 */     if (ch == ' ') {
/* 144 */       ch = (char)this.reader.read();
/* 145 */       if (ch == '[') {
/* 146 */         String digits = readDigits();
/* 147 */         ch = (char)this.reader.read();
/* 148 */         if (ch == ']') {
/* 149 */           return Integer.parseInt(digits);
/*     */         }
/* 151 */         throw new RuntimeException(new StringBuilder().append("unexpected '").append(ch).append("' when parsing object size").toString());
/*     */       }
/*     */     }
/*     */     else {
/* 155 */       this.reader.reset();
/*     */     }
/* 157 */     return -1;
/*     */   }
/*     */ 
/*     */   private Object readValue(Class c, int size)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 163 */     if (c.isPrimitive())
/* 164 */       return readPrimitiveValue(c);
/* 165 */     if (primitiveBoxTypes.contains(c))
/* 166 */       return readPrimitiveValue(c);
/* 167 */     if (c == String.class)
/* 168 */       return readString();
/* 169 */     if (c.isArray())
/* 170 */       return readArray(c.getComponentType(), size);
/* 171 */     if (List.class.isAssignableFrom(c))
/* 172 */       return readCollection(c, size);
/* 173 */     if (Map.class.isAssignableFrom(c))
/* 174 */       return readMap(c, size);
/* 175 */     if (Set.class.isAssignableFrom(c)) {
/* 176 */       return readCollection(c, size);
/*     */     }
/* 178 */     return readObjectValue(c);
/*     */   }
/*     */ 
/*     */   private Object readObjectValue(Class c)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 184 */     char ch = (char)this.reader.read();
/* 185 */     if (ch != '{') {
/* 186 */       throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting '{'").toString());
/* 188 */     }readWhiteSpace();
/*     */ 
/* 190 */     System.out.println(new StringBuilder().append("readObjectValue ").append(c).toString());
/*     */     Object object;
/*     */     try { object = c.newInstance();
/*     */     } catch (InstantiationException e) {
/* 196 */       throw new RuntimeException(c.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 198 */       throw new RuntimeException(c.getName(), e);
/*     */     }
/*     */     while (true)
/*     */     {
/* 202 */       readWhiteSpace();
/* 203 */       String fieldName = readIdentifier();
/* 204 */       if (fieldName.length() == 0) {
/* 205 */         ch = (char)this.reader.read();
/* 206 */         if (ch == '}') {
/*     */           break;
/*     */         }
/* 209 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting '}'").toString());
/*     */       }
/* 211 */       System.out.println(new StringBuilder().append("fieldName ").append(fieldName).toString());
/* 212 */       ch = (char)this.reader.read();
/* 213 */       if (ch != ':')
/* 214 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting ':'").toString());
/* 215 */       Object value = readObject();
/* 216 */       Field field = null;
/* 217 */       Class chain = c;
/*     */       do
/*     */         try {
/* 220 */           field = chain.getDeclaredField(fieldName);
/*     */         } catch (NoSuchFieldException e) {
/* 222 */           chain = chain.getSuperclass();
/*     */         }
/* 224 */       while ((field == null) && (chain != Object.class));
/*     */ 
/* 226 */       if (field == null) {
/* 227 */         throw new RuntimeException(new StringBuilder().append("Unknown field '").append(fieldName).append("' in class ").append(c).toString());
/*     */       }
/*     */ 
/* 231 */       field.setAccessible(true);
/* 232 */       Class fieldType = field.getType();
/* 233 */       if ((value != null) && (!fieldType.isPrimitive()) && (!fieldType.isAssignableFrom(value.getClass()))) {
/* 234 */         throw new RuntimeException(new StringBuilder().append("Field type mismatch: expecting ").append(fieldType.getName()).append(" got ").append(value.getClass().getName()).append(": class=").append(c.getName()).append(" field=").append(fieldName).toString());
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 241 */         field.set(object, value);
/*     */       } catch (IllegalAccessException e) {
/* 243 */         throw new RuntimeException(new StringBuilder().append(c).append(" field ").append(fieldName).toString(), e);
/*     */       }
/*     */     }
/* 246 */     return object;
/*     */   }
/*     */ 
/*     */   private Collection readCollection(Class c, int size)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 252 */     char ch = (char)this.reader.read();
/* 253 */     if (ch != '{') {
/* 254 */       throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting '{'").toString());
/*     */     }
/*     */     Collection collection;
/*     */     try
/*     */     {
/* 260 */       collection = (Collection)c.newInstance();
/*     */     } catch (InstantiationException e) {
/* 262 */       throw new RuntimeException(c.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 264 */       throw new RuntimeException(c.getName(), e);
/*     */     }
/*     */     while (true)
/*     */     {
/* 268 */       TypedObject typedObject = readTypedObject();
/* 269 */       if (typedObject != null)
/* 270 */         collection.add(typedObject.value);
/* 271 */       ch = (char)this.reader.read();
/* 272 */       if (ch == '}')
/*     */         break;
/* 274 */       if (ch != ',') {
/* 275 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting ','").toString());
/*     */       }
/*     */     }
/* 278 */     return collection;
/*     */   }
/*     */ 
/*     */   private Map readMap(Class c, int size)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 284 */     char ch = (char)this.reader.read();
/* 285 */     if (ch != '{') {
/* 286 */       throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting '{'").toString());
/*     */     }
/*     */     Map map;
/*     */     try
/*     */     {
/* 292 */       map = (Map)c.newInstance();
/*     */     } catch (InstantiationException e) {
/* 294 */       throw new RuntimeException(c.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 296 */       throw new RuntimeException(c.getName(), e);
/*     */     }
/*     */     while (true)
/*     */     {
/* 300 */       ch = (char)this.reader.read();
/* 301 */       if (ch == '}')
/*     */         break;
/* 303 */       if (ch != '{')
/* 304 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting '{'").toString());
/* 305 */       TypedObject key = readTypedObject();
/* 306 */       ch = (char)this.reader.read();
/* 307 */       if (ch != ',')
/* 308 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting ','").toString());
/* 309 */       TypedObject value = readTypedObject();
/* 310 */       System.out.println(new StringBuilder().append("key ").append(key).append(" value ").append(value).toString());
/* 311 */       map.put(key.value, value.value);
/* 312 */       ch = (char)this.reader.read();
/* 313 */       if (ch != '}') {
/* 314 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting '}'").toString());
/*     */       }
/*     */     }
/* 317 */     return map;
/*     */   }
/*     */ 
/*     */   private Object readArray(Class c, int size)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 323 */     char ch = (char)this.reader.read();
/* 324 */     if (ch != '{') {
/* 325 */       throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting '{'").toString());
/*     */     }
/*     */ 
/* 330 */     Object array = Array.newInstance(c, size);
/*     */ 
/* 332 */     if (c.isPrimitive()) {
/* 333 */       return readPrimitiveArray(array, c);
/*     */     }
/* 335 */     int ii = 0;
/*     */     while (true) {
/* 337 */       TypedObject typedObject = readTypedObject();
/* 338 */       if (typedObject != null)
/* 339 */         Array.set(array, ii++, typedObject.value);
/* 340 */       ch = (char)this.reader.read();
/* 341 */       if (ch == '}')
/*     */         break;
/* 343 */       if (ch != ',') {
/* 344 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting ','").toString());
/*     */       }
/*     */     }
/* 347 */     return array;
/*     */   }
/*     */ 
/*     */   private Object readPrimitiveArray(Object array, Class c)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 353 */     int ii = 0;
/*     */     while (true) {
/* 355 */       this.reader.mark(2147483647);
/* 356 */       char ch = (char)this.reader.read();
/* 357 */       if (ch == '}')
/*     */         break;
/* 359 */       this.reader.reset();
/* 360 */       Object value = readPrimitiveValue(c);
/* 361 */       Array.set(array, ii++, value);
/* 362 */       ch = (char)this.reader.read();
/* 363 */       if (ch == '}')
/*     */         break;
/* 365 */       if (ch != ',')
/* 366 */         throw new RuntimeException(new StringBuilder().append("Unexpected '").append(ch).append("' when expecting ','").toString());
/*     */     }
/* 368 */     return array;
/*     */   }
/*     */ 
/*     */   private void readWhiteSpace() throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/* 375 */       this.reader.mark(2147483647);
/* 376 */       char ch = (char)this.reader.read();
/* 377 */       if (!Character.isWhitespace(ch)) {
/* 378 */         this.reader.reset();
/* 379 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object readPrimitiveValue(Class c)
/*     */     throws IOException
/*     */   {
/* 387 */     if ((c == Integer.class) || (c == Integer.TYPE)) {
/* 388 */       String digits = readDigits();
/* 389 */       return new Integer(digits);
/*     */     }
/* 391 */     if ((c == Long.class) || (c == Long.TYPE)) {
/* 392 */       String digits = readDigits();
/* 393 */       return new Long(digits);
/*     */     }
/* 395 */     if ((c == Short.class) || (c == Short.TYPE)) {
/* 396 */       String digits = readDigits();
/* 397 */       return new Short(digits);
/*     */     }
/* 399 */     if ((c == Byte.class) || (c == Byte.TYPE)) {
/* 400 */       String digits = readDigits();
/* 401 */       return new Byte(digits);
/*     */     }
/* 403 */     if ((c == Boolean.class) || (c == Boolean.TYPE)) {
/* 404 */       String valueStr = readIdentifier();
/* 405 */       if (valueStr.equals("true"))
/* 406 */         return Boolean.TRUE;
/* 407 */       if (valueStr.equals("false")) {
/* 408 */         return Boolean.FALSE;
/*     */       }
/* 410 */       throw new RuntimeException(new StringBuilder().append("unexpected '").append(valueStr).append("' for boolean value").toString());
/*     */     }
/* 412 */     if ((c == Float.class) || (c == Float.TYPE)) {
/* 413 */       String digits = readFloatDigits();
/* 414 */       return new Float(digits);
/*     */     }
/* 416 */     if ((c == Double.class) || (c == Double.TYPE)) {
/* 417 */       String digits = readFloatDigits();
/* 418 */       return new Double(digits);
/*     */     }
/* 420 */     if ((c == Character.class) || (c == Character.TYPE)) {
/* 421 */       String string = readString();
/* 422 */       return new Character(string.charAt(0));
/*     */     }
/* 424 */     return null;
/*     */   }
/*     */ 
/*     */   private String readString()
/*     */     throws IOException
/*     */   {
/* 430 */     StringBuilder buf = new StringBuilder();
/*     */     while (true) {
/* 432 */       this.reader.mark(2147483647);
/* 433 */       char ch = (char)this.reader.read();
/* 434 */       if ((ch == ',') || (ch == '\n') || (ch == '}')) {
/* 435 */         this.reader.reset();
/* 436 */         break;
/*     */       }
/* 438 */       buf.append(ch);
/*     */     }
/* 440 */     return Coding.stringDecode(new String(buf));
/*     */   }
/*     */ 
/*     */   private String readDigits()
/*     */     throws IOException
/*     */   {
/* 446 */     StringBuilder buf = new StringBuilder();
/*     */     while (true) {
/* 448 */       this.reader.mark(2147483647);
/* 449 */       char ch = (char)this.reader.read();
/* 450 */       if ((Character.isDigit(ch)) || (ch == '-')) {
/* 451 */         buf.append(ch);
/*     */       } else {
/* 453 */         this.reader.reset();
/* 454 */         break;
/*     */       }
/*     */     }
/* 457 */     return new String(buf);
/*     */   }
/*     */ 
/*     */   private String readFloatDigits()
/*     */     throws IOException
/*     */   {
/* 463 */     StringBuilder buf = new StringBuilder();
/*     */     while (true) {
/* 465 */       this.reader.mark(2147483647);
/* 466 */       char ch = (char)this.reader.read();
/* 467 */       if ((Character.isDigit(ch)) || (ch == '-') || (ch == 'E') || (ch == '.')) {
/* 468 */         buf.append(ch);
/*     */       } else {
/* 470 */         this.reader.reset();
/* 471 */         break;
/*     */       }
/*     */     }
/* 474 */     return new String(buf);
/*     */   }
/*     */ 
/*     */   private Class primitiveArrayType(Class componentType)
/*     */     throws ClassNotFoundException
/*     */   {
/* 480 */     if (componentType == Long.TYPE)
/* 481 */       return [J.class;
/* 482 */     if (componentType == Integer.TYPE)
/* 483 */       return [I.class;
/* 484 */     if (componentType == Boolean.TYPE)
/* 485 */       return [Z.class;
/* 486 */     if (componentType == Short.TYPE)
/* 487 */       return [S.class;
/* 488 */     if (componentType == Byte.TYPE)
/* 489 */       return [B.class;
/* 490 */     if (componentType == Character.TYPE)
/* 491 */       return [C.class;
/* 492 */     if (componentType == Double.TYPE)
/* 493 */       return [D.class;
/* 494 */     if (componentType == Float.TYPE)
/* 495 */       return [F.class;
/* 496 */     throw new ClassNotFoundException(new StringBuilder().append("[").append(componentType).toString());
/*     */   }
/*     */ 
/*     */   private static Object test(String string)
/*     */   {
/* 557 */     return test(string, new PackageAliases());
/*     */   }
/*     */ 
/*     */   private static Object test(String string, PackageAliases aliases)
/*     */   {
/* 562 */     System.out.println(new StringBuilder().append("TEST '").append(string).append("'").toString());
/* 563 */     ObjectReader reader = new ObjectReader(string, aliases);
/* 564 */     Object object = null;
/*     */     try {
/* 566 */       object = reader.readObject();
/* 567 */       System.out.println(object);
/* 568 */       System.out.println(object.getClass());
/*     */     } catch (IOException e) {
/* 570 */       e.printStackTrace(); } catch (ClassNotFoundException e) {
/* 571 */       e.printStackTrace();
/* 572 */     }return object;
/*     */   }
/*     */ 
/*     */   private static void testCoding(String s)
/*     */   {
/* 615 */     System.out.println(new StringBuilder().append(s).append(": '").append(Coding.stringEncode(s)).append("'").toString());
/* 616 */     if (s.equals(Coding.stringDecode(Coding.stringEncode(s))))
/* 617 */       System.out.println("PASS");
/*     */     else
/* 619 */       System.out.println(new StringBuilder().append("FAIL: ").append(Coding.stringDecode(Coding.stringEncode(s))).toString());
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 624 */     testCoding("");
/* 625 */     testCoding("abc");
/* 626 */     testCoding("1,2,3");
/* 627 */     testCoding("yum yum");
/* 628 */     testCoding("percent %");
/* 629 */     testCoding("hash #");
/* 630 */     testCoding("PQ貁");
/*     */ 
/* 632 */     test("Long=123");
/* 633 */     test("Boolean=true");
/* 634 */     test("Boolean=false");
/* 635 */     test("long=123");
/*     */ 
/* 637 */     c1 object = new c1();
/* 638 */     object.i1 = 1;
/* 639 */     c1.access$002(object, 2);
/* 640 */     object.i3 = 3;
/* 641 */     object.i4 = 4;
/* 642 */     object.s1 = "string1";
/* 643 */     object.b1 = true;
/* 644 */     object.l1 = new LinkedList();
/* 645 */     object.l2 = new ArrayList();
/* 646 */     object.l2.add(Integer.valueOf(1));
/* 647 */     object.l2.add(Integer.valueOf(2));
/* 648 */     object.l2.add("th,ree");
/* 649 */     object.l3 = new LinkedList();
/* 650 */     object.l3.add("one");
/* 651 */     object.l3.add("two");
/* 652 */     object.l3.add(null);
/* 653 */     object.m1 = new HashMap();
/* 654 */     object.m2 = new HashMap();
/* 655 */     object.m2.put(null, "null key");
/* 656 */     object.m2.put("null value", null);
/* 657 */     object.m2.put(Integer.valueOf(33), "number key");
/* 658 */     object.ia1 = new int[] { 1, 2, 3 };
/* 659 */     object.la1 = new long[] { 1L, 2L, 3L };
/* 660 */     object.sa1 = new String[] { "one", "two", "three" };
/*     */ 
/* 662 */     ObjectWriter writer = new ObjectWriter();
/* 663 */     writer.writeObject(object);
/* 664 */     c1 copy = (c1)test(writer.getString());
/* 665 */     System.out.println(new StringBuilder().append("copy.i1 ").append(copy.i1).toString());
/* 666 */     System.out.println(new StringBuilder().append("copy.i2 ").append(copy.i2).toString());
/* 667 */     System.out.println(new StringBuilder().append("copy.i3 ").append(copy.i3).toString());
/* 668 */     System.out.println(new StringBuilder().append("copy.i4 ").append(copy.i4).toString());
/* 669 */     System.out.println(new StringBuilder().append("copy.s1 ").append(copy.s1).toString());
/* 670 */     System.out.println(new StringBuilder().append("copy.b1 ").append(copy.b1).toString());
/* 671 */     System.out.println(new StringBuilder().append("copy.l1 ").append(copy.l1).toString());
/* 672 */     System.out.println(new StringBuilder().append("copy.l2 ").append(copy.l2).toString());
/* 673 */     System.out.println(new StringBuilder().append("copy.l3 ").append(copy.l3).toString());
/* 674 */     System.out.println(new StringBuilder().append("copy.m1 ").append(copy.m1).toString());
/* 675 */     System.out.println(new StringBuilder().append("copy.m2 ").append(copy.m2).toString());
/* 676 */     System.out.println(new StringBuilder().append("copy.ia1 ").append(copy.ia1).toString());
/* 677 */     System.out.println(new StringBuilder().append("copy.la1 ").append(copy.la1).toString());
/* 678 */     System.out.println(new StringBuilder().append("copy.sa1 ").append(copy.sa1).toString());
/*     */ 
/* 680 */     ObjectWriter writer2 = new ObjectWriter();
/* 681 */     writer2.writeObject(copy);
/* 682 */     System.out.println(new StringBuilder().append("roundtrip ").append(writer2.getString().equals(writer.getString())).toString());
/*     */ 
/* 684 */     PackageAliases aliases = new PackageAliases();
/* 685 */     aliases.addAlias("j.u", "java.util");
/* 686 */     aliases.addAlias("m.s.o", "atavism.server.objects");
/* 687 */     aliases.addAlias("m.s.e", "atavism.server.engine");
/* 688 */     aliases.addAlias("m.m.o", "atavism.agis.objects");
/*     */ 
/* 690 */     Namespace.COMBAT = new Namespace("NS.combat", 1);
/*     */   }
/*     */ 
/*     */   private static class c1
/*     */   {
/*     */     String s;
/*     */     public int i1;
/*     */     private int i2;
/*     */     protected int i3;
/*     */     int i4;
/*     */     String s1;
/*     */     Boolean bNull;
/*     */     boolean b1;
/*     */     List lNull;
/*     */     List l1;
/*     */     ArrayList l2;
/*     */     List<String> l3;
/*     */     Map mNull;
/*     */     Map m1;
/*     */     Map m2;
/*     */     int[] ia0;
/*     */     int[] ia1;
/*     */     long[] la1;
/*     */     String[] sa1;
/* 596 */     byte byte1 = 1;
/* 597 */     byte byte2 = -128;
/* 598 */     float f1 = 9.987004E+011F;
/* 599 */     float f2 = 1.0E-011F;
/*     */     char c0;
/* 601 */     char c1 = '\001';
/* 602 */     char cspace = ' ';
/* 603 */     char cpercent = '%';
/* 604 */     char chash = '#';
/* 605 */     char ca = 'a';
/* 606 */     char cx = '}';
/* 607 */     char cc = ',';
/* 608 */     char cn = '\n';
/* 609 */     char ct = '\t';
/* 610 */     char cu = 'ሴ';
/*     */   }
/*     */ 
/*     */   private static final class NullClass
/*     */   {
/*     */   }
/*     */ 
/*     */   private static class TypedObject
/*     */   {
/*     */     public Class type;
/*     */     public Object value;
/*     */ 
/*     */     public TypedObject(Class type, Object value)
/*     */     {
/* 537 */       this.type = type;
/* 538 */       this.value = value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.persistence.ObjectReader
 * JD-Core Version:    0.6.0
 */