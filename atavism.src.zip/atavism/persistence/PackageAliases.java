/*    */ package atavism.persistence;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class PackageAliases
/*    */ {
/* 23 */   private HashMap<String, String> aliasToPackage = new HashMap();
/*    */ 
/* 25 */   private HashMap<String, String> packageToAlias = new HashMap();
/*    */ 
/*    */   public void addAlias(String alias, String packageName)
/*    */   {
/*  9 */     this.aliasToPackage.put(alias, packageName);
/* 10 */     this.packageToAlias.put(packageName, alias);
/*    */   }
/*    */ 
/*    */   public String getAlias(String packageName)
/*    */   {
/* 15 */     return (String)this.packageToAlias.get(packageName);
/*    */   }
/*    */ 
/*    */   public String getPackage(String alias)
/*    */   {
/* 20 */     return (String)this.aliasToPackage.get(alias);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.persistence.PackageAliases
 * JD-Core Version:    0.6.0
 */