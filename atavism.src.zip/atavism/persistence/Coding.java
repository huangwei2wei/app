/*    */ package atavism.persistence;
/*    */ 
/*    */ class Coding
/*    */ {
/* 91 */   private static final char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*    */ 
/*    */   static String stringEncode(String string)
/*    */   {
/*  9 */     StringBuilder sb = null;
/* 10 */     for (int ii = 0; ii < string.length(); ii++) {
/* 11 */       char c = string.charAt(ii);
/* 12 */       if (c < '') {
/* 13 */         if ((c < ' ') || (c == ',') || (c == '}') || (c == '\n') || (c == '%') || (c == '#') || (c == ''))
/*    */         {
/* 15 */           if (sb == null) {
/* 16 */             sb = new StringBuilder();
/* 17 */             sb.append(string.substring(0, ii));
/*    */           }
/* 19 */           sb.append('%');
/* 20 */           sb.append(hexDigits[((byte)c >> 4 & 0xF)]);
/* 21 */           sb.append(hexDigits[((byte)c >> 0 & 0xF)]);
/*    */         }
/* 23 */         else if (sb != null) {
/* 24 */           sb.append(c);
/*    */         }
/*    */       } else {
/* 27 */         if (sb == null) {
/* 28 */           sb = new StringBuilder();
/* 29 */           sb.append(string.substring(0, ii));
/*    */         }
/* 31 */         int u16 = c;
/* 32 */         sb.append('#');
/* 33 */         sb.append(hexDigits[(u16 >> 12 & 0xF)]);
/* 34 */         sb.append(hexDigits[(u16 >> 8 & 0xF)]);
/* 35 */         sb.append(hexDigits[(u16 >> 4 & 0xF)]);
/* 36 */         sb.append(hexDigits[(u16 >> 0 & 0xF)]);
/*    */       }
/*    */     }
/*    */ 
/* 40 */     if (sb != null) {
/* 41 */       return new String(sb);
/*    */     }
/* 43 */     return string;
/*    */   }
/*    */ 
/*    */   private static int decodeHex(char c)
/*    */   {
/* 48 */     if ((c >= '0') && (c <= '9'))
/* 49 */       return c - '0';
/* 50 */     if ((c >= 'a') && (c <= 'f'))
/* 51 */       return c - 'a' + 10;
/* 52 */     if ((c >= 'A') && (c <= 'F'))
/* 53 */       return c - 'A' + 10;
/* 54 */     return -1;
/*    */   }
/*    */ 
/*    */   static String stringDecode(String string)
/*    */   {
/* 59 */     StringBuilder sb = null;
/* 60 */     for (int ii = 0; ii < string.length(); ii++) {
/* 61 */       char c = string.charAt(ii);
/* 62 */       if (c == '%') {
/* 63 */         if (sb == null) {
/* 64 */           sb = new StringBuilder();
/* 65 */           sb.append(string.substring(0, ii));
/*    */         }
/* 67 */         ii++; int u8 = decodeHex(string.charAt(ii)) << 4;
/* 68 */         ii++; u8 |= decodeHex(string.charAt(ii));
/* 69 */         sb.append((char)u8);
/*    */       }
/* 71 */       else if (c == '#') {
/* 72 */         if (sb == null) {
/* 73 */           sb = new StringBuilder();
/* 74 */           sb.append(string.substring(0, ii));
/*    */         }
/* 76 */         ii++; int u16 = decodeHex(string.charAt(ii)) << 12;
/* 77 */         ii++; u16 |= decodeHex(string.charAt(ii)) << 8;
/* 78 */         ii++; u16 |= decodeHex(string.charAt(ii)) << 4;
/* 79 */         ii++; u16 |= decodeHex(string.charAt(ii));
/* 80 */         sb.append((char)u16);
/*    */       }
/* 82 */       else if (sb != null) {
/* 83 */         sb.append(c);
/*    */       }
/*    */     }
/* 85 */     if (sb != null) {
/* 86 */       return new String(sb);
/*    */     }
/* 88 */     return string;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.persistence.Coding
 * JD-Core Version:    0.6.0
 */