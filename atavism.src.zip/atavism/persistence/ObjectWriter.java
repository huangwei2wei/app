/*     */ package atavism.persistence;
/*     */ 
/*     */ import atavism.server.engine.Namespace;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ObjectWriter
/*     */ {
/*     */   private static final int INITIAL_CAPACITY = 4096;
/* 394 */   private static Map<Class, String> simpleClassNames = new HashMap();
/*     */   private StringBuilder output;
/*     */   private int indent;
/*     */   private PackageAliases aliases;
/*     */ 
/*     */   public ObjectWriter()
/*     */   {
/* 398 */     simpleClassNames.put(Long.class, "Long");
/* 399 */     simpleClassNames.put(Integer.class, "Integer");
/* 400 */     simpleClassNames.put(Boolean.class, "Boolean");
/* 401 */     simpleClassNames.put(Short.class, "Short");
/* 402 */     simpleClassNames.put(Byte.class, "Byte");
/* 403 */     simpleClassNames.put(Character.class, "Character");
/* 404 */     simpleClassNames.put(Double.class, "Double");
/* 405 */     simpleClassNames.put(Float.class, "Float");
/* 406 */     simpleClassNames.put(String.class, "String");
/*     */ 
/*  33 */     this.output = new StringBuilder(4096);
/*  34 */     this.aliases = new PackageAliases();
/*     */   }
/*     */ 
/*     */   public ObjectWriter(PackageAliases aliases)
/*     */   {
/* 398 */     simpleClassNames.put(Long.class, "Long");
/* 399 */     simpleClassNames.put(Integer.class, "Integer");
/* 400 */     simpleClassNames.put(Boolean.class, "Boolean");
/* 401 */     simpleClassNames.put(Short.class, "Short");
/* 402 */     simpleClassNames.put(Byte.class, "Byte");
/* 403 */     simpleClassNames.put(Character.class, "Character");
/* 404 */     simpleClassNames.put(Double.class, "Double");
/* 405 */     simpleClassNames.put(Float.class, "Float");
/* 406 */     simpleClassNames.put(String.class, "String");
/*     */ 
/*  39 */     this.output = new StringBuilder(4096);
/*  40 */     this.aliases = aliases;
/*     */   }
/*     */ 
/*     */   public void writeObject(Object object)
/*     */   {
/*     */     try {
/*  46 */       if (object == null) {
/*  47 */         this.output.append("null");
/*  48 */         return;
/*     */       }
/*  50 */       Class c = object.getClass();
/*  51 */       writeType(c);
/*  52 */       writeSize(object, c);
/*  53 */       this.output.append('=');
/*  54 */       writeValue(object);
/*     */     }
/*     */     catch (IllegalAccessException e) {
/*  57 */       throw new RuntimeException("writeObject", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public PackageAliases getAliases()
/*     */   {
/*  63 */     return this.aliases;
/*     */   }
/*     */ 
/*     */   public void setAliases(PackageAliases aliases)
/*     */   {
/*  68 */     this.aliases = aliases;
/*     */   }
/*     */ 
/*     */   private void writeValue(Object value)
/*     */     throws IllegalAccessException
/*     */   {
/*  75 */     Class c = value.getClass();
/*  76 */     if (c.isPrimitive())
/*  77 */       this.output.append("PRIMITIVE");
/*  78 */     else if (c == Long.class)
/*  79 */       this.output.append((Long)value);
/*  80 */     else if (c == Boolean.class)
/*  81 */       this.output.append((Boolean)value);
/*  82 */     else if (c == String.class)
/*  83 */       this.output.append(Coding.stringEncode((String)value));
/*  84 */     else if (c == Integer.class)
/*  85 */       this.output.append((Integer)value);
/*  86 */     else if (c == Float.class)
/*  87 */       this.output.append((Float)value);
/*  88 */     else if (c == Double.class)
/*  89 */       this.output.append((Double)value);
/*  90 */     else if (c == Byte.class)
/*  91 */       this.output.append((Byte)value);
/*  92 */     else if (c == Character.class)
/*  93 */       this.output.append((Character)value);
/*  94 */     else if (c.isArray())
/*  95 */       writeArray(value);
/*  96 */     else if (List.class.isAssignableFrom(c))
/*  97 */       writeList((List)value);
/*  98 */     else if (Map.class.isAssignableFrom(c))
/*  99 */       writeMap((Map)value);
/* 100 */     else if (Set.class.isAssignableFrom(c))
/* 101 */       writeSet((Set)value);
/*     */     else
/* 103 */       writeObjectValue(value);
/*     */   }
/*     */ 
/*     */   private void writeArray(Object array)
/*     */     throws IllegalAccessException
/*     */   {
/* 109 */     if (array.getClass().getComponentType().isPrimitive()) {
/* 110 */       writePrimitiveArray(array);
/* 111 */       return;
/*     */     }
/* 113 */     this.output.append('{');
/* 114 */     int length = Array.getLength(array);
/* 115 */     for (int ii = 0; ii < length; ii++) {
/* 116 */       Object value = Array.get(array, ii);
/* 117 */       if (value == null) {
/* 118 */         this.output.append("null,");
/*     */       }
/*     */       else {
/* 121 */         writeType(value.getClass());
/* 122 */         writeSize(value, value.getClass());
/* 123 */         this.output.append('=');
/* 124 */         writeValue(value);
/* 125 */         this.output.append(',');
/*     */       }
/*     */     }
/* 127 */     if (length > 0)
/* 128 */       this.output.setLength(this.output.length() - 1);
/* 129 */     this.output.append('}');
/*     */   }
/*     */ 
/*     */   private void writePrimitiveArray(Object array)
/*     */     throws IllegalAccessException
/*     */   {
/* 136 */     Class type = array.getClass().getComponentType();
/* 137 */     this.output.append('{');
/* 138 */     int length = Array.getLength(array);
/* 139 */     for (int ii = 0; ii < length; ii++) {
/* 140 */       if (type == Integer.TYPE)
/* 141 */         this.output.append(Array.getInt(array, ii));
/* 142 */       else if (type == Long.TYPE)
/* 143 */         this.output.append(Array.getLong(array, ii));
/* 144 */       else if (type == Short.TYPE)
/* 145 */         this.output.append(Array.getShort(array, ii));
/* 146 */       else if (type == Byte.TYPE)
/* 147 */         this.output.append(Array.getByte(array, ii));
/* 148 */       else if (type == Boolean.TYPE)
/* 149 */         this.output.append(Array.getBoolean(array, ii));
/* 150 */       else if (type == Character.TYPE)
/* 151 */         this.output.append(Coding.stringEncode("" + Array.getChar(array, ii)));
/* 152 */       else if (type == Double.TYPE)
/* 153 */         this.output.append(Array.getDouble(array, ii));
/* 154 */       else if (type == Float.TYPE)
/* 155 */         this.output.append(Array.getFloat(array, ii));
/* 156 */       this.output.append(',');
/*     */     }
/* 158 */     if (length > 0)
/* 159 */       this.output.setLength(this.output.length() - 1);
/* 160 */     this.output.append('}');
/*     */   }
/*     */ 
/*     */   private void writeList(List list)
/*     */     throws IllegalAccessException
/*     */   {
/* 167 */     this.output.append('{');
/* 168 */     for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 169 */       if (value == null) {
/* 170 */         this.output.append("null,");
/* 171 */         continue;
/*     */       }
/* 173 */       writeType(value.getClass());
/* 174 */       writeSize(value, value.getClass());
/* 175 */       this.output.append('=');
/* 176 */       writeValue(value);
/* 177 */       this.output.append(',');
/*     */     }
/* 179 */     if (list.size() > 0)
/* 180 */       this.output.setLength(this.output.length() - 1);
/* 181 */     this.output.append('}');
/*     */   }
/*     */ 
/*     */   private void writeMap(Map map)
/*     */     throws IllegalAccessException
/*     */   {
/* 187 */     this.output.append('{');
/* 188 */     for (Map.Entry entry : map.entrySet()) {
/* 189 */       this.output.append('{');
/* 190 */       writeObject(entry.getKey());
/* 191 */       this.output.append(',');
/* 192 */       writeObject(entry.getValue());
/* 193 */       this.output.append('}');
/*     */     }
/* 195 */     this.output.append('}');
/*     */   }
/*     */ 
/*     */   private void writeSet(Set set)
/*     */     throws IllegalAccessException
/*     */   {
/* 201 */     this.output.append('{');
/* 202 */     for (Iterator i$ = set.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 203 */       writeType(value.getClass());
/* 204 */       writeSize(value, value.getClass());
/* 205 */       this.output.append('=');
/* 206 */       writeValue(value);
/* 207 */       this.output.append(',');
/*     */     }
/* 209 */     if (set.size() > 0)
/* 210 */       this.output.setLength(this.output.length() - 1);
/* 211 */     this.output.append('}');
/*     */   }
/*     */ 
/*     */   private void writeObjectValue(Object value)
/*     */     throws IllegalAccessException
/*     */   {
/* 217 */     this.output.append('{');
/* 218 */     this.output.append('\n');
/* 219 */     this.indent += 1;
/* 220 */     writeObject(value, value.getClass());
/* 221 */     this.indent -= 1;
/* 222 */     writeIndent();
/* 223 */     this.output.append('}');
/*     */   }
/*     */ 
/*     */   private void writeTypedObject(Object object, Class c)
/*     */   {
/*     */     try {
/* 229 */       if (object != null) {
/* 230 */         writeType(object.getClass());
/* 231 */         writeSize(object, c);
/* 232 */         this.output.append('=');
/* 233 */         writeValue(object);
/*     */       }
/*     */       else {
/* 236 */         writeType(c);
/*     */       }
/*     */     } catch (IllegalAccessException e) {
/* 239 */       throw new RuntimeException("writeObject", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeSize(Object object, Class c)
/*     */   {
/* 245 */     if ((List.class.isAssignableFrom(c)) || (Set.class.isAssignableFrom(c)))
/*     */     {
/* 247 */       this.output.append(" [");
/* 248 */       this.output.append(((Collection)object).size());
/* 249 */       this.output.append(']');
/*     */     }
/* 251 */     else if (Map.class.isAssignableFrom(c)) {
/* 252 */       this.output.append(" [");
/* 253 */       this.output.append(((Map)object).size());
/* 254 */       this.output.append(']');
/*     */     }
/* 256 */     else if (c.isArray()) {
/* 257 */       this.output.append(" [");
/* 258 */       this.output.append(Array.getLength(object));
/* 259 */       this.output.append(']');
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeObject(Object object, Class c)
/*     */     throws IllegalAccessException
/*     */   {
/* 266 */     Class sc = c.getSuperclass();
/* 267 */     System.out.println(c.getName() + " extends " + sc.getName());
/* 268 */     if ((sc != null) && (sc != Object.class))
/* 269 */       writeObject(object, sc);
/* 270 */     Field[] fields = c.getDeclaredFields();
/* 271 */     for (Field field : fields) {
/* 272 */       int modifiers = field.getModifiers();
/* 273 */       if (((modifiers & 0x10) != 0) || ((modifiers & 0x8) != 0) || ((modifiers & 0x80) != 0))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 278 */       System.out.println(field.getName());
/* 279 */       System.out.println(field.toString());
/* 280 */       System.out.println(field.toGenericString());
/* 281 */       field.setAccessible(true);
/* 282 */       Class fieldType = field.getType();
/* 283 */       writeIndent();
/* 284 */       this.output.append(field.getName());
/* 285 */       this.output.append(':');
/* 286 */       if (fieldType.isPrimitive())
/* 287 */         writePrimitive(object, field);
/*     */       else
/* 289 */         writeTypedObject(field.get(object), fieldType);
/* 290 */       this.output.append('\n');
/*     */     }
/*     */   }
/*     */ 
/*     */   public StringBuilder getStringBuilder()
/*     */   {
/* 296 */     return this.output;
/*     */   }
/*     */ 
/*     */   public String getString()
/*     */   {
/* 301 */     return this.output.toString();
/*     */   }
/*     */ 
/*     */   private void writePrimitive(Object object, Field field)
/*     */     throws IllegalAccessException
/*     */   {
/* 307 */     Class fieldType = field.getType();
/* 308 */     if (fieldType == Long.TYPE) {
/* 309 */       this.output.append("long=");
/* 310 */       this.output.append(field.getLong(object));
/*     */     }
/* 312 */     else if (fieldType == Boolean.TYPE) {
/* 313 */       this.output.append("boolean=");
/* 314 */       this.output.append(field.getBoolean(object));
/*     */     }
/* 316 */     else if (fieldType == Integer.TYPE) {
/* 317 */       this.output.append("int=");
/* 318 */       this.output.append(field.getInt(object));
/*     */     }
/* 320 */     else if (fieldType == Float.TYPE) {
/* 321 */       this.output.append("float=");
/* 322 */       this.output.append(field.getFloat(object));
/*     */     }
/* 324 */     else if (fieldType == Double.TYPE) {
/* 325 */       this.output.append("double=");
/* 326 */       this.output.append(field.getDouble(object));
/*     */     }
/* 328 */     else if (fieldType == Byte.TYPE) {
/* 329 */       this.output.append("byte=");
/* 330 */       this.output.append(field.getByte(object));
/*     */     }
/* 332 */     else if (fieldType == Short.TYPE) {
/* 333 */       this.output.append("short=");
/* 334 */       this.output.append(field.getShort(object));
/*     */     }
/* 336 */     else if (fieldType == Character.TYPE) {
/* 337 */       this.output.append("char=");
/* 338 */       this.output.append(Coding.stringEncode("" + field.getChar(object)));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeType(Class c)
/*     */   {
/* 344 */     String shortName = (String)simpleClassNames.get(c);
/* 345 */     if (shortName != null) {
/* 346 */       this.output.append(shortName);
/* 347 */     } else if (c.isPrimitive()) {
/* 348 */       this.output.append(c.getName());
/*     */     }
/* 350 */     else if (c.isArray()) {
/* 351 */       this.output.append("array ");
/* 352 */       writeType(c.getComponentType());
/*     */     }
/* 354 */     else if (List.class.isAssignableFrom(c)) {
/* 355 */       this.output.append("list ");
/* 356 */       writeClassName(c.getName());
/*     */     }
/* 358 */     else if (Map.class.isAssignableFrom(c)) {
/* 359 */       this.output.append("map ");
/* 360 */       writeClassName(c.getName());
/*     */     }
/* 362 */     else if (Set.class.isAssignableFrom(c)) {
/* 363 */       this.output.append("set ");
/* 364 */       writeClassName(c.getName());
/*     */     }
/*     */     else {
/* 367 */       this.output.append("object ");
/* 368 */       writeClassName(c.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeClassName(String className)
/*     */   {
/* 374 */     int dot = className.lastIndexOf(46);
/* 375 */     if (dot == -1) {
/* 376 */       this.output.append(className);
/* 377 */       return;
/*     */     }
/* 379 */     String alias = this.aliases.getAlias(className.substring(0, dot));
/* 380 */     if (alias != null) {
/* 381 */       this.output.append(alias);
/* 382 */       this.output.append(className.substring(dot));
/*     */     }
/*     */     else {
/* 385 */       this.output.append(className);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeIndent() {
/* 390 */     for (int ii = this.indent * 2; ii > 0; ii--)
/* 391 */       this.output.append(' ');
/*     */   }
/*     */ 
/*     */   public static void encode()
/*     */   {
/*     */     try
/*     */     {
/* 425 */       URI uri = new URI(null, null, "abc_123space dash-less<greater>newline\n");
/* 426 */       System.out.println("ASCII");
/* 427 */       System.out.println(uri.toASCIIString());
/* 428 */       System.out.println("toString");
/* 429 */       System.out.println(uri.toString());
/* 430 */       String str = uri.toASCIIString().substring(1);
/* 431 */       URI uri2 = new URI("#" + str);
/* 432 */       System.out.println(uri2.getFragment());
/*     */     } catch (URISyntaxException e) {
/* 434 */       System.out.println("EXCEPTION " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try {
/* 441 */       System.out.println(args.getClass());
/* 442 */       System.out.println(new int[4].getClass());
/* 443 */       Class c = Class.forName("[Ljava.lang.Long;");
/* 444 */       System.out.println(c);
/* 445 */       System.exit(1); } catch (Exception e) {
/* 446 */       System.out.println(e);
/* 447 */     }PackageAliases aliases = new PackageAliases();
/* 448 */     aliases.addAlias("j.u", "java.util");
/* 449 */     aliases.addAlias("m.s.o", "atavism.server.objects");
/* 450 */     aliases.addAlias("m.s.e", "atavism.server.engine");
/* 451 */     aliases.addAlias("m.m.o", "atavism.agis.objects");
/*     */ 
/* 453 */     Namespace.COMBAT = new Namespace("NS.combat", 1);
/*     */ 
/* 468 */     test1 t1 = new test1(null);
/* 469 */     t1.arrayTest1[0] = new test1(null);
/* 470 */     ObjectWriter writer2 = new ObjectWriter(aliases);
/* 471 */     writer2.writeObject(t1);
/* 472 */     System.out.println(writer2.getString());
/*     */   }
/*     */ 
/*     */   private static class test1
/*     */   {
/* 414 */     public int[] arrayInt = { 1, 2, 3 };
/* 415 */     public byte[] arrayByte = { 1, 2, 3, 127, -1, -128 };
/* 416 */     public String[] arrayString = { "one", "two", "three", null };
/* 417 */     public int[] arrayNull = null;
/* 418 */     public test1[] arrayTest1 = { null };
/* 419 */     public test1[] arrayTestNull = null;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.persistence.ObjectWriter
 * JD-Core Version:    0.6.0
 */