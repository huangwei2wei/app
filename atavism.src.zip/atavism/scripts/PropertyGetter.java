/*    */ package atavism.scripts;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class PropertyGetter
/*    */ {
/* 15 */   static String propFile = System.getProperty("atavism.propertyfile");
/* 16 */   static Properties properties = new Properties();
/*    */   static String propName;
/* 18 */   static String win_env_var = System.getProperty("win_env_var");
/*    */ 
/*    */   public static void main(String[] args) {
/* 21 */     if (propFile == null) {
/* 22 */       System.err.println("ERROR: Property file must be specified with -D.");
/* 23 */       System.exit(1);
/*    */     }
/*    */ 
/* 26 */     if (args.length < 1) {
/* 27 */       System.err.println("ERROR: Specify property name!");
/* 28 */       System.exit(1);
/*    */     }
/*    */ 
/* 31 */     propName = args[0];
/* 32 */     String defaultValue = null;
/* 33 */     if (args.length > 1) {
/* 34 */       defaultValue = args[1];
/*    */     }
/* 36 */     File f = new File(propFile);
/*    */ 
/* 38 */     if (f.exists()) {
/*    */       try {
/* 40 */         properties.load(new FileInputStream(propFile));
/*    */       } catch (IOException e) {
/* 42 */         System.out.println("Error finding Properties file - " + f.getAbsoluteFile());
/*    */       }
/*    */ 
/* 45 */       String propValue = properties.getProperty(propName, defaultValue);
/*    */ 
/* 48 */       if (win_env_var == null) {
/* 49 */         System.out.print(propValue);
/*    */       }
/*    */       else
/* 52 */         System.out.println("set " + win_env_var + "=" + propValue);
/*    */     }
/*    */     else {
/* 55 */       System.out.println("Properties file " + propFile + " does not exist.");
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getWorldName() {
/* 60 */     return properties.getProperty("atavism.worldname");
/*    */   }
/*    */ 
/*    */   public String getWorldFileName() {
/* 64 */     return properties.getProperty("atavism.aowfile");
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.scripts.PropertyGetter
 * JD-Core Version:    0.6.0
 */