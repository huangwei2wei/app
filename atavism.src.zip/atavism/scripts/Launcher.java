/*     */ package atavism.scripts;
/*     */ 
/*     */ import atavism.server.engine.PropertyFileReader;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ public class Launcher
/*     */ {
/* 173 */   public static Properties properties = new Properties();
/*     */   public String propFile;
/*     */ 
/*     */   Launcher()
/*     */   {
/*  58 */     this.propFile = System.getProperty("atavism.propertyfile");
/*  59 */     System.out.println("Using property file " + this.propFile);
/*  60 */     PropertyFileReader pfr = new PropertyFileReader();
/*  61 */     properties = pfr.readPropFile();
/*     */   }
/*     */ 
/*     */   public int exit() {
/*  65 */     System.runFinalization();
/*  66 */     ManagementFactory.getPlatformMBeanServer();
/*     */     try {
/*  68 */       ObjectName name = new ObjectName("atavism.server.engine.Launcher:type=Launcher");
/*  69 */       ManagementFactory.getPlatformMBeanServer().unregisterMBean(name);
/*  70 */       System.out.println("Unregistered Launcher with JMX mgmt agent");
/*  71 */       System.exit(0);
/*     */     }
/*     */     catch (Exception ex) {
/*  74 */       System.out.println("Message Server: caught exception: " + ex);
/*  75 */       ex.printStackTrace();
/*     */     }
/*  77 */     System.exit(0);
/*  78 */     return 0;
/*     */   }
/*     */ 
/*     */   public void startAllServers()
/*     */   {
/*  86 */     String servers = properties.getProperty("atavism.servers");
/*     */     try {
/*  88 */       if (servers != null) {
/*  89 */         String[] serverArray = servers.split(",");
/*  90 */         for (int i = 0; i < serverArray.length; i++)
/*  91 */           if (serverArray[i] != null)
/*     */           {
/*  93 */             System.out.println(">>>Starting server #" + i);
/*  94 */             startServer(serverArray[i]);
/*  95 */             Thread.sleep(5000L);
/*     */           } else {
/*  97 */             System.out.println("ERROR - server " + i + " is null");
/*     */           }
/*     */       }
/*     */       else {
/* 101 */         System.out.println("server list is null!");
/*     */       }
/*     */     } catch (Exception ex) {
/* 104 */       System.out.println("Error starting all servers: caught exception: " + ex);
/* 105 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/* 110 */   public void printElements(Vector<String> v) { System.out.println("ELEMENTS OF COMMAND VECTOR");
/* 111 */     for (Iterator it = v.iterator(); it.hasNext(); System.out.println(it.next()));
/*     */   }
/*     */ 
/*     */   public Process startServer(String svrName) {
/* 115 */     Vector cmds = new Vector();
/* 116 */     Process p = null;
/* 117 */     System.out.println("Starting " + svrName);
/* 118 */     cmds.addElement("java");
/* 119 */     cmds.addElement("-Datavism.propertyfile=" + this.propFile);
/* 120 */     cmds.addElement("-Dcom.sun.management.jmxremote");
/* 121 */     cmds.addElement("-Datavism.servername=" + svrName);
/*     */ 
/* 123 */     if (svrName == "messageServer")
/* 124 */       cmds.addElement("atavism.msgsvr.MessageServer");
/*     */     else
/* 126 */       cmds.addElement("atavism.server.engine.Engine");
/*     */     try {
/* 128 */       String scriptlist = properties.getProperty(svrName + ".scripts");
/* 129 */       if (scriptlist != null)
/*     */       {
/* 131 */         String[] scripts = scriptlist.split(",");
/* 132 */         System.out.print("scripts: ");
/* 133 */         for (int i = 0; i < scripts.length; i++) {
/* 134 */           System.out.print(scripts[i] + ",  ");
/* 135 */           cmds.addElement(scripts[i]);
/*     */         }
/*     */ 
/* 138 */         System.out.println("\n---------");
/*     */       } else {
/* 140 */         System.out.println("No scripts specified for " + svrName);
/*     */       }
/* 142 */       List lCmds = cmds;
/* 143 */       ProcessBuilder pb = new ProcessBuilder(lCmds);
/* 144 */       if (pb != null) {
/* 145 */         String cp = System.getProperty("java.class.path");
/* 146 */         Map env = pb.environment();
/* 147 */         env.put("CLASSPATH", cp);
/* 148 */         p = pb.start();
/*     */       } else {
/* 150 */         System.out.println("pb is null!");
/*     */       }
/*     */     } catch (Exception e) {
/* 153 */       System.out.println("Exception in Launcher ");
/* 154 */       e.printStackTrace();
/*     */     }
/* 156 */     return p;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 160 */     Launcher launcher = new Launcher();
/* 161 */     String command = "all";
/* 162 */     command = args[0];
/* 163 */     if (command == null)
/* 164 */       command = "all";
/*     */     try {
/* 166 */       launcher.startAllServers();
/*     */     } catch (Exception e) {
/* 168 */       System.out.println("Exception in Launcher ");
/* 169 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.scripts.Launcher
 * JD-Core Version:    0.6.0
 */