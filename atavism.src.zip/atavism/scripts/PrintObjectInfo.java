/*    */ package atavism.scripts;
/*    */ 
/*    */ import atavism.server.engine.Database;
/*    */ import atavism.server.engine.Namespace;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.Log;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class PrintObjectInfo
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 18 */       if (args.length != 5) {
/* 19 */         System.err.println("need dbhost, dbname, user, password, dbid, namespace");
/* 20 */         System.exit(1);
/*    */       }
/* 22 */       String host = args[0];
/* 23 */       String dbname = args[1];
/* 24 */       String user = args[2];
/* 25 */       String password = args[3];
/* 26 */       OID dbid = OID.parseLong(args[4]);
/* 27 */       Namespace namespace = Namespace.intern(args[5]);
/*    */ 
/* 29 */       Database db = new Database();
/*    */ 
/* 31 */       String dburl = "jdbc:mysql://" + host + "/" + dbname;
/* 32 */       db.connect(dburl, user, password);
/*    */ 
/* 35 */       InputStream is = db.retrieveEntityDataByOidAndNamespace(dbid, namespace);
/* 36 */       Log.debug("retrieved character data");
/*    */ 
/* 39 */       ObjectInputStream ois = new ObjectInputStream(is);
/* 40 */       Log.debug("deserializing the object now");
/* 41 */       AOObject obj = (AOObject)ois.readObject();
/*    */ 
/* 43 */       if (Log.loggingDebug)
/* 44 */         Log.debug("deserialized object: " + obj);
/*    */     }
/*    */     catch (Exception e) {
/* 47 */       Log.exception("PrintObjectInfo.main got exception", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.scripts.PrintObjectInfo
 * JD-Core Version:    0.6.0
 */