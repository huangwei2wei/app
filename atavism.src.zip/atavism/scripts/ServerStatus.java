/*    */ package atavism.scripts;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class ServerStatus
/*    */ {
/* 77 */   public static String RUNNING = "java.exe";
/* 78 */   public static String NOT_RUNNING = "No tasks";
/* 79 */   public static String PATH = "run";
/* 80 */   public static String STATUSFILE = "status.txt";
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/*  9 */     boolean running = false;
/*    */ 
/* 12 */     if (args.length < 2) {
/* 13 */       System.err.println("Error - specify server name and world name on cmd line.");
/* 14 */       System.exit(1);
/*    */     } else {
/* 16 */       String worldName = args[0];
/* 17 */       String serverName = getServerName(args[1]);
/*    */ 
/* 19 */       String sFile = PATH + File.separator + worldName + File.separator + STATUSFILE;
/* 20 */       File f = new File(sFile);
/* 21 */       if (!f.exists()) {
/* 22 */         System.err.println("Error - Staus file " + STATUSFILE + " does not exist");
/* 23 */         System.exit(1);
/*    */       }
/*    */ 
/*    */       try
/*    */       {
/* 28 */         BufferedReader inputStream = new BufferedReader(new FileReader(sFile));
/*    */         String line;
/* 31 */         while ((line = inputStream.readLine()) != null) {
/* 32 */           if ((line.length() > 0) && (line.contains("java.exe")))
/* 33 */             running = true;
/*    */         }
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 38 */         System.err.println("File input error");
/*    */       }
/*    */ 
/* 41 */       if (running == true)
/* 42 */         System.out.println(serverName + ": running");
/*    */       else
/* 44 */         System.out.println(serverName + ": not running");
/*    */     }
/*    */   }
/*    */ 
/*    */   public static String getServerName(String sName)
/*    */   {
/* 50 */     String s = "default";
/* 51 */     if (sName.equals("anim"))
/* 52 */       s = "Animation server";
/* 53 */     else if (sName.equals("combat"))
/* 54 */       s = "Combat server";
/* 55 */     else if (sName.equals("domain"))
/* 56 */       s = "Message domain server";
/* 57 */     else if (sName.equals("objmgr"))
/* 58 */       s = "Object server";
/* 59 */     else if (sName.equals("wmgr_1"))
/* 60 */       s = "World manager";
/* 61 */     else if (sName.equals("login_manager"))
/* 62 */       s = "Login server";
/* 63 */     else if (sName.equals("mobserver"))
/* 64 */       s = "Mob server";
/* 65 */     else if (sName.equals("proxy_1"))
/* 66 */       s = "Proxy server";
/* 67 */     else if (sName.equals("startup"))
/* 68 */       s = "Startup monitor";
/* 69 */     else if (sName.equals("instance"))
/* 70 */       s = "Instance server";
/* 71 */     else if (sName.equals("voiceserver")) {
/* 72 */       s = "Voice server";
/*    */     }
/* 74 */     return s;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.scripts.ServerStatus
 * JD-Core Version:    0.6.0
 */