/*    */ package atavism.scripts;
/*    */ 
/*    */ import atavism.server.engine.Database;
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.engine.OIDManager;
/*    */ import atavism.server.util.Log;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class DeleteCharacter
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 17 */       if (args.length != 6) {
/* 18 */         System.err.println("need dbhost, dbname, dbuser, dbpassword, atavismid, world_name");
/* 19 */         System.exit(1);
/*    */       }
/* 21 */       Database db = new Database();
/*    */ 
/* 23 */       String host = args[0];
/* 24 */       String dbname = args[1];
/* 25 */       String user = args[2];
/* 26 */       String password = args[3];
/*    */ 
/* 28 */       OID atavismID = OID.parseLong(args[4]);
/* 29 */       String worldName = args[5];
/*    */ 
/* 32 */       String dburl = "jdbc:mysql://" + host + "/" + dbname;
/* 33 */       db.connect(dburl, user, password);
/*    */ 
/* 35 */       Engine.setOIDManager(new OIDManager(db));
/* 36 */       Engine.getOIDManager().defaultChunkSize = 1;
/*    */ 
/* 38 */       List gameIDs = db.getGameIDs(worldName, atavismID);
/* 39 */       Iterator iter = gameIDs.iterator();
/* 40 */       while (iter.hasNext()) {
/* 41 */         OID gameId = (OID)iter.next();
/* 42 */         db.deleteObjectData(gameId);
/* 43 */         db.deletePlayerCharacter(gameId);
/* 44 */         if (Log.loggingDebug)
/* 45 */           Log.debug("deleted obj: " + gameId);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 49 */       Log.exception("DeleteCharacter.main got exception", e);
/*    */     }
/* 51 */     Log.debug("Shutting down");
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.scripts.DeleteCharacter
 * JD-Core Version:    0.6.0
 */