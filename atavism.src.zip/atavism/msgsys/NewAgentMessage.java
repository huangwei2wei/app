/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class NewAgentMessage extends Message
/*    */ {
/*    */   int agentId;
/*    */   String agentName;
/*    */   String agentIP;
/*    */   int agentPort;
/*    */   int domainFlags;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public NewAgentMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NewAgentMessage(int agentId, String agentName, String agentIP, int agentPort, int domainFlags)
/*    */   {
/* 12 */     this.msgType = MessageTypes.MSG_TYPE_NEW_AGENT;
/* 13 */     this.agentId = agentId;
/* 14 */     this.agentName = agentName;
/* 15 */     this.agentIP = agentIP;
/* 16 */     this.agentPort = agentPort;
/* 17 */     this.domainFlags = domainFlags;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.NewAgentMessage
 * JD-Core Version:    0.6.0
 */