/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class AllocNameResponseMessage extends ResponseMessage
/*    */ {
/*    */   private String name;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AllocNameResponseMessage()
/*    */   {
/*  6 */     super(MessageTypes.MSG_TYPE_ALLOC_NAME_RESPONSE);
/*    */   }
/*    */ 
/*    */   public AllocNameResponseMessage(Message requestMessage, String name) {
/* 10 */     super(MessageTypes.MSG_TYPE_ALLOC_NAME_RESPONSE, requestMessage);
/* 11 */     setName(name);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 15 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 19 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return "[AllocNameResponseMessage: " + super.toString() + " name=" + this.name + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.AllocNameResponseMessage
 * JD-Core Version:    0.6.0
 */