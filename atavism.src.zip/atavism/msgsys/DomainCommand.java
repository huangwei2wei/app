/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.util.InitLogAndPid;
/*    */ import gnu.getopt.Getopt;
/*    */ import java.io.PrintStream;
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class DomainCommand
/*    */ {
/*    */   public static void main(String[] argv)
/*    */   {
/* 13 */     Getopt g = new Getopt("DomainCommand", argv, "n:m:t:P:");
/*    */ 
/* 15 */     String[] allocName = null;
/*    */     int c;
/* 18 */     while ((c = g.getopt()) != -1) {
/* 19 */       switch (c)
/*    */       {
/*    */       case 110:
/* 22 */         allocName = g.getOptarg().split(",", 2);
/* 23 */         break;
/*    */       case 109:
/*    */       case 116:
/*    */       case 80:
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 34 */     String worldName = System.getProperty("atavism.worldname");
/* 35 */     String hostName = determineHostName();
/*    */ 
/* 37 */     Properties properties = InitLogAndPid.initLogAndPid(argv, worldName, hostName);
/*    */ 
/* 39 */     MessageAgent agent = new MessageAgent();
/* 40 */     String domainHost = properties.getProperty("atavism.msgsvr_hostname", System.getProperty("atavism.msgsvr_hostname"));
/*    */ 
/* 42 */     String portString = properties.getProperty("atavism.msgsvr_port", System.getProperty("atavism.msgsvr_port"));
/*    */ 
/* 44 */     int domainPort = 20374;
/* 45 */     if (portString != null)
/* 46 */       domainPort = Integer.parseInt(portString);
/*    */     try
/*    */     {
/* 49 */       agent.connectToDomain(domainHost, Integer.valueOf(domainPort));
/* 50 */       if (allocName != null) {
/* 51 */         String agentName = agent.getDomainClient().allocName(allocName[0], allocName[1]);
/*    */ 
/* 53 */         System.out.println(agentName);
/*    */       }
/*    */     }
/*    */     catch (Exception ex) {
/* 57 */       System.err.println("DomainCommand: " + ex);
/* 58 */       throw new RuntimeException("failed", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static String determineHostName()
/*    */   {
/* 65 */     String hostName = System.getProperty("atavism.hostname");
/* 66 */     if (hostName == null)
/* 67 */       hostName = reverseLocalHostLookup();
/* 68 */     if (hostName == null) {
/* 69 */       System.err.println("Could not determine host name from reverse lookup or atavism.hostname, using 'localhost'");
/* 70 */       hostName = "localhost";
/*    */     }
/* 72 */     return hostName;
/*    */   }
/*    */ 
/*    */   private static String reverseLocalHostLookup()
/*    */   {
/* 77 */     InetAddress localMachine = null;
/*    */     try {
/* 79 */       localMachine = InetAddress.getLocalHost();
/* 80 */       return localMachine.getHostName();
/*    */     }
/*    */     catch (UnknownHostException e) {
/* 83 */       System.err.println("Could not get host name from local IP address " + localMachine);
/*    */     }
/*    */ 
/* 86 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.DomainCommand
 * JD-Core Version:    0.6.0
 */