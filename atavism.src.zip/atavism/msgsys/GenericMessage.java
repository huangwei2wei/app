/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class GenericMessage extends Message
/*    */ {
/*    */   protected Serializable data;
/*    */   protected Map<String, Serializable> properties;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public GenericMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GenericMessage(MessageType msgType)
/*    */   {
/* 18 */     super(msgType);
/*    */   }
/*    */ 
/*    */   public Serializable getProperty(String key)
/*    */   {
/* 23 */     if (this.properties == null)
/* 24 */       return null;
/* 25 */     return (Serializable)this.properties.get(key);
/*    */   }
/*    */ 
/*    */   public void setProperty(String key, Serializable value)
/*    */   {
/* 31 */     if (this.properties == null)
/* 32 */       this.properties = new HashMap();
/* 33 */     this.properties.put(key, value);
/*    */   }
/*    */ 
/*    */   public Map<String, Serializable> getProperties()
/*    */   {
/* 39 */     return this.properties;
/*    */   }
/*    */ 
/*    */   public void setProperties(Map<String, Serializable> props)
/*    */   {
/* 45 */     this.properties = props;
/*    */   }
/*    */ 
/*    */   public void addProperties(Map<String, Serializable> props)
/*    */   {
/* 51 */     this.properties.putAll(props);
/*    */   }
/*    */ 
/*    */   public Serializable getData()
/*    */   {
/* 57 */     return this.data;
/*    */   }
/*    */ 
/*    */   public void setData(Serializable data)
/*    */   {
/* 63 */     this.data = data;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.GenericMessage
 * JD-Core Version:    0.6.0
 */