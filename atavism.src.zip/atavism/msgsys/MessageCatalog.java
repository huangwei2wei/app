/*     */ package atavism.msgsys;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class MessageCatalog
/*     */ {
/*     */   private static List<MessageCatalog> catalogList;
/*     */   private String name;
/*     */   private int firstMsgNumber;
/*     */   private int lastMsgNumber;
/*     */   private int nextMsgNumber;
/*     */   private static HashMap<String, Integer> stringToMsgNumberMap;
/*     */   private static HashMap<Integer, MessageType> numberToMsgTypeMap;
/*     */ 
/*     */   public static Integer getMessageNumber(String msgTypeString)
/*     */   {
/*  18 */     for (MessageCatalog catalog : catalogList) {
/*  19 */       Integer num = catalog.getMsgNumberFromString(msgTypeString);
/*  20 */       if (num != null)
/*  21 */         return num;
/*     */     }
/*  23 */     return null;
/*     */   }
/*     */ 
/*     */   public static MessageType getMessageType(Integer msgTypeNumber)
/*     */   {
/*  29 */     if (msgTypeNumber == null) {
/*  30 */       return null;
/*     */     }
/*     */ 
/*  34 */     return (MessageType)numberToMsgTypeMap.get(msgTypeNumber);
/*     */   }
/*     */ 
/*     */   public static MessageType getMessageType(String msgTypeString)
/*     */   {
/*  41 */     return getMessageType(getMessageNumber(msgTypeString));
/*     */   }
/*     */ 
/*     */   public static MessageCatalog addMsgCatalog(String name, int firstMsgNumber, int msgNumberCount)
/*     */   {
/*  50 */     MessageCatalog catalog = new MessageCatalog(name, firstMsgNumber, msgNumberCount);
/*  51 */     addMsgCatalog(catalog);
/*  52 */     return catalog;
/*     */   }
/*     */ 
/*     */   public static MessageCatalog addMsgCatalog(MessageCatalog catalog)
/*     */   {
/*  60 */     assert (catalog != null);
/*     */ 
/*  63 */     int first = catalog.firstMsgNumber;
/*  64 */     int last = catalog.lastMsgNumber;
/*  65 */     for (MessageCatalog existingCatalog : catalogList) {
/*  66 */       if (((first >= existingCatalog.firstMsgNumber) && (first <= existingCatalog.lastMsgNumber)) || ((last <= existingCatalog.lastMsgNumber) && (last >= existingCatalog.firstMsgNumber)))
/*     */       {
/*  70 */         throw new RuntimeException("MessageCatalog.addMsgCatalog: Numbers for catalog '" + catalog.name + "' overlap with number for catalog '" + existingCatalog.name + "'");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  76 */     catalogList.add(catalog);
/*  77 */     return catalog;
/*     */   }
/*     */ 
/*     */   public MessageCatalog(String name, int firstMsgNumber, int msgNumberCount)
/*     */   {
/*  93 */     this.name = name;
/*  94 */     this.firstMsgNumber = firstMsgNumber;
/*  95 */     this.nextMsgNumber = firstMsgNumber;
/*  96 */     this.lastMsgNumber = (firstMsgNumber + msgNumberCount - 1);
/*     */   }
/*     */ 
/*     */   public Integer getMsgNumberFromString(String msgTypeString)
/*     */   {
/* 104 */     return (Integer)stringToMsgNumberMap.get(msgTypeString);
/*     */   }
/*     */ 
/*     */   public void addMsgTypeTranslation(String msgTypeString)
/*     */   {
/* 113 */     MessageType msgType = MessageType.intern(msgTypeString);
/* 114 */     addMsgTypeTranslation(msgType);
/*     */   }
/*     */ 
/*     */   public void addMsgTypeTranslation(MessageType msgType)
/*     */   {
/* 123 */     addMsgTypeTranslation(msgType, this.nextMsgNumber++);
/*     */   }
/*     */ 
/*     */   public void addMsgTypeTranslation(MessageType msgType, int msgNumber)
/*     */   {
/* 132 */     if ((msgNumber < this.firstMsgNumber) || (msgNumber > this.lastMsgNumber)) {
/* 133 */       throw new RuntimeException("MessageCatalog.addMsgTypeTranslation: the message number " + msgNumber + " is outside the range of numbers handled by catalog '" + this.name + "'");
/*     */     }
/* 135 */     String msgTypeString = msgType.getMsgTypeString();
/* 136 */     if (stringToMsgNumberMap.get(msgTypeString) != null) {
/* 137 */       Log.debug("MessageCatalog.addMsgTypeTranslation: skipping, a translation for msg type '" + msgTypeString + "' already exists in catalog '" + this.name + "'");
/*     */     }
/*     */     else {
/* 140 */       msgType.setMsgTypeNumber(msgNumber);
/* 141 */       stringToMsgNumberMap.put(msgTypeString, Integer.valueOf(msgNumber));
/* 142 */       numberToMsgTypeMap.put(Integer.valueOf(msgNumber), msgType);
/* 143 */       Log.debug("Adding msg type '" + msgTypeString + "', msgNumber " + msgNumber + "/0x" + Integer.toHexString(msgNumber));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 148 */     return "MessageCatalog [name=" + this.name + "; firstMsgNumber=" + this.firstMsgNumber + "; lastMsgNumber=" + this.lastMsgNumber + "]";
/*     */   }
/*     */ 
/*     */   public int getFirstMsgNumber()
/*     */   {
/* 153 */     return this.firstMsgNumber;
/*     */   }
/*     */ 
/*     */   public int getLastMsgNumber()
/*     */   {
/* 158 */     return this.lastMsgNumber;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  84 */     catalogList = new LinkedList();
/*     */ 
/* 189 */     stringToMsgNumberMap = new HashMap();
/*     */ 
/* 195 */     numberToMsgTypeMap = new HashMap();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageCatalog
 * JD-Core Version:    0.6.0
 */