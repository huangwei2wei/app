/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class StringResponseMessage extends ResponseMessage
/*    */ {
/*    */   private String stringVal;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public StringResponseMessage()
/*    */   {
/*  6 */     super(MessageTypes.MSG_TYPE_STRING_RESPONSE);
/*    */   }
/*    */ 
/*    */   public StringResponseMessage(Message msg, String stringVal) {
/* 10 */     super(MessageTypes.MSG_TYPE_STRING_RESPONSE, msg);
/* 11 */     setStringVal(stringVal);
/*    */   }
/*    */ 
/*    */   public void setStringVal(String stringVal) {
/* 15 */     this.stringVal = stringVal;
/*    */   }
/*    */ 
/*    */   public String getStringVal() {
/* 19 */     return this.stringVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return "[StringResponseMessage: " + super.toString() + ", stringVal " + this.stringVal + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.StringResponseMessage
 * JD-Core Version:    0.6.0
 */