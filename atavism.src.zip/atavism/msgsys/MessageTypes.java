/*    */ package atavism.msgsys;
/*    */ 
/*    */ class MessageTypes
/*    */ {
/*  5 */   public static MessageType MSG_TYPE_AGENT_HELLO = MessageType.intern("msgsys.AGENT_HELLO");
/*  6 */   public static MessageType MSG_TYPE_HELLO_RESPONSE = MessageType.intern("msgsys.HELLO_RESPONSE");
/*  7 */   public static MessageType MSG_TYPE_ALLOC_NAME = MessageType.intern("msgsys.ALLOC_NAME");
/*  8 */   public static MessageType MSG_TYPE_ALLOC_NAME_RESPONSE = MessageType.intern("msgsys.ALLOC_NAME_RESPONSE");
/*  9 */   public static MessageType MSG_TYPE_NEW_AGENT = MessageType.intern("msgsys.NEW_AGENT");
/* 10 */   public static MessageType MSG_TYPE_AGENT_STATE = MessageType.intern("msgsys.AGENT_STATE");
/* 11 */   public static MessageType MSG_TYPE_ADVERTISE = MessageType.intern("msgsys.ADVERTISE");
/* 12 */   public static MessageType MSG_TYPE_SUBSCRIBE = MessageType.intern("msgsys.SUBSCRIBE");
/* 13 */   public static MessageType MSG_TYPE_UNSUBSCRIBE = MessageType.intern("msgsys.UNSUBSCRIBE");
/* 14 */   public static MessageType MSG_TYPE_FILTER_UPDATE = MessageType.intern("msgsys.FILTER_UPDATE");
/* 15 */   public static MessageType MSG_TYPE_AWAIT_PLUGIN_DEPENDENTS = MessageType.intern("msgsys.AWAIT_PLUGIN_DEPENDENTS");
/* 16 */   public static MessageType MSG_TYPE_PLUGIN_AVAILABLE = MessageType.intern("msgsys.PLUGIN_AVAILABLE");
/* 17 */   public static MessageType MSG_TYPE_RESPONSE = MessageType.intern("msgsys.RESPONSE");
/* 18 */   public static MessageType MSG_TYPE_BOOLEAN_RESPONSE = MessageType.intern("msgsys.BOOLEAN_RESPONSE");
/* 19 */   public static MessageType MSG_TYPE_LONG_RESPONSE = MessageType.intern("msgsys.LONG_RESPONSE");
/* 20 */   public static MessageType MSG_TYPE_INT_RESPONSE = MessageType.intern("msgsys.INT_RESPONSE");
/* 21 */   public static MessageType MSG_TYPE_STRING_RESPONSE = MessageType.intern("msgsys.STRING_RESPONSE");
/* 22 */   public static MessageType MSG_TYPE_OID_RESPONSE = MessageType.intern("msgsys.OID_RESPONSE");
/*    */ 
/* 26 */   public static MessageType MSG_TYPE_ALL_TYPES = MessageType.intern("msgsys.all");
/*    */   public static MessageCatalog catalog;
/*    */   private static MessageType firstMsgType;
/*    */   private static MessageType lastMsgType;
/*    */ 
/*    */   public static void initializeCatalog()
/*    */   {
/* 32 */     if (catalog != null)
/* 33 */       return;
/* 34 */     catalog = MessageCatalog.addMsgCatalog("msgsysCatalog", 5000, 100);
/* 35 */     catalog.addMsgTypeTranslation(MSG_TYPE_AGENT_HELLO);
/* 36 */     catalog.addMsgTypeTranslation(MSG_TYPE_HELLO_RESPONSE);
/* 37 */     catalog.addMsgTypeTranslation(MSG_TYPE_ALLOC_NAME);
/* 38 */     catalog.addMsgTypeTranslation(MSG_TYPE_NEW_AGENT);
/* 39 */     catalog.addMsgTypeTranslation(MSG_TYPE_AGENT_STATE);
/* 40 */     catalog.addMsgTypeTranslation(MSG_TYPE_ADVERTISE);
/* 41 */     catalog.addMsgTypeTranslation(MSG_TYPE_SUBSCRIBE);
/* 42 */     catalog.addMsgTypeTranslation(MSG_TYPE_UNSUBSCRIBE);
/* 43 */     catalog.addMsgTypeTranslation(MSG_TYPE_FILTER_UPDATE);
/* 44 */     catalog.addMsgTypeTranslation(MSG_TYPE_AWAIT_PLUGIN_DEPENDENTS);
/* 45 */     catalog.addMsgTypeTranslation(MSG_TYPE_PLUGIN_AVAILABLE);
/*    */ 
/* 47 */     firstMsgType = MSG_TYPE_AGENT_HELLO;
/* 48 */     lastMsgType = MSG_TYPE_FILTER_UPDATE;
/*    */ 
/* 50 */     catalog.addMsgTypeTranslation(MSG_TYPE_RESPONSE);
/* 51 */     catalog.addMsgTypeTranslation(MSG_TYPE_BOOLEAN_RESPONSE);
/* 52 */     catalog.addMsgTypeTranslation(MSG_TYPE_LONG_RESPONSE);
/* 53 */     catalog.addMsgTypeTranslation(MSG_TYPE_INT_RESPONSE);
/* 54 */     catalog.addMsgTypeTranslation(MSG_TYPE_STRING_RESPONSE);
/* 55 */     catalog.addMsgTypeTranslation(MSG_TYPE_ALLOC_NAME_RESPONSE);
/*    */   }
/*    */ 
/*    */   public static boolean isInternal(MessageType type)
/*    */   {
/* 60 */     Integer num = Integer.valueOf(type.getMsgTypeNumber());
/* 61 */     return (num.intValue() >= firstMsgType.getMsgTypeNumber()) && (num.intValue() <= lastMsgType.getMsgTypeNumber());
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageTypes
 * JD-Core Version:    0.6.0
 */