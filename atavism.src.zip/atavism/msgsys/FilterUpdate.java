/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class FilterUpdate
/*    */ {
/*    */   public static final int OP_SET = 1;
/*    */   public static final int OP_ADD = 2;
/*    */   public static final int OP_REMOVE = 3;
/* 89 */   protected List<Instruction> instructions = new LinkedList();
/*    */ 
/*    */   public FilterUpdate()
/*    */   {
/* 19 */     this.instructions = new LinkedList();
/*    */   }
/*    */ 
/*    */   public FilterUpdate(int capacity)
/*    */   {
/* 27 */     this.instructions = new ArrayList(capacity);
/*    */   }
/*    */ 
/*    */   public void setField(int fieldId, Object value)
/*    */   {
/* 36 */     this.instructions.add(new Instruction(1, fieldId, value));
/*    */   }
/*    */ 
/*    */   public void addFieldValue(int fieldId, Object value)
/*    */   {
/* 45 */     this.instructions.add(new Instruction(2, fieldId, value));
/*    */   }
/*    */ 
/*    */   public void removeFieldValue(int fieldId, Object value)
/*    */   {
/* 54 */     this.instructions.add(new Instruction(3, fieldId, value));
/*    */   }
/*    */ 
/*    */   public List<Instruction> getInstructions()
/*    */   {
/* 61 */     return this.instructions;
/*    */   }
/*    */ 
/*    */   public static class Instruction
/*    */   {
/*    */     public int opCode;
/*    */     public int fieldId;
/*    */     public Object value;
/*    */ 
/*    */     public Instruction()
/*    */     {
/*    */     }
/*    */ 
/*    */     public Instruction(int op, int fieldId, Object value)
/*    */     {
/* 80 */       this.opCode = op;
/* 81 */       this.fieldId = fieldId;
/* 82 */       this.value = value;
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.FilterUpdate
 * JD-Core Version:    0.6.0
 */