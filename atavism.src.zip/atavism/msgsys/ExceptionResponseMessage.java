/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class ExceptionResponseMessage extends ResponseMessage
/*    */ {
/*    */   private ExceptionData exceptionData;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ExceptionResponseMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ExceptionResponseMessage(Message requestMessage, Exception ex)
/*    */   {
/* 13 */     super(requestMessage);
/* 14 */     this.exceptionData = new ExceptionData(ex);
/*    */   }
/*    */ 
/*    */   public ExceptionData getException()
/*    */   {
/* 20 */     return this.exceptionData;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.ExceptionResponseMessage
 * JD-Core Version:    0.6.0
 */