package atavism.msgsys;

import java.util.Collection;

public abstract interface IMessageTypeFilter extends IFilter
{
  public abstract void addType(MessageType paramMessageType);

  public abstract void setTypes(Collection<MessageType> paramCollection);

  public abstract Collection<MessageType> getMessageTypes();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.IMessageTypeFilter
 * JD-Core Version:    0.6.0
 */