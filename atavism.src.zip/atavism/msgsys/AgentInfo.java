/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import java.nio.channels.SocketChannel;
/*    */ 
/*    */ public class AgentInfo extends AgentHandle
/*    */ {
/*    */   public int agentId;
/*    */   public int flags;
/*    */   public SocketChannel socket;
/*    */   public String agentName;
/*    */   public String agentIP;
/*    */   public int agentPort;
/*    */   public AOByteBuffer outputBuf;
/*    */   public AOByteBuffer inputBuf;
/*    */   public Object association;
/*    */ 
/*    */   public String getAgentName()
/*    */   {
/* 11 */     return this.agentName;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.AgentInfo
 * JD-Core Version:    0.6.0
 */