/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class RPCException extends RuntimeException
/*    */ {
/*    */   private String exceptionClass;
/*    */   private String agentName;
/*    */   static String myAgentName;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public RPCException(ExceptionData exceptionData)
/*    */   {
/* 17 */     super(exceptionData.getMessage());
/* 18 */     this.agentName = exceptionData.getAgentName();
/* 19 */     this.exceptionClass = exceptionData.getExceptionClassName();
/* 20 */     List stackTrace = exceptionData.getStackTrace();
/* 21 */     StackTraceElement[] exFrames = new StackTraceElement[stackTrace.size()];
/* 22 */     int ii = 0;
/* 23 */     for (StackFrame stackFrame : stackTrace) {
/* 24 */       exFrames[ii] = new StackTraceElement(stackFrame.declaringClass, stackFrame.methodName, stackFrame.fileName, stackFrame.lineNumber);
/*    */ 
/* 27 */       ii++;
/*    */     }
/* 29 */     setStackTrace(exFrames);
/*    */ 
/* 31 */     if (exceptionData.getCause() != null)
/* 32 */       initCause(new RPCException(exceptionData.getCause()));
/*    */   }
/*    */ 
/*    */   public String getExceptionClassName()
/*    */   {
/* 39 */     return this.exceptionClass;
/*    */   }
/*    */ 
/*    */   public String getAgentName()
/*    */   {
/* 46 */     return this.agentName;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     String myName = getClass().getName() + "(" + this.exceptionClass + " in " + this.agentName + ")";
/* 52 */     String message = getLocalizedMessage();
/* 53 */     return message != null ? myName + ": " + message : myName;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.RPCException
 * JD-Core Version:    0.6.0
 */