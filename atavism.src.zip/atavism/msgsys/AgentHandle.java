package atavism.msgsys;

public abstract class AgentHandle
{
  public abstract String getAgentName();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.AgentHandle
 * JD-Core Version:    0.6.0
 */