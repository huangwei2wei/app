/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class IntegerResponseMessage extends ResponseMessage
/*    */ {
/*    */   private Integer intVal;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public IntegerResponseMessage()
/*    */   {
/*  6 */     super(MessageTypes.MSG_TYPE_INT_RESPONSE);
/*    */   }
/*    */ 
/*    */   public IntegerResponseMessage(Message msg, Integer intVal) {
/* 10 */     super(MessageTypes.MSG_TYPE_INT_RESPONSE, msg);
/* 11 */     setIntVal(intVal);
/*    */   }
/*    */ 
/*    */   public void setIntVal(Integer intVal) {
/* 15 */     this.intVal = intVal;
/*    */   }
/*    */ 
/*    */   public Integer getIntVal() {
/* 19 */     return this.intVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return "[IntegerResponseMessage: " + super.toString() + ", intVal " + this.intVal + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.IntegerResponseMessage
 * JD-Core Version:    0.6.0
 */