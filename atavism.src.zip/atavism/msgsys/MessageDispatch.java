package atavism.msgsys;

public abstract interface MessageDispatch
{
  public abstract void dispatchMessage(Message paramMessage, int paramInt, MessageCallback paramMessageCallback);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageDispatch
 * JD-Core Version:    0.6.0
 */