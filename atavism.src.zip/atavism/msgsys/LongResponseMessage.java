/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class LongResponseMessage extends ResponseMessage
/*    */ {
/*    */   private Long longVal;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public LongResponseMessage()
/*    */   {
/*  6 */     super(MessageTypes.MSG_TYPE_LONG_RESPONSE);
/*    */   }
/*    */ 
/*    */   public LongResponseMessage(Message msg, Long longVal) {
/* 10 */     super(MessageTypes.MSG_TYPE_LONG_RESPONSE, msg);
/* 11 */     setLongVal(longVal);
/*    */   }
/*    */ 
/*    */   public void setLongVal(Long longVal) {
/* 15 */     this.longVal = longVal;
/*    */   }
/*    */ 
/*    */   public Long getLongVal() {
/* 19 */     return this.longVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return "[LongResponseMessage: " + super.toString() + ", longVal " + this.longVal + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.LongResponseMessage
 * JD-Core Version:    0.6.0
 */