/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class StackFrame
/*    */ {
/*    */   String declaringClass;
/*    */   String methodName;
/*    */   String fileName;
/*    */   int lineNumber;
/*    */ 
/*    */   public StackFrame()
/*    */   {
/*    */   }
/*    */ 
/*    */   StackFrame(StackTraceElement frame)
/*    */   {
/* 12 */     this.declaringClass = frame.getClassName();
/* 13 */     this.methodName = frame.getMethodName();
/* 14 */     this.fileName = frame.getFileName();
/* 15 */     this.lineNumber = frame.getLineNumber();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.StackFrame
 * JD-Core Version:    0.6.0
 */