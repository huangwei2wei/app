/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class GenericResponseMessage extends ResponseMessage
/*    */ {
/*    */   protected Object data;
/*    */   protected Map<String, Object> properties;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public GenericResponseMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GenericResponseMessage(MessageType msgType)
/*    */   {
/* 14 */     super(msgType);
/*    */   }
/*    */ 
/*    */   public GenericResponseMessage(Message requestMessage)
/*    */   {
/* 19 */     super(requestMessage);
/*    */   }
/*    */ 
/*    */   public GenericResponseMessage(Message requestMessage, Object data)
/*    */   {
/* 24 */     super(requestMessage);
/* 25 */     setData(data);
/*    */   }
/*    */ 
/*    */   public Object getProperty(String key) {
/* 29 */     if (this.properties == null)
/* 30 */       return null;
/* 31 */     return this.properties.get(key);
/*    */   }
/*    */ 
/*    */   public void setProperty(String key, Object value)
/*    */   {
/* 36 */     if (this.properties == null)
/* 37 */       this.properties = new HashMap();
/* 38 */     this.properties.put(key, value);
/*    */   }
/*    */ 
/*    */   public Map<String, Object> getProperties()
/*    */   {
/* 43 */     return this.properties;
/*    */   }
/*    */ 
/*    */   public void setProperties(Map<String, Object> props)
/*    */   {
/* 48 */     this.properties = props;
/*    */   }
/*    */ 
/*    */   public void addProperties(Map<String, Object> props)
/*    */   {
/* 53 */     this.properties.putAll(props);
/*    */   }
/*    */ 
/*    */   public Object getData()
/*    */   {
/* 58 */     return this.data;
/*    */   }
/*    */ 
/*    */   public void setData(Object data)
/*    */   {
/* 63 */     this.data = data;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.GenericResponseMessage
 * JD-Core Version:    0.6.0
 */