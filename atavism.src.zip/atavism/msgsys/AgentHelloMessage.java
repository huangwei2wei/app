/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class AgentHelloMessage extends Message
/*    */ {
/*    */   private String agentName;
/*    */   private String agentIP;
/*    */   private int agentPort;
/*    */   private int flags;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AgentHelloMessage()
/*    */   {
/*  7 */     this.msgType = MessageTypes.MSG_TYPE_AGENT_HELLO;
/*    */   }
/*    */ 
/*    */   AgentHelloMessage(String agentName, String agentIP, int agentPort) {
/* 11 */     this.msgType = MessageTypes.MSG_TYPE_AGENT_HELLO;
/* 12 */     this.agentName = agentName;
/* 13 */     this.agentIP = agentIP;
/* 14 */     this.agentPort = agentPort;
/*    */   }
/*    */ 
/*    */   public String getAgentName()
/*    */   {
/* 19 */     return this.agentName;
/*    */   }
/*    */ 
/*    */   public String getAgentIP()
/*    */   {
/* 24 */     return this.agentIP;
/*    */   }
/*    */ 
/*    */   public int getAgentPort()
/*    */   {
/* 29 */     return this.agentPort;
/*    */   }
/*    */ 
/*    */   public int getFlags()
/*    */   {
/* 34 */     return this.flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int flags)
/*    */   {
/* 39 */     this.flags = flags;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.AgentHelloMessage
 * JD-Core Version:    0.6.0
 */