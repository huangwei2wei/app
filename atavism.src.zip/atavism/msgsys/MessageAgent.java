/*      */ package atavism.msgsys;
/*      */ 
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.marshalling.MarshallingRuntime;
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.network.ChannelUtil;
/*      */ import atavism.server.network.TcpAcceptCallback;
/*      */ import atavism.server.network.TcpServer;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.Base64;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.SQThreadPool;
/*      */ import atavism.server.util.SecureTokenManager;
/*      */ import atavism.server.util.SquareQueue;
/*      */ import atavism.server.util.SquareQueue.SubQueue;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.net.ConnectException;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ 
/*      */ public class MessageAgent
/*      */   implements MessageIO.Callback, TcpAcceptCallback, ResponseCallback
/*      */ {
/*      */   private static final int DEFAULT_RPC_TIMEOUT = 120000;
/*      */   public static final int DOMAIN_FLAG_TRANSIENT = 1;
/*      */   public static final int NO_FLAGS = 0;
/*      */   public static final int BLOCKING = 1;
/*      */   public static final int COMPLETION_CALLBACK = 2;
/*      */   public static final int DEFERRED = 4;
/*      */   public static final int RESPONDER = 8;
/*      */   public static final int NON_BLOCKING = 16;
/* 2498 */   private List<RemoteAgent> remoteAgents = new LinkedList();
/* 2499 */   private SquareQueue<RemoteAgent, Message> remoteAgentOutput = new SquareQueue("MessageAgent");
/*      */   private RemoteAgent selfRemoteAgent;
/* 2503 */   private long nextMessageId = 1L;
/*      */ 
/* 2505 */   private long nextSubId = 1L;
/* 2506 */   private int defaultSubscriptionFlags = 0;
/*      */   private Map<Long, RegisteredSubscription> subscriptions;
/*      */   private List<FilterTable> sendFilters;
/*      */   private List<FilterTable> receiveFilters;
/*      */   private List<FilterTable> responderSendFilters;
/*      */   private List<FilterTable> responderReceiveFilters;
/* 2516 */   private FilterTable defaultSendFilterTable = new DefaultFilterTable();
/* 2517 */   private FilterTable defaultReceiveFilterTable = new DefaultFilterTable();
/* 2518 */   private FilterTable defaultResponderReceiveFilterTable = new DefaultFilterTable();
/* 2519 */   private FilterTable defaultResponderSendFilterTable = new DefaultFilterTable();
/*      */ 
/* 2521 */   private long statAppMessageCount = 0L;
/* 2522 */   private long statSystemMessageCount = 0L;
/*      */ 
/* 2526 */   private Map<Long, PendingRPC> pendingRPC = new HashMap();
/*      */ 
/* 2559 */   private ExecutorService responseCallbackPool = Executors.newFixedThreadPool(10, new ResponseThreadFactory());
/*      */   private String agentName;
/*      */   private int agentPort;
/*      */   private int agentId;
/*      */   private long domainStartTime;
/* 2579 */   private int domainRetries = 2147483647;
/*      */ 
/* 2581 */   private SocketChannel domainServerSocket = null;
/*      */   private AgentInfo domainServerAgent;
/*      */   private int domainFlags;
/*      */   private MessageIO messageIO;
/*      */   private TcpServer listener;
/* 2586 */   private ExecutorService threadPool = Executors.newCachedThreadPool(new AgentConnectionThreadFactory());
/*      */   private List<String> remoteAgentNames;
/* 2591 */   private Set<MessageType> advertisements = new HashSet();
/* 2592 */   private String advertFileName = "<unknown>";
/*      */ 
/* 2594 */   private Set<MessageType> noProducersExpected = new HashSet();
/*      */ 
/* 2624 */   private static int intervalBetweenStatsLogging = 5000;
/*      */ 
/* 2626 */   private static long localSubscriptionCreatedCount = 0L;
/* 2627 */   private static long localSubscriptionRemovedCount = 0L;
/* 2628 */   private static long localFilterUpdateCount = 0L;
/* 2629 */   private static long remoteSubscriptionCreatedCount = 0L;
/* 2630 */   private static long remoteSubscriptionRemovedCount = 0L;
/* 2631 */   private static long remoteFilterUpdateCount = 0L;
/*      */ 
/* 2633 */   private static long lastLocalSubscriptionCreatedCount = 0L;
/* 2634 */   private static long lastLocalSubscriptionRemovedCount = 0L;
/* 2635 */   private static long lastLocalFilterUpdateCount = 0L;
/* 2636 */   private static long lastRemoteSubscriptionCreatedCount = 0L;
/* 2637 */   private static long lastRemoteSubscriptionRemovedCount = 0L;
/* 2638 */   private static long lastRemoteFilterUpdateCount = 0L;
/*      */ 
/*      */   public MessageAgent(String name)
/*      */   {
/*  114 */     MessageTypes.initializeCatalog();
/*      */ 
/*  116 */     this.agentName = name;
/*  117 */     RPCException.myAgentName = this.agentName;
/*      */ 
/*  119 */     this.subscriptions = new HashMap();
/*      */ 
/*  121 */     this.sendFilters = new LinkedList();
/*  122 */     this.sendFilters.add(this.defaultSendFilterTable);
/*      */ 
/*  124 */     this.receiveFilters = new LinkedList();
/*  125 */     this.receiveFilters.add(this.defaultReceiveFilterTable);
/*      */ 
/*  127 */     this.responderSendFilters = new LinkedList();
/*  128 */     this.responderSendFilters.add(this.defaultResponderSendFilterTable);
/*      */ 
/*  130 */     this.responderReceiveFilters = new LinkedList();
/*  131 */     this.responderReceiveFilters.add(this.defaultResponderReceiveFilterTable);
/*      */ 
/*  133 */     addSelfRemoteAgent();
/*      */ 
/*  135 */     this.messageIO = new MessageIO(this);
/*  136 */     this.messageIO.start();
/*      */ 
/*  139 */     new SelfMessageHandler();
/*      */   }
/*      */ 
/*      */   public MessageAgent()
/*      */   {
/*  146 */     MessageTypes.initializeCatalog();
/*      */ 
/*  148 */     this.messageIO = new MessageIO(this);
/*  149 */     this.messageIO.start();
/*      */   }
/*      */ 
/*      */   public String getName()
/*      */   {
/*  157 */     return this.agentName;
/*      */   }
/*      */ 
/*      */   public Integer getAgentId()
/*      */   {
/*  164 */     return Integer.valueOf(this.agentId);
/*      */   }
/*      */ 
/*      */   public long getDomainStartTime()
/*      */   {
/*  171 */     return this.domainStartTime;
/*      */   }
/*      */ 
/*      */   public int getListenerPort()
/*      */   {
/*  179 */     if (this.listener == null)
/*  180 */       return -1;
/*  181 */     return this.listener.getPort();
/*      */   }
/*      */ 
/*      */   public void openListener()
/*      */     throws IOException
/*      */   {
/*  192 */     if (this.listener != null) {
/*  193 */       return;
/*      */     }
/*  195 */     this.listener = new TcpServer();
/*  196 */     this.listener.bind();
/*  197 */     this.agentPort = this.listener.getPort();
/*  198 */     this.listener.registerAcceptCallback(this);
/*      */   }
/*      */ 
/*      */   private void startListener()
/*      */   {
/*  205 */     this.listener.start();
/*      */   }
/*      */ 
/*      */   public void setAdvertisements(Collection<MessageType> typeIds)
/*      */   {
/*  214 */     synchronized (this.advertisements) {
/*  215 */       this.advertisements = new HashSet(typeIds);
/*      */ 
/*  217 */       sendAdvertisements();
/*      */     }
/*      */ 
/*  220 */     synchronized (this.remoteAgents) {
/*  221 */       if (!this.selfRemoteAgent.hasFlag(256)) {
/*  222 */         this.selfRemoteAgent.setFlag(256);
/*  223 */         this.remoteAgents.notify();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addAdvertisement(MessageType msgType)
/*      */   {
/*  232 */     List typeIds = new LinkedList();
/*  233 */     typeIds.add(msgType);
/*  234 */     addAdvertisements(typeIds);
/*      */   }
/*      */ 
/*      */   public void addAdvertisements(List<MessageType> typeIds)
/*      */   {
/*  242 */     synchronized (this.advertisements) {
/*  243 */       int count = 0;
/*  244 */       Set newAdvertisements = new HashSet(this.advertisements);
/*      */ 
/*  246 */       for (MessageType typeId : typeIds) {
/*  247 */         if (!newAdvertisements.contains(typeId)) {
/*  248 */           newAdvertisements.add(typeId);
/*  249 */           count++;
/*      */         }
/*      */       }
/*      */ 
/*  253 */       if (count == 0)
/*  254 */         return;
/*  255 */       this.advertisements = newAdvertisements;
/*      */ 
/*  257 */       sendAdvertisements();
/*      */     }
/*      */ 
/*  260 */     synchronized (this.remoteAgents) {
/*  261 */       if (!this.selfRemoteAgent.hasFlag(256)) {
/*  262 */         this.selfRemoteAgent.setFlag(256);
/*  263 */         this.remoteAgents.notify();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void removeAdvertisements(List<MessageType> typeIds)
/*      */   {
/*  273 */     synchronized (this.advertisements) {
/*  274 */       int count = 0;
/*  275 */       Set newAdvertisements = new HashSet(this.advertisements);
/*      */ 
/*  277 */       for (MessageType typeId : typeIds) {
/*  278 */         if (newAdvertisements.contains(typeId)) {
/*  279 */           newAdvertisements.remove(typeId);
/*  280 */           count++;
/*      */         }
/*      */       }
/*      */ 
/*  284 */       if (count == 0)
/*  285 */         return;
/*  286 */       this.advertisements = newAdvertisements;
/*      */ 
/*  288 */       sendAdvertisements();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setAdvertisementFileName(String fileName)
/*      */   {
/*  297 */     this.advertFileName = fileName;
/*      */   }
/*      */ 
/*      */   private void sendAdvertisements()
/*      */   {
/*  303 */     AdvertiseMessage request = new AdvertiseMessage(this.advertisements);
/*      */ 
/*  305 */     request.setMessageId(nextMessageId());
/*  306 */     request.setRPC();
/*      */ 
/*  308 */     PendingRPC rpc = new PendingRPC();
/*  309 */     rpc.messageId = request.getMsgId();
/*  310 */     rpc.responders = new HashSet();
/*  311 */     rpc.callback = this;
/*  312 */     synchronized (this.remoteAgents) {
/*  313 */       rpc.responders.addAll(this.remoteAgents);
/*      */     }
/*      */ 
/*  316 */     synchronized (this.pendingRPC) {
/*  317 */       this.pendingRPC.put(Long.valueOf(rpc.messageId), rpc);
/*      */     }
/*      */ 
/*  320 */     synchronized (rpc) {
/*  321 */       sendMessageToList(request, rpc.responders);
/*  322 */       while (rpc.responders.size() > 0)
/*      */         try {
/*  324 */           rpc.wait();
/*      */         }
/*      */         catch (InterruptedException ignore) {
/*      */         }
/*      */     }
/*  329 */     synchronized (this.pendingRPC) {
/*  330 */       this.pendingRPC.remove(Long.valueOf(rpc.messageId));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addNoProducersExpected(MessageType messageType)
/*      */   {
/*  336 */     synchronized (this.noProducersExpected) {
/*  337 */       this.noProducersExpected.add(messageType);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Set<MessageType> getNoProducersExpected()
/*      */   {
/*  343 */     synchronized (this.noProducersExpected) {
/*  344 */       return new HashSet(this.noProducersExpected);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getDomainFlags()
/*      */   {
/*  352 */     return this.domainFlags;
/*      */   }
/*      */ 
/*      */   public void setDomainFlags(int flags)
/*      */   {
/*  357 */     this.domainFlags = flags;
/*      */   }
/*      */ 
/*      */   public int getDomainConnectRetries()
/*      */   {
/*  364 */     return this.domainRetries;
/*      */   }
/*      */ 
/*      */   public void setDomainConnectRetries(int retries)
/*      */   {
/*  371 */     this.domainRetries = retries;
/*      */   }
/*      */ 
/*      */   public void connectToDomain(String domainServerHost, Integer domainServerPort)
/*      */     throws IOException, UnknownHostException, AORuntimeException
/*      */   {
/*  385 */     if ((this.listener == null) && (this.agentName != null)) {
/*  386 */       throw new RuntimeException("Call openListener first");
/*      */     }
/*      */ 
/*  389 */     int retryCount = 0;
/*      */     while (true)
/*      */       try {
/*  392 */         this.domainServerSocket = SocketChannel.open(new InetSocketAddress(domainServerHost, domainServerPort.intValue()));
/*      */       }
/*      */       catch (ConnectException ex)
/*      */       {
/*  398 */         retryCount++;
/*  399 */         if (retryCount > this.domainRetries) {
/*  400 */           throw ex;
/*      */         }
/*  402 */         Log.debug("Could not connect to domain server " + domainServerHost + ":" + domainServerPort + " " + ex + ", Retrying ...");
/*      */         try
/*      */         {
/*  406 */           Thread.sleep(1000L);
/*      */         }
/*      */         catch (Exception ignore) {
/*      */         }
/*      */       }
/*  411 */     this.domainServerSocket.configureBlocking(false);
/*  412 */     if (Log.loggingDebug) {
/*  413 */       Log.debug("MessageAgent: connected to domain server " + this.domainServerSocket);
/*      */     }
/*      */ 
/*  416 */     if (this.agentName == null) {
/*  417 */       addDomainServerAgent(domainServerHost, domainServerPort);
/*  418 */       return;
/*      */     }
/*      */ 
/*  422 */     AOByteBuffer buffer = new AOByteBuffer(64);
/*  423 */     AgentHelloMessage agentHello = new AgentHelloMessage(this.agentName, ":same", getListenerPort());
/*      */ 
/*  425 */     agentHello.setFlags(this.domainFlags);
/*      */ 
/*  427 */     Message.toBytes(agentHello, buffer);
/*  428 */     buffer.flip();
/*      */ 
/*  430 */     if (!ChannelUtil.writeBuffer(buffer, this.domainServerSocket))
/*      */     {
/*  432 */       throw new RuntimeException("could not connect to domain server");
/*      */     }
/*      */ 
/*  436 */     HelloResponseMessage helloResponse = (HelloResponseMessage)new DomainClient().readMessage();
/*      */ 
/*  438 */     if (helloResponse.getMsgType() != MessageTypes.MSG_TYPE_HELLO_RESPONSE) {
/*  439 */       throw new RuntimeException("domain server invalid hello response");
/*      */     }
/*  441 */     this.agentId = helloResponse.getAgentId();
/*  442 */     this.domainStartTime = helloResponse.getDomainStartTime();
/*  443 */     this.selfRemoteAgent.agentId = this.agentId;
/*  444 */     Log.info("My agent-id: " + this.agentId);
/*      */ 
/*  446 */     this.remoteAgentNames = helloResponse.getAgentNames();
/*      */ 
/*  449 */     Log.debug("DOMAIN: helloResponse: " + helloResponse);
/*  450 */     Log.debug("DOMAIN: helloResponse key: " + helloResponse.getDomainKey());
/*  451 */     SecureTokenManager.getInstance().initDomain(Base64.decode(helloResponse.getDomainKey()));
/*      */ 
/*  454 */     addDomainServerAgent(domainServerHost, domainServerPort);
/*      */ 
/*  456 */     startListener();
/*      */   }
/*      */ 
/*      */   void addDomainServerAgent(String domainServerHost, Integer domainServerPort)
/*      */   {
/*  462 */     this.domainServerAgent = new RemoteAgent();
/*  463 */     this.domainServerAgent.agentId = 0;
/*  464 */     this.domainServerAgent.socket = this.domainServerSocket;
/*  465 */     this.domainServerAgent.agentName = "DomainServer";
/*  466 */     this.domainServerAgent.agentIP = domainServerHost;
/*  467 */     this.domainServerAgent.agentPort = domainServerPort.intValue();
/*  468 */     this.domainServerAgent.outputBuf = new AOByteBuffer(512);
/*  469 */     this.domainServerAgent.inputBuf = new AOByteBuffer(512);
/*      */ 
/*  471 */     this.messageIO.addAgent(this.domainServerAgent);
/*      */   }
/*      */ 
/*      */   public DomainClient getDomainClient()
/*      */   {
/*  476 */     return new DomainClient();
/*      */   }
/*      */ 
/*      */   private void addSelfRemoteAgent()
/*      */   {
/*  481 */     RemoteAgent remoteAgent = new RemoteAgent();
/*  482 */     remoteAgent.agentId = this.agentId;
/*  483 */     remoteAgent.socket = null;
/*  484 */     remoteAgent.agentName = this.agentName;
/*  485 */     remoteAgent.agentIP = null;
/*  486 */     remoteAgent.agentPort = 0;
/*  487 */     remoteAgent.outputBuf = new AOByteBuffer(8192);
/*  488 */     remoteAgent.inputBuf = remoteAgent.outputBuf;
/*  489 */     remoteAgent.flags = 0;
/*      */ 
/*  491 */     this.selfRemoteAgent = remoteAgent;
/*      */ 
/*  493 */     this.remoteAgents.add(remoteAgent);
/*      */   }
/*      */ 
/*      */   public void waitForRemoteAgents()
/*      */   {
/*  501 */     synchronized (this.remoteAgents) {
/*  502 */       while (!haveAllAdvertisements())
/*      */         try {
/*  504 */           this.remoteAgents.wait();
/*      */         } catch (InterruptedException ignore) {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean haveAllAdvertisements() {
/*  511 */     List remotes = new LinkedList(this.remoteAgentNames);
/*  512 */     for (RemoteAgent remoteAgent : this.remoteAgents) {
/*  513 */       if (((remoteAgent != this.selfRemoteAgent) && (remoteAgent.socket == null)) || (!remoteAgent.hasFlag(256)))
/*      */       {
/*  516 */         return false;
/*  517 */       }if (remotes.contains(remoteAgent.agentName)) {
/*  518 */         remotes.remove(remoteAgent.agentName);
/*      */       }
/*  520 */       else if (remoteAgent.hasFlag(1)) {
/*  521 */         remotes.remove(remoteAgent.agentName);
/*      */       }
/*      */       else {
/*  524 */         Log.error("Unexpected agent '" + remoteAgent.agentName + "'");
/*  525 */         return false;
/*      */       }
/*      */     }
/*      */ 
/*  529 */     return remotes.size() == 0;
/*      */   }
/*      */ 
/*      */   public void setDefaultSubscriptionFlags(int flags)
/*      */   {
/*  556 */     this.defaultSubscriptionFlags = flags;
/*      */   }
/*      */ 
/*      */   public int getDefaultSubscriptionFlags()
/*      */   {
/*  563 */     return this.defaultSubscriptionFlags;
/*      */   }
/*      */ 
/*      */   public long createSubscription(IFilter filter, MessageCallback callback)
/*      */   {
/*  577 */     return createSubscription(filter, callback, 0, null);
/*      */   }
/*      */ 
/*      */   public long createSubscription(IFilter filter, MessageCallback callback, int flags)
/*      */   {
/*  595 */     return createSubscription(filter, callback, flags, null);
/*      */   }
/*      */ 
/*      */   public long createSubscription(IFilter filter, MessageCallback callback, int flags, MessageTrigger trigger)
/*      */   {
/*  618 */     localSubscriptionCreatedCount += 1L;
/*  619 */     flags |= this.defaultSubscriptionFlags;
/*  620 */     if ((flags & 0x10) != 0) {
/*  621 */       flags &= -2;
/*      */     }
/*  623 */     RegisteredSubscription sub = new RegisteredSubscription();
/*  624 */     sub.filter = filter;
/*  625 */     sub.trigger = trigger;
/*  626 */     sub.flags = (short)(flags & 0xC);
/*  627 */     sub.producers = new LinkedList();
/*  628 */     sub.callback = callback;
/*      */ 
/*  631 */     PendingRPC rpc = null;
/*      */ 
/*  633 */     synchronized (this.subscriptions) {
/*  634 */       sub.subId = (this.nextSubId++);
/*  635 */       this.subscriptions.put(Long.valueOf(sub.subId), sub);
/*      */ 
/*  640 */       synchronized (this.remoteAgents) {
/*  641 */         for (RemoteAgent remoteAgent : this.remoteAgents) {
/*  642 */           if (filter.matchMessageType(remoteAgent.getAdvertisements()))
/*      */           {
/*  644 */             sub.producers.add(remoteAgent);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  649 */       if (Log.loggingDebug) {
/*  650 */         Log.debug("subscribe " + filter + " matching agents " + sub.producers.size());
/*      */       }
/*  652 */       if (sub.producers.size() == 0) {
/*  653 */         String m = "";
/*  654 */         for (MessageType type : filter.getMessageTypes()) {
/*  655 */           if (!this.noProducersExpected.contains(type))
/*  656 */             m = m + type + ",";
/*      */         }
/*  658 */         if (m.length() > 0) {
/*  659 */           Log.error("No producers for types " + m);
/*      */         }
/*      */       }
/*  662 */       if ((flags & 0x8) == 0) {
/*  663 */         FilterTable filterTable = filter.getReceiveFilterTable();
/*  664 */         if (filterTable == null)
/*  665 */           filterTable = this.defaultReceiveFilterTable;
/*      */         else
/*  667 */           addUniqueFilterTable(filterTable, this.receiveFilters);
/*  668 */         filterTable.addFilter(sub, callback);
/*      */       }
/*      */       else
/*      */       {
/*  672 */         FilterTable filterTable = filter.getResponderReceiveFilterTable();
/*  673 */         if (filterTable == null)
/*  674 */           filterTable = this.defaultResponderReceiveFilterTable;
/*      */         else
/*  676 */           addUniqueFilterTable(filterTable, this.responderReceiveFilters);
/*  677 */         filterTable.addFilter(sub, callback);
/*      */       }
/*      */ 
/*  683 */       if (sub.producers.size() > 0) {
/*  684 */         SubscribeMessage message = new SubscribeMessage(sub.subId, filter, trigger, sub.flags);
/*      */ 
/*  686 */         message.setMessageId(nextMessageId());
/*  687 */         if ((flags & 0x1) != 0) {
/*  688 */           rpc = setupInternalRPC(message, sub.producers);
/*      */         }
/*      */ 
/*  691 */         sendMessageToList(message, sub.producers);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  701 */     if ((rpc != null) && ((flags & 0x1) != 0) && ((flags & 0x2) == 0))
/*      */     {
/*  703 */       waitInternalRPC(rpc);
/*      */     }
/*      */ 
/*  706 */     return sub.subId;
/*      */   }
/*      */ 
/*      */   public boolean removeSubscription(long subId)
/*      */   {
/*  715 */     synchronized (this.subscriptions) {
/*  716 */       return _removeSubscription(Long.valueOf(subId));
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean removeSubscriptions(Collection<Long> subIds)
/*      */   {
/*  729 */     synchronized (this.subscriptions) {
/*  730 */       int count = 0;
/*  731 */       for (Long subId : subIds)
/*  732 */         if (_removeSubscription(subId))
/*  733 */           count++;
/*  734 */       return count == subIds.size();
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean _removeSubscription(Long subId)
/*      */   {
/*  742 */     RegisteredSubscription sub = (RegisteredSubscription)this.subscriptions.remove(subId);
/*  743 */     if (sub == null) {
/*  744 */       return false;
/*      */     }
/*  746 */     localSubscriptionRemovedCount += 1L;
/*  747 */     if ((sub.flags & 0x8) == 0) {
/*  748 */       FilterTable filterTable = sub.filter.getReceiveFilterTable();
/*  749 */       if (filterTable == null)
/*  750 */         filterTable = this.defaultReceiveFilterTable;
/*  751 */       filterTable.removeFilter(sub, sub.callback);
/*      */     }
/*      */     else {
/*  754 */       FilterTable filterTable = sub.filter.getResponderReceiveFilterTable();
/*  755 */       if (filterTable == null)
/*  756 */         filterTable = this.defaultResponderReceiveFilterTable;
/*  757 */       filterTable.removeFilter(sub, sub.callback);
/*      */     }
/*      */ 
/*  760 */     UnsubscribeMessage message = new UnsubscribeMessage(subId.longValue());
/*  761 */     message.setMessageId(nextMessageId());
/*  762 */     sendMessageToList(message, sub.producers);
/*  763 */     return true;
/*      */   }
/*      */ 
/*      */   public static boolean responseExpected(int flags)
/*      */   {
/*  772 */     return (flags & 0x1) != 0;
/*      */   }
/*      */ 
/*      */   public boolean applyFilterUpdate(long subId, FilterUpdate update)
/*      */   {
/*  796 */     return applyFilterUpdate(subId, update, 0, (RemoteAgent)null);
/*      */   }
/*      */ 
/*      */   public boolean applyFilterUpdate(long subId, FilterUpdate update, int flags)
/*      */   {
/*  809 */     return applyFilterUpdate(subId, update, flags, (RemoteAgent)null);
/*      */   }
/*      */ 
/*      */   public boolean applyFilterUpdate(long subId, FilterUpdate update, int flags, Message excludeSender)
/*      */   {
/*  823 */     return applyFilterUpdate(subId, update, flags, excludeSender.remoteAgent);
/*      */   }
/*      */ 
/*      */   protected boolean applyFilterUpdate(long subId, FilterUpdate update, int flags, RemoteAgent excludeAgent)
/*      */   {
/*  831 */     PendingRPC rpc = null;
/*  832 */     synchronized (this.subscriptions) {
/*  833 */       localFilterUpdateCount += 1L;
/*  834 */       RegisteredSubscription sub = (RegisteredSubscription)this.subscriptions.get(Long.valueOf(subId));
/*  835 */       if (sub == null) {
/*  836 */         return false;
/*      */       }
/*  838 */       FilterUpdateMessage message = new FilterUpdateMessage(subId, update);
/*      */ 
/*  840 */       message.setMessageId(nextMessageId());
/*      */ 
/*  842 */       List producers = sub.producers;
/*  843 */       if (excludeAgent != null) {
/*  844 */         producers = new ArrayList(producers);
/*  845 */         producers.remove(excludeAgent);
/*      */       }
/*  847 */       if (producers.size() > 0) {
/*  848 */         if ((flags & 0x1) != 0)
/*  849 */           rpc = setupInternalRPC(message, producers);
/*  850 */         sendMessageToList(message, producers);
/*      */       }
/*      */     }
/*      */ 
/*  854 */     if (rpc != null) {
/*  855 */       waitInternalRPC(rpc);
/*      */     }
/*      */ 
/*  858 */     return true;
/*      */   }
/*      */ 
/*      */   public int sendBroadcast(Message message)
/*      */   {
/*  868 */     message.setMessageId(nextMessageId());
/*  869 */     message.unsetRPC();
/*  870 */     return _sendBroadcast(message);
/*      */   }
/*      */ 
/*      */   private int _sendBroadcast(Message message)
/*      */   {
/*  876 */     if (Log.loggingDebug) {
/*  877 */       Log.debug("sendBroadcast type=" + message.getMsgType().getMsgTypeString() + " id=" + message.getMsgId() + " class=" + message.getClass().getName());
/*      */     }
/*      */ 
/*  881 */     if (!this.advertisements.contains(message.getMsgType())) {
/*  882 */       Log.error("NEED ADVERT - Add " + message.getMsgType() + " to " + this.advertFileName + " and restart server");
/*      */     }
/*      */ 
/*  885 */     Set matchingAgents = new HashSet(this.remoteAgents.size());
/*      */ 
/*  887 */     List triggers = new LinkedList();
/*  888 */     for (FilterTable filterTable : this.sendFilters) {
/*  889 */       filterTable.match(message, matchingAgents, triggers);
/*      */     }
/*      */ 
/*  893 */     for (Subscription triggerSub : triggers) {
/*  894 */       triggerSub.getTrigger().trigger(message, triggerSub.filter, this);
/*      */     }
/*      */ 
/*  899 */     sendMessageToList(message, matchingAgents);
/*      */ 
/*  901 */     return matchingAgents.size();
/*      */   }
/*      */ 
/*      */   public boolean sendDirect(Message message, AgentHandle destination, SubscriptionHandle runTriggers)
/*      */   {
/*  917 */     if (!(destination instanceof RemoteAgent))
/*  918 */       return false;
/*  919 */     if (!this.remoteAgents.contains(destination)) {
/*  920 */       return false;
/*      */     }
/*  922 */     message.setMessageId(nextMessageId());
/*  923 */     message.unsetRPC();
/*      */ 
/*  925 */     if ((runTriggers != null) && ((runTriggers instanceof RemoteSubscription))) {
/*  926 */       RemoteSubscription remoteSub = (RemoteSubscription)runTriggers;
/*  927 */       if (remoteSub.getTrigger() != null) {
/*  928 */         remoteSub.getTrigger().trigger(message, remoteSub.filter, this);
/*      */       }
/*      */     }
/*  931 */     Collection agents = new ArrayList(1);
/*  932 */     agents.add(destination);
/*  933 */     sendMessageToList(message, agents);
/*  934 */     return true;
/*      */   }
/*      */ 
/*      */   public Message sendRPC(Message message)
/*      */   {
/*  950 */     return sendRPC(message, 120000L);
/*      */   }
/*      */ 
/*      */   public Message sendRPC(Message message, long timeout)
/*      */   {
/*  967 */     PendingRPC rpc = _sendRPC(message, this);
/*      */ 
/*  969 */     SQThreadPool pool = SQThreadPool.getRunningPool();
/*  970 */     if (pool != null) {
/*  971 */       pool.runningThreadWillBlock();
/*      */     }
/*  973 */     long startTime = System.currentTimeMillis();
/*  974 */     synchronized (rpc) {
/*  975 */       while (rpc.response == null)
/*      */         try {
/*  977 */           long elapsed = System.currentTimeMillis() - startTime;
/*  978 */           long waitTime = timeout == 0L ? 0L : timeout - elapsed;
/*  979 */           rpc.wait(waitTime);
/*  980 */           if ((timeout != 0L) && (System.currentTimeMillis() - startTime >= timeout)) {
/*  981 */             Log.error("Exceeded maximum wait time");
/*  982 */             throw new RPCTimeoutException();
/*      */           }
/*      */         }
/*      */         catch (InterruptedException ex)
/*      */         {
/*      */         }
/*      */     }
/*  989 */     synchronized (this.pendingRPC) {
/*  990 */       this.pendingRPC.remove(Long.valueOf(rpc.messageId));
/*      */     }
/*      */ 
/*  993 */     if (pool != null) {
/*  994 */       pool.doneBlocking();
/*      */     }
/*  996 */     if ((rpc.response instanceof ExceptionResponseMessage)) {
/*  997 */       ExceptionResponseMessage exceptionResponse = (ExceptionResponseMessage)rpc.response;
/*      */ 
/*  999 */       if (exceptionResponse.getException().getExceptionClassName().equals("atavism.msgsys.NoRecipientsException")) {
/* 1000 */         throw new NoRecipientsException(exceptionResponse.getException().getMessage());
/*      */       }
/*      */ 
/* 1003 */       throw new RPCException(exceptionResponse.getException());
/*      */     }
/*      */ 
/* 1006 */     return rpc.response;
/*      */   }
/*      */ 
/*      */   public Boolean sendRPCReturnBoolean(Message message)
/*      */   {
/* 1021 */     BooleanResponseMessage response = (BooleanResponseMessage)sendRPC(message);
/* 1022 */     return response.getBooleanVal();
/*      */   }
/*      */ 
/*      */   public Integer sendRPCReturnInt(Message message)
/*      */   {
/* 1037 */     IntegerResponseMessage response = (IntegerResponseMessage)sendRPC(message);
/* 1038 */     return response.getIntVal();
/*      */   }
/*      */ 
/*      */   public Long sendRPCReturnLong(Message message)
/*      */   {
/* 1053 */     LongResponseMessage response = (LongResponseMessage)sendRPC(message);
/* 1054 */     return response.getLongVal();
/*      */   }
/*      */ 
/*      */   public OID sendRPCReturnOID(Message message)
/*      */   {
/* 1069 */     OIDResponseMessage response = (OIDResponseMessage)sendRPC(message);
/* 1070 */     return response.getOIDVal();
/*      */   }
/*      */ 
/*      */   public String sendRPCReturnString(Message message)
/*      */   {
/* 1085 */     StringResponseMessage response = (StringResponseMessage)sendRPC(message);
/* 1086 */     return response.getStringVal();
/*      */   }
/*      */ 
/*      */   public Object sendRPCReturnObject(Message message)
/*      */   {
/* 1101 */     GenericResponseMessage response = (GenericResponseMessage)sendRPC(message);
/* 1102 */     return response.getData();
/*      */   }
/*      */ 
/*      */   public void sendRPC(Message message, ResponseCallback callback)
/*      */   {
/* 1121 */     _sendRPC(message, callback);
/*      */   }
/*      */ 
/*      */   private PendingRPC _sendRPC(Message message, ResponseCallback callback)
/*      */   {
/* 1129 */     message.setMessageId(nextMessageId());
/* 1130 */     message.setRPC();
/*      */ 
/* 1132 */     if (Log.loggingDebug) {
/* 1133 */       Log.debug("sendRPC type=" + message.getMsgType().getMsgTypeString() + " id=" + message.getMsgId() + " class=" + message.getClass().getName());
/*      */     }
/*      */ 
/* 1137 */     if (!this.advertisements.contains(message.getMsgType())) {
/* 1138 */       Log.error("NEED ADVERT - Add " + message.getMsgType() + " to " + this.advertFileName + " and restart server");
/*      */     }
/*      */ 
/* 1142 */     PendingRPC rpc = new PendingRPC();
/* 1143 */     rpc.messageId = message.getMsgId();
/* 1144 */     rpc.responders = null;
/* 1145 */     rpc.callback = callback;
/*      */ 
/* 1147 */     synchronized (this.pendingRPC) {
/* 1148 */       this.pendingRPC.put(Long.valueOf(rpc.messageId), rpc);
/*      */     }
/*      */ 
/* 1151 */     HashSet matchingAgents = new HashSet();
/* 1152 */     Object triggers = new LinkedList();
/* 1153 */     for (FilterTable filterTable : this.responderSendFilters) {
/* 1154 */       filterTable.match(message, matchingAgents, (List)triggers);
/*      */     }
/*      */ 
/* 1157 */     if (matchingAgents.size() == 0) {
/* 1158 */       synchronized (this.pendingRPC) {
/* 1159 */         this.pendingRPC.remove(Long.valueOf(rpc.messageId));
/*      */       }
/* 1161 */       throw new NoRecipientsException("sendRPC: no message recipients for type=" + message.getMsgType() + " " + message + ", class " + message.getClass().getName());
/*      */     }
/*      */ 
/* 1165 */     if (matchingAgents.size() != 1) {
/* 1166 */       synchronized (this.pendingRPC) {
/* 1167 */         this.pendingRPC.remove(Long.valueOf(rpc.messageId));
/*      */       }
/* 1169 */       throw new MultipleRecipientsException("sendRPC: multiple message recipients for type=" + message.getMsgType() + " " + message + ", class " + message.getClass().getName());
/*      */     }
/*      */ 
/* 1174 */     rpc.responders = matchingAgents;
/*      */ 
/* 1177 */     for (Subscription triggerSub : (List)triggers) {
/* 1178 */       triggerSub.getTrigger().trigger(message, triggerSub.filter, this);
/*      */     }
/*      */ 
/* 1184 */     synchronized (rpc) {
/* 1185 */       sendMessageToList(message, matchingAgents);
/*      */     }
/*      */ 
/* 1192 */     return (PendingRPC)rpc;
/*      */   }
/*      */ 
/*      */   private void sendMessageToList(Message message, Collection agents)
/*      */   {
/* 1197 */     int count = 0;
/* 1198 */     for (Iterator i$ = agents.iterator(); i$.hasNext(); ) { Object agent = i$.next();
/* 1199 */       AgentInfo remoteAgent = (AgentInfo)agent;
/* 1200 */       if (Log.loggingDebug) {
/* 1201 */         Log.debug("Sending " + message.getMsgType().getMsgTypeString() + " id=" + message.getMsgId() + " to " + remoteAgent.agentName);
/*      */       }
/* 1203 */       synchronized (remoteAgent.outputBuf) {
/* 1204 */         if (remoteAgent.socket != null) {
/* 1205 */           Message.toBytes(message, remoteAgent.outputBuf);
/* 1206 */           count++;
/*      */         }
/* 1208 */         else if (remoteAgent == this.selfRemoteAgent) {
/* 1209 */           Message.toBytes(message, remoteAgent.outputBuf);
/* 1210 */           remoteAgent.outputBuf.notify();
/*      */         }
/*      */       }
/*      */     }
/* 1214 */     if (count > 0)
/* 1215 */       this.messageIO.outputReady();
/*      */   }
/*      */ 
/*      */   PendingRPC setupInternalRPC(Message message, List producers)
/*      */   {
/* 1220 */     message.setRPC();
/* 1221 */     PendingRPC rpc = new PendingRPC();
/* 1222 */     rpc.messageId = message.getMsgId();
/* 1223 */     rpc.responders = new HashSet();
/* 1224 */     rpc.responders.addAll(producers);
/*      */ 
/* 1228 */     rpc.callback = this;
/*      */ 
/* 1230 */     synchronized (this.pendingRPC) {
/* 1231 */       this.pendingRPC.put(Long.valueOf(rpc.messageId), rpc);
/*      */     }
/* 1233 */     return rpc;
/*      */   }
/*      */ 
/*      */   void waitInternalRPC(PendingRPC rpc)
/*      */   {
/* 1238 */     SQThreadPool pool = SQThreadPool.getRunningPool();
/* 1239 */     if (pool != null) {
/* 1240 */       pool.runningThreadWillBlock();
/*      */     }
/* 1242 */     synchronized (rpc) {
/* 1243 */       while (rpc.responders.size() > 0)
/*      */         try {
/* 1245 */           rpc.wait();
/*      */         }
/*      */         catch (InterruptedException ignore) {
/*      */         }
/*      */     }
/* 1250 */     synchronized (this.pendingRPC) {
/* 1251 */       this.pendingRPC.remove(Long.valueOf(rpc.messageId));
/*      */     }
/*      */ 
/* 1254 */     if (pool != null)
/* 1255 */       pool.doneBlocking();
/*      */   }
/*      */ 
/*      */   public int sendBroadcastRPC(Message message, ResponseCallback callback)
/*      */   {
/* 1275 */     message.setMessageId(nextMessageId());
/* 1276 */     message.setRPC();
/*      */ 
/* 1278 */     if (Log.loggingDebug) {
/* 1279 */       Log.debug("sendBroadcastRPC type=" + message.getMsgType().getMsgTypeString() + " id=" + message.getMsgId() + " class=" + message.getClass().getName());
/*      */     }
/*      */ 
/* 1285 */     if (!this.advertisements.contains(message.getMsgType())) {
/* 1286 */       Log.error("NEED ADVERT - Add " + message.getMsgType() + " to " + this.advertFileName + " and restart server");
/*      */     }
/*      */ 
/* 1289 */     PendingRPC rpc = new PendingRPC();
/* 1290 */     rpc.messageId = message.getMsgId();
/* 1291 */     rpc.responders = new HashSet();
/* 1292 */     rpc.callback = callback;
/*      */ 
/* 1294 */     synchronized (this.pendingRPC) {
/* 1295 */       this.pendingRPC.put(Long.valueOf(rpc.messageId), rpc);
/*      */     }
/*      */ 
/* 1298 */     List triggers = new LinkedList();
/* 1299 */     for (FilterTable filterTable : this.responderSendFilters) {
/* 1300 */       filterTable.match(message, rpc.responders, triggers);
/*      */     }
/*      */ 
/* 1304 */     for (Subscription triggerSub : triggers) {
/* 1305 */       triggerSub.getTrigger().trigger(message, triggerSub.filter, this);
/*      */     }
/*      */ 
/* 1309 */     int responderCount = rpc.responders.size();
/* 1310 */     synchronized (rpc) {
/* 1311 */       sendMessageToList(message, rpc.responders);
/*      */     }
/*      */ 
/* 1314 */     if (responderCount == 0) {
/* 1315 */       synchronized (this.pendingRPC) {
/* 1316 */         this.pendingRPC.remove(Long.valueOf(rpc.messageId));
/*      */       }
/*      */     }
/*      */ 
/* 1320 */     return responderCount;
/*      */   }
/*      */ 
/*      */   public int sendBroadcastRPCBlocking(Message message, ResponseCallback callback)
/*      */   {
/* 1339 */     return sendBroadcastRPCBlocking(message, callback, 120000L);
/*      */   }
/*      */ 
/*      */   public int sendBroadcastRPCBlocking(Message message, ResponseCallback callback, long timeout)
/*      */   {
/* 1360 */     BlockingRPCState countingCallback = new BlockingRPCState(callback);
/*      */ 
/* 1362 */     int responderCount = sendBroadcastRPC(message, countingCallback);
/*      */ 
/* 1364 */     long startTime = System.currentTimeMillis();
/* 1365 */     synchronized (countingCallback) {
/* 1366 */       while (countingCallback.getResponseCount() < responderCount)
/*      */         try {
/* 1368 */           long elapsed = System.currentTimeMillis() - startTime;
/* 1369 */           long waitTime = timeout == 0L ? 0L : timeout - elapsed;
/* 1370 */           countingCallback.wait(waitTime);
/* 1371 */           if ((timeout != 0L) && (System.currentTimeMillis() - startTime >= timeout)) {
/* 1372 */             Log.error("Exceeded maximum wait time");
/* 1373 */             throw new RPCTimeoutException();
/*      */           }
/*      */         }
/*      */         catch (InterruptedException ex)
/*      */         {
/*      */         }
/*      */     }
/* 1380 */     return responderCount;
/*      */   }
/*      */ 
/*      */   public void sendResponse(ResponseMessage message)
/*      */   {
/* 1388 */     message.setMessageId(nextMessageId());
/*      */ 
/* 1390 */     if (Log.loggingDebug) {
/* 1391 */       Log.debug("sendResponse to " + message.getRequestingAgent().agentName + "," + message.getRequestId() + " type=" + message.getMsgType().getMsgTypeString() + " id=" + message.getMsgId() + " class=" + message.getClass().getName());
/*      */     }
/*      */ 
/* 1397 */     synchronized (message.getRequestingAgent().outputBuf) {
/* 1398 */       Message.toBytes(message, message.getRequestingAgent().outputBuf);
/* 1399 */       if (message.getRequestingAgent() == this.selfRemoteAgent) {
/* 1400 */         this.selfRemoteAgent.outputBuf.notify();
/*      */       }
/*      */     }
/* 1403 */     if (message.getRequestingAgent() != this.selfRemoteAgent)
/* 1404 */       this.messageIO.outputReady();
/*      */   }
/*      */ 
/*      */   public void sendBooleanResponse(Message message, Boolean booleanVal)
/*      */   {
/* 1413 */     if (!message.isRPC()) {
/* 1414 */       Log.error("sendBooleanResponse, msg is not rpc, msg=" + message);
/* 1415 */       return;
/*      */     }
/* 1417 */     BooleanResponseMessage response = new BooleanResponseMessage(message, booleanVal);
/* 1418 */     sendResponse(response);
/*      */   }
/*      */ 
/*      */   public void sendIntegerResponse(Message message, Integer intVal)
/*      */   {
/* 1427 */     if (!message.isRPC()) {
/* 1428 */       Log.error("sendIntegerResponse, msg is not rpc, msg=" + message);
/* 1429 */       return;
/*      */     }
/* 1431 */     IntegerResponseMessage response = new IntegerResponseMessage(message, intVal);
/* 1432 */     sendResponse(response);
/*      */   }
/*      */ 
/*      */   public void sendLongResponse(Message message, Long longVal)
/*      */   {
/* 1441 */     if (!message.isRPC()) {
/* 1442 */       Log.error("sendLongResponse, msg is not rpc, msg=" + message);
/* 1443 */       return;
/*      */     }
/* 1445 */     LongResponseMessage response = new LongResponseMessage(message, longVal);
/* 1446 */     sendResponse(response);
/*      */   }
/*      */ 
/*      */   public void sendOIDResponse(Message message, OID oidVal)
/*      */   {
/* 1456 */     if (!message.isRPC()) {
/* 1457 */       Log.error("sendLongResponse, msg is not rpc, msg=" + message);
/* 1458 */       return;
/*      */     }
/* 1460 */     OIDResponseMessage response = new OIDResponseMessage(message, oidVal);
/* 1461 */     sendResponse(response);
/*      */   }
/*      */ 
/*      */   public void sendStringResponse(Message message, String stringVal)
/*      */   {
/* 1470 */     if (!message.isRPC()) {
/* 1471 */       Log.error("sendStringResponse, msg is not rpc, msg=" + message);
/* 1472 */       return;
/*      */     }
/* 1474 */     StringResponseMessage response = new StringResponseMessage(message, stringVal);
/* 1475 */     sendResponse(response);
/*      */   }
/*      */ 
/*      */   public void sendObjectResponse(Message message, Object object)
/*      */   {
/* 1484 */     if (!message.isRPC()) {
/* 1485 */       Log.error("sendObjectResponse, msg is not rpc, msg=" + message);
/* 1486 */       return;
/*      */     }
/* 1488 */     GenericResponseMessage response = new GenericResponseMessage(message, object);
/* 1489 */     sendResponse(response);
/*      */   }
/*      */ 
/*      */   public ExecutorService getResponseThreadPool()
/*      */   {
/* 1497 */     return this.responseCallbackPool;
/*      */   }
/*      */ 
/*      */   public void setResponseThreadPool(ExecutorService threadPool)
/*      */   {
/* 1504 */     this.responseCallbackPool = threadPool;
/*      */   }
/*      */ 
/*      */   public void handleResponse(ResponseMessage message)
/*      */   {
/*      */   }
/*      */ 
/*      */   public long getAppMessageCount()
/*      */   {
/* 1516 */     return this.statAppMessageCount;
/*      */   }
/*      */ 
/*      */   public long getSystemMessageCount()
/*      */   {
/* 1522 */     return this.statSystemMessageCount;
/*      */   }
/*      */ 
/*      */   public void startStatsThread()
/*      */   {
/* 1528 */     Thread messageAgentStatsLogger = new Thread(new MessageAgentStatsLogger(), "Stats:MessageAgent");
/*      */ 
/* 1530 */     messageAgentStatsLogger.setDaemon(true);
/* 1531 */     messageAgentStatsLogger.start();
/*      */   }
/*      */ 
/*      */   public void onTcpAccept(SocketChannel agentSocket)
/*      */   {
/*      */     try {
/* 1537 */       agentSocket.socket().setTcpNoDelay(true);
/* 1538 */       this.threadPool.execute(new NewConnectionHandler(agentSocket));
/*      */     } catch (IOException ex) {
/* 1540 */       Log.exception("Agent listener", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private RemoteAgent waitForAgent(SocketChannel agentSocket)
/*      */     throws IOException, AORuntimeException
/*      */   {
/* 1590 */     ByteBuffer buf = ByteBuffer.allocate(4);
/* 1591 */     int nBytes = ChannelUtil.fillBuffer(buf, agentSocket);
/* 1592 */     if (nBytes < 4) {
/* 1593 */       Log.error("Agent: invalid agent hello bytes=" + nBytes);
/* 1594 */       return null;
/*      */     }
/*      */ 
/* 1597 */     int msgLen = buf.getInt();
/* 1598 */     if (msgLen < 0) {
/* 1599 */       return null;
/*      */     }
/* 1601 */     AOByteBuffer buffer = new AOByteBuffer(msgLen);
/* 1602 */     nBytes = ChannelUtil.fillBuffer(buffer.getNioBuf(), agentSocket);
/* 1603 */     if (nBytes < msgLen) {
/* 1604 */       Log.error("Agent: invalid agent state, expecting " + msgLen + " got " + nBytes);
/*      */ 
/* 1606 */       return null;
/*      */     }
/*      */ 
/* 1610 */     AgentStateMessage agentState = (AgentStateMessage)MarshallingRuntime.unmarshalObject(buffer);
/*      */     RemoteAgent remoteAgent;
/* 1613 */     synchronized (this.remoteAgents) {
/* 1614 */       if ((agentState.agentName == null) || (agentState.agentName.equals("")))
/*      */       {
/* 1616 */         Log.error("Missing remote agent name");
/* 1617 */         return null;
/*      */       }
/* 1619 */       if (getAgent(agentState.agentName) != null) {
/* 1620 */         Log.error("Already connected to '" + agentState.agentName + "'");
/* 1621 */         return null;
/*      */       }
/*      */ 
/* 1624 */       if (getAgent(agentState.agentId) != null) {
/* 1625 */         Log.error("Already connected to '" + agentState.agentName + "' agentId " + agentState.agentId);
/*      */ 
/* 1627 */         return null;
/*      */       }
/*      */ 
/* 1630 */       if ((agentState.agentIP == null) || (agentState.agentIP.equals("")))
/*      */       {
/* 1632 */         Log.error("Missing remote agent IP address");
/* 1633 */         return null;
/*      */       }
/*      */ 
/* 1636 */       if (agentState.agentIP.equals(":same")) {
/* 1637 */         InetAddress agentAddress = agentSocket.socket().getInetAddress();
/* 1638 */         agentState.agentIP = agentAddress.getHostAddress();
/*      */       }
/*      */ 
/* 1641 */       remoteAgent = new RemoteAgent();
/* 1642 */       remoteAgent.agentId = agentState.agentId;
/* 1643 */       remoteAgent.socket = agentSocket;
/* 1644 */       remoteAgent.agentName = agentState.agentName;
/* 1645 */       remoteAgent.agentIP = agentState.agentIP;
/* 1646 */       remoteAgent.agentPort = agentState.agentPort;
/* 1647 */       remoteAgent.outputBuf = new AOByteBuffer(8192);
/* 1648 */       remoteAgent.inputBuf = new AOByteBuffer(8192);
/* 1649 */       remoteAgent.flags = agentState.domainFlags;
/*      */ 
/* 1652 */       this.remoteAgents.add(remoteAgent);
/*      */     }
/*      */ 
/* 1655 */     return remoteAgent;
/*      */   }
/*      */ 
/*      */   public void handleMessageData(int length, AOByteBuffer messageData, AgentInfo agentInfo)
/*      */   {
/* 1740 */     if ((length == -1) || (messageData == null)) {
/* 1741 */       if (agentInfo.socket == this.domainServerSocket) {
/* 1742 */         Log.error("Lost connection to domain server, exiting");
/* 1743 */         System.exit(1);
/* 1744 */         return;
/*      */       }
/* 1746 */       if ((agentInfo.flags & 0x1) != 0) {
/* 1747 */         Log.debug("Lost connection to agent '" + agentInfo.agentName + "' (transient) " + agentInfo.socket);
/*      */ 
/* 1750 */         this.messageIO.removeAgent(agentInfo);
/*      */         try {
/* 1752 */           agentInfo.socket.close(); } catch (IOException e) {
/*      */         }
/* 1754 */         agentInfo.socket = null;
/* 1755 */         synchronized (this.remoteAgents) {
/* 1756 */           this.remoteAgents.remove(agentInfo);
/*      */         }
/* 1758 */         this.remoteAgentOutput.removeKey((RemoteAgent)agentInfo);
/*      */       }
/*      */       else {
/* 1761 */         Log.error("Lost connection to agent '" + agentInfo.agentName + "' " + agentInfo.socket);
/*      */ 
/* 1763 */         synchronized (agentInfo.outputBuf) {
/* 1764 */           agentInfo.socket = null;
/* 1765 */           agentInfo.outputBuf = new AOByteBuffer(8192);
/* 1766 */           agentInfo.inputBuf = new AOByteBuffer(8192);
/*      */         }
/*      */       }
/*      */ 
/* 1770 */       return;
/*      */     }
/*      */ 
/* 1774 */     Message message = (Message)MarshallingRuntime.unmarshalObject(messageData);
/*      */ 
/* 1778 */     MessageType msgType = message.getMsgType();
/*      */ 
/* 1780 */     if (Log.loggingDebug) {
/* 1781 */       String responseTo = "";
/* 1782 */       if ((message instanceof ResponseMessage))
/* 1783 */         responseTo = " responseTo=" + ((ResponseMessage)message).getRequestId();
/* 1784 */       Log.debug("handleMessageData from " + agentInfo.agentName + "," + message.getMsgId() + responseTo + " type=" + msgType.getMsgTypeString() + " len=" + length + " class=" + message.getClass().getName());
/*      */     }
/*      */ 
/* 1791 */     if (!MessageTypes.isInternal(msgType)) {
/* 1792 */       this.statAppMessageCount += 1L;
/* 1793 */       message.remoteAgent = ((RemoteAgent)agentInfo);
/* 1794 */       if ((message instanceof ResponseMessage))
/* 1795 */         handleResponse((ResponseMessage)message, (RemoteAgent)agentInfo);
/*      */       else
/* 1797 */         deliverMessage(message);
/* 1798 */       return;
/*      */     }
/*      */ 
/* 1801 */     this.statSystemMessageCount += 1L;
/* 1802 */     if (msgType == MessageTypes.MSG_TYPE_SUBSCRIBE) {
/* 1803 */       remoteSubscriptionCreatedCount += 1L;
/* 1804 */       message.remoteAgent = ((RemoteAgent)agentInfo);
/* 1805 */       handleSubscribe((SubscribeMessage)message, (RemoteAgent)agentInfo);
/*      */     }
/* 1807 */     else if (msgType == MessageTypes.MSG_TYPE_UNSUBSCRIBE) {
/* 1808 */       remoteSubscriptionRemovedCount += 1L;
/* 1809 */       message.remoteAgent = ((RemoteAgent)agentInfo);
/* 1810 */       handleUnsubscribe((UnsubscribeMessage)message, (RemoteAgent)agentInfo);
/*      */     }
/* 1812 */     else if (msgType == MessageTypes.MSG_TYPE_FILTER_UPDATE) {
/* 1813 */       remoteFilterUpdateCount += 1L;
/* 1814 */       message.remoteAgent = ((RemoteAgent)agentInfo);
/* 1815 */       handleFilterUpdate((FilterUpdateMessage)message, (RemoteAgent)agentInfo);
/*      */     }
/* 1817 */     else if (msgType == MessageTypes.MSG_TYPE_ADVERTISE) {
/* 1818 */       message.remoteAgent = ((RemoteAgent)agentInfo);
/* 1819 */       handleAdvertise((AdvertiseMessage)message, (RemoteAgent)agentInfo);
/*      */     }
/* 1821 */     else if (msgType == MessageTypes.MSG_TYPE_NEW_AGENT) {
/* 1822 */       handleNewAgentMessage((NewAgentMessage)message);
/*      */     }
/*      */     else {
/* 1825 */       Log.error("handleMessageData: unknown message type " + msgType);
/* 1826 */       System.out.println("Unknown message type " + msgType);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleSelfMessage(Message message)
/*      */   {
/* 1832 */     if (Log.loggingDebug) {
/* 1833 */       String responseTo = "";
/* 1834 */       if ((message instanceof ResponseMessage))
/* 1835 */         responseTo = " responseTo=" + ((ResponseMessage)message).getRequestId();
/* 1836 */       Log.debug("handleSelfMessage id=" + message.getMsgId() + responseTo + " type=" + message.getMsgType().getMsgTypeString() + " class=" + message.getClass().getName());
/*      */     }
/*      */ 
/* 1842 */     int msgTypeNumber = message.getMsgType().getMsgTypeNumber();
/* 1843 */     if ((message instanceof ResponseMessage)) {
/* 1844 */       handleResponse((ResponseMessage)message, this.selfRemoteAgent);
/* 1845 */     } else if ((msgTypeNumber < MessageTypes.catalog.getFirstMsgNumber()) || (msgTypeNumber > MessageTypes.catalog.getLastMsgNumber()))
/*      */     {
/* 1847 */       deliverMessage(message);
/*      */     }
/*      */     else {
/* 1850 */       this.statSystemMessageCount += 1L;
/* 1851 */       MessageType msgType = message.getMsgType();
/* 1852 */       if (msgType == MessageTypes.MSG_TYPE_ADVERTISE) {
/* 1853 */         handleAdvertise((AdvertiseMessage)message, this.selfRemoteAgent);
/*      */       }
/* 1855 */       else if (msgType == MessageTypes.MSG_TYPE_SUBSCRIBE) {
/* 1856 */         handleSubscribe((SubscribeMessage)message, this.selfRemoteAgent);
/*      */       }
/* 1858 */       else if (msgType == MessageTypes.MSG_TYPE_UNSUBSCRIBE) {
/* 1859 */         handleUnsubscribe((UnsubscribeMessage)message, this.selfRemoteAgent);
/*      */       }
/* 1861 */       else if (msgType == MessageTypes.MSG_TYPE_FILTER_UPDATE) {
/* 1862 */         handleFilterUpdate((FilterUpdateMessage)message, this.selfRemoteAgent);
/*      */       }
/*      */       else
/* 1865 */         Log.error("Unknown message type " + message.getMsgType());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleNewAgentMessage(NewAgentMessage message)
/*      */   {
/* 1882 */     if (this.agentName.compareTo(message.agentName) > 0) {
/* 1883 */       this.threadPool.execute(new AgentConnector(message));
/* 1884 */     } else if (this.agentName.equals(message.agentName)) {
/* 1885 */       Log.error("Duplicate agent name '" + this.agentName + "', exiting");
/* 1886 */       System.exit(1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleAdvertise(AdvertiseMessage message, RemoteAgent remoteAgent)
/*      */   {
/* 1894 */     synchronized (this.advertisements) {
/* 1895 */       Collection newAdverts = message.getAdvertisements();
/* 1896 */       Collection oldAdverts = remoteAgent.getAdvertisements();
/*      */ 
/* 1898 */       List addAdverts = new LinkedList();
/* 1899 */       List removeAdverts = new LinkedList();
/*      */ 
/* 1901 */       for (MessageType ii : newAdverts) {
/* 1902 */         if (!oldAdverts.contains(ii)) {
/* 1903 */           addAdverts.add(ii);
/*      */         }
/*      */       }
/* 1906 */       for (MessageType ii : oldAdverts) {
/* 1907 */         if (!newAdverts.contains(ii)) {
/* 1908 */           removeAdverts.add(ii);
/*      */         }
/*      */       }
/* 1911 */       if (Log.loggingDebug) {
/* 1912 */         Log.debug("[" + remoteAgent.agentName + "," + message.getMsgId() + "] handleAdvertise: Adding " + addAdverts.size() + " and removing " + removeAdverts.size());
/*      */       }
/*      */ 
/* 1916 */       if (message.isRPC()) {
/* 1917 */         ResponseMessage response = new ResponseMessage(message);
/* 1918 */         sendResponse(response);
/*      */       }
/*      */ 
/* 1921 */       synchronized (this.subscriptions) {
/* 1922 */         Collection mySubs = this.subscriptions.values();
/* 1923 */         boolean self = false;
/* 1924 */         boolean remote = false;
/* 1925 */         for (RegisteredSubscription sub : mySubs) {
/* 1926 */           if ((sub.filter.matchMessageType(addAdverts)) && 
/* 1927 */             (!sub.producers.contains(remoteAgent))) {
/* 1928 */             sub.producers.add(remoteAgent);
/* 1929 */             SubscribeMessage subscribeMsg = new SubscribeMessage(sub.subId, sub.filter, sub.trigger, sub.flags);
/*      */ 
/* 1932 */             subscribeMsg.setMessageId(nextMessageId());
/* 1933 */             if (Log.loggingDebug) {
/* 1934 */               Log.debug("Sending " + subscribeMsg.getMsgType().getMsgTypeString() + " id=" + subscribeMsg.getMsgId() + " to " + remoteAgent.agentName);
/*      */             }
/*      */ 
/* 1938 */             synchronized (remoteAgent.outputBuf) {
/* 1939 */               Message.toBytes(subscribeMsg, remoteAgent.outputBuf);
/*      */             }
/*      */ 
/* 1942 */             if (remoteAgent == this.selfRemoteAgent)
/* 1943 */               self = true;
/*      */             else {
/* 1945 */               remote = true;
/*      */             }
/*      */           }
/*      */         }
/* 1949 */         if (self)
/* 1950 */           this.selfRemoteAgent.outputBuf.notify();
/* 1951 */         if (remote) {
/* 1952 */           this.messageIO.outputReady();
/*      */         }
/*      */       }
/* 1955 */       remoteAgent.setAdvertisements(newAdverts);
/*      */     }
/*      */ 
/* 1958 */     synchronized (this.remoteAgents) {
/* 1959 */       if (!remoteAgent.hasFlag(256)) {
/* 1960 */         remoteAgent.setFlag(256);
/* 1961 */         this.remoteAgents.notify();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleSubscribe(SubscribeMessage message, RemoteAgent remoteAgent)
/*      */   {
/* 1970 */     if (Log.loggingDebug) {
/* 1971 */       Log.debug("[" + remoteAgent.agentName + "," + message.getMsgId() + "] Got subscription subId=" + message.getSubId() + " filter " + message.getFilter());
/*      */     }
/*      */ 
/* 1975 */     RemoteSubscription remoteSub = new RemoteSubscription();
/* 1976 */     remoteSub.remoteAgent = remoteAgent;
/* 1977 */     remoteSub.subId = message.getSubId();
/* 1978 */     remoteSub.filter = message.getFilter();
/* 1979 */     remoteSub.trigger = message.getTrigger();
/* 1980 */     remoteSub.flags = message.getFlags();
/*      */ 
/* 1982 */     if (remoteSub.trigger != null) {
/* 1983 */       remoteSub.trigger.setFilter(remoteSub.filter);
/*      */     }
/* 1985 */     remoteAgent.addRemoteSubscription(remoteSub);
/*      */     FilterTable filterTable;
/* 1988 */     if ((remoteSub.flags & 0x8) == 0) {
/* 1989 */       FilterTable filterTable = remoteSub.filter.getSendFilterTable();
/* 1990 */       if (filterTable == null)
/* 1991 */         filterTable = this.defaultSendFilterTable;
/*      */       else
/* 1993 */         addUniqueFilterTable(filterTable, this.sendFilters);
/*      */     }
/*      */     else {
/* 1996 */       filterTable = remoteSub.filter.getResponderSendFilterTable();
/* 1997 */       if (filterTable == null)
/* 1998 */         filterTable = this.defaultResponderSendFilterTable;
/*      */       else {
/* 2000 */         addUniqueFilterTable(filterTable, this.responderSendFilters);
/*      */       }
/*      */     }
/* 2003 */     filterTable.addFilter(remoteSub, remoteAgent);
/*      */ 
/* 2005 */     if (message.isRPC()) {
/* 2006 */       ResponseMessage response = new ResponseMessage(message);
/* 2007 */       sendResponse(response);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleUnsubscribe(UnsubscribeMessage message, RemoteAgent remoteAgent)
/*      */   {
/* 2015 */     List subIds = message.getSubIds();
/* 2016 */     if (Log.loggingDebug) {
/* 2017 */       Log.debug("[" + remoteAgent.agentName + "," + message.getMsgId() + "] Got unsubscribe count=" + subIds.size());
/*      */     }
/*      */ 
/* 2020 */     for (Long subId : subIds) {
/* 2021 */       RemoteSubscription remoteSub = remoteAgent.removeRemoteSubscription(subId);
/*      */ 
/* 2023 */       if (remoteSub == null) {
/* 2024 */         Log.error("MessageAgent: duplicate remove sub");
/* 2025 */         continue;
/*      */       }
/* 2027 */       if ((remoteSub.flags & 0x8) == 0) {
/* 2028 */         FilterTable filterTable = remoteSub.filter.getSendFilterTable();
/* 2029 */         if (filterTable == null)
/* 2030 */           filterTable = this.defaultSendFilterTable;
/* 2031 */         filterTable.removeFilter(remoteSub, remoteAgent);
/*      */       }
/*      */       else {
/* 2034 */         FilterTable filterTable = remoteSub.filter.getResponderSendFilterTable();
/*      */ 
/* 2036 */         if (filterTable == null)
/* 2037 */           filterTable = this.defaultResponderSendFilterTable;
/* 2038 */         filterTable.removeFilter(remoteSub, remoteAgent);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleFilterUpdate(FilterUpdateMessage message, RemoteAgent remoteAgent)
/*      */   {
/* 2048 */     remoteFilterUpdateCount += 1L;
/*      */ 
/* 2050 */     if (Log.loggingDebug) {
/* 2051 */       Log.debug("[" + remoteAgent.agentName + "," + message.getMsgId() + "] Got filter update subId=" + message.getSubId() + " rpc=" + message.isRPC());
/*      */     }
/*      */ 
/* 2055 */     RemoteSubscription remoteSub = remoteAgent.getRemoteSubscription(Long.valueOf(message.getSubId()));
/*      */ 
/* 2057 */     if (remoteSub == null) {
/* 2058 */       Log.error("handleFilterUpdate: unknown subId=" + message.getSubId());
/* 2059 */       return;
/*      */     }
/* 2061 */     remoteSub.filter.applyFilterUpdate(message.getFilterUpdate(), remoteAgent, remoteSub);
/*      */ 
/* 2064 */     if (message.isRPC()) {
/* 2065 */       ResponseMessage response = new ResponseMessage(message);
/* 2066 */       sendResponse(response);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleResponse(ResponseMessage message, RemoteAgent remoteAgent)
/*      */   {
/*      */     PendingRPC rpc;
/* 2077 */     synchronized (this.pendingRPC) {
/* 2078 */       rpc = (PendingRPC)this.pendingRPC.get(Long.valueOf(message.getRequestId()));
/* 2079 */       if (rpc == null) {
/* 2080 */         Log.error("Unexpected RPC response requestId=" + message.getRequestId() + " from=" + remoteAgent.agentName + "," + message.getMsgId());
/*      */ 
/* 2083 */         return;
/*      */       }
/*      */     }
/*      */ 
/* 2087 */     synchronized (rpc)
/*      */     {
/* 2090 */       if (rpc.responders != null) {
/* 2091 */         rpc.responders.remove(remoteAgent);
/*      */       }
/* 2093 */       if (rpc.callback == this)
/*      */       {
/* 2095 */         rpc.response = message;
/* 2096 */         rpc.notify();
/*      */       }
/*      */       else {
/* 2099 */         if (rpc.responders.size() == 0) {
/* 2100 */           synchronized (this.pendingRPC) {
/* 2101 */             this.pendingRPC.remove(Long.valueOf(message.getRequestId()));
/*      */           }
/*      */         }
/* 2104 */         this.responseCallbackPool.execute(new AsyncRPCResponse(message, rpc.callback));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void deliverMessage(Message message)
/*      */   {
/* 2114 */     int rpcCount = 0;
/* 2115 */     HashSet callbacks = new HashSet();
/* 2116 */     if (message.isRPC()) {
/*      */       try {
/* 2118 */         for (FilterTable filterTable : this.responderReceiveFilters) {
/* 2119 */           filterTable.match(message, callbacks, null);
/*      */         }
/* 2121 */         for (Iterator i$ = callbacks.iterator(); i$.hasNext(); ) { Object callback = i$.next();
/* 2122 */           if (Log.loggingDebug)
/* 2123 */             Log.debug("deliverMessage " + message.getMsgId() + " rpc to " + callback);
/* 2124 */           if ((callback instanceof MessageDispatch)) {
/* 2125 */             ((MessageDispatch)callback).dispatchMessage(message, 1, (MessageCallback)callback);
/*      */           }
/*      */           else
/*      */           {
/* 2129 */             ((MessageCallback)callback).handleMessage(message, 1);
/*      */           }
/* 2131 */           rpcCount++;
/*      */         }
/* 2133 */         if (rpcCount == 0) {
/* 2134 */           ExceptionResponseMessage response = new ExceptionResponseMessage(message, new NoRecipientsException("sendRPC: no message recipients for type=" + message.getMsgType() + " " + message + ", class " + message.getClass().getName()));
/*      */ 
/* 2140 */           sendResponse(response);
/*      */         }
/*      */       }
/*      */       catch (Exception e) {
/* 2144 */         ExceptionResponseMessage response = new ExceptionResponseMessage(message, e);
/*      */ 
/* 2146 */         sendResponse(response);
/*      */       }
/* 2148 */       callbacks.clear();
/*      */     }
/*      */ 
/* 2152 */     for (FilterTable filterTable : this.receiveFilters) {
/* 2153 */       filterTable.match(message, callbacks, null);
/*      */     }
/* 2155 */     if ((Log.loggingDebug) && (callbacks.size() == 0) && (rpcCount == 0)) {
/* 2156 */       Log.debug("deliverMessage matched 0 callbacks");
/*      */     }
/* 2158 */     for (Iterator i$ = callbacks.iterator(); i$.hasNext(); ) { Object callback = i$.next();
/* 2159 */       if (Log.loggingDebug)
/* 2160 */         Log.debug("deliverMessage " + message.getMsgId() + " to " + callback);
/* 2161 */       if ((callback instanceof MessageDispatch)) {
/* 2162 */         ((MessageDispatch)callback).dispatchMessage(message, 0, (MessageCallback)callback);
/*      */       }
/*      */       else
/*      */       {
/* 2166 */         ((MessageCallback)callback).handleMessage(message, 0);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private RemoteAgent getAgent(String agentName)
/*      */   {
/* 2242 */     for (RemoteAgent remoteAgent : this.remoteAgents) {
/* 2243 */       if (agentName.equals(remoteAgent.agentName))
/* 2244 */         return remoteAgent;
/*      */     }
/* 2246 */     return null;
/*      */   }
/*      */ 
/*      */   private RemoteAgent getAgent(int agentId)
/*      */   {
/* 2252 */     for (RemoteAgent remoteAgent : this.remoteAgents) {
/* 2253 */       if (agentId == remoteAgent.agentId)
/* 2254 */         return remoteAgent;
/*      */     }
/* 2256 */     return null;
/*      */   }
/*      */ 
/*      */   private void sendAdvertisements(RemoteAgent remoteAgent)
/*      */   {
/* 2378 */     AdvertiseMessage message = new AdvertiseMessage(this.advertisements);
/* 2379 */     message.setMessageId(nextMessageId());
/* 2380 */     Message.toBytes(message, remoteAgent.outputBuf);
/*      */   }
/*      */ 
/*      */   private synchronized long nextMessageId()
/*      */   {
/* 2386 */     return this.nextMessageId++;
/*      */   }
/*      */ 
/*      */   private void addUniqueFilterTable(FilterTable filterTable, List<FilterTable> list)
/*      */   {
/* 2397 */     synchronized (list) {
/* 2398 */       if (!list.contains(filterTable)) {
/* 2399 */         List newList = new LinkedList(list);
/* 2400 */         newList.add(filterTable);
/* 2401 */         list = newList;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class MessageAgentStatsLogger
/*      */     implements Runnable
/*      */   {
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */         try
/*      */         {
/* 2600 */           Thread.sleep(MessageAgent.intervalBetweenStatsLogging);
/* 2601 */           Log.info("MessageAgent Local Subscription Counters: last interval/total: Created " + (MessageAgent.localSubscriptionCreatedCount - MessageAgent.lastLocalSubscriptionCreatedCount) + "/" + MessageAgent.localSubscriptionCreatedCount + ", Removed " + (MessageAgent.localSubscriptionRemovedCount - MessageAgent.lastLocalSubscriptionRemovedCount) + "/" + MessageAgent.localSubscriptionRemovedCount);
/*      */ 
/* 2604 */           Log.info("MessageAgent Remote Subscription Counters: last interval/total: Created " + (MessageAgent.remoteSubscriptionCreatedCount - MessageAgent.lastRemoteSubscriptionCreatedCount) + "/" + MessageAgent.remoteSubscriptionCreatedCount + ", Removed " + (MessageAgent.remoteSubscriptionRemovedCount - MessageAgent.lastRemoteSubscriptionRemovedCount) + "/" + MessageAgent.remoteSubscriptionRemovedCount);
/*      */ 
/* 2607 */           Log.info("MessageAgent Filter Updates: last interval/total: Local " + (MessageAgent.localFilterUpdateCount - MessageAgent.lastLocalFilterUpdateCount) + "/" + MessageAgent.localFilterUpdateCount + ", Remote " + (MessageAgent.remoteFilterUpdateCount - MessageAgent.lastRemoteFilterUpdateCount) + "/" + MessageAgent.remoteFilterUpdateCount);
/*      */ 
/* 2610 */           MessageAgent.access$1602(MessageAgent.localSubscriptionCreatedCount);
/* 2611 */           MessageAgent.access$1802(MessageAgent.localSubscriptionRemovedCount);
/* 2612 */           MessageAgent.access$2002(MessageAgent.remoteSubscriptionCreatedCount);
/* 2613 */           MessageAgent.access$2202(MessageAgent.remoteSubscriptionRemovedCount);
/* 2614 */           MessageAgent.access$2402(MessageAgent.localFilterUpdateCount);
/* 2615 */           MessageAgent.access$2602(MessageAgent.remoteFilterUpdateCount);
/*      */ 
/* 2619 */           continue;
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 2618 */           Log.exception("MessageAgent.MessageAgentStatsLogger.run thread interrupted", e);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   class AgentConnectionThreadFactory
/*      */     implements ThreadFactory
/*      */   {
/* 2570 */     int threadCount = 1;
/*      */ 
/*      */     AgentConnectionThreadFactory()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Thread newThread(Runnable runnable)
/*      */     {
/* 2566 */       Thread thread = new Thread(runnable, "AgentConnection-" + this.threadCount++);
/* 2567 */       thread.setDaemon(true);
/* 2568 */       return thread;
/*      */     }
/*      */   }
/*      */ 
/*      */   class ResponseThreadFactory
/*      */     implements ThreadFactory
/*      */   {
/* 2557 */     int threadCount = 1;
/*      */ 
/*      */     ResponseThreadFactory()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Thread newThread(Runnable runnable)
/*      */     {
/* 2555 */       return new Thread(runnable, "MessageResponse-" + this.threadCount++);
/*      */     }
/*      */   }
/*      */ 
/*      */   class AsyncRPCResponse
/*      */     implements Runnable
/*      */   {
/*      */     ResponseMessage response;
/*      */     ResponseCallback callback;
/*      */ 
/*      */     AsyncRPCResponse(ResponseMessage m, ResponseCallback c)
/*      */     {
/* 2535 */       this.response = m;
/* 2536 */       this.callback = c;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try {
/* 2542 */         this.callback.handleResponse(this.response);
/*      */       }
/*      */       catch (Exception e) {
/* 2545 */         Log.exception("ResponseCallback threw exception:  response=" + this.response + " callback=" + this.callback, e);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class PendingRPC
/*      */   {
/*      */     long messageId;
/*      */     Set<Object> responders;
/*      */     ResponseCallback callback;
/*      */     Message response;
/*      */ 
/*      */     PendingRPC()
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public class DomainClient
/*      */   {
/*      */     DomainClient()
/*      */     {
/*      */     }
/*      */ 
/*      */     public String allocName(String type, String namePattern)
/*      */       throws IOException
/*      */     {
/* 2424 */       AllocNameMessage allocName = new AllocNameMessage(type, namePattern);
/* 2425 */       allocName.setMessageId(MessageAgent.this.nextMessageId());
/*      */ 
/* 2427 */       List list = new ArrayList(1);
/* 2428 */       list.add(MessageAgent.this.domainServerAgent);
/* 2429 */       MessageAgent.PendingRPC rpc = MessageAgent.this.setupInternalRPC(allocName, list);
/* 2430 */       MessageAgent.this.sendMessageToList(allocName, list);
/*      */ 
/* 2432 */       MessageAgent.this.waitInternalRPC(rpc);
/*      */ 
/* 2434 */       AllocNameResponseMessage response = (AllocNameResponseMessage)rpc.response;
/*      */ 
/* 2437 */       return response.getName();
/*      */     }
/*      */ 
/*      */     public void awaitPluginDependents(String pluginType, String pluginName)
/*      */     {
/* 2442 */       AwaitPluginDependentsMessage await = new AwaitPluginDependentsMessage(pluginType, pluginName);
/*      */ 
/* 2444 */       await.setMessageId(MessageAgent.this.nextMessageId());
/*      */ 
/* 2446 */       List list = new ArrayList(1);
/* 2447 */       list.add(MessageAgent.this.domainServerAgent);
/* 2448 */       MessageAgent.PendingRPC rpc = MessageAgent.this.setupInternalRPC(await, list);
/* 2449 */       MessageAgent.this.sendMessageToList(await, list);
/*      */ 
/* 2451 */       MessageAgent.this.waitInternalRPC(rpc);
/*      */     }
/*      */ 
/*      */     public void pluginAvailable(String pluginType, String pluginName)
/*      */     {
/* 2456 */       PluginAvailableMessage available = new PluginAvailableMessage(pluginType, pluginName);
/*      */ 
/* 2458 */       available.setMessageId(MessageAgent.this.nextMessageId());
/*      */ 
/* 2460 */       List list = new ArrayList(1);
/* 2461 */       list.add(MessageAgent.this.domainServerAgent);
/* 2462 */       MessageAgent.this.sendMessageToList(available, list);
/*      */     }
/*      */ 
/*      */     Message readMessage()
/*      */       throws IOException
/*      */     {
/* 2468 */       ByteBuffer readBuffer = ByteBuffer.allocate(4);
/* 2469 */       int nBytes = ChannelUtil.fillBuffer(readBuffer, MessageAgent.this.domainServerSocket);
/* 2470 */       if (nBytes == 0) {
/* 2471 */         throw new RuntimeException("domain server closed connection");
/*      */       }
/* 2473 */       if (nBytes < 4) {
/* 2474 */         throw new RuntimeException("domain server incomplete response");
/*      */       }
/* 2476 */       int msgLen = readBuffer.getInt();
/* 2477 */       if (msgLen < 0) {
/* 2478 */         throw new RuntimeException("domain server invalid response");
/*      */       }
/*      */ 
/* 2481 */       AOByteBuffer buffer = new AOByteBuffer(msgLen);
/* 2482 */       nBytes = ChannelUtil.fillBuffer(buffer.getNioBuf(), MessageAgent.this.domainServerSocket);
/* 2483 */       if (nBytes == 0) {
/* 2484 */         throw new RuntimeException("domain server closed connection");
/*      */       }
/* 2486 */       if (nBytes < 4) {
/* 2487 */         throw new RuntimeException("domain server invalid response, expecting " + msgLen + " got " + nBytes);
/*      */       }
/*      */ 
/* 2490 */       Message message = (Message)MarshallingRuntime.unmarshalObject(buffer);
/*      */ 
/* 2493 */       return message;
/*      */     }
/*      */   }
/*      */ 
/*      */   class RegisteredSubscription extends Subscription
/*      */   {
/*      */     LinkedList<MessageAgent.RemoteAgent> producers;
/*      */     MessageCallback callback;
/*      */ 
/*      */     RegisteredSubscription()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Object getAssociation()
/*      */     {
/* 2409 */       return this.callback;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class SelfMessageHandler
/*      */     implements Runnable
/*      */   {
/* 2371 */     List<Message> selfMessages = new LinkedList();
/*      */ 
/*      */     SelfMessageHandler()
/*      */     {
/* 2315 */       Thread thread = new Thread(this, "SelfMessage");
/* 2316 */       thread.setDaemon(true);
/* 2317 */       thread.start();
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */         try {
/* 2324 */           handle();
/*      */ 
/* 2328 */           continue;
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/* 2327 */           Log.exception("SelfMessage", ex);
/*      */         }
/*      */     }
/*      */ 
/*      */     void handle()
/*      */       throws InterruptedException
/*      */     {
/* 2335 */       synchronized (MessageAgent.this.selfRemoteAgent.outputBuf) {
/* 2336 */         while (MessageAgent.this.selfRemoteAgent.outputBuf.position() == 0) {
/* 2337 */           MessageAgent.this.selfRemoteAgent.outputBuf.wait();
/*      */         }
/* 2339 */         if (Log.loggingDebug) {
/* 2340 */           Log.debug("SelfMessageHandler.handle pos=" + MessageAgent.this.selfRemoteAgent.outputBuf.position());
/*      */         }
/* 2342 */         AOByteBuffer inputBuf = MessageAgent.this.selfRemoteAgent.outputBuf;
/* 2343 */         inputBuf.flip();
/* 2344 */         this.selfMessages.clear();
/* 2345 */         while (inputBuf.remaining() >= 4) {
/* 2346 */           int currentPos = inputBuf.position();
/* 2347 */           int messageLen = inputBuf.getInt();
/* 2348 */           if (inputBuf.remaining() < messageLen) {
/* 2349 */             inputBuf.position(currentPos);
/* 2350 */             break;
/*      */           }
/* 2352 */           Message message = (Message)MarshallingRuntime.unmarshalObject(inputBuf);
/*      */ 
/* 2355 */           message.remoteAgent = MessageAgent.this.selfRemoteAgent;
/* 2356 */           this.selfMessages.add(message);
/*      */ 
/* 2361 */           inputBuf.position(currentPos + 4 + messageLen);
/*      */         }
/* 2363 */         inputBuf.getNioBuf().compact();
/*      */       }
/*      */ 
/* 2366 */       for (Message message : this.selfMessages)
/* 2367 */         MessageAgent.this.handleSelfMessage(message);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class MessageMarshaller
/*      */     implements Runnable
/*      */   {
/*      */     MessageMarshaller()
/*      */     {
/* 2266 */       new Thread(this, "MessageMarshaller").start();
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */         try {
/* 2273 */           marshall();
/*      */ 
/* 2277 */           continue;
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/* 2276 */           Log.exception("MessageMarshaller", ex);
/*      */         }
/*      */     }
/*      */ 
/*      */     void marshall()
/*      */       throws InterruptedException
/*      */     {
/* 2286 */       SquareQueue.SubQueue raq = MessageAgent.this.remoteAgentOutput.remove();
/*      */       try {
/* 2288 */         if (raq.next()) {
/* 2289 */           Message message = (Message)raq.getHeadValue();
/* 2290 */           MessageAgent.RemoteAgent remoteAgent = (MessageAgent.RemoteAgent)raq.getKey();
/* 2291 */           if (remoteAgent == MessageAgent.this.selfRemoteAgent) {
/* 2292 */             message.remoteAgent = remoteAgent;
/* 2293 */             MessageAgent.this.handleSelfMessage(message);
/*      */           }
/*      */           else {
/* 2296 */             synchronized (remoteAgent.outputBuf)
/*      */             {
/* 2298 */               if (remoteAgent.socket != null)
/* 2299 */                 Message.toBytes(message, remoteAgent.outputBuf);
/*      */             }
/* 2301 */             MessageAgent.this.messageIO.outputReady();
/*      */           }
/*      */         }
/*      */       }
/*      */       finally {
/* 2306 */         MessageAgent.this.remoteAgentOutput.requeue(raq);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class AgentConnector
/*      */     implements Runnable
/*      */   {
/*      */     NewAgentMessage message;
/* 2236 */     SocketChannel agentSocket = null;
/*      */ 
/*      */     AgentConnector(NewAgentMessage message)
/*      */     {
/* 2175 */       this.message = message;
/*      */     }
/*      */ 
/*      */     public void run() {
/*      */       try {
/* 2180 */         connect();
/*      */       } catch (Exception ex) {
/* 2182 */         Log.exception("AgentConnector", ex);
/*      */         try { if (this.agentSocket != null) this.agentSocket.close(); 
/*      */         } catch (Exception ignore)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     void connect() throws IOException, AORuntimeException
/*      */     {
/*      */       while (true)
/*      */         try {
/* 2193 */           this.agentSocket = SocketChannel.open(new InetSocketAddress(this.message.agentIP, this.message.agentPort));
/*      */         }
/*      */         catch (ConnectException ex)
/*      */         {
/* 2198 */           Log.info("Could not connect to agent '" + this.message.agentName + "' at " + this.message.agentIP + ":" + this.message.agentPort + " " + ex);
/*      */           try
/*      */           {
/* 2201 */             Thread.sleep(1000L);
/*      */           }
/*      */           catch (Exception ignore) {
/*      */           }
/*      */         }
/* 2206 */       this.agentSocket.configureBlocking(false);
/* 2207 */       this.agentSocket.socket().setTcpNoDelay(true);
/* 2208 */       if (Log.loggingDebug) {
/* 2209 */         Log.debug("MessageAgent: connected to agent " + this.agentSocket);
/*      */       }
/*      */ 
/* 2212 */       AgentStateMessage agentState = new AgentStateMessage(MessageAgent.this.agentId, MessageAgent.this.agentName, ":same", MessageAgent.this.agentPort, MessageAgent.this.domainFlags);
/*      */ 
/* 2214 */       AOByteBuffer buffer = new AOByteBuffer(64);
/* 2215 */       Message.toBytes(agentState, buffer);
/*      */ 
/* 2217 */       buffer.flip();
/* 2218 */       if (!ChannelUtil.writeBuffer(buffer, this.agentSocket)) {
/* 2219 */         throw new RuntimeException("could not write to agent");
/*      */       }
/*      */ 
/* 2222 */       MessageAgent.RemoteAgent remoteAgent = MessageAgent.this.waitForAgent(this.agentSocket);
/* 2223 */       if (remoteAgent == null) {
/* 2224 */         this.agentSocket.close();
/* 2225 */         return;
/*      */       }
/*      */ 
/* 2228 */       MessageAgent.this.sendAdvertisements(remoteAgent);
/*      */ 
/* 2230 */       if (Log.loggingDebug)
/* 2231 */         Log.debug("connect: Accepted connection from " + this.message.agentName);
/* 2232 */       MessageAgent.this.messageIO.addAgent(remoteAgent);
/*      */     }
/*      */   }
/*      */ 
/*      */   class RemoteSubscription extends Subscription
/*      */   {
/*      */     MessageAgent.RemoteAgent remoteAgent;
/*      */ 
/*      */     RemoteSubscription()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Object getAssociation()
/*      */     {
/* 1729 */       return this.remoteAgent;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected class RemoteAgent extends AgentInfo
/*      */   {
/* 1718 */     Map<Long, MessageAgent.RemoteSubscription> remoteSubs = new HashMap();
/*      */ 
/* 1720 */     Collection<MessageType> remoteAdverts = new HashSet();
/*      */     List<Message> outgoingQueue;
/*      */     static final int HAVE_ADVERTISEMENTS = 256;
/*      */ 
/*      */     protected RemoteAgent()
/*      */     {
/*      */     }
/*      */ 
/*      */     boolean isSelf()
/*      */     {
/* 1662 */       return this == MessageAgent.this.selfRemoteAgent;
/*      */     }
/*      */ 
/*      */     void addRemoteSubscription(MessageAgent.RemoteSubscription remoteSub)
/*      */     {
/* 1667 */       synchronized (this.remoteSubs) {
/* 1668 */         if (this.remoteSubs.get(Long.valueOf(remoteSub.subId)) != null) {
/* 1669 */           Log.error("RemoteAgent " + this.agentName + ": Duplicate subId " + remoteSub.subId);
/*      */ 
/* 1671 */           return;
/*      */         }
/* 1673 */         this.remoteSubs.put(Long.valueOf(remoteSub.subId), remoteSub);
/*      */       }
/*      */     }
/*      */ 
/*      */     MessageAgent.RemoteSubscription removeRemoteSubscription(Long subId)
/*      */     {
/* 1679 */       synchronized (this.remoteSubs) {
/* 1680 */         return (MessageAgent.RemoteSubscription)this.remoteSubs.remove(subId);
/*      */       }
/*      */     }
/*      */ 
/*      */     MessageAgent.RemoteSubscription getRemoteSubscription(Long subId)
/*      */     {
/* 1686 */       synchronized (this.remoteSubs) {
/* 1687 */         return (MessageAgent.RemoteSubscription)this.remoteSubs.get(subId);
/*      */       }
/*      */     }
/*      */ 
/*      */     Collection<MessageType> getAdvertisements()
/*      */     {
/* 1693 */       return this.remoteAdverts;
/*      */     }
/*      */ 
/*      */     void setAdvertisements(Collection<MessageType> adverts)
/*      */     {
/* 1698 */       this.remoteAdverts.clear();
/* 1699 */       this.remoteAdverts.addAll(adverts);
/*      */     }
/*      */ 
/*      */     int getFlags()
/*      */     {
/* 1704 */       return this.flags;
/*      */     }
/*      */ 
/*      */     boolean hasFlag(int flag)
/*      */     {
/* 1709 */       return (this.flags & flag) != 0;
/*      */     }
/*      */ 
/*      */     void setFlag(int flag)
/*      */     {
/* 1714 */       this.flags |= flag;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class NewConnectionHandler
/*      */     implements Runnable
/*      */   {
/*      */     SocketChannel agentSocket;
/*      */ 
/*      */     public NewConnectionHandler(SocketChannel socket)
/*      */       throws IOException
/*      */     {
/* 1550 */       this.agentSocket = socket;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try {
/* 1556 */         MessageAgent.RemoteAgent remoteAgent = MessageAgent.this.waitForAgent(this.agentSocket);
/* 1557 */         if (remoteAgent == null) {
/* 1558 */           this.agentSocket.close();
/*      */         }
/*      */         else
/*      */         {
/* 1564 */           AgentStateMessage agentState = new AgentStateMessage(MessageAgent.this.agentId, MessageAgent.this.agentName, ":same", MessageAgent.this.agentPort, MessageAgent.this.domainFlags);
/*      */ 
/* 1566 */           Message.toBytes(agentState, remoteAgent.outputBuf);
/*      */ 
/* 1568 */           MessageAgent.this.sendAdvertisements(remoteAgent);
/*      */ 
/* 1570 */           if (Log.loggingDebug) {
/* 1571 */             Log.debug("received connect: Accepting connection from " + remoteAgent.agentName);
/*      */           }
/* 1573 */           MessageAgent.this.messageIO.addAgent(remoteAgent);
/*      */         }
/*      */       }
/*      */       catch (Exception ex) {
/* 1577 */         Log.exception("NewConnectionHandler", ex);
/*      */         try { this.agentSocket.close();
/*      */         }
/*      */         catch (Exception ignore)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public class BlockingRPCState
/*      */     implements ResponseCallback
/*      */   {
/*      */     private int responseCount;
/*      */     private ResponseCallback callback;
/*      */ 
/*      */     public BlockingRPCState(ResponseCallback callback)
/*      */     {
/*   90 */       this.callback = callback;
/*   91 */       this.responseCount = 0;
/*      */     }
/*      */ 
/*      */     public void handleResponse(ResponseMessage response) {
/*   95 */       this.callback.handleResponse(response);
/*   96 */       synchronized (this) {
/*   97 */         this.responseCount += 1;
/*   98 */         notifyAll();
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getResponseCount() {
/*  103 */       synchronized (this) {
/*  104 */         return this.responseCount;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageAgent
 * JD-Core Version:    0.6.0
 */