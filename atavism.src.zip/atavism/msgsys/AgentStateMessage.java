/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class AgentStateMessage extends Message
/*    */ {
/*    */   int agentId;
/*    */   String agentName;
/*    */   String agentIP;
/*    */   int agentPort;
/*    */   int domainFlags;
/* 36 */   List<MessageType> advertisements = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AgentStateMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AgentStateMessage(int agentId, String agentName, String agentIP, int agentPort, int domainFlags)
/*    */   {
/* 13 */     this.msgType = MessageTypes.MSG_TYPE_AGENT_STATE;
/* 14 */     this.agentId = agentId;
/* 15 */     this.agentName = agentName;
/* 16 */     this.agentIP = agentIP;
/* 17 */     this.agentPort = agentPort;
/* 18 */     this.domainFlags = domainFlags;
/*    */   }
/*    */ 
/*    */   public void setAdvertisements(List<MessageType> list)
/*    */   {
/* 23 */     this.advertisements = list;
/*    */   }
/*    */ 
/*    */   public List<MessageType> getAdvertisements()
/*    */   {
/* 28 */     return this.advertisements;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.AgentStateMessage
 * JD-Core Version:    0.6.0
 */