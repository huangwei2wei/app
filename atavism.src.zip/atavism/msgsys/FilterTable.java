package atavism.msgsys;

import java.util.List;
import java.util.Set;

public abstract class FilterTable
{
  public abstract void addFilter(Subscription paramSubscription, Object paramObject);

  public abstract void removeFilter(Subscription paramSubscription, Object paramObject);

  public abstract int match(Message paramMessage, Set<Object> paramSet, List<Subscription> paramList);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.FilterTable
 * JD-Core Version:    0.6.0
 */