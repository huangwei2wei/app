/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class MultipleRecipientsException extends AORuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public MultipleRecipientsException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MultipleRecipientsException(String msg)
/*    */   {
/* 14 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MultipleRecipientsException(String msg, Throwable cause) {
/* 18 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public MultipleRecipientsException(Throwable cause) {
/* 22 */     super(cause);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MultipleRecipientsException
 * JD-Core Version:    0.6.0
 */