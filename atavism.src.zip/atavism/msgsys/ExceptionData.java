/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ExceptionData
/*    */ {
/*    */   private String agentName;
/*    */   private String exceptionClass;
/*    */   private String detailMessage;
/*    */   private ExceptionData cause;
/*    */   private ArrayList<StackFrame> stackTrace;
/*    */ 
/*    */   public ExceptionData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ExceptionData(Throwable ex)
/*    */   {
/* 17 */     this.agentName = RPCException.myAgentName;
/* 18 */     this.exceptionClass = ex.getClass().getName();
/* 19 */     this.detailMessage = ex.getMessage();
/* 20 */     StackTraceElement[] exFrames = ex.getStackTrace();
/* 21 */     this.stackTrace = new ArrayList(exFrames.length);
/* 22 */     for (StackTraceElement frame : exFrames) {
/* 23 */       this.stackTrace.add(new StackFrame(frame));
/*    */     }
/* 25 */     if (ex.getCause() != null)
/* 26 */       this.cause = new ExceptionData(ex.getCause());
/*    */   }
/*    */ 
/*    */   public String getExceptionClassName()
/*    */   {
/* 31 */     return this.exceptionClass;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 36 */     return this.detailMessage;
/*    */   }
/*    */ 
/*    */   public ExceptionData getCause()
/*    */   {
/* 41 */     return this.cause;
/*    */   }
/*    */ 
/*    */   List<StackFrame> getStackTrace()
/*    */   {
/* 46 */     return this.stackTrace;
/*    */   }
/*    */ 
/*    */   public String getAgentName()
/*    */   {
/* 51 */     return this.agentName;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.ExceptionData
 * JD-Core Version:    0.6.0
 */