/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class BooleanResponseMessage extends ResponseMessage
/*    */ {
/*    */   private Boolean rv;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public BooleanResponseMessage()
/*    */   {
/*  6 */     super(MessageTypes.MSG_TYPE_BOOLEAN_RESPONSE);
/*    */   }
/*    */ 
/*    */   public BooleanResponseMessage(Message msg, Boolean rv) {
/* 10 */     super(msg);
/* 11 */     setBooleanVal(rv);
/*    */   }
/*    */ 
/*    */   public void setBooleanVal(Boolean rv) {
/* 15 */     this.rv = rv;
/*    */   }
/*    */ 
/*    */   public Boolean getBooleanVal() {
/* 19 */     return this.rv;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return "[BooleanResponseMessage: " + super.toString() + ", value " + this.rv + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.BooleanResponseMessage
 * JD-Core Version:    0.6.0
 */