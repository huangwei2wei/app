/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class PluginAvailableMessage extends Message
/*    */ {
/*    */   private String pluginType;
/*    */   private String pluginName;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PluginAvailableMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PluginAvailableMessage(String pluginType, String pluginName)
/*    */   {
/* 11 */     super(MessageTypes.MSG_TYPE_PLUGIN_AVAILABLE);
/* 12 */     this.pluginType = pluginType;
/* 13 */     this.pluginName = pluginName;
/*    */   }
/*    */ 
/*    */   public String getPluginType() {
/* 17 */     return this.pluginType;
/*    */   }
/*    */ 
/*    */   public String getPluginName() {
/* 21 */     return this.pluginName;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.PluginAvailableMessage
 * JD-Core Version:    0.6.0
 */