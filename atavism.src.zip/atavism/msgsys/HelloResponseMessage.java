/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class HelloResponseMessage extends Message
/*    */ {
/*    */   private int agentId;
/*    */   private long startTime;
/*    */   private List<String> agentNames;
/*    */   private String domainKey;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public HelloResponseMessage()
/*    */   {
/*  8 */     this.msgType = MessageTypes.MSG_TYPE_HELLO_RESPONSE;
/*    */   }
/*    */ 
/*    */   HelloResponseMessage(int id, long time, List<String> names, String key)
/*    */   {
/* 13 */     this.msgType = MessageTypes.MSG_TYPE_HELLO_RESPONSE;
/* 14 */     this.agentId = id;
/* 15 */     this.startTime = time;
/* 16 */     this.agentNames = names;
/* 17 */     this.domainKey = key;
/*    */   }
/*    */ 
/*    */   int getAgentId()
/*    */   {
/* 22 */     return this.agentId;
/*    */   }
/*    */ 
/*    */   long getDomainStartTime()
/*    */   {
/* 27 */     return this.startTime;
/*    */   }
/*    */ 
/*    */   List<String> getAgentNames()
/*    */   {
/* 32 */     return this.agentNames;
/*    */   }
/*    */ 
/*    */   String getDomainKey()
/*    */   {
/* 37 */     return this.domainKey;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.HelloResponseMessage
 * JD-Core Version:    0.6.0
 */