/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class AllocNameMessage extends Message
/*    */ {
/*    */   private String type;
/*    */   private String agentName;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AllocNameMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AllocNameMessage(String type, String agentName)
/*    */   {
/* 11 */     this.msgType = MessageTypes.MSG_TYPE_ALLOC_NAME;
/* 12 */     this.type = type;
/* 13 */     this.agentName = agentName;
/*    */   }
/*    */ 
/*    */   public String getType()
/*    */   {
/* 18 */     return this.type;
/*    */   }
/*    */ 
/*    */   public String getAgentName()
/*    */   {
/* 23 */     return this.agentName;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.AllocNameMessage
 * JD-Core Version:    0.6.0
 */