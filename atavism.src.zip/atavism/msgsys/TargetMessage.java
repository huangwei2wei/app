/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class TargetMessage extends Message
/*    */ {
/*    */   protected OID target;
/*    */   protected OID subject;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public TargetMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TargetMessage(MessageType msgType)
/*    */   {
/* 17 */     super(msgType);
/*    */   }
/*    */ 
/*    */   public TargetMessage(MessageType msgType, OID target, OID subject)
/*    */   {
/* 23 */     super(msgType);
/* 24 */     this.target = target;
/* 25 */     this.subject = subject;
/*    */   }
/*    */ 
/*    */   public TargetMessage(MessageType msgType, OID target)
/*    */   {
/* 31 */     super(msgType);
/* 32 */     this.target = target;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 37 */     return "[" + getClass().getName() + " target=" + this.target + " subject=" + this.subject + "]";
/*    */   }
/*    */ 
/*    */   public OID getTarget()
/*    */   {
/* 45 */     return this.target;
/*    */   }
/*    */ 
/*    */   public void setTarget(OID playerOid)
/*    */   {
/* 52 */     this.target = playerOid;
/*    */   }
/*    */ 
/*    */   public OID getSubject()
/*    */   {
/* 60 */     return this.subject;
/*    */   }
/*    */ 
/*    */   public void setSubject(OID subject)
/*    */   {
/* 67 */     this.subject = subject;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.TargetMessage
 * JD-Core Version:    0.6.0
 */