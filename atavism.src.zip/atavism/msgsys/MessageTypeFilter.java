/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class MessageTypeFilter extends Filter
/*    */   implements IMessageTypeFilter
/*    */ {
/*    */   private Set<MessageType> messageTypes;
/*    */ 
/*    */   public MessageTypeFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MessageTypeFilter(MessageType type)
/*    */   {
/* 18 */     addType(type);
/*    */   }
/*    */ 
/*    */   public MessageTypeFilter(Collection<MessageType> types)
/*    */   {
/* 25 */     this.messageTypes = new HashSet(types.size());
/* 26 */     this.messageTypes.addAll(types);
/*    */   }
/*    */ 
/*    */   public void addType(MessageType type)
/*    */   {
/* 33 */     if (this.messageTypes == null)
/* 34 */       this.messageTypes = new HashSet();
/* 35 */     this.messageTypes.add(type);
/*    */   }
/*    */ 
/*    */   public void setTypes(Collection<MessageType> types)
/*    */   {
/* 42 */     this.messageTypes = new HashSet();
/* 43 */     this.messageTypes.addAll(types);
/*    */   }
/*    */ 
/*    */   public Collection<MessageType> getMessageTypes()
/*    */   {
/* 50 */     return this.messageTypes;
/*    */   }
/*    */ 
/*    */   public boolean matchMessageType(Collection<MessageType> types)
/*    */   {
/* 58 */     for (MessageType tt : types) {
/* 59 */       if (this.messageTypes.contains(tt)) {
/* 60 */         return true;
/*    */       }
/*    */     }
/* 63 */     return this.messageTypes.contains(MessageTypes.MSG_TYPE_ALL_TYPES);
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message message)
/*    */   {
/* 71 */     return true;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 75 */     return "[MessageTypeFilter " + toStringInternal() + "]";
/*    */   }
/*    */ 
/*    */   protected String toStringInternal() {
/* 79 */     String result = "types=";
/* 80 */     if (this.messageTypes == null)
/* 81 */       return result + this.messageTypes;
/* 82 */     for (MessageType type : this.messageTypes)
/* 83 */       result = result + type.getMsgTypeString() + ",";
/* 84 */     return result;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageTypeFilter
 * JD-Core Version:    0.6.0
 */