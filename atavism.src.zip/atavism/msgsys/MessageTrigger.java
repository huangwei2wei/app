/*    */ package atavism.msgsys;
/*    */ 
/*    */ public abstract class MessageTrigger
/*    */ {
/*    */   public abstract void setFilter(IFilter paramIFilter);
/*    */ 
/*    */   public boolean match(Message message)
/*    */   {
/* 34 */     return true;
/*    */   }
/*    */ 
/*    */   public abstract void trigger(Message paramMessage, IFilter paramIFilter, MessageAgent paramMessageAgent);
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageTrigger
 * JD-Core Version:    0.6.0
 */