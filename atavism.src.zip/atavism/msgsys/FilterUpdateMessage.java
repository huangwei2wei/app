/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class FilterUpdateMessage extends Message
/*    */ {
/*    */   long subId;
/*    */   FilterUpdate filterUpdate;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public FilterUpdateMessage()
/*    */   {
/*  7 */     this.msgType = MessageTypes.MSG_TYPE_FILTER_UPDATE;
/*    */   }
/*    */ 
/*    */   FilterUpdateMessage(long subId, FilterUpdate filterUpdate)
/*    */   {
/* 12 */     this.msgType = MessageTypes.MSG_TYPE_FILTER_UPDATE;
/* 13 */     this.subId = subId;
/* 14 */     this.filterUpdate = filterUpdate;
/*    */   }
/*    */ 
/*    */   long getSubId()
/*    */   {
/* 19 */     return this.subId;
/*    */   }
/*    */ 
/*    */   FilterUpdate getFilterUpdate()
/*    */   {
/* 24 */     return this.filterUpdate;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.FilterUpdateMessage
 * JD-Core Version:    0.6.0
 */