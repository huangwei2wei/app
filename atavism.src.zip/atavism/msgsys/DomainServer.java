/*     */ package atavism.msgsys;
/*     */ 
/*     */ import atavism.server.marshalling.MarshallingRuntime;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ChannelUtil;
/*     */ import atavism.server.network.TcpAcceptCallback;
/*     */ import atavism.server.network.TcpServer;
/*     */ import atavism.server.util.Base64;
/*     */ import atavism.server.util.FileUtil;
/*     */ import atavism.server.util.InitLogAndPid;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.SecureTokenUtil;
/*     */ import atavism.server.util.ServerVersion;
/*     */ import gnu.getopt.Getopt;
/*     */ import gnu.getopt.LongOpt;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.RuntimeMXBean;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.crypto.SecretKey;
/*     */ 
/*     */ public class DomainServer
/*     */   implements TcpAcceptCallback, MessageIO.Callback
/*     */ {
/*     */   public static final int DEFAULT_PORT = 20374;
/*     */   static DomainServer domainServer;
/*     */   private int listenPort;
/*     */   private TcpServer listener;
/* 840 */   private List<String> agentNames = new LinkedList();
/* 841 */   private ExecutorService threadPool = Executors.newCachedThreadPool(new DomainThreadFactory());
/*     */   private PluginStartGroup pluginStartGroup;
/*     */   private String worldName;
/*     */   private long domainStartTime;
/*     */   private static String encodedDomainKey;
/* 849 */   private int nextAgentId = 1;
/*     */ 
/* 851 */   private Map<SocketChannel, AgentInfo> agents = new HashMap();
/*     */ 
/* 854 */   private Map<String, Map<String, Integer>> nameTypes = new HashMap();
/*     */   private MessageIO messageIO;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  52 */     String worldName = System.getProperty("atavism.worldname");
/*  53 */     String hostName = determineHostName();
/*  54 */     Properties properties = InitLogAndPid.initLogAndPid(args, worldName, hostName);
/*     */ 
/*  56 */     System.err.println("Atavism server version " + ServerVersion.getVersionString());
/*     */ 
/*  59 */     List agentNames = new LinkedList();
/*     */ 
/*  61 */     LongOpt[] longopts = new LongOpt[2];
/*  62 */     longopts[0] = new LongOpt("pid", 1, null, 2);
/*  63 */     longopts[1] = new LongOpt("port", 1, null, 3);
/*  64 */     Getopt opt = new Getopt("DomainServer", args, "a:m:t:p:P:", longopts);
/*     */ 
/*  66 */     int port = 20374;
/*     */ 
/*  68 */     String portStr = properties.getProperty("atavism.msgsvr_port");
/*  69 */     if (portStr != null) {
/*  70 */       port = Integer.parseInt(portStr);
/*     */     }
/*  72 */     PluginStartGroup pluginStartGroup = new PluginStartGroup();
/*     */ 
/*  74 */     boolean pluginsDefined = populatePluginStartGroup(pluginStartGroup, properties);
/*     */     int c;
/*  76 */     while ((c = opt.getopt()) != -1) {
/*  77 */       switch (c) {
/*     */       case 97:
/*  79 */         agentNames.add(opt.getOptarg());
/*  80 */         break;
/*     */       case 109:
/*     */       case 116:
/*  84 */         opt.getOptarg();
/*  85 */         break;
/*     */       case 112:
/*  87 */         if (pluginsDefined) {
/*     */           break;
/*     */         }
/*  90 */         String pluginSpec = opt.getOptarg();
/*  91 */         String[] pluginDef = pluginSpec.split(",", 2);
/*  92 */         if (pluginDef.length != 2) {
/*  93 */           System.err.println("Invalid plugin spec format: " + pluginSpec);
/*  94 */           Log.error("Invalid plugin spec format: " + pluginSpec);
/*  95 */           System.exit(1);
/*     */         }
/*  97 */         int expected = Integer.parseInt(pluginDef[1]);
/*  98 */         pluginStartGroup.add(pluginDef[0], expected);
/*  99 */         break;
/*     */       case 63:
/* 102 */         System.exit(1);
/* 103 */         break;
/*     */       case 80:
/* 105 */         break;
/*     */       case 2:
/* 108 */         opt.getOptarg();
/* 109 */         break;
/*     */       case 3:
/* 112 */         String arg = opt.getOptarg();
/* 113 */         port = Integer.parseInt(arg);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 121 */     String svrName = System.getProperty("atavism.loggername");
/* 122 */     String runDir = System.getProperty("atavism.rundir");
/*     */ 
/* 125 */     if ((System.getProperty("os.name").contains("Windows")) && (svrName != null) && (runDir != null))
/*     */     {
/* 127 */       saveProcessID(svrName, runDir);
/*     */     }
/*     */ 
/* 132 */     domainServer = new DomainServer(port);
/* 133 */     domainServer.setAgentNames(agentNames);
/* 134 */     domainServer.setWorldName(worldName);
/* 135 */     domainServer.start();
/*     */ 
/* 137 */     pluginStartGroup.prepareDependencies(properties, worldName);
/* 138 */     domainServer.addPluginStartGroup(pluginStartGroup);
/* 139 */     pluginStartGroup.pluginAvailable("Domain", "Domain");
/*     */ 
/* 141 */     String timeoutStr = properties.getProperty("atavism.startup_timeout");
/* 142 */     int timeout = 120;
/* 143 */     if (timeoutStr != null) {
/* 144 */       timeout = Integer.parseInt(timeoutStr);
/*     */     }
/*     */ 
/* 147 */     ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
/* 148 */     ScheduledFuture timeoutHandler = scheduler.schedule(new TimeoutRunnable(timeout), timeout, TimeUnit.SECONDS);
/*     */ 
/* 152 */     SecretKey domainKey = SecureTokenUtil.generateDomainKey();
/*     */ 
/* 154 */     long keyId = new Random().nextLong();
/* 155 */     encodedDomainKey = Base64.encodeBytes(SecureTokenUtil.encodeDomainKey(keyId, domainKey));
/* 156 */     Log.debug("generated domain key: " + encodedDomainKey);
/*     */     try
/*     */     {
/* 159 */       pluginStartGroup.awaitDependency("Domain");
/* 160 */       timeoutHandler.cancel(false);
/* 161 */       String availableMessage = properties.getProperty("atavism.world_available_message");
/*     */ 
/* 163 */       String availableFile = properties.getProperty("atavism.world_available_file");
/*     */ 
/* 165 */       if (availableFile != null)
/* 166 */         touchFile(FileUtil.expandFileName(availableFile));
/* 167 */       if (availableMessage != null)
/* 168 */         System.err.println("\n" + availableMessage);
/*     */       while (true)
/* 170 */         Thread.sleep(10000000L);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 174 */       Log.exception("DomainServer.main", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean populatePluginStartGroup(PluginStartGroup pluginStartGroup, Properties properties)
/*     */   {
/* 186 */     String pluginList = properties.getProperty("atavism.plugin_types");
/* 187 */     if (pluginList == null)
/*     */     {
/* 189 */       Log.warn("Missing plugin list in properties file");
/* 190 */       return false;
/*     */     }
/* 192 */     String[] pluginEntries = pluginList.split(",");
/* 193 */     for (int i = 0; i < pluginEntries.length; i++) {
/* 194 */       String pluginEntry = pluginEntries[i].trim();
/* 195 */       String pluginDef = pluginEntry;
/* 196 */       int expected = 1;
/* 197 */       int index = pluginEntry.indexOf(':');
/* 198 */       if (index >= 0)
/*     */       {
/* 200 */         pluginDef = pluginEntry.substring(0, index);
/*     */         try {
/* 202 */           expected = Integer.parseInt(pluginEntry.substring(index + 1));
/*     */         } catch (Exception e) {
/* 204 */           Log.error("Failed to parse plugin entry: " + pluginEntry);
/*     */         }
/*     */       }
/*     */ 
/* 208 */       Log.debug("Adding plugin entry for " + pluginDef);
/* 209 */       pluginStartGroup.add(pluginDef, expected);
/*     */     }
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */   public DomainServer(int port)
/*     */   {
/* 218 */     MessageTypes.initializeCatalog();
/* 219 */     this.listenPort = port;
/* 220 */     this.messageIO = new MessageIO(this);
/*     */   }
/*     */ 
/*     */   public void setAgentNames(List<String> names)
/*     */   {
/* 225 */     this.agentNames = new LinkedList(names);
/*     */   }
/*     */ 
/*     */   public List<String> getAgentNames()
/*     */   {
/* 230 */     return this.agentNames;
/*     */   }
/*     */ 
/*     */   public String getWorldName()
/*     */   {
/* 235 */     return this.worldName;
/*     */   }
/*     */ 
/*     */   public void setWorldName(String worldName)
/*     */   {
/* 240 */     this.worldName = worldName;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*     */     try {
/* 246 */       this.domainStartTime = System.currentTimeMillis();
/* 247 */       this.messageIO.start();
/* 248 */       this.listener = new TcpServer(this.listenPort);
/* 249 */       this.listener.registerAcceptCallback(this);
/* 250 */       this.listener.start();
/*     */     } catch (Exception e) {
/* 252 */       Log.exception("DomainServer listener", e);
/* 253 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onTcpAccept(SocketChannel agentSocket) {
/* 258 */     Log.debug("Got connection: " + agentSocket);
/*     */     try {
/* 260 */       this.threadPool.execute(new AgentHandler(agentSocket));
/*     */     } catch (IOException ex) {
/* 262 */       Log.exception("DomainServer listener", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   void handleAllocName(AllocNameMessage allocName, SocketChannel agentSocket)
/*     */     throws IOException
/*     */   {
/* 386 */     if (allocName.getMsgType() != MessageTypes.MSG_TYPE_ALLOC_NAME) {
/* 387 */       Log.error("DomainServer: invalid alloc name message");
/* 388 */       return;
/*     */     }
/*     */ 
/* 391 */     String agentName = allocName(allocName.getType(), allocName.getAgentName());
/*     */ 
/* 394 */     AOByteBuffer buffer = new AOByteBuffer(1024);
/* 395 */     AllocNameResponseMessage allocNameResponse = new AllocNameResponseMessage(allocName, agentName);
/*     */ 
/* 397 */     Message.toBytes(allocNameResponse, buffer);
/* 398 */     buffer.flip();
/*     */ 
/* 400 */     if (!ChannelUtil.writeBuffer(buffer, agentSocket))
/* 401 */       throw new RuntimeException("could not write alloc name response");
/*     */   }
/*     */ 
/*     */   void handleAwaitPluginDependents(AwaitPluginDependentsMessage await, SocketChannel agentSocket)
/*     */     throws IOException
/*     */   {
/* 410 */     if (await.getMsgType() != MessageTypes.MSG_TYPE_AWAIT_PLUGIN_DEPENDENTS) {
/* 411 */       Log.error("DomainServer: invalid await message");
/* 412 */       return;
/*     */     }
/*     */ 
/* 415 */     if (this.pluginStartGroup == null) {
/* 416 */       Log.error("DomainServer: no start group defined for plugin type=" + await.getPluginType() + " name=" + await.getPluginName());
/*     */ 
/* 419 */       return;
/*     */     }
/*     */ 
/* 423 */     new Thread(new PluginDependencyWatcher(await, agentSocket)).start();
/*     */   }
/*     */ 
/*     */   void handlePluginAvailable(PluginAvailableMessage available, SocketChannel agentSocket)
/*     */     throws IOException
/*     */   {
/* 431 */     if (available.getMsgType() != MessageTypes.MSG_TYPE_PLUGIN_AVAILABLE) {
/* 432 */       Log.error("DomainServer: invalid available message");
/* 433 */       return;
/*     */     }
/*     */ 
/* 436 */     if (this.pluginStartGroup == null) {
/* 437 */       Log.error("DomainServer: no start group defined for plugin type=" + available.getPluginType() + " name=" + available.getPluginName());
/*     */ 
/* 440 */       return;
/*     */     }
/*     */ 
/* 443 */     this.pluginStartGroup.pluginAvailable(available.getPluginType(), available.getPluginName());
/*     */   }
/*     */ 
/*     */   private int getNextAgentId()
/*     */   {
/* 451 */     return this.nextAgentId++;
/*     */   }
/*     */ 
/*     */   private synchronized void addNewAgent(int agentId, SocketChannel socket, String agentName, String agentIP, int agentPort, int flags)
/*     */   {
/* 457 */     if (agentIP.equals(":same")) {
/* 458 */       InetAddress agentAddress = socket.socket().getInetAddress();
/* 459 */       agentIP = agentAddress.getHostAddress();
/*     */     }
/*     */ 
/* 462 */     Log.info("New agent id=" + agentId + " name=" + agentName + " address=" + agentIP + ":" + agentPort + " flags=" + flags);
/*     */ 
/* 464 */     AgentInfo agentInfo = new AgentInfo();
/* 465 */     agentInfo.agentId = agentId;
/* 466 */     agentInfo.flags = flags;
/* 467 */     agentInfo.socket = socket;
/* 468 */     agentInfo.agentName = agentName;
/* 469 */     agentInfo.agentIP = agentIP;
/* 470 */     agentInfo.agentPort = agentPort;
/* 471 */     agentInfo.outputBuf = new AOByteBuffer(1024);
/* 472 */     agentInfo.inputBuf = new AOByteBuffer(1024);
/* 473 */     this.agents.put(socket, agentInfo);
/*     */ 
/* 475 */     NewAgentMessage newAgentMessage = new NewAgentMessage(agentId, agentName, agentIP, agentPort, flags);
/*     */ 
/* 477 */     for (Map.Entry entry : this.agents.entrySet()) {
/* 478 */       if (entry.getKey() == socket)
/*     */       {
/*     */         continue;
/*     */       }
/* 482 */       synchronized (((AgentInfo)entry.getValue()).outputBuf) {
/* 483 */         Message.toBytes(newAgentMessage, ((AgentInfo)entry.getValue()).outputBuf);
/*     */       }
/*     */ 
/* 487 */       NewAgentMessage otherAgentMessage = new NewAgentMessage(((AgentInfo)entry.getValue()).agentId, ((AgentInfo)entry.getValue()).agentName, ((AgentInfo)entry.getValue()).agentIP, ((AgentInfo)entry.getValue()).agentPort, ((AgentInfo)entry.getValue()).flags);
/*     */ 
/* 491 */       synchronized (agentInfo.outputBuf) {
/* 492 */         Message.toBytes(otherAgentMessage, agentInfo.outputBuf);
/*     */       }
/*     */     }
/*     */ 
/* 496 */     this.messageIO.addAgent(agentInfo);
/* 497 */     this.messageIO.outputReady();
/*     */   }
/*     */ 
/*     */   public void handleMessageData(int length, AOByteBuffer messageData, AgentInfo agentInfo)
/*     */   {
/* 503 */     if ((length == -1) || (messageData == null)) {
/* 504 */       if ((agentInfo.flags & 0x1) != 0) {
/* 505 */         Log.info("Lost connection to '" + agentInfo.agentName + "' (transient)");
/* 506 */         this.agents.remove(agentInfo.socket);
/* 507 */         this.agentNames.remove(agentInfo.agentName);
/* 508 */         this.messageIO.removeAgent(agentInfo);
/*     */       }
/*     */       else {
/* 511 */         Log.info("Lost connection to '" + agentInfo.agentName + "'");
/*     */       }
/*     */       try {
/* 514 */         agentInfo.socket.close(); } catch (IOException ex) {
/* 515 */         Log.exception("close", ex);
/* 516 */       }agentInfo.socket = null;
/*     */ 
/* 519 */       return;
/*     */     }
/*     */ 
/* 522 */     Message message = (Message)MarshallingRuntime.unmarshalObject(messageData);
/*     */ 
/* 524 */     MessageType msgType = message.getMsgType();
/* 525 */     if (Log.loggingDebug) {
/* 526 */       Log.debug("handleMessageData from " + agentInfo.agentName + "," + message.getMsgId() + " type=" + msgType.getMsgTypeString() + " len=" + length + " class=" + message.getClass().getName());
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 532 */       if ((message instanceof AllocNameMessage))
/* 533 */         handleAllocName((AllocNameMessage)message, agentInfo.socket);
/* 534 */       else if ((message instanceof AwaitPluginDependentsMessage)) {
/* 535 */         handleAwaitPluginDependents((AwaitPluginDependentsMessage)message, agentInfo.socket);
/*     */       }
/* 537 */       else if ((message instanceof PluginAvailableMessage)) {
/* 538 */         handlePluginAvailable((PluginAvailableMessage)message, agentInfo.socket);
/*     */       }
/*     */       else {
/* 541 */         Log.error("Unsupported message from " + agentInfo.agentName + "," + message.getMsgId() + " type=" + msgType.getMsgTypeString() + " len=" + length + " class=" + message.getClass().getName());
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 547 */       Log.error("IO error on message from " + agentInfo.agentName + "," + message.getMsgId() + " type=" + msgType.getMsgTypeString() + " len=" + length + " class=" + message.getClass().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized String allocName(String type, String namePattern)
/*     */   {
/* 556 */     Map patterns = (Map)this.nameTypes.get(type);
/* 557 */     if (patterns == null) {
/* 558 */       patterns = new HashMap();
/* 559 */       this.nameTypes.put(type, patterns);
/*     */     }
/*     */ 
/* 562 */     Integer id = (Integer)patterns.get(namePattern);
/* 563 */     if (id == null) {
/* 564 */       id = Integer.valueOf(0);
/*     */     }
/* 566 */     Integer localInteger1 = id; Integer localInteger2 = id = Integer.valueOf(id.intValue() + 1);
/* 567 */     patterns.put(namePattern, id);
/* 568 */     String agentName = namePattern.replaceFirst("#", id.toString());
/* 569 */     if (agentName.equals(namePattern)) {
/* 570 */       Log.warn("AllocName: missing '#' in name pattern '" + namePattern + "'");
/*     */     }
/*     */     else {
/* 573 */       Log.debug("AllocName: for type=" + type + " assigned '" + agentName + "' from pattern '" + namePattern + "'");
/*     */     }
/* 575 */     return agentName;
/*     */   }
/*     */ 
/*     */   private static void saveProcessID(String svrName, String runDir)
/*     */   {
/* 580 */     Log.info("Server Name is " + svrName + " Run Dir is " + runDir);
/* 581 */     RuntimeMXBean rt = ManagementFactory.getRuntimeMXBean();
/* 582 */     String pid = rt.getName();
/* 583 */     if (Log.loggingDebug) {
/* 584 */       Log.info("PROCESS ID IS " + pid);
/* 585 */       Log.info("server name is " + svrName);
/*     */     }
/*     */     try
/*     */     {
/* 589 */       if (runDir != null) {
/* 590 */         File outFile = new File(runDir + "\\" + svrName + ".bat");
/* 591 */         PrintWriter out = new PrintWriter(new FileWriter(outFile));
/* 592 */         out.println("set pid=" + pid.substring(0, pid.indexOf("@")));
/* 593 */         out.close();
/*     */       }
/*     */     } catch (IOException e) {
/* 596 */       Log.exception("saveProcessID caught exception", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void touchFile(String fileName)
/*     */   {
/*     */     try {
/* 603 */       FileWriter writer = new FileWriter(fileName);
/* 604 */       writer.close();
/*     */     }
/*     */     catch (IOException e) {
/* 607 */       Log.exception("touchFile " + fileName, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addPluginStartGroup(PluginStartGroup startGroup)
/*     */   {
/* 790 */     this.pluginStartGroup = startGroup;
/*     */   }
/*     */ 
/*     */   private static String determineHostName()
/*     */   {
/* 795 */     String hostName = System.getProperty("atavism.hostname");
/* 796 */     if (hostName == null)
/* 797 */       hostName = reverseLocalHostLookup();
/* 798 */     if (hostName == null) {
/* 799 */       Log.warn("Could not determine host name from reverse lookup or atavism.hostname, using 'localhost'");
/* 800 */       hostName = "localhost";
/*     */     }
/* 802 */     return hostName;
/*     */   }
/*     */ 
/*     */   private static String reverseLocalHostLookup()
/*     */   {
/* 807 */     InetAddress localMachine = null;
/*     */     try {
/* 809 */       localMachine = InetAddress.getLocalHost();
/* 810 */       return localMachine.getHostName();
/*     */     }
/*     */     catch (UnknownHostException e) {
/* 813 */       Log.warn("Could not get host name from local IP address " + localMachine);
/*     */     }
/*     */ 
/* 816 */     return null;
/*     */   }
/*     */ 
/*     */   static class TimeoutRunnable
/*     */     implements Runnable
/*     */   {
/*     */     int timeout;
/*     */ 
/*     */     public TimeoutRunnable(int timeout)
/*     */     {
/* 830 */       this.timeout = timeout;
/*     */     }
/*     */     public void run() {
/* 833 */       System.err.println("\nSTARTUP FAILED -- didnt complete after " + this.timeout + " seconds.\nPlease stop server.");
/*     */     }
/*     */   }
/*     */ 
/*     */   class DomainThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/* 825 */     int threadCount = 1;
/*     */ 
/*     */     DomainThreadFactory()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Thread newThread(Runnable runnable)
/*     */     {
/* 823 */       return new Thread(runnable, "Domain-" + this.threadCount++);
/*     */     }
/*     */   }
/*     */ 
/*     */   class PluginDependencyWatcher
/*     */     implements Runnable
/*     */   {
/*     */     AwaitPluginDependentsMessage await;
/*     */     SocketChannel agentSocket;
/*     */ 
/*     */     public PluginDependencyWatcher(AwaitPluginDependentsMessage await, SocketChannel agentSocket)
/*     */     {
/* 744 */       this.await = await;
/* 745 */       this.agentSocket = agentSocket;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 750 */       synchronized (DomainServer.this.pluginStartGroup) {
/* 751 */         waitForDependencies();
/*     */       }
/*     */ 
/* 754 */       if (Log.loggingDebug) {
/* 755 */         Log.debug("Dependency satisfied for type=" + this.await.getPluginType() + " name=" + this.await.getPluginName());
/*     */       }
/*     */ 
/* 758 */       AOByteBuffer buffer = new AOByteBuffer(1024);
/* 759 */       ResponseMessage response = new ResponseMessage(this.await);
/* 760 */       Message.toBytes(response, buffer);
/* 761 */       buffer.flip();
/*     */       try
/*     */       {
/* 764 */         if (!ChannelUtil.writeBuffer(buffer, this.agentSocket))
/* 765 */           Log.error("could not write await dependencies response");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 769 */         Log.exception("could not write await dependencies response", e);
/*     */       }
/*     */     }
/*     */ 
/*     */     void waitForDependencies()
/*     */     {
/* 776 */       while (DomainServer.this.pluginStartGroup.hasDependencies(this.await.getPluginType(), this.await.getPluginName()))
/*     */         try
/*     */         {
/* 779 */           DomainServer.this.pluginStartGroup.wait();
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class PluginStartGroup
/*     */   {
/* 735 */     Map<String, DomainServer.PluginSpec> plugins = new HashMap();
/* 736 */     Map<String, String[]> dependencies = new HashMap();
/*     */ 
/*     */     public void add(String pluginType, int expected)
/*     */     {
/* 625 */       this.plugins.put(pluginType, new DomainServer.PluginSpec(pluginType, expected));
/*     */     }
/*     */ 
/*     */     public void prepareDependencies(Properties properties, String worldName)
/*     */     {
/* 630 */       for (DomainServer.PluginSpec plugin : this.plugins.values())
/*     */       {
/* 632 */         String depString = properties.getProperty(new StringBuilder().append("atavism.plugin_dep.").append(worldName).append(".").append(plugin.pluginType).toString());
/*     */ 
/* 634 */         if (depString == null) {
/* 635 */           depString = properties.getProperty(new StringBuilder().append("atavism.plugin_dep.").append(plugin.pluginType).toString());
/*     */         }
/*     */ 
/* 638 */         if (depString == null)
/*     */           continue;
/* 640 */         depString = depString.trim();
/* 641 */         String[] deps = null;
/* 642 */         if (!depString.equals(""))
/* 643 */           deps = depString.split(",");
/* 644 */         this.dependencies.put(plugin.pluginType, deps);
/* 645 */         if (Log.loggingDebug)
/* 646 */           Log.debug(new StringBuilder().append("plugin type ").append(plugin.pluginType).append(" depends on plugin types: ").append(deps == null ? "*none*" : depString).toString());
/*     */       }
/*     */     }
/*     */ 
/*     */     public synchronized void pluginAvailable(String pluginType, String pluginName)
/*     */     {
/* 655 */       if (Log.loggingDebug) {
/* 656 */         Log.debug(new StringBuilder().append("Plugin available type=").append(pluginType).append(" name=").append(pluginName).toString());
/*     */       }
/*     */ 
/* 659 */       DomainServer.PluginSpec pluginSpec = (DomainServer.PluginSpec)this.plugins.get(pluginType);
/* 660 */       if (pluginSpec == null) {
/* 661 */         Log.error(new StringBuilder().append("DomainServer: unexpected plugin type=").append(pluginType).append(" name=").append(pluginName).toString());
/*     */ 
/* 663 */         return;
/*     */       }
/*     */ 
/* 666 */       pluginSpec.running += 1;
/* 667 */       if (pluginSpec.running > pluginSpec.expected) {
/* 668 */         Log.warn(new StringBuilder().append("DomainServer: more plugins than expected, type=").append(pluginType).append(" name=").append(pluginName).append(" expected=").append(pluginSpec.expected).append(" available=").append(pluginSpec.running).toString());
/*     */       }
/*     */ 
/* 674 */       if (pluginSpec.running >= pluginSpec.expected)
/* 675 */         notifyAll();
/*     */     }
/*     */ 
/*     */     public synchronized boolean hasDependencies(String pluginType, String pluginName)
/*     */     {
/* 682 */       String[] deps = (String[])this.dependencies.get(pluginType);
/* 683 */       if (deps == null)
/* 684 */         return false;
/* 685 */       for (String dependentType : deps) {
/* 686 */         DomainServer.PluginSpec pluginSpec = (DomainServer.PluginSpec)this.plugins.get(dependentType);
/* 687 */         if (pluginSpec == null) {
/* 688 */           Log.warn(new StringBuilder().append("No information for dependent type=").append(dependentType).toString());
/*     */         }
/* 692 */         else if (pluginSpec.running < pluginSpec.expected) {
/* 693 */           if (Log.loggingDebug) {
/* 694 */             Log.debug(new StringBuilder().append("Incomplete dependency for type=").append(pluginType).append(" name=").append(pluginName).append(" dependentType=").append(dependentType).toString());
/*     */           }
/*     */ 
/* 698 */           return true;
/*     */         }
/*     */       }
/* 701 */       return false;
/*     */     }
/*     */ 
/*     */     public synchronized void awaitDependency(String pluginType)
/*     */     {
/* 706 */       while (hasDependencies(pluginType, pluginType))
/*     */         try {
/* 708 */           wait();
/*     */         }
/*     */         catch (InterruptedException e) {
/*     */         }
/*     */     }
/*     */ 
/*     */     public synchronized void awaitAllAvailable() {
/* 715 */       while (!allAvailable())
/*     */         try {
/* 717 */           wait();
/*     */         }
/*     */         catch (InterruptedException e) {
/*     */         }
/*     */     }
/*     */ 
/*     */     boolean allAvailable() {
/* 724 */       for (Map.Entry plugin : this.plugins.entrySet()) {
/* 725 */         DomainServer.PluginSpec pluginSpec = (DomainServer.PluginSpec)plugin.getValue();
/* 726 */         if (pluginSpec.running < pluginSpec.expected) {
/* 727 */           System.err.println(new StringBuilder().append("STILL waiting for ").append(pluginSpec.pluginType).append(" expected ").append(pluginSpec.expected).append(" running ").append(pluginSpec.running).toString());
/*     */ 
/* 729 */           return false;
/*     */         }
/*     */       }
/* 732 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class PluginSpec
/*     */   {
/*     */     public String pluginType;
/*     */     public int expected;
/*     */     public int running;
/*     */ 
/*     */     public PluginSpec(String pluginType, int expected)
/*     */     {
/* 614 */       this.pluginType = pluginType;
/* 615 */       this.expected = expected;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AgentHandler
/*     */     implements Runnable
/*     */   {
/*     */     SocketChannel agentSocket;
/*     */ 
/*     */     public AgentHandler(SocketChannel socket)
/*     */       throws IOException
/*     */     {
/* 272 */       this.agentSocket = socket;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try { while (handleMessage());
/*     */       }
/*     */       catch (InterruptedIOException ex) {
/* 281 */         Log.info("DomainServer: closed connection due to timeout " + this.agentSocket);
/*     */       }
/*     */       catch (IOException ex) {
/* 284 */         Log.info("DomainServer: agent closed connection " + this.agentSocket);
/*     */       }
/*     */       catch (Exception ex) {
/* 287 */         Log.exception("DomainServer.SocketHandler: ", ex);
/*     */       }
/*     */       try
/*     */       {
/* 291 */         if (this.agentSocket != null)
/* 292 */           this.agentSocket.close();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean handleMessage() throws IOException {
/* 300 */       ByteBuffer buf = ByteBuffer.allocate(4);
/* 301 */       int nBytes = ChannelUtil.fillBuffer(buf, this.agentSocket);
/* 302 */       if (nBytes == 0) {
/* 303 */         Log.info("DomainServer: agent closed connection " + this.agentSocket);
/*     */ 
/* 305 */         return false;
/*     */       }
/* 307 */       if (nBytes < 4) {
/* 308 */         Log.error("DomainServer: invalid message " + nBytes);
/* 309 */         return false;
/*     */       }
/*     */ 
/* 312 */       int msgLen = buf.getInt();
/* 313 */       if (msgLen < 0) {
/* 314 */         return false;
/*     */       }
/*     */ 
/* 317 */       AOByteBuffer buffer = new AOByteBuffer(msgLen);
/* 318 */       nBytes = ChannelUtil.fillBuffer(buffer.getNioBuf(), this.agentSocket);
/* 319 */       if (nBytes == 0) {
/* 320 */         Log.info("DomainServer: agent closed connection " + this.agentSocket);
/*     */ 
/* 322 */         return false;
/*     */       }
/* 324 */       if (nBytes < msgLen) {
/* 325 */         Log.error("DomainServer: invalid message, expecting " + msgLen + " got " + nBytes + " from " + this.agentSocket);
/*     */ 
/* 327 */         return false;
/*     */       }
/*     */ 
/* 330 */       Message message = (Message)MarshallingRuntime.unmarshalObject(buffer);
/*     */ 
/* 333 */       if ((message instanceof AgentHelloMessage))
/*     */       {
/* 336 */         if (handleAgentHello((AgentHelloMessage)message))
/* 337 */           this.agentSocket = null;
/* 338 */         return false;
/*     */       }
/* 340 */       if ((message instanceof AllocNameMessage)) {
/* 341 */         DomainServer.this.handleAllocName((AllocNameMessage)message, this.agentSocket);
/*     */       }
/* 343 */       return true;
/*     */     }
/*     */ 
/*     */     boolean handleAgentHello(AgentHelloMessage agentHello)
/*     */       throws IOException
/*     */     {
/* 349 */       if (agentHello.getMsgType() != MessageTypes.MSG_TYPE_AGENT_HELLO) {
/* 350 */         Log.error("DomainServer: invalid agent hello, got message type " + agentHello.getMsgType() + " from " + this.agentSocket);
/*     */ 
/* 352 */         return false;
/*     */       }
/*     */       int agentId;
/* 356 */       synchronized (DomainServer.domainServer) {
/* 357 */         agentId = DomainServer.this.getNextAgentId();
/* 358 */         if (!DomainServer.this.agentNames.contains(agentHello.getAgentName())) {
/* 359 */           DomainServer.this.agentNames.add(agentHello.getAgentName());
/*     */         }
/*     */       }
/* 362 */       AOByteBuffer buffer = new AOByteBuffer(1024);
/* 363 */       HelloResponseMessage helloResponse = new HelloResponseMessage(agentId, DomainServer.this.domainStartTime, DomainServer.this.agentNames, DomainServer.encodedDomainKey);
/*     */ 
/* 365 */       Message.toBytes(helloResponse, buffer);
/* 366 */       buffer.flip();
/*     */ 
/* 368 */       if (!ChannelUtil.writeBuffer(buffer, this.agentSocket)) {
/* 369 */         Log.error("could not write to new agent, " + this.agentSocket);
/* 370 */         return false;
/*     */       }
/*     */ 
/* 373 */       DomainServer.this.addNewAgent(agentId, this.agentSocket, agentHello.getAgentName(), agentHello.getAgentIP(), agentHello.getAgentPort(), agentHello.getFlags());
/*     */ 
/* 377 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.DomainServer
 * JD-Core Version:    0.6.0
 */