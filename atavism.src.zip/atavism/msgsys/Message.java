/*     */ package atavism.msgsys;
/*     */ 
/*     */ import atavism.server.marshalling.MarshallingRuntime;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Message
/*     */   implements Serializable
/*     */ {
/*     */   static final short RPC = 1;
/*     */   long msgId;
/*     */   MessageType msgType;
/*     */   short flags;
/*     */   transient MessageAgent.RemoteAgent remoteAgent;
/*     */   transient long enqueueTime;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Message()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Message(MessageType msgType)
/*     */   {
/*  18 */     this.msgType = msgType;
/*     */   }
/*     */ 
/*     */   public MessageType getMsgType()
/*     */   {
/*  24 */     return this.msgType;
/*     */   }
/*     */ 
/*     */   public void setMsgType(MessageType msgType)
/*     */   {
/*  30 */     this.msgType = msgType;
/*     */   }
/*     */ 
/*     */   public long getMsgId()
/*     */   {
/*  37 */     return this.msgId;
/*     */   }
/*     */   void setMessageId(long msgId) {
/*  40 */     this.msgId = msgId;
/*     */   }
/*     */ 
/*     */   public String getSenderName()
/*     */   {
/*  47 */     if (this.remoteAgent != null) {
/*  48 */       return this.remoteAgent.agentName;
/*     */     }
/*  50 */     return null;
/*     */   }
/*     */ 
/*     */   public long getEnqueueTime()
/*     */   {
/*  56 */     return this.enqueueTime;
/*     */   }
/*     */ 
/*     */   public void setEnqueueTime(long when)
/*     */   {
/*  64 */     this.enqueueTime = when;
/*     */   }
/*     */ 
/*     */   public void setEnqueueTime()
/*     */   {
/*  72 */     this.enqueueTime = System.nanoTime();
/*     */   }
/*     */ 
/*     */   MessageAgent.RemoteAgent getRemoteAgent() {
/*  76 */     return this.remoteAgent;
/*     */   }
/*     */ 
/*     */   public static void toBytes(Message message, AOByteBuffer buffer)
/*     */   {
/*  82 */     int lengthPos = buffer.position();
/*  83 */     buffer.putInt(0);
/*  84 */     MarshallingRuntime.marshalObject(buffer, message);
/*     */ 
/*  87 */     int currentPos = buffer.position();
/*  88 */     buffer.position(lengthPos);
/*  89 */     buffer.putInt(currentPos - lengthPos - 4);
/*  90 */     buffer.position(currentPos);
/*     */   }
/*     */ 
/*     */   void setRPC() {
/*  94 */     this.flags = (short)(this.flags | 0x1);
/*     */   }
/*     */ 
/*     */   void unsetRPC() {
/*  98 */     this.flags = (short)(this.flags & 0xFFFFFFFE);
/*     */   }
/*     */ 
/*     */   public boolean isRPC()
/*     */   {
/* 103 */     return (this.flags & 0x1) != 0;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.Message
 * JD-Core Version:    0.6.0
 */