/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class NoRecipientsException extends AORuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public NoRecipientsException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NoRecipientsException(String msg)
/*    */   {
/* 14 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NoRecipientsException(String msg, Throwable cause) {
/* 18 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public NoRecipientsException(Throwable cause) {
/* 22 */     super(cause);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.NoRecipientsException
 * JD-Core Version:    0.6.0
 */