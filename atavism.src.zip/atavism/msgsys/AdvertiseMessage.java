/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AdvertiseMessage extends Message
/*    */ {
/* 26 */   private Collection<MessageType> advertisements = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AdvertiseMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AdvertiseMessage(Collection<MessageType> list)
/*    */   {
/* 12 */     this.msgType = MessageTypes.MSG_TYPE_ADVERTISE;
/* 13 */     this.advertisements = list;
/*    */   }
/*    */ 
/*    */   public void setAdvertisements(List<MessageType> list)
/*    */   {
/* 18 */     this.advertisements = list;
/*    */   }
/*    */ 
/*    */   public Collection<MessageType> getAdvertisements()
/*    */   {
/* 23 */     return this.advertisements;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.AdvertiseMessage
 * JD-Core Version:    0.6.0
 */