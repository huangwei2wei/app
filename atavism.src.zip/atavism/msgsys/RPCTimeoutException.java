/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class RPCTimeoutException extends AORuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public RPCTimeoutException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RPCTimeoutException(String msg)
/*    */   {
/* 15 */     super(msg);
/*    */   }
/*    */ 
/*    */   public RPCTimeoutException(String msg, Throwable cause) {
/* 19 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public RPCTimeoutException(Throwable cause) {
/* 23 */     super(cause);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.RPCTimeoutException
 * JD-Core Version:    0.6.0
 */