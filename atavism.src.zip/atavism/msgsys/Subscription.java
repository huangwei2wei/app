/*    */ package atavism.msgsys;
/*    */ 
/*    */ public abstract class Subscription extends SubscriptionHandle
/*    */ {
/*    */   long subId;
/*    */   IFilter filter;
/*    */   MessageTrigger trigger;
/*    */   short flags;
/*    */ 
/*    */   public Subscription()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Subscription(IFilter filter)
/*    */   {
/* 12 */     this.filter = filter;
/* 13 */     this.flags = 0;
/*    */   }
/*    */ 
/*    */   public Subscription(IFilter filter, short flags) {
/* 17 */     this.filter = filter;
/* 18 */     this.flags = flags;
/*    */   }
/*    */ 
/*    */   public Subscription(IFilter filter, MessageTrigger trigger, short flags) {
/* 22 */     this.filter = filter;
/* 23 */     this.trigger = trigger;
/* 24 */     this.flags = flags;
/*    */   }
/*    */ 
/*    */   public long getSubId()
/*    */   {
/* 29 */     return this.subId;
/*    */   }
/*    */ 
/*    */   public IFilter getFilter()
/*    */   {
/* 34 */     return this.filter;
/*    */   }
/*    */ 
/*    */   public MessageTrigger getTrigger()
/*    */   {
/* 39 */     return this.trigger;
/*    */   }
/*    */ 
/*    */   public short getFlags()
/*    */   {
/* 44 */     return this.flags;
/*    */   }
/*    */ 
/*    */   public abstract Object getAssociation();
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.Subscription
 * JD-Core Version:    0.6.0
 */