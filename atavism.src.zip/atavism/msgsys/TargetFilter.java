/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class TargetFilter extends MessageTypeFilter
/*    */ {
/*    */   private long targetOid;
/*    */   private long subjectOid;
/*    */ 
/*    */   public TargetFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TargetFilter(Collection<MessageType> types, long targetOid, long subjectOid)
/*    */   {
/* 19 */     super(types);
/* 20 */     this.targetOid = targetOid;
/* 21 */     this.subjectOid = subjectOid;
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message message)
/*    */   {
/* 31 */     if ((message instanceof TargetMessage)) {
/* 32 */       return (((TargetMessage)message).getTarget().equals(Long.valueOf(this.targetOid))) || (((TargetMessage)message).getTarget().equals(Long.valueOf(this.subjectOid)));
/*    */     }
/* 34 */     if ((message instanceof SubjectMessage)) {
/* 35 */       return ((SubjectMessage)message).getSubject().equals(Long.valueOf(this.subjectOid));
/*    */     }
/* 37 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 42 */     return "[TargetFilter " + toStringInternal() + "]";
/*    */   }
/*    */ 
/*    */   protected String toStringInternal()
/*    */   {
/* 47 */     return "target=" + this.targetOid + " subject=" + this.subjectOid + " " + super.toStringInternal();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.TargetFilter
 * JD-Core Version:    0.6.0
 */