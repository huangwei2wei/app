/*     */ package atavism.msgsys;
/*     */ 
/*     */ import atavism.server.marshalling.Marshallable;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class MessageType
/*     */   implements Serializable, Marshallable
/*     */ {
/*  60 */   protected static Map<String, MessageType> internedMsgTypes = new HashMap();
/*     */   protected transient String msgTypeString;
/*     */   protected transient Integer msgTypeNumber;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public MessageType()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected MessageType(String msgTypeString)
/*     */   {
/*  31 */     this.msgTypeString = msgTypeString;
/*  32 */     this.msgTypeNumber = Integer.valueOf(-1);
/*     */   }
/*     */ 
/*     */   public int getMsgTypeNumber()
/*     */   {
/*  37 */     if (this.msgTypeNumber.intValue() == -1) {
/*  38 */       Integer number = MessageCatalog.getMessageNumber(this.msgTypeString);
/*  39 */       if (number != null)
/*  40 */         this.msgTypeNumber = number;
/*     */       else
/*  42 */         this.msgTypeNumber = Integer.valueOf(0);
/*     */     }
/*  44 */     return this.msgTypeNumber.intValue();
/*     */   }
/*     */ 
/*     */   public void setMsgTypeNumber(int msgTypeNumber)
/*     */   {
/*  51 */     this.msgTypeNumber = Integer.valueOf(msgTypeNumber);
/*     */   }
/*     */ 
/*     */   public String getMsgTypeString()
/*     */   {
/*  57 */     return this.msgTypeString;
/*     */   }
/*     */ 
/*     */   public static MessageType intern(String typeName)
/*     */   {
/*  66 */     MessageType type = (MessageType)internedMsgTypes.get(typeName);
/*  67 */     if (type == null) {
/*  68 */       type = new MessageType(typeName);
/*  69 */       internedMsgTypes.put(typeName, type);
/*     */     }
/*  71 */     return type;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  75 */     return "MessageType['" + this.msgTypeString + "', " + this.msgTypeNumber + "]";
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/*  80 */     boolean b = in.readBoolean();
/*  81 */     if (b) {
/*  82 */       this.msgTypeNumber = Integer.valueOf(in.readInt());
/*  83 */       MessageType type = MessageCatalog.getMessageType(this.msgTypeNumber);
/*  84 */       this.msgTypeString = type.getMsgTypeString();
/*     */     }
/*     */     else
/*     */     {
/*  90 */       this.msgTypeNumber = Integer.valueOf(-1);
/*  91 */       this.msgTypeString = in.readUTF();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static MessageType readObjectUtility(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 102 */     boolean b = in.readBoolean();
/* 103 */     if (b) {
/* 104 */       int msgTypeNumber = in.readInt();
/* 105 */       return MessageCatalog.getMessageType(Integer.valueOf(msgTypeNumber));
/*     */     }
/*     */ 
/* 108 */     String msgTypeString = in.readUTF();
/* 109 */     return intern(msgTypeString);
/*     */   }
/*     */ 
/*     */   private Object readResolve()
/*     */     throws ObjectStreamException
/*     */   {
/* 115 */     if (this.msgTypeNumber.intValue() > 0)
/*     */     {
/* 117 */       MessageType type = MessageCatalog.getMessageType(this.msgTypeNumber);
/*     */ 
/* 120 */       return type;
/*     */     }
/*     */ 
/* 123 */     MessageType type = intern(this.msgTypeString);
/*     */ 
/* 126 */     return type;
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 132 */     if (this.msgTypeNumber.intValue() > 0)
/*     */     {
/* 135 */       out.writeBoolean(true);
/* 136 */       out.writeInt(this.msgTypeNumber.intValue());
/*     */     }
/*     */     else
/*     */     {
/* 141 */       out.writeBoolean(false);
/* 142 */       out.writeUTF(this.msgTypeString);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void writeObjectUtility(ObjectOutputStream out, MessageType type)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 149 */     if (type.msgTypeNumber.intValue() > 0) {
/* 150 */       out.writeBoolean(true);
/* 151 */       out.writeInt(type.msgTypeNumber.intValue());
/*     */     }
/*     */     else {
/* 154 */       out.writeBoolean(false);
/* 155 */       out.writeUTF(type.msgTypeString);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void marshalObject(AOByteBuffer buf)
/*     */   {
/* 161 */     if (this.msgTypeNumber.intValue() > 0) {
/* 162 */       buf.putByte(1);
/* 163 */       buf.putShort((short)this.msgTypeNumber.intValue());
/*     */     }
/*     */     else {
/* 166 */       buf.putByte(0);
/* 167 */       buf.putString(this.msgTypeString);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object unmarshalObject(AOByteBuffer buf)
/*     */   {
/* 173 */     MessageType msgType = null;
/* 174 */     byte b = buf.getByte();
/* 175 */     if (b != 0) {
/* 176 */       int typeNum = buf.getShort();
/* 177 */       msgType = MessageCatalog.getMessageType(Integer.valueOf(typeNum));
/* 178 */       if (msgType == null)
/* 179 */         Log.error("No MessageType number " + typeNum + " in MessageCatalog");
/*     */     }
/*     */     else
/*     */     {
/* 183 */       msgType = intern(buf.getString());
/* 184 */     }return msgType;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageType
 * JD-Core Version:    0.6.0
 */