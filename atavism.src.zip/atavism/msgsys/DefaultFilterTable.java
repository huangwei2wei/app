/*     */ package atavism.msgsys;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DefaultFilterTable extends FilterTable
/*     */ {
/* 102 */   Map<MessageType, Map<Object, List<Subscription>>> messageTypes = new HashMap();
/*     */ 
/*     */   public synchronized void addFilter(Subscription sub, Object object)
/*     */   {
/*  17 */     Collection types = sub.filter.getMessageTypes();
/*  18 */     if (types == null)
/*     */     {
/*  20 */       return;
/*     */     }
/*     */ 
/*  23 */     for (MessageType tt : types) {
/*  24 */       Map objectMap = (Map)this.messageTypes.get(tt);
/*  25 */       if (objectMap == null) {
/*  26 */         objectMap = new HashMap();
/*  27 */         this.messageTypes.put(tt, objectMap);
/*     */       }
/*  29 */       LinkedList subList = (LinkedList)objectMap.get(object);
/*     */ 
/*  31 */       if (subList == null) {
/*  32 */         subList = new LinkedList();
/*  33 */         objectMap.put(object, subList);
/*     */       }
/*  35 */       if (sub.getTrigger() != null)
/*  36 */         subList.addFirst(sub);
/*     */       else
/*  38 */         subList.addLast(sub);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void removeFilter(Subscription sub, Object object)
/*     */   {
/*  44 */     Collection types = sub.filter.getMessageTypes();
/*  45 */     if (types == null)
/*     */     {
/*  47 */       return;
/*     */     }
/*     */ 
/*  50 */     for (MessageType tt : types) {
/*  51 */       Map objectMap = (Map)this.messageTypes.get(tt);
/*  52 */       if (objectMap == null) {
/*     */         continue;
/*     */       }
/*  55 */       List subList = (List)objectMap.get(object);
/*  56 */       if (subList == null)
/*     */       {
/*     */         continue;
/*     */       }
/*  60 */       ListIterator iterator = subList.listIterator();
/*  61 */       while (iterator.hasNext()) {
/*  62 */         Subscription ss = (Subscription)iterator.next();
/*  63 */         if (ss.subId == sub.subId) {
/*  64 */           iterator.remove();
/*  65 */           break;
/*     */         }
/*     */       }
/*  68 */       if (subList.size() == 0)
/*  69 */         objectMap.remove(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized int match(Message message, Set<Object> matches, List<Subscription> triggers)
/*     */   {
/*  77 */     MessageType type = message.getMsgType();
/*  78 */     Map objectMap = (Map)this.messageTypes.get(type);
/*  79 */     if (objectMap == null)
/*  80 */       return 0;
/*  81 */     int count = 0;
/*  82 */     for (Iterator i$ = objectMap.entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
/*  83 */       List subs = (List)entry.getValue();
/*  84 */       matched = false;
/*  85 */       for (Subscription sub : subs)
/*  86 */         if (sub.filter.matchRemaining(message)) {
/*  87 */           if ((!matched) && (matches.add(entry.getKey()))) {
/*  88 */             count++;
/*  89 */             matched = true;
/*     */           }
/*  91 */           if ((triggers == null) || (sub.getTrigger() == null) || (!sub.getTrigger().match(message)))
/*     */             break;
/*  93 */           triggers.add(sub);
/*     */         }
/*     */     }
/*     */     Map.Entry entry;
/*     */     boolean matched;
/*  99 */     return count;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.DefaultFilterTable
 * JD-Core Version:    0.6.0
 */