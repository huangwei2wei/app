/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class SubscribeMessage extends Message
/*    */ {
/*    */   private long subId;
/*    */   private IFilter filter;
/*    */   private MessageTrigger trigger;
/*    */   private short flags;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public SubscribeMessage()
/*    */   {
/*  7 */     this.msgType = MessageTypes.MSG_TYPE_SUBSCRIBE;
/*    */   }
/*    */ 
/*    */   SubscribeMessage(long subId, IFilter filter, short flags)
/*    */   {
/* 12 */     this.msgType = MessageTypes.MSG_TYPE_SUBSCRIBE;
/* 13 */     this.subId = subId;
/* 14 */     this.filter = filter;
/* 15 */     this.flags = flags;
/*    */   }
/*    */ 
/*    */   SubscribeMessage(long subId, IFilter filter, MessageTrigger trigger, short flags)
/*    */   {
/* 21 */     this.msgType = MessageTypes.MSG_TYPE_SUBSCRIBE;
/* 22 */     this.subId = subId;
/* 23 */     this.filter = filter;
/* 24 */     this.trigger = trigger;
/* 25 */     this.flags = flags;
/*    */   }
/*    */ 
/*    */   long getSubId()
/*    */   {
/* 30 */     return this.subId;
/*    */   }
/*    */ 
/*    */   IFilter getFilter()
/*    */   {
/* 35 */     return this.filter;
/*    */   }
/*    */ 
/*    */   short getFlags()
/*    */   {
/* 40 */     return this.flags;
/*    */   }
/*    */ 
/*    */   MessageTrigger getTrigger()
/*    */   {
/* 45 */     return this.trigger;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.SubscribeMessage
 * JD-Core Version:    0.6.0
 */