package atavism.msgsys;

public abstract interface MessageCallback
{
  public static final int NO_FLAGS = 0;
  public static final int RESPONSE_EXPECTED = 1;

  public abstract void handleMessage(Message paramMessage, int paramInt);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageCallback
 * JD-Core Version:    0.6.0
 */