package atavism.msgsys;

public abstract interface ITargetSessionId
{
  public abstract String getTargetSessionId();

  public abstract void setTargetSessionId(String paramString);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.ITargetSessionId
 * JD-Core Version:    0.6.0
 */