/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class OIDResponseMessage extends ResponseMessage
/*    */ {
/*    */   private OID oidVal;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public OIDResponseMessage()
/*    */   {
/*  7 */     super(MessageTypes.MSG_TYPE_OID_RESPONSE);
/*    */   }
/*    */ 
/*    */   public OIDResponseMessage(Message msg, OID oidVal) {
/* 11 */     super(MessageTypes.MSG_TYPE_OID_RESPONSE, msg);
/* 12 */     setOIDVal(oidVal);
/*    */   }
/*    */ 
/*    */   public void setOIDVal(OID oidVal) {
/* 16 */     this.oidVal = oidVal;
/*    */   }
/*    */ 
/*    */   public OID getOIDVal() {
/* 20 */     return this.oidVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 24 */     return "[OIDResponseMessage: " + super.toString() + ", oidVal " + this.oidVal + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.OIDResponseMessage
 * JD-Core Version:    0.6.0
 */