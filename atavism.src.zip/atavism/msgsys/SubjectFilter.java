/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class SubjectFilter extends MessageTypeFilter
/*    */ {
/*    */   private OID subjectOid;
/*    */ 
/*    */   public SubjectFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SubjectFilter(OID oid)
/*    */   {
/* 19 */     this.subjectOid = oid;
/*    */   }
/*    */ 
/*    */   public SubjectFilter(Collection<MessageType> types, OID oid)
/*    */   {
/* 26 */     super(types);
/* 27 */     this.subjectOid = oid;
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message message)
/*    */   {
/* 36 */     if ((message instanceof SubjectMessage))
/* 37 */       return ((SubjectMessage)message).getSubject().equals(this.subjectOid);
/* 38 */     if ((message instanceof TargetMessage)) {
/* 39 */       return ((TargetMessage)message).getTarget().equals(this.subjectOid);
/*    */     }
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 46 */     return "[SubjectFilter " + toStringInternal() + "]";
/*    */   }
/*    */ 
/*    */   protected String toStringInternal()
/*    */   {
/* 51 */     return "oid=" + this.subjectOid + " " + super.toStringInternal();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.SubjectFilter
 * JD-Core Version:    0.6.0
 */