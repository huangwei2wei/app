/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ public class UnsubscribeMessage extends Message
/*    */ {
/*    */   private ArrayList<Long> subIds;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public UnsubscribeMessage()
/*    */   {
/*  8 */     this.msgType = MessageTypes.MSG_TYPE_UNSUBSCRIBE;
/*    */   }
/*    */ 
/*    */   UnsubscribeMessage(long subId)
/*    */   {
/* 13 */     this.msgType = MessageTypes.MSG_TYPE_UNSUBSCRIBE;
/* 14 */     this.subIds = new ArrayList(4);
/* 15 */     this.subIds.add(Long.valueOf(subId));
/*    */   }
/*    */ 
/*    */   UnsubscribeMessage(Collection<Long> subIds)
/*    */   {
/* 20 */     this.msgType = MessageTypes.MSG_TYPE_UNSUBSCRIBE;
/* 21 */     this.subIds = new ArrayList(subIds.size());
/* 22 */     this.subIds.addAll(subIds);
/*    */   }
/*    */ 
/*    */   List<Long> getSubIds()
/*    */   {
/* 27 */     return this.subIds;
/*    */   }
/*    */ 
/*    */   void add(long subId)
/*    */   {
/* 32 */     if (this.subIds == null)
/* 33 */       this.subIds = new ArrayList(4);
/* 34 */     this.subIds.add(Long.valueOf(subId));
/*    */   }
/*    */ 
/*    */   void add(Collection<Long> subIds)
/*    */   {
/* 39 */     if (this.subIds == null)
/* 40 */       this.subIds = new ArrayList(subIds.size());
/* 41 */     this.subIds.addAll(subIds);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.UnsubscribeMessage
 * JD-Core Version:    0.6.0
 */