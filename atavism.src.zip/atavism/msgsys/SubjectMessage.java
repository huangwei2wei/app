/*    */ package atavism.msgsys;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class SubjectMessage extends Message
/*    */ {
/*    */   protected OID oid;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public SubjectMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SubjectMessage(MessageType msgType)
/*    */   {
/* 16 */     super(msgType);
/*    */   }
/*    */ 
/*    */   public SubjectMessage(MessageType msgType, OID oid)
/*    */   {
/* 22 */     super(msgType);
/* 23 */     this.oid = oid;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 28 */     return "[" + getClass().getName() + " subject=" + this.oid + "]";
/*    */   }
/*    */ 
/*    */   public OID getSubject()
/*    */   {
/* 36 */     return this.oid;
/*    */   }
/*    */ 
/*    */   public void setSubject(OID oid)
/*    */   {
/* 43 */     this.oid = oid;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.SubjectMessage
 * JD-Core Version:    0.6.0
 */