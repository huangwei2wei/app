/*     */ package atavism.msgsys;
/*     */ 
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.CancelledKeyException;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MessageIO
/*     */   implements Runnable
/*     */ {
/*     */   private Callback callback;
/* 328 */   private List<AgentInfo> newAgents = new LinkedList();
/*     */   private Selector ioSelector;
/*     */   private ByteBuffer readBuf;
/* 331 */   private boolean scanForWrite = false;
/*     */ 
/* 335 */   private int messageLengthByteCount = 4;
/*     */ 
/*     */   public MessageIO()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MessageIO(int messageLengthByteCount)
/*     */   {
/*  23 */     setMessageLengthByteCount(messageLengthByteCount);
/*     */   }
/*     */ 
/*     */   public MessageIO(Callback callback)
/*     */   {
/*  28 */     initialize(callback);
/*     */   }
/*     */ 
/*     */   protected void initialize(Callback callback)
/*     */   {
/*  33 */     this.readBuf = ByteBuffer.allocate(8192);
/*  34 */     this.callback = callback;
/*     */     try {
/*  36 */       this.ioSelector = Selector.open();
/*     */     } catch (IOException ex) {
/*  38 */       Log.exception("MessageHandler selector failed", ex);
/*  39 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*  45 */     start("MessageIO");
/*     */   }
/*     */ 
/*     */   public void start(String threadName)
/*     */   {
/*  50 */     if (Log.loggingNet)
/*  51 */       Log.net("MessageIO.start: Starting MessageIO thread");
/*  52 */     Thread thread = new Thread(this, threadName);
/*  53 */     thread.setDaemon(true);
/*  54 */     thread.start();
/*     */   }
/*     */ 
/*     */   public void addAgent(AgentInfo agentInfo)
/*     */   {
/*  59 */     synchronized (this.newAgents) {
/*  60 */       this.newAgents.add(agentInfo);
/*     */     }
/*  62 */     this.ioSelector.wakeup();
/*     */   }
/*     */ 
/*     */   public void removeAgent(AgentInfo agentInfo)
/*     */   {
/*  67 */     agentInfo.socket.keyFor(this.ioSelector).cancel();
/*  68 */     this.ioSelector.wakeup();
/*     */   }
/*     */ 
/*     */   public void outputReady()
/*     */   {
/*  73 */     this.scanForWrite = true;
/*  74 */     this.ioSelector.wakeup();
/*     */   }
/*     */ 
/*     */   public void addToOutputWithLength(AOByteBuffer buf, AgentInfo agentInfo) {
/*  78 */     boolean needNotify = true;
/*  79 */     synchronized (agentInfo.outputBuf) {
/*  80 */       needNotify = agentInfo.outputBuf.position() == 0;
/*  81 */       putMessageLength(buf, agentInfo);
/*  82 */       byte[] data = buf.array();
/*  83 */       agentInfo.outputBuf.putBytes(data, 0, buf.limit());
/*     */     }
/*  85 */     if (needNotify)
/*  86 */       outputReady();
/*     */   }
/*     */ 
/*     */   public void addToOutput(AOByteBuffer buf, AgentInfo agentInfo) {
/*  90 */     boolean needNotify = true;
/*  91 */     synchronized (agentInfo.outputBuf) {
/*  92 */       needNotify = agentInfo.outputBuf.position() == 0;
/*  93 */       byte[] data = buf.array();
/*  94 */       agentInfo.outputBuf.putBytes(data, 0, buf.limit());
/*     */     }
/*  96 */     if (needNotify)
/*  97 */       outputReady();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     while (true)
/*     */       try
/*     */       {
/* 110 */         doMessageIO();
/*     */ 
/* 117 */         continue;
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 113 */         Log.exception("MessageIO thread got", ex);
/*     */ 
/* 117 */         continue;
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 116 */         Log.exception("MessageIO thread got", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void doMessageIO()
/*     */     throws IOException
/*     */   {
/* 124 */     this.ioSelector.select();
/*     */ 
/* 126 */     synchronized (this.newAgents) {
/* 127 */       for (AgentInfo agentInfo : this.newAgents)
/*     */         try {
/* 129 */           agentInfo.socket.register(this.ioSelector, 5, agentInfo);
/*     */         }
/*     */         catch (ClosedChannelException ex)
/*     */         {
/* 134 */           Log.exception("addNewAgent", ex);
/*     */           try
/*     */           {
/* 137 */             this.callback.handleMessageData(-1, null, agentInfo);
/*     */           }
/*     */           catch (AORuntimeException e) {
/*     */           }
/*     */         }
/* 142 */       this.newAgents.clear();
/*     */     }
/*     */ 
/* 145 */     Set readyKeys = this.ioSelector.selectedKeys();
/* 146 */     for (SelectionKey key : readyKeys) {
/* 147 */       SocketChannel socket = (SocketChannel)key.channel();
/* 148 */       AgentInfo agentInfo = (AgentInfo)key.attachment();
/*     */       try {
/* 150 */         handleReadyChannel(socket, key, agentInfo);
/*     */       }
/*     */       catch (CancelledKeyException ex) {
/* 153 */         Log.debug("Connection closed (cancelled) " + socket);
/*     */         try {
/* 155 */           this.callback.handleMessageData(-1, null, agentInfo);
/*     */         } catch (Exception e) {
/*     */         }
/*     */       }
/*     */     }
/* 160 */     if (this.scanForWrite) {
/* 161 */       Set allKeys = this.ioSelector.keys();
/* 162 */       for (SelectionKey key : allKeys) {
/* 163 */         AgentInfo agentInfo = (AgentInfo)key.attachment();
/*     */         try {
/* 165 */           synchronized (agentInfo.outputBuf) {
/* 166 */             if (agentInfo.outputBuf.position() > 0)
/* 167 */               key.interestOps(5);
/*     */           }
/*     */         }
/*     */         catch (CancelledKeyException ex) {
/*     */         }
/*     */       }
/* 173 */       this.scanForWrite = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void handleReadyChannel(SocketChannel socket, SelectionKey key, AgentInfo agentInfo)
/*     */     throws IOException
/*     */   {
/* 181 */     if (key.isWritable()) {
/* 182 */       synchronized (agentInfo.outputBuf) {
/* 183 */         if (agentInfo.outputBuf.position() > 0) {
/* 184 */           agentInfo.outputBuf.flip();
/*     */           try {
/* 186 */             socket.write(agentInfo.outputBuf.getNioBuf());
/*     */           }
/*     */           catch (IOException ex) {
/* 189 */             Log.debug("Connection closed (exception on write) " + socket + " exception=" + ex);
/*     */ 
/* 191 */             return;
/*     */           }
/*     */ 
/* 194 */           agentInfo.outputBuf.getNioBuf().compact();
/*     */         }
/*     */       }
/*     */     }
/* 198 */     if (key.isReadable()) {
/* 199 */       int nRead = -1;
/* 200 */       this.readBuf.clear();
/*     */       try {
/* 202 */         nRead = socket.read(this.readBuf);
/*     */       }
/*     */       catch (IOException ex) {
/* 205 */         Log.debug("Connection closed (exception) " + socket);
/* 206 */         socket.close();
/*     */         try {
/* 208 */           this.callback.handleMessageData(-1, null, agentInfo);
/*     */         } catch (Exception e) {
/* 210 */           Log.exception("Exception handling closed connection", e);
/*     */         }
/* 212 */         return;
/*     */       }
/* 214 */       if (nRead == -1) {
/* 215 */         Log.debug("Connection closed (-1) " + socket);
/* 216 */         socket.close();
/*     */         try {
/* 218 */           this.callback.handleMessageData(-1, null, agentInfo);
/*     */         } catch (Exception e) {
/* 220 */           Log.exception("Exception handling closed connection", e);
/*     */         }
/* 222 */         return;
/*     */       }
/* 224 */       this.readBuf.flip();
/*     */ 
/* 226 */       addAgentData(this.readBuf, agentInfo);
/*     */     }
/* 228 */     synchronized (agentInfo.outputBuf) {
/* 229 */       if (agentInfo.outputBuf.position() > 0) {
/* 230 */         key.interestOps(5);
/*     */       }
/*     */       else
/*     */       {
/* 234 */         key.interestOps(1);
/* 235 */         agentInfo.outputBuf.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addAgentData(ByteBuffer buf, AgentInfo agentInfo)
/*     */   {
/* 244 */     AOByteBuffer inputBuf = agentInfo.inputBuf;
/* 245 */     if (inputBuf.remaining() < buf.limit()) {
/* 246 */       int additional = inputBuf.capacity();
/* 247 */       while (inputBuf.remaining() + additional < buf.limit()) {
/* 248 */         additional = 2 * additional;
/*     */       }
/* 250 */       AOByteBuffer newBuf = new AOByteBuffer(inputBuf.capacity() + additional);
/*     */ 
/* 252 */       byte[] bytes = inputBuf.array();
/* 253 */       newBuf.putBytes(bytes, 0, bytes.length);
/* 254 */       newBuf.position(inputBuf.position());
/* 255 */       newBuf.limit(inputBuf.limit());
/* 256 */       agentInfo.inputBuf = newBuf;
/* 257 */       inputBuf = newBuf;
/*     */     }
/*     */ 
/* 260 */     byte[] bytes = buf.array();
/* 261 */     inputBuf.putBytes(bytes, 0, buf.limit());
/*     */ 
/* 263 */     inputBuf.flip();
/* 264 */     while (inputBuf.remaining() >= 4) {
/* 265 */       int currentPos = inputBuf.position();
/* 266 */       int messageLen = getMessageLength(inputBuf);
/* 267 */       if (inputBuf.remaining() < messageLen) {
/* 268 */         inputBuf.position(currentPos);
/* 269 */         break;
/*     */       }
/*     */       try {
/* 272 */         this.callback.handleMessageData(messageLen, inputBuf, agentInfo);
/*     */       }
/*     */       catch (Exception ex) {
/* 275 */         Log.exception("handleMessageData", ex);
/*     */       }
/*     */ 
/* 280 */       inputBuf.position(currentPos + this.messageLengthByteCount + messageLen);
/*     */     }
/* 282 */     inputBuf.getNioBuf().compact();
/*     */   }
/*     */ 
/*     */   private int getMessageLength(AOByteBuffer inputBuf)
/*     */   {
/* 287 */     switch (this.messageLengthByteCount) {
/*     */     case 4:
/* 289 */       return inputBuf.getInt();
/*     */     case 2:
/* 291 */       return inputBuf.getShort();
/*     */     case 1:
/* 293 */       return inputBuf.getByte();
/*     */     case 3:
/* 295 */     }throw new AORuntimeException("MessageIO.getMessageLength: messageLengthByteCount is " + this.messageLengthByteCount);
/*     */   }
/*     */ 
/*     */   private void putMessageLength(AOByteBuffer buf, AgentInfo agentInfo)
/*     */   {
/* 300 */     int dataLen = buf.limit();
/* 301 */     AOByteBuffer target = agentInfo.outputBuf;
/* 302 */     switch (this.messageLengthByteCount) {
/*     */     case 4:
/* 304 */       target.putInt(dataLen);
/* 305 */       break;
/*     */     case 2:
/* 307 */       target.putShort((short)dataLen);
/* 308 */       break;
/*     */     case 1:
/* 310 */       target.putByte((byte)dataLen);
/* 311 */       break;
/*     */     case 3:
/*     */     default:
/* 313 */       Log.error("MessageIO.putBufLength: messageLengthByteCount is " + this.messageLengthByteCount);
/* 314 */       target.putInt(dataLen);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMessageLengthByteCount()
/*     */   {
/* 320 */     return this.messageLengthByteCount;
/*     */   }
/*     */ 
/*     */   public void setMessageLengthByteCount(int messageLengthByteCount) {
/* 324 */     this.messageLengthByteCount = messageLengthByteCount;
/*     */   }
/*     */ 
/*     */   public static abstract interface Callback
/*     */   {
/*     */     public abstract void handleMessageData(int paramInt, AOByteBuffer paramAOByteBuffer, AgentInfo paramAgentInfo);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageIO
 * JD-Core Version:    0.6.0
 */