/*     */ package atavism.msgsys;
/*     */ 
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class MessageTypeSessionIdFilter extends MessageTypeFilter
/*     */ {
/* 109 */   transient Lock lock = null;
/* 110 */   static final Logger log = new Logger("MessageTypeSessionIdFilter");
/*     */ 
/* 113 */   Set<MessageType> types = new HashSet();
/*     */ 
/* 115 */   String targetSessionId = null;
/* 116 */   boolean matchesNullSessionId = false;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public MessageTypeSessionIdFilter()
/*     */   {
/*  15 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public MessageTypeSessionIdFilter(String targetSessionId)
/*     */   {
/*  20 */     setupTransient();
/*  21 */     setTargetSessionId(targetSessionId);
/*     */   }
/*     */ 
/*     */   public MessageTypeSessionIdFilter(String targetSessionId, MessageType type)
/*     */   {
/*  27 */     setupTransient();
/*  28 */     setTargetSessionId(targetSessionId);
/*  29 */     addType(type);
/*     */   }
/*     */ 
/*     */   public MessageTypeSessionIdFilter(MessageType type, String targetSessionId, boolean matchNullFlag)
/*     */   {
/*  36 */     setupTransient();
/*  37 */     setTargetSessionId(targetSessionId);
/*  38 */     addType(type);
/*  39 */     matchesNullSessionId(matchNullFlag);
/*     */   }
/*     */ 
/*     */   void setupTransient() {
/*  43 */     this.lock = LockFactory.makeLock("MessageTypeSessionIdFilterLock");
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  47 */     return "MessageTypeSessionIdFilter";
/*     */   }
/*     */ 
/*     */   public void matchesNullSessionId(boolean flag) {
/*  51 */     this.matchesNullSessionId = flag;
/*     */   }
/*     */   public boolean matchesNullSessionId() {
/*  54 */     return this.matchesNullSessionId;
/*     */   }
/*     */ 
/*     */   public void setTargetSessionId(String s) {
/*  58 */     this.targetSessionId = s;
/*     */   }
/*     */   public String getTargetSessionId() {
/*  61 */     return this.targetSessionId;
/*     */   }
/*     */ 
/*     */   public boolean matchesRemaining(Message msg) {
/*  65 */     MessageType msgType = msg.getMsgType();
/*  66 */     this.lock.lock();
/*     */     try {
/*  68 */       boolean typeMatched = false;
/*  69 */       for (MessageType t : this.types) {
/*  70 */         if (msgType == t) {
/*  71 */           typeMatched = true;
/*  72 */           break;
/*     */         }
/*     */       }
/*  75 */       if (!typeMatched) {
/*  76 */         ??? = 0;
/*     */         return ???;
/*     */       } } finally { this.lock.unlock();
/*     */     }
/*     */ 
/*  89 */     String msgTargetSessionId = null;
/*  90 */     if ((msg instanceof ITargetSessionId)) {
/*  91 */       msgTargetSessionId = ((ITargetSessionId)msg).getTargetSessionId();
/*     */     }
/*     */ 
/*  94 */     if ((matchesNullSessionId()) && (msgTargetSessionId == null)) {
/*  95 */       return true;
/*     */     }
/*     */ 
/*  99 */     if (msgTargetSessionId == null) {
/* 100 */       return false;
/*     */     }
/* 102 */     return msgTargetSessionId.equals(getTargetSessionId());
/*     */   }
/*     */ 
/*     */   public Set<MessageType> getTypes() {
/* 106 */     return this.types;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.MessageTypeSessionIdFilter
 * JD-Core Version:    0.6.0
 */