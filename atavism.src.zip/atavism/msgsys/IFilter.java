package atavism.msgsys;

import java.util.Collection;

public abstract interface IFilter
{
  public abstract boolean matchMessageType(Collection<MessageType> paramCollection);

  public abstract boolean matchRemaining(Message paramMessage);

  public abstract Collection<MessageType> getMessageTypes();

  public abstract boolean applyFilterUpdate(FilterUpdate paramFilterUpdate, AgentHandle paramAgentHandle, SubscriptionHandle paramSubscriptionHandle);

  public abstract FilterTable getSendFilterTable();

  public abstract FilterTable getReceiveFilterTable();

  public abstract FilterTable getResponderSendFilterTable();

  public abstract FilterTable getResponderReceiveFilterTable();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.IFilter
 * JD-Core Version:    0.6.0
 */