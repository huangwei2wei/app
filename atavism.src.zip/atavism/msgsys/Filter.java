/*    */ package atavism.msgsys;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ public abstract class Filter
/*    */   implements IFilter
/*    */ {
/*    */   public abstract boolean matchMessageType(Collection<MessageType> paramCollection);
/*    */ 
/*    */   public abstract boolean matchRemaining(Message paramMessage);
/*    */ 
/*    */   public abstract Collection<MessageType> getMessageTypes();
/*    */ 
/*    */   public boolean applyFilterUpdate(FilterUpdate update, AgentHandle sender, SubscriptionHandle sub)
/*    */   {
/* 36 */     return applyFilterUpdate(update);
/*    */   }
/*    */ 
/*    */   public boolean applyFilterUpdate(FilterUpdate update)
/*    */   {
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   public FilterTable getSendFilterTable()
/*    */   {
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */   public FilterTable getReceiveFilterTable()
/*    */   {
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   public FilterTable getResponderSendFilterTable()
/*    */   {
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   public FilterTable getResponderReceiveFilterTable()
/*    */   {
/* 74 */     return null;
/*    */   }
/*    */ 
/*    */   protected String toStringInternal() {
/* 78 */     return "";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.Filter
 * JD-Core Version:    0.6.0
 */