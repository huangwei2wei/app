package atavism.msgsys;

import atavism.server.engine.OID;

public abstract interface HasTarget
{
  public abstract OID getTarget();

  public abstract void setTarget(OID paramOID);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.HasTarget
 * JD-Core Version:    0.6.0
 */