/*    */ package atavism.msgsys;
/*    */ 
/*    */ public class ResponseMessage extends Message
/*    */ {
/*    */   long requestId;
/*    */   transient MessageAgent.RemoteAgent requestingAgent;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ResponseMessage()
/*    */   {
/* 11 */     this.msgType = MessageTypes.MSG_TYPE_RESPONSE;
/*    */   }
/*    */ 
/*    */   public ResponseMessage(MessageType type)
/*    */   {
/* 17 */     this.msgType = type;
/*    */   }
/*    */ 
/*    */   public ResponseMessage(Message requestMessage)
/*    */   {
/* 24 */     this.msgType = MessageTypes.MSG_TYPE_RESPONSE;
/* 25 */     this.requestId = requestMessage.getMsgId();
/* 26 */     this.requestingAgent = requestMessage.getRemoteAgent();
/*    */   }
/*    */ 
/*    */   public ResponseMessage(MessageType msgType, Message requestMessage)
/*    */   {
/* 32 */     this.msgType = msgType;
/* 33 */     this.requestId = requestMessage.getMsgId();
/* 34 */     this.requestingAgent = requestMessage.getRemoteAgent();
/*    */   }
/*    */ 
/*    */   public long getRequestId()
/*    */   {
/* 40 */     return this.requestId;
/*    */   }
/*    */ 
/*    */   MessageAgent.RemoteAgent getRequestingAgent()
/*    */   {
/* 45 */     return this.requestingAgent;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.ResponseMessage
 * JD-Core Version:    0.6.0
 */