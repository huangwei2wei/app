package atavism.msgsys;

public abstract interface ResponseCallback
{
  public abstract void handleResponse(ResponseMessage paramResponseMessage);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.msgsys.ResponseCallback
 * JD-Core Version:    0.6.0
 */