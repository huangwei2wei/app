/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.text.DateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public final class SecureTokenSpec
/*    */ {
/*    */   private final byte type;
/*    */   private final String issuerId;
/*    */   private final long expiry;
/* 30 */   private TreeMap<String, Serializable> properties = new TreeMap();
/*    */   public static final byte TOKEN_TYPE_MASTER = 1;
/*    */   public static final byte TOKEN_TYPE_DOMAIN = 2;
/*    */ 
/*    */   public SecureTokenSpec(byte type, String issuerId, long expiry)
/*    */   {
/* 16 */     this.type = type;
/* 17 */     this.issuerId = issuerId;
/* 18 */     this.expiry = expiry;
/*    */   }
/*    */   public SecureTokenSpec(byte type, String issuerId, long expiry, Map<String, Serializable> properties) {
/* 21 */     this.type = type;
/* 22 */     this.issuerId = issuerId;
/* 23 */     this.expiry = expiry;
/* 24 */     this.properties.putAll(properties);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     String str = "type=" + this.type + " issuerId=" + this.issuerId + " expiry=<" + DateFormat.getInstance().format(new Date(this.expiry)) + "> props:";
/*    */ 
/* 35 */     for (String key : this.properties.keySet()) {
/* 36 */       str = str + " " + key + ":" + ((Serializable)this.properties.get(key)).toString();
/*    */     }
/* 38 */     return str;
/*    */   }
/*    */ 
/*    */   public byte getType() {
/* 42 */     return this.type;
/*    */   }
/*    */   public String getIssuerId() {
/* 45 */     return this.issuerId;
/*    */   }
/*    */   public long getExpiry() {
/* 48 */     return this.expiry;
/*    */   }
/*    */   public Serializable getProperty(String key) {
/* 51 */     return (Serializable)this.properties.get(key);
/*    */   }
/*    */   public void setProperty(String key, Serializable value) {
/* 54 */     this.properties.put(key, value);
/*    */   }
/*    */ 
/*    */   public TreeMap<String, Serializable> getPropertyMap() {
/* 58 */     return this.properties;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SecureTokenSpec
 * JD-Core Version:    0.6.0
 */