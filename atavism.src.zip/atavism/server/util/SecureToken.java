/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class SecureToken
/*    */ {
/*    */   protected final SecureTokenSpec spec;
/*    */   protected final byte version;
/*    */   protected final long tokenId;
/*    */   protected final long keyId;
/*    */   protected final byte[] authenticator;
/*    */   protected final boolean valid;
/*    */   protected static final byte TOKEN_VERSION = 1;
/*    */ 
/*    */   SecureToken(SecureTokenSpec spec, byte version, long tokenId, long keyId, byte[] authenticator, boolean valid)
/*    */   {
/* 14 */     this.spec = spec;
/* 15 */     this.version = version;
/* 16 */     this.tokenId = tokenId;
/* 17 */     this.keyId = keyId;
/* 18 */     this.authenticator = authenticator;
/* 19 */     this.valid = valid;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 30 */     return "[SecureToken: version=" + this.version + " tokenId=0x" + Long.toHexString(this.tokenId) + " keyId=0x" + Long.toHexString(this.keyId) + " valid=" + this.valid + " " + this.spec.toString() + "]";
/*    */   }
/*    */ 
/*    */   public byte getType()
/*    */   {
/* 35 */     return this.spec.getType();
/*    */   }
/*    */   public String getIssuerId() {
/* 38 */     return this.spec.getIssuerId();
/*    */   }
/*    */   public long getExpiry() {
/* 41 */     return this.spec.getExpiry();
/*    */   }
/*    */   public Serializable getProperty(String key) {
/* 44 */     return this.spec.getProperty(key);
/*    */   }
/*    */   public byte getVersion() {
/* 47 */     return this.version;
/*    */   }
/*    */   public long getTokenId() {
/* 50 */     return this.tokenId;
/*    */   }
/*    */   public long getKeyId() {
/* 53 */     return this.keyId;
/*    */   }
/*    */   public boolean getValid() {
/* 56 */     return this.valid;
/*    */   }
/*    */   public byte[] getAuthenticator() {
/* 59 */     return this.authenticator;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SecureToken
 * JD-Core Version:    0.6.0
 */