/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class AnimationCommand
/*    */   implements Serializable
/*    */ {
/* 61 */   String command = null;
/* 62 */   String animName = null;
/*    */ 
/* 64 */   boolean isLoopFlag = false;
/*    */   public static final String ADD_CMD = "add";
/*    */   public static final String CLEAR_CMD = "clear";
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 15 */     return "[AnimationCommand: cmd=" + getCommand() + ", animName=" + getAnimName() + ", isLoop=" + isLoop() + "]";
/*    */   }
/*    */ 
/*    */   public String getCommand()
/*    */   {
/* 22 */     return this.command;
/*    */   }
/*    */ 
/*    */   public void setCommand(String command) {
/* 26 */     this.command = command;
/*    */   }
/*    */ 
/*    */   public String getAnimName() {
/* 30 */     return this.animName;
/*    */   }
/*    */ 
/*    */   public void setAnimName(String animName) {
/* 34 */     this.animName = animName;
/*    */   }
/*    */ 
/*    */   public boolean isLoop() {
/* 38 */     return this.isLoopFlag;
/*    */   }
/*    */ 
/*    */   public void isLoop(boolean flag) {
/* 42 */     this.isLoopFlag = flag;
/*    */   }
/*    */ 
/*    */   public static AnimationCommand clear() {
/* 46 */     AnimationCommand ac = new AnimationCommand();
/* 47 */     ac.setCommand("clear");
/* 48 */     ac.setAnimName("");
/* 49 */     ac.isLoop(false);
/* 50 */     return ac;
/*    */   }
/*    */ 
/*    */   public static AnimationCommand add(String animName, boolean isLoop) {
/* 54 */     AnimationCommand ac = new AnimationCommand();
/* 55 */     ac.setCommand("add");
/* 56 */     ac.setAnimName(animName);
/* 57 */     ac.isLoop(isLoop);
/* 58 */     return ac;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.AnimationCommand
 * JD-Core Version:    0.6.0
 */