/*    */ package atavism.server.util;
/*    */ 
/*    */ public class AORuntimeException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AORuntimeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AORuntimeException(String msg)
/*    */   {
/* 10 */     super(msg);
/*    */   }
/*    */ 
/*    */   public AORuntimeException(String msg, Throwable cause) {
/* 14 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public AORuntimeException(Throwable cause) {
/* 18 */     super(cause);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.AORuntimeException
 * JD-Core Version:    0.6.0
 */