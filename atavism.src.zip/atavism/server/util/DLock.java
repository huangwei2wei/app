/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ 
/*     */ public class DLock extends ReentrantLock
/*     */ {
/* 446 */   String threadName = null;
/*     */ 
/* 448 */   String lockName = "unknown";
/*     */ 
/* 452 */   static Map<DLock, Map<DLock, StackTraceElement[]>> lockOrderMap = new HashMap();
/*     */ 
/* 457 */   static Map<Thread, LinkedList<DLock>> threadLocks = new HashMap();
/*     */ 
/* 459 */   static int lockTimeoutMS = 30000;
/*     */ 
/* 470 */   static ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
/*     */ 
/* 472 */   static ReentrantReadWriteLock.ReadLock rLock = rwLock.readLock();
/*     */ 
/* 474 */   static ReentrantReadWriteLock.WriteLock wLock = rwLock.writeLock();
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   DLock(String name)
/*     */   {
/*  14 */     setName(name);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  18 */     return "[DLock lockName=" + getLockName() + ", hashCode=" + hashCode() + "]";
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  23 */     this.lockName = name;
/*     */   }
/*     */ 
/*     */   public String getLockName() {
/*  27 */     return this.lockName;
/*     */   }
/*     */ 
/*     */   public boolean tryLock()
/*     */   {
/*  32 */     boolean rv = super.tryLock();
/*  33 */     if (rv) {
/*  34 */       lock(false);
/*     */     }
/*  36 */     return rv;
/*     */   }
/*     */ 
/*     */   public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
/*  40 */     System.err.println("dlock.lock: called tryLock");
/*  41 */     throw new RuntimeException();
/*     */   }
/*     */ 
/*     */   public void lockInterruptibly() throws InterruptedException {
/*  45 */     System.err.println("dlock.lock: called lockInterruptibly");
/*  46 */     throw new RuntimeException();
/*     */   }
/*     */ 
/*     */   public Condition newCondition() {
/*  50 */     Log.warn("dlock.lock: called newCondition");
/*  51 */     return super.newCondition();
/*     */   }
/*     */ 
/*     */   public void lock() {
/*  55 */     lock(true);
/*     */   }
/*     */ 
/*     */   public void lock(boolean acquireLock)
/*     */   {
/*  61 */     Thread currentThread = Thread.currentThread();
/*     */ 
/*  63 */     Log.debug("lock: name=" + this.lockName + ", thread=" + currentThread);
/*     */ 
/*  65 */     boolean acquiredLock = false;
/*  66 */     rLock.lock();
/*     */     try {
/*  68 */       if (acquireLock) {
/*     */         try
/*     */         {
/*  71 */           acquiredLock = super.tryLock(lockTimeoutMS, TimeUnit.MILLISECONDS);
/*     */         }
/*     */         catch (Exception e) {
/*  74 */           System.err.println("dlock.lock: got exception: " + e);
/*  75 */           Log.error("dlock.lock: got exception: " + e);
/*  76 */           System.exit(-1);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  81 */         acquiredLock = true;
/*     */       }
/*     */ 
/*  84 */       if (acquiredLock)
/*  85 */         synchronized (DLock.class)
/*     */         {
/*  90 */           LinkedList locks = (LinkedList)threadLocks.get(currentThread);
/*  91 */           if (locks == null)
/*     */           {
/*  94 */             Log.info("lock: lockName=" + this.lockName + ", this thread has no locks yet, creating entry.  thread=" + currentThread);
/*     */ 
/*  98 */             locks = new LinkedList();
/*  99 */             threadLocks.put(currentThread, locks);
/*     */           }
/*     */ 
/* 106 */           DLock lastLock = null;
/* 107 */           if (!locks.isEmpty()) {
/* 108 */             lastLock = (DLock)locks.getLast();
/*     */           }
/* 110 */           locks.add(this);
/*     */ 
/* 112 */           Log.debug("lock: lockName=" + this.lockName + ", lastLock=" + lastLock);
/*     */ 
/* 114 */           if ((lastLock != null) && (lastLock != this)) {
/* 115 */             Map subMap = (Map)lockOrderMap.get(lastLock);
/*     */ 
/* 117 */             if (subMap == null)
/*     */             {
/* 119 */               subMap = new HashMap();
/* 120 */               lockOrderMap.put(lastLock, subMap);
/*     */             }
/*     */ 
/* 124 */             if (subMap.get(this) == null)
/*     */             {
/* 126 */               StackTraceElement[] dump = currentThread.getStackTrace();
/*     */ 
/* 128 */               subMap.put(this, dump);
/*     */             }
/*     */           }
/*     */         }
/*     */     }
/*     */     finally {
/* 134 */       rLock.unlock();
/*     */     }
/* 136 */     if (!acquiredLock)
/*     */     {
/* 139 */       throwException("acquire lock failed: forcing cycle detection");
/* 140 */       Log.error("DLock.lock: thread with lock error is: " + currentThread);
/*     */ 
/* 144 */       Log.error("DLock.lock: dumping all threads currently holding locks");
/*     */ 
/* 146 */       for (Iterator i$ = threadLocks.keySet().iterator(); i$.hasNext(); ) { thread = (Thread)i$.next();
/* 147 */         LinkedList heldLocks = (LinkedList)threadLocks.get(thread);
/* 148 */         for (DLock heldLock : heldLocks) {
/* 149 */           Log.error("DLock.lock: thread " + thread + ", is holding lock " + heldLock);
/*     */ 
/* 151 */           if (heldLock == this)
/* 152 */             Log.error("DLock.lock: thread has lock in question, dumping stack trace:\n" + makeStackDumpString(thread.getStackTrace()));
/*     */         }
/*     */       }
/*     */       Thread thread;
/* 157 */       Log.error("DLock.lock: DONE dumping all threads currently held locks");
/* 158 */       Log.error("DLock.lock: detecting cycles for lock in question: " + this);
/*     */ 
/* 160 */       detectCycleHelper(this, new LinkedList(), new HashSet());
/*     */ 
/* 162 */       Log.error("DLock.lock: detecting all other cycles");
/* 163 */       detectCycle();
/* 164 */       Log.error("deadlock cycle detection complete, exiting process");
/* 165 */       System.exit(-1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unlock()
/*     */   {
/* 173 */     super.unlock();
/*     */ 
/* 176 */     synchronized (DLock.class) {
/* 177 */       Thread currentThread = Thread.currentThread();
/*     */ 
/* 180 */       LinkedList locks = (LinkedList)threadLocks.get(currentThread);
/* 181 */       if (locks == null)
/*     */       {
/* 183 */         throwException("unlock, but thread has no previous locks");
/*     */       }
/* 185 */       DLock lastLock = (DLock)locks.getLast();
/* 186 */       if (lastLock == null)
/*     */       {
/* 188 */         throwException("unlock, but thread has no previous locks");
/*     */       }
/* 190 */       if (lastLock == this)
/* 191 */         locks.removeLast();
/*     */       else
/* 193 */         throwException("unlock, last lock did not match this lock");
/*     */     }
/*     */   }
/*     */ 
/*     */   void throwException(String error)
/*     */   {
/* 204 */     Log.error("DLock.throwException: lock in question is: " + this + ", thread=" + Thread.currentThread().getName() + ", msg=" + error);
/*     */ 
/* 207 */     Log.dumpStack();
/*     */   }
/*     */ 
/*     */   public static Set<List<DLock>> detectCycle()
/*     */   {
/* 218 */     synchronized (DLock.class) {
/* 219 */       Log.error("DLock.detectCycles: finding all child nodes");
/*     */ 
/* 222 */       Set childNodes = getChildNodes();
/* 223 */       Log.error("DLock.detectCycle: found " + childNodes.size() + " child nodes");
/*     */ 
/* 227 */       Set topNodes = getTopNodes(childNodes);
/* 228 */       Log.error("DLock.detectCycle: found " + topNodes.size() + " top nodes");
/*     */ 
/* 232 */       HashSet cycleNodes = new HashSet();
/* 233 */       Set allCycles = new HashSet();
/* 234 */       for (DLock node : topNodes) {
/* 235 */         Log.error("DLock.detectCycle: doing depth first for top node " + node);
/*     */ 
/* 237 */         List history = new LinkedList();
/* 238 */         allCycles.addAll(detectCycleHelper(node, history, cycleNodes));
/*     */       }
/*     */ 
/* 244 */       Log.error("DLock.detectCycle: doing depth first for all child nodes");
/*     */ 
/* 246 */       for (DLock node : childNodes) {
/* 247 */         Log.error("DLock.detectCycle: doing depth first for child node " + node);
/*     */ 
/* 250 */         List history = new LinkedList();
/* 251 */         Set cycles = detectCycleHelper(node, history, cycleNodes);
/*     */ 
/* 255 */         for (List cycle : cycles) {
/* 256 */           if (!isSubset(cycle, allCycles)) {
/* 257 */             allCycles.add(cycle);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 262 */       Log.error("DLock.detectCycle: printing out all detected cycles");
/* 263 */       for (List cycle : allCycles) {
/* 264 */         printCycle(cycle);
/*     */       }
/* 266 */       Log.error("DLock.detectCycle: done with printout");
/* 267 */       return allCycles;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static boolean isSubset(List<DLock> set, Set<List<DLock>> allSets) {
/* 272 */     for (List testSet : allSets) {
/* 273 */       if (isSubset(set, testSet)) {
/* 274 */         return true;
/*     */       }
/*     */     }
/* 277 */     return false;
/*     */   }
/*     */ 
/*     */   protected static boolean isSubset(List<DLock> subset, List<DLock> superset) {
/* 281 */     for (DLock element : subset) {
/* 282 */       if (!superset.contains(element)) {
/* 283 */         return false;
/*     */       }
/*     */     }
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */   protected static Set<DLock> getChildNodes()
/*     */   {
/* 291 */     Set childNodes = new HashSet();
/* 292 */     for (Map subMap : lockOrderMap.values()) {
/* 293 */       childNodes.addAll(subMap.keySet());
/*     */     }
/* 295 */     return childNodes;
/*     */   }
/*     */ 
/*     */   protected static Set<DLock> getTopNodes(Set<DLock> childNodes)
/*     */   {
/* 302 */     Set topNodes = new HashSet();
/* 303 */     for (DLock node : lockOrderMap.keySet()) {
/* 304 */       if (!childNodes.contains(node)) {
/* 305 */         topNodes.add(node);
/*     */       }
/*     */     }
/* 308 */     return topNodes;
/*     */   }
/*     */ 
/*     */   protected static Set<List<DLock>> detectCycleHelper(DLock node, List<DLock> history, HashSet<DLock> cycleNodes)
/*     */   {
/* 320 */     if (Log.loggingDebug) {
/* 321 */       Log.debug("DLock.detectCyleHelper: considering node " + node + ", numCycleNodes=" + cycleNodes.size());
/*     */     }
/*     */ 
/* 325 */     if (history.contains(node)) {
/* 326 */       if (Log.loggingDebug) {
/* 327 */         Log.debug("DLock.detectCycleHelper: node " + node + " already in history, cycle detected");
/*     */       }
/* 329 */       history.add(node);
/*     */ 
/* 331 */       Set cycle = new HashSet();
/* 332 */       cycle.add(history);
/* 333 */       cycleNodes.add(node);
/* 334 */       return cycle;
/*     */     }
/*     */ 
/* 338 */     history.add(node);
/*     */ 
/* 341 */     Map subMap = (Map)lockOrderMap.get(node);
/* 342 */     if (subMap == null)
/*     */     {
/* 344 */       Log.debug("DLock.detectCycleHelper: node is leaf, returning");
/* 345 */       return new HashSet();
/*     */     }
/* 347 */     Set childSet = subMap.keySet();
/* 348 */     if ((childSet == null) || (childSet.isEmpty())) {
/* 349 */       Log.debug("DLock.detectCycleHelper: node is leaf, returning");
/* 350 */       return new HashSet();
/*     */     }
/*     */ 
/* 354 */     Set cycles = new HashSet();
/* 355 */     for (DLock child : childSet) {
/* 356 */       if (cycleNodes.contains(child)) {
/* 357 */         Log.debug("DLock.detectCycleHelper: child already causes cycle, skipping - currentNode=" + node + ", child=" + child);
/*     */ 
/* 359 */         continue;
/*     */       }
/* 361 */       if (Log.loggingDebug) {
/* 362 */         Log.debug("DLock.detectCycleHelper: currentNode=" + node + ", decending, child=" + child + ", numChildren=" + childSet.size());
/*     */       }
/*     */ 
/* 366 */       List historyCopy = new LinkedList(history);
/* 367 */       Set childCycles = detectCycleHelper(child, historyCopy, cycleNodes);
/*     */ 
/* 369 */       cycles.addAll(childCycles);
/*     */     }
/* 371 */     return cycles;
/*     */   }
/*     */ 
/*     */   protected static void stackDump(List<DLock> nodes)
/*     */   {
/* 380 */     if (nodes == null) {
/* 381 */       System.err.println("ERROR: DLock.stackDump: nodes is null");
/* 382 */       return;
/*     */     }
/* 384 */     if (nodes.isEmpty()) {
/* 385 */       System.err.println("ERROR: DLock.stackDump: nodes list is empty");
/* 386 */       return;
/*     */     }
/*     */ 
/* 389 */     System.err.println("Found Cycle, dumping history");
/* 390 */     Iterator iter = nodes.iterator();
/* 391 */     DLock prev = null;
/* 392 */     DLock cur = null;
/* 393 */     for (prev = (DLock)iter.next(); iter.hasNext(); prev = cur) {
/* 394 */       cur = (DLock)iter.next();
/*     */ 
/* 397 */       StackTraceElement[] stackArray = (StackTraceElement[])((Map)lockOrderMap.get(prev)).get(cur);
/* 398 */       String stackTrace = "";
/* 399 */       for (int i = 0; i < stackArray.length; i++) {
/* 400 */         stackTrace = stackTrace + "  stack" + i + "=" + stackArray[i].toString() + "\n";
/*     */       }
/*     */ 
/* 405 */       System.err.println("ERROR: DLock.stackDump: had lock " + prev.getLockName() + " when locked " + cur.getLockName() + ", dump:\n" + stackTrace);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void printCycle(List<DLock> cycle)
/*     */   {
/* 413 */     String s = "Cycle: ";
/* 414 */     DLock prev = null;
/* 415 */     for (DLock node : cycle) {
/* 416 */       s = s + "\nlock=" + node;
/*     */ 
/* 419 */       if (prev != null) {
/* 420 */         s = s + ", stackdump:\n";
/* 421 */         Map subMap = (Map)lockOrderMap.get(prev);
/* 422 */         StackTraceElement[] trace = (StackTraceElement[])subMap.get(node);
/*     */ 
/* 425 */         for (int i = 0; i < trace.length; i++) {
/* 426 */           s = s + "  stack" + i + "=" + trace[i].toString() + "\n";
/*     */         }
/*     */       }
/*     */ 
/* 430 */       prev = node;
/*     */     }
/* 432 */     Log.error("DLock.printCycle: " + s);
/*     */   }
/*     */ 
/*     */   public static String makeStackDumpString(StackTraceElement[] stackArray)
/*     */   {
/* 439 */     String stackTrace = "";
/* 440 */     for (int i = 0; i < stackArray.length; i++) {
/* 441 */       stackTrace = stackTrace + "  stack" + i + "=" + stackArray[i].toString() + "\n";
/*     */     }
/* 443 */     return stackTrace;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 477 */     DLock a = new DLock("A");
/* 478 */     DLock b = new DLock("B");
/* 479 */     a.lock();
/* 480 */     b.lock();
/* 481 */     a.lock();
/*     */ 
/* 483 */     a.unlock();
/* 484 */     b.unlock();
/* 485 */     a.unlock();
/* 486 */     System.out.println("detecting cycles..");
/* 487 */     detectCycle();
/* 488 */     System.out.println("done");
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.DLock
 * JD-Core Version:    0.6.0
 */