/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ public class XMLHelper
/*     */ {
/* 233 */   static final String[] typeName = { "none", "Element", "Attr", "Text", "CDATA", "EntityRef", "Entity", "ProcInstr", "Comment", "Document", "DocType", "DocFragment", "Notation" };
/*     */ 
/*     */   public static DocumentBuilder makeDocBuilder()
/*     */   {
/*  16 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  17 */     DocumentBuilder builder = null;
/*     */     try {
/*  19 */       builder = factory.newDocumentBuilder();
/*  20 */       builder.setErrorHandler(new ErrorHandler()
/*     */       {
/*     */         public void fatalError(SAXParseException exception) throws SAXException
/*     */         {
/*     */         }
/*     */ 
/*     */         public void error(SAXParseException e) throws SAXParseException
/*     */         {
/*  28 */           throw e;
/*     */         }
/*     */ 
/*     */         public void warning(SAXParseException err)
/*     */           throws SAXParseException
/*     */         {
/*  34 */           System.out.println("** Warning, line " + err.getLineNumber() + ", uri " + err.getSystemId());
/*     */ 
/*  37 */           System.out.println("   " + err.getMessage());
/*     */         }
/*     */ 
/*     */       });
/*     */     }
/*     */     catch (ParserConfigurationException pce)
/*     */     {
/*  49 */       Log.exception("XMLHelper.makeDocBuilder caught ParserConfigurationException", pce);
/*     */     }
/*  51 */     return builder;
/*     */   }
/*     */ 
/*     */   public static String getNodeValue(Node node)
/*     */   {
/*  56 */     return node.getFirstChild().getNodeValue();
/*     */   }
/*     */ 
/*     */   public static List<Node> getMatchingChildren(Node node, String name)
/*     */   {
/*  62 */     if (node == null) {
/*  63 */       return null;
/*     */     }
/*     */ 
/*  66 */     LinkedList returnList = new LinkedList();
/*     */ 
/*  68 */     NodeList childList = node.getChildNodes();
/*  69 */     int len = childList.getLength();
/*  70 */     for (int i = 0; i < len; i++) {
/*  71 */       Node curNode = childList.item(i);
/*  72 */       if (name.equals(curNode.getNodeName())) {
/*  73 */         returnList.add(curNode);
/*     */       }
/*     */     }
/*  76 */     return returnList;
/*     */   }
/*     */ 
/*     */   public static Node getMatchingChild(Node node, String name)
/*     */   {
/*  82 */     if (node == null) {
/*  83 */       return null;
/*     */     }
/*     */ 
/*  86 */     NodeList childList = node.getChildNodes();
/*  87 */     int len = childList.getLength();
/*  88 */     for (int i = 0; i < len; i++) {
/*  89 */       Node curNode = childList.item(i);
/*  90 */       if (name.equals(curNode.getNodeName())) {
/*  91 */         return curNode;
/*     */       }
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getMatchingChildValue(Node node, String name)
/*     */   {
/*  99 */     Node childNode = getMatchingChild(node, name);
/* 100 */     return getNodeValue(childNode);
/*     */   }
/*     */ 
/*     */   public static String getAttribute(Node node, String attrName) {
/* 104 */     NamedNodeMap attrMap = node.getAttributes();
/* 105 */     if (attrMap == null) {
/* 106 */       Log.debug("getAttribute: attr map is null");
/* 107 */       return null;
/*     */     }
/* 109 */     Node attrNode = attrMap.getNamedItem(attrName);
/* 110 */     if (attrNode == null) {
/* 111 */       Log.debug("getAttribute: attr node is null");
/* 112 */       return null;
/*     */     }
/* 114 */     return getNodeValue(attrNode);
/*     */   }
/*     */ 
/*     */   public static String toXML(Node node) {
/* 118 */     String xml = "";
/* 119 */     String name = node.getNodeName();
/* 120 */     xml = xml + "<" + name;
/*     */ 
/* 123 */     NamedNodeMap attrMap = node.getAttributes();
/* 124 */     if (attrMap != null) {
/* 125 */       int len = attrMap.getLength();
/* 126 */       for (int i = 0; i < len; i++) {
/* 127 */         Node attrNode = attrMap.item(i);
/* 128 */         String attrName = attrNode.getNodeName();
/* 129 */         String attrVal = getNodeValue(attrNode);
/* 130 */         xml = xml + " " + attrName + "=\"" + attrVal + "\"";
/*     */       }
/*     */     }
/* 133 */     xml = xml + ">";
/*     */ 
/* 136 */     NodeList children = node.getChildNodes();
/* 137 */     if (children != null) {
/* 138 */       int len = children.getLength();
/* 139 */       for (int i = 0; i < len; i++) {
/* 140 */         Node childNode = children.item(i);
/* 141 */         short nodeType = childNode.getNodeType();
/* 142 */         if (nodeType == 3)
/*     */         {
/* 147 */           xml = xml + childNode.getNodeValue();
/* 148 */         } else if (nodeType == 1)
/*     */         {
/* 153 */           xml = xml + toXML(childNode);
/*     */         }
/* 155 */         else if (Log.loggingDebug) {
/* 156 */           Log.debug("XMLHelper: unknown child node: , name=" + childNode.getNodeName() + ", type=" + typeName[childNode.getNodeType()] + ", val=" + childNode.getNodeValue());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 163 */     xml = xml + "</" + name + ">";
/* 164 */     return xml;
/*     */   }
/*     */ 
/*     */   public static void printAllChildren(Node node) {
/* 168 */     if (node == null) {
/* 169 */       return;
/*     */     }
/*     */ 
/* 172 */     NodeList childList = node.getChildNodes();
/* 173 */     int len = childList.getLength();
/* 174 */     for (int i = 0; i < len; i++) {
/* 175 */       Node curNode = childList.item(i);
/* 176 */       if (Log.loggingDebug)
/* 177 */         Log.debug("XMLHelper.printAllChildren: childnode= " + nodeToString(curNode));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String nodeToString(Node domNode)
/*     */   {
/* 183 */     if (domNode == null) {
/* 184 */       return "";
/*     */     }
/* 186 */     String s = typeName[domNode.getNodeType()];
/* 187 */     String nodeName = domNode.getNodeName();
/* 188 */     if (!nodeName.startsWith("#")) {
/* 189 */       s = s + ": " + nodeName;
/*     */     }
/* 191 */     if (domNode.getNodeValue() != null) {
/* 192 */       if (s.startsWith("ProcInstr"))
/* 193 */         s = s + ", ";
/*     */       else {
/* 195 */         s = s + ": ";
/*     */       }
/* 197 */       String t = domNode.getNodeValue().trim();
/* 198 */       int x = t.indexOf("\n");
/* 199 */       if (x >= 0)
/* 200 */         t = t.substring(0, x);
/* 201 */       s = s + t;
/*     */     }
/* 203 */     return s;
/*     */   }
/*     */ 
/*     */   public static Map<String, Serializable> nameValuePairsHelper(Node node) {
/* 207 */     Map resultMap = new HashMap();
/*     */ 
/* 209 */     List nameValueNodes = getMatchingChildren(node, "NameValuePair");
/* 210 */     for (Node pairNode : nameValueNodes) {
/* 211 */       String key = getAttribute(pairNode, "Name");
/* 212 */       String valueString = getAttribute(pairNode, "Value");
/* 213 */       String type = getAttribute(pairNode, "Type");
/* 214 */       Serializable value = null;
/*     */ 
/* 216 */       if ((type.equalsIgnoreCase("string")) || (type.equalsIgnoreCase("enum")))
/* 217 */         value = valueString;
/* 218 */       else if (type.equalsIgnoreCase("boolean"))
/* 219 */         value = Boolean.valueOf(Boolean.parseBoolean(valueString));
/* 220 */       else if ((type.equalsIgnoreCase("int")) || (type.equalsIgnoreCase("uint")))
/* 221 */         value = Integer.valueOf(Integer.parseInt(valueString));
/* 222 */       else if (type.equalsIgnoreCase("float")) {
/* 223 */         value = Float.valueOf(Float.parseFloat(valueString));
/*     */       }
/* 225 */       resultMap.put(key, value);
/*     */     }
/*     */ 
/* 228 */     return resultMap;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 239 */     if (args.length != 1) {
/* 240 */       System.err.println("specify config file");
/* 241 */       System.exit(1);
/* 243 */     }DocumentBuilder builder = makeDocBuilder();
/*     */     Document doc;
/*     */     try { doc = builder.parse(new File(args[0]));
/*     */     } catch (Exception e) {
/* 248 */       Log.error(e.toString());
/* 249 */       return;
/*     */     }
/*     */ 
/* 252 */     Node worldDescNode = getMatchingChild(doc, "WorldDescription");
/*     */ 
/* 255 */     Node terrainNode = getMatchingChild(worldDescNode, "Terrain");
/* 256 */     if (Log.loggingDebug)
/* 257 */       Log.debug("toXML: " + toXML(terrainNode));
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.XMLHelper
 * JD-Core Version:    0.6.0
 */