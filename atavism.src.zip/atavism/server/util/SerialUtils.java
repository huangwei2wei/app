/*     */ package atavism.server.util;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.objects.Color;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class SerialUtils
/*     */ {
/*     */   private static final byte valueTypeNull = 0;
/*     */   private static final byte valueTypeString = 1;
/*     */   private static final byte valueTypeLong = 2;
/*     */   private static final byte valueTypeInteger = 3;
/*     */   private static final byte valueTypeBoolean = 4;
/*     */   private static final byte valueTypeBooleanFalse = 4;
/*     */   private static final byte valueTypeBooleanTrue = 5;
/*     */   private static final byte valueTypeFloat = 6;
/*     */   private static final byte valueTypePoint = 7;
/*     */   private static final byte valueTypeAOVector = 8;
/*     */   private static final byte valueTypeQuaternion = 9;
/*     */   private static final byte valueTypeColor = 10;
/*     */   private static final byte valueTypeLinkedList = 11;
/*     */   private static final byte valueTypeHashSet = 12;
/*     */   private static final byte valueTypeHashMap = 13;
/*     */   private static final byte valueTypeObject = 100;
/*  40 */   private static Map<Class, Byte> classToValueTypeMap = null;
/*     */ 
/*     */   private static void initializeClassToValueTypeMap() {
/*  43 */     Long v1 = Long.valueOf(3L);
/*  44 */     Integer v2 = Integer.valueOf(3);
/*  45 */     Boolean v3 = Boolean.valueOf(true);
/*  46 */     Float v4 = Float.valueOf(3.0F);
/*  47 */     classToValueTypeMap = new HashMap();
/*  48 */     classToValueTypeMap.put(new String().getClass(), Byte.valueOf(1));
/*  49 */     classToValueTypeMap.put(v1.getClass(), Byte.valueOf(2));
/*  50 */     classToValueTypeMap.put(v2.getClass(), Byte.valueOf(3));
/*  51 */     classToValueTypeMap.put(v3.getClass(), Byte.valueOf(4));
/*  52 */     classToValueTypeMap.put(v4.getClass(), Byte.valueOf(6));
/*  53 */     classToValueTypeMap.put(new Point().getClass(), Byte.valueOf(7));
/*  54 */     classToValueTypeMap.put(new AOVector().getClass(), Byte.valueOf(8));
/*  55 */     classToValueTypeMap.put(new Quaternion().getClass(), Byte.valueOf(9));
/*  56 */     classToValueTypeMap.put(new Color().getClass(), Byte.valueOf(10));
/*  57 */     classToValueTypeMap.put(new LinkedList().getClass(), Byte.valueOf(11));
/*  58 */     classToValueTypeMap.put(new HashSet().getClass(), Byte.valueOf(12));
/*  59 */     classToValueTypeMap.put(new HashMap().getClass(), Byte.valueOf(13));
/*     */   }
/*     */ 
/*     */   public static void writeEncodedObject(ObjectOutputStream out, Object val)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  65 */     if (classToValueTypeMap == null)
/*  66 */       initializeClassToValueTypeMap();
/*  67 */     if (val == null) {
/*  68 */       out.writeByte(0);
/*     */     } else {
/*  70 */       Class c = val.getClass();
/*  71 */       Byte index = (Byte)classToValueTypeMap.get(c);
/*  72 */       if (index == null)
/*  73 */         index = Byte.valueOf(100);
/*     */       Iterator i$;
/*     */       Iterator i$;
/*  74 */       switch (index.byteValue()) {
/*     */       case 1:
/*  76 */         out.writeByte(1);
/*  77 */         out.writeUTF((String)val);
/*  78 */         break;
/*     */       case 2:
/*  80 */         out.writeByte(2);
/*  81 */         out.writeLong(((Long)val).longValue());
/*  82 */         break;
/*     */       case 3:
/*  84 */         out.writeByte(3);
/*  85 */         out.writeInt(((Integer)val).intValue());
/*  86 */         break;
/*     */       case 4:
/*  88 */         out.writeByte(((Boolean)val).booleanValue() ? 5 : 4);
/*  89 */         break;
/*     */       case 6:
/*  91 */         out.writeByte(6);
/*  92 */         out.writeFloat(((Float)val).floatValue());
/*  93 */         break;
/*     */       case 7:
/*  95 */         out.writeByte(7);
/*  96 */         ((Point)val).writeExternal(out);
/*  97 */         break;
/*     */       case 8:
/*  99 */         out.writeByte(8);
/* 100 */         ((AOVector)val).writeExternal(out);
/* 101 */         break;
/*     */       case 9:
/* 103 */         out.writeByte(9);
/* 104 */         ((Quaternion)val).writeExternal(out);
/* 105 */         break;
/*     */       case 10:
/* 107 */         out.writeByte(10);
/* 108 */         ((Color)val).writeExternal(out);
/* 109 */         break;
/*     */       case 100:
/* 113 */         out.writeByte(100);
/* 114 */         out.writeObject(val);
/* 115 */         break;
/*     */       case 11:
/* 117 */         out.writeByte(11);
/* 118 */         LinkedList list = (LinkedList)val;
/* 119 */         out.writeInt(list.size());
/* 120 */         for (i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/*     */ 
/* 122 */           writeEncodedObject(out, obj);
/*     */         }
/* 124 */         break;
/*     */       case 12:
/* 126 */         out.writeByte(12);
/* 127 */         HashSet set = (HashSet)val;
/* 128 */         out.writeInt(set.size());
/* 129 */         for (i$ = set.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/*     */ 
/* 131 */           writeEncodedObject(out, obj);
/*     */         }
/* 133 */         break;
/*     */       case 13:
/* 135 */         out.writeByte(13);
/* 136 */         HashMap map = (HashMap)val;
/* 137 */         out.writeInt(map.size());
/* 138 */         for (Map.Entry entry : map.entrySet()) {
/* 139 */           out.writeUTF((String)entry.getKey());
/* 140 */           writeEncodedObject(out, entry.getValue());
/*     */         }
/* 142 */         break;
/*     */       default:
/* 144 */         Log.error("WorldManagerClient.writeEncodedObject: index " + index + " out of bounds; class " + c.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Serializable readEncodedObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 152 */     byte typecode = in.readByte();
/*     */     int count;
/* 153 */     switch (typecode) {
/*     */     case 0:
/* 155 */       return null;
/*     */     case 1:
/* 157 */       return in.readUTF();
/*     */     case 2:
/* 159 */       return Long.valueOf(in.readLong());
/*     */     case 3:
/* 161 */       return Integer.valueOf(in.readInt());
/*     */     case 4:
/* 163 */       return Boolean.valueOf(false);
/*     */     case 5:
/* 165 */       return Boolean.valueOf(true);
/*     */     case 6:
/* 167 */       return Float.valueOf(in.readFloat());
/*     */     case 7:
/* 169 */       Point p = new Point();
/* 170 */       p.readExternal(in);
/* 171 */       return p;
/*     */     case 8:
/* 173 */       AOVector v = new AOVector();
/* 174 */       v.readExternal(in);
/* 175 */       return v;
/*     */     case 9:
/* 177 */       Quaternion q = new Quaternion();
/* 178 */       q.readExternal(in);
/* 179 */       return q;
/*     */     case 10:
/* 181 */       Color color = new Color();
/* 182 */       color.readExternal(in);
/* 183 */       return color;
/*     */     case 100:
/* 185 */       return (Serializable)in.readObject();
/*     */     case 11:
/* 187 */       count = in.readInt();
/* 188 */       LinkedList list = new LinkedList();
/* 189 */       for (int i = 0; i < count; i++)
/* 190 */         list.add(readEncodedObject(in));
/* 191 */       return list;
/*     */     case 12:
/* 193 */       count = in.readInt();
/* 194 */       HashSet set = new HashSet();
/* 195 */       for (int i = 0; i < count; i++)
/* 196 */         set.add(readEncodedObject(in));
/* 197 */       return set;
/*     */     case 13:
/* 199 */       count = in.readInt();
/* 200 */       HashMap map = new HashMap();
/* 201 */       for (int i = 0; i < count; i++) {
/* 202 */         String key = in.readUTF();
/* 203 */         Object value = readEncodedObject(in);
/* 204 */         map.put(key, value);
/*     */       }
/* 206 */       return map;
/*     */     }
/* 208 */     Log.error("WorldManagerClient.readObjectUtility: Illegal value type code " + typecode);
/* 209 */     return null;
/*     */   }
/*     */ 
/*     */   public static void writePropertyMap(ObjectOutputStream out, Map<String, Object> propertyMap)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 215 */     out.writeInt(propertyMap == null ? 0 : propertyMap.size());
/* 216 */     if (propertyMap != null)
/* 217 */       for (Map.Entry entry : propertyMap.entrySet()) {
/* 218 */         String key = (String)entry.getKey();
/* 219 */         Log.debug("Writing property map with key: " + key);
/* 220 */         Object val = entry.getValue();
/* 221 */         out.writeUTF(key);
/* 222 */         writeEncodedObject(out, val);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> readPropertyMap(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 229 */     Integer count = Integer.valueOf(in.readInt());
/* 230 */     if (count.intValue() == 0)
/* 231 */       return null;
/* 232 */     Map props = new HashMap();
/* 233 */     for (int i = 0; i < count.intValue(); i++) {
/* 234 */       String key = in.readUTF();
/* 235 */       Log.debug("Reading property map with key: " + key);
/* 236 */       Serializable val = readEncodedObject(in);
/* 237 */       props.put(key, val);
/*     */     }
/* 239 */     return props;
/*     */   }
/*     */ 
/*     */   public static void writeSerializablePropertyMap(ObjectOutputStream out, Map<String, Serializable> propertyMap)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 245 */     out.writeInt(propertyMap == null ? 0 : propertyMap.size());
/* 246 */     for (Map.Entry entry : propertyMap.entrySet()) {
/* 247 */       String key = (String)entry.getKey();
/* 248 */       Log.debug("Writing serializable property map with key: " + key);
/* 249 */       Object val = entry.getValue();
/* 250 */       out.writeUTF(key);
/* 251 */       writeEncodedObject(out, val);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Map<String, Serializable> readSerializablePropertyMap(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 257 */     Integer count = Integer.valueOf(in.readInt());
/* 258 */     if (count.intValue() == 0)
/* 259 */       return null;
/* 260 */     Map props = new HashMap();
/* 261 */     for (int i = 0; i < count.intValue(); i++) {
/* 262 */       String key = in.readUTF();
/* 263 */       Log.debug("Reading serializable property map with key: " + key);
/* 264 */       Serializable val = readEncodedObject(in);
/* 265 */       props.put(key, val);
/*     */     }
/* 267 */     return props;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SerialUtils
 * JD-Core Version:    0.6.0
 */