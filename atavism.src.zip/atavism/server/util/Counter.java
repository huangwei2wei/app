/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class Counter
/*    */ {
/* 30 */   Lock lock = LockFactory.makeLock("CounterLock");
/* 31 */   long counter = 1L;
/*    */ 
/*    */   public Counter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Counter(Long startNum)
/*    */   {
/* 13 */     this.counter = startNum.longValue();
/*    */   }
/*    */ 
/*    */   public int getIntNext() {
/* 17 */     return (int)getNext();
/*    */   }
/*    */ 
/*    */   public long getNext() {
/* 21 */     this.lock.lock();
/*    */     try {
/* 23 */       long l = this.counter++;
/*    */       return l; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.Counter
 * JD-Core Version:    0.6.0
 */