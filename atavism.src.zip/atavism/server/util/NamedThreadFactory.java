/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ 
/*    */ public class NamedThreadFactory
/*    */   implements ThreadFactory
/*    */ {
/*    */   private String namePrefix;
/* 31 */   private int threadCount = 1;
/* 32 */   private boolean daemon = false;
/*    */ 
/*    */   public NamedThreadFactory(String namePrefix)
/*    */   {
/* 10 */     this.namePrefix = namePrefix;
/*    */   }
/*    */ 
/*    */   public Thread newThread(Runnable runnable)
/*    */   {
/* 15 */     Thread thread = new Thread(runnable, this.namePrefix + "-" + this.threadCount++);
/* 16 */     thread.setDaemon(this.daemon);
/* 17 */     return thread;
/*    */   }
/*    */ 
/*    */   public boolean getDaemon()
/*    */   {
/* 22 */     return this.daemon;
/*    */   }
/*    */ 
/*    */   public void setDaemon(boolean flag)
/*    */   {
/* 27 */     this.daemon = flag;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.NamedThreadFactory
 * JD-Core Version:    0.6.0
 */