/*     */ package atavism.server.util;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class ObjectLockManager
/*     */ {
/* 157 */   private Lock lock = LockFactory.makeLock("ObjectLockManager");
/* 158 */   private Map<OID, Lock> lockMap = new HashMap();
/*     */ 
/*     */   public Lock getLock(OID mobOid)
/*     */   {
/*  22 */     this.lock.lock();
/*     */     try {
/*  24 */       Lock objLock = (Lock)this.lockMap.get(mobOid);
/*  25 */       if (objLock == null)
/*     */       {
/*  27 */         objLock = LockFactory.makeLock("ObjectLockManager.ObjLock:" + mobOid);
/*  28 */         this.lockMap.put(mobOid, objLock);
/*     */       }
/*  30 */       Lock localLock1 = objLock;
/*     */       return localLock1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public static void lockAll(Lock[] locks)
/*     */   {
/*  43 */     lockAll(Arrays.asList(locks));
/*     */   }
/*     */ 
/*     */   public static void lockAll(Collection<Lock> locks)
/*     */   {
/*  56 */     for (Lock lockEntry : locks) {
/*  57 */       if (Thread.holdsLock(lockEntry)) {
/*  58 */         Log.warnAndDumpStack("Possible deadlock: lockAll passed lock collection, but some locks are already held");
/*     */       }
/*     */     }
/*  61 */     LinkedList lockedLocks = new LinkedList();
/*     */     while (true) {
/*  63 */       boolean success = true;
/*  64 */       for (Lock lockEntry : locks) {
/*  65 */         if (lockEntry == null) {
/*     */           continue;
/*     */         }
/*  68 */         if (lockEntry.tryLock()) {
/*  69 */           lockedLocks.add(0, lockEntry);
/*     */         } else {
/*  71 */           success = false;
/*  72 */           break;
/*     */         }
/*     */       }
/*  75 */       if (success) break;
/*  76 */       for (Lock lockedLock : lockedLocks) {
/*  77 */         lockedLock.unlock();
/*     */       }
/*  79 */       lockedLocks.clear();
/*  80 */       Thread.yield();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void unlockAll(Collection<Lock> locks)
/*     */   {
/*  96 */     List lockedLocks = new LinkedList(locks);
/*  97 */     Collections.reverse(lockedLocks);
/*  98 */     for (Lock lockedLock : lockedLocks) {
/*  99 */       if (lockedLock == null) {
/*     */         continue;
/*     */       }
/* 102 */       lockedLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean tryLockAll(Collection<Lock> locks, long time)
/*     */   {
/* 119 */     for (Lock lockEntry : locks) {
/* 120 */       if (Thread.holdsLock(lockEntry)) {
/* 121 */         Log.warnAndDumpStack("Possible deadlock: tryLockAll passed lock collection, but some locks are already held");
/*     */       }
/*     */     }
/* 124 */     long start = System.currentTimeMillis();
/* 125 */     LinkedList lockedLocks = new LinkedList();
/*     */     while (true) {
/* 127 */       boolean success = true;
/* 128 */       for (Lock lockEntry : locks) {
/* 129 */         if (lockEntry == null) {
/*     */           continue;
/*     */         }
/* 132 */         if (lockEntry.tryLock()) {
/* 133 */           lockedLocks.add(0, lockEntry);
/*     */         } else {
/* 135 */           success = false;
/* 136 */           break;
/*     */         }
/*     */       }
/* 139 */       if (success) break;
/* 140 */       for (Lock lockedLock : lockedLocks) {
/* 141 */         lockedLock.unlock();
/*     */       }
/* 143 */       lockedLocks.clear();
/* 144 */       Thread.yield();
/* 145 */       if (System.currentTimeMillis() - start > time)
/*     */       {
/* 147 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 152 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.ObjectLockManager
 * JD-Core Version:    0.6.0
 */