package atavism.server.util;

public class AODeadLockException extends Exception
{
  private static final long serialVersionUID = 1L;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.AODeadLockException
 * JD-Core Version:    0.6.0
 */