/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SquareQueue<K, V>
/*     */ {
/* 138 */   protected HashMap<K, SquareQueue<K, V>.SubQueue> subQueues = new HashMap();
/* 139 */   protected LinkedList<SquareQueue<K, V>.SubQueue> queue = new LinkedList();
/*     */   protected String name;
/*     */ 
/*     */   public SquareQueue(String name)
/*     */   {
/*  13 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public synchronized void insert(K key, V value) {
/*  17 */     SubQueue subQueue = (SubQueue)this.subQueues.get(key);
/*  18 */     if (subQueue == null)
/*     */     {
/*  21 */       subQueue = newSubQueue(key);
/*  22 */       subQueue.queue.add(value);
/*  23 */       this.queue.add(subQueue);
/*  24 */       notify();
/*     */     }
/*     */     else {
/*  27 */       subQueue.queue.add(value);
/*  28 */       if (subQueue.unqueued) {
/*  29 */         subQueue.unqueued = false;
/*  30 */         this.queue.add(subQueue);
/*  31 */         notify();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void insert(List<K> keys, V value) {
/*  37 */     for (Iterator i$ = keys.iterator(); i$.hasNext(); ) { Object key = i$.next();
/*  38 */       insert(key, value); }
/*     */   }
/*     */ 
/*     */   public synchronized SquareQueue<K, V>.SubQueue remove()
/*     */     throws InterruptedException
/*     */   {
/*  44 */     while (this.queue.size() == 0) {
/*  45 */       wait();
/*     */     }
/*  47 */     return (SubQueue)this.queue.poll();
/*     */   }
/*     */ 
/*     */   public synchronized void requeue(SquareQueue<K, V>.SubQueue subQueue)
/*     */   {
/*  54 */     subQueue.headValue = null;
/*  55 */     if (subQueue.size() > 0) {
/*  56 */       subQueue.unqueued = false;
/*  57 */       this.queue.add(subQueue);
/*  58 */       notify();
/*     */     }
/*     */     else {
/*  61 */       subQueue.unqueued = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void removeKey(K key)
/*     */   {
/*  68 */     SubQueue subQueue = (SubQueue)this.subQueues.remove(key);
/*  69 */     if (subQueue == null)
/*  70 */       return;
/*  71 */     subQueue.queue.clear();
/*  72 */     Iterator iterator = this.queue.iterator();
/*  73 */     while (iterator.hasNext()) {
/*  74 */       SubQueue pq = (SubQueue)iterator.next();
/*  75 */       if (key.equals(pq.getKey())) {
/*  76 */         iterator.remove();
/*  77 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized int getSQSize()
/*     */   {
/*  84 */     return this.queue.size();
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  88 */     return this.name;
/*     */   }
/*     */ 
/*     */   protected synchronized boolean getNext(SquareQueue<K, V>.SubQueue subQueue)
/*     */   {
/* 119 */     Object headValue = subQueue.queue.poll();
/*     */ 
/* 122 */     if (headValue == null)
/* 123 */       return false;
/* 124 */     subQueue.headValue = headValue;
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */   protected synchronized int getSubQueueSize(SquareQueue<K, V>.SubQueue subQueue) {
/* 129 */     return subQueue.queue.size();
/*     */   }
/*     */ 
/*     */   protected SquareQueue<K, V>.SubQueue newSubQueue(K key) {
/* 133 */     SubQueue subQueue = new SubQueue(key);
/* 134 */     this.subQueues.put(key, subQueue);
/* 135 */     return subQueue;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 143 */     SquareQueue sq = new SquareQueue("main");
/*     */ 
/* 145 */     sq.insert(Long.valueOf(1L), "goober1");
/* 146 */     sq.insert(Long.valueOf(2L), "goober2");
/* 147 */     sq.insert(Long.valueOf(1L), "goober3");
/*     */     try
/*     */     {
/* 153 */       SubQueue subQueue = sq.remove();
/* 154 */       System.out.println("GOT key " + subQueue.getKey());
/* 155 */       if (subQueue.next()) {
/* 156 */         System.out.println("HEAD " + (String)subQueue.getHeadValue());
/*     */       }
/* 158 */       sq.requeue(subQueue);
/*     */ 
/* 160 */       subQueue = sq.remove();
/* 161 */       System.out.println("GOT key " + subQueue.getKey());
/* 162 */       if (subQueue.next()) {
/* 163 */         System.out.println("HEAD " + (String)subQueue.getHeadValue());
/*     */       }
/* 165 */       sq.requeue(subQueue);
/*     */ 
/* 168 */       subQueue = sq.remove();
/* 169 */       System.out.println("GOT key " + subQueue.getKey());
/* 170 */       if (subQueue.next()) {
/* 171 */         System.out.println("HEAD " + (String)subQueue.getHeadValue());
/*     */       }
/* 173 */       sq.requeue(subQueue);
/*     */ 
/* 175 */       subQueue = sq.remove();
/*     */     }
/*     */     catch (InterruptedException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public class SubQueue
/*     */   {
/*     */     K key;
/* 113 */     LinkedList<V> queue = new LinkedList();
/*     */     V headValue;
/* 115 */     boolean unqueued = false;
/*     */ 
/*     */     SubQueue()
/*     */     {
/*  93 */       this.key = key;
/*     */     }
/*     */ 
/*     */     public boolean next() {
/*  97 */       return SquareQueue.this.getNext(this);
/*     */     }
/*     */ 
/*     */     public K getKey() {
/* 101 */       return this.key;
/*     */     }
/*     */ 
/*     */     public V getHeadValue() {
/* 105 */       return this.headValue;
/*     */     }
/*     */ 
/*     */     int size() {
/* 109 */       return SquareQueue.this.getSubQueueSize(this);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SquareQueue
 * JD-Core Version:    0.6.0
 */