/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ public class ServerVersion
/*     */ {
/*     */   public static final String ServerMajorVersion = "2.5.0";
/*     */   public static final int VERSION_LESSER = -1;
/*     */   public static final int VERSION_EQUAL = 0;
/*     */   public static final int VERSION_GREATER = 1;
/*     */   public static final int VERSION_FORMAT_ERROR = -9;
/* 106 */   private static String buildString = null;
/* 107 */   private static String buildDate = null;
/* 108 */   private static String buildNumber = null;
/*     */ 
/*     */   public static String getVersionString()
/*     */   {
/*  10 */     return "2.5.0 " + getBuildNumber() + " (" + getBuildString() + " " + getBuildDate() + ")";
/*     */   }
/*     */ 
/*     */   public static String getBuildString()
/*     */   {
/*  16 */     if (buildString != null) {
/*  17 */       return buildString;
/*     */     }
/*  19 */     return getFieldValue("buildString", "-");
/*     */   }
/*     */ 
/*     */   public static String getBuildDate()
/*     */   {
/*  24 */     if (buildDate != null) {
/*  25 */       return buildDate;
/*     */     }
/*  27 */     return getFieldValue("buildDate", "-");
/*     */   }
/*     */ 
/*     */   public static String getBuildNumber()
/*     */   {
/*  32 */     if (buildNumber != null) {
/*  33 */       return buildNumber;
/*     */     }
/*  35 */     return getFieldValue("buildNumber", "0");
/*     */   }
/*     */ 
/*     */   public static int compareVersionStrings(String leftVersion, String rightVersion)
/*     */   {
/*  46 */     float left = extractVersion(leftVersion);
/*  47 */     float right = extractVersion(rightVersion);
/*  48 */     if ((left == 0.0D) || (right == 0.0D)) {
/*  49 */       return -9;
/*     */     }
/*  51 */     if (left == right)
/*  52 */       return 0;
/*  53 */     if (left < right)
/*  54 */       return -1;
/*  55 */     if (left > right)
/*  56 */       return 1;
/*  57 */     return -9;
/*     */   }
/*     */ 
/*     */   public static float extractVersion(String versionString)
/*     */   {
/*  62 */     int ii = 0;
/*  63 */     for (; ii < versionString.length(); ii++) {
/*  64 */       char c = versionString.charAt(ii);
/*  65 */       if (!Character.isDigit(c))
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*  70 */     if (ii == 0) return 0.0F;
/*  71 */     if (ii == versionString.length()) return 0.0F;
/*  72 */     if (versionString.charAt(ii) != '.') return 0.0F;
/*  73 */     ii++;
/*     */ 
/*  75 */     for (; ii < versionString.length(); ii++) {
/*  76 */       char c = versionString.charAt(ii);
/*  77 */       if (!Character.isDigit(c))
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*  82 */     String versionNumber = versionString.substring(0, ii);
/*     */ 
/*  84 */     float num = Float.parseFloat(versionNumber);
/*  85 */     return num;
/*     */   }
/*     */ 
/*     */   private static String getFieldValue(String fieldName, String defaultValue)
/*     */   {
/*     */     try
/*     */     {
/*  92 */       Class buildInfo = Class.forName("atavism.server.util.BuildInfo");
/*  93 */       Field stringField = buildInfo.getField(fieldName);
/*  94 */       return (String)stringField.get(null);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/*     */     }
/*     */     catch (NoSuchFieldException ex) {
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*     */     }
/* 103 */     return defaultValue;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.ServerVersion
 * JD-Core Version:    0.6.0
 */