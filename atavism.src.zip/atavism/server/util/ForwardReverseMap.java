/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class ForwardReverseMap<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*  15 */   protected Map<K, V> forwardMap = new HashMap();
/*  16 */   protected Map<V, K> reverseMap = new HashMap();
/*  17 */   protected transient Lock lock = LockFactory.makeLock("forwardReverseMapLock");
/*     */ 
/*     */   public void clear()
/*     */   {
/*  23 */     this.lock.lock();
/*     */     try {
/*  25 */       this.forwardMap.clear();
/*  26 */       this.reverseMap.clear();
/*     */     }
/*     */     finally {
/*  29 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/*  34 */     this.lock.lock();
/*     */     try {
/*  36 */       boolean bool = this.forwardMap.containsKey(key);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/*  44 */     this.lock.lock();
/*     */     try {
/*  46 */       boolean bool = this.forwardMap.containsValue(value);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<K, V>> entrySet()
/*     */   {
/*  54 */     this.lock.lock();
/*     */     try {
/*  56 */       Set localSet = this.forwardMap.entrySet();
/*     */       return localSet; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/*  64 */     this.lock.lock();
/*     */     try {
/*  66 */       Object localObject1 = this.forwardMap.get(key);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public K getByValue(Object value)
/*     */   {
/*  77 */     this.lock.lock();
/*     */     try {
/*  79 */       Object localObject1 = this.reverseMap.get(value);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  87 */     this.lock.lock();
/*     */     try {
/*  89 */       boolean bool = this.forwardMap.isEmpty();
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Set<K> keySet() {
/*  96 */     this.lock.lock();
/*     */     try {
/*  98 */       Set localSet = this.forwardMap.keySet();
/*     */       return localSet; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public V put(K key, V value)
/*     */   {
/* 106 */     this.lock.lock();
/*     */     try {
/* 108 */       this.reverseMap.put(value, key);
/* 109 */       Object localObject1 = this.forwardMap.put(key, value);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends K, ? extends V> m) {
/* 116 */     this.lock.lock();
/*     */     try {
/* 118 */       for (i$ = m.keySet().iterator(); i$.hasNext(); ) { Object key = i$.next();
/* 119 */         put(key, m.get(key));
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator i$;
/* 123 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public V remove(Object key) {
/* 128 */     this.lock.lock();
/*     */     try {
/* 130 */       Object v = this.forwardMap.remove(key);
/* 131 */       this.reverseMap.remove(v);
/* 132 */       Object localObject1 = v;
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public K removeByValue(Object value)
/*     */   {
/* 140 */     this.lock.lock();
/*     */     try {
/* 142 */       Object key = this.reverseMap.remove(value);
/* 143 */       if (key == null) {
/* 144 */         localObject1 = null;
/*     */         return localObject1;
/*     */       }
/* 146 */       if (this.forwardMap.remove(key) == null) {
/* 147 */         throw new RuntimeException("forward map did not contain key");
/*     */       }
/* 149 */       Object localObject1 = key;
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public int size() {
/* 156 */     this.lock.lock();
/*     */     try {
/* 158 */       int i = this.forwardMap.size();
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Collection<V> values()
/*     */   {
/* 166 */     this.lock.lock();
/*     */     try {
/* 168 */       Collection localCollection = this.forwardMap.values();
/*     */       return localCollection; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.ForwardReverseMap
 * JD-Core Version:    0.6.0
 */