/*     */ package atavism.server.util;
/*     */ 
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.spec.EncodedKeySpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ public class SecureTokenManager
/*     */ {
/*  58 */   protected static SecureTokenManager instance = null;
/*     */ 
/* 503 */   protected long lastTokenId = 1L;
/*     */ 
/* 510 */   protected long domainKeyId = -1L;
/* 511 */   protected Map<Long, SecretKey> domainKeys = new HashMap();
/*     */ 
/* 514 */   protected Map<Long, PublicKey> masterPublicKeys = new HashMap();
/*     */ 
/* 517 */   protected PrivateKey masterPrivateKey = null;
/* 518 */   protected long masterKeyId = -1L;
/*     */ 
/* 520 */   protected Map<String, IssuerHistory> issuerHistories = new HashMap();
/*     */ 
/*     */   public static SecureTokenManager getInstance()
/*     */   {
/*  60 */     if (instance == null) {
/*  61 */       instance = new SecureTokenManager();
/*     */     }
/*  63 */     return instance;
/*     */   }
/*     */ 
/*     */   public SecureToken importToken(byte[] encodedToken)
/*     */   {
/*  79 */     AOByteBuffer buf = new AOByteBuffer(encodedToken);
/*  80 */     byte version = 0;
/*  81 */     byte type = 0;
/*  82 */     String issuerId = null;
/*  83 */     long tokenId = 0L;
/*  84 */     long keyId = 0L;
/*  85 */     long expiry = 0L;
/*  86 */     TreeMap properties = new TreeMap();
/*  87 */     byte[] authenticator = null;
/*  88 */     boolean valid = true;
/*  89 */     int authedLength = 0;
/*     */ 
/*  95 */     Log.debug("Importing Token: " + buf.toString());
/*     */     try {
/*  97 */       version = buf.getByte();
/*  98 */       type = buf.getByte();
/*  99 */       issuerId = buf.getString();
/* 100 */       tokenId = buf.getLong();
/* 101 */       keyId = buf.getLong();
/* 102 */       expiry = buf.getLong();
/* 103 */       properties = (TreeMap)buf.getEncodedObject();
/* 104 */       authedLength = buf.position();
/* 105 */       authenticator = new byte[buf.remaining()];
/* 106 */       buf.getBytes(authenticator, 0, authenticator.length);
/*     */     }
/*     */     catch (BufferUnderflowException e) {
/* 109 */       Log.exception("SecureTokenManager.importToken: caught exception when decoding token.", e);
/* 110 */       valid = false;
/*     */     }
/*     */     catch (RuntimeException e) {
/* 113 */       Log.exception("SecureTokenManager.importToken: caught exception when decoding token.", e);
/* 114 */       valid = false;
/*     */     }
/*     */ 
/* 118 */     if (version != 1) {
/* 119 */       Log.error("SecureTokenManager.importToken: token version mismatch tokenId=0x" + Long.toHexString(tokenId) + " version=" + version);
/*     */ 
/* 121 */       valid = false;
/*     */     }
/*     */ 
/* 125 */     if ((valid) && 
/* 126 */       (expiry <= System.currentTimeMillis())) {
/* 127 */       valid = false;
/* 128 */       Log.error("SecureTokenManager.importToken: token expired tokenId=0x" + Long.toHexString(tokenId) + " expiry=<" + DateFormat.getInstance().format(new Date(expiry)) + ">");
/*     */     }
/*     */ 
/* 136 */     if (valid) {
/* 137 */       synchronized (this) {
/* 138 */         if (issuerAlreadyUsed(issuerId, tokenId)) {
/* 139 */           valid = false;
/* 140 */           Log.error("SecureTokenManager.importToken: token already used tokenId=0x" + Long.toHexString(tokenId));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 145 */     SecureTokenSpec spec = new SecureTokenSpec(type, issuerId, expiry, properties);
/* 146 */     if ((authenticator == null) || (authenticator.length == 0))
/*     */     {
/* 149 */       Log.info("SecureTokenManager.importToken: token has no authenticator tokenId=0x" + Long.toHexString(tokenId));
/*     */ 
/* 151 */       valid = false;
/*     */     }
/* 153 */     if (valid)
/*     */     {
/* 155 */       buf.rewind();
/* 156 */       byte[] authedData = new byte[authedLength];
/* 157 */       buf.getBytes(authedData, 0, authedData.length);
/*     */ 
/* 159 */       switch (type)
/*     */       {
/*     */       case 1:
/*     */         PublicKey pubKey;
/* 162 */         synchronized (this) {
/* 163 */           pubKey = (PublicKey)this.masterPublicKeys.get(Long.valueOf(keyId));
/*     */         }
/* 165 */         valid = validateMasterAuthenticator(pubKey, authedData, authenticator);
/* 166 */         break;
/*     */       case 2:
/*     */         SecretKey secretKey;
/* 169 */         synchronized (this) {
/* 170 */           secretKey = (SecretKey)this.domainKeys.get(Long.valueOf(keyId));
/*     */         }
/* 172 */         valid = validateDomainAuthenticator(secretKey, authedData, authenticator);
/* 173 */         break;
/*     */       default:
/* 175 */         Log.error("SecureTokenManager.importToken: invalid type=" + type);
/* 176 */         valid = false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 181 */     if (valid) {
/* 182 */       synchronized (this) {
/* 183 */         if (issuerAlreadyUsed(issuerId, tokenId)) {
/* 184 */           valid = false;
/* 185 */           Log.error("SecureTokenManager.importToken: token already used tokenId=0x" + Long.toHexString(tokenId));
/*     */         }
/*     */         else
/*     */         {
/* 189 */           issuerAddToken(issuerId, tokenId, expiry);
/*     */         }
/* 191 */         Log.debug("SecureTokenManager - cleaning up token");
/* 192 */         issuerCleanup(issuerId, System.currentTimeMillis());
/*     */       }
/*     */     }
/*     */ 
/* 196 */     SecureToken token = new SecureToken(spec, version, tokenId, keyId, authenticator, valid);
/* 197 */     return (SecureToken)(SecureToken)token;
/*     */   }
/*     */ 
/*     */   public SecureToken importToken(AOByteBuffer tokenBuf) {
/* 201 */     byte[] encodedToken = new byte[tokenBuf.remaining()];
/* 202 */     tokenBuf.getBytes(encodedToken, 0, encodedToken.length);
/* 203 */     if (Log.loggingDebug) {
/* 204 */       Log.debug("SecureTokenManager.importToken: token=" + Arrays.toString(encodedToken));
/*     */     }
/* 206 */     return importToken(encodedToken);
/*     */   }
/*     */ 
/*     */   public byte[] generateToken(SecureTokenSpec spec)
/*     */   {
/* 215 */     AOByteBuffer buf = new AOByteBuffer(512);
/*     */ 
/* 217 */     SecretKey domainKey = null;
/* 218 */     PrivateKey masterKey = null;
/*     */ 
/* 220 */     byte type = spec.getType();
/*     */     long keyId;
/* 222 */     synchronized (this) {
/* 223 */       switch (type) {
/*     */       case 1:
/* 225 */         if (this.masterKeyId == -1L) {
/* 226 */           Log.error("SecureTokenManager.generateToken: master key not initialized");
/* 227 */           throw new RuntimeException("master key not initialized");
/*     */         }
/* 229 */         keyId = this.masterKeyId;
/* 230 */         masterKey = this.masterPrivateKey;
/* 231 */         break;
/*     */       case 2:
/* 233 */         if (this.domainKeyId == -1L) {
/* 234 */           Log.error("SecureTokenManager.generateToken: domain key not initialized");
/* 235 */           throw new RuntimeException("domain key not initialized");
/*     */         }
/* 237 */         keyId = this.domainKeyId;
/* 238 */         domainKey = (SecretKey)this.domainKeys.get(Long.valueOf(keyId));
/* 239 */         break;
/*     */       default:
/* 241 */         Log.error("SecureTokenManager.generateToken: invalid token type=" + type);
/* 242 */         throw new RuntimeException("invalid token type=" + type);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 247 */     buf.putByte(1);
/* 248 */     buf.putByte(type);
/* 249 */     buf.putString(spec.getIssuerId());
/* 250 */     buf.putLong(nextTokenId());
/* 251 */     buf.putLong(keyId);
/* 252 */     buf.putLong(spec.getExpiry());
/*     */ 
/* 254 */     TreeMap properties = spec.getPropertyMap();
/* 255 */     buf.putEncodedObject(properties);
/*     */ 
/* 257 */     int authedDataLen = buf.position();
/* 258 */     buf.flip();
/* 259 */     byte[] authedData = new byte[authedDataLen];
/* 260 */     buf.getBytes(authedData, 0, authedData.length);
/*     */     byte[] authenticator;
/* 264 */     switch (type) {
/*     */     case 1:
/* 266 */       authenticator = generateMasterAuthenticator(masterKey, authedData);
/* 267 */       break;
/*     */     case 2:
/* 269 */       authenticator = generateDomainAuthenticator(domainKey, authedData);
/* 270 */       break;
/*     */     default:
/* 273 */       Log.error("SecureTokenManager.generateToken: invalid token type=" + type);
/* 274 */       throw new RuntimeException("invalid token type=" + type);
/*     */     }
/*     */ 
/* 277 */     if (authenticator == null) {
/* 278 */       Log.error("SecureTokenManager.generateToken: null authenticator");
/* 279 */       return null;
/*     */     }
/*     */ 
/* 282 */     buf.putBytes(authenticator, 0, authenticator.length);
/* 283 */     byte[] token = new byte[buf.position()];
/* 284 */     buf.flip();
/* 285 */     buf.getBytes(token, 0, token.length);
/* 286 */     return token;
/*     */   }
/*     */ 
/*     */   protected byte[] generateDomainAuthenticator(SecretKey key, byte[] data) {
/* 290 */     if (key == null)
/* 291 */       return null;
/*     */     try
/*     */     {
/* 294 */       Mac mac = Mac.getInstance(key.getAlgorithm());
/* 295 */       mac.init(key);
/* 296 */       return mac.doFinal(data);
/*     */     }
/*     */     catch (NoSuchAlgorithmException e)
/*     */     {
/* 300 */       return null;
/*     */     }
/*     */     catch (InvalidKeyException e)
/*     */     {
/* 304 */       Log.exception("SecureTokenManager.generateDomainAuthenticator: invalid key", e);
/* 305 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (IllegalStateException e)
/*     */     {
/* 309 */       Log.exception("SecureTokenManager.generateDomainAuthenticator: illegal state", e);
/* 310 */     }throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   protected boolean validateDomainAuthenticator(SecretKey key, byte[] data, byte[] authenticator)
/*     */   {
/* 315 */     byte[] newAuthenticator = generateDomainAuthenticator(key, data);
/* 316 */     return Arrays.equals(newAuthenticator, authenticator);
/*     */   }
/*     */ 
/*     */   protected byte[] generateMasterAuthenticator(PrivateKey key, byte[] data) {
/* 320 */     if (key == null) {
/* 321 */       Log.error("SecureTokenManager.generateMasterAuthenticator: null key");
/* 322 */       return null;
/*     */     }
/*     */     try {
/* 325 */       Signature sig = Signature.getInstance(key.getAlgorithm());
/* 326 */       sig.initSign(key);
/* 327 */       sig.update(data);
/* 328 */       return sig.sign();
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/* 331 */       Log.exception("SecureTokenManager.generateMasterAuthenticator: bad key", e);
/*     */ 
/* 333 */       return null;
/*     */     }
/*     */     catch (InvalidKeyException e)
/*     */     {
/* 337 */       Log.exception("SecureTokenManager.generateMasterAuthenticator: invalid key", e);
/* 338 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (SignatureException e)
/*     */     {
/* 342 */       Log.exception("SecureTokenManager.generateMasterAuthenticator: illegal signature state", e);
/* 343 */     }throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   protected boolean validateMasterAuthenticator(PublicKey key, byte[] data, byte[] authenticator)
/*     */   {
/* 348 */     if (key == null) {
/* 349 */       Log.error("SecureTokenManager.validateMasterAuthenticator: key is null");
/* 350 */       return false;
/*     */     }
/*     */     try {
/* 353 */       Signature sig = Signature.getInstance(key.getAlgorithm());
/* 354 */       sig.initVerify(key);
/* 355 */       sig.update(data);
/* 356 */       boolean rv = sig.verify(authenticator);
/* 357 */       if (Log.loggingDebug) {
/* 358 */         Log.debug("SecureTokenManager.validateMasterAuthenticator rv=" + rv);
/*     */       }
/* 360 */       return rv;
/*     */     }
/*     */     catch (NoSuchAlgorithmException e)
/*     */     {
/* 364 */       Log.exception("SecureTokenManager.validateMasterAuthenticator: bad key", e);
/* 365 */       return false;
/*     */     }
/*     */     catch (InvalidKeyException e)
/*     */     {
/* 369 */       Log.exception("SecureTokenManager.validateMasterAuthenticator: invalid key", e);
/* 370 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (SignatureException e)
/*     */     {
/* 374 */       Log.exception("SecureTokenManager.validateMasterAuthenticator: bad signature", e);
/* 375 */     }return false;
/*     */   }
/*     */ 
/*     */   public void registerMasterPublicKey(byte[] encodedPubKey)
/*     */   {
/* 386 */     AOByteBuffer buf = new AOByteBuffer(encodedPubKey);
/*     */ 
/* 389 */     long keyId = buf.getLong();
/* 390 */     String algorithm = buf.getString();
/* 391 */     if (Log.loggingDebug) {
/* 392 */       Log.debug("SecureTokenManager.registerMasterPublicKey: decoding public key keyId=0x" + Long.toHexString(keyId) + " algorithm=" + algorithm);
/*     */     }
/*     */ 
/* 396 */     byte[] keyData = new byte[buf.remaining()];
/* 397 */     buf.getBytes(keyData, 0, keyData.length);
/*     */ 
/* 399 */     EncodedKeySpec keySpec = new X509EncodedKeySpec(keyData);
/*     */ 
/* 401 */     if (this.masterPublicKeys.containsKey(Long.valueOf(keyId))) {
/* 402 */       Log.error("SecureTokenManager.registerMasterPublicKey: key already exists in table keyId=0x" + Long.toHexString(keyId));
/*     */ 
/* 404 */       throw new IllegalArgumentException("master public already exists in table keyId=0x" + Long.toHexString(keyId));
/*     */     }
/*     */     KeyFactory factory;
/*     */     try
/*     */     {
/* 410 */       factory = KeyFactory.getInstance(algorithm);
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/* 413 */       Log.exception("SecureTokenManager.registerMasterPublicKey: could not get KeyFactory instance. keyId=0x" + Long.toHexString(keyId) + " algorithm=" + algorithm, e);
/*     */ 
/* 415 */       throw new RuntimeException(e);
/*     */     }
/*     */     PublicKey pubKey;
/*     */     try {
/* 420 */       pubKey = factory.generatePublic(keySpec);
/*     */     }
/*     */     catch (InvalidKeySpecException e) {
/* 423 */       Log.exception("SecureTokenManager.registerMasterPublicKey: invalid master public key. keyId=0x" + Long.toHexString(keyId), e);
/*     */ 
/* 425 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 428 */     this.masterPublicKeys.put(Long.valueOf(keyId), pubKey);
/*     */   }
/*     */ 
/*     */   public void initMaster(byte[] encodedPrivKey)
/*     */   {
/* 437 */     AOByteBuffer buf = new AOByteBuffer(encodedPrivKey);
/*     */ 
/* 440 */     long keyId = buf.getLong();
/* 441 */     String algorithm = buf.getString();
/* 442 */     if (Log.loggingDebug) {
/* 443 */       Log.debug("SecureTokenManager.initMaster: master key keyId=0x" + Long.toHexString(keyId) + " algorithm=" + algorithm); } 
/*     */ byte[] keyData = new byte[buf.remaining()];
/* 447 */     buf.getBytes(keyData, 0, keyData.length);
/* 448 */     EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyData);
/*     */     KeyFactory factory;
/*     */     try { factory = KeyFactory.getInstance(algorithm);
/*     */     } catch (NoSuchAlgorithmException e)
/*     */     {
/* 455 */       Log.exception("SecureTokenManager.initMaster: could not get KeyFactory instance. algorithm=" + algorithm + " for keyId=0x" + Long.toHexString(keyId), e);
/*     */ 
/* 457 */       throw new RuntimeException(e);
/*     */     }
/*     */     try {
/* 460 */       synchronized (this) {
/* 461 */         this.masterPrivateKey = factory.generatePrivate(keySpec);
/* 462 */         this.masterKeyId = keyId;
/*     */       }
/*     */     }
/*     */     catch (InvalidKeySpecException e) {
/* 466 */       Log.exception("SecureTokenManager.initMaster: invalid master private key. keyId=0x" + Long.toHexString(keyId), e);
/*     */ 
/* 468 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void initDomain(byte[] domainKey)
/*     */   {
/* 480 */     AOByteBuffer buf = new AOByteBuffer(domainKey);
/* 481 */     long domainKeyId = buf.getLong();
/* 482 */     String algorithm = buf.getString();
/* 483 */     if (Log.loggingDebug) {
/* 484 */       Log.debug("SecureTokenManager.initDomain: reading domain key. keyId=0x" + Long.toHexString(domainKeyId) + " algorithm=" + algorithm);
/*     */     }
/*     */ 
/* 487 */     byte[] keyData = new byte[buf.remaining()];
/* 488 */     buf.getBytes(keyData, 0, buf.remaining());
/*     */ 
/* 490 */     if (this.domainKeys.containsKey(Long.valueOf(domainKeyId))) {
/* 491 */       Log.error("SecureTokenManager.initDomain: domain key already exists in table keyId=0x" + Long.toHexString(domainKeyId));
/*     */ 
/* 493 */       throw new IllegalArgumentException("domain key already exists in table keyId=0x" + Long.toHexString(domainKeyId));
/*     */     }
/*     */ 
/* 497 */     SecretKeySpec keySpec = new SecretKeySpec(keyData, algorithm);
/* 498 */     this.domainKeyId = domainKeyId;
/* 499 */     this.domainKeys.put(Long.valueOf(domainKeyId), keySpec);
/*     */   }
/*     */ 
/*     */   protected synchronized long nextTokenId()
/*     */   {
/* 505 */     this.lastTokenId += 1L;
/* 506 */     return this.lastTokenId;
/*     */   }
/*     */ 
/*     */   public byte[] getEncodedDomainKey()
/*     */   {
/* 523 */     return SecureTokenUtil.encodeDomainKey(this.domainKeyId, (SecretKey)this.domainKeys.get(Long.valueOf(this.domainKeyId)));
/*     */   }
/*     */ 
/*     */   public boolean hasDomainKey()
/*     */   {
/* 529 */     boolean result = true;
/* 530 */     if (this.domainKeyId == -1L) {
/* 531 */       result = false;
/*     */     }
/* 533 */     return result;
/*     */   }
/*     */ 
/*     */   protected boolean issuerAlreadyUsed(String issuerId, long tokenId) {
/* 537 */     IssuerHistory issuer = (IssuerHistory)this.issuerHistories.get(issuerId);
/* 538 */     if (issuer == null) {
/* 539 */       return false;
/*     */     }
/* 541 */     return issuer.alreadyUsed(tokenId);
/*     */   }
/*     */ 
/*     */   protected void issuerAddToken(String issuerId, long tokenId, long expiry) {
/* 545 */     IssuerHistory issuer = (IssuerHistory)this.issuerHistories.get(issuerId);
/* 546 */     if (issuer == null) {
/* 547 */       issuer = new IssuerHistory(issuerId);
/* 548 */       this.issuerHistories.put(issuerId, issuer);
/*     */     }
/* 550 */     issuer.addToken(tokenId, expiry);
/*     */   }
/*     */ 
/*     */   protected void issuerCleanup(String issuerId, long time) {
/* 554 */     IssuerHistory issuer = (IssuerHistory)this.issuerHistories.get(issuerId);
/* 555 */     if (issuer == null) {
/* 556 */       return;
/*     */     }
/* 558 */     issuer.cleanup(time);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 615 */     Log.init();
/* 616 */     SecretKey key = SecureTokenUtil.generateDomainKey();
/* 617 */     System.out.println("domain key:");
/* 618 */     System.out.println(key.getFormat() + ", " + key.getAlgorithm());
/* 619 */     System.out.println(Base64.encodeBytes(key.getEncoded()));
/* 620 */     System.out.println("");
/*     */ 
/* 622 */     KeyPair pair = SecureTokenUtil.generateMasterKeyPair();
/* 623 */     PrivateKey priv = pair.getPrivate();
/* 624 */     System.out.println("private key:");
/* 625 */     System.out.println(priv.getFormat() + ", " + priv.getAlgorithm());
/* 626 */     System.out.println(Base64.encodeBytes(priv.getEncoded()));
/* 627 */     System.out.println("");
/* 628 */     PublicKey pub = pair.getPublic();
/* 629 */     System.out.println("public key:");
/* 630 */     System.out.println(pub.getFormat() + ", " + pub.getAlgorithm());
/* 631 */     System.out.println(Base64.encodeBytes(pub.getEncoded()));
/* 632 */     System.out.println("");
/*     */ 
/* 634 */     byte[] encodedPrivKey = SecureTokenUtil.encodeMasterPrivateKey(12L, pair.getPrivate());
/* 635 */     System.out.println("encoded private key:");
/* 636 */     System.out.println(Base64.encodeBytes(encodedPrivKey));
/* 637 */     System.out.println("");
/*     */ 
/* 639 */     byte[] encodedPubKey = SecureTokenUtil.encodeMasterPublicKey(12L, pair.getPublic());
/* 640 */     System.out.println("encoded public key:");
/* 641 */     System.out.println(Base64.encodeBytes(encodedPubKey));
/* 642 */     System.out.println("");
/*     */ 
/* 644 */     byte[] encodedDomainKey = SecureTokenUtil.encodeDomainKey(24L, key);
/* 645 */     System.out.println("encoded domain key:");
/* 646 */     System.out.println(Base64.encodeBytes(encodedDomainKey));
/* 647 */     System.out.println("");
/*     */ 
/* 649 */     getInstance().registerMasterPublicKey(encodedPubKey);
/* 650 */     getInstance().initMaster(encodedPrivKey);
/* 651 */     getInstance().initDomain(encodedDomainKey);
/*     */ 
/* 653 */     SecureTokenSpec masterSpec = new SecureTokenSpec(1, "test", System.currentTimeMillis() + 10000L);
/*     */ 
/* 655 */     masterSpec.setProperty("prop1", "value1");
/*     */ 
/* 657 */     byte[] masterTokenData = getInstance().generateToken(masterSpec);
/* 658 */     System.out.println("master token data:");
/* 659 */     System.out.println(Base64.encodeBytes(masterTokenData));
/* 660 */     System.out.println("");
/*     */ 
/* 662 */     SecureToken masterToken = getInstance().importToken(masterTokenData);
/* 663 */     System.out.println("imported master token:");
/* 664 */     System.out.println(masterToken.toString());
/*     */ 
/* 666 */     SecureTokenSpec domainSpec = new SecureTokenSpec(2, "test", System.currentTimeMillis() + 10000L);
/*     */ 
/* 668 */     domainSpec.setProperty("prop1", "value1");
/*     */ 
/* 670 */     byte[] domainTokenData = getInstance().generateToken(domainSpec);
/* 671 */     System.out.println("domain token data:");
/* 672 */     System.out.println(Base64.encodeBytes(domainTokenData));
/* 673 */     System.out.println("");
/*     */ 
/* 675 */     SecureToken domainToken = getInstance().importToken(domainTokenData);
/* 676 */     System.out.println("imported domain token:");
/* 677 */     System.out.println(domainToken.toString());
/*     */   }
/*     */ 
/*     */   protected class IssuerHistory
/*     */   {
/*     */     protected final String issuerId;
/* 568 */     protected final Set<Long> usedTokenIds = new HashSet();
/*     */ 
/* 571 */     protected final TreeMap<Long, Set<Long>> usedTokens = new TreeMap();
/*     */ 
/*     */     protected IssuerHistory(String issuerId)
/*     */     {
/* 563 */       this.issuerId = issuerId;
/*     */     }
/*     */ 
/*     */     public boolean alreadyUsed(long tokenId)
/*     */     {
/* 574 */       return this.usedTokenIds.contains(Long.valueOf(tokenId));
/*     */     }
/*     */ 
/*     */     protected void addToken(long tokenId, long expiry) {
/* 578 */       this.usedTokenIds.add(Long.valueOf(tokenId));
/* 579 */       Set tokenIdList = (Set)this.usedTokens.get(Long.valueOf(expiry));
/* 580 */       if (tokenIdList == null) {
/* 581 */         tokenIdList = new HashSet();
/* 582 */         this.usedTokens.put(Long.valueOf(expiry), tokenIdList);
/*     */       }
/* 584 */       tokenIdList.add(Long.valueOf(tokenId));
/*     */     }
/*     */ 
/*     */     protected void cleanup(long time)
/*     */     {
/* 589 */       Log.debug("IssuerHistory - cleaning up tokens");
/*     */       while (true)
/*     */       {
/* 592 */         if (this.usedTokens.size() == 0) {
/* 593 */           Log.debug("IssuerHistory - no tokens");
/* 594 */           break;
/*     */         }
/* 596 */         Long expiry = (Long)this.usedTokens.firstKey();
/*     */ 
/* 598 */         if (expiry.longValue() >= time) {
/* 599 */           Log.debug("IssuerHistory - no tokens older than time");
/* 600 */           break;
/*     */         }
/*     */ 
/* 603 */         for (Long tokenId : (Set)this.usedTokens.get(expiry)) {
/* 604 */           Log.debug("IssuerHistory - removing usedtokenId: " + tokenId);
/* 605 */           this.usedTokenIds.remove(tokenId);
/*     */         }
/* 607 */         Log.debug("IssuerHistory - removing usedtoken: " + expiry);
/* 608 */         this.usedTokens.remove(expiry);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SecureTokenManager
 * JD-Core Version:    0.6.0
 */