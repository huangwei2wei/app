package atavism.server.util;

public abstract interface SQCallback<K, V>
{
  public abstract void doWork(K paramK, V paramV);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SQCallback
 * JD-Core Version:    0.6.0
 */