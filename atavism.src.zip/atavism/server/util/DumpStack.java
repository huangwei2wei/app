/*    */ package atavism.server.util;
/*    */ 
/*    */ public class DumpStack
/*    */ {
/*    */   public static String getTrace(StackTraceElement[] stackArray)
/*    */   {
/*  6 */     String stackTrace = "";
/*  7 */     for (int i = 0; i < stackArray.length; i++) {
/*  8 */       stackTrace = stackTrace + "  stack" + i + "=" + stackArray[i].toString() + "\n";
/*    */     }
/*    */ 
/* 11 */     return stackTrace;
/*    */   }
/*    */ 
/*    */   public static String getTrace(Throwable t) {
/* 15 */     StackTraceElement[] stackArray = t.getStackTrace();
/* 16 */     String stackTrace = "";
/* 17 */     for (int i = 0; i < stackArray.length; i++) {
/* 18 */       stackTrace = stackTrace + "  stack" + i + "=" + stackArray[i].toString() + "\n";
/*    */     }
/*    */ 
/* 21 */     return stackTrace;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.DumpStack
 * JD-Core Version:    0.6.0
 */