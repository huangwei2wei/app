/*    */ package atavism.server.util;
/*    */ 
/*    */ public class TimingMeter
/*    */ {
/*    */   public String title;
/*    */   public String category;
/*    */   public boolean enabled;
/*    */   public boolean accumulate;
/*    */   public long addedTime;
/*    */   public long addStart;
/*    */   public int stackDepth;
/*    */   protected short meterId;
/*    */ 
/*    */   protected TimingMeter(String title, String category, short meterId)
/*    */   {
/*  6 */     this.title = title;
/*  7 */     this.category = category;
/*  8 */     this.meterId = meterId;
/*  9 */     this.enabled = true;
/* 10 */     this.accumulate = false;
/*    */   }
/*    */ 
/*    */   public void Enter()
/*    */   {
/* 30 */     if ((MeterManager.Collecting) && (this.enabled))
/* 31 */       MeterManager.AddEvent(this, MeterManager.ekEnter);
/*    */   }
/*    */ 
/*    */   public void Exit() {
/* 35 */     if ((MeterManager.Collecting) && (this.enabled))
/* 36 */       MeterManager.AddEvent(this, MeterManager.ekExit);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.TimingMeter
 * JD-Core Version:    0.6.0
 */