/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class SQThreadPool
/*     */   implements Runnable
/*     */ {
/*     */   static final int MIN_THREADS = 8;
/*     */   static final int MAX_THREADS = 40;
/*     */   static final int MIN_RUN_TIME = 15000;
/*  20 */   protected static ThreadLocal<SQThreadPool> selfPool = new ThreadLocal();
/*     */ 
/*  28 */   protected static ThreadLocal<ThreadStatus> threadStatus = new ThreadLocal();
/*     */   static final int STATUS_NORMAL = 0;
/*     */   static final int STATUS_BLOCKED = 1;
/*     */   protected SquareQueue sq;
/*     */   protected SQCallback callback;
/* 152 */   protected int total = 0;
/* 153 */   protected int running = 0;
/* 154 */   protected int blocking = 0;
/* 155 */   protected int threadId = 1;
/*     */ 
/*     */   public SQThreadPool(SquareQueue sq, SQCallback callback)
/*     */   {
/*  10 */     this.sq = sq;
/*  11 */     this.callback = callback;
/*     */ 
/*  13 */     this.total = 8;
/*  14 */     for (int ii = 0; ii < this.total; ii++) {
/*  15 */       new Thread(this, "SQ-" + sq.getName() + "-" + this.threadId).start();
/*  16 */       this.threadId += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SQThreadPool getRunningPool()
/*     */   {
/*  33 */     return (SQThreadPool)selfPool.get();
/*     */   }
/*     */ 
/*     */   public synchronized void runningThreadWillBlock() {
/*  37 */     ThreadStatus myStatus = (ThreadStatus)threadStatus.get();
/*  38 */     if (myStatus == null) {
/*  39 */       throw new RuntimeException("Not an SQ thread");
/*     */     }
/*  41 */     if (myStatus.status == 1) {
/*  42 */       throw new RuntimeException("Nested blocking for SQ thread");
/*     */     }
/*     */ 
/*  45 */     this.blocking += 1;
/*  46 */     myStatus.status = 1;
/*  47 */     if (Log.loggingDebug)
/*  48 */       Log.debug("SQ-" + this.sq.getName() + ": runningThreadWillBlock: " + this.blocking + "/" + this.running + "/" + this.total);
/*  49 */     if ((this.blocking == this.total) && (this.total < 40)) {
/*  50 */       this.total += 1;
/*  51 */       if (Log.loggingDebug)
/*  52 */         Log.debug("SQ-" + this.sq.getName() + ": Starting new thread");
/*  53 */       new Thread(this, "SQ-" + this.sq.getName() + "-" + this.threadId).start();
/*  54 */       this.threadId += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void doneBlocking() {
/*  58 */     ThreadStatus myStatus = (ThreadStatus)threadStatus.get();
/*  59 */     if (myStatus == null) {
/*  60 */       throw new RuntimeException("Not an SQ thread");
/*     */     }
/*  62 */     if (myStatus.status != 1) {
/*  63 */       throw new RuntimeException("Nested blocking for SQ thread");
/*     */     }
/*     */ 
/*  66 */     this.blocking -= 1;
/*  67 */     myStatus.status = 0;
/*     */   }
/*     */ 
/*     */   private boolean retiring()
/*     */   {
/*  77 */     return (this.total > 8) && (this.total - this.blocking > 1) && (this.sq.getSQSize() < 8);
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  83 */     if (Log.loggingInfo)
/*  84 */       Log.info("SQ-" + this.sq.getName() + ": Started new thread");
/*  85 */     String title = "SQThreadPool " + this.sq.getName();
/*  86 */     selfPool.set(this);
/*  87 */     threadStatus.set(new ThreadStatus(0));
/*  88 */     SquareQueue.SubQueue pq = null;
/*  89 */     long startTime = System.currentTimeMillis();
/*     */     while (true)
/*     */     {
/*     */       try
/*     */       {
/*  95 */         pq = this.sq.remove();
/*     */         try
/*     */         {
/* 100 */           if (!pq.next()) {
/*     */             continue;
/*     */           }
/* 103 */           synchronized (this) {
/* 104 */             this.running += 1;
/*     */           }
/* 106 */           this.callback.doWork(pq.getHeadValue(), pq.getKey());
/*     */ 
/* 114 */           long runTime = System.currentTimeMillis() - startTime;
/* 115 */           boolean retire = false;
/* 116 */           synchronized (this) {
/* 117 */             this.running -= 1;
/* 118 */             if ((runTime > 15000L) && (retiring()))
/* 119 */               retire = true;
/*     */           }
/* 121 */           this.sq.requeue(pq);
/* 122 */           if (retire)
/* 123 */             break;
/*     */         }
/*     */         finally
/*     */         {
/* 114 */           long runTime = System.currentTimeMillis() - startTime;
/* 115 */           boolean retire = false;
/* 116 */           synchronized (this) {
/* 117 */             this.running -= 1;
/* 118 */             if ((runTime > 15000L) && (retiring()))
/* 119 */               retire = true;
/*     */           }
/* 121 */           this.sq.requeue(pq);
/* 122 */           if (!retire) continue; 
/*     */         }
/* 123 */         break;
/* 124 */         throw localObject3;
/*     */ 
/* 134 */         continue;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 127 */         Log.exception(title, e);
/*     */ 
/* 130 */         ThreadStatus myStatus = (ThreadStatus)threadStatus.get();
/* 131 */         if (myStatus.status == 1) {
/* 132 */           doneBlocking();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 137 */     synchronized (this) {
/* 138 */       this.total -= 1;
/* 139 */       if (Log.loggingInfo)
/* 140 */         Log.info("SQ-" + this.sq.getName() + ": Retiring thread: " + this.blocking + "/" + this.running + "/" + this.total);
/*     */     }
/*     */   }
/*     */ 
/*     */   public SquareQueue getSquareQueue()
/*     */   {
/* 146 */     return this.sq;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 169 */     SquareQueue sq = new SquareQueue("test");
/*     */ 
/* 171 */     sq.insert(Long.valueOf(1L), "goober1");
/* 172 */     sq.insert(Long.valueOf(2L), "goober2");
/* 173 */     sq.insert(Long.valueOf(1L), "goober3");
/*     */ 
/* 175 */     TestSQCallback callback = new TestSQCallback();
/* 176 */     new SQThreadPool(sq, callback);
/*     */ 
/* 178 */     SQThreadPool localPool = getRunningPool();
/* 179 */     System.out.println("localPool " + localPool);
/*     */ 
/* 181 */     Object o = new Object();
/* 182 */     synchronized (o) {
/*     */       try { o.wait();
/*     */       }
/*     */       catch (InterruptedException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class TestSQCallback<K, V>
/*     */     implements SQCallback<K, V>
/*     */   {
/*     */     public void doWork(K key, V value)
/*     */     {
/* 162 */       System.out.println("CALLBACK key=" + key + " value=" + value);
/* 163 */       SQThreadPool localPool = SQThreadPool.getRunningPool();
/* 164 */       System.out.println("CALLBACK localPool " + localPool);
/*     */     }
/*     */   }
/*     */ 
/*     */   class ThreadStatus
/*     */   {
/*     */     public int status;
/*     */ 
/*     */     ThreadStatus(int status)
/*     */     {
/*  24 */       this.status = status;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SQThreadPool
 * JD-Core Version:    0.6.0
 */