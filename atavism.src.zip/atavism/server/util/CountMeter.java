/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class CountMeter
/*    */ {
/*    */   private String name;
/* 57 */   Lock lock = LockFactory.makeLock("CounterLock");
/* 58 */   private int count = 0;
/* 59 */   private long intervalMS = 10000L;
/* 60 */   private long lastRun = System.currentTimeMillis();
/* 61 */   private boolean logging = true;
/*    */ 
/*    */   public CountMeter(String name)
/*    */   {
/* 13 */     this.name = name; } 
/* 17 */   public void add() { boolean logCount = false;
/* 18 */     int currentCount = 0;
/*    */ 
/* 20 */     this.lock.lock();
/*    */     long elapsed;
/*    */     try { this.count += 1;
/* 23 */       long now = System.currentTimeMillis();
/* 24 */       elapsed = now - this.lastRun;
/* 25 */       if (elapsed > this.intervalMS) {
/* 26 */         currentCount = this.count;
/* 27 */         this.count = 0;
/* 28 */         logCount = true;
/* 29 */         this.lastRun = now;
/*    */       }
/*    */     } finally
/*    */     {
/* 33 */       this.lock.unlock();
/*    */     }
/* 35 */     if ((logCount) && (this.logging))
/* 36 */       Log.info("CountMeter: counter=" + getName() + " count=" + currentCount + " elapsed=" + elapsed);
/*    */   }
/*    */ 
/*    */   public int getCount()
/*    */   {
/* 42 */     return this.count;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 46 */     this.name = name;
/*    */   }
/*    */   public String getName() {
/* 49 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setLogging(boolean enable) {
/* 53 */     this.logging = enable;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.CountMeter
 * JD-Core Version:    0.6.0
 */