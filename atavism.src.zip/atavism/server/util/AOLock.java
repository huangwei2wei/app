/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public class AOLock extends ReentrantLock
/*     */ {
/* 142 */   String threadName = null;
/* 143 */   String lockName = "unknown";
/*     */ 
/* 148 */   private List<LStack> stackTraceList = new LinkedList();
/*     */ 
/* 210 */   static Set<AOLock> lockSet = new HashSet();
/*     */ 
/* 219 */   static int DefaultLockTimeoutMS = 30000;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public AOLock(String name)
/*     */   {
/*  21 */     synchronized (lockSet) {
/*  22 */       lockSet.add(this);
/*     */     }
/*  24 */     this.lockName = name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  28 */     this.lockName = name;
/*     */   }
/*     */ 
/*     */   public String getLockName() {
/*  32 */     return this.lockName;
/*     */   }
/*     */ 
/*     */   public void lock() {
/*  36 */     lock(DefaultLockTimeoutMS);
/*     */   }
/*     */ 
/*     */   public void lock(long lockTimeoutMS)
/*     */   {
/*  43 */     Throwable t = new Throwable();
/*  44 */     synchronized (this) {
/*  45 */       this.stackTraceList.add(new LStack(0, t.getStackTrace()));
/*     */     }
/*     */ 
/*  49 */     boolean acquiredLock = false;
/*     */     try {
/*  51 */       acquiredLock = super.tryLock(lockTimeoutMS, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (Exception e) {
/*  54 */       System.err.println("aolock.lock: got exception: " + e);
/*  55 */       System.exit(-1);
/*     */     }
/*  57 */     if (acquiredLock)
/*     */     {
/*  59 */       synchronized (this) {
/*  60 */         this.stackTraceList.add(new LStack(2, t.getStackTrace()));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  65 */       throwException();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unlock()
/*     */   {
/*  73 */     Throwable t = new Throwable();
/*  74 */     new LStack(1, t.getStackTrace());
/*     */ 
/*  76 */     super.unlock();
/*     */ 
/*  79 */     synchronized (this) {
/*  80 */       if (!isHeldByCurrentThread())
/*     */       {
/*  82 */         this.stackTraceList.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized List getStackTraceList()
/*     */   {
/*  94 */     return new LinkedList(this.stackTraceList);
/*     */   }
/*     */ 
/*     */   synchronized void getStackTraceString()
/*     */   {
/* 101 */     System.err.println("-----------------------------------------\nstacktrace for lock " + getLockName() + "\n");
/*     */ 
/* 103 */     Iterator iter = this.stackTraceList.iterator();
/* 104 */     while (iter.hasNext()) {
/* 105 */       LStack lstack = (LStack)iter.next();
/* 106 */       System.err.println("trace=" + lstack.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   void throwException()
/*     */   {
/* 113 */     System.err.println("AOLock: apparent deadlock, lock in question is: " + this.lockName + ", thread=" + Thread.currentThread().getName() + "\n" + ", the lock's stack trace follows:\n");
/*     */ 
/* 117 */     Thread.dumpStack();
/* 118 */     String msg = "AOLock: apparent deadlock, lock in question is: " + this.lockName + ", thread=" + Thread.currentThread().getName();
/*     */ 
/* 120 */     getStackTraceString();
/*     */ 
/* 124 */     synchronized (lockSet) {
/* 125 */       System.err.println("AOLock: going through global lock set to print debug info, total number of locks: " + lockSet.size());
/* 126 */       Iterator iter = lockSet.iterator();
/* 127 */       int i = 0;
/* 128 */       while (iter.hasNext()) {
/* 129 */         AOLock l = (AOLock)iter.next();
/* 130 */         if (l.isLocked()) {
/* 131 */           System.err.println("lock being used: " + i);
/* 132 */           l.getStackTraceString();
/*     */         }
/* 134 */         i++;
/*     */       }
/*     */     }
/* 137 */     System.err.println("AOLock: deadlock info:\n" + msg + "\n----End of deadlock info----");
/*     */ 
/* 139 */     throw new RuntimeException(msg);
/*     */   }
/*     */ 
/*     */   public static void setDeadlockTimeout(int timeoutMS)
/*     */   {
/* 216 */     System.err.println("SET DEADLOCK TIMEOUT TO " + timeoutMS);
/* 217 */     DefaultLockTimeoutMS = timeoutMS;
/*     */   }
/*     */ 
/*     */   static class LStack
/*     */   {
/* 196 */     String threadName = null;
/* 197 */     int action = -1;
/* 198 */     StackTraceElement[] stackArray = null;
/* 199 */     long time = -1L;
/*     */     public static final int LOCK_ACTION = 0;
/*     */     public static final int UNLOCK_ACTION = 1;
/*     */     public static final int LOCK_ACQUIRED = 2;
/*     */ 
/*     */     LStack(int action, StackTraceElement[] array)
/*     */     {
/* 162 */       this.threadName = Thread.currentThread().getName();
/* 163 */       this.action = action;
/* 164 */       this.stackArray = array;
/* 165 */       this.time = System.currentTimeMillis();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 169 */       String actionString = null;
/* 170 */       if (this.action == 0) {
/* 171 */         actionString = "LOCK_ATTEMPT";
/*     */       }
/* 173 */       else if (this.action == 1) {
/* 174 */         actionString = "UNLOCK";
/*     */       }
/* 176 */       else if (this.action == 2) {
/* 177 */         actionString = "ACQUIRED";
/*     */       }
/*     */       else {
/* 180 */         actionString = "UNKNOWN";
/*     */       }
/*     */ 
/* 183 */       if (this.stackArray == null) {
/* 184 */         return actionString + ":stack is empty";
/*     */       }
/*     */ 
/* 187 */       String msg = "\n,thread=" + this.threadName + ",action=" + actionString + ",time=" + this.time + "\n";
/*     */ 
/* 191 */       for (int i = 0; i < this.stackArray.length; i++) {
/* 192 */         msg = msg + "  stack" + i + "=" + this.stackArray[i].toString() + "\n";
/*     */       }
/* 194 */       return msg;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.AOLock
 * JD-Core Version:    0.6.0
 */