/*     */ package atavism.server.util;
/*     */ 
/*     */ import atavism.server.engine.PropertyFileReader;
/*     */ import atavism.server.marshalling.MarshallingRuntime;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.RuntimeMXBean;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class InitLogAndPid
/*     */ {
/*     */   public static Properties initLogAndPid(String[] args)
/*     */   {
/*  19 */     return initLogAndPid(args, null, null);
/*     */   }
/*     */ 
/*     */   public static Properties initLogAndPid(String[] args, String worldName, String hostName)
/*     */   {
/*  27 */     boolean disableLogs = System.getProperty("atavism.disable_logs", "false").equals("true");
/*     */ 
/*  29 */     Log.init();
/*     */ 
/*  31 */     String pid = "?";
/*  32 */     RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
/*     */ 
/*  34 */     pid = runtimeBean.getName();
/*     */ 
/*  36 */     Properties properties = readAndParseProperties(args, worldName, hostName);
/*     */ 
/*  44 */     String logLevelString = properties.getProperty("atavism.log_level");
/*     */ 
/*  46 */     Integer logLevel = null;
/*  47 */     if (logLevelString != null)
/*     */       try {
/*  49 */         logLevel = Integer.valueOf(Integer.parseInt(logLevelString.trim()));
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*  54 */     if (!disableLogs)
/*  55 */       Log.init(properties);
/*  56 */     else if (logLevel != null) {
/*  57 */       Log.setLogLevel(logLevel.intValue());
/*     */     }
/*  59 */     Log.info("pid " + pid);
/*  60 */     writePidFile(args, pid);
/*     */ 
/*  62 */     Log.debug("Using property file " + PropertyFileReader.propFile);
/*  63 */     Log.debug("Properties are:");
/*     */ 
/*  65 */     Enumeration en = properties.propertyNames();
/*  66 */     while (en.hasMoreElements()) {
/*  67 */       String sKey = (String)en.nextElement();
/*  68 */       Log.debug("    " + sKey + " = " + properties.getProperty(sKey));
/*     */     }
/*     */ 
/*  71 */     if (logLevel != null) {
/*  72 */       Log.setLogLevel(logLevel.intValue());
/*     */     }
/*  74 */     Log.info("The log level is " + Log.getLogLevel());
/*     */ 
/*  76 */     String build = properties.getProperty("atavism.build");
/*  77 */     if (build != null) {
/*  78 */       Log.info("Atavism Server Build " + build);
/*     */     }
/*     */ 
/*  81 */     Log.info("Atavism server version " + ServerVersion.getVersionString());
/*     */ 
/*  84 */     String typeNumFileName = getTypeNumbersArg(args);
/*  85 */     if (typeNumFileName != "") {
/*  86 */       MarshallingRuntime.initializeBatch(typeNumFileName);
/*     */     }
/*  88 */     return properties;
/*     */   }
/*     */ 
/*     */   public static String getTypeNumbersArg(String[] args) {
/*  92 */     for (int i = 0; i < args.length - 1; i++) {
/*  93 */       if (args[i].equals("-t"))
/*  94 */         return args[(i + 1)];
/*     */     }
/*  96 */     return "";
/*     */   }
/*     */ 
/*     */   public static Properties readAndParseProperties(String[] args, String worldName, String hostName)
/*     */   {
/* 103 */     PropertyFileReader pfr = new PropertyFileReader();
/* 104 */     Properties properties = null;
/* 105 */     if (PropertyFileReader.usePropFile) {
/* 106 */       properties = pfr.readPropFile();
/*     */     }
/*     */ 
/* 109 */     String worldConfigDir = System.getenv("AO_WORLD_CONFIG");
/* 110 */     if ((worldName != null) && (worldConfigDir != null)) {
/* 111 */       properties = readPropertyFile(worldConfigDir + "/world.properties", properties);
/*     */     }
/*     */ 
/* 115 */     if ((hostName != null) && (worldConfigDir != null)) {
/* 116 */       String propfilename = worldConfigDir + "/" + hostName + ".properties";
/* 117 */       properties = readPropertyFile(propfilename, properties);
/*     */     }
/*     */ 
/* 120 */     properties = parsePropertyArgs(args, properties);
/* 121 */     return properties;
/*     */   }
/*     */ 
/*     */   private static Properties readPropertyFile(String fileName, Properties properties)
/*     */   {
/* 127 */     File propertyFile = new File(fileName);
/* 128 */     if (propertyFile.exists()) {
/* 129 */       Properties overrideProperties = new Properties(properties);
/*     */       try {
/* 131 */         overrideProperties.load(new FileInputStream(propertyFile));
/* 132 */         properties = overrideProperties;
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 136 */         Log.exception("Loading properties file " + fileName, e);
/*     */       }
/*     */     }
/* 139 */     return properties;
/*     */   }
/*     */ 
/*     */   private static Properties parsePropertyArgs(String[] args, Properties defaults)
/*     */   {
/* 145 */     Properties properties = new Properties(defaults);
/* 146 */     for (int ii = 0; ii < args.length; ii++) {
/* 147 */       if ((args[ii].startsWith("-P")) && (args[ii].indexOf(61) != -1)) {
/* 148 */         int equal = args[ii].indexOf(61);
/* 149 */         String key = args[ii].substring(2, equal);
/* 150 */         String value = args[ii].substring(equal + 1);
/* 151 */         properties.put(key, value);
/*     */       }
/* 153 */       else if (args[ii].equals("-p")) {
/* 154 */         ii++;
/* 155 */         if (ii >= args.length) {
/* 156 */           Log.error("Missing file name for -p");
/* 157 */           break;
/*     */         }
/* 159 */         properties = readPropertyFile(args[ii], properties);
/*     */       }
/*     */     }
/* 162 */     return properties;
/*     */   }
/*     */ 
/*     */   private static void writePidFile(String[] argv, String pid)
/*     */   {
/* 167 */     String pidFileName = null;
/* 168 */     for (int ii = 0; ii < argv.length; ii++) {
/* 169 */       if (argv[ii].equals("--pid")) {
/* 170 */         pidFileName = argv[(ii + 1)];
/* 171 */         break;
/*     */       }
/*     */     }
/* 174 */     if (pidFileName == null) {
/* 175 */       return;
/*     */     }
/* 177 */     int nDigits = 0;
/* 178 */     for (int ii = 0; (ii < pid.length()) && 
/* 179 */       (Character.isDigit(pid.charAt(ii))); ii++)
/*     */     {
/* 180 */       nDigits++;
/*     */     }
/*     */ 
/* 184 */     if (nDigits == 0)
/* 185 */       return;
/*     */     try
/*     */     {
/* 188 */       FileOutputStream pidFile = new FileOutputStream(pidFileName);
/* 189 */       pidFile.write((pid.substring(0, nDigits) + "\n").getBytes());
/* 190 */       pidFile.close();
/*     */     }
/*     */     catch (IOException e) {
/* 193 */       Log.exception(pidFileName, e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.InitLogAndPid
 * JD-Core Version:    0.6.0
 */