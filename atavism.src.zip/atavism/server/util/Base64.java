/*      */ package atavism.server.util;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FilterInputStream;
/*      */ import java.io.FilterOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import java.util.zip.GZIPOutputStream;
/*      */ 
/*      */ public class Base64
/*      */ {
/*      */   public static final int NO_OPTIONS = 0;
/*      */   public static final int ENCODE = 1;
/*      */   public static final int DECODE = 0;
/*      */   public static final int GZIP = 2;
/*      */   public static final int DONT_BREAK_LINES = 8;
/*      */   public static final int URL_SAFE = 16;
/*      */   public static final int ORDERED = 32;
/*      */   private static final int MAX_LINE_LENGTH = 76;
/*      */   private static final byte EQUALS_SIGN = 61;
/*      */   private static final byte NEW_LINE = 10;
/*      */   private static final String PREFERRED_ENCODING = "UTF-8";
/*      */   private static final byte WHITE_SPACE_ENC = -5;
/*      */   private static final byte EQUALS_SIGN_ENC = -1;
/*  159 */   private static final byte[] _STANDARD_ALPHABET = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*  178 */   private static final byte[] _STANDARD_DECODABET = { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9 };
/*      */ 
/*  221 */   private static final byte[] _URL_SAFE_ALPHABET = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
/*      */ 
/*  238 */   private static final byte[] _URL_SAFE_DECODABET = { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, 63, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9 };
/*      */ 
/*  285 */   private static final byte[] _ORDERED_ALPHABET = { 45, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122 };
/*      */ 
/*  304 */   private static final byte[] _ORDERED_DECODABET = { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 0, -9, -9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -9, -9, -9, -1, -9, -9, -9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, -9, -9, -9, -9, 37, -9, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, -9, -9, -9, -9 };
/*      */ 
/*      */   private static final byte[] getAlphabet(int options)
/*      */   {
/*  356 */     if ((options & 0x10) == 16) return _URL_SAFE_ALPHABET;
/*  357 */     if ((options & 0x20) == 32) return _ORDERED_ALPHABET;
/*  358 */     return _STANDARD_ALPHABET;
/*      */   }
/*      */ 
/*      */   private static final byte[] getDecodabet(int options)
/*      */   {
/*  372 */     if ((options & 0x10) == 16) return _URL_SAFE_DECODABET;
/*  373 */     if ((options & 0x20) == 32) return _ORDERED_DECODABET;
/*  374 */     return _STANDARD_DECODABET;
/*      */   }
/*      */ 
/*      */   public static final void main(String[] args)
/*      */   {
/*  391 */     if (args.length < 3) {
/*  392 */       usage("Not enough arguments.");
/*      */     }
/*      */     else {
/*  395 */       String flag = args[0];
/*  396 */       String infile = args[1];
/*  397 */       String outfile = args[2];
/*  398 */       if (flag.equals("-e")) {
/*  399 */         encodeFileToFile(infile, outfile);
/*      */       }
/*  401 */       else if (flag.equals("-d")) {
/*  402 */         decodeFileToFile(infile, outfile);
/*      */       }
/*      */       else
/*  405 */         usage("Unknown flag: " + flag);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final void usage(String msg)
/*      */   {
/*  417 */     System.err.println(msg);
/*  418 */     System.err.println("Usage: java Base64 -e|-d inputfile outputfile");
/*      */   }
/*      */ 
/*      */   private static byte[] encode3to4(byte[] b4, byte[] threeBytes, int numSigBytes, int options)
/*      */   {
/*  442 */     encode3to4(threeBytes, 0, numSigBytes, b4, 0, options);
/*  443 */     return b4;
/*      */   }
/*      */ 
/*      */   private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset, int options)
/*      */   {
/*  474 */     byte[] ALPHABET = getAlphabet(options);
/*      */ 
/*  487 */     int inBuff = (numSigBytes > 0 ? source[srcOffset] << 24 >>> 8 : 0) | (numSigBytes > 1 ? source[(srcOffset + 1)] << 24 >>> 16 : 0) | (numSigBytes > 2 ? source[(srcOffset + 2)] << 24 >>> 24 : 0);
/*      */ 
/*  491 */     switch (numSigBytes)
/*      */     {
/*      */     case 3:
/*  494 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  495 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  496 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/*  497 */       destination[(destOffset + 3)] = ALPHABET[(inBuff & 0x3F)];
/*  498 */       return destination;
/*      */     case 2:
/*  501 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  502 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  503 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/*  504 */       destination[(destOffset + 3)] = 61;
/*  505 */       return destination;
/*      */     case 1:
/*  508 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  509 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  510 */       destination[(destOffset + 2)] = 61;
/*  511 */       destination[(destOffset + 3)] = 61;
/*  512 */       return destination;
/*      */     }
/*      */ 
/*  515 */     return destination;
/*      */   }
/*      */ 
/*      */   public static String encodeObject(Serializable serializableObject)
/*      */   {
/*  534 */     return encodeObject(serializableObject, 0);
/*      */   }
/*      */ 
/*      */   public static String encodeObject(Serializable serializableObject, int options)
/*      */   {
/*  565 */     ByteArrayOutputStream baos = null;
/*  566 */     OutputStream b64os = null;
/*  567 */     ObjectOutputStream oos = null;
/*  568 */     GZIPOutputStream gzos = null;
/*      */ 
/*  571 */     int gzip = options & 0x2;
/*      */     try
/*      */     {
/*  577 */       baos = new ByteArrayOutputStream();
/*  578 */       b64os = new OutputStream(baos, 0x1 | options);
/*      */ 
/*  581 */       if (gzip == 2)
/*      */       {
/*  583 */         gzos = new GZIPOutputStream(b64os);
/*  584 */         oos = new ObjectOutputStream(gzos);
/*      */       }
/*      */       else {
/*  587 */         oos = new ObjectOutputStream(b64os);
/*      */       }
/*  589 */       oos.writeObject(serializableObject);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  593 */       e.printStackTrace();
/*  594 */       Object localObject1 = null;
/*      */       return localObject1;
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  598 */         oos.close(); } catch (Exception e) {
/*      */       }try { gzos.close(); } catch (Exception e) {
/*      */       }try { b64os.close(); } catch (Exception e) {
/*      */       }try { baos.close();
/*      */       } catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */     try {
/*  607 */       return new String(baos.toByteArray(), "UTF-8");
/*      */     }
/*      */     catch (UnsupportedEncodingException uue) {
/*      */     }
/*  611 */     return new String(baos.toByteArray());
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source)
/*      */   {
/*  627 */     return encodeBytes(source, 0, source.length, 0);
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int options)
/*      */   {
/*  654 */     return encodeBytes(source, 0, source.length, options);
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int off, int len)
/*      */   {
/*  669 */     return encodeBytes(source, off, len, 0);
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int off, int len, int options)
/*      */   {
/*  699 */     int dontBreakLines = options & 0x8;
/*  700 */     int gzip = options & 0x2;
/*      */ 
/*  703 */     if (gzip == 2)
/*      */     {
/*  705 */       ByteArrayOutputStream baos = null;
/*  706 */       GZIPOutputStream gzos = null;
/*  707 */       OutputStream b64os = null;
/*      */       try
/*      */       {
/*  713 */         baos = new ByteArrayOutputStream();
/*  714 */         b64os = new OutputStream(baos, 0x1 | options);
/*  715 */         gzos = new GZIPOutputStream(b64os);
/*      */ 
/*  717 */         gzos.write(source, off, len);
/*  718 */         gzos.close();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  722 */         e.printStackTrace();
/*  723 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/*      */       finally
/*      */       {
/*      */         try
/*      */         {
/*  727 */           gzos.close(); } catch (Exception e) {
/*      */         }try { b64os.close(); } catch (Exception e) {
/*      */         }try { baos.close();
/*      */         } catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */       try {
/*  735 */         return new String(baos.toByteArray(), "UTF-8");
/*      */       }
/*      */       catch (UnsupportedEncodingException uue)
/*      */       {
/*  739 */         return new String(baos.toByteArray());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  747 */     boolean breakLines = dontBreakLines == 0;
/*      */ 
/*  749 */     int len43 = len * 4 / 3;
/*  750 */     byte[] outBuff = new byte[len43 + (len % 3 > 0 ? 4 : 0) + (breakLines ? len43 / 76 : 0)];
/*      */ 
/*  753 */     int d = 0;
/*  754 */     int e = 0;
/*  755 */     int len2 = len - 2;
/*  756 */     int lineLength = 0;
/*  757 */     for (; d < len2; e += 4)
/*      */     {
/*  759 */       encode3to4(source, d + off, 3, outBuff, e, options);
/*      */ 
/*  761 */       lineLength += 4;
/*  762 */       if ((breakLines) && (lineLength == 76))
/*      */       {
/*  764 */         outBuff[(e + 4)] = 10;
/*  765 */         e++;
/*  766 */         lineLength = 0;
/*      */       }
/*  757 */       d += 3;
/*      */     }
/*      */ 
/*  770 */     if (d < len)
/*      */     {
/*  772 */       encode3to4(source, d + off, len - d, outBuff, e, options);
/*  773 */       e += 4;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  780 */       return new String(outBuff, 0, e, "UTF-8");
/*      */     }
/*      */     catch (UnsupportedEncodingException uue) {
/*      */     }
/*  784 */     return new String(outBuff, 0, e);
/*      */   }
/*      */ 
/*      */   private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset, int options)
/*      */   {
/*  825 */     byte[] DECODABET = getDecodabet(options);
/*      */ 
/*  828 */     if (source[(srcOffset + 2)] == 61)
/*      */     {
/*  833 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12;
/*      */ 
/*  836 */       destination[destOffset] = (byte)(outBuff >>> 16);
/*  837 */       return 1;
/*      */     }
/*      */ 
/*  841 */     if (source[(srcOffset + 3)] == 61)
/*      */     {
/*  847 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6;
/*      */ 
/*  851 */       destination[destOffset] = (byte)(outBuff >>> 16);
/*  852 */       destination[(destOffset + 1)] = (byte)(outBuff >>> 8);
/*  853 */       return 2;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  865 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6 | DECODABET[source[(srcOffset + 3)]] & 0xFF;
/*      */ 
/*  871 */       destination[destOffset] = (byte)(outBuff >> 16);
/*  872 */       destination[(destOffset + 1)] = (byte)(outBuff >> 8);
/*  873 */       destination[(destOffset + 2)] = (byte)outBuff;
/*      */ 
/*  875 */       return 3;
/*      */     } catch (Exception e) {
/*  877 */       System.out.println("" + source[srcOffset] + ": " + DECODABET[source[srcOffset]]);
/*  878 */       System.out.println("" + source[(srcOffset + 1)] + ": " + DECODABET[source[(srcOffset + 1)]]);
/*  879 */       System.out.println("" + source[(srcOffset + 2)] + ": " + DECODABET[source[(srcOffset + 2)]]);
/*  880 */       System.out.println("" + source[(srcOffset + 3)] + ": " + DECODABET[source[(srcOffset + 3)]]);
/*  881 */     }return -1;
/*      */   }
/*      */ 
/*      */   public static byte[] decode(byte[] source, int off, int len, int options)
/*      */   {
/*  902 */     byte[] DECODABET = getDecodabet(options);
/*      */ 
/*  904 */     int len34 = len * 3 / 4;
/*  905 */     byte[] outBuff = new byte[len34];
/*  906 */     int outBuffPosn = 0;
/*      */ 
/*  908 */     byte[] b4 = new byte[4];
/*  909 */     int b4Posn = 0;
/*  910 */     int i = 0;
/*  911 */     byte sbiCrop = 0;
/*  912 */     byte sbiDecode = 0;
/*  913 */     for (i = off; i < off + len; i++)
/*      */     {
/*  915 */       sbiCrop = (byte)(source[i] & 0x7F);
/*  916 */       sbiDecode = DECODABET[sbiCrop];
/*      */ 
/*  918 */       if (sbiDecode >= -5)
/*      */       {
/*  920 */         if (sbiDecode < -1)
/*      */           continue;
/*  922 */         b4[(b4Posn++)] = sbiCrop;
/*  923 */         if (b4Posn <= 3)
/*      */           continue;
/*  925 */         outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn, options);
/*  926 */         b4Posn = 0;
/*      */ 
/*  929 */         if (sbiCrop == 61) {
/*  930 */           break;
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  938 */         System.err.println("Bad Base64 input character at " + i + ": " + source[i] + "(decimal)");
/*  939 */         return null;
/*      */       }
/*      */     }
/*      */ 
/*  943 */     byte[] out = new byte[outBuffPosn];
/*  944 */     System.arraycopy(outBuff, 0, out, 0, outBuffPosn);
/*  945 */     return out;
/*      */   }
/*      */ 
/*      */   public static byte[] decode(String s)
/*      */   {
/*  961 */     return decode(s, 0);
/*      */   }
/*      */ 
/*      */   public static byte[] decode(String s, int options)
/*      */   {
/*      */     try
/*      */     {
/*  979 */       bytes = s.getBytes("UTF-8");
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*  983 */       bytes = s.getBytes();
/*      */     }
/*      */ 
/*  988 */     byte[] bytes = decode(bytes, 0, bytes.length, options);
/*      */ 
/*  993 */     if ((bytes != null) && (bytes.length >= 4))
/*      */     {
/*  996 */       int head = bytes[0] & 0xFF | bytes[1] << 8 & 0xFF00;
/*  997 */       if (35615 == head)
/*      */       {
/*  999 */         ByteArrayInputStream bais = null;
/* 1000 */         GZIPInputStream gzis = null;
/* 1001 */         ByteArrayOutputStream baos = null;
/* 1002 */         byte[] buffer = new byte[2048];
/* 1003 */         int length = 0;
/*      */         try
/*      */         {
/* 1007 */           baos = new ByteArrayOutputStream();
/* 1008 */           bais = new ByteArrayInputStream(bytes);
/* 1009 */           gzis = new GZIPInputStream(bais);
/*      */ 
/* 1011 */           while ((length = gzis.read(buffer)) >= 0)
/*      */           {
/* 1013 */             baos.write(buffer, 0, length);
/*      */           }
/*      */ 
/* 1017 */           bytes = baos.toByteArray();
/*      */         }
/*      */         catch (IOException e)
/*      */         {
/*      */         }
/*      */         finally
/*      */         {
/*      */           try
/*      */           {
/* 1026 */             baos.close(); } catch (Exception e) {
/*      */           }try { gzis.close(); } catch (Exception e) {
/*      */           }try { bais.close();
/*      */           } catch (Exception e) {
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1034 */     return bytes;
/*      */   }
/*      */ 
/*      */   public static Object decodeToObject(String encodedObject)
/*      */   {
/* 1051 */     byte[] objBytes = decode(encodedObject);
/*      */ 
/* 1053 */     ByteArrayInputStream bais = null;
/* 1054 */     ObjectInputStream ois = null;
/* 1055 */     Object obj = null;
/*      */     try
/*      */     {
/* 1059 */       bais = new ByteArrayInputStream(objBytes);
/* 1060 */       ois = new ObjectInputStream(bais);
/*      */ 
/* 1062 */       obj = ois.readObject();
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1066 */       e.printStackTrace();
/* 1067 */       obj = null;
/*      */     }
/*      */     catch (ClassNotFoundException e)
/*      */     {
/* 1071 */       e.printStackTrace();
/* 1072 */       obj = null;
/*      */     }
/*      */     finally {
/*      */       try {
/* 1076 */         bais.close(); } catch (Exception e) {
/*      */       }try { ois.close(); } catch (Exception e) {
/*      */       }
/*      */     }
/* 1080 */     return obj;
/*      */   }
/*      */ 
/*      */   public static boolean encodeToFile(byte[] dataToEncode, String filename)
/*      */   {
/* 1096 */     boolean success = false;
/* 1097 */     OutputStream bos = null;
/*      */     try
/*      */     {
/* 1100 */       bos = new OutputStream(new FileOutputStream(filename), 1);
/*      */ 
/* 1102 */       bos.write(dataToEncode);
/* 1103 */       success = true;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1108 */       success = false;
/*      */     }
/*      */     finally {
/*      */       try {
/* 1112 */         bos.close(); } catch (Exception e) {
/*      */       }
/*      */     }
/* 1115 */     return success;
/*      */   }
/*      */ 
/*      */   public static boolean decodeToFile(String dataToDecode, String filename)
/*      */   {
/* 1130 */     boolean success = false;
/* 1131 */     OutputStream bos = null;
/*      */     try
/*      */     {
/* 1134 */       bos = new OutputStream(new FileOutputStream(filename), 0);
/*      */ 
/* 1136 */       bos.write(dataToDecode.getBytes("UTF-8"));
/* 1137 */       success = true;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1141 */       success = false;
/*      */     }
/*      */     finally {
/*      */       try {
/* 1145 */         bos.close(); } catch (Exception e) {
/*      */       }
/*      */     }
/* 1148 */     return success;
/*      */   }
/*      */ 
/*      */   public static byte[] decodeFromFile(String filename)
/*      */   {
/* 1165 */     byte[] decodedData = null;
/* 1166 */     InputStream bis = null;
/*      */     try
/*      */     {
/* 1170 */       File file = new File(filename);
/* 1171 */       byte[] buffer = null;
/* 1172 */       int length = 0;
/* 1173 */       int numBytes = 0;
/*      */ 
/* 1176 */       if (file.length() > 2147483647L)
/*      */       {
/* 1178 */         System.err.println("File is too big for this convenience method (" + file.length() + " bytes).");
/* 1179 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/* 1181 */       buffer = new byte[(int)file.length()];
/*      */ 
/* 1184 */       bis = new InputStream(new BufferedInputStream(new FileInputStream(file)), 0);
/*      */ 
/* 1189 */       while ((numBytes = bis.read(buffer, length, 4096)) >= 0) {
/* 1190 */         length += numBytes;
/*      */       }
/*      */ 
/* 1193 */       decodedData = new byte[length];
/* 1194 */       System.arraycopy(buffer, 0, decodedData, 0, length);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1199 */       System.err.println("Error decoding from file " + filename);
/*      */     }
/*      */     finally {
/*      */       try {
/* 1203 */         bis.close(); } catch (Exception e) {
/*      */       }
/*      */     }
/* 1206 */     return decodedData;
/*      */   }
/*      */ 
/*      */   public static String encodeFromFile(String filename)
/*      */   {
/* 1222 */     String encodedData = null;
/* 1223 */     InputStream bis = null;
/*      */     try
/*      */     {
/* 1227 */       File file = new File(filename);
/* 1228 */       byte[] buffer = new byte[Math.max((int)(file.length() * 1.4D), 40)];
/* 1229 */       int length = 0;
/* 1230 */       int numBytes = 0;
/*      */ 
/* 1233 */       bis = new InputStream(new BufferedInputStream(new FileInputStream(file)), 1);
/*      */ 
/* 1238 */       while ((numBytes = bis.read(buffer, length, 4096)) >= 0) {
/* 1239 */         length += numBytes;
/*      */       }
/*      */ 
/* 1242 */       encodedData = new String(buffer, 0, length, "UTF-8");
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1247 */       System.err.println("Error encoding from file " + filename);
/*      */     }
/*      */     finally {
/*      */       try {
/* 1251 */         bis.close(); } catch (Exception e) {
/*      */       }
/*      */     }
/* 1254 */     return encodedData;
/*      */   }
/*      */ 
/*      */   public static boolean encodeFileToFile(String infile, String outfile)
/*      */   {
/* 1270 */     boolean success = false;
/* 1271 */     InputStream in = null;
/* 1272 */     OutputStream out = null;
/*      */     try {
/* 1274 */       in = new InputStream(new BufferedInputStream(new FileInputStream(infile)), 1);
/*      */ 
/* 1278 */       out = new BufferedOutputStream(new FileOutputStream(outfile));
/* 1279 */       byte[] buffer = new byte[65536];
/* 1280 */       int read = -1;
/* 1281 */       while ((read = in.read(buffer)) >= 0) {
/* 1282 */         out.write(buffer, 0, read);
/*      */       }
/* 1284 */       success = true;
/*      */     } catch (IOException exc) {
/* 1286 */       exc.printStackTrace(); } finally {
/*      */       try {
/* 1288 */         in.close(); } catch (Exception exc) {
/*      */       }try { out.close(); } catch (Exception exc) {
/*      */       }
/*      */     }
/* 1292 */     return success;
/*      */   }
/*      */ 
/*      */   public static boolean decodeFileToFile(String infile, String outfile)
/*      */   {
/* 1307 */     boolean success = false;
/* 1308 */     InputStream in = null;
/* 1309 */     OutputStream out = null;
/*      */     try {
/* 1311 */       in = new InputStream(new BufferedInputStream(new FileInputStream(infile)), 0);
/*      */ 
/* 1315 */       out = new BufferedOutputStream(new FileOutputStream(outfile));
/* 1316 */       byte[] buffer = new byte[65536];
/* 1317 */       int read = -1;
/* 1318 */       while ((read = in.read(buffer)) >= 0) {
/* 1319 */         out.write(buffer, 0, read);
/*      */       }
/* 1321 */       success = true;
/*      */     } catch (IOException exc) {
/* 1323 */       exc.printStackTrace(); } finally {
/*      */       try {
/* 1325 */         in.close(); } catch (Exception exc) {
/*      */       }try { out.close(); } catch (Exception exc) {
/*      */       }
/*      */     }
/* 1329 */     return success;
/*      */   }
/*      */ 
/*      */   public static class OutputStream extends FilterOutputStream
/*      */   {
/*      */     private boolean encode;
/*      */     private int position;
/*      */     private byte[] buffer;
/*      */     private int bufferLength;
/*      */     private int lineLength;
/*      */     private boolean breakLines;
/*      */     private byte[] b4;
/*      */     private boolean suspendEncoding;
/*      */     private int options;
/*      */     private byte[] decodabet;
/*      */ 
/*      */     public OutputStream(OutputStream out)
/*      */     {
/* 1603 */       this(out, 1);
/*      */     }
/*      */ 
/*      */     public OutputStream(OutputStream out, int options)
/*      */     {
/* 1629 */       super();
/* 1630 */       this.breakLines = ((options & 0x8) != 8);
/* 1631 */       this.encode = ((options & 0x1) == 1);
/* 1632 */       this.bufferLength = (this.encode ? 3 : 4);
/* 1633 */       this.buffer = new byte[this.bufferLength];
/* 1634 */       this.position = 0;
/* 1635 */       this.lineLength = 0;
/* 1636 */       this.suspendEncoding = false;
/* 1637 */       this.b4 = new byte[4];
/* 1638 */       this.options = options;
/*      */ 
/* 1640 */       this.decodabet = Base64.access$000(options);
/*      */     }
/*      */ 
/*      */     public void write(int theByte)
/*      */       throws IOException
/*      */     {
/* 1659 */       if (this.suspendEncoding)
/*      */       {
/* 1661 */         this.out.write(theByte);
/* 1662 */         return;
/*      */       }
/*      */ 
/* 1666 */       if (this.encode)
/*      */       {
/* 1668 */         this.buffer[(this.position++)] = (byte)theByte;
/* 1669 */         if (this.position >= this.bufferLength)
/*      */         {
/* 1671 */           this.out.write(Base64.access$300(this.b4, this.buffer, this.bufferLength, this.options));
/*      */ 
/* 1673 */           this.lineLength += 4;
/* 1674 */           if ((this.breakLines) && (this.lineLength >= 76))
/*      */           {
/* 1676 */             this.out.write(10);
/* 1677 */             this.lineLength = 0;
/*      */           }
/*      */ 
/* 1680 */           this.position = 0;
/*      */         }
/*      */ 
/*      */       }
/* 1688 */       else if (this.decodabet[(theByte & 0x7F)] > -5)
/*      */       {
/* 1690 */         this.buffer[(this.position++)] = (byte)theByte;
/* 1691 */         if (this.position >= this.bufferLength)
/*      */         {
/* 1693 */           int len = Base64.access$200(this.buffer, 0, this.b4, 0, this.options);
/* 1694 */           this.out.write(this.b4, 0, len);
/*      */ 
/* 1696 */           this.position = 0;
/*      */         }
/*      */       }
/* 1699 */       else if (this.decodabet[(theByte & 0x7F)] != -5)
/*      */       {
/* 1701 */         throw new IOException("Invalid character in Base64 data.");
/*      */       }
/*      */     }
/*      */ 
/*      */     public void write(byte[] theBytes, int off, int len)
/*      */       throws IOException
/*      */     {
/* 1720 */       if (this.suspendEncoding)
/*      */       {
/* 1722 */         this.out.write(theBytes, off, len);
/* 1723 */         return;
/*      */       }
/*      */ 
/* 1726 */       for (int i = 0; i < len; i++)
/*      */       {
/* 1728 */         write(theBytes[(off + i)]);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void flushBase64()
/*      */       throws IOException
/*      */     {
/* 1741 */       if (this.position > 0)
/*      */       {
/* 1743 */         if (this.encode)
/*      */         {
/* 1745 */           this.out.write(Base64.access$300(this.b4, this.buffer, this.position, this.options));
/* 1746 */           this.position = 0;
/*      */         }
/*      */         else
/*      */         {
/* 1750 */           throw new IOException("Base64 input not properly padded.");
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 1765 */       flushBase64();
/*      */ 
/* 1769 */       super.close();
/*      */ 
/* 1771 */       this.buffer = null;
/* 1772 */       this.out = null;
/*      */     }
/*      */ 
/*      */     public void suspendEncoding()
/*      */       throws IOException
/*      */     {
/* 1786 */       flushBase64();
/* 1787 */       this.suspendEncoding = true;
/*      */     }
/*      */ 
/*      */     public void resumeEncoding()
/*      */     {
/* 1800 */       this.suspendEncoding = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class InputStream extends FilterInputStream
/*      */   {
/*      */     private boolean encode;
/*      */     private int position;
/*      */     private byte[] buffer;
/*      */     private int bufferLength;
/*      */     private int numSigBytes;
/*      */     private int lineLength;
/*      */     private boolean breakLines;
/*      */     private int options;
/*      */     private byte[] decodabet;
/*      */ 
/*      */     public InputStream(InputStream in)
/*      */     {
/* 1367 */       this(in, 0);
/*      */     }
/*      */ 
/*      */     public InputStream(InputStream in, int options)
/*      */     {
/* 1394 */       super();
/* 1395 */       this.breakLines = ((options & 0x8) != 8);
/* 1396 */       this.encode = ((options & 0x1) == 1);
/* 1397 */       this.bufferLength = (this.encode ? 4 : 3);
/* 1398 */       this.buffer = new byte[this.bufferLength];
/* 1399 */       this.position = -1;
/* 1400 */       this.lineLength = 0;
/* 1401 */       this.options = options;
/*      */ 
/* 1403 */       this.decodabet = Base64.access$000(options);
/*      */     }
/*      */ 
/*      */     public int read()
/*      */       throws IOException
/*      */     {
/* 1416 */       if (this.position < 0)
/*      */       {
/* 1418 */         if (this.encode)
/*      */         {
/* 1420 */           byte[] b3 = new byte[3];
/* 1421 */           int numBinaryBytes = 0;
/* 1422 */           for (int i = 0; i < 3; i++)
/*      */           {
/*      */             try
/*      */             {
/* 1426 */               int b = this.in.read();
/*      */ 
/* 1429 */               if (b >= 0)
/*      */               {
/* 1431 */                 b3[i] = (byte)b;
/* 1432 */                 numBinaryBytes++;
/*      */               }
/*      */ 
/*      */             }
/*      */             catch (IOException e)
/*      */             {
/* 1439 */               if (i == 0) {
/* 1440 */                 throw e;
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/* 1445 */           if (numBinaryBytes > 0)
/*      */           {
/* 1447 */             Base64.access$100(b3, 0, numBinaryBytes, this.buffer, 0, this.options);
/* 1448 */             this.position = 0;
/* 1449 */             this.numSigBytes = 4;
/*      */           }
/*      */           else
/*      */           {
/* 1453 */             return -1;
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1460 */           byte[] b4 = new byte[4];
/* 1461 */           int i = 0;
/* 1462 */           for (i = 0; i < 4; i++)
/*      */           {
/* 1465 */             int b = 0;
/*      */             do b = this.in.read();
/* 1467 */             while ((b >= 0) && (this.decodabet[(b & 0x7F)] <= -5));
/*      */ 
/* 1469 */             if (b < 0) {
/*      */               break;
/*      */             }
/* 1472 */             b4[i] = (byte)b;
/*      */           }
/*      */ 
/* 1475 */           if (i == 4)
/*      */           {
/* 1477 */             this.numSigBytes = Base64.access$200(b4, 0, this.buffer, 0, this.options);
/* 1478 */             this.position = 0;
/*      */           } else {
/* 1480 */             if (i == 0) {
/* 1481 */               return -1;
/*      */             }
/*      */ 
/* 1486 */             throw new IOException("Improperly padded Base64 input.");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1493 */       if (this.position >= 0)
/*      */       {
/* 1496 */         if (this.position >= this.numSigBytes) {
/* 1497 */           return -1;
/*      */         }
/* 1499 */         if ((this.encode) && (this.breakLines) && (this.lineLength >= 76))
/*      */         {
/* 1501 */           this.lineLength = 0;
/* 1502 */           return 10;
/*      */         }
/*      */ 
/* 1506 */         this.lineLength += 1;
/*      */ 
/* 1510 */         int b = this.buffer[(this.position++)];
/*      */ 
/* 1512 */         if (this.position >= this.bufferLength) {
/* 1513 */           this.position = -1;
/*      */         }
/* 1515 */         return b & 0xFF;
/*      */       }
/*      */ 
/* 1524 */       throw new IOException("Error in Base64 code reading stream.");
/*      */     }
/*      */ 
/*      */     public int read(byte[] dest, int off, int len)
/*      */       throws IOException
/*      */     {
/* 1545 */       for (int i = 0; i < len; i++)
/*      */       {
/* 1547 */         int b = read();
/*      */ 
/* 1552 */         if (b >= 0) {
/* 1553 */           dest[(off + i)] = (byte)b; } else {
/* 1554 */           if (i != 0) break;
/* 1555 */           return -1;
/*      */         }
/*      */       }
/*      */ 
/* 1559 */       return i;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.Base64
 * JD-Core Version:    0.6.0
 */