/*     */ package atavism.server.util;
/*     */ 
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import java.io.PrintStream;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ 
/*     */ public class SecureTokenUtil
/*     */ {
/*     */   public static SecretKey generateDomainKey()
/*     */   {
/*     */     KeyGenerator keyGen;
/*     */     try
/*     */     {
/*  29 */       keyGen = KeyGenerator.getInstance("HmacSHA1");
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/*  32 */       Log.exception("SecureTokenManager.generateDomainKey: could not get KeyGenerator instance.", e);
/*  33 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/*  36 */     keyGen.init(160);
/*  37 */     SecretKey key = keyGen.generateKey();
/*  38 */     return key;
/*     */   }
/*     */ 
/*     */   public static byte[] encodeDomainKey(long keyId, SecretKey key)
/*     */   {
/*  48 */     AOByteBuffer buf = new AOByteBuffer(256);
/*  49 */     buf.putLong(keyId);
/*  50 */     buf.putString(key.getAlgorithm());
/*  51 */     byte[] encodedKey = key.getEncoded();
/*  52 */     buf.putBytes(encodedKey, 0, encodedKey.length);
/*  53 */     buf.flip();
/*  54 */     byte[] outKey = new byte[buf.remaining()];
/*  55 */     buf.getBytes(outKey, 0, outKey.length);
/*  56 */     return outKey;
/*     */   }
/*     */ 
/*     */   public static KeyPair generateMasterKeyPair()
/*     */   {
/*     */     KeyPairGenerator keyGen;
/*     */     try
/*     */     {
/*  66 */       keyGen = KeyPairGenerator.getInstance("DSA");
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/*  69 */       Log.exception("SecureTokenManager.generateMasterKeyPair: could not get DSA KeyPairGenerator instance.", e);
/*  70 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/*  73 */     keyGen.initialize(1024);
/*  74 */     KeyPair pair = keyGen.generateKeyPair();
/*  75 */     return pair;
/*     */   }
/*     */ 
/*     */   public static byte[] encodeMasterPrivateKey(long keyId, PrivateKey privKey)
/*     */   {
/*  84 */     AOByteBuffer buf = new AOByteBuffer(1024);
/*  85 */     buf.putLong(keyId);
/*  86 */     buf.putString(privKey.getAlgorithm());
/*  87 */     byte[] encodedKey = privKey.getEncoded();
/*  88 */     buf.putBytes(encodedKey, 0, encodedKey.length);
/*  89 */     buf.flip();
/*  90 */     byte[] outKey = new byte[buf.remaining()];
/*  91 */     buf.getBytes(outKey, 0, outKey.length);
/*  92 */     return outKey;
/*     */   }
/*     */ 
/*     */   public static byte[] encodeMasterPublicKey(long keyId, PublicKey pubKey)
/*     */   {
/* 101 */     AOByteBuffer buf = new AOByteBuffer(1024);
/* 102 */     buf.putLong(keyId);
/* 103 */     buf.putString(pubKey.getAlgorithm());
/* 104 */     byte[] encodedKey = pubKey.getEncoded();
/* 105 */     buf.putBytes(encodedKey, 0, encodedKey.length);
/* 106 */     buf.flip();
/* 107 */     byte[] outKey = new byte[buf.remaining()];
/* 108 */     buf.getBytes(outKey, 0, outKey.length);
/* 109 */     return outKey;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 116 */     Log.init();
/* 117 */     if (args.length != 1) {
/* 118 */       System.exit(-1);
/*     */     }
/* 120 */     Integer keyId = Integer.valueOf(Integer.parseInt(args[0]));
/*     */ 
/* 122 */     KeyPair pair = generateMasterKeyPair();
/* 123 */     PrivateKey priv = pair.getPrivate();
/* 124 */     PublicKey pub = pair.getPublic();
/*     */ 
/* 126 */     System.out.println("master key id = " + keyId);
/* 127 */     System.out.println("");
/*     */ 
/* 129 */     byte[] encodedPrivKey = encodeMasterPrivateKey(keyId.intValue(), pair.getPrivate());
/* 130 */     System.out.println("encoded private key:");
/* 131 */     System.out.println(Base64.encodeBytes(encodedPrivKey));
/* 132 */     System.out.println("");
/*     */ 
/* 134 */     byte[] encodedPubKey = encodeMasterPublicKey(keyId.intValue(), pair.getPublic());
/* 135 */     System.out.println("encoded public key:");
/* 136 */     System.out.println(Base64.encodeBytes(encodedPubKey));
/* 137 */     System.out.println("");
/* 138 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.SecureTokenUtil
 * JD-Core Version:    0.6.0
 */