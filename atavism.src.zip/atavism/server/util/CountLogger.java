/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class CountLogger
/*     */   implements Runnable
/*     */ {
/* 189 */   protected List<Counter> counters = new LinkedList();
/* 190 */   protected Thread countLoggerThread = null;
/* 191 */   protected boolean running = false;
/*     */   protected String name;
/*     */   protected int runInterval;
/*     */   protected int logLevel;
/* 196 */   protected boolean logging = true;
/* 197 */   protected boolean showAllNonzeroCounters = false;
/*     */ 
/*     */   public CountLogger(String name, int runInterval, int logLevel)
/*     */   {
/*  25 */     this.name = name;
/*  26 */     this.runInterval = runInterval;
/*  27 */     this.logLevel = logLevel;
/*     */   }
/*     */ 
/*     */   public CountLogger(String name, int runInterval, int logLevel, boolean showAllNonzeroCounters)
/*     */   {
/*  39 */     this.name = name;
/*  40 */     this.runInterval = runInterval;
/*  41 */     this.logLevel = logLevel;
/*  42 */     this.showAllNonzeroCounters = showAllNonzeroCounters;
/*     */   }
/*     */ 
/*     */   public Counter addCounter(String name)
/*     */   {
/*  50 */     Counter counter = new Counter(name);
/*  51 */     addCounter(counter);
/*  52 */     return counter;
/*     */   }
/*     */ 
/*     */   public Counter addCounter(String name, long count)
/*     */   {
/*  60 */     Counter counter = new Counter(name, count);
/*  61 */     addCounter(counter);
/*  62 */     return counter;
/*     */   }
/*     */ 
/*     */   public void addCounter(Counter counter)
/*     */   {
/*  70 */     synchronized (this.counters) {
/*  71 */       this.counters.add(counter);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeCounter(Counter counter)
/*     */   {
/*  79 */     synchronized (this.counters) {
/*  80 */       this.counters.remove(counter);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*  88 */     if (this.running) {
/*  89 */       Log.error("CountLogger.start: CountLogger thread is already running!");
/*     */     } else {
/*  91 */       this.countLoggerThread = new Thread(this, this.name);
/*  92 */       this.running = true;
/*  93 */       this.countLoggerThread.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 101 */     if (!this.running)
/* 102 */       Log.error("CountLogger.stop: CountLogger thread isn't running!");
/*     */     else
/* 104 */       this.running = false;
/*     */   }
/*     */ 
/*     */   public void setLogging(boolean enable)
/*     */   {
/* 111 */     this.logging = enable;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 120 */     while (this.running) {
/*     */       try {
/* 122 */         Thread.sleep(this.runInterval);
/*     */       } catch (Exception e) {
/* 124 */         Log.exception("CountLogger.run: error in Thread.sleep", e);
/*     */       }
/* 126 */       boolean logging = (this.logging) && (Log.getLogLevel() <= this.logLevel);
/* 127 */       String s = "";
/* 128 */       synchronized (this.counters) {
/* 129 */         for (Counter counter : this.counters) {
/* 130 */           long delta = counter.count - counter.lastCount;
/* 131 */           if ((delta == 0L) && (!this.showAllNonzeroCounters))
/*     */             continue;
/* 133 */           if (logging) {
/* 134 */             if (!s.equals(""))
/* 135 */               s = new StringBuilder().append(s).append(", ").toString();
/* 136 */             if (this.showAllNonzeroCounters)
/* 137 */               s = new StringBuilder().append(s).append(counter.name).append(" ").append(delta).append("|").append(counter.count).toString();
/*     */             else
/* 139 */               s = new StringBuilder().append(s).append(counter.name).append(" ").append(delta).toString();
/*     */           }
/* 141 */           counter.lastCount = counter.count;
/*     */         }
/*     */       }
/* 144 */       if (logging)
/* 145 */         Log.logAtLevel(this.logLevel, new StringBuilder().append(this.name).append(": ").append(s.equals("") ? "No non-zero counters" : s).toString()); 
/*     */     }
/*     */   }
/*     */   public static class Counter {
/*     */     public String name;
/*     */     public long count;
/*     */     public long lastCount;
/*     */ 
/*     */     public Counter(String name) {
/* 155 */       this.name = name;
/* 156 */       this.count = 0L;
/* 157 */       this.lastCount = 0L;
/*     */     }
/*     */ 
/*     */     public Counter(String name, long count) {
/* 161 */       this.name = name;
/* 162 */       this.count = count;
/* 163 */       this.lastCount = count;
/*     */     }
/*     */ 
/*     */     public void add()
/*     */     {
/* 170 */       this.count += 1L;
/*     */     }
/*     */ 
/*     */     public void add(long addend)
/*     */     {
/* 177 */       this.count += addend;
/*     */     }
/*     */ 
/*     */     public long getCount() {
/* 181 */       return this.count;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.CountLogger
 * JD-Core Version:    0.6.0
 */