/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class AOMeter
/*    */ {
/* 57 */   private String name = null;
/* 58 */   private long totalTime = 0L;
/* 59 */   private int count = 0;
/* 60 */   private long lastDumpTimeMS = System.currentTimeMillis();
/*    */ 
/* 62 */   private Lock lock = LockFactory.makeLock("AOMeter");
/*    */   public static final int intervalMS = 10000;
/*    */ 
/*    */   public AOMeter(String name)
/*    */   {
/* 13 */     setName(name);
/*    */   }
/*    */ 
/*    */   public void add(Long time) {
/* 17 */     this.lock.lock();
/*    */     try
/*    */     {
/* 20 */       this.totalTime += time.longValue();
/* 21 */       this.count += 1;
/*    */ 
/* 24 */       Long currentTime = Long.valueOf(System.currentTimeMillis());
/* 25 */       Long elapsedTime = Long.valueOf(currentTime.longValue() - this.lastDumpTimeMS);
/*    */ 
/* 28 */       if (elapsedTime.longValue() > 10000L)
/*    */       {
/* 30 */         dumpStats(elapsedTime);
/* 31 */         this.lastDumpTimeMS = currentTime.longValue();
/* 32 */         this.totalTime = 0L;
/* 33 */         this.count = 0;
/*    */       }
/*    */ 
/*    */     }
/*    */     finally
/*    */     {
/* 40 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   void dumpStats(Long elapsedMS) {
/* 45 */     long avgTime = this.totalTime / this.count;
/* 46 */     Log.info("AOMeter: meter=" + getName() + ", avgTime=" + avgTime + ", totalTime=" + this.totalTime + ", entries=" + this.count + ", elapsedMS=" + elapsedMS);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 50 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 54 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.AOMeter
 * JD-Core Version:    0.6.0
 */