/*    */ package atavism.server.util;
/*    */ 
/*    */ import atavism.server.math.Point;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class Points
/*    */ {
/* 11 */   private static Random random = new Random();
/*    */ 
/* 14 */   public static Point findNearby(Point point, int radius) { float radiusSQ = radius * radius;
/*    */     float dx;
/*    */     float dz;
/*    */     float distSQ;
/*    */     do { dx = random.nextFloat() * (2 * radius) - radius;
/* 19 */       dz = random.nextFloat() * (2 * radius) - radius;
/* 20 */       distSQ = dx * dx + dz * dz; }
/* 21 */     while (distSQ > radiusSQ);
/* 22 */     Point newPoint = (Point)point.clone();
/* 23 */     newPoint.add(dx, 0.0F, dz);
/* 24 */     return newPoint;
/*    */   }
/*    */ 
/*    */   public static Point findAdjacent(Point point, int radius)
/*    */   {
/* 30 */     double angle = 6.283185307179586D * random.nextDouble();
/* 31 */     int dx = (int)(Math.sin(angle) * radius);
/* 32 */     int dz = (int)(Math.cos(angle) * radius);
/* 33 */     Point newPoint = (Point)point.clone();
/* 34 */     newPoint.add(dx, 0, dz);
/* 35 */     return newPoint;
/*    */   }
/*    */ 
/*    */   public static boolean isClose(Point p1, Point p2, int radius) {
/* 39 */     double dx = p1.getX() - p2.getX();
/* 40 */     double dz = p1.getZ() - p2.getZ();
/* 41 */     double distSQ = dx * dx + dz * dz;
/* 42 */     double radiusSQ = radius * radius;
/*    */ 
/* 44 */     return distSQ <= radiusSQ;
/*    */   }
/*    */ 
/*    */   public static Point offset(Point p, int x, int z)
/*    */   {
/* 50 */     Point point = (Point)p.clone();
/* 51 */     point.add(x, 0, z);
/* 52 */     return point;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.Points
 * JD-Core Version:    0.6.0
 */