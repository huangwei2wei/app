/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class Logger
/*    */ {
/* 63 */   private String subj = null;
/*    */ 
/* 88 */   private static Set<String> subjSet = new HashSet();
/* 89 */   private static Lock staticLock = LockFactory.makeLock("LoggerStaticLock");
/*    */ 
/*    */   public Logger(String subj)
/*    */   {
/*  8 */     this.subj = subj;
/*    */   }
/*    */ 
/*    */   public void net(String s) {
/* 12 */     if ((!Log.loggingNet) || (!subjectStatus(this.subj))) {
/* 13 */       return;
/*    */     }
/* 15 */     Log.net(this.subj + ": " + s);
/*    */   }
/*    */ 
/*    */   public void debug(String s) {
/* 19 */     if ((!Log.loggingDebug) || (!subjectStatus(this.subj))) {
/* 20 */       return;
/*    */     }
/* 22 */     Log.debug(this.subj + ": " + s);
/*    */   }
/*    */ 
/*    */   public void info(String s) {
/* 26 */     if ((!Log.loggingInfo) || (!subjectStatus(this.subj))) {
/* 27 */       return;
/*    */     }
/* 29 */     Log.info(this.subj + ": " + s);
/*    */   }
/*    */ 
/*    */   public void warn(String s) {
/* 33 */     if ((!Log.loggingWarn) || (!subjectStatus(this.subj))) {
/* 34 */       return;
/*    */     }
/* 36 */     Log.warn(this.subj + ": " + s);
/*    */   }
/*    */ 
/*    */   public void error(String s) {
/* 40 */     Log.error(this.subj + ": " + s);
/*    */   }
/*    */ 
/*    */   public void dumpStack() {
/* 44 */     Log.dumpStack(this.subj + ": ");
/*    */   }
/*    */ 
/*    */   public void dumpStack(String context) {
/* 48 */     Log.dumpStack(this.subj + ": " + context);
/*    */   }
/*    */ 
/*    */   public void dumpStack(String context, Thread thread) {
/* 52 */     Log.dumpStack(this.subj + ": " + context, thread);
/*    */   }
/*    */ 
/*    */   public void exception(Exception e) {
/* 56 */     Log.exception(this.subj + ": ", e);
/*    */   }
/*    */ 
/*    */   public void exception(String context, Exception e) {
/* 60 */     Log.exception(this.subj + ": " + context, e);
/*    */   }
/*    */ 
/*    */   public static void logSubject(String subj)
/*    */   {
/* 66 */     staticLock.lock();
/*    */     try {
/* 68 */       subjSet.add(subj);
/*    */     }
/*    */     finally {
/* 71 */       staticLock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   private static boolean subjectStatus(String subj) {
/* 76 */     staticLock.lock();
/*    */     try
/*    */     {
/* 79 */       if (subjSet.isEmpty()) {
/* 80 */         bool = true;
/*    */         return bool;
/*    */       }
/* 82 */       boolean bool = subjSet.contains(subj);
/*    */       return bool; } finally { staticLock.unlock(); } throw localObject;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.Logger
 * JD-Core Version:    0.6.0
 */