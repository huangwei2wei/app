/*    */ package atavism.server.util;
/*    */ 
/*    */ public class FileUtil
/*    */ {
/*    */   public static String expandFileName(String fileName)
/*    */   {
/*  9 */     fileName = fileName.replace("$AO_HOME", System.getenv("AO_HOME"));
/* 10 */     fileName = fileName.replace("$WORLD_NAME", System.getProperty("atavism.worldname"));
/*    */ 
/* 12 */     fileName = fileName.replace("$WORLD_DIR", System.getenv("AO_WORLD_CONFIG"));
/*    */ 
/* 14 */     fileName = fileName.replace("$AO_LOGS", System.getProperty("atavism.logs"));
/*    */ 
/* 16 */     return fileName;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.FileUtil
 * JD-Core Version:    0.6.0
 */