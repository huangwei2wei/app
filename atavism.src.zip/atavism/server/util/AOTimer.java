/*    */ package atavism.server.util;
/*    */ 
/*    */ public class AOTimer
/*    */ {
/* 23 */   private String name = null;
/*    */ 
/* 52 */   Long startTime = null;
/* 53 */   Long elapsedTime = Long.valueOf(0L);
/*    */ 
/*    */   public AOTimer(String name)
/*    */   {
/* 12 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 16 */     return "(elapsedTime=" + elapsed() + ")";
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 20 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void start()
/*    */   {
/* 26 */     if (this.startTime != null) {
/* 27 */       throw new RuntimeException("started twice");
/*    */     }
/* 29 */     this.startTime = Long.valueOf(System.nanoTime());
/*    */   }
/*    */   public void stop() {
/* 32 */     if (this.startTime == null) {
/* 33 */       throw new RuntimeException("stop without start");
/*    */     }
/* 35 */     this.elapsedTime = Long.valueOf(this.elapsedTime.longValue() + (System.nanoTime() - this.startTime.longValue()));
/* 36 */     this.startTime = null;
/*    */   }
/*    */ 
/*    */   public long elapsed()
/*    */   {
/* 41 */     if (this.startTime != null) {
/* 42 */       throw new RuntimeException("must be stopped to get elapsed");
/*    */     }
/* 44 */     return ()(this.elapsedTime.longValue() / 1000000.0D);
/*    */   }
/*    */ 
/*    */   public void reset() {
/* 48 */     this.startTime = null;
/* 49 */     this.elapsedTime = Long.valueOf(0L);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.AOTimer
 * JD-Core Version:    0.6.0
 */