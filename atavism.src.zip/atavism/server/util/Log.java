/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Appender;
/*     */ import org.apache.log4j.AppenderSkeleton;
/*     */ import org.apache.log4j.ConsoleAppender;
/*     */ import org.apache.log4j.FileAppender;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PatternLayout;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ import org.apache.log4j.RollingFileAppender;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ public class Log
/*     */ {
/* 255 */   private static int logLevel = 1;
/*     */   static Logger logger;
/* 259 */   public static boolean loggingWarn = false;
/* 260 */   public static boolean loggingInfo = false;
/* 261 */   public static boolean loggingDebug = false;
/* 262 */   public static boolean loggingNet = false;
/* 263 */   public static boolean loggingTrace = false;
/*     */ 
/*     */   public static void init()
/*     */   {
/*  10 */     if (logger == null)
/*  11 */       initLogging();
/*     */   }
/*     */ 
/*     */   public static void init(Properties properties) {
/*  15 */     if (logger != null) {
/*  16 */       logger.removeAppender("AODefaultConsoleAppender");
/*     */     }
/*  18 */     PropertyConfigurator.configure(properties);
/*  19 */     if (logger == null) {
/*  20 */       initLogging();
/*     */     } else {
/*  22 */       syncWithOtherLevel();
/*  23 */       makeFailsafeAppender(true);
/*     */     }
/*  25 */     boolean rotate = Boolean.parseBoolean(properties.getProperty("atavism.rotate_logs_on_startup", "false"));
/*  26 */     if (rotate)
/*  27 */       rotateLogs();
/*     */   }
/*     */ 
/*     */   private Log()
/*     */   {
/*  32 */     init();
/*     */   }
/*     */ 
/*     */   public static void net(String s)
/*     */   {
/*  37 */     logger.trace(s);
/*     */   }
/*     */ 
/*     */   public static void trace(String s) {
/*  41 */     logger.trace(s);
/*     */   }
/*     */ 
/*     */   public static void debug(String s) {
/*  45 */     logger.debug(s);
/*     */   }
/*     */ 
/*     */   public static void info(String s) {
/*  49 */     logger.info(s);
/*     */   }
/*     */ 
/*     */   public static void warn(String s) {
/*  53 */     logger.warn(s);
/*     */   }
/*     */ 
/*     */   public static void error(String s) {
/*  57 */     logger.error(s);
/*     */   }
/*     */ 
/*     */   public static void logAtLevel(int level, String s) {
/*  61 */     if (logLevel <= level)
/*  62 */       switch (level) {
/*     */       case 0:
/*  64 */         trace(s);
/*  65 */         break;
/*     */       case 1:
/*  67 */         debug(s);
/*  68 */         break;
/*     */       case 2:
/*  70 */         info(s);
/*  71 */         break;
/*     */       case 3:
/*  73 */         warn(s);
/*  74 */         break;
/*     */       case 4:
/*  76 */         error(s);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void dumpStack()
/*     */   {
/*  83 */     dumpStack("");
/*     */   }
/*     */ 
/*     */   public static void dumpStack(String context) {
/*  87 */     logger.error(buildStackDump(context, Thread.currentThread(), 5).toString());
/*     */   }
/*     */ 
/*     */   public static void dumpStack(String context, Thread thread) {
/*  91 */     logger.error(buildStackDump(context, thread, 5).toString());
/*     */   }
/*     */ 
/*     */   public static void warnAndDumpStack(String context) {
/*  95 */     logger.warn(buildStackDump(context, Thread.currentThread(), 5).toString());
/*     */   }
/*     */ 
/*     */   public static void warnAndDumpStack(String context, Thread thread) {
/*  99 */     logger.warn(buildStackDump(context, thread, 5).toString());
/*     */   }
/*     */ 
/*     */   protected static StringBuilder buildStackDump(String context, Thread thread, int framesToSkip) {
/* 103 */     StringBuilder traceStr = new StringBuilder(1000);
/* 104 */     traceStr.append(new StringBuilder().append((context == null) || (context.length() == 0) ? "Dumping stack for thread " : new StringBuilder().append(context).append(", dumping stack for thread ").toString()).append(thread.getName()).toString());
/* 105 */     int cnt = 0;
/* 106 */     for (StackTraceElement elem : thread.getStackTrace()) {
/* 107 */       cnt++;
/* 108 */       if (cnt < framesToSkip)
/*     */         continue;
/* 110 */       traceStr.append("\n       at ");
/* 111 */       traceStr.append(elem.toString());
/*     */     }
/* 113 */     return traceStr;
/*     */   }
/*     */ 
/*     */   public static String exceptionToString(Exception e) {
/* 117 */     Throwable throwable = e;
/* 118 */     StringBuilder traceStr = new StringBuilder(1000);
/*     */     do {
/* 120 */       traceStr.append(throwable.toString());
/* 121 */       for (StackTraceElement elem : throwable.getStackTrace()) {
/* 122 */         traceStr.append("\n       at ");
/* 123 */         traceStr.append(elem.toString());
/*     */       }
/* 125 */       throwable = throwable.getCause();
/* 126 */       if (throwable != null)
/* 127 */         traceStr.append("\nCaused by: ");
/*     */     }
/* 129 */     while (throwable != null);
/* 130 */     return traceStr.toString();
/*     */   }
/*     */ 
/*     */   public static void exception(String context, Exception e) {
/* 134 */     logger.error(new StringBuilder().append((context == null) || (context.length() == 0) ? "Exception: " : new StringBuilder().append(context).append(" ").toString()).append(exceptionToString(e)).toString());
/*     */   }
/*     */ 
/*     */   public static void exception(Exception e) {
/* 138 */     logger.error(new StringBuilder().append("Exception: ").append(e).append(exceptionToString(e)).toString());
/*     */   }
/*     */ 
/*     */   public static void addFile(String fileName)
/*     */     throws IOException
/*     */   {
/* 144 */     FileAppender appender = new FileAppender(new PatternLayout("%-5p [%d{ISO8601}] %-10t %m%n"), fileName);
/*     */ 
/* 147 */     appender.setName(fileName);
/* 148 */     logger.addAppender(appender);
/*     */   }
/*     */ 
/*     */   public static void removeFile(String fileName)
/*     */   {
/* 153 */     logger.removeAppender(fileName);
/*     */   }
/*     */ 
/*     */   private static void initLogging() {
/* 157 */     String disableLogs = System.getProperty("atavism.disable_logs", null);
/* 158 */     if (disableLogs != null) {
/* 159 */       logger = Logger.getRootLogger();
/* 160 */       logger.addAppender(new NullAppender(null));
/*     */     }
/*     */     else {
/* 163 */       String loggerName = System.getProperty("atavism.loggername", "AO");
/* 164 */       logger = Logger.getLogger(loggerName);
/* 165 */       syncWithOtherLevel();
/* 166 */       makeFailsafeAppender(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void syncWithOtherLevel() {
/* 171 */     Level log4jLevel = logger.getEffectiveLevel();
/* 172 */     if (log4jLevel == Level.TRACE)
/* 173 */       logLevel = 0;
/* 174 */     else if (log4jLevel == Level.DEBUG)
/* 175 */       logLevel = 1;
/* 176 */     else if (log4jLevel == Level.INFO)
/* 177 */       logLevel = 2;
/* 178 */     else if (log4jLevel == Level.WARN)
/* 179 */       logLevel = 3;
/* 180 */     else if (log4jLevel == Level.ERROR)
/* 181 */       logLevel = 4;
/* 182 */     setLogLevel(logLevel);
/*     */   }
/*     */ 
/*     */   private static void makeFailsafeAppender(boolean complain)
/*     */   {
/* 191 */     Logger rootLogger = Logger.getRootLogger();
/* 192 */     Enumeration rootAppenders = rootLogger.getAllAppenders();
/* 193 */     Enumeration ourAppenders = logger.getAllAppenders();
/* 194 */     boolean rootEmpty = !rootAppenders.hasMoreElements();
/* 195 */     boolean ourEmpty = !ourAppenders.hasMoreElements();
/* 196 */     if ((rootEmpty) && (ourEmpty)) {
/* 197 */       if (complain)
/* 198 */         System.out.println("Missing log config file, logging to console");
/* 199 */       ConsoleAppender appender = new ConsoleAppender(new PatternLayout("%-5p [%d{ISO8601}] %-10t %m%n"), "System.err");
/*     */ 
/* 202 */       appender.setName("AODefaultConsoleAppender");
/* 203 */       logger.addAppender(appender);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void rotateLogs()
/*     */   {
/* 222 */     Enumeration appenders = Logger.getRootLogger().getAllAppenders();
/* 223 */     while (appenders.hasMoreElements()) {
/* 224 */       Appender a = (Appender)appenders.nextElement();
/* 225 */       if (((a instanceof RollingFileAppender)) && (!a.getName().equals("ErrorLog")))
/*     */       {
/* 227 */         ((RollingFileAppender)a).rollOver();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setLogLevel(int level)
/*     */   {
/* 234 */     if (level != logLevel) {
/* 235 */       if (level == 0) logger.setLevel(Level.TRACE);
/* 236 */       else if (level == 1) logger.setLevel(Level.DEBUG);
/* 237 */       else if (level == 2) logger.setLevel(Level.INFO);
/* 238 */       else if (level == 3) logger.setLevel(Level.WARN);
/* 239 */       else if (level == 4) logger.setLevel(Level.ERROR);
/*     */       else
/* 241 */         return;
/*     */     }
/* 243 */     logLevel = level;
/* 244 */     loggingWarn = logLevel <= 3;
/* 245 */     loggingInfo = logLevel <= 2;
/* 246 */     loggingDebug = logLevel <= 1;
/* 247 */     loggingNet = logLevel <= 0;
/* 248 */     loggingTrace = loggingNet;
/*     */   }
/*     */ 
/*     */   public static int getLogLevel() {
/* 252 */     return logLevel;
/*     */   }
/*     */ 
/*     */   private static class NullAppender extends AppenderSkeleton
/*     */   {
/*     */     protected void append(LoggingEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean requiresLayout()
/*     */     {
/* 275 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.Log
 * JD-Core Version:    0.6.0
 */