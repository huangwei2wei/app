/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class MeterManager
/*     */ {
/*     */   protected static MeterManager instance;
/*     */   protected short timerIdCounter;
/*     */   protected long startTime;
/*     */   float microsecondsPerTick;
/*     */   protected Vector<MeterEvent> eventTrace;
/*     */   protected HashMap<String, TimingMeter> metersByTitle;
/*     */   protected HashMap<Short, TimingMeter> metersById;
/*     */   protected static boolean dumpEventLog;
/*     */   public static boolean Collecting;
/*     */   public static int DontDisplayUsecs;
/*     */   public static short ekEnter;
/*     */   public static short ekExit;
/*     */ 
/*     */   protected static long CaptureCurrentTime()
/*     */   {
/*  53 */     return System.nanoTime();
/*     */   }
/*     */ 
/*     */   protected String OptionValue(String name, HashMap<String, String> options)
/*     */   {
/*     */     String value;
/*  59 */     if ((value = (String)options.get(name)) != null) {
/*  60 */       return value;
/*     */     }
/*  62 */     return "";
/*     */   }
/*     */ 
/*     */   protected boolean BooleanOption(String name, HashMap<String, String> options)
/*     */   {
/*  67 */     String value = OptionValue(name, options);
/*  68 */     return (value != "") && (value != "false");
/*     */   }
/*     */ 
/*     */   protected int IntOption(String name, HashMap<String, String> options)
/*     */   {
/*  73 */     String value = OptionValue(name, options);
/*  74 */     return value == "" ? 0 : Integer.parseInt(value);
/*     */   }
/*     */ 
/*     */   protected static void BarfOnBadChars(String name, String nameDescription) throws Exception
/*     */   {
/*  79 */     if (name.indexOf("\n") >= 0)
/*  80 */       throw new Exception(String.format("Carriage returns are not allowed in %1$s", new Object[] { nameDescription }));
/*  81 */     if (name.indexOf(",") >= 0)
/*  82 */       throw new Exception(String.format("Commas are not allowed in %1$s", new Object[] { nameDescription }));
/*     */   }
/*     */ 
/*     */   protected MeterManager()
/*     */   {
/* 112 */     this.timerIdCounter = 1;
/* 113 */     this.eventTrace = new Vector();
/* 114 */     this.metersByTitle = new HashMap();
/* 115 */     this.metersById = new HashMap();
/* 116 */     this.startTime = CaptureCurrentTime();
/* 117 */     this.microsecondsPerTick = 0.001F;
/* 118 */     instance = this;
/*     */   }
/*     */ 
/*     */   protected TimingMeter GetMeterById(int id)
/*     */   {
/* 123 */     TimingMeter meter = (TimingMeter)this.metersById.get(Integer.valueOf(id));
/* 124 */     if ((!$assertionsDisabled) && (meter == null)) throw new AssertionError(String.format("Meter for id %1$d is not in the index", new Object[] { Integer.valueOf(id) }));
/* 125 */     return meter;
/*     */   }
/*     */   protected void SaveToFileInternal(String pathname) {
/*     */     FileWriter writer;
/*     */     try {
/* 131 */       writer = new FileWriter(pathname);
/* 132 */       writer.write(String.format("MeterCount=%1$d\n", new Object[] { Integer.valueOf(this.metersById.size()) }));
/* 133 */       for (TimingMeter meter : instance.metersById.values())
/* 134 */         writer.write(String.format("%1$s,%2$s,%3$d\n", new Object[] { meter.title, meter.category, Short.valueOf(meter.meterId) }));
/*     */     }
/*     */     catch (IOException e) {
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String IndentCount(int count) {
/* 141 */     if (count > 20)
/* 142 */       count = 20;
/* 143 */     String s = "|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-";
/* 144 */     return s.substring(0, 2 * count);
/*     */   }
/*     */ 
/*     */   protected long ToMicroseconds(long ticks)
/*     */   {
/* 149 */     return ()((float)ticks * this.microsecondsPerTick);
/*     */   }
/*     */ 
/*     */   protected void DumpEventLogInternal()
/*     */   {
/* 154 */     String p = "../MeterEvents.txt";
/*     */     try {
/* 156 */       FileWriter writer = new FileWriter(p);
/* 157 */       writer.write(String.format("Dumping meter event log; units are usecs\r\n", new Object[0]));
/* 158 */       int indent = 0;
/* 159 */       Vector meterStack = new Vector();
/* 160 */       for (int i = 0; i < this.eventTrace.size(); i++) {
/* 161 */         MeterEvent me = (MeterEvent)this.eventTrace.get(i);
/* 162 */         TimingMeter meter = GetMeterById(me.meterId);
/* 163 */         short kind = me.eventKind;
/* 164 */         long t = me.eventTime;
/* 165 */         if (kind == ekEnter) {
/* 166 */           indent++;
/* 167 */           writer.write(String.format("%112d %2s%3s %4s.%5s\r\n", new Object[] { Long.valueOf(ToMicroseconds(t - this.startTime)), IndentCount(indent), "Enter", meter.category, meter.title }));
/*     */ 
/* 172 */           meterStack.add(new MeterStackEntry(meter, t));
/*     */         }
/*     */         else {
/* 175 */           assert (meterStack.size() > 0) : "Meter stack is empty during ekExit";
/* 176 */           MeterStackEntry s = (MeterStackEntry)meterStack.get(meterStack.size() - 1);
/* 177 */           assert (s.meter == meter);
/* 178 */           writer.write(String.format("%112d %2s%3s %4s.%5s\r\n", new Object[] { Long.valueOf(ToMicroseconds(t - s.eventTime)), IndentCount(indent), "Exit ", meter.category, meter.title }));
/*     */ 
/* 183 */           indent--;
/* 184 */           meterStack.remove(meterStack.size() - 1);
/*     */         }
/*     */       }
/* 187 */       writer.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void GenerateReport(FileWriter writer, int start, HashMap<String, String> options)
/*     */   {
/* 197 */     if (dumpEventLog) {
/* 198 */       DumpEventLog();
/*     */     }
/*     */     try
/*     */     {
/* 202 */       for (TimingMeter meter : instance.metersById.values()) {
/* 203 */         meter.stackDepth = 0;
/* 204 */         meter.addedTime = 0L;
/*     */       }
/* 206 */       Vector meterStack = new Vector();
/* 207 */       int indent = 0;
/* 208 */       for (int i = 0; i < this.eventTrace.size(); i++) {
/* 209 */         MeterEvent me = (MeterEvent)this.eventTrace.get(i);
/* 210 */         TimingMeter meter = GetMeterById(me.meterId);
/* 211 */         short kind = me.eventKind;
/* 212 */         long t = me.eventTime;
/* 213 */         if (kind == ekEnter) {
/* 214 */           if ((meter.accumulate) && (meter.stackDepth == 0))
/* 215 */             meter.addedTime = 0L;
/* 216 */           if ((i >= start) && ((!meter.accumulate) || (meter.stackDepth == 0)))
/*     */           {
/* 220 */             if ((this.eventTrace.size() > i + 1) && (((MeterEvent)this.eventTrace.get(i + 1)).meterId == me.meterId) && (((MeterEvent)this.eventTrace.get(i + 1)).eventKind == ekExit) && (ToMicroseconds(((MeterEvent)this.eventTrace.get(i + 1)).eventTime - t) < DontDisplayUsecs))
/*     */             {
/* 223 */               i++;
/* 224 */               continue;
/*     */             }
/* 226 */             writer.write(String.format("%112d %2s%3s %4s.%5s\r\n", new Object[] { Long.valueOf(ToMicroseconds(t - this.startTime)), IndentCount(indent), "Enter", meter.accumulate ? "*" : " ", meter.category, meter.title }));
/*     */ 
/* 231 */             if (!meter.accumulate)
/* 232 */               indent++;
/*     */           }
/* 234 */           meter.stackDepth += 1;
/* 235 */           meterStack.add(new MeterStackEntry(meter, t));
/*     */         }
/* 237 */         else if (kind == ekExit) {
/* 238 */           assert (meterStack.size() > 0) : "Meter stack is empty during ekExit";
/* 239 */           MeterStackEntry s = (MeterStackEntry)meterStack.get(meterStack.size() - 1);
/* 240 */           meter.stackDepth -= 1;
/* 241 */           assert (s.meter == meter);
/* 242 */           if ((meter.stackDepth > 0) && (meter.accumulate)) {
/* 243 */             meter.addedTime += t - s.eventTime;
/* 244 */           } else if (i >= start) {
/* 245 */             if (!meter.accumulate)
/* 246 */               indent--;
/* 247 */             writer.write(String.format("%112d %2s%3s %4s.%5s\r\n", new Object[] { Long.valueOf(ToMicroseconds(meter.accumulate ? meter.addedTime : t - s.eventTime)), IndentCount(indent), "Exit ", meter.accumulate ? "*" : " ", meter.category, meter.title }));
/*     */           }
/*     */ 
/* 253 */           meterStack.remove(meterStack.size() - 1);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void Init()
/*     */   {
/* 277 */     if (instance == null)
/* 278 */       instance = new MeterManager();
/*     */   }
/*     */ 
/*     */   public static void EnableCategory(String categoryName, boolean enable)
/*     */   {
/* 284 */     Init();
/* 285 */     for (TimingMeter meter : instance.metersById.values())
/* 286 */       if (meter.category == categoryName)
/* 287 */         meter.enabled = enable;
/*     */   }
/*     */ 
/*     */   public static TimingMeter GetMeter(String title, String category)
/*     */   {
/* 296 */     Init();
/* 297 */     if ((meter = (TimingMeter)instance.metersByTitle.get(title)) != null)
/* 298 */       return meter;
/*     */     try
/*     */     {
/* 301 */       BarfOnBadChars(title, "TimingMeter title");
/* 302 */       BarfOnBadChars(title, "TimingMeter category");
/*     */     }
/*     */     catch (Exception e) {
/* 305 */       return null;
/*     */     }
/* 307 */     short id = instance.timerIdCounter++;
/* 308 */     TimingMeter meter = new TimingMeter(title, category, id);
/* 309 */     instance.metersByTitle.put(title, meter);
/* 310 */     instance.metersById.put(Short.valueOf(id), meter);
/* 311 */     return meter;
/*     */   }
/*     */ 
/*     */   public static TimingMeter GetMeter(String title, String category, boolean accumulate)
/*     */   {
/* 317 */     TimingMeter meter = GetMeter(title, category);
/* 318 */     meter.accumulate = true;
/* 319 */     return meter;
/*     */   }
/*     */ 
/*     */   public static int AddEvent(TimingMeter meter, short eventKind)
/*     */   {
/* 325 */     long time = CaptureCurrentTime();
/* 326 */     instance.eventTrace.add(new MeterEvent(meter.meterId, eventKind, time));
/* 327 */     return instance.eventTrace.size();
/*     */   }
/*     */ 
/*     */   public static void ClearEvents()
/*     */   {
/* 332 */     Init();
/* 333 */     instance.eventTrace.clear();
/*     */   }
/*     */ 
/*     */   public static void SaveToFile(String pathname)
/*     */   {
/* 338 */     instance.SaveToFileInternal(pathname);
/*     */   }
/*     */ 
/*     */   public static long StartTime()
/*     */   {
/* 343 */     Init();
/* 344 */     return instance.startTime;
/*     */   }
/*     */ 
/*     */   public static void Report(String title)
/*     */   {
/* 349 */     Report(title, null, 0, "");
/*     */   }
/*     */ 
/*     */   public static void Report(String title, FileWriter writer, int start, String optionsString)
/*     */   {
/* 354 */     boolean opened = false;
/* 355 */     if (writer == null) {
/* 356 */       String p = "../MeterLog.txt";
/*     */       try {
/* 358 */         writer = new FileWriter(p, true);
/* 359 */         writer.write(String.format("\r\n\r\n\r\nStarting meter report for %1s; starting event %2d; units are usecs\r\n", new Object[] { title, Integer.valueOf(start) }));
/*     */ 
/* 361 */         opened = true;
/*     */       }
/*     */       catch (IOException e) {
/* 364 */         return;
/*     */       }
/*     */     }
/* 367 */     instance.GenerateReport(writer, start, null);
/* 368 */     if (opened)
/*     */       try {
/* 370 */         writer.close();
/*     */       } catch (IOException e) {
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void DumpEventLog() {
/* 376 */     Init();
/* 377 */     instance.DumpEventLogInternal();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  38 */     instance = null;
/*     */ 
/* 192 */     dumpEventLog = false;
/*     */ 
/* 270 */     DontDisplayUsecs = 3;
/*     */ 
/* 272 */     ekEnter = 1;
/* 273 */     ekExit = 2;
/*     */   }
/*     */ 
/*     */   protected static class MeterStackEntry
/*     */   {
/*     */     public TimingMeter meter;
/*     */     public long eventTime;
/*     */ 
/*     */     public MeterStackEntry(TimingMeter meter, long eventTime)
/*     */     {
/* 105 */       this.meter = meter;
/* 106 */       this.eventTime = eventTime;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class MeterEvent
/*     */   {
/*     */     public short meterId;
/*     */     public short eventKind;
/*     */     public long eventTime;
/*     */ 
/*     */     public MeterEvent(short meterId, short eventKind, long eventTime)
/*     */     {
/*  93 */       this.meterId = meterId;
/*  94 */       this.eventKind = eventKind;
/*  95 */       this.eventTime = eventTime;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.MeterManager
 * JD-Core Version:    0.6.0
 */