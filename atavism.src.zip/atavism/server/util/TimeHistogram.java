/*     */ package atavism.server.util;
/*     */ 
/*     */ public class TimeHistogram
/*     */   implements Runnable
/*     */ {
/*     */   protected String name;
/*     */   protected int reportingInterval;
/*     */   protected Boolean running;
/*     */   protected int bucketCount;
/*     */   protected int pointCount;
/*     */   protected Integer[] histogram;
/*     */   protected Long[] timeBounds;
/* 111 */   protected Long[] defaultTimeBounds = { Long.valueOf(10000L), Long.valueOf(20000L), Long.valueOf(50000L), Long.valueOf(100000L), Long.valueOf(200000L), Long.valueOf(500000L), Long.valueOf(1000000L), Long.valueOf(2000000L), Long.valueOf(5000000L), Long.valueOf(10000000L), Long.valueOf(20000000L), Long.valueOf(40000000L), Long.valueOf(100000000L), Long.valueOf(150000000L), Long.valueOf(200000000L), Long.valueOf(500000000L), Long.valueOf(1000000000L), Long.valueOf(2000000000L), Long.valueOf(5000000000L), Long.valueOf(10000000000L), Long.valueOf(20000000000L), Long.valueOf(50000000000L), Long.valueOf(100000000000L) };
/*     */ 
/*     */   public TimeHistogram(String name)
/*     */   {
/*  10 */     this.name = name;
/*  11 */     this.timeBounds = this.defaultTimeBounds;
/*  12 */     this.reportingInterval = 5000;
/*  13 */     start();
/*     */   }
/*     */ 
/*     */   public TimeHistogram(String name, Integer reportingInterval) {
/*  17 */     this.name = name;
/*  18 */     this.reportingInterval = reportingInterval.intValue();
/*  19 */     this.timeBounds = this.defaultTimeBounds;
/*  20 */     start();
/*     */   }
/*     */ 
/*     */   public TimeHistogram(String name, Integer reportingInterval, Long[] timeBounds) {
/*  24 */     this.name = name;
/*  25 */     this.reportingInterval = reportingInterval.intValue();
/*  26 */     this.timeBounds = timeBounds;
/*  27 */     start();
/*     */   }
/*     */ 
/*     */   public void stop() {
/*  31 */     this.running = Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */   public synchronized void addTime(long time)
/*     */   {
/*  36 */     this.pointCount += 1;
/*     */ 
/*  38 */     for (int i = 0; i < this.bucketCount; i++) {
/*  39 */       if (time < this.timeBounds[i].longValue()) {
/*  40 */         Integer[] arrayOfInteger = this.histogram; int j = i; localInteger1 = arrayOfInteger[j]; Integer localInteger2 = arrayOfInteger[j] =  = Integer.valueOf(arrayOfInteger[j].intValue() + 1);
/*  41 */         return;
/*     */       }
/*     */     }
/*  44 */     i = this.histogram; int i = this.bucketCount; Object localObject = i[i]; Integer localInteger1 = i[i] =  = Integer.valueOf(i[i].intValue() + 1);
/*     */   }
/*     */ 
/*     */   protected void start()
/*     */   {
/*  49 */     this.running = Boolean.valueOf(true);
/*  50 */     this.bucketCount = this.timeBounds.length;
/*  51 */     this.pointCount = 0;
/*  52 */     this.histogram = new Integer[this.bucketCount + 1];
/*  53 */     for (int i = 0; i < this.bucketCount + 1; i++)
/*  54 */       this.histogram[i] = Integer.valueOf(0);
/*  55 */     new Thread(this, this.name).start();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  60 */     while (this.running.booleanValue())
/*     */       try {
/*  62 */         Thread.sleep(this.reportingInterval);
/*  63 */         report();
/*     */       } catch (InterruptedException ex) {
/*     */       }
/*     */   }
/*     */ 
/*     */   protected synchronized void report() {
/*  69 */     long low = 0L;
/*  70 */     String s = "";
/*  71 */     if (this.pointCount == 0) {
/*  72 */       s = "No points in reporting interval";
/*     */     } else {
/*  74 */       int total = 0;
/*  75 */       for (int i = 0; i < this.bucketCount; i++) {
/*  76 */         if (this.histogram[i].intValue() > 0) {
/*  77 */           total += this.histogram[i].intValue();
/*  78 */           s = s + "[" + formatTime(low) + "-" + formatTime(this.timeBounds[i].longValue()) + "]: " + histogramString(i) + "  ";
/*     */         }
/*  80 */         low = this.timeBounds[i].longValue();
/*     */       }
/*  82 */       if (this.histogram[this.bucketCount].intValue() > 0)
/*  83 */         s = s + "[>" + formatTime(this.timeBounds[(this.bucketCount - 1)].longValue()) + "]: " + histogramString(this.bucketCount);
/*  84 */       s = "Samples " + total + " " + s;
/*     */     }
/*  86 */     this.pointCount = 0;
/*  87 */     for (int i = 0; i < this.bucketCount + 1; i++)
/*  88 */       this.histogram[i] = Integer.valueOf(0);
/*  89 */     Log.info("Histogram (" + this.reportingInterval + " ms): " + s);
/*     */   }
/*     */ 
/*     */   protected String formatTime(long t) {
/*  93 */     if (t < 1000000L) {
/*  94 */       return t / 1000L + "us";
/*     */     }
/*  96 */     return t / 1000000L + "ms";
/*     */   }
/*     */ 
/*     */   protected String histogramString(int index) {
/* 100 */     return "" + this.histogram[index] + "(" + this.histogram[index].intValue() * 100 / this.pointCount + "%)";
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.TimeHistogram
 * JD-Core Version:    0.6.0
 */