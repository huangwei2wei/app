/*    */ package atavism.server.util;
/*    */ 
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class DebugUtils
/*    */ {
/*    */   public static String byteArrayToHexString(AOByteBuffer buf)
/*    */   {
/* 13 */     String bytes = byteArrayToHexString(buf.copyBytes());
/* 14 */     buf.rewind();
/* 15 */     return bytes;
/*    */   }
/*    */ 
/*    */   public static String byteArrayToHexString(byte[] in) {
/* 19 */     byte ch = 0;
/* 20 */     int i = 0;
/* 21 */     if ((in == null) || (in.length <= 0))
/* 22 */       return null;
/* 23 */     String[] pseudo = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
/*    */ 
/* 27 */     StringBuffer out = new StringBuffer(in.length * 2);
/* 28 */     StringBuffer chars = new StringBuffer(in.length);
/* 29 */     while (i < in.length) {
/* 30 */       ch = (byte)(in[i] & 0xF0);
/* 31 */       ch = (byte)(ch >>> 4);
/* 32 */       ch = (byte)(ch & 0xF);
/* 33 */       out.append(pseudo[ch]);
/* 34 */       ch = (byte)(in[i] & 0xF);
/* 35 */       out.append(pseudo[ch]);
/* 36 */       if ((in[i] >= 32) && (in[i] <= 126))
/* 37 */         chars.append((char)in[i]);
/*    */       else
/* 39 */         chars.append("*");
/* 40 */       i++;
/*    */     }
/* 42 */     return new String(out) + " == " + new String(chars);
/*    */   }
/*    */ 
/*    */   public static void logDebugMap(Map<String, Serializable> map)
/*    */   {
/* 47 */     if (!Log.loggingDebug)
/* 48 */       return;
/* 49 */     Log.debug("PRINTMAP START");
/* 50 */     for (Map.Entry e : map.entrySet()) {
/* 51 */       Object key = e.getKey();
/* 52 */       Object val = e.getValue();
/* 53 */       if (Log.loggingDebug) {
/* 54 */         Log.debug("entry: key=" + key.toString() + ", value=" + val.toString());
/*    */       }
/*    */     }
/* 57 */     Log.debug("PRINTMAP END");
/*    */   }
/*    */ 
/*    */   public static String mapToString(Map<String, Serializable> map)
/*    */   {
/* 62 */     if (map == null)
/* 63 */       return "null";
/* 64 */     String result = "[";
/* 65 */     for (Map.Entry entry : map.entrySet()) {
/* 66 */       if (result.length() > 1)
/* 67 */         result = result + ",";
/* 68 */       result = result + (String)entry.getKey() + "=" + entry.getValue();
/*    */     }
/* 70 */     result = result + "]";
/* 71 */     return result;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.DebugUtils
 * JD-Core Version:    0.6.0
 */