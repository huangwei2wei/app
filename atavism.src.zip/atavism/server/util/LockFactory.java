/*    */ package atavism.server.util;
/*    */ 
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ public class LockFactory
/*    */ {
/* 16 */   public static boolean USE_DLOCK = false;
/*    */ 
/*    */   public static ReentrantLock makeLock(String name)
/*    */   {
/*  8 */     if (USE_DLOCK) {
/*  9 */       return new DLock(name);
/*    */     }
/*    */ 
/* 12 */     return new ReentrantLock();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 20 */     Lock A = makeLock("A");
/* 21 */     Lock B = makeLock("B");
/* 22 */     Lock C = makeLock("C");
/* 23 */     Lock D = makeLock("D");
/* 24 */     Lock Z = makeLock("Z");
/* 25 */     Lock Y = makeLock("Y");
/*    */ 
/* 27 */     A.lock();
/* 28 */     B.lock();
/* 29 */     C.lock();
/* 30 */     A.lock();
/* 31 */     A.unlock();
/* 32 */     C.unlock();
/* 33 */     D.lock();
/* 34 */     D.unlock();
/* 35 */     B.unlock();
/* 36 */     A.unlock();
/* 37 */     Z.lock();
/* 38 */     Y.lock();
/* 39 */     Y.unlock();
/* 40 */     Z.unlock();
/*    */ 
/* 42 */     DLock.detectCycle();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.LockFactory
 * JD-Core Version:    0.6.0
 */