/*     */ package atavism.server.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Table<A, B, C>
/*     */ {
/* 123 */   Lock lock = LockFactory.makeLock("TableLock");
/* 124 */   Map<A, Map<B, C>> map = new HashMap();
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  19 */     this.lock.lock();
/*     */     try {
/*  21 */       for (Map subMap : this.map.values())
/*  22 */         if (!subMap.isEmpty()) {
/*  23 */           int i = 0;
/*     */           return i;
/*     */         }
/*  26 */       ??? = 1;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Collection<A> getKeys()
/*     */   {
/*  34 */     this.lock.lock();
/*     */     try {
/*  36 */       Collection l = new LinkedList(this.map.keySet());
/*  37 */       Collection localCollection1 = l;
/*     */       return localCollection1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void put(A a, B b, C c)
/*     */   {
/*  45 */     this.lock.lock();
/*     */     try {
/*  47 */       Map subMap = (Map)this.map.get(a);
/*  48 */       if (subMap == null) {
/*  49 */         subMap = new HashMap();
/*  50 */         this.map.put(a, subMap);
/*     */       }
/*  52 */       subMap.put(b, c);
/*     */     }
/*     */     finally {
/*  55 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public C get(A a, B b)
/*     */   {
/*  72 */     this.lock.lock();
/*     */     try {
/*  74 */       Map subMap = (Map)this.map.get(a);
/*  75 */       if (subMap == null) {
/*  76 */         localObject1 = null;
/*     */         return localObject1;
/*     */       }
/*  78 */       Object localObject1 = subMap.get(b);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public C getWithAddSubMap(A a, B b)
/*     */   {
/*  90 */     this.lock.lock();
/*     */     try {
/*  92 */       Map subMap = (Map)this.map.get(a);
/*  93 */       if (subMap == null) {
/*  94 */         subMap = new HashMap();
/*  95 */         this.map.put(a, subMap);
/*     */       }
/*  97 */       Object localObject1 = subMap.get(b);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public Map<B, C> getSubMap(A a)
/*     */   {
/* 108 */     this.lock.lock();
/*     */     try {
/* 110 */       Map subMap = (Map)this.map.get(a);
/* 111 */       if (subMap == null) {
/* 112 */         subMap = new HashMap();
/* 113 */         this.map.put(a, subMap);
/* 114 */         localObject1 = subMap;
/*     */         return localObject1;
/*     */       }
/* 116 */       Object localObject1 = new HashMap(subMap);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.util.Table
 * JD-Core Version:    0.6.0
 */