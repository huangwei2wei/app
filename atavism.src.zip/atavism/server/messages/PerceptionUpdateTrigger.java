package atavism.server.messages;

import atavism.msgsys.AgentHandle;
import atavism.msgsys.FilterUpdate.Instruction;
import atavism.msgsys.SubscriptionHandle;

public abstract interface PerceptionUpdateTrigger
{
  public abstract void preUpdate(PerceptionFilter paramPerceptionFilter, FilterUpdate.Instruction paramInstruction, AgentHandle paramAgentHandle, SubscriptionHandle paramSubscriptionHandle);

  public abstract void postUpdate(PerceptionFilter paramPerceptionFilter, FilterUpdate.Instruction paramInstruction, AgentHandle paramAgentHandle, SubscriptionHandle paramSubscriptionHandle);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.PerceptionUpdateTrigger
 * JD-Core Version:    0.6.0
 */