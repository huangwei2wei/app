/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.Message;
/*    */ import atavism.msgsys.MessageTypeFilter;
/*    */ import atavism.server.objects.ObjectType;
/*    */ 
/*    */ public class SearchMessageFilter extends MessageTypeFilter
/*    */ {
/*    */   private ObjectType objectType;
/*    */ 
/*    */   public SearchMessageFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SearchMessageFilter(ObjectType objectType)
/*    */   {
/* 15 */     super(SearchMessage.MSG_TYPE_SEARCH);
/* 16 */     setType(objectType);
/*    */   }
/*    */ 
/*    */   public ObjectType getType()
/*    */   {
/* 21 */     return this.objectType;
/*    */   }
/*    */ 
/*    */   public void setType(ObjectType objectType)
/*    */   {
/* 26 */     this.objectType = objectType;
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message message)
/*    */   {
/* 31 */     return ((SearchMessage)message).getType() == this.objectType;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 36 */     return "[SearchMessageFilter " + toStringInternal() + "]";
/*    */   }
/*    */ 
/*    */   protected String toStringInternal()
/*    */   {
/* 41 */     return "type=" + this.objectType + " " + super.toStringInternal();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.SearchMessageFilter
 * JD-Core Version:    0.6.0
 */