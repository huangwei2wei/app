/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.Message;
/*    */ import atavism.msgsys.MessageTypeFilter;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PropertyFilter extends MessageTypeFilter
/*    */ {
/*    */   private Collection<String> propertyNames;
/*    */ 
/*    */   public Collection<String> getPropertyNames()
/*    */   {
/* 25 */     return this.propertyNames;
/*    */   }
/*    */ 
/*    */   public void setPropertyNames(Collection<String> names)
/*    */   {
/* 30 */     this.propertyNames = names;
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message message)
/*    */   {
/* 35 */     if ((!super.matchRemaining(message)) || (!(message instanceof PropertyMessage)))
/*    */     {
/* 37 */       return false;
/*    */     }
/* 39 */     Map properties = ((PropertyMessage)message).getPropertyMapRef();
/*    */ 
/* 41 */     for (String propertyName : this.propertyNames)
/* 42 */       if (properties.containsKey(propertyName))
/* 43 */         return true;
/* 44 */     return false;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.PropertyFilter
 * JD-Core Version:    0.6.0
 */