/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.Message;
/*    */ import atavism.msgsys.MessageType;
/*    */ import atavism.server.engine.SearchClause;
/*    */ import atavism.server.engine.SearchSelection;
/*    */ import atavism.server.objects.ObjectType;
/*    */ 
/*    */ public class SearchMessage extends Message
/*    */ {
/* 54 */   public static final MessageType MSG_TYPE_SEARCH = MessageType.intern("ao.SEARCH");
/*    */   private ObjectType objectType;
/*    */   private SearchClause searchClause;
/*    */   private SearchSelection selection;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public SearchMessage()
/*    */   {
/* 12 */     setMsgType(MSG_TYPE_SEARCH);
/*    */   }
/*    */ 
/*    */   public SearchMessage(ObjectType objectType, SearchClause searchClause, SearchSelection selection)
/*    */   {
/* 18 */     setMsgType(MSG_TYPE_SEARCH);
/* 19 */     setType(objectType);
/* 20 */     setSearchClause(searchClause);
/* 21 */     setSearchSelection(selection);
/*    */   }
/*    */ 
/*    */   public ObjectType getType()
/*    */   {
/* 26 */     return this.objectType;
/*    */   }
/*    */ 
/*    */   public void setType(ObjectType objectType)
/*    */   {
/* 31 */     this.objectType = objectType;
/*    */   }
/*    */ 
/*    */   public SearchClause getSearchClause()
/*    */   {
/* 36 */     return this.searchClause;
/*    */   }
/*    */ 
/*    */   public void setSearchClause(SearchClause searchClause)
/*    */   {
/* 41 */     this.searchClause = searchClause;
/*    */   }
/*    */ 
/*    */   public SearchSelection getSearchSelection()
/*    */   {
/* 46 */     return this.selection;
/*    */   }
/*    */ 
/*    */   public void setSearchSelection(SearchSelection selection)
/*    */   {
/* 51 */     this.selection = selection;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.SearchMessage
 * JD-Core Version:    0.6.0
 */