/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.Message;
/*    */ import atavism.msgsys.MessageTypeFilter;
/*    */ import atavism.server.objects.ObjectType;
/*    */ import atavism.server.plugins.WorldManagerClient;
/*    */ import atavism.server.plugins.WorldManagerClient.DespawnedMessage;
/*    */ import atavism.server.plugins.WorldManagerClient.SpawnedMessage;
/*    */ 
/*    */ public class PopulationFilter extends MessageTypeFilter
/*    */ {
/*    */   private ObjectType objectType;
/*    */ 
/*    */   public PopulationFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PopulationFilter(ObjectType type)
/*    */   {
/* 17 */     this.objectType = type;
/* 18 */     addType(WorldManagerClient.MSG_TYPE_SPAWNED);
/* 19 */     addType(WorldManagerClient.MSG_TYPE_DESPAWNED);
/*    */   }
/*    */ 
/*    */   public ObjectType getType()
/*    */   {
/* 24 */     return this.objectType;
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message message)
/*    */   {
/* 29 */     if ((message instanceof WorldManagerClient.SpawnedMessage))
/* 30 */       return this.objectType == ((WorldManagerClient.SpawnedMessage)message).getType();
/* 31 */     if ((message instanceof WorldManagerClient.DespawnedMessage)) {
/* 32 */       return this.objectType == ((WorldManagerClient.DespawnedMessage)message).getType();
/*    */     }
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 38 */     return "[PopulationFilter " + toStringInternal() + "]";
/*    */   }
/*    */ 
/*    */   protected String toStringInternal()
/*    */   {
/* 43 */     return "type=" + this.objectType + " " + super.toStringInternal();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.PopulationFilter
 * JD-Core Version:    0.6.0
 */