/*     */ package atavism.server.messages;
/*     */ 
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.msgsys.SubjectMessage;
/*     */ import atavism.server.engine.EventParser;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class PropertyMessage extends SubjectMessage
/*     */   implements EventParser, IPropertyMessage
/*     */ {
/*     */   private Namespace namespace;
/* 239 */   protected transient Lock lock = null;
/*     */ 
/* 241 */   protected Map<String, Serializable> propertyMap = new HashMap();
/* 242 */   protected Collection<String> removedProperties = new HashSet();
/*     */   private static final long serialVersionUID = 1L;
/* 246 */   public static MessageType MSG_TYPE_PROPERTY = MessageType.intern("ao.PROPERTY");
/*     */ 
/*     */   public PropertyMessage()
/*     */   {
/*  25 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public PropertyMessage(MessageType msgType) {
/*  29 */     super(msgType);
/*  30 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public PropertyMessage(OID objOid) {
/*  34 */     super(MSG_TYPE_PROPERTY, objOid);
/*  35 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public PropertyMessage(MessageType msgType, OID objOid) {
/*  39 */     super(msgType, objOid);
/*  40 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public PropertyMessage(OID objOid, OID notifyOid) {
/*  44 */     super(MSG_TYPE_PROPERTY, objOid);
/*  45 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  49 */     String s = "[PropertyMessage super=" + super.toString();
/*  50 */     for (Map.Entry entry : this.propertyMap.entrySet()) {
/*  51 */       String key = (String)entry.getKey();
/*  52 */       Serializable val = (Serializable)entry.getValue();
/*  53 */       s = s + " key=" + key + ",value=" + val;
/*     */     }
/*  55 */     return s + "]";
/*     */   }
/*     */ 
/*     */   public void setNamespace(Namespace namespace)
/*     */   {
/*  69 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public Namespace getNamespace() {
/*  73 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void put(String key, Serializable val)
/*     */   {
/*  83 */     setProperty(key, val);
/*     */   }
/*     */ 
/*     */   public void setProperty(String key, Serializable val)
/*     */   {
/*  92 */     this.lock.lock();
/*     */     try {
/*  94 */       this.propertyMap.put(key, val);
/*  95 */       this.removedProperties.remove(key);
/*     */     } finally {
/*  97 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setProperty(String key, Serializable val, boolean clone)
/*     */   {
/* 108 */     if (!clone) {
/* 109 */       setProperty(key, val);
/* 110 */       return;
/*     */     }
/* 112 */     this.lock.lock();
/*     */     try {
/*     */       try {
/* 115 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 116 */         ObjectOutputStream oos = new ObjectOutputStream(baos);
/* 117 */         oos.writeObject(val);
/* 118 */         ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
/* 119 */         ObjectInputStream ois = new ObjectInputStream(bais);
/* 120 */         Serializable valDeepCopy = (Serializable)ois.readObject();
/* 121 */         this.propertyMap.put(key, valDeepCopy);
/* 122 */         this.removedProperties.remove(key);
/*     */       } catch (ClassNotFoundException e) {
/* 124 */         this.propertyMap.put(key, null);
/* 125 */         this.removedProperties.remove(key);
/*     */       } catch (IOException e) {
/* 127 */         this.propertyMap.put(key, null);
/* 128 */         this.removedProperties.remove(key);
/*     */       }
/*     */     } finally {
/* 131 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeProperty(String key)
/*     */   {
/* 141 */     this.lock.lock();
/*     */     try {
/* 143 */       this.propertyMap.remove(key);
/* 144 */       this.removedProperties.add(key);
/*     */     } finally {
/* 146 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public Serializable get(String key)
/*     */   {
/* 155 */     return getProperty(key);
/*     */   }
/*     */ 
/*     */   public Serializable getProperty(String key)
/*     */   {
/* 164 */     this.lock.lock();
/*     */     try {
/* 166 */       Serializable localSerializable = (Serializable)this.propertyMap.get(key);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Set<String> keySet()
/*     */   {
/* 173 */     this.lock.lock();
/*     */     try {
/* 175 */       Set localSet = this.propertyMap.keySet();
/*     */       return localSet; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBuffer(String version)
/*     */   {
/* 182 */     return toBuffer(version, this.propertyMap, this.removedProperties, null);
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBuffer(String version, Set<String> filteredProps) {
/* 186 */     return toBuffer(version, this.propertyMap, this.removedProperties, filteredProps);
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBuffer(String version, Map<String, Serializable> propMap, Collection<String> removedSet, Set<String> filteredProps) {
/* 190 */     this.lock.lock();
/*     */     try {
/* 192 */       AOByteBuffer buf = new AOByteBuffer(500);
/* 193 */       buf.putOID(getSubject());
/* 194 */       buf.putInt(62);
/* 195 */       buf.putFilteredPropertyMap(propMap, filteredProps);
/* 196 */       buf.putFilteredPropertyCollection(removedSet, filteredProps);
/* 197 */       buf.flip();
/* 198 */       AOByteBuffer localAOByteBuffer1 = buf;
/*     */       return localAOByteBuffer1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void fromBuffer(AOByteBuffer buf)
/*     */   {
/* 205 */     OID oid = buf.getOID();
/* 206 */     int msgNumber = buf.getInt();
/* 207 */     if (msgNumber != 62) {
/* 208 */       Log.error("PropertyMessage.fromBuffer: msgNumber " + msgNumber + " is not 62");
/* 209 */       return;
/*     */     }
/* 211 */     this.propertyMap = buf.getPropertyMap();
/* 212 */     Collection collection = buf.getCollection();
/* 213 */     this.removedProperties = new HashSet();
/* 214 */     for (Serializable entry : collection) {
/* 215 */       this.removedProperties.add((String)entry);
/*     */     }
/* 217 */     setSubject(oid);
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf)
/*     */   {
/* 222 */     fromBuffer(buf);
/*     */   }
/*     */ 
/*     */   void setupTransient() {
/* 226 */     this.lock = LockFactory.makeLock("PropertyMessageLock");
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getPropertyMapRef()
/*     */   {
/* 231 */     return this.propertyMap;
/*     */   }
/*     */ 
/*     */   public Collection<String> getRemovedPropertiesRef()
/*     */   {
/* 236 */     return this.removedProperties;
/*     */   }
/*     */ 
/*     */   public static int createPropertyString(List<String> propStrings, Map<String, Serializable> propertyMap, String version)
/*     */   {
/* 257 */     int len = 0;
/* 258 */     for (Map.Entry entry : propertyMap.entrySet()) {
/* 259 */       String key = (String)entry.getKey();
/* 260 */       Serializable val = (Serializable)entry.getValue();
/* 261 */       len = addPropertyStringElement(key, val, propStrings, version, len);
/*     */     }
/* 263 */     return len;
/*     */   }
/*     */ 
/*     */   public static int createFilteredPropertyString(List<String> propStrings, Map<String, Serializable> propertyMap, String version, Set<String> filteredProps)
/*     */   {
/* 268 */     int len = 0;
/* 269 */     for (Map.Entry entry : propertyMap.entrySet()) {
/* 270 */       String key = (String)entry.getKey();
/* 271 */       if (filteredProps.contains(key))
/*     */         continue;
/* 273 */       Serializable val = (Serializable)entry.getValue();
/* 274 */       len = addPropertyStringElement(key, val, propStrings, version, len);
/*     */     }
/* 276 */     return len;
/*     */   }
/*     */ 
/*     */   protected static int addPropertyStringElement(String key, Serializable val, List<String> propStrings, String version, int len)
/*     */   {
/* 281 */     if ((val instanceof Boolean))
/*     */     {
/* 283 */       Boolean b = (Boolean)val;
/* 284 */       propStrings.add(key);
/* 285 */       propStrings.add("B");
/* 286 */       propStrings.add(b.booleanValue() ? "true" : "false");
/* 287 */       len++;
/* 288 */     } else if ((val instanceof Integer)) {
/* 289 */       propStrings.add(key);
/* 290 */       propStrings.add("I");
/* 291 */       propStrings.add(val.toString());
/* 292 */       len++;
/* 293 */     } else if ((val instanceof Long)) {
/* 294 */       propStrings.add(key);
/* 295 */       propStrings.add("L");
/* 296 */       propStrings.add(val.toString());
/* 297 */       len++;
/* 298 */     } else if ((val instanceof OID)) {
/* 299 */       propStrings.add(key);
/* 300 */       propStrings.add("O");
/* 301 */       propStrings.add(Long.toString(((OID)val).toLong()));
/* 302 */       len++;
/* 303 */     } else if ((val instanceof String)) {
/* 304 */       propStrings.add(key);
/* 305 */       propStrings.add("S");
/* 306 */       propStrings.add((String)val);
/* 307 */       len++;
/* 308 */     } else if ((val instanceof Float)) {
/* 309 */       propStrings.add(key);
/* 310 */       propStrings.add("F");
/* 311 */       propStrings.add(val.toString());
/* 312 */       len++;
/* 313 */     } else if ((val instanceof Point)) {
/* 314 */       if (version != null) {
/* 315 */         propStrings.add(key);
/* 316 */         propStrings.add("V");
/* 317 */         Point loc = (Point)val;
/* 318 */         propStrings.add(loc.toString());
/* 319 */         len++;
/*     */       }
/* 321 */     } else if ((val instanceof Quaternion)) {
/* 322 */       if (version != null) {
/* 323 */         propStrings.add(key);
/* 324 */         propStrings.add("Q");
/* 325 */         Quaternion q = (Quaternion)val;
/* 326 */         propStrings.add(q.toString());
/* 327 */         len++;
/*     */       }
/*     */     }
/* 330 */     else if (val == null) {
/* 331 */       Log.warn("propertyMessage: null value for key=" + key);
/*     */     }
/*     */     else {
/* 334 */       Log.warn("propertyMessage: unknown type '" + val.getClass().getName() + "', skipping key=" + key);
/*     */     }
/*     */ 
/* 338 */     if (Log.loggingDebug)
/* 339 */       Log.debug("propertyMessage: key=" + key + ", val=" + val);
/* 340 */     return len;
/*     */   }
/*     */ 
/*     */   public static Map<String, Serializable> unmarshallProperyMap(AOByteBuffer buffer) {
/* 344 */     int nProps = buffer.getInt();
/* 345 */     HashMap props = new HashMap(nProps);
/* 346 */     for (int ii = 0; ii < nProps; ii++) {
/* 347 */       String key = buffer.getString();
/* 348 */       String type = buffer.getString();
/* 349 */       String value = buffer.getString();
/* 350 */       if (type.equals("I")) {
/* 351 */         props.put(key, Integer.valueOf(value));
/*     */       }
/* 353 */       else if (type.equals("B")) {
/* 354 */         props.put(key, Boolean.valueOf(value));
/*     */       }
/* 356 */       else if (type.equals("L")) {
/* 357 */         props.put(key, Long.valueOf(value));
/*     */       }
/* 359 */       else if (type.equals("O")) {
/* 360 */         props.put(key, OID.fromLong(Long.valueOf(value).longValue()));
/*     */       }
/* 362 */       else if (type.equals("S")) {
/* 363 */         props.put(key, value);
/*     */       }
/* 365 */       else if (type.equals("F")) {
/* 366 */         props.put(key, Float.valueOf(value));
/*     */       }
/* 369 */       else if (Log.loggingDebug) {
/* 370 */         Log.debug("unmarshallProperyMap: unknown type '" + type + "', skipping key=" + key);
/*     */       }
/*     */     }
/*     */ 
/* 374 */     return props;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.PropertyMessage
 * JD-Core Version:    0.6.0
 */