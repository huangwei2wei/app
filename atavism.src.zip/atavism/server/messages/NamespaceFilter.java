/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.Message;
/*    */ import atavism.msgsys.MessageType;
/*    */ import atavism.msgsys.MessageTypeFilter;
/*    */ import atavism.server.engine.Namespace;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class NamespaceFilter extends MessageTypeFilter
/*    */   implements INamespaceFilter
/*    */ {
/*    */   private Collection<Namespace> namespaces;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public NamespaceFilter(Collection<Namespace> namespaces)
/*    */   {
/* 20 */     setNamespaces(namespaces);
/*    */   }
/*    */ 
/*    */   public NamespaceFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NamespaceFilter(MessageType msgType, Collection<Namespace> namespaces)
/*    */   {
/* 31 */     addType(msgType);
/* 32 */     setNamespaces(namespaces);
/*    */   }
/*    */ 
/*    */   public void setNamespaces(Collection<Namespace> namespaces) {
/* 36 */     this.namespaces = new ArrayList(namespaces);
/*    */   }
/*    */ 
/*    */   public Collection<Namespace> getNamespaces() {
/* 40 */     return this.namespaces;
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message msg) {
/* 44 */     if ((msg instanceof INamespaceMessage)) {
/* 45 */       INamespaceMessage namespaceMsg = (INamespaceMessage)msg;
/* 46 */       Namespace msgNamespace = namespaceMsg.getNamespace();
/* 47 */       boolean matches = this.namespaces.contains(msgNamespace);
/* 48 */       return matches;
/*    */     }
/* 50 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 54 */     return "[Some Namespace]";
/*    */   }
/*    */ 
/*    */   protected String toStringInternal()
/*    */   {
/* 59 */     String s = "";
/* 60 */     if (this.namespaces != null) {
/* 61 */       for (Namespace ns : this.namespaces) {
/* 62 */         if (s != "")
/* 63 */           s = s + ",";
/* 64 */         s = s + ns.getName();
/*    */       }
/*    */     }
/* 67 */     return super.toStringInternal() + " namespaces=" + s;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.NamespaceFilter
 * JD-Core Version:    0.6.0
 */