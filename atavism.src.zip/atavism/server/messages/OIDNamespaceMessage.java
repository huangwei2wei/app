/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.MessageType;
/*    */ import atavism.msgsys.SubjectMessage;
/*    */ import atavism.server.engine.Namespace;
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class OIDNamespaceMessage extends SubjectMessage
/*    */   implements INamespaceMessage
/*    */ {
/*    */   private Namespace namespace;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public OIDNamespaceMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public OIDNamespaceMessage(MessageType msgType)
/*    */   {
/* 18 */     setMsgType(msgType);
/*    */   }
/*    */ 
/*    */   public OIDNamespaceMessage(MessageType msgType, OID oid) {
/* 22 */     super(msgType, oid);
/*    */   }
/*    */ 
/*    */   public OIDNamespaceMessage(MessageType msgType, OID oid, Namespace namespace) {
/* 26 */     super(msgType, oid);
/* 27 */     setNamespace(namespace);
/*    */   }
/*    */ 
/*    */   public Namespace getNamespace() {
/* 31 */     return this.namespace;
/*    */   }
/*    */   public void setNamespace(Namespace namespace) {
/* 34 */     this.namespace = namespace;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.OIDNamespaceMessage
 * JD-Core Version:    0.6.0
 */