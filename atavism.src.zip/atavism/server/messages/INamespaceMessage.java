package atavism.server.messages;

import atavism.server.engine.Namespace;

public abstract interface INamespaceMessage
{
  public abstract Namespace getNamespace();

  public abstract void setNamespace(Namespace paramNamespace);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.INamespaceMessage
 * JD-Core Version:    0.6.0
 */