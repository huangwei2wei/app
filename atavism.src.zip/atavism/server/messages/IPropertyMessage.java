package atavism.server.messages;

import java.io.Serializable;

public abstract interface IPropertyMessage
{
  public abstract void setProperty(String paramString, Serializable paramSerializable);

  public abstract void removeProperty(String paramString);

  public abstract Serializable getProperty(String paramString);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.IPropertyMessage
 * JD-Core Version:    0.6.0
 */