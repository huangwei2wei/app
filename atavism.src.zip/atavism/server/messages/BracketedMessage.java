package atavism.server.messages;

import atavism.msgsys.Message;

public abstract interface BracketedMessage
{
  public abstract Message getPreMessage();

  public abstract Message getPostMessage();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.BracketedMessage
 * JD-Core Version:    0.6.0
 */