/*     */ package atavism.server.messages;
/*     */ 
/*     */ import atavism.msgsys.IFilter;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageTrigger;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class PerceptionTrigger extends MessageTrigger
/*     */ {
/*     */   private List<MessageType> msgTypes;
/* 122 */   private transient Map<OID, IntHolder> objectRefs = new HashMap();
/*     */   private transient PerceptionFilter filter;
/*     */ 
/*     */   public void setFilter(IFilter filter)
/*     */   {
/*  27 */     this.filter = ((PerceptionFilter)filter);
/*     */   }
/*     */ 
/*     */   public void setTriggeringTypes(Collection<MessageType> types)
/*     */   {
/*  33 */     this.msgTypes = new ArrayList(types.size());
/*  34 */     this.msgTypes.addAll(types);
/*     */   }
/*     */ 
/*     */   public boolean match(Message message)
/*     */   {
/*  44 */     if (this.msgTypes == null) {
/*  45 */       return message instanceof PerceptionMessage;
/*     */     }
/*     */ 
/*  48 */     return this.msgTypes.contains(message.getMsgType());
/*     */   }
/*     */ 
/*     */   public synchronized void trigger(Message triggeringMessage, IFilter triggeringFilter, MessageAgent agent)
/*     */   {
/*  61 */     PerceptionMessage message = (PerceptionMessage)triggeringMessage;
/*     */ 
/*  63 */     List gainObjects = message.getGainObjects();
/*  64 */     List lostObjects = message.getLostObjects();
/*     */ 
/*  66 */     if (gainObjects != null) {
/*  67 */       List newSubjects = new ArrayList(gainObjects.size());
/*     */ 
/*  70 */       for (PerceptionMessage.ObjectNote gain : gainObjects) {
/*  71 */         IntHolder refCount = (IntHolder)this.objectRefs.get(gain.subjectOid);
/*  72 */         if (refCount == null) {
/*  73 */           this.objectRefs.put(gain.subjectOid, new IntHolder(1));
/*  74 */           newSubjects.add(new PerceptionFilter.TypedSubject(gain.subjectOid, gain.objectType));
/*     */         }
/*     */         else
/*     */         {
/*  79 */           refCount.count += 1;
/*     */         }
/*     */       }
/*  82 */       if (newSubjects.size() > 0) {
/*  83 */         if (Log.loggingDebug)
/*  84 */           Log.debug("PerceptionTrigger adding " + newSubjects.size() + "; newSubjects: " + newSubjects.toString());
/*  85 */         this.filter.addSubjects(newSubjects);
/*     */       }
/*     */     }
/*     */ 
/*  89 */     if (lostObjects == null) {
/*  90 */       return;
/*     */     }
/*  92 */     List freeOids = new ArrayList(lostObjects.size());
/*     */ 
/*  94 */     for (PerceptionMessage.ObjectNote lost : lostObjects) {
/*  95 */       IntHolder refCount = (IntHolder)this.objectRefs.get(lost.subjectOid);
/*  96 */       if (refCount == null) {
/*  97 */         Log.error("PerceptionTrigger: duplicate lost " + lost.subjectOid);
/*  98 */       } else if (refCount.count == 1) {
/*  99 */         this.objectRefs.remove(lost.subjectOid);
/* 100 */         freeOids.add(lost.subjectOid);
/*     */       }
/*     */       else {
/* 103 */         refCount.count -= 1;
/*     */       }
/*     */     }
/* 106 */     if (freeOids.size() > 0) {
/* 107 */       if (Log.loggingDebug)
/* 108 */         Log.debug("PerceptionTrigger removing " + freeOids.size());
/* 109 */       this.filter.removeSubjects(freeOids);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class IntHolder
/*     */   {
/* 118 */     int count = 0;
/*     */ 
/*     */     IntHolder()
/*     */     {
/*     */     }
/*     */ 
/*     */     IntHolder(int initial)
/*     */     {
/* 116 */       this.count = initial;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.PerceptionTrigger
 * JD-Core Version:    0.6.0
 */