/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.Message;
/*    */ import atavism.server.engine.Namespace;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class SubObjectFilter extends PerceptionFilter
/*    */   implements INamespaceFilter
/*    */ {
/*    */   Collection<Namespace> namespaces;
/*    */ 
/*    */   public SubObjectFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SubObjectFilter(Collection<Namespace> namespaces)
/*    */   {
/* 21 */     setNamespaces(namespaces);
/*    */   }
/*    */ 
/*    */   public Collection<Namespace> getNamespaces()
/*    */   {
/* 26 */     return this.namespaces;
/*    */   }
/*    */ 
/*    */   public void setNamespaces(Collection<Namespace> namespaces)
/*    */   {
/* 31 */     this.namespaces = new ArrayList(namespaces);
/*    */   }
/*    */ 
/*    */   public boolean matchNamespace(Message message)
/*    */   {
/* 36 */     if ((message instanceof INamespaceMessage)) {
/* 37 */       INamespaceMessage namespaceMsg = (INamespaceMessage)message;
/* 38 */       Namespace msgNamespace = namespaceMsg.getNamespace();
/* 39 */       return this.namespaces.contains(msgNamespace);
/*    */     }
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean matchRemaining(Message message)
/*    */   {
/* 46 */     if (!matchNamespace(message))
/* 47 */       return false;
/* 48 */     return super.matchRemaining(message);
/*    */   }
/*    */ 
/*    */   protected boolean matchPerception(Message message)
/*    */   {
/* 53 */     return super.matchRemaining(message);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.SubObjectFilter
 * JD-Core Version:    0.6.0
 */