/*     */ package atavism.server.messages;
/*     */ 
/*     */ import atavism.msgsys.HasTarget;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.objects.ObjectType;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PerceptionMessage extends Message
/*     */   implements HasTarget
/*     */ {
/*     */   OID target;
/*     */   List<ObjectNote> gainObjects;
/*     */   List<ObjectNote> lostObjects;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public PerceptionMessage()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PerceptionMessage(MessageType msgType)
/*     */   {
/*  31 */     super(msgType);
/*     */   }
/*     */ 
/*     */   public PerceptionMessage(MessageType msgType, OID target)
/*     */   {
/*  37 */     super(msgType);
/*  38 */     this.target = target;
/*     */   }
/*     */ 
/*     */   public OID getTarget()
/*     */   {
/*  46 */     return this.target;
/*     */   }
/*     */ 
/*     */   public void setTarget(OID target)
/*     */   {
/*  53 */     this.target = target;
/*     */   }
/*     */ 
/*     */   public ObjectNote gainObject(OID targetOid, OID subjectOid, ObjectType objectType)
/*     */   {
/*  60 */     if (this.gainObjects == null)
/*  61 */       this.gainObjects = new LinkedList();
/*  62 */     ObjectNote note = new ObjectNote(targetOid, subjectOid, objectType);
/*  63 */     this.gainObjects.add(note);
/*  64 */     return note;
/*     */   }
/*     */ 
/*     */   public void gainObject(ObjectNote note)
/*     */   {
/*  70 */     if (this.gainObjects == null)
/*  71 */       this.gainObjects = new LinkedList();
/*  72 */     this.gainObjects.add(note);
/*     */   }
/*     */ 
/*     */   public void lostObject(OID targetOid, OID subjectOid)
/*     */   {
/*  78 */     if (this.lostObjects == null)
/*  79 */       this.lostObjects = new LinkedList();
/*  80 */     this.lostObjects.add(new ObjectNote(targetOid, subjectOid));
/*     */   }
/*     */ 
/*     */   public void lostObject(OID targetOid, OID subjectOid, ObjectType objectType)
/*     */   {
/*  86 */     if (this.lostObjects == null)
/*  87 */       this.lostObjects = new LinkedList();
/*  88 */     this.lostObjects.add(new ObjectNote(targetOid, subjectOid, objectType));
/*     */   }
/*     */ 
/*     */   public void lostObject(ObjectNote note)
/*     */   {
/*  94 */     if (this.lostObjects == null)
/*  95 */       this.lostObjects = new LinkedList();
/*  96 */     this.lostObjects.add(note);
/*     */   }
/*     */ 
/*     */   public List<ObjectNote> getGainObjects()
/*     */   {
/* 104 */     return this.gainObjects;
/*     */   }
/*     */ 
/*     */   public List<ObjectNote> getLostObjects()
/*     */   {
/* 112 */     return this.lostObjects;
/*     */   }
/*     */ 
/*     */   public int getGainObjectCount()
/*     */   {
/* 118 */     return this.gainObjects == null ? 0 : this.gainObjects.size();
/*     */   }
/*     */ 
/*     */   public int getLostObjectCount()
/*     */   {
/* 124 */     return this.lostObjects == null ? 0 : this.lostObjects.size();
/*     */   }
/*     */   public static class ObjectNote {
/*     */     OID targetOid;
/*     */     OID subjectOid;
/*     */     ObjectType objectType;
/*     */     Object info;
/*     */ 
/*     */     public ObjectNote() {  }
/*     */ 
/* 137 */     public ObjectNote(OID targetOid, OID subjectOid) { this.targetOid = targetOid;
/* 138 */       this.subjectOid = subjectOid;
/*     */     }
/*     */ 
/*     */     public ObjectNote(OID targetOid, OID subjectOid, ObjectType objectType)
/*     */     {
/* 144 */       this.targetOid = targetOid;
/* 145 */       this.subjectOid = subjectOid;
/* 146 */       this.objectType = objectType;
/*     */     }
/*     */ 
/*     */     public ObjectNote(OID targetOid, OID subjectOid, ObjectType objectType, Object info)
/*     */     {
/* 153 */       this.targetOid = targetOid;
/* 154 */       this.subjectOid = subjectOid;
/* 155 */       this.objectType = objectType;
/* 156 */       this.info = info;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 160 */       return "targ=" + this.targetOid + " subj=" + this.subjectOid + " t=" + this.objectType;
/*     */     }
/*     */ 
/*     */     public OID getTarget()
/*     */     {
/* 165 */       return this.targetOid;
/*     */     }
/*     */ 
/*     */     public OID getSubject()
/*     */     {
/* 170 */       return this.subjectOid;
/*     */     }
/*     */ 
/*     */     public ObjectType getObjectType()
/*     */     {
/* 175 */       return this.objectType;
/*     */     }
/*     */ 
/*     */     public Object getObjectInfo()
/*     */     {
/* 180 */       return this.info;
/*     */     }
/*     */ 
/*     */     public void setObjectInfo(Object info)
/*     */     {
/* 185 */       this.info = info;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.PerceptionMessage
 * JD-Core Version:    0.6.0
 */