package atavism.server.messages;

import atavism.msgsys.IMessageTypeFilter;
import atavism.server.engine.Namespace;
import java.util.Collection;

public abstract interface INamespaceFilter extends IMessageTypeFilter
{
  public abstract Collection<Namespace> getNamespaces();

  public abstract void setNamespaces(Collection<Namespace> paramCollection);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.INamespaceFilter
 * JD-Core Version:    0.6.0
 */