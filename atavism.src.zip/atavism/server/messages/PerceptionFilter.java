/*     */ package atavism.server.messages;
/*     */ 
/*     */ import atavism.msgsys.AgentHandle;
/*     */ import atavism.msgsys.Filter;
/*     */ import atavism.msgsys.FilterUpdate;
/*     */ import atavism.msgsys.FilterUpdate.Instruction;
/*     */ import atavism.msgsys.IMessageTypeFilter;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.msgsys.SubjectMessage;
/*     */ import atavism.msgsys.SubscriptionHandle;
/*     */ import atavism.msgsys.TargetMessage;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.marshalling.Marshallable;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.objects.ObjectType;
/*     */ import atavism.server.objects.ObjectTypes;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class PerceptionFilter extends Filter
/*     */   implements Marshallable, IMessageTypeFilter
/*     */ {
/*     */   public static final int FIELD_TARGETS = 1;
/*     */   public static final int FIELD_SUBJECTS = 2;
/* 504 */   private Set<MessageType> messageTypes = new HashSet();
/* 505 */   private Map<OID, IntHolder> targets = new HashMap();
/*     */ 
/* 507 */   private transient Map<OID, SubjectInfo> subjects = new HashMap();
/* 508 */   private transient boolean matchAllSubjects = false;
/* 509 */   private boolean matchSubjects = false;
/*     */   private List<ObjectType> subjectTypeFilter;
/* 512 */   private static List<PerceptionUpdateTrigger> updateTriggers = new LinkedList();
/*     */ 
/*     */   public PerceptionFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PerceptionFilter(Collection<MessageType> types)
/*     */   {
/*  53 */     this.messageTypes.addAll(types);
/*     */   }
/*     */ 
/*     */   public void setTypes(Collection<MessageType> types)
/*     */   {
/*  60 */     this.messageTypes = new HashSet();
/*  61 */     this.messageTypes.addAll(types);
/*     */   }
/*     */ 
/*     */   public void addType(MessageType type)
/*     */   {
/*  68 */     this.messageTypes.add(type);
/*     */   }
/*     */ 
/*     */   public Collection<MessageType> getMessageTypes()
/*     */   {
/*  75 */     return this.messageTypes;
/*     */   }
/*     */ 
/*     */   public boolean getMatchAllSubjects()
/*     */   {
/*  82 */     return this.matchAllSubjects;
/*     */   }
/*     */ 
/*     */   public void setMatchAllSubjects(boolean match)
/*     */   {
/*  91 */     this.matchAllSubjects = match;
/*     */   }
/*     */ 
/*     */   public boolean getMatchSubjects()
/*     */   {
/*  98 */     return this.matchSubjects;
/*     */   }
/*     */ 
/*     */   public void setMatchSubjects(boolean match)
/*     */   {
/* 105 */     this.matchSubjects = match;
/*     */   }
/*     */ 
/*     */   public synchronized boolean addSubject(OID oid)
/*     */   {
/* 113 */     SubjectInfo holder = (SubjectInfo)this.subjects.get(oid);
/* 114 */     if (holder == null) {
/* 115 */       this.subjects.put(oid, new SubjectInfo(1, ObjectTypes.unknown));
/* 116 */       return true;
/*     */     }
/* 118 */     holder.count += 1;
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean addSubjectIfMissing(OID oid)
/*     */   {
/* 126 */     SubjectInfo holder = (SubjectInfo)this.subjects.get(oid);
/* 127 */     if (holder == null) {
/* 128 */       this.subjects.put(oid, new SubjectInfo(1, ObjectTypes.unknown));
/* 129 */       return true;
/*     */     }
/*     */ 
/* 132 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean hasSubject(OID oid)
/*     */   {
/* 139 */     return this.subjects.containsKey(oid);
/*     */   }
/*     */ 
/*     */   synchronized void addSubjects(Collection<TypedSubject> newSubjects)
/*     */   {
/* 146 */     for (TypedSubject subject : newSubjects) {
/* 147 */       if (this.subjects.get(subject.oid) != null)
/* 148 */         Log.error("PerceptionFilter: already have subject " + subject.oid);
/* 149 */       this.subjects.put(subject.oid, new SubjectInfo(1, subject.type));
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized boolean removeSubject(OID oid)
/*     */   {
/* 158 */     IntHolder holder = (IntHolder)this.subjects.get(oid);
/* 159 */     if (holder == null) {
/* 160 */       Log.error("PerceptionFilter.removeSubject: oid " + oid + " not found");
/* 161 */       return false;
/*     */     }
/* 163 */     holder.count -= 1;
/* 164 */     if (holder.count == 0) {
/* 165 */       this.subjects.remove(oid);
/* 166 */       return true;
/*     */     }
/*     */ 
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   synchronized void removeSubjects(Collection<OID> freeOids)
/*     */   {
/* 176 */     for (OID oid : freeOids) {
/* 177 */       if (this.subjects.get(oid) == null)
/* 178 */         Log.error("PerceptionFilter.removeSubjects: duplicate remove " + oid);
/* 179 */       this.subjects.remove(oid);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized boolean addTarget(OID oid)
/*     */   {
/* 192 */     IntHolder holder = (IntHolder)this.targets.get(oid);
/* 193 */     if (holder == null) {
/* 194 */       this.targets.put(oid, new IntHolder(1));
/* 195 */       return true;
/*     */     }
/* 197 */     holder.count += 1;
/* 198 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean hasTarget(OID oid)
/*     */   {
/* 205 */     return this.targets.containsKey(oid);
/*     */   }
/*     */ 
/*     */   public synchronized void setSubjectObjectTypes(Collection<ObjectType> subjectTypes)
/*     */   {
/* 216 */     if (subjectTypes != null)
/* 217 */       this.subjectTypeFilter = new ArrayList(subjectTypes);
/*     */     else
/* 219 */       this.subjectTypeFilter = null;
/*     */   }
/*     */ 
/*     */   public synchronized List<ObjectType> getSubjectObjectTypes()
/*     */   {
/* 227 */     return new ArrayList(this.subjectTypeFilter);
/*     */   }
/*     */ 
/*     */   public synchronized boolean removeTarget(OID oid)
/*     */   {
/* 237 */     IntHolder holder = (IntHolder)this.targets.get(oid);
/* 238 */     if (holder == null) {
/* 239 */       Log.error("PerceptionFilter.removeTarget: oid " + oid + " not found");
/* 240 */       return false;
/*     */     }
/* 242 */     holder.count -= 1;
/* 243 */     if (holder.count == 0) {
/* 244 */       this.targets.remove(oid);
/* 245 */       return true;
/*     */     }
/* 247 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean matchMessageType(Collection<MessageType> types)
/*     */   {
/* 255 */     for (MessageType tt : types) {
/* 256 */       if (this.messageTypes.contains(tt)) {
/* 257 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 261 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean matchRemaining(Message message)
/*     */   {
/* 275 */     if ((message instanceof PerceptionMessage)) {
/* 276 */       PerceptionMessage msg = (PerceptionMessage)message;
/* 277 */       if (this.targets.get(msg.getTarget()) != null)
/* 278 */         return true;
/* 279 */       List gainObjects = msg.getGainObjects();
/* 280 */       if (gainObjects != null) {
/* 281 */         for (PerceptionMessage.ObjectNote gain : gainObjects) {
/* 282 */           if (this.targets.get(gain.targetOid) != null)
/* 283 */             return true;
/*     */         }
/*     */       }
/* 286 */       List lostObjects = msg.getLostObjects();
/* 287 */       if (lostObjects != null) {
/* 288 */         for (PerceptionMessage.ObjectNote lost : lostObjects) {
/* 289 */           if (this.targets.get(lost.targetOid) != null)
/* 290 */             return true;
/*     */         }
/*     */       }
/* 293 */       return false;
/*     */     }
/*     */ 
/* 296 */     if ((message instanceof TargetMessage)) {
/* 297 */       TargetMessage msg = (TargetMessage)message;
/* 298 */       if (this.targets.get(msg.getTarget()) != null) {
/* 299 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 310 */     if ((message instanceof SubjectMessage)) {
/* 311 */       if (this.matchAllSubjects)
/* 312 */         return true;
/* 313 */       SubjectMessage msg = (SubjectMessage)message;
/* 314 */       SubjectInfo subjectInfo = (SubjectInfo)this.subjects.get(msg.getSubject());
/* 315 */       if (subjectInfo != null)
/*     */       {
/* 318 */         return (this.subjectTypeFilter == null) || (this.subjectTypeFilter.contains(subjectInfo.type));
/*     */       }
/*     */ 
/* 322 */       if (this.targets.get(msg.getSubject()) != null) {
/* 323 */         return true;
/*     */       }
/*     */     }
/* 326 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean applyFilterUpdate(FilterUpdate update, AgentHandle sender, SubscriptionHandle sub)
/*     */   {
/* 341 */     List instructions = update.getInstructions();
/*     */     Iterator i$;
/* 343 */     if ((updateTriggers.size() > 0) && (sender != null)) {
/* 344 */       for (i$ = instructions.iterator(); i$.hasNext(); ) { instruction = (FilterUpdate.Instruction)i$.next();
/* 345 */         for (PerceptionUpdateTrigger updateTrigger : updateTriggers) {
/* 346 */           updateTrigger.preUpdate(this, instruction, sender, sub);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 351 */     synchronized (this)
/*     */     {
/*     */       FilterUpdate.Instruction instruction;
/* 352 */       for (FilterUpdate.Instruction instruction : instructions)
/* 353 */         switch (instruction.opCode) {
/*     */         case 2:
/* 355 */           if (instruction.fieldId == 1) {
/* 356 */             if (Log.loggingDebug)
/* 357 */               Log.debug("ADD TARGET " + instruction.value);
/* 358 */             this.targets.put((OID)instruction.value, new IntHolder(1));
/*     */           }
/* 360 */           else if (instruction.fieldId == 2) {
/* 361 */             if (Log.loggingDebug)
/* 362 */               Log.debug("ADD SUBJECT " + instruction.value);
/* 363 */             this.subjects.put((OID)instruction.value, new SubjectInfo(1, ObjectTypes.unknown));
/*     */           }
/*     */           else
/*     */           {
/* 367 */             Log.error("PerceptionFilter.applyFilterUpdate: invalid fieldId " + instruction.fieldId);
/*     */           }
/* 369 */           break;
/*     */         case 3:
/* 371 */           if (instruction.fieldId == 1) {
/* 372 */             if (Log.loggingDebug)
/* 373 */               Log.debug("REMOVE TARGET " + instruction.value);
/* 374 */             this.targets.remove((OID)instruction.value);
/*     */           }
/* 376 */           else if (instruction.fieldId == 2) {
/* 377 */             if (Log.loggingDebug)
/* 378 */               Log.debug("REMOVE SUBJECT " + instruction.value);
/* 379 */             this.subjects.remove((OID)instruction.value);
/*     */           }
/*     */           else {
/* 382 */             Log.error("PerceptionFilter.applyFilterUpdate: invalid fieldId " + instruction.fieldId);
/*     */           }
/* 384 */           break;
/*     */         case 1:
/* 386 */           Log.error("PerceptionFilter.applyFilterUpdate: OP_SET is not supported");
/* 387 */           break;
/*     */         default:
/* 389 */           Log.error("PerceptionFilter.applyFilterUpdate: invalid opCode " + instruction.opCode);
/*     */         }
/*     */     }
/*     */     Iterator i$;
/* 396 */     if ((updateTriggers.size() > 0) && (sender != null))
/* 397 */       for (i$ = instructions.iterator(); i$.hasNext(); ) { instruction = (FilterUpdate.Instruction)i$.next();
/* 398 */         for (PerceptionUpdateTrigger updateTrigger : updateTriggers)
/* 399 */           updateTrigger.postUpdate(this, instruction, sender, sub);
/*     */       }
/*     */     FilterUpdate.Instruction instruction;
/* 404 */     return false;
/*     */   }
/*     */ 
/*     */   public static void addUpdateTrigger(PerceptionUpdateTrigger updateTrigger)
/*     */   {
/* 409 */     synchronized (updateTriggers) {
/* 410 */       updateTriggers.add(updateTrigger);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void marshalObject(AOByteBuffer buf)
/*     */   {
/* 418 */     buf.putInt(this.messageTypes.size());
/* 419 */     for (MessageType type : this.messageTypes) {
/* 420 */       type.marshalObject(buf);
/*     */     }
/* 422 */     buf.putBoolean(this.matchSubjects);
/*     */ 
/* 424 */     buf.putInt(this.targets.size());
/* 425 */     for (OID oid : this.targets.keySet()) {
/* 426 */       buf.putOID(oid);
/*     */     }
/* 428 */     if (this.matchSubjects) {
/* 429 */       buf.putInt(this.subjects.size());
/* 430 */       for (OID oid : this.subjects.keySet())
/* 431 */         buf.putOID(oid);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object unmarshalObject(AOByteBuffer buf)
/*     */   {
/* 439 */     int size = buf.getInt();
/* 440 */     for (; size > 0; size--) {
/* 441 */       MessageType type = new MessageType();
/* 442 */       type = (MessageType)type.unmarshalObject(buf);
/* 443 */       this.messageTypes.add(type);
/*     */     }
/*     */ 
/* 446 */     this.matchSubjects = buf.getBoolean();
/*     */ 
/* 448 */     size = buf.getInt();
/* 449 */     for (; size > 0; size--) {
/* 450 */       this.targets.put(buf.getOID(), new IntHolder(1));
/*     */     }
/* 452 */     if (this.matchSubjects) {
/* 453 */       size = buf.getInt();
/* 454 */       for (; size > 0; size--) {
/* 455 */         this.subjects.put(buf.getOID(), new SubjectInfo(1, ObjectTypes.unknown));
/*     */       }
/*     */     }
/*     */ 
/* 459 */     return this;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 463 */     return "[PerceptionFilter " + toStringInternal() + "]";
/*     */   }
/*     */ 
/*     */   protected String toStringInternal() {
/* 467 */     String result = "types=";
/* 468 */     for (MessageType type : this.messageTypes)
/* 469 */       result = result + type.getMsgTypeString() + ",";
/* 470 */     result = result + " subjectCount=" + this.subjects.size();
/* 471 */     result = result + " targets=";
/* 472 */     for (OID oid : this.targets.keySet())
/* 473 */       result = result + oid + ",";
/* 474 */     return result;
/*     */   }
/*     */ 
/*     */   public static class TypedSubject
/*     */   {
/*     */     OID oid;
/*     */     ObjectType type;
/*     */ 
/*     */     public TypedSubject(OID subjectOid, ObjectType objectType)
/*     */     {
/* 497 */       this.oid = subjectOid;
/* 498 */       this.type = objectType;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class SubjectInfo extends PerceptionFilter.IntHolder
/*     */   {
/*     */     ObjectType type;
/*     */ 
/*     */     SubjectInfo()
/*     */     {
/* 486 */       super();
/*     */     }
/* 488 */     SubjectInfo(int initial, ObjectType objectType) { super(initial);
/* 489 */       this.type = objectType;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class IntHolder
/*     */   {
/* 482 */     int count = 0;
/*     */ 
/*     */     IntHolder()
/*     */     {
/*     */     }
/*     */ 
/*     */     IntHolder(int initial)
/*     */     {
/* 480 */       this.count = initial;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.PerceptionFilter
 * JD-Core Version:    0.6.0
 */