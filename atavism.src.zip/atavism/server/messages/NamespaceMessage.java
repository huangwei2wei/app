/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.Message;
/*    */ import atavism.msgsys.MessageType;
/*    */ import atavism.server.engine.Namespace;
/*    */ 
/*    */ public class NamespaceMessage extends Message
/*    */   implements INamespaceMessage
/*    */ {
/*    */   private Namespace namespace;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public NamespaceMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NamespaceMessage(MessageType msgType)
/*    */   {
/* 16 */     super(msgType);
/*    */   }
/*    */ 
/*    */   public NamespaceMessage(MessageType msgType, Namespace namespace) {
/* 20 */     super(msgType);
/* 21 */     setNamespace(namespace);
/*    */   }
/*    */ 
/*    */   public Namespace getNamespace() {
/* 25 */     return this.namespace;
/*    */   }
/*    */   public void setNamespace(Namespace namespace) {
/* 28 */     this.namespace = namespace;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.NamespaceMessage
 * JD-Core Version:    0.6.0
 */