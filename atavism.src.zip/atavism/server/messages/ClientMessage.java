package atavism.server.messages;

import atavism.server.network.AOByteBuffer;

public abstract interface ClientMessage
{
  public abstract AOByteBuffer toBuffer();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.ClientMessage
 * JD-Core Version:    0.6.0
 */