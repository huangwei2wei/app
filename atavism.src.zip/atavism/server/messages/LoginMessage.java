/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.MessageType;
/*    */ import atavism.msgsys.SubjectMessage;
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class LoginMessage extends SubjectMessage
/*    */ {
/*    */   private String playerName;
/*    */   private OID instanceOid;
/* 54 */   public static final MessageType MSG_TYPE_LOGIN = MessageType.intern("ao.LOGIN");
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public LoginMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LoginMessage(OID playerOid, String playerName)
/*    */   {
/* 19 */     super(MSG_TYPE_LOGIN, playerOid);
/* 20 */     setPlayerName(playerName);
/*    */   }
/*    */ 
/*    */   public String getPlayerName()
/*    */   {
/* 27 */     return this.playerName;
/*    */   }
/*    */ 
/*    */   public void setPlayerName(String name)
/*    */   {
/* 34 */     this.playerName = name;
/*    */   }
/*    */ 
/*    */   public OID getInstanceOid()
/*    */   {
/* 40 */     return this.instanceOid;
/*    */   }
/*    */ 
/*    */   public void setInstanceOid(OID oid)
/*    */   {
/* 46 */     this.instanceOid = oid;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.LoginMessage
 * JD-Core Version:    0.6.0
 */