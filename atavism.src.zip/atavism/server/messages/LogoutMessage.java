/*    */ package atavism.server.messages;
/*    */ 
/*    */ import atavism.msgsys.MessageType;
/*    */ import atavism.msgsys.SubjectMessage;
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class LogoutMessage extends SubjectMessage
/*    */ {
/*    */   private String playerName;
/* 41 */   public static final MessageType MSG_TYPE_LOGOUT = MessageType.intern("ao.LOGOUT");
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public LogoutMessage()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LogoutMessage(OID playerOid, String playerName)
/*    */   {
/* 19 */     super(MSG_TYPE_LOGOUT, playerOid);
/* 20 */     setPlayerName(playerName);
/*    */   }
/*    */ 
/*    */   public String getPlayerName()
/*    */   {
/* 27 */     return this.playerName;
/*    */   }
/*    */ 
/*    */   public void setPlayerName(String name)
/*    */   {
/* 34 */     this.playerName = name;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.messages.LogoutMessage
 * JD-Core Version:    0.6.0
 */