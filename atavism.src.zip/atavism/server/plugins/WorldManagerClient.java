/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.msgsys.HasTarget;
/*      */ import atavism.msgsys.ITargetSessionId;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageType;
/*      */ import atavism.msgsys.NoRecipientsException;
/*      */ import atavism.msgsys.ResponseMessage;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.msgsys.TargetMessage;
/*      */ import atavism.server.engine.BasicWorldNode;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.EnginePlugin;
/*      */ import atavism.server.engine.EventParser;
/*      */ import atavism.server.engine.EventServer;
/*      */ import atavism.server.engine.Namespace;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.math.AOVector;
/*      */ import atavism.server.math.Geometry;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.math.Quaternion;
/*      */ import atavism.server.messages.BracketedMessage;
/*      */ import atavism.server.messages.ClientMessage;
/*      */ import atavism.server.messages.IPropertyMessage;
/*      */ import atavism.server.messages.PropertyMessage;
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.objects.Color;
/*      */ import atavism.server.objects.DisplayContext;
/*      */ import atavism.server.objects.DisplayContext.Submesh;
/*      */ import atavism.server.objects.Entity;
/*      */ import atavism.server.objects.Fog;
/*      */ import atavism.server.objects.FogRegionConfig;
/*      */ import atavism.server.objects.LightData;
/*      */ import atavism.server.objects.Marker;
/*      */ import atavism.server.objects.ObjectType;
/*      */ import atavism.server.objects.ObjectTypes;
/*      */ import atavism.server.objects.Region;
/*      */ import atavism.server.objects.Road;
/*      */ import atavism.server.objects.RoadSegment;
/*      */ import atavism.server.objects.SoundData;
/*      */ import atavism.server.pathing.PathInterpolator;
/*      */ import atavism.server.pathing.PathLinear;
/*      */ import atavism.server.pathing.PathLocAndDir;
/*      */ import atavism.server.pathing.PathSpline;
/*      */ import atavism.server.util.AnimationCommand;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ public class WorldManagerClient
/*      */ {
/*      */   public static final int NO_FLAGS = 0;
/*      */   public static final int SAVE_NOW = 1;
/*      */   public static final byte modifyDisplayContextActionReplace = 1;
/*      */   public static final byte modifyDisplayContextActionAdd = 2;
/*      */   public static final byte modifyDisplayContextActionAddChild = 3;
/*      */   public static final byte modifyDisplayContextActionRemove = 4;
/*      */   public static final byte modifyDisplayContextActionRemoveChild = 5;
/* 3136 */   public static final String WMGR_LAST_SAVED_PROP = (String)Entity.registerTransientPropertyKey("wmgr.lastSaved");
/*      */ 
/* 3141 */   public static Long WMGR_SAVE_INTERVAL_MS = Long.valueOf(60000L);
/*      */ 
/* 3144 */   public static MessageType MSG_TYPE_NEW_DIRLIGHT = MessageType.intern("ao.NEW_DIRLIGHT");
/* 3145 */   public static MessageType MSG_TYPE_FREE_OBJECT = MessageType.intern("ao.FREE_OBJECT");
/*      */ 
/* 3148 */   public static MessageType MSG_TYPE_SET_AMBIENT = MessageType.intern("ao.SET_AMBIENT");
/*      */ 
/* 3150 */   public static MessageType MSG_TYPE_TERRAIN_REQ = MessageType.intern("ao.TERRAIN_REQ");
/*      */ 
/* 3152 */   public static MessageType MSG_TYPE_OBJINFO_REQ = MessageType.intern("ao.OBJINFO_REQ");
/*      */ 
/* 3154 */   public static MessageType MSG_TYPE_DC_REQ = MessageType.intern("ao.DC_REQ");
/*      */ 
/* 3156 */   public static MessageType MSG_TYPE_FOG = MessageType.intern("ao.FOG");
/*      */ 
/* 3159 */   public static MessageType MSG_TYPE_SPAWN_REQ = MessageType.intern("ao.SPAWN_REQ");
/*      */ 
/* 3162 */   public static MessageType MSG_TYPE_SPAWNED = MessageType.intern("ao.SPAWNED");
/*      */ 
/* 3165 */   public static MessageType MSG_TYPE_DESPAWN_REQ = MessageType.intern("ao.DESPAWN_REQ");
/*      */ 
/* 3168 */   public static MessageType MSG_TYPE_DESPAWNED = MessageType.intern("ao.DESPAWNED");
/*      */ 
/* 3170 */   public static MessageType MSG_TYPE_UPDATE_OBJECT = MessageType.intern("ao.UPDATE_OBJECT");
/*      */ 
/* 3172 */   public static MessageType MSG_TYPE_DISPLAY_CONTEXT = MessageType.intern("ao.DISPLAY_CONTEXT");
/*      */ 
/* 3174 */   public static MessageType MSG_TYPE_ANIMATION = MessageType.intern("ao.ANIMATION");
/*      */ 
/* 3176 */   public static MessageType MSG_TYPE_SETWNODE_REQ = MessageType.intern("ao.SETWNODE_REQ");
/*      */ 
/* 3178 */   public static MessageType MSG_TYPE_UPDATEWNODE_REQ = MessageType.intern("ao.UPDATEWNODE_REQ");
/*      */ 
/* 3180 */   public static MessageType MSG_TYPE_GETWNODE_REQ = MessageType.intern("ao.GETWNODE_REQ");
/*      */ 
/* 3182 */   public static MessageType MSG_TYPE_GET_OBJECTS_IN = MessageType.intern("ao.GET_OBJECTS_IN");
/*      */ 
/* 3184 */   public static MessageType MSG_TYPE_TARGETED_PROPERTY = MessageType.intern("ao.TARGETED_PROPERTY");
/*      */ 
/* 3186 */   public static MessageType MSG_TYPE_COM_REQ = MessageType.intern("ao.COM_REQ");
/*      */ 
/* 3188 */   public static MessageType MSG_TYPE_COM = MessageType.intern("ao.COM");
/*      */ 
/* 3190 */   public static MessageType MSG_TYPE_SYS_CHAT = MessageType.intern("ao.SYS_CHAT");
/*      */ 
/* 3192 */   public static MessageType MSG_TYPE_UPDATEWNODE = MessageType.intern("ao.UPDATEWNODE");
/*      */ 
/* 3194 */   public static MessageType MSG_TYPE_WNODECORRECT = MessageType.intern("ao.WNODECORRECT");
/*      */ 
/* 3196 */   public static MessageType MSG_TYPE_ORIENT_REQ = MessageType.intern("ao.ORIENT_REQ");
/*      */ 
/* 3198 */   public static MessageType MSG_TYPE_ORIENT = MessageType.intern("ao.ORIENT");
/*      */ 
/* 3200 */   public static MessageType MSG_TYPE_REFRESH_WNODE = MessageType.intern("ao.REFRESH_WNODE");
/*      */ 
/* 3202 */   public static MessageType MSG_TYPE_PERCEIVER_REGIONS = MessageType.intern("ao.PERCEIVER_REGIONS");
/*      */ 
/* 3204 */   public static MessageType MSG_TYPE_NEW_REMOTE_OBJ = MessageType.intern("ao.NEW_REMOTE_OBJ");
/*      */ 
/* 3206 */   public static MessageType MSG_TYPE_FREE_REMOTE_OBJ = MessageType.intern("ao.FREE_REMOTE_OBJ");
/*      */ 
/* 3208 */   public static MessageType MSG_TYPE_ROAD = MessageType.intern("ao.ROAD");
/*      */ 
/* 3210 */   public static MessageType MSG_TYPE_FREE_ROAD = MessageType.intern("ao.FREE_ROAD");
/*      */ 
/* 3212 */   public static MessageType MSG_TYPE_NEW_REGION = MessageType.intern("ao.NEW_REGION");
/*      */ 
/* 3214 */   public static MessageType MSG_TYPE_SOUND = MessageType.intern("ao.SOUND");
/*      */ 
/* 3216 */   public static MessageType MSG_TYPE_MODIFY_DC = MessageType.intern("ao.MODIFY_DC");
/*      */ 
/* 3218 */   public static MessageType MSG_TYPE_DETACH = MessageType.intern("ao.DETACH");
/*      */ 
/* 3220 */   public static MessageType MSG_TYPE_REPARENT_WNODE_REQ = MessageType.intern("ao.REPARENT_WNODE_REQ");
/*      */ 
/* 3222 */   public static MessageType MSG_TYPE_EXTENSION = MessageType.intern("ao.EXTENSION");
/*      */ 
/* 3224 */   public static MessageType MSG_TYPE_MOB_PATH = MessageType.intern("ao.MOB_PATH");
/*      */ 
/* 3226 */   public static MessageType MSG_TYPE_MOB_PATH_REQ = MessageType.intern("ao.MOB_PATH_REQ");
/*      */ 
/* 3228 */   public static MessageType MSG_TYPE_MOB_PATH_CORRECTION = MessageType.intern("ao.MOB_PATH_CORRECTION");
/*      */ 
/* 3230 */   public static MessageType MSG_TYPE_DIR_LOC_ORIENT = MessageType.intern("ao.DIR_LOC_ORIENT");
/*      */ 
/* 3232 */   public static MessageType MSG_TYPE_PERCEPTION = MessageType.intern("ao.PERCEPTION");
/* 3233 */   public static MessageType MSG_TYPE_PERCEPTION_INFO = MessageType.intern("ao.PERCEPTION_INFO");
/*      */ 
/* 3235 */   public static MessageType MSG_TYPE_P2P_EXTENSION = MessageType.intern("ao.P2P_EXTENSION");
/* 3236 */   public static MessageType MSG_TYPE_HOST_INSTANCE = MessageType.intern("ao.HOST_INSTANCE");
/*      */ 
/* 3238 */   public static MessageType MSG_TYPE_PLAYER_PATH_WM_REQ = MessageType.intern("ao.PLAYER_PATH_WM_REQ");
/*      */   public static final String WORLD_PROP_NOMOVE = "world.nomove";
/*      */   public static final String WORLD_PROP_NOTURN = "world.noturn";
/*      */   public static final String ACCOUNT_PROPERTY = "accountId";
/* 3249 */   public static String TEMPL_LOC = ":loc";
/* 3250 */   public static String TEMPL_INSTANCE = ":instance";
/*      */ 
/* 3252 */   public static String TEMPL_NAME = ":entityName";
/* 3253 */   public static String TEMPL_ORIENT = ":orient";
/*      */ 
/* 3255 */   public static String TEMPL_SCALE = ":scale";
/* 3256 */   public static String TEMPL_PERCEPTION_RADIUS = ":percRadius";
/*      */ 
/* 3258 */   public static String TEMPL_FOLLOWS_TERRAIN = ":followsTerrain";
/*      */ 
/* 3260 */   public static String TEMPL_RUN_THRESHOLD = "runThreshold";
/*      */ 
/* 3262 */   public static String TEMPL_TERRAIN_DECAL_DATA = "terrainDecal";
/* 3263 */   public static String TEMPL_SOUND_DATA_LIST = "soundData";
/* 3264 */   public static String TEMPL_ID = "templateID";
/*      */ 
/* 3269 */   public static String TEMPL_OBJECT_TYPE = ":objType";
/* 3270 */   public static ObjectType TEMPL_OBJECT_TYPE_MOB = ObjectTypes.mob;
/* 3271 */   public static ObjectType TEMPL_OBJECT_TYPE_PLAYER = ObjectTypes.player;
/* 3272 */   public static ObjectType TEMPL_OBJECT_TYPE_LIGHT = ObjectTypes.light;
/* 3273 */   public static ObjectType TEMPL_OBJECT_TYPE_ITEM = ObjectTypes.item;
/* 3274 */   public static ObjectType TEMPL_OBJECT_TYPE_STRUCTURE = ObjectTypes.structure;
/* 3275 */   public static ObjectType TEMPL_OBJECT_TYPE_TERRAIN_DECAL = ObjectTypes.terrainDecal;
/* 3276 */   public static ObjectType TEMPL_OBJECT_TYPE_POINT_SOUND = ObjectTypes.pointSound;
/* 3277 */   public static ObjectType TEMPL_OBJECT_TYPE_MARKER = Marker.OBJECT_TYPE;
/*      */ 
/* 3282 */   public static String TEMPL_DISPLAY_CONTEXT = ":displayContext";
/*      */   public static final String TEMPL_WORLDMGR_NAME = ":wmName";
/* 3290 */   public static String MOB_PATH_PROPERTY = "MobPathMsg";
/*      */ 
/* 3292 */   public static String MSG_PROP_LOC = "msgPropLoc";
/*      */ 
/* 3294 */   public static Namespace NAMESPACE = null;
/* 3295 */   public static Namespace INSTANCE_NAMESPACE = null;
/*      */ 
/*      */   public static boolean setWorldNode(OID oid, BasicWorldNode wnode)
/*      */   {
/*   26 */     return setWorldNode(oid, wnode, 0);
/*      */   }
/*      */ 
/*      */   public static boolean setWorldNode(OID oid, BasicWorldNode wnode, int flags)
/*      */   {
/*   37 */     Log.debug("WorldManagerClient.setWorldNode: oid=" + oid + " node=" + wnode + " flags=" + flags);
/*      */ 
/*   39 */     SetWorldNodeReqMessage msg = new SetWorldNodeReqMessage(oid, wnode, flags);
/*      */ 
/*   41 */     Boolean rc = Engine.getAgent().sendRPCReturnBoolean(msg);
/*   42 */     if (Log.loggingDebug)
/*   43 */       Log.debug("WorldManagerClient.setWorldNode: oid=" + oid + " got response rc=" + rc);
/*   44 */     return rc.booleanValue();
/*      */   }
/*      */ 
/*      */   public static void updateWorldNode(OID oid, BasicWorldNode wnode)
/*      */   {
/*   53 */     updateWorldNode(oid, wnode, false, null, null);
/*      */   }
/*      */ 
/*      */   public static void updateWorldNode(OID oid, BasicWorldNode wnode, boolean override)
/*      */   {
/*   58 */     updateWorldNode(oid, wnode, override, null, null);
/*      */   }
/*      */ 
/*      */   public static void updateWorldNode(OID oid, BasicWorldNode wnode, boolean override, Message preMessage, Message postMessage)
/*      */   {
/*   63 */     UpdateWorldNodeReqMessage msg = new UpdateWorldNodeReqMessage(oid, wnode);
/*   64 */     msg.setOverride(override);
/*   65 */     msg.setPreMessage(preMessage);
/*   66 */     msg.setPostMessage(postMessage);
/*   67 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static BasicWorldNode getWorldNode(OID oid)
/*      */   {
/*   74 */     SubjectMessage msg = new SubjectMessage(MSG_TYPE_GETWNODE_REQ, oid);
/*   75 */     BasicWorldNode wnode = (BasicWorldNode)Engine.getAgent().sendRPCReturnObject(msg);
/*      */ 
/*   77 */     if (Log.loggingDebug) {
/*   78 */       Log.debug("WorldManagerClient.getWorldNode: oid=" + oid + " wnode=" + wnode);
/*      */     }
/*   80 */     return wnode;
/*      */   }
/*      */ 
/*      */   public static void correctWorldNode(OID oid, BasicWorldNode wnode)
/*      */   {
/*   88 */     if (Log.loggingDebug)
/*   89 */       Log.debug("WorldManagerClient.correctWorldNode: loc=" + wnode.getLoc());
/*   90 */     WorldNodeCorrectMessage msg = new WorldNodeCorrectMessage(oid, wnode);
/*   91 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void reparentWorldNode(OID oid, OID parentOid)
/*      */   {
/*   98 */     Log.debug("WorldManagerClient.reparentWorldNode: sending message");
/*   99 */     ReparentWNodeReqMessage msg = new ReparentWNodeReqMessage(oid, parentOid);
/*  100 */     Engine.getAgent().sendBroadcast(msg);
/*  101 */     Log.debug("WorldManagerClient.reparentWorldNode: sent message");
/*      */   }
/*      */ 
/*      */   public static Integer spawn(OID oid)
/*      */   {
/*  108 */     return spawn(oid, null, null);
/*      */   }
/*      */ 
/*      */   public static Integer spawn(OID oid, Message preMessage, Message postMessage)
/*      */   {
/*  128 */     if (Log.loggingDebug)
/*  129 */       Log.debug("WorldManagerClient.spawn: oid=" + oid);
/*  130 */     SpawnReqMessage msg = new SpawnReqMessage(oid);
/*  131 */     msg.setPreMessage(preMessage);
/*  132 */     msg.setPostMessage(postMessage);
/*  133 */     Integer result = (Integer)Engine.getAgent().sendRPCReturnObject(msg);
/*  134 */     if (Log.loggingDebug) {
/*  135 */       Log.debug("WorldManagerClient.spawn: response for oid=" + oid + " result=" + result);
/*      */     }
/*  137 */     return result;
/*      */   }
/*      */ 
/*      */   public static boolean despawn(OID oid)
/*      */   {
/*  144 */     return despawn(oid, null, null);
/*      */   }
/*      */ 
/*      */   public static boolean despawn(OID oid, Message preMessage, Message postMessage)
/*      */   {
/*  161 */     if (Log.loggingDebug) {
/*  162 */       Log.debug("WorldManagerClient.despawn: oid=" + oid);
/*      */     }
/*  164 */     Boolean rc = Boolean.valueOf(false);
/*      */     try {
/*  166 */       DespawnReqMessage msg = new DespawnReqMessage(oid);
/*  167 */       msg.setPreMessage(preMessage);
/*  168 */       msg.setPostMessage(postMessage);
/*  169 */       rc = Engine.getAgent().sendRPCReturnBoolean(msg);
/*      */     } catch (NoRecipientsException nre) {
/*  171 */       Log.exception("WorldManagerClient.despawn(): ", nre);
/*      */     }
/*  173 */     if (Log.loggingDebug) {
/*  174 */       Log.debug("WorldManagerClient.despawn: response oid=" + oid + " rc=" + rc);
/*      */     }
/*  176 */     return rc.booleanValue();
/*      */   }
/*      */ 
/*      */   public static ObjectInfo getObjectInfo(OID oid) {
/*  180 */     ObjInfoReqMessage msg = new ObjInfoReqMessage(oid);
/*  181 */     ObjInfoRespMessage respMsg = null;
/*      */     try {
/*  183 */       respMsg = (ObjInfoRespMessage)Engine.getAgent().sendRPC(msg);
/*      */     }
/*      */     catch (NoRecipientsException e) {
/*  186 */       Log.warn("WorldManagerClient.getObjectInfo, no recipiends for oid " + oid);
/*  187 */       return null;
/*      */     }
/*  189 */     if (Log.loggingDebug) {
/*  190 */       Log.debug("WorldManagerClient.getObjectInfo: oid=" + oid + " info=" + respMsg.getObjInfo());
/*      */     }
/*  192 */     return respMsg.getObjInfo();
/*      */   }
/*      */ 
/*      */   public static List<OID> getObjectsIn(OID instanceOid, Point loc, Integer radius, ObjectType objectType) {
/*  196 */     GetObjectsInMessage msg = new GetObjectsInMessage(instanceOid, loc, radius, objectType);
/*  197 */     List objectsIn = (List)Engine.getAgent().sendRPCReturnObject(msg);
/*  198 */     return objectsIn;
/*      */   }
/*      */ 
/*      */   public static DisplayContext getDisplayContext(OID oid)
/*      */   {
/*  205 */     DisplayContextReqMessage msg = new DisplayContextReqMessage(oid);
/*  206 */     DisplayContext dc = (DisplayContext)Engine.getAgent().sendRPCReturnObject(msg);
/*  207 */     if (Log.loggingDebug) {
/*  208 */       Log.debug("WorldManagerClient.getDisplayContext: oid=" + oid + " dc=" + dc);
/*      */     }
/*  210 */     return dc;
/*      */   }
/*      */ 
/*      */   public static void modifyDisplayContext(OID oid, byte action, String base, List<DisplayContext.Submesh> submeshes)
/*      */   {
/*  221 */     if (Log.loggingDebug) {
/*  222 */       Log.debug("WorldManagerClient.modifyDisplayContext: oid=" + oid + " action=" + action + " base=" + base + " submeshCount=" + submeshes.size());
/*      */     }
/*      */ 
/*  225 */     ModifyDisplayContextMessage msg = new ModifyDisplayContextMessage(oid, action, base, submeshes, null, null);
/*      */ 
/*  227 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void modifyDisplayContext(OID oid, byte action, List<DisplayContext.Submesh> submeshes)
/*      */   {
/*  232 */     if (Log.loggingDebug) {
/*  233 */       Log.debug("WorldManagerClient.modifyDisplayContext: oid=" + oid + " action=" + action + " submeshCount=" + submeshes.size());
/*      */     }
/*      */ 
/*  236 */     ModifyDisplayContextMessage msg = new ModifyDisplayContextMessage(oid, action, submeshes);
/*      */ 
/*  238 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void updateObject(OID notifyObj, OID updateObj)
/*      */   {
/*  254 */     UpdateMessage msg = new UpdateMessage(notifyObj, updateObj);
/*  255 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void refreshWNode(OID objId)
/*      */   {
/*  263 */     RefreshWNodeMessage msg = new RefreshWNodeMessage(objId);
/*  264 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void sendChatMsg(OID objId, String chatterName, int channelId, String text)
/*      */   {
/*  273 */     ComReqMessage msg = new ComReqMessage(objId, chatterName, channelId, text);
/*  274 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void sendObjChatMsg(OID objOid, int channelId, String text)
/*      */   {
/*  282 */     sendObjChatMsg(objOid, "", channelId, text);
/*      */   }
/*      */ 
/*      */   public static void sendObjChatMsg(OID objOid, String senderName, int channelId, String text)
/*      */   {
/*  291 */     TargetedComMessage comMsg = new TargetedComMessage(objOid, objOid, senderName, channelId, text);
/*      */ 
/*  294 */     Engine.getAgent().sendBroadcast(comMsg);
/*      */   }
/*      */ 
/*      */   public static void sendSysChatMsg(String text)
/*      */   {
/*  301 */     SysChatMessage sysMsg = new SysChatMessage(text);
/*  302 */     Engine.getAgent().sendBroadcast(sysMsg);
/*      */   }
/*      */ 
/*      */   public static void sendOrientMsg(OID objId, Quaternion q)
/*      */   {
/*  310 */     OrientReqMessage msg = new OrientReqMessage(objId, q);
/*  311 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void sendPerceiverRegionsMsg(OID instanceOid, Geometry region, String targetSessionId)
/*      */   {
/*  321 */     if (region == null) {
/*  322 */       throw new RuntimeException("region geometry is null");
/*      */     }
/*  324 */     PerceiverRegionsMessage msg = new PerceiverRegionsMessage(instanceOid, region);
/*      */ 
/*  326 */     if (targetSessionId != null) {
/*  327 */       msg.setTargetSessionId(targetSessionId);
/*      */     }
/*  329 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static Boolean hostInstance(OID instanceOid, String wmPluginName)
/*      */   {
/*  334 */     HostInstanceMessage message = new HostInstanceMessage(wmPluginName, instanceOid);
/*      */ 
/*  336 */     return Engine.getAgent().sendRPCReturnBoolean(message);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static Serializable getObjectProperty(OID oid, String key)
/*      */   {
/*  349 */     return EnginePlugin.getObjectProperty(oid, Namespace.WORLD_MANAGER, key);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static Serializable setObjectProperty(OID oid, String key, Serializable val)
/*      */   {
/*  365 */     return EnginePlugin.setObjectProperty(oid, Namespace.WORLD_MANAGER, key, val);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static void setObjectPropertyNoResponse(OID oid, String key, Serializable val)
/*      */   {
/*  379 */     EnginePlugin.setObjectPropertyNoResponse(oid, Namespace.WORLD_MANAGER, key, val);
/*      */   }
/*      */ 
/*      */   public static class PlayerPathWMReqMessage extends Message
/*      */   {
/*      */     private float avatarWidth;
/*      */     private List<AOVector> boundary;
/*      */     private AOVector dest;
/*      */     private Quaternion destOrientation;
/*      */     private OID instanceOid;
/*      */     private List<List<AOVector>> obstacles;
/*      */     private OID playerOid;
/*      */     private String roomId;
/*      */     private float speed;
/*      */     private AOVector start;
/*      */     private Quaternion startOrientation;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public PlayerPathWMReqMessage()
/*      */     {
/* 3009 */       super();
/*      */     }
/*      */ 
/*      */     public PlayerPathWMReqMessage(OID playerOid, OID instanceOid, String roomId, AOVector start, float speed, Quaternion startOrientation, AOVector dest, Quaternion destOrientation, List<AOVector> boundary, List<List<AOVector>> obstacles, float avatarWidth)
/*      */     {
/* 3016 */       super();
/* 3017 */       this.playerOid = playerOid;
/* 3018 */       this.instanceOid = instanceOid;
/* 3019 */       this.start = start;
/* 3020 */       this.speed = speed;
/* 3021 */       this.startOrientation = startOrientation;
/* 3022 */       this.dest = dest;
/* 3023 */       this.destOrientation = destOrientation;
/* 3024 */       this.boundary = boundary;
/* 3025 */       this.obstacles = obstacles;
/* 3026 */       this.avatarWidth = avatarWidth;
/*      */     }
/*      */ 
/*      */     public float getAvatarWidth() {
/* 3030 */       return this.avatarWidth;
/*      */     }
/*      */ 
/*      */     public void setAvatarWidth(float avatarWidth) {
/* 3034 */       this.avatarWidth = avatarWidth;
/*      */     }
/*      */ 
/*      */     public List<AOVector> getBoundary() {
/* 3038 */       return this.boundary;
/*      */     }
/*      */ 
/*      */     public void setBoundary(List<AOVector> boundary) {
/* 3042 */       this.boundary = boundary;
/*      */     }
/*      */ 
/*      */     public AOVector getDest() {
/* 3046 */       return this.dest;
/*      */     }
/*      */ 
/*      */     public void setDest(AOVector dest) {
/* 3050 */       this.dest = dest;
/*      */     }
/*      */ 
/*      */     public Quaternion getDestOrientation() {
/* 3054 */       return this.destOrientation;
/*      */     }
/*      */ 
/*      */     public void setDestOrientation(Quaternion destOrientation) {
/* 3058 */       this.destOrientation = destOrientation;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/* 3062 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID instanceOid) {
/* 3066 */       this.instanceOid = instanceOid;
/*      */     }
/*      */ 
/*      */     public List<List<AOVector>> getObstacles() {
/* 3070 */       return this.obstacles;
/*      */     }
/*      */ 
/*      */     public void setObstacles(List<List<AOVector>> obstacles) {
/* 3074 */       this.obstacles = obstacles;
/*      */     }
/*      */ 
/*      */     public OID getPlayerOid() {
/* 3078 */       return this.playerOid;
/*      */     }
/*      */ 
/*      */     public void setPlayerOid(OID playerOid) {
/* 3082 */       this.playerOid = playerOid;
/*      */     }
/*      */ 
/*      */     public String getRoomId() {
/* 3086 */       return this.roomId;
/*      */     }
/*      */ 
/*      */     public void setRoomId(String roomId) {
/* 3090 */       this.roomId = roomId;
/*      */     }
/*      */ 
/*      */     public float getSpeed() {
/* 3094 */       return this.speed;
/*      */     }
/*      */ 
/*      */     public void setSpeed(float speed) {
/* 3098 */       this.speed = speed;
/*      */     }
/*      */ 
/*      */     public AOVector getStart() {
/* 3102 */       return this.start;
/*      */     }
/*      */ 
/*      */     public void setStart(AOVector start) {
/* 3106 */       this.start = start;
/*      */     }
/*      */ 
/*      */     public Quaternion getStartOrientation() {
/* 3110 */       return this.startOrientation;
/*      */     }
/*      */ 
/*      */     public void setStartOrientation(Quaternion startOrientation) {
/* 3114 */       this.startOrientation = startOrientation;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class HostInstanceMessage extends Message
/*      */   {
/*      */     private String pluginName;
/*      */     private OID instanceOid;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public HostInstanceMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public HostInstanceMessage(String pluginName, OID instanceOid2)
/*      */     {
/* 2979 */       super();
/* 2980 */       setPluginName(pluginName);
/* 2981 */       setInstanceOid(instanceOid2);
/*      */     }
/*      */ 
/*      */     public String getPluginName() {
/* 2985 */       return this.pluginName;
/*      */     }
/*      */ 
/*      */     public void setPluginName(String name) {
/* 2989 */       this.pluginName = name;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/* 2993 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID instanceOid) {
/* 2997 */       this.instanceOid = instanceOid;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class LoadSubObjectMessage extends ObjectManagerClient.LoadSubObjectMessage
/*      */   {
/*      */     private Point location;
/*      */     private OID instanceOid;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public LoadSubObjectMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public LoadSubObjectMessage(OID oid, Namespace namespace, Point location, OID instanceOid)
/*      */     {
/* 2952 */       super(namespace);
/* 2953 */       this.location = location;
/* 2954 */       this.instanceOid = instanceOid;
/*      */     }
/*      */ 
/*      */     public Point getLocation() {
/* 2958 */       return this.location;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/* 2962 */       return this.instanceOid;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class MobPathMessageBaseClass extends SubjectMessage
/*      */   {
/*      */     long startTime;
/* 2937 */     String interpKind = "linear";
/*      */     float speed;
/* 2939 */     String terrainString = "";
/* 2940 */     List<Point> pathPoints = null;
/*      */ 
/*      */     protected abstract MessageType getMobPathMsgType();
/*      */ 
/*      */     protected abstract String getMobPathMsgTypeTitle();
/*      */ 
/*      */     public MobPathMessageBaseClass()
/*      */     {
/*      */     }
/*      */ 
/*      */     public MobPathMessageBaseClass(OID oid, Long startTime, String interpKind, float speed, String terrainString, List<Point> pathPoints)
/*      */     {
/* 2839 */       setMsgType(getMobPathMsgType());
/* 2840 */       setSubject(oid);
/* 2841 */       setStartTime(startTime.longValue());
/* 2842 */       setInterpKind(interpKind);
/* 2843 */       setSpeed(speed);
/* 2844 */       setTerrainString(terrainString);
/* 2845 */       setPathPoints(pathPoints);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 2849 */       return "[" + getMobPathMsgTypeTitle() + " oid=" + getSubject() + ", interpKind=" + this.interpKind + ", speed=" + this.speed + ", terrainString=" + this.terrainString + ", pathPoints=" + getPathPoints() + ", super=" + super.toString() + "]";
/*      */     }
/*      */ 
/*      */     public void setStartTime(long startTime)
/*      */     {
/* 2854 */       this.startTime = startTime;
/*      */     }
/*      */ 
/*      */     public long getStartTime() {
/* 2858 */       return this.startTime;
/*      */     }
/*      */ 
/*      */     public void setInterpKind(String interpKind) {
/* 2862 */       this.interpKind = interpKind;
/*      */     }
/*      */ 
/*      */     public String getInterpKind() {
/* 2866 */       return this.interpKind;
/*      */     }
/*      */ 
/*      */     public void setSpeed(float speed) {
/* 2870 */       this.speed = speed;
/*      */     }
/*      */ 
/*      */     public float getSpeed() {
/* 2874 */       return this.speed;
/*      */     }
/*      */ 
/*      */     public void setTerrainString(String terrainString) {
/* 2878 */       this.terrainString = terrainString;
/*      */     }
/*      */ 
/*      */     public String getTerrainString() {
/* 2882 */       return this.terrainString;
/*      */     }
/*      */ 
/*      */     public void setPathPoints(List<Point> pathPoints) {
/* 2886 */       this.pathPoints = pathPoints;
/*      */     }
/*      */ 
/*      */     public List<Point> getPathPoints() {
/* 2890 */       return this.pathPoints;
/*      */     }
/*      */ 
/*      */     public Point getPositionAtTime(Long when)
/*      */     {
/* 2904 */       if ((this.pathPoints == null) || (this.pathPoints.size() == 0))
/* 2905 */         return null;
/* 2906 */       if (when.longValue() <= this.startTime) {
/* 2907 */         return (Point)this.pathPoints.get(0);
/*      */       }
/* 2909 */       PathInterpolator interp = this.interpKind == "linear" ? new PathLinear(null, this.startTime, this.speed, this.terrainString, this.pathPoints) : new PathSpline(null, this.startTime, this.speed, this.terrainString, this.pathPoints);
/*      */ 
/* 2912 */       PathLocAndDir locAndDir = interp.interpolate(when.longValue());
/* 2913 */       if (locAndDir == null) {
/* 2914 */         return (Point)this.pathPoints.get(this.pathPoints.size() - 1);
/*      */       }
/* 2916 */       return locAndDir.getLoc();
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer()
/*      */     {
/* 2921 */       AOByteBuffer buf = new AOByteBuffer(400);
/* 2922 */       buf.putOID(getSubject());
/* 2923 */       buf.putInt(73);
/* 2924 */       buf.putLong(this.startTime);
/* 2925 */       buf.putString(this.interpKind);
/* 2926 */       buf.putFloat(this.speed);
/* 2927 */       buf.putString(this.terrainString);
/* 2928 */       buf.putInt(this.pathPoints.size());
/* 2929 */       for (Point point : this.pathPoints) {
/* 2930 */         buf.putPoint(point);
/*      */       }
/* 2932 */       buf.flip();
/* 2933 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MobPathCorrectionMessage extends WorldManagerClient.MobPathMessageBaseClass
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public MobPathCorrectionMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public MobPathCorrectionMessage(OID oid, long startTime, String interpKind, float speed, String terrainString, List<Point> pathPoints)
/*      */     {
/* 2811 */       super(Long.valueOf(startTime), interpKind, speed, terrainString, pathPoints);
/*      */     }
/*      */ 
/*      */     protected MessageType getMobPathMsgType() {
/* 2815 */       return WorldManagerClient.MSG_TYPE_MOB_PATH_CORRECTION;
/*      */     }
/*      */ 
/*      */     protected String getMobPathMsgTypeTitle() {
/* 2819 */       return "MobPathCorrectionMessage";
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MobPathMessage extends WorldManagerClient.MobPathMessageBaseClass
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public MobPathMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public MobPathMessage(OID oid, long startTime, String interpKind, float speed, String terrainString, List<Point> pathPoints)
/*      */     {
/* 2772 */       super(Long.valueOf(startTime), interpKind, speed, terrainString, pathPoints);
/*      */     }
/*      */ 
/*      */     protected MessageType getMobPathMsgType() {
/* 2776 */       return WorldManagerClient.MSG_TYPE_MOB_PATH;
/*      */     }
/*      */ 
/*      */     protected String getMobPathMsgTypeTitle() {
/* 2780 */       return "MobPathMessage";
/*      */     }
/*      */ 
/*      */     public boolean pathExpired()
/*      */     {
/* 2786 */       if ((this.pathPoints == null) || (this.pathPoints.size() < 2))
/* 2787 */         return true;
/* 2788 */       float pathTime = 0.0F;
/* 2789 */       Point curr = (Point)this.pathPoints.get(0);
/* 2790 */       for (int i = 1; i < this.pathPoints.size(); i++) {
/* 2791 */         Point next = (Point)this.pathPoints.get(i);
/* 2792 */         float dist = Point.distanceTo(curr, next);
/* 2793 */         float diffTime = dist / this.speed;
/* 2794 */         pathTime += diffTime;
/* 2795 */         curr = next;
/*      */       }
/* 2797 */       return (float)this.startTime + pathTime < (float)System.currentTimeMillis();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MobPathReqMessage extends WorldManagerClient.MobPathMessageBaseClass
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public MobPathReqMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public MobPathReqMessage(OID oid, long startTime, String interpKind, float speed, String terrainString, List<Point> pathPoints)
/*      */     {
/* 2744 */       super(Long.valueOf(startTime), interpKind, speed, terrainString, pathPoints);
/*      */     }
/*      */ 
/*      */     public MobPathReqMessage(OID oid)
/*      */     {
/* 2750 */       super(Long.valueOf(0L), "linear", 0.0F, "", new LinkedList());
/*      */     }
/*      */ 
/*      */     protected MessageType getMobPathMsgType() {
/* 2754 */       return WorldManagerClient.MSG_TYPE_MOB_PATH_REQ;
/*      */     }
/*      */ 
/*      */     protected String getMobPathMsgTypeTitle() {
/* 2758 */       return "MobPathMessageReq";
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class FreeObjectMessage extends TargetMessage
/*      */     implements ClientMessage, EventParser
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public FreeObjectMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public FreeObjectMessage(OID playerOid, OID objOid)
/*      */     {
/* 2696 */       super(playerOid, objOid);
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer()
/*      */     {
/* 2701 */       AOByteBuffer buf = new AOByteBuffer(24);
/* 2702 */       buf.putOID(getTarget());
/* 2703 */       buf.putInt(10);
/* 2704 */       buf.putOID(getSubject());
/* 2705 */       buf.flip();
/* 2706 */       return buf;
/*      */     }
/*      */ 
/*      */     public void parseBytes(AOByteBuffer buf)
/*      */     {
/* 2711 */       setTarget(buf.getOID());
/* 2712 */       buf.getInt();
/* 2713 */       setSubject(buf.getOID());
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class NewDirLightMessage extends TargetMessage
/*      */   {
/*      */     private LightData lightData;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public NewDirLightMessage()
/*      */     {
/* 2667 */       super();
/*      */     }
/*      */ 
/*      */     public NewDirLightMessage(OID objOid, OID lightOid, LightData lightData) {
/* 2671 */       super(objOid, lightOid);
/* 2672 */       setLightData(lightData);
/*      */     }
/*      */ 
/*      */     public void setLightData(LightData lightData) {
/* 2676 */       this.lightData = lightData;
/*      */     }
/*      */     public LightData getLightData() {
/* 2679 */       return this.lightData;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ModifyDisplayContextMessage extends SubjectMessage
/*      */   {
/*      */     String handle;
/* 2646 */     DisplayContext childDC = null;
/*      */     byte action;
/* 2650 */     String base = null;
/*      */     List<DisplayContext.Submesh> submeshes;
/* 2654 */     transient Lock lock = LockFactory.makeLock("ModifyDCMsgLock");
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ModifyDisplayContextMessage()
/*      */     {
/* 2553 */       super();
/*      */     }
/*      */ 
/*      */     public ModifyDisplayContextMessage(OID oid, byte action, String base, Collection<DisplayContext.Submesh> submeshes, String childDCHandle, DisplayContext childDC)
/*      */     {
/* 2560 */       super(oid);
/* 2561 */       setAction(action);
/* 2562 */       setBase(base);
/* 2563 */       setSubmeshes(submeshes);
/* 2564 */       setChildDCHandle(childDCHandle);
/* 2565 */       setChildDC(childDC);
/*      */     }
/*      */ 
/*      */     public ModifyDisplayContextMessage(OID oid, byte action, Collection<DisplayContext.Submesh> submeshes)
/*      */     {
/* 2570 */       super(oid);
/* 2571 */       setAction(action);
/* 2572 */       setSubmeshes(submeshes);
/*      */     }
/*      */ 
/*      */     public ModifyDisplayContextMessage(OID oid, byte action, DisplayContext.Submesh submesh)
/*      */     {
/* 2577 */       super(oid);
/* 2578 */       setAction(action);
/*      */ 
/* 2580 */       List l = new LinkedList();
/* 2581 */       l.add(submesh);
/*      */ 
/* 2585 */       this.submeshes = l;
/*      */     }
/*      */ 
/*      */     public void setAction(byte action) {
/* 2589 */       this.action = action;
/*      */     }
/*      */ 
/*      */     public byte getAction() {
/* 2593 */       return this.action;
/*      */     }
/*      */ 
/*      */     public void setBase(String base) {
/* 2597 */       this.base = base;
/*      */     }
/*      */ 
/*      */     public String getBase() {
/* 2601 */       return this.base;
/*      */     }
/*      */ 
/*      */     public void setSubmeshes(Collection<DisplayContext.Submesh> submeshes) {
/* 2605 */       this.lock.lock();
/*      */       try {
/* 2607 */         if (submeshes != null)
/* 2608 */           this.submeshes = new LinkedList(submeshes);
/*      */       }
/*      */       finally
/*      */       {
/* 2612 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public List<DisplayContext.Submesh> getSubmeshes() {
/* 2617 */       this.lock.lock();
/*      */       try {
/* 2619 */         if (this.submeshes == null) {
/* 2620 */           localLinkedList = null;
/*      */           return localLinkedList;
/*      */         }
/* 2622 */         LinkedList localLinkedList = new LinkedList(this.submeshes);
/*      */         return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public void setChildDCHandle(String handle)
/*      */     {
/* 2629 */       this.handle = handle;
/*      */     }
/*      */ 
/*      */     public String getChildDCHandle() {
/* 2633 */       return this.handle;
/*      */     }
/*      */ 
/*      */     public void setChildDC(DisplayContext dc)
/*      */     {
/* 2639 */       this.childDC = dc;
/*      */     }
/*      */ 
/*      */     public DisplayContext getChildDC() {
/* 2643 */       return this.childDC;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SoundMessage extends SubjectMessage
/*      */     implements ClientMessage, HasTarget
/*      */   {
/*      */     public static final byte soundTypePoint = 1;
/*      */     public static final byte soundTypeAmbient = 2;
/*      */     byte soundType;
/* 2538 */     List<SoundData> soundData = null;
/* 2539 */     List<String> soundOff = null;
/*      */     private boolean clearFlag;
/* 2542 */     private OID target = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SoundMessage()
/*      */     {
/* 2377 */       super();
/*      */     }
/*      */ 
/*      */     public SoundMessage(OID oid) {
/* 2381 */       super(oid);
/* 2382 */       setType(1);
/*      */     }
/*      */ 
/*      */     public OID getTarget()
/*      */     {
/* 2387 */       return this.target;
/*      */     }
/*      */ 
/*      */     public void setTarget(OID target)
/*      */     {
/* 2392 */       this.target = target;
/*      */     }
/*      */ 
/*      */     public void setSoundData(List<SoundData> soundData)
/*      */     {
/* 2402 */       this.soundData = new LinkedList(soundData);
/*      */     }
/*      */ 
/*      */     public List<SoundData> getSoundData()
/*      */     {
/* 2407 */       return this.soundData;
/*      */     }
/*      */ 
/*      */     public void addSound(SoundData data)
/*      */     {
/* 2412 */       if (this.soundData == null)
/* 2413 */         this.soundData = new LinkedList();
/* 2414 */       this.soundData.add(data);
/*      */     }
/*      */ 
/*      */     public void setType(byte type)
/*      */     {
/* 2422 */       this.soundType = type;
/*      */     }
/*      */ 
/*      */     public byte getType()
/*      */     {
/* 2428 */       return this.soundType;
/*      */     }
/*      */ 
/*      */     public void setClearFlag(boolean val)
/*      */     {
/* 2435 */       this.clearFlag = val;
/*      */     }
/*      */ 
/*      */     public boolean getClearFlag()
/*      */     {
/* 2441 */       return this.clearFlag;
/*      */     }
/*      */ 
/*      */     public void addSound(String fileName, boolean looping)
/*      */     {
/* 2450 */       addSound(fileName, looping, 1.0F);
/*      */     }
/*      */ 
/*      */     public void addSound(String fileName, boolean looping, float gain)
/*      */     {
/* 2461 */       if (this.soundData == null)
/* 2462 */         this.soundData = new LinkedList();
/* 2463 */       HashMap properties = new HashMap();
/* 2464 */       if (looping)
/* 2465 */         properties.put("Loop", "true");
/*      */       else
/* 2467 */         properties.put("Loop", "false");
/* 2468 */       properties.put("Gain", "" + gain);
/* 2469 */       SoundData data = new SoundData(fileName, "Positional", properties);
/* 2470 */       this.soundData.add(data);
/*      */     }
/*      */ 
/*      */     public void removeSound(String fileName)
/*      */     {
/* 2476 */       if (this.soundOff == null)
/* 2477 */         this.soundOff = new LinkedList();
/* 2478 */       this.soundOff.add(fileName);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 2482 */       String typeStr = "POINT";
/* 2483 */       if (this.soundType == 2)
/* 2484 */         typeStr = "AMBIENT";
/* 2485 */       return "[SoundMessage: OID=" + getSubject() + ", TYPE=" + typeStr + ", ON=" + this.soundData + ", OFF=" + this.soundOff + ", CLEAR=" + this.clearFlag;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer()
/*      */     {
/* 2493 */       AOByteBuffer buf = new AOByteBuffer(400);
/* 2494 */       if (this.soundType == 2)
/* 2495 */         buf.putOID(null);
/*      */       else
/* 2497 */         buf.putOID(getSubject());
/* 2498 */       buf.putInt(78);
/*      */ 
/* 2500 */       if (Log.loggingDebug)
/* 2501 */         Log.debug("sending SoundControl: " + this);
/*      */       try
/*      */       {
/* 2504 */         boolean cflag = getClearFlag();
/* 2505 */         int numEntries = 0;
/* 2506 */         if (this.soundData != null)
/* 2507 */           numEntries = this.soundData.size();
/* 2508 */         if (cflag)
/* 2509 */           numEntries++;
/* 2510 */         else if (this.soundOff != null)
/* 2511 */           numEntries += this.soundOff.size();
/* 2512 */         buf.putInt(numEntries);
/*      */ 
/* 2514 */         if (cflag) {
/* 2515 */           buf.putString("clear");
/*      */         }
/* 2517 */         else if (this.soundOff != null) {
/* 2518 */           for (String fileName : this.soundOff) {
/* 2519 */             buf.putString("off");
/* 2520 */             buf.putString(fileName);
/*      */           }
/*      */         }
/*      */ 
/* 2524 */         if (this.soundData != null)
/* 2525 */           for (SoundData data : this.soundData) {
/* 2526 */             buf.putString("on");
/* 2527 */             buf.putString(data.getFileName());
/* 2528 */             Map props = new HashMap(data.getProperties());
/* 2529 */             buf.putPropertyMap(props);
/*      */           }
/*      */       }
/*      */       finally {
/*      */       }
/* 2534 */       buf.flip();
/* 2535 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class NewRegionMessage extends Message
/*      */   {
/*      */     private OID instanceOid;
/*      */     private Region region;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public NewRegionMessage()
/*      */     {
/* 2324 */       super();
/*      */     }
/*      */ 
/*      */     public NewRegionMessage(OID instanceOid, Region region) {
/* 2328 */       super();
/* 2329 */       setInstanceOid(instanceOid);
/* 2330 */       setRegion(region);
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/* 2334 */       this.instanceOid = oid;
/*      */     }
/*      */     public OID getInstanceOid() {
/* 2337 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setRegion(Region r) {
/* 2341 */       this.region = r;
/*      */     }
/*      */ 
/*      */     public Region getRegion() {
/* 2345 */       return this.region;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class PerceiverRegionsMessage extends Message
/*      */     implements ITargetSessionId
/*      */   {
/*      */     private OID instanceOid;
/* 2315 */     private Geometry region = null;
/*      */     private String targetSessionId;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public PerceiverRegionsMessage()
/*      */     {
/* 2280 */       super();
/*      */     }
/*      */ 
/*      */     public PerceiverRegionsMessage(OID instanceOid2, Geometry region)
/*      */     {
/* 2285 */       setMsgType(WorldManagerClient.MSG_TYPE_PERCEIVER_REGIONS);
/* 2286 */       setInstanceOid(instanceOid2);
/* 2287 */       setRegion(region);
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/* 2291 */       this.instanceOid = oid;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/* 2295 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setRegion(Geometry g) {
/* 2299 */       this.region = g;
/*      */     }
/*      */ 
/*      */     public Geometry getRegion() {
/* 2303 */       return this.region;
/*      */     }
/*      */ 
/*      */     public String getTargetSessionId() {
/* 2307 */       return this.targetSessionId;
/*      */     }
/*      */ 
/*      */     public void setTargetSessionId(String targetSessionId) {
/* 2311 */       this.targetSessionId = targetSessionId;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class RefreshWNodeMessage extends SubjectMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public RefreshWNodeMessage()
/*      */     {
/* 2262 */       super();
/*      */     }
/*      */ 
/*      */     public RefreshWNodeMessage(OID objOid) {
/* 2266 */       super(objOid);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class TargetedExtensionMessage extends WorldManagerClient.TargetedPropertyMessage
/*      */   {
/* 2250 */     private boolean clientTargeted = false;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public TargetedExtensionMessage()
/*      */     {
/* 2156 */       super();
/*      */     }
/*      */ 
/*      */     public TargetedExtensionMessage(OID target)
/*      */     {
/* 2163 */       super(target);
/*      */     }
/*      */ 
/*      */     public TargetedExtensionMessage(OID target, OID subject)
/*      */     {
/* 2171 */       super(target, subject);
/*      */     }
/*      */ 
/*      */     public TargetedExtensionMessage(String subType, OID target)
/*      */     {
/* 2179 */       super(target);
/* 2180 */       setExtensionType(subType);
/*      */     }
/*      */ 
/*      */     public TargetedExtensionMessage(MessageType msgType, String subType, OID target, OID subject)
/*      */     {
/* 2191 */       super(target, subject);
/* 2192 */       if (subType != null)
/* 2193 */         setExtensionType(subType);
/*      */     }
/*      */ 
/*      */     public TargetedExtensionMessage(MessageType msgType, OID target, OID subject, Boolean clientTargeted, Map<String, Serializable> propertyMap)
/*      */     {
/* 2205 */       super(target, subject);
/* 2206 */       this.clientTargeted = clientTargeted.booleanValue();
/* 2207 */       this.propertyMap = propertyMap;
/*      */     }
/*      */ 
/*      */     public void setExtensionType(String type)
/*      */     {
/* 2214 */       setProperty("ext_msg_subtype", type);
/*      */     }
/*      */ 
/*      */     public String getExtensionType()
/*      */     {
/* 2220 */       return (String)getProperty("ext_msg_subtype");
/*      */     }
/*      */ 
/*      */     public Set<String> getKeys() {
/* 2224 */       return this.propertyMap.keySet();
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer(String version)
/*      */     {
/* 2232 */       this.lock.lock();
/*      */       try {
/* 2234 */         AOByteBuffer buf = new AOByteBuffer(2048);
/* 2235 */         buf.putOID(getSubject());
/* 2236 */         buf.putInt(83);
/* 2237 */         OID oid = getTarget();
/* 2238 */         byte flags = (byte)((oid != null ? 1 : 0) | (this.clientTargeted ? 2 : 0));
/* 2239 */         buf.putByte(flags);
/* 2240 */         if (oid != null)
/* 2241 */           buf.putOID(oid);
/* 2242 */         buf.putPropertyMap(this.propertyMap);
/* 2243 */         buf.flip();
/* 2244 */         AOByteBuffer localAOByteBuffer1 = buf;
/*      */         return localAOByteBuffer1; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ExtensionMessage extends PropertyMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ExtensionMessage()
/*      */     {
/* 2081 */       super();
/*      */     }
/*      */ 
/*      */     public ExtensionMessage(OID objOid)
/*      */     {
/* 2088 */       super(objOid);
/*      */     }
/*      */ 
/*      */     public ExtensionMessage(MessageType msgType, String subType, OID objOid)
/*      */     {
/* 2097 */       super(objOid);
/* 2098 */       setExtensionType(subType);
/*      */     }
/*      */ 
/*      */     public ExtensionMessage(MessageType msgType, OID objOid, Map<String, Serializable> propertyMap)
/*      */     {
/* 2107 */       super(objOid);
/* 2108 */       this.propertyMap = propertyMap;
/*      */     }
/*      */ 
/*      */     public void setExtensionType(String type)
/*      */     {
/* 2115 */       setProperty("ext_msg_subtype", type);
/*      */     }
/*      */ 
/*      */     public String getExtensionType()
/*      */     {
/* 2121 */       return (String)getProperty("ext_msg_subtype");
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer(String version)
/*      */     {
/* 2129 */       this.lock.lock();
/*      */       try {
/* 2131 */         AOByteBuffer buf = new AOByteBuffer(2048);
/* 2132 */         buf.putOID(getSubject());
/* 2133 */         buf.putInt(83);
/* 2134 */         byte flags = 0;
/* 2135 */         buf.putByte(flags);
/* 2136 */         buf.putPropertyMap(this.propertyMap);
/* 2137 */         buf.flip();
/* 2138 */         AOByteBuffer localAOByteBuffer1 = buf;
/*      */         return localAOByteBuffer1; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class TargetedPropertyMessage extends TargetMessage
/*      */     implements Serializable, IPropertyMessage
/*      */   {
/* 2064 */     protected transient Lock lock = null;
/*      */ 
/* 2066 */     Map<String, Serializable> propertyMap = new HashMap();
/* 2067 */     protected Collection<String> removedProperties = new HashSet();
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public TargetedPropertyMessage()
/*      */     {
/* 1905 */       super();
/* 1906 */       setupTransient();
/*      */     }
/*      */ 
/*      */     public TargetedPropertyMessage(MessageType msgType) {
/* 1910 */       super();
/* 1911 */       setupTransient();
/*      */     }
/*      */ 
/*      */     public TargetedPropertyMessage(MessageType msgType, OID target) {
/* 1915 */       super(target);
/* 1916 */       setupTransient();
/*      */     }
/*      */ 
/*      */     public TargetedPropertyMessage(OID target, OID subject) {
/* 1920 */       super(target, subject);
/* 1921 */       setupTransient();
/*      */     }
/*      */ 
/*      */     public TargetedPropertyMessage(MessageType msgType, OID target, OID subject) {
/* 1925 */       super(target, subject);
/* 1926 */       setupTransient();
/*      */     }
/*      */ 
/*      */     /** @deprecated */
/*      */     public void put(String key, Serializable val)
/*      */     {
/* 1934 */       setProperty(key, val);
/*      */     }
/*      */ 
/*      */     public void setProperty(String key, Serializable val)
/*      */     {
/* 1943 */       this.lock.lock();
/*      */       try {
/* 1945 */         this.propertyMap.put(key, val);
/* 1946 */         this.removedProperties.remove(key);
/*      */       } finally {
/* 1948 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void setProperty(String key, Serializable val, boolean clone)
/*      */     {
/* 1959 */       if (!clone) {
/* 1960 */         setProperty(key, val);
/* 1961 */         return;
/*      */       }
/* 1963 */       this.lock.lock();
/*      */       try {
/*      */         try {
/* 1966 */           ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1967 */           ObjectOutputStream oos = new ObjectOutputStream(baos);
/* 1968 */           oos.writeObject(val);
/* 1969 */           ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
/* 1970 */           ObjectInputStream ois = new ObjectInputStream(bais);
/* 1971 */           Serializable valDeepCopy = (IPropertyMessage)ois.readObject();
/* 1972 */           this.propertyMap.put(key, valDeepCopy);
/* 1973 */           this.removedProperties.remove(key);
/*      */         } catch (ClassNotFoundException e) {
/* 1975 */           this.propertyMap.put(key, null);
/* 1976 */           this.removedProperties.remove(key);
/*      */         } catch (IOException e) {
/* 1978 */           this.propertyMap.put(key, null);
/* 1979 */           this.removedProperties.remove(key);
/*      */         }
/*      */       } finally {
/* 1982 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     /** @deprecated */
/*      */     public Serializable get(String key)
/*      */     {
/* 1991 */       return getProperty(key);
/*      */     }
/*      */ 
/*      */     public Serializable getProperty(String key)
/*      */     {
/* 2000 */       this.lock.lock();
/*      */       try {
/* 2002 */         Serializable localSerializable = (IPropertyMessage)this.propertyMap.get(key);
/*      */         return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public void removeProperty(String key)
/*      */     {
/* 2014 */       this.lock.lock();
/*      */       try {
/* 2016 */         this.propertyMap.remove(key);
/* 2017 */         this.removedProperties.add(key);
/*      */       } finally {
/* 2019 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<String> keySet() {
/* 2024 */       this.lock.lock();
/*      */       try {
/* 2026 */         Set localSet = this.propertyMap.keySet();
/*      */         return localSet; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public Map<String, Serializable> getPropertyMapRef()
/*      */     {
/* 2034 */       return this.propertyMap;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer(String version) {
/* 2038 */       return toBufferInternal(version, null);
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer(String version, Set<String> filteredProps) {
/* 2042 */       return toBufferInternal(version, filteredProps);
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBufferInternal(String version, Set<String> filteredProps) {
/* 2046 */       this.lock.lock();
/*      */       try {
/* 2048 */         AOByteBuffer buf = new AOByteBuffer(2048);
/* 2049 */         buf.putOID(getSubject());
/* 2050 */         buf.putInt(62);
/* 2051 */         buf.putFilteredPropertyMap(this.propertyMap, filteredProps);
/* 2052 */         buf.putFilteredPropertyCollection(this.removedProperties, filteredProps);
/* 2053 */         buf.flip();
/* 2054 */         AOByteBuffer localAOByteBuffer1 = buf;
/*      */         return localAOByteBuffer1; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     void setupTransient()
/*      */     {
/* 2061 */       this.lock = LockFactory.makeLock("TargetedPropertyMessageLock");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class AnimationMessage extends SubjectMessage
/*      */   {
/*      */     private LinkedList<AnimationCommand> animationList;
/* 1891 */     protected transient Lock lock = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public AnimationMessage()
/*      */     {
/* 1849 */       super();
/* 1850 */       setupTransient();
/*      */     }
/*      */ 
/*      */     public AnimationMessage(OID objOid, OID notifyOid, AnimationCommand anim) {
/* 1854 */       super(objOid);
/* 1855 */       setupTransient();
/* 1856 */       List l = new LinkedList();
/* 1857 */       l.add(anim);
/* 1858 */       setAnimationList(l);
/*      */     }
/*      */ 
/*      */     public AnimationMessage(OID objOid, List<AnimationCommand> animList) {
/* 1862 */       super(objOid);
/* 1863 */       setupTransient();
/* 1864 */       setAnimationList(animList);
/*      */     }
/*      */ 
/*      */     public List<AnimationCommand> getAnimationList() {
/* 1868 */       this.lock.lock();
/*      */       try {
/* 1870 */         LinkedList localLinkedList = new LinkedList(this.animationList);
/*      */         return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public void setAnimationList(List<AnimationCommand> animList)
/*      */     {
/* 1877 */       this.lock.lock();
/*      */       try {
/* 1879 */         this.animationList = new LinkedList(animList);
/*      */       } finally {
/* 1881 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     void setupTransient() {
/* 1886 */       this.lock = LockFactory.makeLock("AnimationMessageLock");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class OrientMessage extends SubjectMessage
/*      */     implements ClientMessage
/*      */   {
/*      */     private Quaternion q;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public OrientMessage()
/*      */     {
/* 1812 */       super();
/*      */     }
/*      */ 
/*      */     public OrientMessage(OID objOid, Quaternion q) {
/* 1816 */       super(objOid);
/* 1817 */       setQuaternion(q);
/*      */     }
/*      */ 
/*      */     public Quaternion getQuaternion() {
/* 1821 */       return this.q;
/*      */     }
/*      */ 
/*      */     public void setQuaternion(Quaternion q) {
/* 1825 */       this.q = q;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/* 1829 */       AOByteBuffer buf = new AOByteBuffer(32);
/* 1830 */       buf.putOID(getSubject());
/* 1831 */       buf.putInt(9);
/* 1832 */       buf.putQuaternion(getQuaternion());
/* 1833 */       buf.flip();
/* 1834 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class OrientReqMessage extends SubjectMessage
/*      */   {
/*      */     Quaternion q;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public OrientReqMessage()
/*      */     {
/* 1784 */       super();
/*      */     }
/*      */ 
/*      */     public OrientReqMessage(OID objOid, Quaternion q) {
/* 1788 */       super(objOid);
/* 1789 */       setQuaternion(q);
/*      */     }
/*      */ 
/*      */     public Quaternion getQuaternion() {
/* 1793 */       return this.q;
/*      */     }
/*      */ 
/*      */     public void setQuaternion(Quaternion q) {
/* 1797 */       this.q = q;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SysChatMessage extends Message
/*      */     implements ClientMessage
/*      */   {
/*      */     private String msgString;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SysChatMessage()
/*      */     {
/* 1747 */       super();
/*      */     }
/*      */ 
/*      */     public SysChatMessage(String msgString) {
/* 1751 */       super();
/* 1752 */       setString(msgString);
/*      */     }
/*      */ 
/*      */     public String getString() {
/* 1756 */       return this.msgString;
/*      */     }
/*      */ 
/*      */     public void setString(String msgString) {
/* 1760 */       this.msgString = msgString;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/* 1764 */       AOByteBuffer buf = new AOByteBuffer(200);
/* 1765 */       buf.putOID(null);
/* 1766 */       buf.putInt(3);
/* 1767 */       buf.putInt(0);
/* 1768 */       buf.putString(getString());
/* 1769 */       buf.flip();
/* 1770 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class TargetedComMessage extends TargetMessage
/*      */     implements ClientMessage
/*      */   {
/*      */     private String chatterName;
/* 1735 */     int channel = -1;
/*      */     private String msgString;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public TargetedComMessage()
/*      */     {
/* 1669 */       super();
/*      */     }
/*      */ 
/*      */     public TargetedComMessage(OID targetOid, OID subjectOid, String chatterName, int channel, String msgString)
/*      */     {
/* 1675 */       super(targetOid, subjectOid);
/* 1676 */       setChatterName(chatterName);
/* 1677 */       setChannel(channel);
/* 1678 */       setString(msgString);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1682 */       return "[ComMessage: targetOid=" + getTarget() + ", subjectOid=" + getSubject() + ", channel=" + getChannel() + ", msg=" + getString() + "]";
/*      */     }
/*      */ 
/*      */     public String getChatterName()
/*      */     {
/* 1688 */       return this.chatterName;
/*      */     }
/*      */ 
/*      */     public void setChatterName(String chatterName) {
/* 1692 */       this.chatterName = chatterName;
/*      */     }
/*      */ 
/*      */     public String getString() {
/* 1696 */       return this.msgString;
/*      */     }
/*      */ 
/*      */     public void setString(String msgString) {
/* 1700 */       this.msgString = msgString;
/*      */     }
/*      */ 
/*      */     public int getChannel() {
/* 1704 */       return this.channel;
/*      */     }
/*      */ 
/*      */     public void setChannel(int channel) {
/* 1708 */       this.channel = channel;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/* 1712 */       AOByteBuffer buf = new AOByteBuffer(400);
/* 1713 */       buf.putOID(getSubject());
/* 1714 */       buf.putInt(3);
/* 1715 */       buf.putString(getChatterName());
/* 1716 */       buf.putInt(getChannel());
/* 1717 */       buf.putString(getString());
/* 1718 */       buf.flip();
/* 1719 */       return buf;
/*      */     }
/*      */ 
/*      */     public void fromBuffer(AOByteBuffer buf) {
/* 1723 */       this.subject = buf.getOID();
/* 1724 */       int msgNumber = buf.getInt();
/* 1725 */       if (msgNumber != 3) {
/* 1726 */         Log.error("ComMessage.fromBuffer: msgNumber " + msgNumber + " is not 3");
/* 1727 */         return;
/*      */       }
/* 1729 */       this.chatterName = buf.getString();
/* 1730 */       this.channel = buf.getInt();
/* 1731 */       this.msgString = buf.getString();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ComMessage extends SubjectMessage
/*      */     implements ClientMessage
/*      */   {
/*      */     private String chatterName;
/* 1654 */     int channel = -1;
/*      */     private String msgString;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ComMessage()
/*      */     {
/* 1592 */       super();
/*      */     }
/*      */ 
/*      */     public ComMessage(OID objOid, String chatterName, int channel, String msgString) {
/* 1596 */       super(objOid);
/* 1597 */       setChatterName(chatterName);
/* 1598 */       setChannel(channel);
/* 1599 */       setString(msgString);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1603 */       return "[ComMessage: objOid=" + getSubject() + ", channel=" + getChannel() + ", msg=" + getString() + "]";
/*      */     }
/*      */ 
/*      */     public String getChatterName()
/*      */     {
/* 1608 */       return this.chatterName;
/*      */     }
/*      */ 
/*      */     public void setChatterName(String chatterName) {
/* 1612 */       this.chatterName = chatterName;
/*      */     }
/*      */ 
/*      */     public String getString() {
/* 1616 */       return this.msgString;
/*      */     }
/*      */ 
/*      */     public void setString(String msgString) {
/* 1620 */       this.msgString = msgString;
/*      */     }
/*      */ 
/*      */     public int getChannel() {
/* 1624 */       return this.channel;
/*      */     }
/*      */ 
/*      */     public void setChannel(int channel) {
/* 1628 */       this.channel = channel;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/* 1632 */       AOByteBuffer buf = new AOByteBuffer(400);
/* 1633 */       buf.putOID(getSubject());
/* 1634 */       buf.putInt(3);
/* 1635 */       buf.putString(getChatterName());
/* 1636 */       buf.putInt(getChannel());
/* 1637 */       buf.putString(getString());
/* 1638 */       buf.flip();
/* 1639 */       return buf;
/*      */     }
/*      */ 
/*      */     public void fromBuffer(AOByteBuffer buf) {
/* 1643 */       buf.getOID();
/* 1644 */       int msgNumber = buf.getInt();
/* 1645 */       if (msgNumber != 3) {
/* 1646 */         Log.error("ComMessage.fromBuffer: msgNumber " + msgNumber + " is not 3");
/* 1647 */         return;
/*      */       }
/* 1649 */       this.channel = buf.getInt();
/* 1650 */       this.msgString = buf.getString();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ComReqMessage extends SubjectMessage
/*      */   {
/*      */     private String chatterName;
/* 1577 */     int channel = -1;
/*      */     private String msgString;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ComReqMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public ComReqMessage(OID objOid, String chatterName, int channel, String msgString)
/*      */     {
/* 1546 */       super(objOid);
/* 1547 */       setChatterName(chatterName);
/* 1548 */       setChannel(channel);
/* 1549 */       setString(msgString);
/*      */     }
/*      */ 
/*      */     public String getChatterName() {
/* 1553 */       return this.chatterName;
/*      */     }
/*      */ 
/*      */     public void setChatterName(String chatterName) {
/* 1557 */       this.chatterName = chatterName;
/*      */     }
/*      */ 
/*      */     public String getString() {
/* 1561 */       return this.msgString;
/*      */     }
/*      */ 
/*      */     public void setString(String msgString) {
/* 1565 */       this.msgString = msgString;
/*      */     }
/*      */ 
/*      */     public int getChannel() {
/* 1569 */       return this.channel;
/*      */     }
/*      */ 
/*      */     public void setChannel(int channel) {
/* 1573 */       this.channel = channel;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DetachMessage extends SubjectMessage
/*      */   {
/*      */     private String socketName;
/* 1530 */     private OID objBeingDetached = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DetachMessage()
/*      */     {
/* 1506 */       super();
/*      */     }
/*      */ 
/*      */     public DetachMessage(OID dcObjOid, OID objBeingDetached, String socketName) {
/* 1510 */       super(dcObjOid);
/* 1511 */       setSocketName(socketName);
/* 1512 */       setObjBeingDetached(objBeingDetached);
/*      */     }
/*      */ 
/*      */     public String getSocketName() {
/* 1516 */       return this.socketName;
/*      */     }
/*      */ 
/*      */     public void setSocketName(String socket) {
/* 1520 */       this.socketName = socket;
/*      */     }
/*      */ 
/*      */     public OID getObjBeingDetached() {
/* 1524 */       return this.objBeingDetached;
/*      */     }
/*      */     public void setObjBeingDetached(OID oid) {
/* 1527 */       this.objBeingDetached = oid;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DisplayContextMessage extends SubjectMessage
/*      */   {
/*      */     private DisplayContext dc;
/* 1495 */     private boolean forceInstantLoad = false;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DisplayContextMessage()
/*      */     {
/* 1471 */       super();
/*      */     }
/*      */ 
/*      */     public DisplayContextMessage(OID dcObjOid, DisplayContext dc) {
/* 1475 */       super(dcObjOid);
/* 1476 */       setDisplayContext(dc);
/*      */     }
/*      */ 
/*      */     public DisplayContext getDisplayContext() {
/* 1480 */       return this.dc;
/*      */     }
/*      */ 
/*      */     public void setDisplayContext(DisplayContext dc) {
/* 1484 */       this.dc = dc;
/*      */     }
/*      */ 
/*      */     public boolean getForceInstantLoad() {
/* 1488 */       return this.forceInstantLoad;
/*      */     }
/*      */     public void setForceInstantLoad(boolean forceInstantLoad) {
/* 1491 */       this.forceInstantLoad = forceInstantLoad;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class UpdateMessage extends SubjectMessage
/*      */     implements HasTarget
/*      */   {
/*      */     OID target;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public UpdateMessage()
/*      */     {
/* 1429 */       super();
/*      */     }
/*      */ 
/*      */     UpdateMessage(OID notifyOid, OID updateOid)
/*      */     {
/* 1437 */       super(updateOid);
/*      */ 
/* 1443 */       this.target = notifyOid;
/* 1444 */       if ((notifyOid == null) || (updateOid == null))
/* 1445 */         throw new RuntimeException("null oid");
/*      */     }
/*      */ 
/*      */     public OID getTarget()
/*      */     {
/* 1451 */       return this.target;
/*      */     }
/*      */ 
/*      */     public void setTarget(OID target)
/*      */     {
/* 1456 */       this.target = target;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class FreeRemoteObjectMessage extends SubjectMessage
/*      */     implements ITargetSessionId
/*      */   {
/*      */     private OID instanceOid;
/*      */     private String targetSessionId;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public FreeRemoteObjectMessage()
/*      */     {
/* 1388 */       super();
/*      */     }
/*      */ 
/*      */     public FreeRemoteObjectMessage(String targetSessionId, OID instanceOid, OID objId)
/*      */     {
/* 1393 */       super(objId);
/* 1394 */       setTargetSessionId(targetSessionId);
/* 1395 */       setInstanceOid(instanceOid);
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/* 1399 */       this.instanceOid = oid;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/* 1403 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public String getTargetSessionId() {
/* 1407 */       return this.targetSessionId;
/*      */     }
/*      */ 
/*      */     public void setTargetSessionId(String targetSessionId) {
/* 1411 */       this.targetSessionId = targetSessionId;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class NewRemoteObjectMessage extends SubjectMessage
/*      */     implements ITargetSessionId
/*      */   {
/*      */     private OID instanceOid;
/*      */     private Point loc;
/*      */     private Quaternion orient;
/*      */     private ObjectType type;
/*      */     int perceptionRadius;
/*      */     private String targetSessionId;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public NewRemoteObjectMessage()
/*      */     {
/* 1306 */       super();
/*      */     }
/*      */ 
/*      */     public NewRemoteObjectMessage(String targetSessionId, OID instanceOid, OID newObjId, Point loc, Quaternion orient, int perceptionRadius, ObjectType type)
/*      */     {
/* 1313 */       super(newObjId);
/* 1314 */       setTargetSessionId(targetSessionId);
/* 1315 */       setInstanceOid(instanceOid);
/* 1316 */       setLoc(loc);
/* 1317 */       setOrient(orient);
/* 1318 */       setPerceptionRadius(perceptionRadius);
/* 1319 */       setType(type);
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/* 1323 */       this.instanceOid = oid;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/* 1327 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setLoc(Point loc) {
/* 1331 */       this.loc = loc;
/*      */     }
/*      */ 
/*      */     public Point getLoc() {
/* 1335 */       return this.loc;
/*      */     }
/*      */ 
/*      */     public void setOrient(Quaternion orient) {
/* 1339 */       this.orient = orient;
/*      */     }
/*      */ 
/*      */     public Quaternion getOrient() {
/* 1343 */       return this.orient;
/*      */     }
/*      */ 
/*      */     public void setPerceptionRadius(int perceptionRadius) {
/* 1347 */       this.perceptionRadius = perceptionRadius;
/*      */     }
/*      */ 
/*      */     public int getPerceptionRadius() {
/* 1351 */       return this.perceptionRadius;
/*      */     }
/*      */ 
/*      */     public void setType(ObjectType type) {
/* 1355 */       this.type = type;
/*      */     }
/*      */ 
/*      */     public ObjectType getType() {
/* 1359 */       return this.type;
/*      */     }
/*      */ 
/*      */     public String getTargetSessionId() {
/* 1363 */       return this.targetSessionId;
/*      */     }
/*      */ 
/*      */     public void setTargetSessionId(String targetSessionId) {
/* 1367 */       this.targetSessionId = targetSessionId;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class PerceptionInfo
/*      */   {
/*      */     public WorldManagerClient.ObjectInfo objectInfo;
/*      */     public DisplayContext displayContext;
/*      */ 
/*      */     public PerceptionInfo()
/*      */     {
/*      */     }
/*      */ 
/*      */     public PerceptionInfo(WorldManagerClient.ObjectInfo info)
/*      */     {
/* 1290 */       this.objectInfo = info;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ReparentWNodeReqMessage extends SubjectMessage
/*      */   {
/*      */     private OID parentOid;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ReparentWNodeReqMessage()
/*      */     {
/* 1257 */       super();
/*      */     }
/*      */ 
/*      */     public ReparentWNodeReqMessage(OID oid, OID parentOid) {
/* 1261 */       super(oid);
/* 1262 */       setParentOid(parentOid);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1266 */       return "[ReparentWNodeReqMessage oid= + getSubject(), parent=" + this.parentOid + "]";
/*      */     }
/*      */ 
/*      */     public void setParentOid(OID parentOid) {
/* 1270 */       this.parentOid = parentOid;
/*      */     }
/*      */ 
/*      */     public OID getParentOid() {
/* 1274 */       return this.parentOid;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class WorldNodeCorrectMessage extends SubjectMessage
/*      */     implements ClientMessage
/*      */   {
/* 1249 */     private BasicWorldNode wnode = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public WorldNodeCorrectMessage()
/*      */     {
/* 1191 */       setMsgType(WorldManagerClient.MSG_TYPE_WNODECORRECT);
/*      */     }
/*      */ 
/*      */     public WorldNodeCorrectMessage(OID oid, BasicWorldNode wnode) {
/* 1195 */       super(oid);
/* 1196 */       setWorldNode(wnode);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1200 */       return "[WorldNodeCorrectMessage oid=" + getSubject() + ", wnode=" + getWorldNode() + "]";
/*      */     }
/*      */ 
/*      */     public void setWorldNode(BasicWorldNode wnode)
/*      */     {
/* 1205 */       this.wnode = wnode;
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getWorldNode() {
/* 1209 */       return this.wnode;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/* 1213 */       AOByteBuffer buf = new AOByteBuffer(128);
/* 1214 */       buf.putOID(getSubject());
/* 1215 */       buf.putInt(79);
/* 1216 */       buf.putLong(System.currentTimeMillis());
/*      */ 
/* 1218 */       AOVector dir = this.wnode.getDir();
/* 1219 */       buf.putAOVector(dir == null ? new AOVector() : dir);
/* 1220 */       Point loc = this.wnode.getLoc();
/* 1221 */       buf.putPoint(loc == null ? new Point() : loc);
/* 1222 */       Quaternion q = this.wnode.getOrientation();
/* 1223 */       buf.putQuaternion(q == null ? new Quaternion() : q);
/* 1224 */       buf.flip();
/* 1225 */       return buf;
/*      */     }
/*      */ 
/*      */     public void fromBuffer(AOByteBuffer buf)
/*      */     {
/* 1230 */       OID oid = buf.getOID();
/* 1231 */       int msgNumber = buf.getInt();
/* 1232 */       if (msgNumber != 79) {
/* 1233 */         Log.error("WorldNodeCorrectMessage.fromBuffer: msgNumber " + msgNumber + " is not 79");
/* 1234 */         return;
/*      */       }
/*      */ 
/* 1237 */       buf.getLong();
/* 1238 */       AOVector dir = buf.getAOVector();
/* 1239 */       Point loc = buf.getPoint();
/* 1240 */       Quaternion orient = buf.getQuaternion();
/* 1241 */       BasicWorldNode wnode = new BasicWorldNode();
/* 1242 */       wnode.setDir(dir);
/* 1243 */       wnode.setLoc(loc);
/* 1244 */       wnode.setOrientation(orient);
/* 1245 */       setWorldNode(wnode);
/* 1246 */       setSubject(oid);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DirLocOrientMessage extends SubjectMessage
/*      */     implements ClientMessage
/*      */   {
/* 1179 */     private BasicWorldNode wnode = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DirLocOrientMessage()
/*      */     {
/* 1115 */       super();
/*      */     }
/*      */ 
/*      */     public DirLocOrientMessage(OID oid, BasicWorldNode wnode) {
/* 1119 */       super(oid);
/* 1120 */       setWorldNode(wnode);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1124 */       return "[DirLocOrient oid=" + getSubject() + ", wnode=" + getWorldNode() + "]";
/*      */     }
/*      */ 
/*      */     public void setWorldNode(BasicWorldNode wnode)
/*      */     {
/* 1129 */       this.wnode = wnode;
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getWorldNode() {
/* 1133 */       return this.wnode;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/* 1137 */       BasicWorldNode bnode = getWorldNode();
/*      */ 
/* 1139 */       AOByteBuffer buf = new AOByteBuffer(128);
/* 1140 */       buf.putOID(getSubject());
/* 1141 */       buf.putInt(79);
/* 1142 */       buf.putLong(System.currentTimeMillis());
/*      */ 
/* 1144 */       AOVector dir = bnode.getDir();
/* 1145 */       buf.putAOVector(dir == null ? new AOVector() : dir);
/* 1146 */       Point loc = bnode.getLoc();
/* 1147 */       buf.putPoint(loc == null ? new Point() : loc);
/* 1148 */       Quaternion q = bnode.getOrientation();
/* 1149 */       buf.putQuaternion(q == null ? new Quaternion() : q);
/* 1150 */       buf.flip();
/* 1151 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class UpdateWorldNodeMessage extends SubjectMessage
/*      */     implements ClientMessage
/*      */   {
/* 1093 */     private BasicWorldNode wnode = null;
/*      */     transient AOByteBuffer eventBuf;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public UpdateWorldNodeMessage()
/*      */     {
/* 1059 */       super();
/*      */     }
/*      */ 
/*      */     public UpdateWorldNodeMessage(OID oid, BasicWorldNode wnode) {
/* 1063 */       super(oid);
/* 1064 */       setWorldNode(wnode);
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1068 */       return "[UpdateWorldNodeMessage " + getWorldNode() + "]";
/*      */     }
/*      */ 
/*      */     public void setWorldNode(BasicWorldNode wnode) {
/* 1072 */       this.wnode = wnode;
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getWorldNode() {
/* 1076 */       return this.wnode;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/* 1080 */       BasicWorldNode bnode = getWorldNode();
/*      */ 
/* 1082 */       AOByteBuffer buf = new AOByteBuffer(64);
/* 1083 */       buf.putOID(getSubject());
/* 1084 */       buf.putInt(2);
/* 1085 */       buf.putLong(System.currentTimeMillis());
/*      */ 
/* 1087 */       buf.putAOVector(bnode.getDir());
/* 1088 */       buf.putPoint(bnode.getLoc());
/* 1089 */       buf.flip();
/* 1090 */       return buf;
/*      */     }
/*      */ 
/*      */     public void setEventBuf(AOByteBuffer buf)
/*      */     {
/* 1097 */       this.eventBuf = buf;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer getEventBuf()
/*      */     {
/* 1102 */       return this.eventBuf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class UpdateWorldNodeReqMessage extends SubjectMessage
/*      */     implements BracketedMessage
/*      */   {
/*      */     private Message preMessage;
/*      */     private Message postMessage;
/* 1046 */     private BasicWorldNode wnode = null;
/* 1047 */     protected boolean override = false;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public UpdateWorldNodeReqMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public UpdateWorldNodeReqMessage(OID oid, BasicWorldNode wnode)
/*      */     {
/* 1003 */       super(oid);
/* 1004 */       setWorldNode(wnode);
/*      */     }
/*      */ 
/*      */     public void setWorldNode(BasicWorldNode wnode) {
/* 1008 */       this.wnode = wnode;
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getWorldNode() {
/* 1012 */       return this.wnode;
/*      */     }
/*      */ 
/*      */     public void setOverride(boolean override) {
/* 1016 */       this.override = override;
/*      */     }
/*      */ 
/*      */     public boolean getOverride() {
/* 1020 */       return this.override;
/*      */     }
/*      */ 
/*      */     public Message getPreMessage()
/*      */     {
/* 1025 */       return this.preMessage;
/*      */     }
/*      */ 
/*      */     public void setPreMessage(Message message)
/*      */     {
/* 1030 */       this.preMessage = message;
/*      */     }
/*      */ 
/*      */     public Message getPostMessage()
/*      */     {
/* 1035 */       return this.postMessage;
/*      */     }
/*      */ 
/*      */     public void setPostMessage(Message message)
/*      */     {
/* 1040 */       this.postMessage = message;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SetWorldNodeReqMessage extends SubjectMessage
/*      */   {
/*  988 */     private BasicWorldNode wnode = null;
/*      */     private int flags;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SetWorldNodeReqMessage()
/*      */     {
/*  962 */       super();
/*      */     }
/*      */ 
/*      */     SetWorldNodeReqMessage(OID oid, BasicWorldNode wnode, int flags) {
/*  966 */       super(oid);
/*      */ 
/*  968 */       setWorldNode(wnode);
/*  969 */       setFlags(flags);
/*      */     }
/*      */ 
/*      */     public void setWorldNode(BasicWorldNode wnode) {
/*  973 */       this.wnode = wnode;
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getWorldNode() {
/*  977 */       return this.wnode;
/*      */     }
/*      */ 
/*      */     public void setFlags(int flags) {
/*  981 */       this.flags = flags;
/*      */     }
/*      */ 
/*      */     public int getFlags() {
/*  985 */       return this.flags;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DespawnedMessage extends SubjectMessage
/*      */   {
/*      */     private OID instanceOid;
/*      */     private ObjectType type;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DespawnedMessage()
/*      */     {
/*  922 */       super();
/*      */     }
/*      */ 
/*      */     public DespawnedMessage(OID oid, OID instanceOid, ObjectType type)
/*      */     {
/*  928 */       super(oid);
/*  929 */       setInstanceOid(instanceOid);
/*  930 */       setType(type);
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/*  934 */       this.instanceOid = oid;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/*  938 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setType(ObjectType type) {
/*  942 */       this.type = type;
/*      */     }
/*      */ 
/*      */     public ObjectType getType() {
/*  946 */       return this.type;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DespawnReqMessage extends SubjectMessage
/*      */     implements BracketedMessage
/*      */   {
/*      */     private Message preMessage;
/*      */     private Message postMessage;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DespawnReqMessage()
/*      */     {
/*  887 */       super();
/*      */     }
/*      */     DespawnReqMessage(OID oid) {
/*  890 */       super(oid);
/*      */     }
/*      */ 
/*      */     public Message getPreMessage()
/*      */     {
/*  895 */       return this.preMessage;
/*      */     }
/*      */ 
/*      */     public void setPreMessage(Message message)
/*      */     {
/*  900 */       this.preMessage = message;
/*      */     }
/*      */ 
/*      */     public Message getPostMessage()
/*      */     {
/*  905 */       return this.postMessage;
/*      */     }
/*      */ 
/*      */     public void setPostMessage(Message message)
/*      */     {
/*  910 */       this.postMessage = message;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SpawnedMessage extends SubjectMessage
/*      */   {
/*      */     private OID instanceOid;
/*      */     private ObjectType objectType;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SpawnedMessage()
/*      */     {
/*  850 */       super();
/*      */     }
/*      */ 
/*      */     public SpawnedMessage(OID oid, OID instanceOid, ObjectType objectType)
/*      */     {
/*  856 */       super(oid);
/*  857 */       setInstanceOid(instanceOid);
/*  858 */       setType(objectType);
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/*  862 */       this.instanceOid = oid;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/*  866 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setType(ObjectType type) {
/*  870 */       this.objectType = type;
/*      */     }
/*      */ 
/*      */     public ObjectType getType() {
/*  874 */       return this.objectType;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SpawnReqMessage extends SubjectMessage
/*      */     implements BracketedMessage
/*      */   {
/*      */     private Message preMessage;
/*      */     private Message postMessage;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SpawnReqMessage()
/*      */     {
/*  814 */       super();
/*      */     }
/*      */ 
/*      */     SpawnReqMessage(OID oid) {
/*  818 */       super(oid);
/*      */     }
/*      */ 
/*      */     public Message getPreMessage()
/*      */     {
/*  823 */       return this.preMessage;
/*      */     }
/*      */ 
/*      */     public void setPreMessage(Message message)
/*      */     {
/*  828 */       this.preMessage = message;
/*      */     }
/*      */ 
/*      */     public Message getPostMessage()
/*      */     {
/*  833 */       return this.postMessage;
/*      */     }
/*      */ 
/*      */     public void setPostMessage(Message message)
/*      */     {
/*  838 */       this.postMessage = message;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class RoadMessage extends TargetMessage
/*      */   {
/*  804 */     private Set<Road> roads = new HashSet();
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public RoadMessage()
/*      */     {
/*  763 */       super();
/*      */     }
/*      */ 
/*      */     public RoadMessage(OID oid, Set<Road> roads) {
/*  767 */       super(oid, oid);
/*  768 */       setRoads(roads);
/*      */     }
/*      */ 
/*      */     public void setRoads(Set<Road> roads) {
/*  772 */       this.roads = roads;
/*      */     }
/*      */ 
/*      */     public Set<Road> getRoads() {
/*  776 */       return new HashSet(this.roads);
/*      */     }
/*      */ 
/*      */     public List<AOByteBuffer> toBuffer()
/*      */     {
/*  785 */       List bufList = new LinkedList();
/*      */ 
/*  787 */       for (Road road : this.roads) {
/*  788 */         AOByteBuffer buf = new AOByteBuffer(1000);
/*  789 */         buf.putOID(road.getOid());
/*  790 */         buf.putInt(54);
/*  791 */         buf.putString(road.getName());
/*  792 */         List points = road.getPoints();
/*  793 */         buf.putInt(points.size());
/*  794 */         for (Point p : points) {
/*  795 */           buf.putPoint(p);
/*      */         }
/*  797 */         buf.putInt(road.getHalfWidth().intValue());
/*  798 */         buf.flip();
/*  799 */         bufList.add(buf);
/*      */       }
/*  801 */       return bufList;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class FogMessage extends TargetMessage
/*      */     implements EventParser
/*      */   {
/*  749 */     private FogRegionConfig fogConfig = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public FogMessage()
/*      */     {
/*  702 */       super();
/*      */     }
/*      */ 
/*      */     public FogMessage(OID oid, FogRegionConfig fogConfig) {
/*  706 */       super(oid, oid);
/*  707 */       setFogConfig(fogConfig);
/*      */     }
/*      */ 
/*      */     public FogMessage(OID oid, Fog fog) {
/*  711 */       super(oid, oid);
/*  712 */       FogRegionConfig config = new FogRegionConfig();
/*  713 */       config.setColor(fog.getColor());
/*  714 */       config.setNear(fog.getStart());
/*  715 */       config.setFar(fog.getEnd());
/*  716 */       setFogConfig(config);
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/*  720 */       int msgId = Engine.getEventServer().getEventID(getClass());
/*  721 */       AOByteBuffer buf = new AOByteBuffer(32);
/*      */ 
/*  723 */       buf.putOID(null);
/*  724 */       buf.putInt(msgId);
/*  725 */       buf.putColor(this.fogConfig.getColor());
/*  726 */       buf.putInt(this.fogConfig.getNear());
/*  727 */       buf.putInt(this.fogConfig.getFar());
/*  728 */       buf.flip();
/*  729 */       return buf;
/*      */     }
/*      */ 
/*      */     public void parseBytes(AOByteBuffer buf) {
/*  733 */       buf.getOID();
/*  734 */       buf.getInt();
/*  735 */       FogRegionConfig config = new FogRegionConfig();
/*  736 */       config.setColor(buf.getColor());
/*  737 */       config.setNear(buf.getInt());
/*  738 */       config.setFar(buf.getInt());
/*      */     }
/*      */ 
/*      */     public void setFogConfig(FogRegionConfig fogConfig) {
/*  742 */       this.fogConfig = fogConfig;
/*      */     }
/*      */ 
/*      */     public FogRegionConfig getFogConfig() {
/*  746 */       return this.fogConfig;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SetAmbientLightMessage extends TargetMessage
/*      */   {
/*      */     private Color color;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SetAmbientLightMessage()
/*      */     {
/*  676 */       setMsgType(WorldManagerClient.MSG_TYPE_SET_AMBIENT);
/*      */     }
/*      */ 
/*      */     public SetAmbientLightMessage(OID oid, Color color) {
/*  680 */       super(oid, oid);
/*  681 */       setColor(color);
/*      */     }
/*      */ 
/*      */     public void setColor(Color color) {
/*  685 */       this.color = color;
/*      */     }
/*      */ 
/*      */     public Color getColor() {
/*  689 */       return this.color;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DisplayContextReqMessage extends SubjectMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DisplayContextReqMessage()
/*      */     {
/*  665 */       super();
/*      */     }
/*      */     DisplayContextReqMessage(OID oid) {
/*  668 */       super(oid);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetObjectsInMessage extends SubjectMessage
/*      */   {
/*      */     private Point loc;
/*      */     private Integer radius;
/*      */     private ObjectType objectType;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetObjectsInMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public GetObjectsInMessage(OID subjectOid, Point loc, Integer radius, ObjectType objectType)
/*      */     {
/*  635 */       super(subjectOid);
/*  636 */       this.loc = loc;
/*  637 */       this.radius = radius;
/*  638 */       this.objectType = objectType;
/*      */     }
/*      */ 
/*      */     public Point getLoc()
/*      */     {
/*  643 */       return this.loc;
/*      */     }
/*      */ 
/*      */     public Integer getRadius()
/*      */     {
/*  648 */       return this.radius;
/*      */     }
/*      */ 
/*      */     public ObjectType getObjectType()
/*      */     {
/*  653 */       return this.objectType;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ObjInfoRespMessage extends ResponseMessage
/*      */     implements ITargetSessionId
/*      */   {
/*      */     private String targetSessionId;
/*  621 */     private WorldManagerClient.ObjectInfo objInfo = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ObjInfoRespMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public ObjInfoRespMessage(Message msg, String targetSessionId, WorldManagerClient.ObjectInfo objInfo)
/*      */     {
/*  599 */       super();
/*  600 */       setTargetSessionId(targetSessionId);
/*  601 */       setObjInfo(objInfo);
/*      */     }
/*      */ 
/*      */     public String getTargetSessionId() {
/*  605 */       return this.targetSessionId;
/*      */     }
/*      */ 
/*      */     public void setTargetSessionId(String targetSessionId) {
/*  609 */       this.targetSessionId = targetSessionId;
/*      */     }
/*      */ 
/*      */     public void setObjInfo(WorldManagerClient.ObjectInfo objInfo) {
/*  613 */       this.objInfo = objInfo;
/*      */     }
/*      */     public WorldManagerClient.ObjectInfo getObjInfo() {
/*  616 */       return this.objInfo;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ObjInfoReqMessage extends SubjectMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ObjInfoReqMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     ObjInfoReqMessage(OID oid)
/*      */     {
/*  587 */       super(oid);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class TerrainReqMessage extends SubjectMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public TerrainReqMessage()
/*      */     {
/*  574 */       super();
/*      */     }
/*      */     TerrainReqMessage(OID oid) {
/*  577 */       super(oid);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class FreeRoadMessage extends TargetMessage
/*      */     implements ClientMessage, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public FreeRoadMessage()
/*      */     {
/*  554 */       super();
/*      */     }
/*      */ 
/*      */     public FreeRoadMessage(OID oid) {
/*  558 */       super(oid, oid);
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/*  562 */       AOByteBuffer buf = new AOByteBuffer(20);
/*  563 */       buf.putOID(getTarget());
/*  564 */       buf.putInt(69);
/*  565 */       buf.flip();
/*  566 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class RoadInfo
/*      */     implements ClientMessage, Serializable
/*      */   {
/*      */     private OID oid;
/*      */     private String name;
/*      */     private Point start;
/*      */     private Point end;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public RoadInfo()
/*      */     {
/*      */     }
/*      */ 
/*      */     public RoadInfo(RoadSegment segment)
/*      */     {
/*  476 */       setOid(segment.getOid());
/*  477 */       setName(segment.getName());
/*  478 */       setStart(segment.getStart());
/*  479 */       setEnd(segment.getEnd());
/*      */     }
/*      */ 
/*      */     public RoadInfo(OID oid, String name, Point start, Point end) {
/*  483 */       setOid(oid);
/*  484 */       setName(name);
/*  485 */       setStart(start);
/*  486 */       setEnd(end);
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  490 */       return "[RoadInfo: oid=" + getOid() + ", name=" + getName() + ", start=" + getStart() + ", end=" + getEnd() + "]";
/*      */     }
/*      */ 
/*      */     public OID getOid()
/*      */     {
/*  495 */       return this.oid;
/*      */     }
/*      */ 
/*      */     public void setOid(OID oid) {
/*  499 */       this.oid = oid;
/*      */     }
/*      */ 
/*      */     public String getName() {
/*  503 */       return this.name;
/*      */     }
/*      */ 
/*      */     public void setName(String name) {
/*  507 */       this.name = name;
/*      */     }
/*      */ 
/*      */     public Point getStart() {
/*  511 */       return this.start;
/*      */     }
/*      */ 
/*      */     public void setStart(Point start) {
/*  515 */       this.start = start;
/*      */     }
/*      */ 
/*      */     public Point getEnd() {
/*  519 */       return this.end;
/*      */     }
/*      */ 
/*      */     public void setEnd(Point end) {
/*  523 */       this.end = end;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer() {
/*  527 */       AOByteBuffer buf = new AOByteBuffer(200);
/*  528 */       buf.putOID(getOid());
/*  529 */       buf.putInt(54);
/*  530 */       buf.putString(getName());
/*  531 */       buf.putInt(2);
/*  532 */       buf.putPoint(this.start);
/*  533 */       buf.putPoint(this.end);
/*  534 */       buf.flip();
/*  535 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ObjectInfo
/*      */     implements Serializable
/*      */   {
/*      */     public OID instanceOid;
/*      */     public OID oid;
/*      */     public String name;
/*      */     public OID accountOid;
/*      */     public Point loc;
/*      */     public Quaternion orient;
/*      */     public AOVector scale;
/*      */     public ObjectType objType;
/*      */     public boolean followsTerrain;
/*      */     public AOVector dir;
/*      */     public long lastInterp;
/*  460 */     private Map<String, Serializable> propMap = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public String toString()
/*      */     {
/*  396 */       return "[ObjectInfo: name=" + this.name + ", oid=" + this.oid + ", loc=" + this.loc + ", orient=" + this.orient + ", scale=" + this.scale + ", objType=" + this.objType + ", followsTerrain=" + this.followsTerrain + "]";
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBuffer(OID notifyOid)
/*      */     {
/*  403 */       Log.debug("INFO: creating buffer with notifyOid: " + notifyOid);
/*  404 */       AOByteBuffer buf = new AOByteBuffer(220);
/*  405 */       buf.putOID(notifyOid);
/*  406 */       buf.putInt(8);
/*  407 */       buf.putOID(this.oid);
/*  408 */       buf.putString(this.name == null ? "unknown" : this.name);
/*      */ 
/*  410 */       buf.putPoint(this.loc == null ? new Point() : this.loc);
/*  411 */       buf.putQuaternion(this.orient == null ? new Quaternion() : this.orient);
/*  412 */       buf.putAOVector(this.scale == null ? new AOVector(1.0F, 1.0F, 1.0F) : this.scale);
/*      */ 
/*  414 */       buf.putInt(this.objType.getTypeId());
/*  415 */       buf.putInt(this.followsTerrain ? 1 : 0);
/*  416 */       buf.putAOVector(this.dir);
/*  417 */       buf.putLong(this.lastInterp);
/*  418 */       buf.flip();
/*  419 */       return buf;
/*      */     }
/*      */ 
/*      */     public void setProperty(String key, Serializable val)
/*      */     {
/*  426 */       if (this.propMap == null)
/*  427 */         this.propMap = new HashMap();
/*  428 */       this.propMap.put(key, val);
/*      */     }
/*      */ 
/*      */     public Serializable getProperty(String key) {
/*  432 */       if (this.propMap == null) {
/*  433 */         return null;
/*      */       }
/*  435 */       return (Serializable)this.propMap.get(key);
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.WorldManagerClient
 * JD-Core Version:    0.6.0
 */