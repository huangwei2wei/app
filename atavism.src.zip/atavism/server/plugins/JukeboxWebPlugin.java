/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.msgsys.GenericMessage;
/*     */ import atavism.msgsys.GenericResponseMessage;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.EnginePlugin;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.python.core.PyDictionary;
/*     */ import org.python.core.PyList;
/*     */ import org.python.core.PyObject;
/*     */ import org.python.core.PyString;
/*     */ import org.python.core.PyTuple;
/*     */ 
/*     */ public class JukeboxWebPlugin extends EnginePlugin
/*     */ {
/*     */   public JukeboxWebPlugin()
/*     */   {
/*  21 */     super("JukeboxWeb");
/*  22 */     setPluginType("JukeboxWeb");
/*     */   }
/*     */ 
/*     */   public void onActivate() {
/*     */   }
/*     */ 
/*     */   public ArrayList getTracks() {
/*  29 */     GenericMessage msg = new GenericMessage();
/*  30 */     MessageType jukeboxGetTracks = MessageType.intern("jukeboxGetTracks");
/*  31 */     msg.setMsgType(jukeboxGetTracks);
/*     */ 
/*  33 */     GenericResponseMessage respMsg = (GenericResponseMessage)Engine.getAgent().sendRPC(msg);
/*     */ 
/*  36 */     PyList trackData = (PyList)respMsg.getData();
/*     */ 
/*  38 */     ArrayList trackList = new ArrayList();
/*     */ 
/*  40 */     for (int j = trackData.__len__(); j-- > 0; ) {
/*  41 */       PyDictionary trackInfo = (PyDictionary)trackData.__getitem__(j);
/*  42 */       PyList list = trackInfo.items();
/*  43 */       HashMap trackMap = new HashMap();
/*  44 */       for (int i = list.__len__(); i-- > 0; ) {
/*  45 */         PyTuple tup = (PyTuple)list.__getitem__(i);
/*  46 */         trackMap.put(tup.__getitem__(0).__str__().internedString(), tup.__getitem__(1).__str__().internedString());
/*     */       }
/*     */ 
/*  49 */       trackList.add(trackMap);
/*     */     }
/*     */ 
/*  58 */     return trackList;
/*     */   }
/*     */ 
/*     */   public boolean addTrack(String name, String type, String url, String cost, String description) {
/*  62 */     GenericMessage msg = new GenericMessage();
/*  63 */     MessageType jukeboxAddTrack = MessageType.intern("jukeboxAddTrack");
/*  64 */     msg.setMsgType(jukeboxAddTrack);
/*  65 */     msg.setProperty("name", name);
/*  66 */     msg.setProperty("type", type);
/*  67 */     msg.setProperty("url", url);
/*  68 */     msg.setProperty("cost", cost);
/*  69 */     msg.setProperty("description", description);
/*     */ 
/*  71 */     GenericResponseMessage respMsg = (GenericResponseMessage)Engine.getAgent().sendRPC(msg);
/*     */ 
/*  73 */     Integer respVal = (Integer)respMsg.getData();
/*  74 */     return respVal.intValue() != 0;
/*     */   }
/*     */ 
/*     */   public boolean deleteTrack(String name) {
/*  78 */     GenericMessage msg = new GenericMessage();
/*  79 */     MessageType jukeboxDeleteTrack = MessageType.intern("jukeboxDeleteTrack");
/*  80 */     msg.setMsgType(jukeboxDeleteTrack);
/*  81 */     msg.setProperty("name", name);
/*     */ 
/*  83 */     GenericResponseMessage respMsg = (GenericResponseMessage)Engine.getAgent().sendRPC(msg);
/*     */ 
/*  85 */     Integer respVal = (Integer)respMsg.getData();
/*  86 */     return respVal.intValue() != 0;
/*     */   }
/*     */ 
/*     */   public int getMoney(String poid) {
/*  90 */     GenericMessage msg = new GenericMessage();
/*  91 */     MessageType jukeboxGetFunds = MessageType.intern("jukeboxGetFunds");
/*  92 */     msg.setMsgType(jukeboxGetFunds);
/*  93 */     msg.setProperty("poid", poid);
/*     */ 
/*  95 */     GenericResponseMessage respMsg = (GenericResponseMessage)Engine.getAgent().sendRPC(msg);
/*     */ 
/*  97 */     Integer respVal = (Integer)respMsg.getData();
/*  98 */     return respVal.intValue();
/*     */   }
/*     */ 
/*     */   public boolean addMoney(String poid, String money) {
/* 102 */     GenericMessage msg = new GenericMessage();
/* 103 */     MessageType jukeboxAddFunds = MessageType.intern("jukeboxAddFunds");
/* 104 */     msg.setMsgType(jukeboxAddFunds);
/* 105 */     msg.setProperty("poid", poid);
/* 106 */     msg.setProperty("money", money);
/*     */ 
/* 108 */     Engine.getAgent().sendRPC(msg);
/*     */ 
/* 111 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.JukeboxWebPlugin
 * JD-Core Version:    0.6.0
 */