/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.management.Management;
/*      */ import atavism.msgsys.FilterUpdate;
/*      */ import atavism.msgsys.GenericResponseMessage;
/*      */ import atavism.msgsys.IntegerResponseMessage;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageTypeFilter;
/*      */ import atavism.msgsys.OIDResponseMessage;
/*      */ import atavism.msgsys.ResponseMessage;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.msgsys.TargetMessage;
/*      */ import atavism.server.engine.BasicInterpolator;
/*      */ import atavism.server.engine.BasicWorldNode;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.EnginePlugin;
/*      */ import atavism.server.engine.Hook;
/*      */ import atavism.server.engine.HookManager;
/*      */ import atavism.server.engine.InterpolatedWorldNode;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.messages.LoginMessage;
/*      */ import atavism.server.messages.PerceptionFilter;
/*      */ import atavism.server.messages.PerceptionMessage;
/*      */ import atavism.server.messages.PerceptionMessage.ObjectNote;
/*      */ import atavism.server.messages.PerceptionTrigger;
/*      */ import atavism.server.messages.PopulationFilter;
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.network.ClientConnection;
/*      */ import atavism.server.network.ClientConnection.AcceptCallback;
/*      */ import atavism.server.network.ClientConnection.MessageCallback;
/*      */ import atavism.server.network.ClientTCPMessageIO;
/*      */ import atavism.server.objects.ObjectType;
/*      */ import atavism.server.objects.ObjectTypes;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.Base64;
/*      */ import atavism.server.util.CountLogger;
/*      */ import atavism.server.util.CountLogger.Counter;
/*      */ import atavism.server.util.DebugUtils;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.SecureToken;
/*      */ import atavism.server.util.SecureTokenManager;
/*      */ import atavism.server.util.ServerVersion;
/*      */ import atavism.server.util.TimeHistogram;
/*      */ import atavism.server.voice.GroupMember;
/*      */ import atavism.server.voice.NonpositionalVoiceGroup;
/*      */ import atavism.server.voice.PositionalGroupMember;
/*      */ import atavism.server.voice.PositionalVoiceGroup;
/*      */ import atavism.server.voice.VoiceConnection;
/*      */ import atavism.server.voice.VoiceGroup;
/*      */ import atavism.server.voice.VoiceSender;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ public class VoicePlugin extends EnginePlugin
/*      */   implements VoiceSender, ClientConnection.AcceptCallback, ClientConnection.MessageCallback
/*      */ {
/*      */   public static final byte voicePacketHeaderSize = 4;
/*      */   public static final byte opcodeVoiceUnallocated = 0;
/*      */   public static final byte opcodeAuthenticate = 1;
/*      */   public static final byte opcodeAllocateCodec = 2;
/*      */   public static final byte opcodeAllocatePositionalCodec = 3;
/*      */   public static final byte opcodeReconfirmCodec = 4;
/*      */   public static final byte opcodeDeallocate = 5;
/*      */   public static final byte opcodeData = 6;
/*      */   public static final byte opcodeAggregatedData = 7;
/*      */   public static final byte opcodeLoginStatus = 8;
/*      */   public static final byte opcodeChangeIgnoredStatus = 9;
/*      */   public static final int opcodeHighest = 9;
/* 1756 */   public static String[] opcodeNames = { "Unallocd", "Auth    ", "Alloc   ", "AllocPos", "Confirm ", "Dealloc ", "Data    ", "AggrData", "LgnStatus" };
/*      */ 
/* 1763 */   public static int[] voiceMsgSize = { 0, 25, 12, 12, 12, 4, 4, 5, 12, 6 };
/*      */ 
/* 1768 */   public static int lengthBytes = 2;
/*      */ 
/* 1774 */   public static int[] speexNarrowBandFrameSize = { 1, 6, 15, 20, 28, 38, 46, 62, 10 };
/*      */ 
/* 1786 */   public static int[] speexWideBandFrameSize = { 1, 5, 14, 24, 44 };
/*      */ 
/* 1792 */   public static int maxVoiceChannels = 4;
/*      */   private CountLogger countLogger;
/*      */   private static CountLogger.Counter countPacketsIgnored;
/*      */   private static CountLogger.Counter countSeqNumGaps;
/*      */   public static CountLogger.Counter countSendLoginStatus;
/*      */   private static CountLogger.Counter countPacketsReceived;
/*      */   private static CountLogger.Counter countDataFramesReceived;
/*      */   public static CountLogger.Counter countAllocateVoiceReceived;
/*      */   public static CountLogger.Counter countDeallocateVoiceReceived;
/*      */   private static CountLogger.Counter countPacketsSent;
/*      */   private static CountLogger.Counter countDataFramesSent;
/*      */   public static CountLogger.Counter countAllocateVoiceSent;
/*      */   public static CountLogger.Counter countDeallocateVoiceSent;
/* 1814 */   public static boolean runHistograms = false;
/*      */   public static TimeHistogram processPacketHistogram;
/*      */   public static TimeHistogram dataSendHistogram;
/*      */   public static TimeHistogram voiceAllocHistogram;
/*      */   public static TimeHistogram voiceDeallocHistogram;
/* 1821 */   public static boolean checkAuthToken = true;
/*      */ 
/* 1823 */   private VoiceConManager conMgr = new VoiceConManager();
/*      */   private Integer voicePort;
/* 1836 */   private boolean recordVoices = false;
/*      */ 
/* 1842 */   private Set<VoiceConnection> loginStatusEventReceivers = null;
/*      */ 
/* 1847 */   private short loginStatusSeqNum = 0;
/*      */ 
/* 1852 */   private ClientTCPMessageIO clientTCPMessageIO = null;
/*      */ 
/* 1858 */   protected static boolean createGroupWhenReferenced = false;
/*      */ 
/* 1864 */   protected static boolean allowVoiceBots = false;
/*      */ 
/* 1869 */   private static float audibleRadius = 20.0F;
/*      */ 
/* 1876 */   protected static float hystericalMargin = 3.0F;
/*      */ 
/* 1881 */   protected static VoicePlugin instance = null;
/*      */ 
/* 1886 */   private String serverVersion = null;
/*      */   protected PerceptionFilter perceptionFilter;
/*      */   protected long perceptionSubId;
/* 1891 */   protected Updater updater = null;
/*      */ 
/* 1893 */   protected Thread updaterThread = null;
/*      */ 
/* 1895 */   protected boolean running = true;
/*      */ 
/* 1897 */   protected transient Lock lock = LockFactory.makeLock("VoicePlugin");
/*      */ 
/*      */   public VoicePlugin()
/*      */   {
/*   52 */     super("Voice");
/*   53 */     setPluginType("Voice");
/*   54 */     this.serverVersion = ("2.5.0 " + ServerVersion.getBuildNumber());
/*      */ 
/*   56 */     Log.info("VoicePlugin (server version " + this.serverVersion + ") starting up");
/*   57 */     this.loginStatusEventReceivers = new HashSet();
/*   58 */     this.countLogger = new CountLogger("VoiceMsg", 5000, 2, true);
/*   59 */     String log_voice_counters = Engine.getProperty("atavism.log_voice_counters");
/*      */ 
/*   61 */     if ((log_voice_counters == null) || (log_voice_counters.equals("false"))) {
/*   62 */       this.countLogger.setLogging(false);
/*      */     }
/*      */ 
/*   65 */     countPacketsReceived = this.countLogger.addCounter("pkts received");
/*   66 */     countDataFramesReceived = this.countLogger.addCounter("data frames recvd");
/*   67 */     countAllocateVoiceReceived = this.countLogger.addCounter("alloc voice recvd");
/*   68 */     countDeallocateVoiceReceived = this.countLogger.addCounter("dealloc voice recvd");
/*   69 */     countSeqNumGaps = this.countLogger.addCounter("seqnum gaps");
/*   70 */     countPacketsIgnored = this.countLogger.addCounter("pkts ignored");
/*      */ 
/*   72 */     countPacketsSent = this.countLogger.addCounter("pkts sent");
/*   73 */     countDataFramesSent = this.countLogger.addCounter("data frames sent");
/*   74 */     countAllocateVoiceSent = this.countLogger.addCounter("alloc voice sent");
/*   75 */     countDeallocateVoiceSent = this.countLogger.addCounter("dealloc voice sent");
/*      */ 
/*   77 */     countSendLoginStatus = this.countLogger.addCounter("login status");
/*      */ 
/*   79 */     handleVoiceProperties();
/*      */ 
/*   81 */     if (runHistograms) {
/*   82 */       processPacketHistogram = new TimeHistogram("Process Packet");
/*   83 */       dataSendHistogram = new TimeHistogram("Process Data Frames");
/*   84 */       voiceAllocHistogram = new TimeHistogram("Process Allocate");
/*   85 */       voiceDeallocHistogram = new TimeHistogram("Process Deallocate");
/*      */     }
/*      */ 
/*   88 */     instance = this;
/*   89 */     this.countLogger.start();
/*   90 */     this.updater = new Updater();
/*   91 */     Thread updaterThread = new Thread(this.updater);
/*   92 */     updaterThread.start();
/*      */   }
/*      */ 
/*      */   private void handleVoiceProperties()
/*      */   {
/*  100 */     OID precreatedPositionalOid = parseOIDOrNull(Engine.getProperty("atavism.precreated_positional_voice_group"));
/*  101 */     if (precreatedPositionalOid != null)
/*  102 */       this.conMgr.addGroup(precreatedPositionalOid, new PositionalVoiceGroup(precreatedPositionalOid, null, this, maxVoiceChannels, audibleRadius, hystericalMargin));
/*  103 */     OID precreatedNonpositionalOid = parseOIDOrNull(Engine.getProperty("atavism.precreated_nonpositional_voice_group"));
/*  104 */     if (precreatedNonpositionalOid != null)
/*  105 */       this.conMgr.addGroup(precreatedNonpositionalOid, new NonpositionalVoiceGroup(precreatedNonpositionalOid, null, this, maxVoiceChannels));
/*  106 */     Boolean autoCreateGroups = Boolean.valueOf(Engine.getProperty("atavism.autocreate_referenced_voice_groups"));
/*  107 */     if ((autoCreateGroups != null) && (autoCreateGroups.booleanValue()))
/*  108 */       createGroupWhenReferenced = true;
/*  109 */     Boolean voiceBots = Boolean.valueOf(Engine.getProperty("atavism.voice_bots"));
/*  110 */     if ((voiceBots != null) && (voiceBots.booleanValue()))
/*  111 */       allowVoiceBots = true;
/*  112 */     Boolean histograms = Boolean.valueOf(Engine.getProperty("atavism.voice_packet_histograms"));
/*  113 */     if ((histograms != null) && (histograms.booleanValue()))
/*  114 */       runHistograms = true;
/*  115 */     Boolean checkAuthTokenValue = Boolean.valueOf(Engine.getProperty("atavism.check_auth_token"));
/*  116 */     if (checkAuthTokenValue != null)
/*  117 */       checkAuthToken = checkAuthTokenValue.booleanValue();
/*      */   }
/*      */ 
/*      */   private OID parseOIDOrNull(String s)
/*      */   {
/*      */     try {
/*  123 */       return OID.fromLong(Long.parseLong(s));
/*      */     } catch (Exception e) {
/*      */     }
/*  126 */     return null;
/*      */   }
/*      */ 
/*      */   public static VoicePlugin getInstance()
/*      */   {
/*  134 */     return instance;
/*      */   }
/*      */ 
/*      */   public void onActivate()
/*      */   {
/*  142 */     this.voicePort = Integer.valueOf(Integer.parseInt(Engine.getProperty("atavism.voiceport")));
/*  143 */     String s = Engine.getProperty("atavism.record_voices");
/*  144 */     if ((s != null) && (s.length() > 3))
/*  145 */       this.recordVoices = Boolean.parseBoolean(s);
/*  146 */     if (allowVoiceBots) {
/*  147 */       getHookManager().addHook(LoginMessage.MSG_TYPE_LOGIN, new LoginHook());
/*      */     }
/*  149 */     getHookManager().addHook(VoiceClient.MSG_TYPE_VOICECLIENT, new VoiceClientMessageHook());
/*      */ 
/*  151 */     getHookManager().addHook(InstanceClient.MSG_TYPE_INSTANCE_DELETED, new InstanceUnloadedHook());
/*      */ 
/*  153 */     getHookManager().addHook(InstanceClient.MSG_TYPE_INSTANCE_UNLOADED, new InstanceUnloadedHook());
/*      */ 
/*  155 */     getHookManager().addHook(Management.MSG_TYPE_GET_PLUGIN_STATUS, new GetPluginStatusHook());
/*      */ 
/*  158 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_PERCEPTION, new PerceptionHook());
/*      */ 
/*  160 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_UPDATEWNODE, new UpdateWorldNodeHook());
/*      */ 
/*  162 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_SPAWNED, new SpawnedHook());
/*      */ 
/*  164 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_DESPAWNED, new DespawnedHook());
/*      */ 
/*  166 */     getHookManager().addHook(ProxyPlugin.MSG_TYPE_RELAY_UPDATE_PLAYER_IGNORE_LIST, new RelayUpdatePlayerIgnoreListHook());
/*      */ 
/*  169 */     MessageTypeFilter filter = new MessageTypeFilter();
/*  170 */     if (allowVoiceBots)
/*  171 */       filter.addType(LoginMessage.MSG_TYPE_LOGIN);
/*  172 */     filter.addType(VoiceClient.MSG_TYPE_VOICECLIENT);
/*  173 */     filter.addType(InstanceClient.MSG_TYPE_INSTANCE_DELETED);
/*  174 */     filter.addType(InstanceClient.MSG_TYPE_INSTANCE_UNLOADED);
/*  175 */     filter.addType(Management.MSG_TYPE_GET_PLUGIN_STATUS);
/*  176 */     Engine.getAgent().createSubscription(filter, this, 8);
/*      */ 
/*  180 */     this.clientTCPMessageIO = ClientTCPMessageIO.setup(2, this.voicePort, this, this);
/*  181 */     this.clientTCPMessageIO.start("VoiceIO");
/*      */ 
/*  183 */     Engine.registerStatusReportingPlugin(this);
/*      */ 
/*  188 */     this.perceptionFilter = new PerceptionFilter();
/*  189 */     this.perceptionFilter.addType(WorldManagerClient.MSG_TYPE_PERCEPTION);
/*  190 */     this.perceptionFilter.addType(WorldManagerClient.MSG_TYPE_UPDATEWNODE);
/*  191 */     this.perceptionFilter.addType(ProxyPlugin.MSG_TYPE_RELAY_UPDATE_PLAYER_IGNORE_LIST);
/*  192 */     this.perceptionFilter.setMatchAllSubjects(false);
/*  193 */     List subjectTypes = new ArrayList(1);
/*  194 */     subjectTypes.add(ObjectTypes.player);
/*  195 */     this.perceptionFilter.setSubjectObjectTypes(subjectTypes);
/*  196 */     PerceptionTrigger perceptionTrigger = new PerceptionTrigger();
/*  197 */     this.perceptionSubId = Engine.getAgent().createSubscription(this.perceptionFilter, this, 0, perceptionTrigger);
/*      */ 
/*  201 */     PopulationFilter populationFilter = new PopulationFilter(ObjectTypes.player);
/*      */ 
/*  203 */     Engine.getAgent().createSubscription(populationFilter, this);
/*  204 */     if (Engine.getInterpolator() == null)
/*  205 */       Engine.setInterpolator(new BasicInterpolator());
/*      */   }
/*      */ 
/*      */   public void acceptConnection(ClientConnection con)
/*      */   {
/*  213 */     con.setAssociation(new VoiceConnection(con));
/*  214 */     Log.info("VoicePlugin: CONNECT remote=" + con.IPAndPort());
/*      */   }
/*      */ 
/*      */   protected void sendLoginStatusToReceivers(OID playerOid, boolean login)
/*      */   {
/*  497 */     for (VoiceConnection playerCon : this.loginStatusEventReceivers)
/*  498 */       sendLoginStatus(playerCon, playerOid, login);
/*      */   }
/*      */ 
/*      */   protected GroupMember getPlayerMember(OID playerOid)
/*      */   {
/*  508 */     VoiceConnection con = this.conMgr.getPlayerCon(playerOid);
/*  509 */     if ((con == null) || (con.group == null)) {
/*  510 */       Log.error("VoicePlugin.getPlayerMember: For " + playerOid + ", con " + con + " group field is null!");
/*  511 */       return null;
/*      */     }
/*      */ 
/*  514 */     return con.groupMember;
/*      */   }
/*      */ 
/*      */   public void processPacket(ClientConnection con, AOByteBuffer buf)
/*      */   {
/*  525 */     byte opcode = 0;
/*  526 */     long startTime = System.nanoTime();
/*  527 */     this.lock.lock();
/*      */     try {
/*  529 */       countPacketsReceived.add();
/*  530 */       short seqNum = buf.getShort();
/*  531 */       opcode = buf.getByte();
/*  532 */       byte micVoiceNumber = buf.getByte();
/*  533 */       VoiceConnection speaker = getConnectionData(con);
/*  534 */       if (speaker == null) { Log.error("VoicePlugin.processPacket: Could not find VoiceConnection for con " + con + ", micVoiceNumber " + micVoiceNumber + ", opcode " + opcodeString(opcode));
/*      */         return;
/*      */       }
/*  539 */       if (incSeqNum(speaker.seqNum) != seqNum)
/*  540 */         countSeqNumGaps.add();
/*  541 */       speaker.seqNum = seqNum;
/*      */ 
/*  543 */       if (speaker.authToken == null) {
/*  544 */         if (opcode != 1) {
/*  545 */           countPacketsIgnored.add();
/*  546 */           Log.error("VoicePlugin.processPacket: Have not yet received authentication token, but packet opcode is " + opcodeString(opcode));
/*      */         }
/*      */         else {
/*  549 */           processAuthenticationPacket(speaker, buf);
/*      */         }
/*      */       } else {
/*  552 */         speaker.micVoiceNumber = micVoiceNumber;
/*  553 */         OID oid = speaker.playerOid;
/*  554 */         if (Log.loggingNet) {
/*  555 */           Log.net("VoicePlugin.processPacket: micVoiceNumber " + micVoiceNumber + ", opcode " + opcodeString(opcode) + ", seqNum " + seqNum + ", oid " + oid);
/*      */         }
/*  557 */         else if ((Log.loggingDebug) && (opcode != 6) && (opcode != 7)) {
/*  558 */           Log.debug("VoicePlugin.processPacket: micVoiceNumber " + micVoiceNumber + ", opcode " + opcodeString(opcode) + ", seqNum " + seqNum + ", oid " + oid);
/*      */         }
/*  560 */         VoiceGroup group = speaker.group;
/*  561 */         if (group == null) {
/*  562 */           Log.error("VoicePlugin.processPacket: For speaker " + oid + ", connection " + con + ", group is null");
/*      */           return;
/*      */         }
/*      */         int dataSize;
/*  566 */         switch (opcode) {
/*      */         case 1:
/*  568 */           processAuthenticationPacket(speaker, buf);
/*  569 */           break;
/*      */         case 2:
/*  571 */           if ((this.recordVoices) && (speaker.recordSpeexStream == null))
/*  572 */             speaker.recordSpeexStream = openSpeexVoiceFile(oid);
/*  573 */           countAllocateVoiceReceived.add();
/*  574 */           group.setMemberSpeaking(oid, true);
/*  575 */           break;
/*      */         case 3:
/*  577 */           Log.error("VoicePlugin.processPacket: shouldn't get AllocatePositionalCodec message!");
/*  578 */           break;
/*      */         case 4:
/*  580 */           group.setMemberSpeaking(oid, true);
/*  581 */           break;
/*      */         case 5:
/*  583 */           if ((this.recordVoices) && (speaker.recordSpeexStream == null)) {
/*      */             try {
/*  585 */               speaker.recordSpeexStream.close();
/*      */             }
/*      */             catch (IOException e) {
/*  588 */               Log.exception("Error closing Speex stream for voice " + speaker.playerOid, e);
/*      */             }
/*  590 */             speaker.recordSpeexStream = null;
/*      */           }
/*  592 */           countDeallocateVoiceReceived.add();
/*  593 */           group.setMemberSpeaking(oid, false);
/*  594 */           break;
/*      */         case 6:
/*  596 */           dataSize = buf.limit();
/*  597 */           if (speaker.recordSpeexStream != null)
/*  598 */             writeSpeexData(speaker.recordSpeexStream, buf.array(), 4, dataSize - 4);
/*  599 */           countDataFramesReceived.add();
/*  600 */           if (group.isMemberSpeaking(speaker.playerOid))
/*  601 */             group.sendVoiceFrameToListeners(oid, buf, 6, dataSize);
/*      */           else {
/*  603 */             Log.error("VoicePlugin.processPacket: got data pkt for speaker " + speaker.playerOid + ", but speaker.currentSpeaker false.  micVoiceNumber " + micVoiceNumber + ", opcode " + opcodeString(opcode) + ", seqNum " + seqNum + DebugUtils.byteArrayToHexString(buf));
/*      */           }
/*  605 */           break;
/*      */         case 7:
/*  607 */           dataSize = buf.limit();
/*  608 */           byte dataFrameCount = buf.getByte();
/*  609 */           if (speaker.recordSpeexStream != null) {
/*  610 */             byte[] array = buf.array();
/*  611 */             int currentIndex = 5;
/*  612 */             for (int i = 0; i < dataFrameCount; i++) {
/*  613 */               byte frameLength = array[currentIndex];
/*  614 */               currentIndex++;
/*  615 */               writeSpeexData(speaker.recordSpeexStream, array, currentIndex, frameLength);
/*  616 */               currentIndex += frameLength;
/*      */             }
/*  618 */             if (currentIndex != dataSize) {
/*  619 */               Log.error("VoicePlugin.processPacket: While recording agg data packet: currentIndex " + currentIndex + " != dataSize " + dataSize);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  625 */           if (group.isMemberSpeaking(speaker.playerOid))
/*  626 */             group.sendVoiceFrameToListeners(oid, buf, 7, dataSize);
/*      */           else {
/*  628 */             Log.error("VoicePlugin.processPacket: got data pkt for speaker " + speaker.playerOid + ", but speaker.currentSpeaker false.  micVoiceNumber " + micVoiceNumber + ", opcode " + opcodeString(opcode) + ", seqNum " + seqNum + DebugUtils.byteArrayToHexString(buf));
/*      */           }
/*  630 */           countDataFramesReceived.add(dataFrameCount);
/*  631 */           speaker.seqNum = incSeqNum(speaker.seqNum, dataFrameCount - 1);
/*  632 */           break;
/*      */         case 9:
/*  634 */           processIgnoreListChangeMessage(speaker, buf);
/*      */         case 8:
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  640 */       Log.exception("VoicePlugin.processPacket: For packet " + DebugUtils.byteArrayToHexString(buf), e);
/*      */     }
/*      */     finally {
/*  643 */       this.lock.unlock();
/*      */     }
/*  645 */     if (runHistograms) {
/*  646 */       long packetTime = System.nanoTime() - startTime;
/*  647 */       switch (opcode) {
/*      */       case 2:
/*  649 */         voiceAllocHistogram.addTime(packetTime);
/*  650 */         break;
/*      */       case 5:
/*  652 */         voiceDeallocHistogram.addTime(packetTime);
/*  653 */         break;
/*      */       case 6:
/*      */       case 7:
/*  656 */         dataSendHistogram.addTime(packetTime);
/*      */       case 3:
/*      */       case 4:
/*  659 */       }processPacketHistogram.addTime(packetTime);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void writeSpeexData(BufferedOutputStream recordSpeexStream, byte[] buf, int startIndex, int byteCount)
/*      */   {
/*      */     try
/*      */     {
/*  673 */       recordSpeexStream.write(buf, startIndex, byteCount);
/*      */     }
/*      */     catch (IOException e) {
/*  676 */       Log.exception("VoicePlugin.writeVoiceData: Exception writing voice data", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void processAuthenticationPacket(VoiceConnection playerCon, AOByteBuffer buf)
/*      */   {
/*  690 */     OID playerOid = buf.getOID();
/*  691 */     OID groupOid = buf.getOID();
/*  692 */     String encodedToken = buf.getString();
/*  693 */     byte listenToYourselfByte = buf.getByte();
/*  694 */     boolean listenToYourself = listenToYourselfByte != 0;
/*  695 */     if (Log.loggingDebug) {
/*  696 */       Log.debug("VoicePlugin.processAuthenticationPacket: Received auth packet; playerOid " + playerOid + ", groupOid " + groupOid + ", authToken " + encodedToken + ", listenToYourself " + listenToYourself);
/*      */     }
/*      */ 
/*  703 */     VoiceConnection previousPlayerCon = this.conMgr.getPlayerCon(playerOid);
/*  704 */     if ((previousPlayerCon != null) && (previousPlayerCon != playerCon)) {
/*  705 */       expungeVoiceClient(playerOid, previousPlayerCon);
/*      */     }
/*      */ 
/*  709 */     if (playerCon.group != null) {
/*  710 */       removePlayerFromGroup(playerCon);
/*      */     }
/*  712 */     SecureToken authToken = SecureTokenManager.getInstance().importToken(Base64.decode(encodedToken));
/*  713 */     if ((checkAuthToken) && ((authToken.getValid() != true) || (!playerOid.equals((OID)authToken.getProperty("player_oid"))))) {
/*  714 */       Log.error("VoicePlugin.processAuthenticationPacket: token rejected for playerOid=" + playerOid + " token=" + authToken);
/*      */ 
/*  716 */       playerCon.con.close();
/*  717 */       return;
/*      */     }
/*      */ 
/*  723 */     if ((allowVoiceBots) && (playerOid == null) && (groupOid == null)) {
/*  724 */       this.loginStatusEventReceivers.add(playerCon);
/*      */     }
/*      */     else {
/*  727 */       VoiceGroup group = findVoiceGroup(groupOid);
/*  728 */       if (group != null) {
/*  729 */         if (group.addMemberAllowed(playerOid)) {
/*  730 */           playerCon.groupOid = groupOid;
/*  731 */           playerCon.group = group;
/*  732 */           playerCon.authToken = authToken;
/*  733 */           playerCon.playerOid = playerOid;
/*  734 */           playerCon.listenToYourself = listenToYourself;
/*  735 */           this.conMgr.setPlayerCon(playerOid, playerCon);
/*  736 */           playerCon.groupMember = group.addMember(playerOid, playerCon);
/*  737 */           initializeIgnoreList(playerCon);
/*  738 */           this.conMgr.setPlayerGroup(playerOid, group);
/*  739 */           group.setListener(playerOid, true);
/*  740 */           if (group.isPositional()) {
/*  741 */             PositionalGroupMember member = (PositionalGroupMember)playerCon.groupMember;
/*  742 */             if (member.wnode == null)
/*  743 */               trackNewPerceiver(member);
/*      */           }
/*  745 */           Log.info("VoicePlugin: VOICE_AUTH remote=" + playerCon.con.IPAndPort() + " playerOid=" + playerOid + " groupOid=" + groupOid);
/*      */         }
/*      */         else
/*      */         {
/*  750 */           Log.error("VoicePlugin.processAuthenticationPacket: Player " + playerOid + " with authToken '" + encodedToken + "' was denied access to group " + groupOid + " - - auth packet ignored!");
/*      */         }
/*      */       }
/*  753 */       else Log.error("VoicePlugin.processAuthenticationPacket: Could not find group " + groupOid + " for playerOid " + playerOid + " - - auth packet ignored!");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initializeIgnoreList(VoiceConnection playerCon)
/*      */   {
/*  759 */     OID playerOid = playerCon.playerOid;
/*  760 */     TargetMessage msg = new TargetMessage(ProxyPlugin.MSG_TYPE_PLAYER_IGNORE_LIST_REQ, playerOid, playerOid);
/*      */     try {
/*  762 */       List ignoreList = (List)Engine.getAgent().sendRPCReturnObject(msg);
/*  763 */       playerCon.groupMember.initializeIgnoredSpeakers(ignoreList);
/*      */     }
/*      */     catch (Exception NoRecipientsException) {
/*  766 */       Log.error("VoicePlugin.initializeIgnoreList: Could not retrieve ignore list for player " + playerCon.playerOid);
/*  767 */       playerCon.groupMember.initializeIgnoredSpeakers(new LinkedList());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void trackNewPerceiver(PositionalGroupMember member)
/*      */   {
/*  777 */     OID memberOid = member.getMemberOid();
/*  778 */     WorldManagerClient.ObjectInfo info = WorldManagerClient.getObjectInfo(memberOid);
/*  779 */     member.wnode = new InterpolatedWorldNode(info);
/*  780 */     PositionalVoiceGroup pGroup = (PositionalVoiceGroup)member.getGroup();
/*  781 */     pGroup.addTrackedPerceiver(member, info.instanceOid);
/*  782 */     addToPerceptionFilter(memberOid);
/*      */   }
/*      */ 
/*      */   protected void processIgnoreListChangeMessage(VoiceConnection playerCon, AOByteBuffer buf)
/*      */   {
/*  811 */     GroupMember member = playerCon.group.isMember(playerCon.playerOid);
/*  812 */     if (member == null) {
/*  813 */       Log.error("VoicePlugin.processBlacklistChangeMessage: player " + playerCon.playerOid + " is not associated with a group member!");
/*  814 */       return;
/*      */     }
/*  816 */     int count = buf.getShort();
/*  817 */     List addToIgnored = new LinkedList();
/*  818 */     List removeFromIgnored = new LinkedList();
/*  819 */     for (int i = 0; i < count; i++) {
/*  820 */       byte which = buf.getByte();
/*  821 */       OID oid = buf.getOID();
/*  822 */       if (which != 0)
/*  823 */         addToIgnored.add(oid);
/*      */       else
/*  825 */         removeFromIgnored.add(oid);
/*      */     }
/*  827 */     member.addIgnoredSpeakerOids(addToIgnored);
/*  828 */     member.removeIgnoredSpeakerOids(removeFromIgnored);
/*      */   }
/*      */ 
/*      */   protected void addToPerceptionFilter(OID playerOid)
/*      */   {
/*  838 */     if (Log.loggingDebug)
/*  839 */       Log.debug("VoicePlugin.addToPerceptionFilter: Adding playerOid " + playerOid);
/*  840 */     if (this.perceptionFilter.addTarget(playerOid)) {
/*  841 */       FilterUpdate filterUpdate = new FilterUpdate(1);
/*  842 */       filterUpdate.addFieldValue(1, playerOid);
/*  843 */       Engine.getAgent().applyFilterUpdate(this.perceptionSubId, filterUpdate);
/*      */     }
/*  846 */     else if (Log.loggingDebug) {
/*  847 */       Log.debug("VoicePlugin.addToPerceptionFilter: PlayerOid " + playerOid + " was already in the filter");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void removeFromPerceptionFilter(OID playerOid)
/*      */   {
/*  858 */     if (this.perceptionFilter.hasTarget(playerOid)) {
/*  859 */       this.perceptionFilter.removeTarget(playerOid);
/*  860 */       FilterUpdate filterUpdate = new FilterUpdate(1);
/*  861 */       filterUpdate.removeFieldValue(1, playerOid);
/*  862 */       Engine.getAgent().applyFilterUpdate(this.perceptionSubId, filterUpdate);
/*      */     }
/*  865 */     else if (Log.loggingDebug) {
/*  866 */       Log.debug("VoicePlugin.removeFromPerceptionFilter: PlayerOid " + playerOid + " was not in the filter");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void removePlayerFromGroup(VoiceConnection playerCon)
/*      */   {
/*  874 */     if (playerCon.group == null) {
/*  875 */       Log.error("VoicePlugin.removePlayerFromGroup: playerCon " + playerCon + " group is null!");
/*      */     } else {
/*  877 */       playerCon.group.removeMember(playerCon.playerOid);
/*  878 */       playerCon.group = null;
/*  879 */       playerCon.groupOid = null;
/*  880 */       playerCon.authToken = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected VoiceGroup findVoiceGroup(OID groupOid)
/*      */   {
/*  890 */     VoiceGroup group = this.conMgr.getGroup(groupOid);
/*  891 */     if (group == null) {
/*  892 */       if (createGroupWhenReferenced) {
/*  893 */         group = new NonpositionalVoiceGroup(groupOid, null, this, maxVoiceChannels);
/*  894 */         this.conMgr.addGroup(groupOid, group);
/*      */       }
/*      */       else {
/*  897 */         return null;
/*      */       }
/*      */     }
/*  900 */     return group;
/*      */   }
/*      */ 
/*      */   public void addGroup(OID groupOid, VoiceGroup group)
/*      */   {
/*  909 */     this.conMgr.addGroup(groupOid, group);
/*      */   }
/*      */ 
/*      */   public void removeGroup(OID groupOid)
/*      */   {
/*  917 */     List playerOids = this.conMgr.groupPlayers(groupOid);
/*  918 */     for (OID playerOid : playerOids)
/*  919 */       expungeVoiceClient(playerOid);
/*      */   }
/*      */ 
/*      */   private void sendPacketToListener(VoiceConnection listener, AOByteBuffer buf)
/*      */   {
/*  928 */     countPacketsSent.add();
/*  929 */     listener.con.send(buf);
/*      */   }
/*      */ 
/*      */   public void sendAllocateVoice(VoiceConnection speaker, VoiceConnection listener, byte voiceNumber, boolean positional)
/*      */   {
/*  944 */     sendAllocateVoice(speaker, listener, voiceNumber, positional ? 3 : 2);
/*      */   }
/*      */ 
/*      */   public void sendAllocateVoice(VoiceConnection speaker, VoiceConnection listener, byte voiceNumber, byte opcode)
/*      */   {
/*  961 */     short msgSize = (short)voiceMsgSize[opcode];
/*  962 */     AOByteBuffer buf = new AOByteBuffer(msgSize);
/*  963 */     buf.putShort(speaker.seqNum);
/*  964 */     buf.putByte(opcode);
/*  965 */     buf.putByte(voiceNumber);
/*  966 */     buf.putOID(speaker.playerOid);
/*  967 */     if (Log.loggingDebug) {
/*  968 */       Log.debug("VoicePlugin.sendAllocateVoice: speaker " + speaker + ", listener " + listener + ", voiceNumber " + voiceNumber + ", opcode " + opcodeString(opcode) + ", seqNum " + speaker.seqNum + ", oid " + speaker.playerOid + " " + DebugUtils.byteArrayToHexString(buf));
/*      */     }
/*      */ 
/*  971 */     countAllocateVoiceSent.add();
/*  972 */     sendPacketToListener(listener, buf);
/*      */   }
/*      */ 
/*      */   public void sendDeallocateVoice(VoiceConnection speaker, VoiceConnection listener, byte voiceNumber)
/*      */   {
/*  984 */     AOByteBuffer buf = new AOByteBuffer(4);
/*  985 */     buf.putShort(speaker.seqNum);
/*  986 */     buf.putByte(5);
/*  987 */     buf.putByte(voiceNumber);
/*  988 */     if (Log.loggingDebug) {
/*  989 */       Log.debug("VoicePlugin.sendDeallocateVoice: speaker " + speaker + ", listener " + listener + ", voiceNumber " + voiceNumber + ", seqNum " + speaker.seqNum + ", oid " + speaker.playerOid + " " + DebugUtils.byteArrayToHexString(buf));
/*      */     }
/*      */ 
/*  992 */     countDeallocateVoiceSent.add();
/*  993 */     sendPacketToListener(listener, buf);
/*      */   }
/*      */ 
/*      */   public void sendVoiceFrame(VoiceConnection speaker, VoiceConnection listener, byte opcode, byte voiceNumber, AOByteBuffer sourceBuf, short pktLength)
/*      */   {
/* 1010 */     if (Log.loggingNet) {
/* 1011 */       Log.net("VoicePlugin.sendVoiceFrame: length " + pktLength + ", speaker " + speaker + ", listener " + listener + ", packet " + DebugUtils.byteArrayToHexString(sourceBuf));
/*      */     }
/* 1013 */     AOByteBuffer buf = new AOByteBuffer(pktLength);
/* 1014 */     buf.putShort(speaker.seqNum);
/* 1015 */     buf.putByte(opcode);
/* 1016 */     buf.putByte(voiceNumber);
/* 1017 */     buf.putBytes(sourceBuf.array(), 4, pktLength - 4);
/* 1018 */     countDataFramesSent.add();
/* 1019 */     sendPacketToListener(listener, buf);
/*      */   }
/*      */ 
/*      */   public void sendLoginStatus(VoiceConnection receiver, OID playerOid, boolean login)
/*      */   {
/* 1033 */     countSendLoginStatus.add();
/* 1034 */     short msgSize = (short)voiceMsgSize[8];
/* 1035 */     AOByteBuffer buf = new AOByteBuffer(msgSize);
/* 1036 */     this.loginStatusSeqNum = incSeqNum(this.loginStatusSeqNum);
/* 1037 */     buf.putShort(this.loginStatusSeqNum);
/* 1038 */     buf.putByte(8);
/* 1039 */     buf.putByte((byte)(login ? 1 : 0));
/* 1040 */     buf.putOID(playerOid);
/* 1041 */     if (Log.loggingDebug) {
/* 1042 */       Log.debug("VoicePlugin.sendLoginStatus: receiver " + receiver + ", opcode " + opcodeString(8) + ", seqNum " + this.loginStatusSeqNum + " " + DebugUtils.byteArrayToHexString(buf));
/*      */     }
/* 1044 */     receiver.con.send(buf);
/*      */   }
/*      */ 
/*      */   public void sendExtensionMessage(WorldManagerClient.ExtensionMessage msg)
/*      */   {
/* 1052 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   protected BufferedOutputStream openSpeexVoiceFile(OID oid)
/*      */   {
/*      */     try
/*      */     {
/* 1064 */       FileOutputStream fileOutputStream = new FileOutputStream("Voice-" + oid + ".speex");
/* 1065 */       BufferedOutputStream bufferedStream = new BufferedOutputStream(fileOutputStream);
/* 1066 */       return bufferedStream;
/*      */     }
/*      */     catch (Exception e) {
/* 1069 */       Log.exception("VoicePlugin.openSpeexVoiceFile: Exception opening file for oid " + oid, e);
/* 1070 */     }return null;
/*      */   }
/*      */ 
/*      */   public VoiceConnection getConnectionData(ClientConnection con)
/*      */   {
/* 1081 */     VoiceConnection data = (VoiceConnection)con.getAssociation();
/* 1082 */     if (data == null) {
/* 1083 */       String s = "getConnectionData: Could not find connection " + formatCon(con);
/* 1084 */       Log.dumpStack(s);
/* 1085 */       return null;
/*      */     }
/*      */ 
/* 1088 */     return data;
/*      */   }
/*      */ 
/*      */   public String formatCon(ClientConnection con)
/*      */   {
/* 1097 */     return con.toString();
/*      */   }
/*      */ 
/*      */   public void connectionReset(ClientConnection con)
/*      */   {
/* 1107 */     VoiceConnection data = getConnectionData(con);
/* 1108 */     if (data == null) {
/* 1109 */       Log.error("VoicePlugin.connectionReset: Could not find connection " + con);
/*      */     } else {
/* 1111 */       OID playerOid = data.playerOid;
/* 1112 */       Log.info("VoicePlugin: DISCONNECT remote=" + data.con.IPAndPort() + " playerOid=" + playerOid);
/* 1113 */       if (data.recordSpeexStream != null) {
/*      */         try {
/* 1115 */           data.recordSpeexStream.close();
/*      */         }
/*      */         catch (IOException e) {
/* 1118 */           Log.exception("VoicePlugin.connectionReset: Exception closing record stream", e);
/*      */         }
/* 1120 */         data.recordSpeexStream = null;
/*      */       }
/* 1122 */       expungeVoiceClient(playerOid, data);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void expungeVoiceClient(OID playerOid)
/*      */   {
/* 1132 */     expungeVoiceClient(playerOid, this.conMgr.getPlayerCon(playerOid));
/*      */   }
/*      */ 
/*      */   protected void expungeVoiceClient(OID playerOid, VoiceConnection con)
/*      */   {
/* 1143 */     if ((con.groupMember != null) && (con.groupMember.getExpunged()))
/* 1144 */       return;
/* 1145 */     VoiceGroup group = con.group;
/* 1146 */     if (group != null) {
/* 1147 */       con.group = null;
/* 1148 */       if (group.isPositional()) {
/* 1149 */         PositionalVoiceGroup pGroup = (PositionalVoiceGroup)group;
/* 1150 */         pGroup.removeTrackedPerceiver(playerOid);
/* 1151 */         if (con.groupMember != null)
/* 1152 */           removeFromPerceptionFilter(playerOid);
/* 1153 */         else if (Log.loggingDebug)
/* 1154 */           Log.debug("VoicePlugin.expungeVoiceClient: For playerOid " + playerOid + ", con.groupMember is null");
/*      */       }
/* 1156 */       GroupMember member = con.groupMember;
/* 1157 */       if (member == null) {
/* 1158 */         Log.info("VoicePlugin.expungeVoiceClient: For playerOid " + playerOid + ", could not find member in group " + group);
/*      */       } else {
/* 1160 */         member.setExpunged();
/* 1161 */         group.removeMember(playerOid);
/*      */       }
/*      */     }
/* 1164 */     con.groupMember = null;
/* 1165 */     this.conMgr.removePlayer(playerOid);
/* 1166 */     if (Log.loggingDebug)
/* 1167 */       Log.debug("VoicePlugin.expungeVoiceClient: PlayerOid " + playerOid + " expunged");
/*      */   }
/*      */ 
/*      */   public static short incSeqNum(short original)
/*      */   {
/* 1176 */     if (original == 32767) {
/* 1177 */       return -32768;
/*      */     }
/* 1179 */     return (short)(original + 1);
/*      */   }
/*      */ 
/*      */   public static short incSeqNum(short original, int byWhat)
/*      */   {
/* 1189 */     int sum = byWhat + original;
/* 1190 */     if (sum >= 32767) {
/* 1191 */       return (short)(-32768 + (sum - 32767));
/*      */     }
/* 1193 */     return (short)(original + byWhat);
/*      */   }
/*      */ 
/*      */   public static int encodedFrameSizeForMode(int mode, boolean wideBand)
/*      */   {
/* 1204 */     if (wideBand) {
/* 1205 */       if ((mode < 0) || (mode > 4)) {
/* 1206 */         Log.error("VoicePlugin.encodedFrameSizeForMode: wide-band mode " + mode + " is outside the range of 0-4");
/*      */ 
/* 1208 */         mode = 3;
/*      */       }
/* 1210 */       return speexNarrowBandFrameSize[mode] + speexWideBandFrameSize[mode];
/*      */     }
/*      */ 
/* 1213 */     if ((mode < 0) || (mode > 8)) {
/* 1214 */       Log.error("VoicePlugin.encodedFrameSizeForMode: narrow-band mode " + mode + " is outside the range of 0-8");
/*      */ 
/* 1216 */       mode = 5;
/*      */     }
/* 1218 */     return speexWideBandFrameSize[mode];
/*      */   }
/*      */ 
/*      */   public static int encodedFrameSizeFromFirstByte(byte b)
/*      */   {
/* 1229 */     if ((b & 0x80) != 0) {
/* 1230 */       return encodedFrameSizeForMode((b & 0x70) >> 4, true);
/*      */     }
/* 1232 */     return encodedFrameSizeForMode((b & 0x78) >> 3, true);
/*      */   }
/*      */ 
/*      */   public static String opcodeString(byte opcode)
/*      */   {
/*      */     String name;
/*      */     String name;
/* 1242 */     if ((opcode >= 0) && (opcode <= 9)) {
/* 1243 */       name = opcodeNames[opcode];
/*      */     } else {
/* 1245 */       Log.error("VoicePlugin.opcodeString: opcode " + opcode + " is out of range!");
/* 1246 */       name = "????????";
/*      */     }
/* 1248 */     return name + "(" + opcode + ")";
/*      */   }
/*      */ 
/*      */   class Updater
/*      */     implements Runnable
/*      */   {
/*      */     Updater()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1534 */       while (VoicePlugin.this.running) {
/*      */         try {
/* 1536 */           update();
/*      */         } catch (AORuntimeException e) {
/* 1538 */           Log.exception("ProximityTracker.Updater.run caught AORuntimeException", e);
/*      */         } catch (Exception e) {
/* 1540 */           Log.exception("ProximityTracker.Updater.run caught exception", e);
/*      */         }
/*      */         try
/*      */         {
/* 1544 */           Thread.sleep(1000L);
/*      */         } catch (InterruptedException e) {
/* 1546 */           Log.warn("Updater: " + e);
/* 1547 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void update()
/*      */     {
/* 1561 */       List pMembers = VoicePlugin.this.conMgr.getAllPositionalGroupMembers();
/*      */ 
/* 1569 */       for (GroupMember member : pMembers) {
/* 1570 */         PositionalGroupMember pMember = (PositionalGroupMember)member;
/* 1571 */         if (pMember.wnode == null)
/*      */           continue;
/* 1573 */         pMember.previousLoc = pMember.lastLoc;
/*      */ 
/* 1575 */         pMember.lastLoc = pMember.wnode.getLoc();
/*      */       }
/*      */ 
/* 1582 */       for (GroupMember member : pMembers) {
/* 1583 */         pMember = (PositionalGroupMember)member;
/* 1584 */         if (pMember.wnode == null)
/*      */         {
/*      */           continue;
/*      */         }
/* 1588 */         if (Log.loggingDebug)
/* 1589 */           Log.debug("Updater.update: perceiverOid " + pMember.getMemberOid() + " previousLoc " + pMember.previousLoc + ", lastLoc " + pMember.lastLoc);
/* 1590 */         if ((pMember.previousLoc != null) && (Point.distanceToSquared(pMember.previousLoc, pMember.lastLoc) < 100.0F)) {
/*      */           continue;
/*      */         }
/* 1593 */         ArrayList perceivedOids = new ArrayList(pMember.perceivedOids);
/* 1594 */         if (Log.loggingDebug)
/* 1595 */           Log.debug("Updater.update: perceiverOid " + pMember.getMemberOid() + " has " + perceivedOids.size() + " perceivedOids");
/* 1596 */         for (OID perceivedOid : perceivedOids) {
/* 1597 */           VoiceConnection con = VoicePlugin.this.conMgr.getPlayerCon(perceivedOid);
/* 1598 */           if (con == null)
/*      */             continue;
/* 1600 */           PositionalGroupMember perceivedMember = (PositionalGroupMember)con.groupMember;
/* 1601 */           if ((perceivedMember == null) || (perceivedMember.wnode == null))
/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 1606 */           PositionalVoiceGroup pGroup = (PositionalVoiceGroup)pMember.getGroup();
/* 1607 */           pGroup.testProximity(pMember, perceivedMember, false, false);
/*      */         }
/*      */       }
/*      */       PositionalGroupMember pMember;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class VoiceConManager
/*      */   {
/* 1501 */     private Map<OID, VoiceConnection> playerOidToVoiceConnectionMap = new HashMap();
/*      */ 
/* 1507 */     private Map<OID, VoiceGroup> groupOidToGroupMap = new HashMap();
/*      */ 
/* 1513 */     private Map<OID, VoiceGroup> playerOidToGroupMap = new HashMap();
/*      */ 
/* 1519 */     private Map<OID, Set<PositionalVoiceGroup>> groupsInInstance = new HashMap();
/*      */ 
/* 1521 */     protected transient Lock lock = LockFactory.makeLock("VoiceConManager");
/*      */ 
/*      */     public void addGroup(OID groupOid, VoiceGroup group)
/*      */     {
/* 1275 */       this.lock.lock();
/*      */       try {
/* 1277 */         this.groupOidToGroupMap.put(groupOid, group);
/*      */       }
/*      */       finally {
/* 1280 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public List<OID> groupPlayers(OID groupOid)
/*      */     {
/* 1290 */       List playerOids = new LinkedList();
/* 1291 */       VoiceGroup group = getGroup(groupOid);
/* 1292 */       if (group == null) {
/* 1293 */         Log.error("VoicePlugin.VoiceConManager.groupPlayers: There is no group associated with groupOid " + groupOid);
/*      */       } else {
/* 1295 */         this.lock.lock();
/*      */         try {
/* 1297 */           for (Map.Entry entry : this.playerOidToGroupMap.entrySet())
/* 1298 */             if (entry.getValue() == group)
/* 1299 */               playerOids.add(entry.getKey());
/*      */         }
/*      */         finally
/*      */         {
/* 1303 */           this.lock.unlock();
/*      */         }
/*      */       }
/* 1306 */       return playerOids;
/*      */     }
/*      */ 
/*      */     public VoiceGroup getGroup(OID groupOid)
/*      */     {
/* 1315 */       this.lock.lock();
/*      */       try {
/* 1317 */         VoiceGroup localVoiceGroup = (VoiceGroup)this.groupOidToGroupMap.get(groupOid);
/*      */         return localVoiceGroup; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public void removePlayer(OID playerOid)
/*      */     {
/* 1329 */       this.lock.lock();
/*      */       try {
/* 1331 */         this.playerOidToVoiceConnectionMap.remove(playerOid);
/* 1332 */         this.playerOidToGroupMap.remove(playerOid);
/*      */       }
/*      */       finally {
/* 1335 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public VoiceConnection getPlayerCon(OID playerOid)
/*      */     {
/* 1348 */       this.lock.lock();
/*      */       try {
/* 1350 */         VoiceConnection localVoiceConnection = (VoiceConnection)this.playerOidToVoiceConnectionMap.get(playerOid);
/*      */         return localVoiceConnection; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public void setPlayerCon(OID playerOid, VoiceConnection con)
/*      */     {
/* 1366 */       this.lock.lock();
/*      */       try {
/* 1368 */         this.playerOidToVoiceConnectionMap.put(playerOid, con);
/*      */       }
/*      */       finally {
/* 1371 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void setPlayerGroup(OID playerOid, VoiceGroup group)
/*      */     {
/* 1383 */       this.lock.lock();
/*      */       try {
/* 1385 */         this.playerOidToGroupMap.put(playerOid, group);
/*      */       }
/*      */       finally {
/* 1388 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public VoiceGroup getPlayerGroup(OID playerOid)
/*      */     {
/* 1399 */       this.lock.lock();
/*      */       try {
/* 1401 */         VoiceGroup localVoiceGroup = (VoiceGroup)this.playerOidToGroupMap.get(playerOid);
/*      */         return localVoiceGroup; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public PositionalGroupMember getPositionalMember(OID playerOid)
/*      */     {
/* 1417 */       this.lock.lock();
/*      */       try {
/* 1419 */         VoiceGroup group = (VoiceGroup)this.playerOidToGroupMap.get(playerOid);
/* 1420 */         if ((group != null) && (group.isPositional())) {
/* 1421 */           localPositionalGroupMember = (PositionalGroupMember)group.isMember(playerOid);
/*      */           return localPositionalGroupMember;
/*      */         }
/* 1423 */         PositionalGroupMember localPositionalGroupMember = null;
/*      */         return localPositionalGroupMember; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public List<GroupMember> getAllPositionalGroupMembers()
/*      */     {
/* 1438 */       List pGroupMembers = new LinkedList();
/* 1439 */       this.lock.lock();
/*      */       try {
/* 1441 */         for (VoiceGroup group : this.groupOidToGroupMap.values()) {
/* 1442 */           if (group.isPositional())
/* 1443 */             group.getAllMembers(pGroupMembers);
/*      */         }
/* 1445 */         ??? = pGroupMembers;
/*      */         return ???; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public boolean maybeAddToGroupInstances(OID instanceOid, PositionalVoiceGroup group)
/*      */     {
/* 1461 */       this.lock.lock();
/*      */       try {
/* 1463 */         Set groups = (Set)this.groupsInInstance.get(instanceOid);
/* 1464 */         if (groups == null) {
/* 1465 */           groups = new HashSet();
/* 1466 */           this.groupsInInstance.put(instanceOid, groups);
/*      */         }
/* 1468 */         boolean bool = groups.add(group);
/*      */         return bool; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public Set<PositionalVoiceGroup> removeInstance(OID instanceOid)
/*      */     {
/* 1484 */       this.lock.lock();
/*      */       try {
/* 1486 */         Set localSet = (Set)this.groupsInInstance.remove(instanceOid);
/*      */         return localSet; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public int getPlayerCount()
/*      */     {
/* 1495 */       return this.playerOidToVoiceConnectionMap.size();
/*      */     }
/*      */   }
/*      */ 
/*      */   class RelayUpdatePlayerIgnoreListHook
/*      */     implements Hook
/*      */   {
/*      */     RelayUpdatePlayerIgnoreListHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  791 */       WorldManagerClient.ExtensionMessage extMsg = (WorldManagerClient.ExtensionMessage)msg;
/*  792 */       OID playerOid = extMsg.getSubject();
/*  793 */       VoiceConnection playerCon = VoicePlugin.this.conMgr.getPlayerCon(playerOid);
/*  794 */       if (playerCon == null)
/*  795 */         return true;
/*  796 */       GroupMember member = playerCon.groupMember;
/*  797 */       member.applyIgnoreUpdateMessage(extMsg);
/*  798 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetPluginStatusHook
/*      */     implements Hook
/*      */   {
/*      */     GetPluginStatusHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  482 */       LinkedHashMap status = new LinkedHashMap();
/*      */ 
/*  484 */       status.put("plugin", VoicePlugin.this.getName());
/*  485 */       status.put("voice_user", Integer.valueOf(VoicePlugin.this.conMgr.getPlayerCount()));
/*  486 */       status.put("voice_alloc", Long.valueOf(VoicePlugin.countAllocateVoiceReceived.getCount()));
/*  487 */       status.put("voice_frame", Long.valueOf(VoicePlugin.countDataFramesReceived.getCount()));
/*  488 */       Engine.getAgent().sendObjectResponse(msg, status);
/*  489 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DespawnedHook
/*      */     implements Hook
/*      */   {
/*      */     DespawnedHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  463 */       WorldManagerClient.DespawnedMessage despawnedMsg = (WorldManagerClient.DespawnedMessage)msg;
/*  464 */       OID playerOid = despawnedMsg.getSubject();
/*  465 */       PositionalGroupMember member = VoicePlugin.this.conMgr.getPositionalMember(playerOid);
/*  466 */       if ((member != null) && (member.wnode != null)) {
/*  467 */         if (Log.loggingDebug)
/*  468 */           Log.debug(new StringBuilder().append("DespawnedHook.processMessage: Despawn for ").append(playerOid).append(", instanceOid ").append(member.getInstanceOid()).toString());
/*  469 */         PositionalVoiceGroup group = (PositionalVoiceGroup)member.getGroup();
/*  470 */         group.removeTrackedPerceiver(member);
/*  471 */         VoicePlugin.this.removeFromPerceptionFilter(playerOid);
/*      */       }
/*  473 */       else if (Log.loggingDebug) {
/*  474 */         Log.debug(new StringBuilder().append("DespawnedHook.processMessage: Ignored despawn for player ").append(playerOid).append(" because ").append(member != null ? "member was null" : "member.wnode wasn't null").toString());
/*      */       }
/*  476 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SpawnedHook
/*      */     implements Hook
/*      */   {
/*      */     SpawnedHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  438 */       WorldManagerClient.SpawnedMessage spawnedMsg = (WorldManagerClient.SpawnedMessage)msg;
/*  439 */       OID playerOid = spawnedMsg.getSubject();
/*  440 */       OID instanceOid = spawnedMsg.getInstanceOid();
/*  441 */       PositionalGroupMember member = VoicePlugin.this.conMgr.getPositionalMember(playerOid);
/*  442 */       if ((member != null) && (member.wnode == null)) {
/*  443 */         if (Log.loggingDebug)
/*  444 */           Log.debug("SpawnedHook.processMessage: playerOid " + playerOid + " spawned, instanceOid " + instanceOid);
/*  445 */         VoicePlugin.this.trackNewPerceiver(member);
/*      */       }
/*  448 */       else if (Log.loggingDebug) {
/*  449 */         Log.debug("SpawnedHook.processMessage: playerOid " + playerOid + " spawn ignored, instanceOid " + instanceOid);
/*  450 */       }return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class UpdateWorldNodeHook
/*      */     implements Hook
/*      */   {
/*      */     UpdateWorldNodeHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  416 */       WorldManagerClient.UpdateWorldNodeMessage wnodeMsg = (WorldManagerClient.UpdateWorldNodeMessage)msg;
/*  417 */       OID playerOid = wnodeMsg.getSubject();
/*  418 */       PositionalGroupMember perceiverMember = VoicePlugin.this.conMgr.getPositionalMember(playerOid);
/*  419 */       if ((perceiverMember != null) && (perceiverMember.wnode != null)) {
/*  420 */         BasicWorldNode bwnode = wnodeMsg.getWorldNode();
/*  421 */         if (Log.loggingDebug)
/*  422 */           Log.debug("VoicePlugin.handleMessage: UpdateWnode for " + playerOid + ", loc " + bwnode.getLoc() + ", dir " + bwnode.getDir());
/*  423 */         PositionalVoiceGroup group = (PositionalVoiceGroup)perceiverMember.getGroup();
/*  424 */         group.updateWorldNode(perceiverMember, bwnode);
/*      */       }
/*  426 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class PerceptionHook
/*      */     implements Hook
/*      */   {
/*      */     PerceptionHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  373 */       PerceptionMessage perceptionMessage = (PerceptionMessage)msg;
/*  374 */       OID perceiverOid = perceptionMessage.getTarget();
/*  375 */       PositionalGroupMember perceiverMember = VoicePlugin.this.conMgr.getPositionalMember(perceiverOid);
/*  376 */       if (perceiverMember != null) {
/*  377 */         List gain = perceptionMessage.getGainObjects();
/*  378 */         List lost = perceptionMessage.getLostObjects();
/*  379 */         if (Log.loggingDebug) {
/*  380 */           Log.debug(new StringBuilder().append("PerceptionHook.processMessage: perceiverOid ").append(perceiverOid).append(", instanceOid=").append(perceiverMember.getInstanceOid()).append(" ").append(gain == null ? 0 : gain.size()).append(" gain and ").append(lost == null ? 0 : lost.size()).append(" lost").toString());
/*      */         }
/*      */ 
/*  384 */         if (gain != null) {
/*  385 */           for (PerceptionMessage.ObjectNote note : gain)
/*  386 */             processNote(perceiverOid, perceiverMember, note, true);
/*      */         }
/*  388 */         if (lost != null) {
/*  389 */           for (PerceptionMessage.ObjectNote note : lost)
/*  390 */             processNote(perceiverOid, perceiverMember, note, false);
/*      */         }
/*      */       }
/*  393 */       else if (Log.loggingDebug) {
/*  394 */         Log.debug(new StringBuilder().append("PerceptionHook.processMessage: Could not find PositionalGroupMember for player ").append(perceiverOid).toString());
/*  395 */       }return true;
/*      */     }
/*      */ 
/*      */     protected void processNote(OID perceiverOid, PositionalGroupMember perceiverMember, PerceptionMessage.ObjectNote note, boolean add) {
/*  399 */       OID perceivedOid = note.getSubject();
/*  400 */       PositionalVoiceGroup group = (PositionalVoiceGroup)VoicePlugin.this.conMgr.getPlayerGroup(perceiverOid);
/*  401 */       ObjectType objType = note.getObjectType();
/*  402 */       if (objType.isPlayer())
/*  403 */         group.maybeChangePerceivedObject(perceiverMember, perceivedOid, add);
/*      */     }
/*      */   }
/*      */ 
/*      */   class VoiceClientMessageHook
/*      */     implements Hook
/*      */   {
/*      */     VoiceClientMessageHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message amsg, int flags)
/*      */     {
/*  256 */       WorldManagerClient.ExtensionMessage msg = (WorldManagerClient.ExtensionMessage)amsg;
/*  257 */       String opcode = (String)msg.getProperty("opcode");
/*  258 */       if (Log.loggingDebug) {
/*  259 */         Log.debug("VoiceClientMessageHook.processMessage: Received VoiceClient msg for opcode " + opcode);
/*      */       }
/*  261 */       int returnCode = 1;
/*  262 */       if (opcode.equals("getPlayerGroup")) {
/*  263 */         OID groupOid = null;
/*  264 */         OID memberOid = (OID)msg.getProperty("memberOid");
/*  265 */         if (memberOid != null) {
/*  266 */           VoiceGroup group = VoicePlugin.this.conMgr.getPlayerGroup(memberOid);
/*  267 */           if (group != null)
/*  268 */             groupOid = group.getGroupOid();
/*      */         }
/*  270 */         Engine.getAgent().sendResponse(new OIDResponseMessage(amsg, groupOid));
/*  271 */         return true;
/*      */       }
/*  273 */       OID groupOid = (OID)msg.getProperty("groupOid");
/*  274 */       if (opcode.equals("addVoiceGroup")) {
/*  275 */         if (VoicePlugin.this.conMgr.getGroup(groupOid) != null) {
/*  276 */           returnCode = -2;
/*      */         } else {
/*  278 */           Integer maxVoices = (Integer)msg.getProperty("maxVoices");
/*  279 */           Boolean positional = (Boolean)msg.getProperty("positional");
/*  280 */           if (maxVoices == null) {
/*  281 */             returnCode = -8;
/*  282 */           } else if (positional == null) {
/*  283 */             returnCode = -9;
/*      */           } else {
/*  285 */             VoiceGroup group = positional.booleanValue() ? new PositionalVoiceGroup(groupOid, null, VoicePlugin.this, maxVoices.intValue(), VoicePlugin.audibleRadius, VoicePlugin.hystericalMargin) : new NonpositionalVoiceGroup(groupOid, null, VoicePlugin.this, maxVoices.intValue());
/*      */ 
/*  288 */             VoicePlugin.this.addGroup(groupOid, group);
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  294 */         VoiceGroup group = VoicePlugin.this.conMgr.getGroup(groupOid);
/*  295 */         if (group == null) {
/*  296 */           returnCode = -1;
/*      */         }
/*  298 */         else if (opcode.equals("removeVoiceGroup")) {
/*  299 */           VoicePlugin.this.removeGroup(groupOid);
/*  300 */         } else if (opcode.equals("isPositional")) {
/*  301 */           returnCode = successTrueOrFalse(group.isPositional());
/*  302 */         } else if (opcode.equals("setAllowedMembers")) {
/*  303 */           group.setAllowedMembers((Set)msg.getProperty("allowedMembers")); } else {
/*  304 */           if (opcode.equals("getAllowedMembers")) {
/*  305 */             Engine.getAgent().sendResponse(new GenericResponseMessage(amsg, group.getAllowedMembers()));
/*  306 */             return true;
/*      */           }
/*      */ 
/*  310 */           OID memberOid = (OID)msg.getProperty("memberOid");
/*  311 */           if (memberOid == null) {
/*  312 */             returnCode = -3;
/*  313 */           } else if (opcode.equals("addMember")) {
/*  314 */             VoiceConnection con = VoicePlugin.this.conMgr.getPlayerCon(memberOid);
/*  315 */             if (con == null)
/*  316 */               returnCode = -6;
/*      */             else
/*  318 */               group.addMember(memberOid, con, ((Integer)msg.getProperty("priority")).intValue(), ((Boolean)msg.getProperty("allowedSpeaker")).booleanValue());
/*      */           }
/*  320 */           else if (opcode.equals("isMember")) {
/*  321 */             returnCode = successTrueOrFalse(group.isMember(memberOid) != null);
/*  322 */           } else if (opcode.equals("addMemberAllowed")) {
/*  323 */             returnCode = successTrueOrFalse(group.addMemberAllowed(memberOid));
/*      */           }
/*  327 */           else if (group.isMember(memberOid) == null) {
/*  328 */             returnCode = -3;
/*  329 */           } else if (opcode.equals("removeMember")) {
/*  330 */             group.removeMember(memberOid);
/*  331 */           } else if (opcode.equals("isMemberSpeaking")) {
/*  332 */             returnCode = successTrueOrFalse(group.isMemberSpeaking(memberOid));
/*  333 */           } else if (opcode.equals("isListener")) {
/*  334 */             returnCode = successTrueOrFalse(group.isListener(memberOid));
/*      */           }
/*      */           else {
/*  337 */             Boolean add = (Boolean)msg.getProperty("add");
/*  338 */             if (add == null) {
/*  339 */               returnCode = -7;
/*      */             }
/*  341 */             else if (opcode.equals("setAllowedSpeaker"))
/*  342 */               group.setAllowedSpeaker(memberOid, add.booleanValue());
/*  343 */             else if (opcode.equals("setMemberSpeaking"))
/*  344 */               group.setMemberSpeaking(memberOid, add.booleanValue());
/*  345 */             else if (opcode.equals("setListener"))
/*  346 */               group.setListener(memberOid, add.booleanValue());
/*      */             else {
/*  348 */               returnCode = -5;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  355 */       if (Log.loggingDebug) {
/*  356 */         Log.debug("VoiceClientMessageHook.processMessage: Response to VoiceClient msg for opcode " + opcode + " is returnCode " + returnCode);
/*      */       }
/*  358 */       Engine.getAgent().sendResponse(new IntegerResponseMessage(amsg, Integer.valueOf(returnCode)));
/*  359 */       return true;
/*      */     }
/*      */ 
/*      */     protected int successTrueOrFalse(boolean which) {
/*  363 */       return which ? 2 : 3;
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceUnloadedHook
/*      */     implements Hook
/*      */   {
/*      */     InstanceUnloadedHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  238 */       SubjectMessage message = (SubjectMessage)msg;
/*  239 */       OID instanceOid = message.getSubject();
/*  240 */       Set groups = VoicePlugin.this.conMgr.removeInstance(instanceOid);
/*  241 */       if (groups != null) {
/*  242 */         for (PositionalVoiceGroup group : groups)
/*  243 */           group.unloadInstance(instanceOid);
/*      */       }
/*  245 */       Engine.getAgent().sendResponse(new ResponseMessage(message));
/*  246 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class LoginHook
/*      */     implements Hook
/*      */   {
/*      */     LoginHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  223 */       LoginMessage message = (LoginMessage)msg;
/*  224 */       OID playerOid = message.getSubject();
/*  225 */       OID instanceOid = message.getInstanceOid();
/*  226 */       Log.debug("LoginHook: playerOid=" + playerOid + " instanceOid=" + instanceOid);
/*  227 */       Engine.getAgent().sendResponse(new ResponseMessage(message));
/*  228 */       VoicePlugin.this.sendLoginStatusToReceivers(playerOid, true);
/*  229 */       return true;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.VoicePlugin
 * JD-Core Version:    0.6.0
 */