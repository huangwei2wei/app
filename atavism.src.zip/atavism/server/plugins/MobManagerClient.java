/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.objects.SpawnData;
/*     */ 
/*     */ public class MobManagerClient
/*     */ {
/* 115 */   public static MessageType MSG_TYPE_CREATE_SPAWN_GEN = MessageType.intern("ao.CREATE_SPAWN_GEN");
/*     */ 
/* 117 */   public static MessageType MSG_TYPE_SET_AGGRO_RADIUS = MessageType.intern("ao.SET_AGGRO_RADIUS");
/*     */ 
/*     */   public static boolean createSpawnGenerator(SpawnData spawnData)
/*     */   {
/*  23 */     CreateSpawnGeneratorMessage message = new CreateSpawnGeneratorMessage(spawnData);
/*     */ 
/*  26 */     return Engine.getAgent().sendRPCReturnBoolean(message).booleanValue();
/*     */   }
/*     */ 
/*     */   public static void setAggroRadius(OID mob, OID target, int radius)
/*     */   {
/*  61 */     SetAggroRadiusMessage message = new SetAggroRadiusMessage(mob, target, radius);
/*     */ 
/*  64 */     Engine.getAgent().sendBroadcast(message); } 
/*     */   public static class SetAggroRadiusMessage extends Message { private OID mob;
/*     */     private OID target;
/*     */     private int radius;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public SetAggroRadiusMessage() {  }
/*     */ 
/*  75 */     public SetAggroRadiusMessage(OID mob, OID target, int radius) { super();
/*  76 */       setMob(mob);
/*  77 */       setTarget(target);
/*  78 */       setRadius(radius);
/*     */     }
/*     */ 
/*     */     public OID getMob()
/*     */     {
/*  83 */       return this.mob;
/*     */     }
/*     */ 
/*     */     public void setMob(OID mob) {
/*  87 */       this.mob = mob;
/*     */     }
/*     */ 
/*     */     public OID getTarget()
/*     */     {
/*  92 */       return this.target;
/*     */     }
/*     */ 
/*     */     public void setTarget(OID target) {
/*  96 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public int getRadius()
/*     */     {
/* 101 */       return this.radius;
/*     */     }
/*     */ 
/*     */     public void setRadius(int radius) {
/* 105 */       this.radius = radius;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CreateSpawnGeneratorMessage extends Message
/*     */   {
/*     */     private SpawnData spawnData;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public CreateSpawnGeneratorMessage()
/*     */     {
/*     */     }
/*     */ 
/*     */     public CreateSpawnGeneratorMessage(SpawnData spawnData)
/*     */     {
/*  37 */       super();
/*  38 */       setSpawnData(spawnData);
/*     */     }
/*     */ 
/*     */     public SpawnData getSpawnData()
/*     */     {
/*  43 */       return this.spawnData;
/*     */     }
/*     */ 
/*     */     public void setSpawnData(SpawnData spawnData) {
/*  47 */       this.spawnData = spawnData;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.MobManagerClient
 * JD-Core Version:    0.6.0
 */