/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.management.Management;
/*      */ import atavism.msgsys.AgentHandle;
/*      */ import atavism.msgsys.Filter;
/*      */ import atavism.msgsys.FilterUpdate;
/*      */ import atavism.msgsys.FilterUpdate.Instruction;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageAgent.DomainClient;
/*      */ import atavism.msgsys.MessageCallback;
/*      */ import atavism.msgsys.MessageType;
/*      */ import atavism.msgsys.MessageTypeFilter;
/*      */ import atavism.msgsys.MessageTypeSessionIdFilter;
/*      */ import atavism.msgsys.ResponseMessage;
/*      */ import atavism.msgsys.SubjectFilter;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.msgsys.SubscriptionHandle;
/*      */ import atavism.server.engine.BasicWorldNode;
/*      */ import atavism.server.engine.Database;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.EnginePlugin;
/*      */ import atavism.server.engine.EnginePlugin.DeleteHook;
/*      */ import atavism.server.engine.EnginePlugin.GenerateSubObjectHook;
/*      */ import atavism.server.engine.EnginePlugin.LoadHook;
/*      */ import atavism.server.engine.EnginePlugin.SubObjData;
/*      */ import atavism.server.engine.EnginePlugin.TransferFilter;
/*      */ import atavism.server.engine.EnginePlugin.TransferObjectMessage;
/*      */ import atavism.server.engine.EnginePlugin.UnloadHook;
/*      */ import atavism.server.engine.FixedPerceiver;
/*      */ import atavism.server.engine.Hook;
/*      */ import atavism.server.engine.HookManager;
/*      */ import atavism.server.engine.InterpolatedWorldNode;
/*      */ import atavism.server.engine.InterpolatedWorldNode.InterpolatedDirLocOrientTime;
/*      */ import atavism.server.engine.MobilePerceiver;
/*      */ import atavism.server.engine.Namespace;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.engine.OIDManager;
/*      */ import atavism.server.engine.Perceiver;
/*      */ import atavism.server.engine.PerceiverCallback;
/*      */ import atavism.server.engine.PerceiverFilter;
/*      */ import atavism.server.engine.PerceiverNewsAndFrees;
/*      */ import atavism.server.engine.PersistenceManager;
/*      */ import atavism.server.engine.QuadTree;
/*      */ import atavism.server.engine.QuadTree.NewsAndFrees;
/*      */ import atavism.server.engine.QuadTreeNode;
/*      */ import atavism.server.engine.QuadTreeNode.NodeType;
/*      */ import atavism.server.engine.SoundManager;
/*      */ import atavism.server.engine.WMWorldNode;
/*      */ import atavism.server.engine.WorldNode;
/*      */ import atavism.server.math.AOVector;
/*      */ import atavism.server.math.Geometry;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.math.Quaternion;
/*      */ import atavism.server.messages.NamespaceFilter;
/*      */ import atavism.server.messages.PerceptionFilter;
/*      */ import atavism.server.messages.PerceptionMessage;
/*      */ import atavism.server.messages.PerceptionMessage.ObjectNote;
/*      */ import atavism.server.messages.PerceptionUpdateTrigger;
/*      */ import atavism.server.messages.SubObjectFilter;
/*      */ import atavism.server.objects.AOObject;
/*      */ import atavism.server.objects.Boundary;
/*      */ import atavism.server.objects.Color;
/*      */ import atavism.server.objects.DisplayContext;
/*      */ import atavism.server.objects.Entity;
/*      */ import atavism.server.objects.EntityManager;
/*      */ import atavism.server.objects.Fog;
/*      */ import atavism.server.objects.FogRegionConfig;
/*      */ import atavism.server.objects.Light;
/*      */ import atavism.server.objects.LightData;
/*      */ import atavism.server.objects.ObjectType;
/*      */ import atavism.server.objects.ObjectTypes;
/*      */ import atavism.server.objects.Region;
/*      */ import atavism.server.objects.RegionConfig;
/*      */ import atavism.server.objects.RegionTrigger;
/*      */ import atavism.server.objects.RoadRegionConfig;
/*      */ import atavism.server.objects.SoundData;
/*      */ import atavism.server.objects.SoundRegionConfig;
/*      */ import atavism.server.objects.Template;
/*      */ import atavism.server.objects.World;
/*      */ import atavism.server.pathing.PathFinderValue;
/*      */ import atavism.server.pathing.PathInfo;
/*      */ import atavism.server.pathing.PathInterpolator;
/*      */ import atavism.server.pathing.PathLinear;
/*      */ import atavism.server.pathing.PathObject;
/*      */ import atavism.server.pathing.PathSearcher;
/*      */ import atavism.server.pathing.PathSpline;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.Logger;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ public abstract class WorldManagerPlugin extends EnginePlugin
/*      */   implements MessageCallback, PerceiverCallback<WMWorldNode>, PerceptionUpdateTrigger
/*      */ {
/* 2523 */   FixedPerceiverMap fixedPerceiverMap = new FixedPerceiverMap();
/*      */ 
/* 2530 */   OidSubscriptionMap remoteMobSubscription = new OidSubscriptionMap();
/*      */ 
/* 3322 */   private int maxObjects = 30;
/* 3323 */   private int maxDepth = 20;
/*      */   protected SubObjectFilter subObjectFilter;
/*      */   protected WorldManagerFilter newRegionFilter;
/*      */   protected long newRegionSub;
/*      */   protected PerceptionFilter mobFilter;
/*      */   protected long mobSubId;
/*      */   protected PerceptionFilter mobRPCFilter;
/*      */   protected long mobRPCSubId;
/*      */   protected PerceptionFilter structFilter;
/*      */   protected long structSubId;
/*      */   protected PerceptionFilter structRPCFilter;
/*      */   protected long structRPCSubId;
/* 3344 */   protected int defaultWorldManagerHysteresis = 20;
/*      */ 
/* 3346 */   protected Map<OID, QuadTree<WMWorldNode>> quadtrees = new HashMap();
/*      */ 
/* 3349 */   protected Map<String, RegionTrigger> regionTriggers = new HashMap();
/*      */ 
/* 3352 */   protected Set<String> propertyExclusions = new HashSet();
/*      */ 
/* 3354 */   protected static final Logger log = new Logger("WorldManagerPlugin");
/*      */ 
/* 3356 */   protected PathInfo pathInfo = null;
/*      */ 
/* 3358 */   protected boolean askedForPathInfo = false;
/*      */ 
/* 3360 */   protected Updater updater = null;
/*      */ 
/* 3362 */   protected static PathObjectCache pathObjectCache = new PathObjectCache();
/*      */ 
/* 3364 */   public static final String REGION_MEMBERSHIP = (String)Entity.registerTransientPropertyKey("customRegions");
/*      */ 
/*      */   public WorldManagerPlugin()
/*      */   {
/*   35 */     setPluginType("WorldManager");
/*      */     String wmAgentName;
/*      */     try
/*      */     {
/*   38 */       wmAgentName = Engine.getAgent().getDomainClient().allocName("PLUGIN", getPluginType() + "#");
/*      */     }
/*      */     catch (IOException e) {
/*   41 */       throw new AORuntimeException("Could not allocate world manager plugin name", e);
/*      */     }
/*      */ 
/*   44 */     setName(wmAgentName);
/*      */ 
/*   46 */     this.propertyExclusions.add("aoobj.wnode");
/*   47 */     this.propertyExclusions.add("aoobj.perceiver");
/*   48 */     this.propertyExclusions.add("aoobj.dc");
/*   49 */     this.propertyExclusions.add("aoobj.statemap");
/*      */ 
/*   51 */     PerceptionFilter.addUpdateTrigger(this);
/*      */   }
/*      */ 
/*      */   public void onActivate()
/*      */   {
/*      */     try {
/*   57 */       registerHooks();
/*      */ 
/*   59 */       Integer maxObjects = Engine.getIntProperty("atavism.quad_tree_node_max_objects");
/*   60 */       Integer maxDepth = Engine.getIntProperty("atavism.quad_tree_max_depth");
/*   61 */       if (maxObjects != null)
/*   62 */         this.maxObjects = maxObjects.intValue();
/*   63 */       if (maxDepth != null) {
/*   64 */         this.maxDepth = maxDepth.intValue();
/*      */       }
/*      */ 
/*   67 */       Integer minX = Engine.getIntProperty("atavism.geometry_min_x");
/*   68 */       Integer maxX = Engine.getIntProperty("atavism.geometry_max_x");
/*   69 */       Integer minZ = Engine.getIntProperty("atavism.geometry_min_z");
/*   70 */       Integer maxZ = Engine.getIntProperty("atavism.geometry_max_z");
/*   71 */       if ((minX != null) && (maxX != null) && (minZ != null) && (maxZ != null)) {
/*   72 */         Geometry.GEO_MIN_X = minX.intValue();
/*   73 */         Geometry.GEO_MAX_X = maxX.intValue();
/*   74 */         Geometry.GEO_MIN_Z = minZ.intValue();
/*   75 */         Geometry.GEO_MAX_Z = maxZ.intValue();
/*      */       }
/*      */ 
/*   78 */       Geometry localGeo = World.getLocalGeometry();
/*   79 */       if (localGeo == null) {
/*   80 */         throw new RuntimeException("null local geometry");
/*      */       }
/*      */ 
/*   84 */       List namespaces = new LinkedList();
/*   85 */       namespaces.add(Namespace.WORLD_MANAGER);
/*   86 */       namespaces.add(Namespace.WM_INSTANCE);
/*      */ 
/*   88 */       WorldManagerFilter selectionFilter = new WorldManagerFilter(getName());
/*   89 */       this.subObjectFilter = new SubObjectFilter();
/*   90 */       this.subObjectFilter.setMatchSubjects(true);
/*   91 */       registerPluginNamespaces(namespaces, new WorldManagerGenerateSubObjectHook(), selectionFilter, this.subObjectFilter);
/*      */ 
/*   95 */       HostInstanceFilter hostInstanceFilter = new HostInstanceFilter(getName());
/*   96 */       hostInstanceFilter.addType(WorldManagerClient.MSG_TYPE_HOST_INSTANCE);
/*   97 */       Engine.getAgent().createSubscription(hostInstanceFilter, this, 8);
/*      */ 
/*  100 */       this.newRegionFilter = new WorldManagerFilter();
/*  101 */       this.newRegionFilter.setNamespaces(namespaces);
/*  102 */       this.newRegionFilter.addType(WorldManagerClient.MSG_TYPE_NEW_REGION);
/*  103 */       this.newRegionFilter.addType(WorldManagerClient.MSG_TYPE_PLAYER_PATH_WM_REQ);
/*  104 */       this.newRegionSub = Engine.getAgent().createSubscription(this.newRegionFilter, this);
/*      */ 
/*  107 */       registerLoadHook(Namespace.WORLD_MANAGER, new MobLoadHook());
/*  108 */       registerUnloadHook(Namespace.WORLD_MANAGER, new MobUnloadHook());
/*  109 */       registerDeleteHook(Namespace.WORLD_MANAGER, new MobDeleteHook());
/*      */ 
/*  112 */       registerLoadHook(WorldManagerClient.INSTANCE_NAMESPACE, new InstanceLoadHook());
/*      */ 
/*  114 */       registerUnloadHook(WorldManagerClient.INSTANCE_NAMESPACE, new InstanceUnloadHook());
/*      */ 
/*  116 */       registerDeleteHook(WorldManagerClient.INSTANCE_NAMESPACE, new InstanceDeleteHook());
/*      */ 
/*  120 */       LinkedList types = new LinkedList();
/*  121 */       types.add(WorldManagerClient.MSG_TYPE_REFRESH_WNODE);
/*  122 */       types.add(WorldManagerClient.MSG_TYPE_MODIFY_DC);
/*  123 */       types.add(WorldManagerClient.MSG_TYPE_UPDATE_OBJECT);
/*  124 */       types.add(WorldManagerClient.MSG_TYPE_UPDATEWNODE_REQ);
/*  125 */       types.add(WorldManagerClient.MSG_TYPE_ORIENT_REQ);
/*  126 */       types.add(WorldManagerClient.MSG_TYPE_MOB_PATH_REQ);
/*  127 */       types.add(WorldManagerClient.MSG_TYPE_REPARENT_WNODE_REQ);
/*  128 */       types.add(WorldManagerClient.MSG_TYPE_COM_REQ);
/*  129 */       this.mobFilter = new PerceptionFilter(types);
/*  130 */       this.mobFilter.setMatchSubjects(true);
/*  131 */       this.mobSubId = Engine.getAgent().createSubscription(this.mobFilter, this);
/*      */ 
/*  134 */       types.clear();
/*  135 */       types.add(WorldManagerClient.MSG_TYPE_OBJINFO_REQ);
/*  136 */       types.add(WorldManagerClient.MSG_TYPE_DC_REQ);
/*  137 */       types.add(WorldManagerClient.MSG_TYPE_SPAWN_REQ);
/*  138 */       types.add(WorldManagerClient.MSG_TYPE_DESPAWN_REQ);
/*  139 */       types.add(WorldManagerClient.MSG_TYPE_SETWNODE_REQ);
/*  140 */       types.add(WorldManagerClient.MSG_TYPE_GETWNODE_REQ);
/*  141 */       types.add(WorldManagerClient.MSG_TYPE_GET_OBJECTS_IN);
/*  142 */       this.mobRPCFilter = new PerceptionFilter(types);
/*  143 */       this.mobRPCFilter.setMatchSubjects(true);
/*  144 */       this.mobRPCSubId = Engine.getAgent().createSubscription(this.mobRPCFilter, this, 8);
/*      */ 
/*  152 */       Filter percFilter = new MessageTypeSessionIdFilter(WorldManagerClient.MSG_TYPE_PERCEIVER_REGIONS, Engine.getAgent().getName(), true);
/*      */ 
/*  155 */       Long percSub = Long.valueOf(Engine.getAgent().createSubscription(percFilter, this));
/*  156 */       if (percSub == null) {
/*  157 */         throw new AORuntimeException("create perceiver sub failed");
/*      */       }
/*  159 */       if (Log.loggingDebug) {
/*  160 */         Log.debug("created perceiver regions subscriptions: " + percSub);
/*      */       }
/*      */ 
/*  163 */       WorldManagerTransferFilter transferFilter = new WorldManagerTransferFilter();
/*  164 */       transferFilter.addGeometry(localGeo);
/*  165 */       Hook transferHook = new WorldManagerTransferHook();
/*  166 */       registerTransferHook(transferFilter, transferHook);
/*      */ 
/*  170 */       MessageTypeSessionIdFilter remoteMobFilter = new MessageTypeSessionIdFilter(Engine.getAgent().getName());
/*  171 */       remoteMobFilter.matchesNullSessionId(false);
/*  172 */       remoteMobFilter.addType(WorldManagerClient.MSG_TYPE_NEW_REMOTE_OBJ);
/*  173 */       remoteMobFilter.addType(WorldManagerClient.MSG_TYPE_FREE_REMOTE_OBJ);
/*  174 */       Engine.getAgent().createSubscription(remoteMobFilter, this);
/*      */ 
/*  176 */       types.clear();
/*  177 */       types.add(Management.MSG_TYPE_GET_PLUGIN_STATUS);
/*  178 */       Engine.getAgent().createSubscription(new MessageTypeFilter(types), this, 8);
/*      */ 
/*  193 */       Engine.registerStatusReportingPlugin(this);
/*      */ 
/*  198 */       startUpdater();
/*      */     } catch (Exception e) {
/*  200 */       Log.exception("WorldManagerPlugin.onActivate failed", e);
/*  201 */       throw new AORuntimeException("activate failed", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, String> getStatusMap()
/*      */   {
/*  207 */     Map status = new HashMap();
/*      */ 
/*  209 */     status.put("instances", Integer.toString(this.quadtrees.size()));
/*  210 */     status.put("entities", Integer.toString(EntityManager.getEntityCount()));
/*  211 */     return status;
/*      */   }
/*      */ 
/*      */   public Entity getWorldManagerEntity(OID oid) {
/*  215 */     return EntityManager.getEntityByNamespace(oid, Namespace.WORLD_MANAGER);
/*      */   }
/*      */ 
/*      */   public Entity getWorldManagerEntityOrError(OID oid) {
/*  219 */     Entity entity = getWorldManagerEntity(oid);
/*  220 */     if (entity == null)
/*  221 */       throw new AORuntimeException("Could not find wm entity for oid " + oid);
/*  222 */     return entity;
/*      */   }
/*      */ 
/*      */   public void registerWorldManagerEntity(Entity entity) {
/*  226 */     EntityManager.registerEntityByNamespace(entity, Namespace.WORLD_MANAGER);
/*      */   }
/*      */ 
/*      */   public boolean removeWorldManagerEntity(OID oid) {
/*  230 */     return EntityManager.removeEntityByNamespace(oid, Namespace.WORLD_MANAGER);
/*      */   }
/*      */ 
/*      */   protected void startUpdater()
/*      */   {
/*  238 */     this.updater = new Updater();
/*  239 */     Thread updateThread = new Thread(this.updater, "WMUpdater");
/*  240 */     updateThread.start();
/*      */   }
/*      */ 
/*      */   public void sendRegionUpdate(AOObject obj)
/*      */   {
/*  245 */     WMWorldNode wnode = (WMWorldNode)obj.worldNode();
/*  246 */     QuadTreeNode quadNode = wnode.getQuadNode();
/*  247 */     if (quadNode != null) {
/*  248 */       Point loc = wnode.getCurrentLoc();
/*  249 */       List regionList = quadNode.getRegionByLoc(loc);
/*  250 */       if (regionList != null)
/*  251 */         synchronized (this.updater) {
/*  252 */           this.updater.updateRegion(obj, regionList);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   Fog getInstanceFog(OID instanceOid)
/*      */   {
/*  906 */     WorldManagerInstance instance = (WorldManagerInstance)EntityManager.getEntityByNamespace(instanceOid, WorldManagerClient.INSTANCE_NAMESPACE);
/*      */ 
/*  910 */     return instance.getGlobalFog();
/*      */   }
/*      */ 
/*      */   protected void registerHooks()
/*      */   {
/*  915 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_GET_OBJECTS_IN, new GetObjectsInHook());
/*      */ 
/*  917 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_OBJINFO_REQ, new ObjectInfoReqHook());
/*      */ 
/*  919 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_DC_REQ, new DisplayContextReqHook());
/*      */ 
/*  921 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_SPAWN_REQ, new SpawnReqHook());
/*      */ 
/*  923 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_DESPAWN_REQ, new DespawnReqHook());
/*      */ 
/*  925 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_UPDATE_OBJECT, new UpdateObjectHook());
/*      */ 
/*  927 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_GETWNODE_REQ, new GetWNodeReqHook());
/*      */ 
/*  929 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_COM_REQ, new ComReqHook());
/*      */ 
/*  931 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_ORIENT_REQ, new OrientReqHook());
/*      */ 
/*  933 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_REFRESH_WNODE, new RefreshWNodeHook());
/*      */ 
/*  935 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_PERCEIVER_REGIONS, new PerceiverRegionsHook());
/*      */ 
/*  937 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_NEW_REMOTE_OBJ, new NewRemoteObjHook());
/*      */ 
/*  939 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_FREE_REMOTE_OBJ, new FreeRemoteObjHook());
/*      */ 
/*  943 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_MOB_PATH_REQ, new MobPathReqHook());
/*      */ 
/*  945 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_NEW_REGION, new NewRegionHook());
/*      */ 
/*  947 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_MODIFY_DC, new ModifyDisplayContextHook());
/*      */ 
/*  949 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_HOST_INSTANCE, new HostInstanceHook());
/*      */ 
/*  951 */     getHookManager().addHook(Management.MSG_TYPE_GET_PLUGIN_STATUS, new GetPluginStatusHook());
/*      */ 
/*  953 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_PLAYER_PATH_WM_REQ, new PlayerPathWMReqHook());
/*      */   }
/*      */ 
/*      */   protected WorldManagerClient.PerceptionInfo makePerceptionInfo(OID oid, AOObject object)
/*      */   {
/* 1020 */     WorldManagerClient.ObjectInfo objectInfo = makeObjectInfo(oid);
/*      */ 
/* 1035 */     WorldManagerClient.PerceptionInfo info = new WorldManagerClient.PerceptionInfo(objectInfo);
/*      */ 
/* 1037 */     ObjectType objectType = object.getType();
/* 1038 */     if ((objectType != ObjectTypes.light) && (objectType != WorldManagerClient.TEMPL_OBJECT_TYPE_TERRAIN_DECAL) && (objectType != WorldManagerClient.TEMPL_OBJECT_TYPE_POINT_SOUND))
/*      */     {
/* 1041 */       info.displayContext = getDisplayContext(oid);
/*      */     }
/* 1043 */     return info;
/*      */   }
/*      */ 
/*      */   protected void sendWMMessage(Message msg) {
/* 1047 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   protected OID getPerceiverOid(MobilePerceiver<WMWorldNode> mobileP) {
/* 1051 */     WMWorldNode pWnode = (WMWorldNode)mobileP.getElement();
/* 1052 */     AOObject pObj = pWnode.getObject();
/* 1053 */     return pObj.getOid();
/*      */   }
/*      */ 
/*      */   public void newObjectForFixedPerceiver(Perceiver<WMWorldNode> p, WMWorldNode newWnode)
/*      */   {
/* 1062 */     FixedPerceiver fixedP = (FixedPerceiver)p;
/* 1063 */     Engine.getAgent().sendBroadcast(makeNewObjectForFixedPerceiverMessage(fixedP, newWnode));
/*      */   }
/*      */ 
/*      */   protected WorldManagerClient.NewRemoteObjectMessage makeNewObjectForFixedPerceiverMessage(FixedPerceiver<WMWorldNode> fixedP, WMWorldNode newWnode)
/*      */   {
/* 1069 */     String remoteSessionId = this.fixedPerceiverMap.getSessionId(fixedP);
/* 1070 */     if (remoteSessionId == null) {
/* 1071 */       throw new RuntimeException("unknown remoteSessionId " + remoteSessionId);
/*      */     }
/*      */ 
/* 1075 */     AOObject newObj = newWnode.getObject();
/* 1076 */     OID newOid = newObj.getOid();
/*      */ 
/* 1078 */     if (Log.loggingDebug) {
/* 1079 */       log.debug("newObjectForFixedPerceiver: objOid=" + newOid + ", newWnode=" + newWnode + ", remoteSessionId=" + remoteSessionId);
/*      */     }
/*      */ 
/* 1083 */     WorldManagerClient.NewRemoteObjectMessage newObjMsg = new WorldManagerClient.NewRemoteObjectMessage(remoteSessionId, newWnode.getInstanceOid(), newOid, newWnode.getLoc(), newWnode.getOrientation(), newWnode.getPerceptionRadius(), newObj.getType());
/*      */ 
/* 1087 */     return newObjMsg;
/*      */   }
/*      */ 
/*      */   public void freeObjectForFixedPerceiver(Perceiver<WMWorldNode> p, WMWorldNode freeWnode) {
/* 1091 */     FixedPerceiver fixedP = (FixedPerceiver)p;
/* 1092 */     Engine.getAgent().sendBroadcast(makeFreeObjectForFixedPerceiverMessage(fixedP, freeWnode));
/*      */   }
/*      */ 
/*      */   protected WorldManagerClient.FreeRemoteObjectMessage makeFreeObjectForFixedPerceiverMessage(FixedPerceiver<WMWorldNode> fixedP, WMWorldNode freeWnode)
/*      */   {
/* 1098 */     String remoteSessionId = this.fixedPerceiverMap.getSessionId(fixedP);
/* 1099 */     if (remoteSessionId == null) {
/* 1100 */       throw new RuntimeException("unknown remoteSessionId " + remoteSessionId);
/*      */     }
/*      */ 
/* 1103 */     AOObject freeObj = freeWnode.getObject();
/*      */ 
/* 1105 */     OID freeOid = freeObj.getOid();
/*      */ 
/* 1107 */     if (Log.loggingDebug) {
/* 1108 */       log.debug("freeFixedObj: objOid=" + freeOid + ", wnode=" + freeWnode + ", remoteSessionId=" + remoteSessionId);
/*      */     }
/*      */ 
/* 1112 */     WorldManagerClient.FreeRemoteObjectMessage msg = new WorldManagerClient.FreeRemoteObjectMessage(remoteSessionId, freeWnode.getInstanceOid(), freeOid);
/*      */ 
/* 1114 */     return msg;
/*      */   }
/*      */ 
/*      */   public Integer processNewsAndFrees(Perceiver<WMWorldNode> p, PerceiverNewsAndFrees<WMWorldNode> newsAndFrees, OID perceiverOid)
/*      */   {
/* 1127 */     if (Log.loggingDebug) {
/* 1128 */       Log.debug("processNewsAndFrees: perceiverOid " + perceiverOid + " freeCount=" + newsAndFrees.getFreedElements().size() + " newCount=" + newsAndFrees.getNewElements().size());
/*      */     }
/*      */ 
/* 1133 */     if ((p instanceof MobilePerceiver)) {
/* 1134 */       MobilePerceiver mobileP = (MobilePerceiver)p;
/* 1135 */       OID pOid = getPerceiverOid(mobileP);
/* 1136 */       OID instanceOid = ((WMWorldNode)mobileP.getElement()).getInstanceOid();
/* 1137 */       QuadTree quadtree = (QuadTree)this.quadtrees.get(instanceOid);
/* 1138 */       if (quadtree == null) {
/* 1139 */         Log.error("processNewsAndFrees: unknown instanceOid=" + instanceOid + " oid=" + pOid);
/*      */ 
/* 1141 */         return null;
/*      */       }
/*      */ 
/* 1144 */       if (Log.loggingDebug) {
/* 1145 */         Log.debug("processNewsAndFrees: perceiverOid " + perceiverOid + ", pOid " + pOid);
/*      */       }
/*      */ 
/* 1148 */       if ((quadtree.spawningNewsAndFrees != null) && 
/* 1149 */         (!quadtree.spawningNewsAndFrees.getMap().values().contains(newsAndFrees))) {
/* 1150 */         System.out.println("perceiverOid " + perceiverOid + ", pOid " + pOid + " freeCount=" + newsAndFrees.getFreedElements().size() + " newCount=" + newsAndFrees.getNewElements().size());
/*      */ 
/* 1154 */         Thread.dumpStack();
/*      */       }
/*      */ 
/* 1158 */       if ((World.DEBUG_OID.equals(perceiverOid)) || (World.DEBUG_OID.equals(pOid))) {
/* 1159 */         Log.info("processNewsAndFrees: oid=" + perceiverOid + " pOid=" + pOid + " newCount=" + newsAndFrees.getNewElements().size() + " freeCount=" + newsAndFrees.getFreedElements().size());
/*      */       }
/*      */ 
/* 1165 */       PerceptionMessage message = new PerceptionMessage(WorldManagerClient.MSG_TYPE_PERCEPTION_INFO, pOid);
/*      */ 
/* 1168 */       int count = 0;
/* 1169 */       for (WMWorldNode lostNode : newsAndFrees.getFreedElements()) {
/* 1170 */         AOObject lostObj = lostNode.getObject();
/* 1171 */         OID lostOid = lostObj.getOid();
/* 1172 */         message.lostObject(pOid, lostOid, lostObj.getType());
/* 1173 */         count++;
/*      */       }
/*      */ 
/* 1176 */       for (WMWorldNode gainNode : newsAndFrees.getNewElements()) {
/* 1177 */         AOObject gainObj = gainNode.getObject();
/* 1178 */         OID gainOid = gainObj.getOid();
/* 1179 */         PerceptionMessage.ObjectNote note = new PerceptionMessage.ObjectNote(pOid, gainOid, gainObj.getType());
/*      */ 
/* 1182 */         note.setObjectInfo(makePerceptionInfo(gainOid, gainObj));
/* 1183 */         message.gainObject(note);
/* 1184 */         count++;
/*      */       }
/*      */ 
/* 1187 */       Engine.getAgent().sendBroadcast(message);
/*      */ 
/* 1191 */       Log.debug("PERCEP2: sending Perception Message with oid: " + message.getTarget() + " and gainCount=" + message.getGainObjectCount() + " and lostCount=" + message.getLostObjectCount());
/*      */ 
/* 1195 */       message.setMsgType(WorldManagerClient.MSG_TYPE_PERCEPTION);
/* 1196 */       if (message.getGainObjects() != null)
/*      */       {
/* 1198 */         for (PerceptionMessage.ObjectNote gainNote : message.getGainObjects()) {
/* 1199 */           gainNote.setObjectInfo(null);
/*      */         }
/*      */       }
/*      */ 
/* 1203 */       Engine.getAgent().sendBroadcast(message);
/*      */ 
/* 1205 */       if (pOid.equals(perceiverOid)) {
/* 1206 */         return Integer.valueOf(count);
/*      */       }
/* 1208 */       return null;
/*      */     }
/* 1210 */     if ((p instanceof FixedPerceiver)) {
/* 1211 */       FixedPerceiver fixedP = (FixedPerceiver)p;
/* 1212 */       for (WMWorldNode freeNode : newsAndFrees.getFreedElements())
/* 1213 */         freeObjectForFixedPerceiver(fixedP, freeNode);
/* 1214 */       for (WMWorldNode newNode : newsAndFrees.getNewElements())
/* 1215 */         newObjectForFixedPerceiver(fixedP, newNode);
/* 1216 */       return null;
/*      */     }
/* 1218 */     throw new RuntimeException("unknown perceiver type");
/*      */   }
/*      */ 
/*      */   public void preUpdate(PerceptionFilter filter, FilterUpdate.Instruction instruction, AgentHandle sender, SubscriptionHandle sub)
/*      */   {
/* 1228 */     if ((instruction.opCode == 2) && (instruction.fieldId == 1))
/*      */     {
/* 1230 */       MessageType perceptionType = null;
/* 1231 */       if (filter.getMessageTypes().contains(WorldManagerClient.MSG_TYPE_PERCEPTION_INFO))
/* 1232 */         perceptionType = WorldManagerClient.MSG_TYPE_PERCEPTION_INFO;
/* 1233 */       else if (filter.getMessageTypes().contains(WorldManagerClient.MSG_TYPE_PERCEPTION))
/* 1234 */         perceptionType = WorldManagerClient.MSG_TYPE_PERCEPTION;
/*      */       else {
/* 1236 */         return;
/*      */       }
/* 1238 */       OID targetOid = (OID)instruction.value;
/* 1239 */       AOObject obj = (AOObject)getWorldManagerEntity(targetOid);
/* 1240 */       if (obj == null) {
/* 1241 */         return;
/*      */       }
/* 1243 */       WMWorldNode targetNode = (WMWorldNode)obj.worldNode();
/* 1244 */       if (targetNode == null) {
/* 1245 */         return; } 
/*      */ QuadTree quadtree = (QuadTree)this.quadtrees.get(targetNode.getInstanceOid());
/*      */ 
/* 1252 */       quadtree.getLock().lock();
/*      */       Collection perceivables;
/*      */       PerceptionMessage message;
/*      */       try { targetNode = (WMWorldNode)obj.worldNode();
/* 1255 */         if (targetNode == null) return;
/* 1257 */         perceivables = quadtree.getElementPerceivables(targetNode);
/* 1258 */         message = new PerceptionMessage(perceptionType, targetOid);
/* 1259 */         for (WMWorldNode gainNode : perceivables) {
/* 1260 */           AOObject gainObj = gainNode.getObject();
/* 1261 */           OID gainOid = gainObj.getOid();
/* 1262 */           if (gainOid.equals(targetOid))
/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 1267 */           PerceptionMessage.ObjectNote note = new PerceptionMessage.ObjectNote(targetOid, gainOid, gainObj.getType());
/*      */ 
/* 1270 */           if (perceptionType == WorldManagerClient.MSG_TYPE_PERCEPTION_INFO)
/*      */           {
/* 1272 */             note.setObjectInfo(makePerceptionInfo(gainOid, gainObj));
/*      */           }
/* 1274 */           message.gainObject(note);
/*      */         }
/*      */       } finally {
/* 1277 */         quadtree.getLock().unlock();
/*      */       }
/* 1279 */       if (perceivables.size() > 0) {
/* 1280 */         if (Log.loggingDebug)
/* 1281 */           Log.debug("PerceptionUpdateTrigger: sending initial perception for oid=" + targetOid + " agent=" + sender.getAgentName());
/* 1282 */         Engine.getAgent().sendDirect(message, sender, sub);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void postUpdate(PerceptionFilter filter, FilterUpdate.Instruction instruction, AgentHandle sender, SubscriptionHandle sub)
/*      */   {
/*      */   }
/*      */ 
/*      */   public PathInfo getPathInfo()
/*      */   {
/* 1297 */     return this.pathInfo;
/*      */   }
/*      */ 
/*      */   public void setPathInfo(PathInfo pathInfo) {
/* 1301 */     this.pathInfo = pathInfo;
/* 1302 */     PathSearcher.createPathSearcher(pathInfo, World.getGeometry());
/*      */   }
/*      */ 
/*      */   protected WorldManagerClient.ObjectInfo makeObjectInfo(OID oid)
/*      */   {
/* 1345 */     if (Log.loggingDebug) {
/* 1346 */       log.debug("makeObjectInfo: oid=" + oid);
/*      */     }
/* 1348 */     Entity entity = getWorldManagerEntity(oid);
/* 1349 */     if (entity == null) {
/* 1350 */       return null;
/*      */     }
/* 1352 */     if (!(entity instanceof AOObject)) {
/* 1353 */       throw new AORuntimeException("entity is not AOObject");
/*      */     }
/* 1355 */     AOObject obj = (AOObject)entity;
/*      */ 
/* 1357 */     InterpolatedWorldNode.InterpolatedDirLocOrientTime before = null;
/* 1358 */     if (Log.loggingDebug) {
/* 1359 */       before = obj.getDirLocOrientTime();
/*      */     }
/*      */ 
/* 1362 */     CaptureInterpWorldNode capture = new CaptureInterpWorldNode((InterpolatedWorldNode)obj.getProperty("aoobj.wnode"));
/*      */ 
/* 1364 */     capture.getLoc();
/* 1365 */     InterpolatedWorldNode.InterpolatedDirLocOrientTime vals = capture.getDirLocOrientTime();
/*      */ 
/* 1368 */     if (Log.loggingDebug) {
/* 1369 */       float distance = Point.distanceTo(vals.interpLoc, before.interpLoc);
/* 1370 */       if (distance != 0.0F) {
/* 1371 */         Log.debug("DISTANCE " + distance + " TIME " + (vals.lastInterp - before.lastInterp) + " DIR " + vals.dir + " oid=" + obj.getOid());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1376 */     WorldManagerClient.ObjectInfo objInfo = new WorldManagerClient.ObjectInfo();
/*      */ 
/* 1379 */     objInfo.instanceOid = capture.getInstanceOid();
/* 1380 */     objInfo.oid = obj.getOid();
/* 1381 */     objInfo.name = obj.getName();
/* 1382 */     objInfo.accountOid = null;
/* 1383 */     objInfo.loc = vals.interpLoc;
/* 1384 */     objInfo.orient = vals.orient;
/* 1385 */     objInfo.scale = obj.scale();
/* 1386 */     objInfo.objType = obj.getType();
/* 1387 */     objInfo.dir = vals.dir;
/* 1388 */     objInfo.lastInterp = vals.lastInterp;
/*      */ 
/* 1390 */     if (objInfo.objType == ObjectTypes.mob) {
/* 1391 */       Object pathMsgObject = obj.getProperty(WorldManagerClient.MOB_PATH_PROPERTY);
/* 1392 */       if (pathMsgObject != null) {
/* 1393 */         WorldManagerClient.MobPathMessage pathMsg = (WorldManagerClient.MobPathMessage)pathMsgObject;
/* 1394 */         objInfo.setProperty(WorldManagerClient.MOB_PATH_PROPERTY, pathMsg);
/*      */       }
/*      */     }
/*      */ 
/* 1398 */     WMWorldNode wnode = (WMWorldNode)obj.worldNode();
/* 1399 */     Boolean b = wnode.getFollowsTerrain();
/* 1400 */     objInfo.followsTerrain = (b == null ? false : b.booleanValue());
/*      */ 
/* 1402 */     return objInfo;
/*      */   }
/*      */ 
/*      */   private List<OID> getInstanceObjectsIn(OID instanceOid, Point loc, Integer radius, ObjectType objectType)
/*      */   {
/* 1483 */     Entity[] entities = EntityManager.getAllEntitiesByNamespace(Namespace.WORLD_MANAGER);
/* 1484 */     List objectsIn = new ArrayList();
/* 1485 */     if (objectType != null) {
/* 1486 */       for (Entity entity : entities) {
/* 1487 */         OID entityOid = entity.getOid();
/* 1488 */         BasicWorldNode entityWorldNode = ((AOObject)getWorldManagerEntity(entityOid)).baseWorldNode();
/* 1489 */         if ((entity.getType().isA(objectType)) && (instanceOid.equals(entityWorldNode.getInstanceOid()))) {
/* 1490 */           Log.debug("[CYC][1] entityType: " + entity.getType() + ", objectType: " + objectType);
/* 1491 */           Point entityLoc = entityWorldNode.getLoc();
/* 1492 */           Log.debug("[CYC][1] loc: " + loc + ", entityLoc: " + entityLoc + ", entityName: " + entity.getName());
/* 1493 */           if (Math.round(Point.distanceTo(loc, entityLoc)) <= radius.intValue()) {
/* 1494 */             objectsIn.add(entityOid);
/*      */           }
/* 1496 */           Log.debug("[CYC][1] distance: " + Math.round(Point.distanceTo(loc, entityLoc)) + ", radius: " + radius);
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1501 */       for (Entity entity : entities) {
/* 1502 */         OID entityOid = entity.getOid();
/* 1503 */         BasicWorldNode entityWorldNode = ((AOObject)getWorldManagerEntity(entityOid)).baseWorldNode();
/* 1504 */         if (instanceOid.equals(entityWorldNode.getInstanceOid())) {
/* 1505 */           Log.debug("[CYC][2] entityType: " + entity.getType());
/* 1506 */           Point entityLoc = entityWorldNode.getLoc();
/* 1507 */           Log.debug("[CYC][2] loc: " + loc + ", entityLoc: " + entityLoc + ", entityName: " + entity.getName());
/* 1508 */           if (Math.round(Point.distanceTo(loc, entityLoc)) <= radius.intValue()) {
/* 1509 */             objectsIn.add(entityOid);
/*      */           }
/* 1511 */           Log.debug("[CYC][2] distance: " + Math.round(Point.distanceTo(loc, entityLoc)) + ", radius: " + radius);
/*      */         }
/*      */       }
/*      */     }
/* 1515 */     return objectsIn;
/*      */   }
/*      */ 
/*      */   private List<OID> getObjectsIn(Point loc, Integer radius, ObjectType objectType)
/*      */   {
/* 1520 */     Entity[] entities = EntityManager.getAllEntitiesByNamespace(Namespace.WORLD_MANAGER);
/* 1521 */     List objectsIn = new ArrayList();
/* 1522 */     if (objectType != null) {
/* 1523 */       for (Entity entity : entities) {
/* 1524 */         if (entity.getType().isA(objectType)) {
/* 1525 */           OID entityOid = entity.getOid();
/* 1526 */           BasicWorldNode entityWorldNode = ((AOObject)getWorldManagerEntity(entityOid)).baseWorldNode();
/* 1527 */           Point entityLoc = entityWorldNode.getLoc();
/* 1528 */           if (Math.round(Point.distanceTo(loc, entityLoc)) <= radius.intValue()) {
/* 1529 */             objectsIn.add(entityOid);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1535 */       for (Entity entity : entities) {
/* 1536 */         OID entityOid = entity.getOid();
/* 1537 */         BasicWorldNode entityWorldNode = ((AOObject)getWorldManagerEntity(entityOid)).baseWorldNode();
/* 1538 */         Point entityLoc = entityWorldNode.getLoc();
/* 1539 */         if (Math.round(Point.distanceTo(loc, entityLoc)) <= radius.intValue()) {
/* 1540 */           objectsIn.add(entityOid);
/*      */         }
/*      */       }
/*      */     }
/* 1544 */     return objectsIn;
/*      */   }
/*      */ 
/*      */   WorldManagerInstance createInstanceEntity(OID instanceOid)
/*      */   {
/* 1841 */     WorldManagerInstance instance = new WorldManagerInstance(instanceOid);
/* 1842 */     initializeInstance(instance);
/*      */ 
/* 1844 */     EntityManager.registerEntityByNamespace(instance, WorldManagerClient.INSTANCE_NAMESPACE);
/*      */ 
/* 1847 */     return instance;
/*      */   }
/*      */ 
/*      */   void initializeInstance(WorldManagerInstance instance)
/*      */   {
/* 1852 */     Geometry localGeo = Geometry.maxGeometry();
/* 1853 */     if (localGeo == null) {
/* 1854 */       throw new RuntimeException("null local geometry");
/*      */     }
/*      */ 
/* 1858 */     QuadTree quadtree = new QuadTree(Geometry.maxGeometry(), this.defaultWorldManagerHysteresis);
/*      */ 
/* 1860 */     this.quadtrees.put(instance.getOid(), quadtree);
/*      */ 
/* 1862 */     quadtree.setMaxObjects(this.maxObjects);
/* 1863 */     quadtree.setMaxDepth(this.maxDepth);
/* 1864 */     quadtree.setLocalGeometry(localGeo);
/*      */ 
/* 1866 */     instance.setQuadTree(quadtree);
/*      */   }
/*      */ 
/*      */   void hostInstance(OID masterOid, Geometry localGeo)
/*      */   {
/* 1871 */     WorldManagerPlugin.WorldManagerFilter.InstanceGeometry instanceGeo = new WorldManagerPlugin.WorldManagerFilter.InstanceGeometry();
/*      */ 
/* 1873 */     instanceGeo.instanceOid = masterOid;
/* 1874 */     instanceGeo.geometry = new ArrayList(1);
/* 1875 */     instanceGeo.geometry.add(localGeo);
/*      */ 
/* 1878 */     FilterUpdate filterUpdate = new FilterUpdate();
/* 1879 */     filterUpdate.addFieldValue(1, instanceGeo);
/*      */ 
/* 1881 */     ((WorldManagerFilter)selectionFilter).applyFilterUpdate(filterUpdate);
/* 1882 */     Engine.getAgent().applyFilterUpdate(selectionSubscription.longValue(), filterUpdate, 1);
/*      */ 
/* 1885 */     filterUpdate = new FilterUpdate();
/* 1886 */     filterUpdate.addFieldValue(1, instanceGeo);
/*      */ 
/* 1888 */     this.newRegionFilter.applyFilterUpdate(filterUpdate);
/* 1889 */     Engine.getAgent().applyFilterUpdate(this.newRegionSub, filterUpdate, 1);
/*      */   }
/*      */ 
/*      */   void unhostInstance(OID oid)
/*      */   {
/* 1896 */     FilterUpdate filterUpdate = new FilterUpdate();
/* 1897 */     filterUpdate.removeFieldValue(1, oid);
/* 1898 */     ((WorldManagerFilter)selectionFilter).applyFilterUpdate(filterUpdate);
/* 1899 */     Engine.getAgent().applyFilterUpdate(selectionSubscription.longValue(), filterUpdate, 1);
/*      */ 
/* 1902 */     filterUpdate = new FilterUpdate();
/* 1903 */     filterUpdate.removeFieldValue(1, oid);
/* 1904 */     this.newRegionFilter.applyFilterUpdate(filterUpdate);
/* 1905 */     Engine.getAgent().applyFilterUpdate(this.newRegionSub, filterUpdate, 1);
/*      */   }
/*      */ 
/*      */   public String getInstanceInfoString(OID instanceOid)
/*      */   {
/* 1943 */     String info = "";
/* 1944 */     Entity entity = EntityManager.getEntityByNamespace(instanceOid, WorldManagerClient.INSTANCE_NAMESPACE);
/*      */ 
/* 1946 */     if (entity != null) {
/* 1947 */       info = info + "Entity:               yes\n";
/* 1948 */       info = info + "Entity class:         " + entity.getClass().getSimpleName() + "\n";
/* 1949 */       info = info + "Entity name:          " + entity.getName() + "\n";
/*      */     }
/*      */     else {
/* 1952 */       info = info + "Entity:               no\n";
/*      */     }
/* 1954 */     QuadTree quadtree = (QuadTree)this.quadtrees.get(instanceOid);
/* 1955 */     if (quadtree != null)
/* 1956 */       info = info + "Quad tree:            yes\n";
/*      */     else {
/* 1958 */       info = info + "Quad tree:            no\n";
/*      */     }
/* 1960 */     boolean rc = this.subObjectFilter.hasSubject(instanceOid);
/* 1961 */     info = info + "Sub-object filter:    " + rc + "\n";
/*      */ 
/* 1963 */     List geometry = this.newRegionFilter.getInstance(instanceOid);
/* 1964 */     if (geometry != null) {
/* 1965 */       info = info + "New region filter:    yes\n";
/* 1966 */       info = info + "New region geometry:  " + geometry.get(0) + "\n";
/*      */     }
/*      */     else {
/* 1969 */       info = info + "New region filter:    no\n";
/*      */     }
/* 1971 */     WorldManagerFilter filter = (WorldManagerFilter)selectionFilter;
/* 1972 */     geometry = filter.getInstance(instanceOid);
/* 1973 */     if (geometry != null) {
/* 1974 */       info = info + "Selection filter:     yes\n";
/* 1975 */       info = info + "Selection geometry:   " + geometry.get(0) + "\n";
/*      */     }
/*      */     else {
/* 1978 */       info = info + "Selection filter:     no\n";
/*      */     }
/* 1980 */     return info;
/*      */   }
/*      */ 
/*      */   protected AOObject generateWorldManagerSubObject(Template template, OID masterOid)
/*      */   {
/* 2037 */     AOObject wObj = new AOObject(masterOid);
/*      */ 
/* 2039 */     Map props = template.getSubMap(Namespace.WORLD_MANAGER);
/* 2040 */     if (props == null) {
/* 2041 */       Log.warn("WorldManagerPlugin.generateSubObject: no props in ns " + Namespace.WORLD_MANAGER);
/*      */ 
/* 2043 */       return null;
/*      */     }
/*      */ 
/* 2047 */     for (Map.Entry entry : props.entrySet()) {
/* 2048 */       String key = (String)entry.getKey();
/* 2049 */       Serializable value = (Serializable)entry.getValue();
/* 2050 */       if (!key.startsWith(":")) {
/* 2051 */         wObj.setProperty(key, value);
/*      */       }
/*      */     }
/*      */ 
/* 2055 */     ObjectType objType = (ObjectType)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE);
/*      */ 
/* 2058 */     if (objType != null) {
/* 2059 */       wObj.setType(objType);
/*      */     }
/* 2061 */     return wObj;
/*      */   }
/*      */ 
/*      */   protected void subscribeForMob(OID oid)
/*      */   {
/* 2067 */     if (Log.loggingDebug) {
/* 2068 */       log.debug("subscribeForMob: oid=" + oid);
/*      */     }
/* 2070 */     if (this.mobFilter.addSubjectIfMissing(oid)) {
/* 2071 */       FilterUpdate filterUpdate = new FilterUpdate();
/* 2072 */       filterUpdate.addFieldValue(2, oid);
/* 2073 */       Engine.getAgent().applyFilterUpdate(this.mobSubId, filterUpdate, 1);
/*      */     }
/*      */     else
/*      */     {
/* 2077 */       Log.debug("subscribeForMob: mobFilter double bind oid=" + oid);
/*      */     }
/*      */ 
/* 2080 */     if (this.mobRPCFilter.addSubjectIfMissing(oid)) {
/* 2081 */       FilterUpdate filterUpdate = new FilterUpdate();
/* 2082 */       filterUpdate.addFieldValue(2, oid);
/* 2083 */       Engine.getAgent().applyFilterUpdate(this.mobRPCSubId, filterUpdate, 1);
/*      */     }
/*      */     else
/*      */     {
/* 2087 */       Log.debug("subscribeForMob: mobRPCFilter double bind oid=" + oid);
/*      */     }
/*      */ 
/* 2090 */     subscribeForObject(oid);
/*      */   }
/*      */ 
/*      */   protected void subscribeForObject(OID masterOid)
/*      */   {
/* 2096 */     if (Log.loggingDebug) {
/* 2097 */       log.debug("subscribeForObject: oid=" + masterOid);
/*      */     }
/* 2099 */     if (this.subObjectFilter.addSubjectIfMissing(masterOid)) {
/* 2100 */       FilterUpdate filterUpdate = new FilterUpdate();
/* 2101 */       filterUpdate.addFieldValue(2, masterOid);
/* 2102 */       Engine.getAgent().applyFilterUpdate(subObjectSubscription.longValue(), filterUpdate, 1);
/*      */     }
/*      */     else
/*      */     {
/* 2106 */       Log.debug("subscribeForObject: subObjectFilter double bind oid=" + masterOid);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void unsubscribeForMob(OID oid)
/*      */   {
/* 2113 */     if (Log.loggingDebug) {
/* 2114 */       log.debug("unsubscribeForObject: oid=" + oid);
/*      */     }
/* 2116 */     if (this.mobFilter.removeSubject(oid)) {
/* 2117 */       FilterUpdate filterUpdate = new FilterUpdate();
/* 2118 */       filterUpdate.removeFieldValue(2, oid);
/* 2119 */       Engine.getAgent().applyFilterUpdate(this.mobSubId, filterUpdate, 1);
/*      */     }
/*      */     else
/*      */     {
/* 2123 */       Log.debug("unsubscribeForObject: mobFilter double remove oid=" + oid);
/*      */     }
/*      */ 
/* 2126 */     if (this.mobRPCFilter.removeSubject(oid)) {
/* 2127 */       FilterUpdate filterUpdate = new FilterUpdate();
/* 2128 */       filterUpdate.removeFieldValue(2, oid);
/* 2129 */       Engine.getAgent().applyFilterUpdate(this.mobRPCSubId, filterUpdate, 1);
/*      */     }
/*      */     else
/*      */     {
/* 2133 */       Log.debug("unsubscribeForObject: mobRPCFilter double remove oid=" + oid);
/*      */     }
/*      */ 
/* 2136 */     unsubscribeForObject(oid);
/*      */   }
/*      */ 
/*      */   protected void unsubscribeForObject(OID oid)
/*      */   {
/* 2142 */     if (Log.loggingDebug) {
/* 2143 */       log.debug("unsubscribeForObject: oid=" + oid);
/*      */     }
/* 2145 */     if (this.subObjectFilter.removeSubject(oid)) {
/* 2146 */       FilterUpdate filterUpdate = new FilterUpdate();
/* 2147 */       filterUpdate.removeFieldValue(2, oid);
/* 2148 */       Engine.getAgent().applyFilterUpdate(subObjectSubscription.longValue(), filterUpdate, 1);
/*      */     }
/*      */     else
/*      */     {
/* 2152 */       Log.debug("unsubscribeForObject: subObjectFilter double remove oid=" + oid);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Integer spawnObject(AOObject obj, QuadTree<WMWorldNode> quadtree)
/*      */   {
/* 2163 */     WMWorldNode wnode = (WMWorldNode)obj.worldNode();
/* 2164 */     if (wnode == null) {
/* 2165 */       throw new AORuntimeException("obj has no world node: " + obj);
/*      */     }
/* 2167 */     AOObject backRef = wnode.getObject();
/* 2168 */     if (backRef == null) {
/* 2169 */       throw new AORuntimeException("obj wnode backref is null: " + obj);
/*      */     }
/* 2171 */     if (!backRef.getOid().equals(obj.getOid())) {
/* 2172 */       throw new AORuntimeException("obj wnode backref does not match self: " + obj);
/*      */     }
/*      */ 
/* 2177 */     MobilePerceiver p = obj.perceiver();
/* 2178 */     OID mobilePerceiverOid = null;
/* 2179 */     if (p != null) {
/* 2180 */       mobilePerceiverOid = obj.getMasterOid();
/* 2181 */       if (Log.loggingDebug) {
/* 2182 */         log.debug("spawnObject: registering perceiver cb: " + obj + ", masterOid " + mobilePerceiverOid);
/*      */       }
/* 2184 */       if (wnode.getPerceiver() == null) {
/* 2185 */         throw new AORuntimeException("wnode doesnt have perceiver, obj=" + obj);
/*      */       }
/* 2187 */       p.registerCallback(this);
/*      */     }
/* 2189 */     else if (Log.loggingDebug) {
/* 2190 */       log.debug("spawnObject: no perceiver for obj " + obj);
/*      */     }
/*      */ 
/* 2195 */     wnode.isLocal(true);
/* 2196 */     wnode.isSpawned(true);
/* 2197 */     Integer newsAndFressCount = quadtree.addElementReturnCountForPerceiver(wnode, mobilePerceiverOid);
/*      */ 
/* 2199 */     if (Log.loggingDebug)
/* 2200 */       log.debug("spawnObject: spawned obj: " + obj + ", wnode=" + wnode);
/* 2201 */     return newsAndFressCount;
/*      */   }
/*      */ 
/*      */   protected void despawnObject(AOObject obj)
/*      */   {
/* 2206 */     if (obj.isUser()) {
/* 2207 */       Engine.getPersistenceManager().setDirty(obj);
/*      */     }
/* 2209 */     WMWorldNode wnode = (WMWorldNode)obj.worldNode();
/* 2210 */     if (wnode == null) {
/* 2211 */       throw new AORuntimeException("obj has no world node: " + obj);
/*      */     }
/* 2213 */     QuadTree quadtree = (QuadTree)this.quadtrees.get(wnode.getInstanceOid());
/* 2214 */     if (quadtree == null) {
/* 2215 */       log.error("despawnObject: unknown instanceOid=" + wnode.getInstanceOid() + " oid=" + obj.getOid());
/*      */ 
/* 2217 */       return;
/*      */     }
/*      */ 
/* 2220 */     quadtree.getLock().lock();
/*      */     try {
/* 2222 */       if (wnode.getQuadNode() == null) return;
/* 2224 */       AOObject backRef = wnode.getObject();
/* 2225 */       if (backRef == null) {
/* 2226 */         throw new AORuntimeException("obj wnode backref is null: " + obj);
/*      */       }
/* 2228 */       if (!backRef.getOid().equals(obj.getOid())) {
/* 2229 */         throw new AORuntimeException("obj wnode backref does not match: " + obj);
/*      */       }
/*      */ 
/* 2233 */       wnode.isSpawned(false);
/*      */ 
/* 2236 */       boolean elementRemoved = quadtree.removeElement(wnode);
/*      */ 
/* 2239 */       if (Log.loggingDebug)
/* 2240 */         log.debug("despawnObject: despawned obj: " + obj + " with node removed: " + elementRemoved);
/*      */     } finally {
/* 2242 */       quadtree.getLock().unlock();
/*      */     }
/*      */ 
/* 2245 */     if (obj.isUser()) {
/* 2246 */       if (Log.loggingDebug) {
/* 2247 */         log.debug("despawnObject: removing regions for oid=" + obj.getOid());
/*      */       }
/* 2249 */       List regionList = new ArrayList(0);
/* 2250 */       synchronized (this.updater) {
/* 2251 */         this.updater.updateRegion(obj, regionList);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void sendDCMessage(AOObject obj)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected abstract DisplayContext getDisplayContext(OID paramOID);
/*      */ 
/*      */   protected void sendPropertyMessage(OID notifyOid, AOObject updateObj)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void sendTargetedPropertyMessage(OID targetOid, AOObject updateObj)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void sendWNodeMessage(OID oid, AOObject updateObj)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void sendObjectSoundMessage(OID notifyOid, AOObject updateObj, List<SoundData> soundData)
/*      */   {
/* 3303 */     WorldManagerClient.SoundMessage soundMsg = new WorldManagerClient.SoundMessage(updateObj.getOid());
/* 3304 */     soundMsg.setSoundData(soundData);
/* 3305 */     Engine.getAgent().sendBroadcast(soundMsg);
/*      */   }
/*      */ 
/*      */   public void registerRegionTrigger(String name, RegionTrigger trigger)
/*      */   {
/* 3312 */     this.regionTriggers.put(name, trigger);
/*      */   }
/*      */ 
/*      */   public Set<String> getPropertyExclusions()
/*      */   {
/* 3319 */     return this.propertyExclusions;
/*      */   }
/*      */ 
/*      */   public static class PathObjectCache
/*      */   {
/* 3262 */     protected Map<String, PathObject> cache = new HashMap();
/* 3263 */     protected static transient Lock lock = LockFactory.makeLock("PathObjectCache");
/*      */ 
/*      */     public PathObject getPathObject(String roomId)
/*      */     {
/* 3243 */       lock.lock();
/*      */       try {
/* 3245 */         PathObject localPathObject = (PathObject)this.cache.get(roomId);
/*      */         return localPathObject; } finally { lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public void setPathObject(String roomId, PathObject pathObject)
/*      */     {
/* 3253 */       lock.lock();
/*      */       try {
/* 3255 */         this.cache.put(roomId, pathObject);
/*      */       }
/*      */       finally {
/* 3258 */         lock.unlock();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class WorldManagerTransferFilter extends EnginePlugin.TransferFilter
/*      */   {
/* 3235 */     List<Geometry> geoList = new LinkedList();
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public WorldManagerTransferFilter()
/*      */     {
/*      */     }
/*      */ 
/*      */     public WorldManagerTransferFilter(Geometry g)
/*      */     {
/* 3208 */       addGeometry(g);
/*      */     }
/*      */ 
/*      */     public void addGeometry(Geometry g) {
/* 3212 */       this.geoList.add(g);
/*      */     }
/*      */ 
/*      */     public boolean matchesGeometry(Point loc) {
/* 3216 */       for (Geometry g : this.geoList) {
/* 3217 */         if (g.contains(loc)) {
/* 3218 */           Log.debug("WorldManagerTransferFilter.matchesGeometry: matched.  loc=" + loc + ", geometry=" + g);
/* 3219 */           return true;
/*      */         }
/*      */       }
/* 3222 */       Log.debug("WorldManagerTransferFilter.matchesGeometry: no geometries matched");
/* 3223 */       return false;
/*      */     }
/*      */ 
/*      */     public boolean matchesMap(Map propMap, Message msg) {
/* 3227 */       Point loc = (Point)propMap.get(WorldManagerClient.MSG_PROP_LOC);
/* 3228 */       if (loc == null) {
/* 3229 */         Log.debug("WorldManagerTransferFilter.matchesMap: no loc, msg=" + msg);
/* 3230 */         return false;
/*      */       }
/* 3232 */       return matchesGeometry(loc);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class LocationNamespaceFilter extends NamespaceFilter
/*      */   {
/* 3197 */     Geometry geometry = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public boolean matchesRest(Message msg)
/*      */     {
/* 3171 */       if ((msg instanceof ObjectManagerClient.GenerateSubObjectMessage)) {
/* 3172 */         ObjectManagerClient.GenerateSubObjectMessage genObjMsg = (ObjectManagerClient.GenerateSubObjectMessage)msg;
/* 3173 */         Template t = genObjMsg.getTemplate();
/* 3174 */         Point loc = (Point)t.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC);
/* 3175 */         if (loc == null) {
/* 3176 */           Log.warn("LocationNamespaceFilter: subobj msg has null loc");
/* 3177 */           return false;
/*      */         }
/* 3179 */         boolean rv = getGeometry().contains(loc);
/* 3180 */         if (Log.loggingDebug) {
/* 3181 */           Log.debug("LocationNamespaceFilter: geometry=" + getGeometry() + ", loc=" + loc + ", rv=" + rv);
/*      */         }
/* 3183 */         return rv;
/*      */       }
/*      */ 
/* 3186 */       return false;
/*      */     }
/*      */ 
/*      */     public void setGeometry(Geometry g)
/*      */     {
/* 3191 */       this.geometry = g;
/*      */     }
/*      */     public Geometry getGeometry() {
/* 3194 */       return this.geometry;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class WorldManagerInstance extends Entity
/*      */   {
/*      */     private transient QuadTree<WMWorldNode> quadtree;
/*      */     private transient Fog globalFog;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public WorldManagerInstance()
/*      */     {
/*      */     }
/*      */ 
/*      */     public WorldManagerInstance(OID instanceOid)
/*      */     {
/* 3130 */       super();
/*      */     }
/*      */ 
/*      */     public QuadTree<WMWorldNode> getQuadTree()
/*      */     {
/* 3135 */       return this.quadtree;
/*      */     }
/*      */ 
/*      */     public void setQuadTree(QuadTree<WMWorldNode> quadtree)
/*      */     {
/* 3140 */       this.quadtree = quadtree;
/*      */     }
/*      */ 
/*      */     public Fog getGlobalFog()
/*      */     {
/* 3146 */       if (this.globalFog == null) {
/* 3147 */         InstanceClient.InstanceInfo instanceInfo = InstanceClient.getInstanceInfo(getOid(), 16);
/*      */ 
/* 3150 */         this.globalFog = instanceInfo.fog;
/*      */       }
/* 3152 */       return this.globalFog;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class HostInstanceFilter extends MessageTypeFilter
/*      */   {
/*      */     private String pluginName;
/*      */ 
/*      */     public HostInstanceFilter()
/*      */     {
/*      */     }
/*      */ 
/*      */     public HostInstanceFilter(String pluginName)
/*      */     {
/* 3094 */       setPluginName(pluginName);
/*      */     }
/*      */ 
/*      */     public String getPluginName()
/*      */     {
/* 3099 */       return this.pluginName;
/*      */     }
/*      */ 
/*      */     public void setPluginName(String pluginName)
/*      */     {
/* 3104 */       this.pluginName = pluginName;
/*      */     }
/*      */ 
/*      */     public synchronized boolean matchRemaining(Message message)
/*      */     {
/* 3109 */       if (message.getMsgType() == WorldManagerClient.MSG_TYPE_HOST_INSTANCE)
/*      */       {
/* 3111 */         WorldManagerClient.HostInstanceMessage hostMsg = (WorldManagerClient.HostInstanceMessage)message;
/* 3112 */         return this.pluginName.equals(hostMsg.getPluginName());
/*      */       }
/*      */ 
/* 3115 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class WorldManagerFilter extends NamespaceFilter
/*      */   {
/*      */     public static final int FIELD_INSTANCES = 1;
/*      */     private String pluginName;
/* 3082 */     private Map<OID, List<Geometry>> instanceGeometry = new HashMap();
/*      */ 
/*      */     public WorldManagerFilter()
/*      */     {
/*      */     }
/*      */ 
/*      */     public WorldManagerFilter(String pluginName)
/*      */     {
/* 2899 */       setPluginName(pluginName);
/*      */     }
/*      */ 
/*      */     public String getPluginName()
/*      */     {
/* 2904 */       return this.pluginName;
/*      */     }
/*      */ 
/*      */     public void setPluginName(String pluginName)
/*      */     {
/* 2909 */       this.pluginName = pluginName;
/*      */     }
/*      */ 
/*      */     public void addInstance(OID instanceOid, Geometry geometry)
/*      */     {
/* 2915 */       List geoList = new ArrayList();
/* 2916 */       geoList.add(geometry);
/* 2917 */       this.instanceGeometry.put(instanceOid, geoList);
/*      */     }
/*      */ 
/*      */     public void removeInstance(OID instanceOid)
/*      */     {
/* 2922 */       this.instanceGeometry.remove(instanceOid);
/*      */     }
/*      */ 
/*      */     public List<Geometry> getInstance(OID instanceOid)
/*      */     {
/* 2927 */       return (List)this.instanceGeometry.get(instanceOid);
/*      */     }
/*      */ 
/*      */     public synchronized boolean matchRemaining(Message message)
/*      */     {
/* 2932 */       OID instanceOid = null;
/* 2933 */       Point location = null;
/* 2934 */       MessageType type = message.getMsgType();
/* 2935 */       Namespace namespace = null;
/*      */ 
/* 2937 */       if ((!super.matchRemaining(message)) && 
/* 2938 */         (type != WorldManagerClient.MSG_TYPE_NEW_REGION) && (type != WorldManagerClient.MSG_TYPE_PLAYER_PATH_WM_REQ))
/*      */       {
/* 2940 */         return false;
/*      */       }
/*      */ 
/* 2946 */       if ((type == ObjectManagerClient.MSG_TYPE_GENERATE_SUB_OBJECT) && ((message instanceof ObjectManagerClient.GenerateSubObjectMessage)))
/*      */       {
/* 2948 */         ObjectManagerClient.GenerateSubObjectMessage genMsg = (ObjectManagerClient.GenerateSubObjectMessage)message;
/*      */ 
/* 2950 */         Template template = genMsg.getTemplate();
/*      */ 
/* 2952 */         String targetPlugin = (String)template.get(Namespace.WM_INSTANCE, ":wmName");
/*      */ 
/* 2955 */         if (targetPlugin != null)
/*      */         {
/* 2957 */           return targetPlugin.equals(this.pluginName);
/*      */         }
/*      */ 
/* 2962 */         location = (Point)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC);
/*      */ 
/* 2964 */         if (location == null) {
/* 2965 */           Log.error("WorldManagerFilter: generate msg has null loc, oid=" + genMsg.getSubject());
/* 2966 */           return false;
/*      */         }
/* 2968 */         instanceOid = (OID)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE);
/*      */ 
/* 2970 */         if (instanceOid == null) {
/* 2971 */           Log.error("WorldManagerFilter: generate msg has null instanceOid, oid=" + genMsg.getSubject());
/* 2972 */           return false;
/*      */         }
/*      */       }
/* 2975 */       else if (type == ObjectManagerClient.MSG_TYPE_LOAD_SUBOBJECT) {
/* 2976 */         if ((message instanceof WorldManagerClient.LoadSubObjectMessage)) {
/* 2977 */           WorldManagerClient.LoadSubObjectMessage loadMsg = (WorldManagerClient.LoadSubObjectMessage)message;
/*      */ 
/* 2979 */           instanceOid = loadMsg.getInstanceOid();
/* 2980 */           location = loadMsg.getLocation();
/*      */         }
/* 2982 */         else if ((message instanceof ObjectManagerClient.LoadSubObjectMessage)) {
/* 2983 */           ObjectManagerClient.LoadSubObjectMessage loadMsg = (ObjectManagerClient.LoadSubObjectMessage)message;
/*      */ 
/* 2985 */           instanceOid = loadMsg.getSubject();
/* 2986 */           namespace = loadMsg.getNamespace();
/*      */         }
/*      */       } else {
/* 2989 */         if (type == WorldManagerClient.MSG_TYPE_NEW_REGION) {
/* 2990 */           WorldManagerClient.NewRegionMessage regionMsg = (WorldManagerClient.NewRegionMessage)message;
/* 2991 */           instanceOid = regionMsg.getInstanceOid();
/* 2992 */           List localGeometry = (List)this.instanceGeometry.get(instanceOid);
/*      */ 
/* 2994 */           return localGeometry != null;
/*      */         }
/*      */ 
/* 2999 */         if (type == WorldManagerClient.MSG_TYPE_PLAYER_PATH_WM_REQ) {
/* 3000 */           WorldManagerClient.PlayerPathWMReqMessage reqMsg = (WorldManagerClient.PlayerPathWMReqMessage)message;
/* 3001 */           instanceOid = reqMsg.getInstanceOid();
/*      */         }
/*      */       }
/* 3003 */       if (instanceOid != null) {
/* 3004 */         List localGeometry = (List)this.instanceGeometry.get(instanceOid);
/* 3005 */         if (localGeometry == null) {
/* 3006 */           return false;
/*      */         }
/*      */ 
/* 3009 */         if ((namespace == Namespace.WM_INSTANCE) && (location == null)) {
/* 3010 */           return true;
/*      */         }
/*      */ 
/* 3013 */         for (Geometry geometry : localGeometry) {
/* 3014 */           if (geometry.contains(location))
/* 3015 */             return true;
/*      */         }
/* 3017 */         return false;
/*      */       }
/*      */ 
/* 3020 */       return false;
/*      */     }
/*      */ 
/*      */     public synchronized boolean applyFilterUpdate(FilterUpdate update)
/*      */     {
/* 3025 */       List instructions = update.getInstructions();
/*      */ 
/* 3028 */       for (FilterUpdate.Instruction instruction : instructions) {
/* 3029 */         switch (instruction.opCode) {
/*      */         case 2:
/* 3031 */           if (instruction.fieldId == 1) {
/* 3032 */             InstanceGeometry instanceGeo = (InstanceGeometry)instruction.value;
/*      */ 
/* 3034 */             if (Log.loggingDebug)
/* 3035 */               Log.debug("WorldManagerFilter ADD INSTANCE " + instruction.value);
/* 3036 */             this.instanceGeometry.put(instanceGeo.instanceOid, instanceGeo.geometry);
/*      */           }
/*      */           else
/*      */           {
/* 3040 */             Log.error("WorldManagerFilter: invalid fieldId " + instruction.fieldId);
/*      */           }
/* 3042 */           break;
/*      */         case 3:
/* 3044 */           if (instruction.fieldId == 1) {
/* 3045 */             if (Log.loggingDebug)
/* 3046 */               Log.debug("WorldManagerFilter REMOVE INSTANCE " + instruction.value);
/* 3047 */             this.instanceGeometry.remove((OID)instruction.value);
/*      */           }
/*      */           else {
/* 3050 */             Log.error("WorldManagerFilter: invalid fieldId " + instruction.fieldId);
/*      */           }
/* 3052 */           break;
/*      */         case 1:
/* 3054 */           Log.error("WorldManagerFilter: OP_SET is not supported");
/* 3055 */           break;
/*      */         default:
/* 3057 */           Log.error("WorldManagerFilter: invalid opCode " + instruction.opCode);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3062 */       return false;
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 3066 */       return "[WorldManagerFilter " + toStringInternal() + "]";
/*      */     }
/*      */ 
/*      */     protected String toStringInternal() {
/* 3070 */       return super.toStringInternal() + " pluginName=" + this.pluginName + " instances=" + this.instanceGeometry.size();
/*      */     }
/*      */ 
/*      */     public static class InstanceGeometry
/*      */     {
/*      */       OID instanceOid;
/*      */       List<Geometry> geometry;
/*      */     }
/*      */   }
/*      */ 
/*      */   class PlayerPathWMReqHook
/*      */     implements Hook
/*      */   {
/*      */     PlayerPathWMReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2842 */       WorldManagerClient.PlayerPathWMReqMessage reqMsg = (WorldManagerClient.PlayerPathWMReqMessage)msg;
/* 2843 */       OID playerOid = reqMsg.getPlayerOid();
/* 2844 */       String roomId = reqMsg.getRoomId();
/* 2845 */       PathObject pathObject = WorldManagerPlugin.pathObjectCache.getPathObject(roomId);
/*      */ 
/* 2849 */       List boundary = reqMsg.getBoundary();
/* 2850 */       List obstacles = reqMsg.getObstacles();
/* 2851 */       float avatarWidth = reqMsg.getAvatarWidth();
/* 2852 */       if (Log.loggingDebug) {
/* 2853 */         WorldManagerPlugin.log.debug("PlayerPathReqWMHook.processMessage: Received a PLAYER_PATH_REQ message for player " + playerOid + " and roomId " + roomId + " with boundary " + boundary + " and obstacles " + obstacles);
/*      */       }
/*      */ 
/* 2856 */       if ((boundary == null ? 1 : 0) != (obstacles == null ? 1 : 0)) {
/* 2857 */         WorldManagerPlugin.log.error("PlayerPathReqWMHook.processMessage: For player " + playerOid + ", received a PLAYER_PATH_REQ message for roomId " + roomId + ", but boundary is " + boundary + " but obstacles is " + obstacles);
/*      */ 
/* 2859 */         return false;
/*      */       }
/*      */ 
/* 2863 */       if ((pathObject == null) && (boundary == null)) {
/* 2864 */         WorldManagerPlugin.log.error("PlayerPathReqWMHook.processMessage: For player " + playerOid + ", received a PLAYER_PATH_REQ message for roomId " + roomId + ", but didn't find roomId in the cache and no no boundary or obstacles were supplied.");
/*      */ 
/* 2866 */         return false;
/*      */       }
/*      */ 
/* 2870 */       if (boundary != null) {
/* 2871 */         pathObject = new PathObject("Player " + playerOid + ", roomId " + roomId, avatarWidth, boundary, obstacles);
/* 2872 */         WorldManagerPlugin.pathObjectCache.setPathObject(roomId, pathObject);
/*      */       }
/*      */ 
/* 2875 */       PathFinderValue value = PathSearcher.findPath(playerOid, pathObject, reqMsg.getStart(), reqMsg.getDest(), avatarWidth / 2.0F);
/* 2876 */       if (value == null) {
/* 2877 */         WorldManagerPlugin.log.error("PlayerPathReqWMHook.processMessage: For player " + playerOid + ", roomId " + roomId + ", start " + reqMsg.getStart() + ", dest " + reqMsg.getDest() + ", cound not generate path!");
/*      */       }
/*      */       else {
/* 2880 */         List pathPoints = new LinkedList();
/* 2881 */         for (AOVector p : value.getPath())
/* 2882 */           pathPoints.add(new Point(p));
/* 2883 */         WorldManagerClient.MobPathMessage mobPathMsg = new WorldManagerClient.MobPathMessage(playerOid, System.currentTimeMillis(), "spline", reqMsg.getSpeed(), value.getTerrainString(), pathPoints);
/*      */ 
/* 2885 */         Engine.getAgent().sendBroadcast(mobPathMsg);
/*      */       }
/* 2887 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetPluginStatusHook
/*      */     implements Hook
/*      */   {
/*      */     GetPluginStatusHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2830 */       LinkedHashMap status = new LinkedHashMap();
/*      */ 
/* 2832 */       status.put("plugin", WorldManagerPlugin.this.getName());
/* 2833 */       status.put("entity", Integer.valueOf(EntityManager.getEntityCount()));
/* 2834 */       status.put("instance", Integer.valueOf(WorldManagerPlugin.this.quadtrees.size()));
/* 2835 */       Engine.getAgent().sendObjectResponse(msg, status);
/* 2836 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class ModifyDisplayContextHook
/*      */     implements Hook
/*      */   {
/*      */     ModifyDisplayContextHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2745 */       WorldManagerClient.ModifyDisplayContextMessage dMsg = (WorldManagerClient.ModifyDisplayContextMessage)msg;
/*      */ 
/* 2748 */       OID oid = dMsg.getSubject();
/* 2749 */       byte action = dMsg.getAction();
/* 2750 */       String base = dMsg.getBase();
/* 2751 */       List submeshes = dMsg.getSubmeshes();
/* 2752 */       String handle = dMsg.getChildDCHandle();
/* 2753 */       DisplayContext childDC = dMsg.getChildDC();
/*      */ 
/* 2755 */       AOObject obj = (AOObject)WorldManagerPlugin.this.getWorldManagerEntity(oid);
/* 2756 */       if (obj == null) {
/* 2757 */         Log.warn("ModifyDisplayContextHook: no obj: " + oid);
/* 2758 */         return false;
/*      */       }
/* 2760 */       obj.getLock().lock();
/*      */       try {
/* 2762 */         if (action == 1) {
/* 2763 */           if (Log.loggingDebug) {
/* 2764 */             WorldManagerPlugin.log.debug("ModifyDisplayContextHook: obj " + oid + ", action=REPLACE, submeshes.size() " + submeshes.size());
/* 2765 */             if (submeshes.size() > 0)
/* 2766 */               WorldManagerPlugin.log.debug("ModifyDisplayContextHook: first submesh " + submeshes.get(0));
/*      */           }
/* 2768 */           obj.displayContext(new DisplayContext(oid, base));
/* 2769 */           obj.displayContext().addSubmeshes(submeshes);
/*      */ 
/* 2771 */           WorldManagerPlugin.this.sendDCMessage(obj);
/* 2772 */         } else if (action == 2) {
/* 2773 */           if (Log.loggingDebug)
/* 2774 */             WorldManagerPlugin.log.debug("ModifyDisplayContextHook: obj " + oid + ", action=ADD");
/* 2775 */           obj.displayContext().addSubmeshes(submeshes);
/*      */ 
/* 2777 */           WorldManagerPlugin.this.sendDCMessage(obj);
/* 2778 */         } else if (action == 3) {
/* 2779 */           if (Log.loggingDebug)
/* 2780 */             WorldManagerPlugin.log.debug("ModifyDisplayContextHook: obj " + oid + ", action=ADD_CHILD");
/* 2781 */           if (handle == null) {
/* 2782 */             throw new AORuntimeException("ModifyDisplayContextHook: obj=" + oid + ", handle is null");
/*      */           }
/* 2784 */           obj.displayContext().addChildDC(handle, childDC);
/*      */ 
/* 2786 */           WorldManagerPlugin.this.sendDCMessage(obj);
/* 2787 */         } else if (action == 5) {
/* 2788 */           if (Log.loggingDebug)
/* 2789 */             WorldManagerPlugin.log.debug("ModifyDisplayContextHook: obj " + oid + ", action=REMOVE_CHILD");
/* 2790 */           if (handle == null) {
/* 2791 */             throw new AORuntimeException("ModifyDisplayContextHook: obj=" + oid + ", handle is null");
/*      */           }
/* 2793 */           DisplayContext rv = obj.displayContext().removeChildDC(handle);
/*      */           int i;
/* 2794 */           if (rv == null) {
/* 2795 */             Log.error("ModifyDisplayContextHook: obj=" + oid + " did not find child to remove");
/* 2796 */             i = 0;
/*      */             return i;
/*      */           }
/* 2798 */           if (Log.loggingDebug) {
/* 2799 */             WorldManagerPlugin.log.debug("ModifyDisplayContextHook: sending out detach msg for oid " + oid + ", dcObjRef=" + childDC.getObjRef() + ", socket=" + handle);
/*      */           }
/* 2801 */           if (childDC.getObjRef() == null) {
/* 2802 */             Log.error("ModifyDisplayContextHook: remove child dc, obj ref is null");
/* 2803 */             i = 0;
/*      */             return i;
/*      */           }
/* 2805 */           WorldManagerClient.DetachMessage detachMsg = new WorldManagerClient.DetachMessage(oid, childDC.getObjRef(), handle);
/*      */ 
/* 2807 */           Engine.getAgent().sendBroadcast(detachMsg);
/* 2808 */         } else if (action == 4) {
/* 2809 */           if (Log.loggingDebug)
/* 2810 */             WorldManagerPlugin.log.debug("ModifyDisplayContextHook: obj " + oid + ", action=REMOVE");
/* 2811 */           obj.displayContext().removeSubmeshes(submeshes);
/*      */ 
/* 2813 */           WorldManagerPlugin.this.sendDCMessage(obj);
/*      */         }
/*      */         else {
/* 2816 */           throw new AORuntimeException("unknown action type");
/*      */         }
/*      */       } finally {
/* 2819 */         obj.getLock().unlock();
/*      */       }
/*      */ 
/* 2823 */       Engine.getPersistenceManager().setDirty(obj);
/* 2824 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class NewRegionHook
/*      */     implements Hook
/*      */   {
/*      */     NewRegionHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2716 */       WorldManagerClient.NewRegionMessage rMsg = (WorldManagerClient.NewRegionMessage)msg;
/*      */ 
/* 2718 */       Region region = rMsg.getRegion();
/* 2719 */       Boundary b = region.getBoundary();
/*      */ 
/* 2721 */       OID instanceOid = rMsg.getInstanceOid();
/* 2722 */       QuadTree quadtree = (QuadTree)WorldManagerPlugin.this.quadtrees.get(instanceOid);
/* 2723 */       if (quadtree == null) {
/* 2724 */         WorldManagerPlugin.log.error("NewRegionHook: unknown instanceOid=" + instanceOid + " boundary=" + b + " region=" + region);
/*      */ 
/* 2726 */         return false;
/*      */       }
/*      */ 
/* 2730 */       RegionConfig dirLightConfig = region.getConfig(LightData.DirLightRegionType);
/*      */ 
/* 2732 */       if (dirLightConfig != null) {
/* 2733 */         dirLightConfig.setProperty("_oid", Engine.getOIDManager().getNextOid());
/*      */       }
/* 2735 */       if (Log.loggingDebug) {
/* 2736 */         WorldManagerPlugin.log.debug("NewRegionHook: boundary=" + b + " region=" + region + " instanceOid=" + instanceOid);
/*      */       }
/* 2738 */       quadtree.addRegion(region);
/* 2739 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class HostInstanceHook
/*      */     implements Hook
/*      */   {
/*      */     HostInstanceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2706 */       WorldManagerClient.HostInstanceMessage message = (WorldManagerClient.HostInstanceMessage)msg;
/* 2707 */       Geometry localGeo = Geometry.maxGeometry();
/* 2708 */       WorldManagerPlugin.this.hostInstance(message.getInstanceOid(), localGeo);
/* 2709 */       Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(true));
/* 2710 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class UpdateWNodeHook
/*      */     implements Hook
/*      */   {
/*      */     UpdateWNodeHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2666 */       WorldManagerClient.UpdateWorldNodeMessage uMsg = (WorldManagerClient.UpdateWorldNodeMessage)msg;
/*      */ 
/* 2668 */       OID objOid = uMsg.getSubject();
/* 2669 */       BasicWorldNode inNode = uMsg.getWorldNode();
/* 2670 */       if (!(inNode instanceof BasicWorldNode)) {
/* 2671 */         throw new RuntimeException("inWorldNode not BasicWorldNode");
/*      */       }
/* 2673 */       if (Log.loggingDebug) {
/* 2674 */         WorldManagerPlugin.log.debug("UpdateWNodeHook: inNode=" + inNode);
/*      */       }
/*      */ 
/* 2679 */       Entity entity = WorldManagerPlugin.this.getWorldManagerEntity(objOid);
/* 2680 */       if (entity == null) {
/* 2681 */         Log.warn("UpdateWNodeHook: entity not found oid=" + objOid);
/* 2682 */         return true;
/*      */       }
/* 2684 */       if (!(entity instanceof AOObject)) {
/* 2685 */         throw new RuntimeException("not aoobject");
/*      */       }
/* 2687 */       AOObject obj = (AOObject)entity;
/*      */ 
/* 2690 */       WorldNode node = obj.worldNode();
/* 2691 */       if (!(node instanceof WMWorldNode)) {
/* 2692 */         throw new RuntimeException("not a wmwnode");
/*      */       }
/* 2694 */       WMWorldNode wnode = (WMWorldNode)node;
/*      */ 
/* 2697 */       wnode.setLoc(inNode.getLoc());
/* 2698 */       wnode.setOrientation(inNode.getOrientation());
/* 2699 */       wnode.setDir(inNode.getDir());
/* 2700 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class FreeRemoteObjHook
/*      */     implements Hook
/*      */   {
/*      */     FreeRemoteObjHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2611 */       WorldManagerClient.FreeRemoteObjectMessage rMsg = (WorldManagerClient.FreeRemoteObjectMessage)msg;
/*      */ 
/* 2615 */       String targetSessionId = rMsg.getTargetSessionId();
/* 2616 */       if (!targetSessionId.equals(Engine.getAgent().getName())) {
/* 2617 */         throw new RuntimeException("session ids dont match");
/*      */       }
/*      */ 
/* 2620 */       OID freeObjOid = rMsg.getSubject();
/* 2621 */       if (freeObjOid == null) {
/* 2622 */         throw new RuntimeException("no remote objoid");
/*      */       }
/*      */ 
/* 2625 */       OID instanceOid = rMsg.getInstanceOid();
/* 2626 */       QuadTree quadtree = (QuadTree)WorldManagerPlugin.this.quadtrees.get(instanceOid);
/* 2627 */       if (quadtree == null) {
/* 2628 */         WorldManagerPlugin.log.error("FreeRemoteObjHook: unknown instanceOid=" + instanceOid + " oid=" + freeObjOid);
/*      */ 
/* 2630 */         return false;
/*      */       }
/*      */ 
/* 2634 */       Entity entity = WorldManagerPlugin.this.getWorldManagerEntity(freeObjOid);
/* 2635 */       if (entity == null) {
/* 2636 */         throw new RuntimeException("could not find entity " + freeObjOid);
/*      */       }
/*      */ 
/* 2639 */       AOObject obj = (AOObject)entity;
/* 2640 */       WMWorldNode wnode = (WMWorldNode)obj.worldNode();
/* 2641 */       if (Log.loggingDebug) {
/* 2642 */         WorldManagerPlugin.log.debug("FreeRemoteObjHook: removing obj " + obj + ", unsubscribing");
/*      */       }
/*      */ 
/* 2646 */       Long removeSub = WorldManagerPlugin.this.remoteMobSubscription.removeSub(freeObjOid);
/* 2647 */       if (removeSub == null) {
/* 2648 */         throw new RuntimeException("no existing remote sub");
/*      */       }
/* 2650 */       Engine.getAgent().removeSubscription(removeSub.longValue());
/* 2651 */       WorldManagerPlugin.log.debug("FreeRemoteObjHook: unsubscribed");
/*      */ 
/* 2654 */       quadtree.removeElement(wnode);
/*      */ 
/* 2657 */       WorldManagerPlugin.this.removeWorldManagerEntity(freeObjOid);
/* 2658 */       if (Log.loggingDebug)
/* 2659 */         WorldManagerPlugin.log.debug("FreeRemoteObjHook: removed obj " + freeObjOid);
/* 2660 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class NewRemoteObjHook
/*      */     implements Hook
/*      */   {
/*      */     NewRemoteObjHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2541 */       WorldManagerClient.NewRemoteObjectMessage rMsg = (WorldManagerClient.NewRemoteObjectMessage)msg;
/*      */ 
/* 2544 */       String targetSessionId = rMsg.getTargetSessionId();
/* 2545 */       if (!targetSessionId.equals(Engine.getAgent().getName())) {
/* 2546 */         throw new RuntimeException("session ids dont match");
/*      */       }
/*      */ 
/* 2549 */       OID newObjOid = rMsg.getSubject();
/* 2550 */       if (Log.loggingDebug)
/* 2551 */         WorldManagerPlugin.log.debug("NewRemoteObjHook: oid=" + newObjOid);
/* 2552 */       if (newObjOid == null) {
/* 2553 */         throw new RuntimeException("no remote newobjoid");
/*      */       }
/*      */ 
/* 2556 */       OID instanceOid = rMsg.getInstanceOid();
/* 2557 */       Point loc = rMsg.getLoc();
/* 2558 */       Quaternion orient = rMsg.getOrient();
/* 2559 */       int radius = rMsg.getPerceptionRadius();
/* 2560 */       QuadTree quadtree = (QuadTree)WorldManagerPlugin.this.quadtrees.get(instanceOid);
/* 2561 */       if (quadtree == null) {
/* 2562 */         WorldManagerPlugin.log.error("NewRemoteObjHook: unknown instanceOid=" + instanceOid + " oid=" + newObjOid);
/*      */ 
/* 2564 */         return false;
/*      */       }
/*      */ 
/* 2568 */       if (Log.loggingDebug) {
/* 2569 */         WorldManagerPlugin.log.debug("NewRemoteObjHook: creating world node for oid " + newObjOid);
/*      */       }
/* 2571 */       WMWorldNode node = new WMWorldNode(radius);
/* 2572 */       node.isLocal(false);
/* 2573 */       node.setInstanceOid(rMsg.getInstanceOid());
/* 2574 */       node.setLoc(loc);
/* 2575 */       node.setOrientation(orient);
/* 2576 */       if (Log.loggingDebug) {
/* 2577 */         WorldManagerPlugin.log.debug("NewRemoteObjHook: created world node for oid " + newObjOid + ", wnode=" + node);
/*      */       }
/*      */ 
/* 2581 */       AOObject newObj = new AOObject(newObjOid);
/* 2582 */       newObj.setType(rMsg.getType());
/* 2583 */       newObj.worldNode(node);
/* 2584 */       node.setObject(newObj);
/* 2585 */       if (Log.loggingDebug) {
/* 2586 */         WorldManagerPlugin.log.debug("NewRemoteObjHook: created obj for oid " + newObjOid + ", obj=" + newObj);
/*      */       }
/*      */ 
/* 2590 */       WorldManagerPlugin.this.registerWorldManagerEntity(newObj);
/*      */ 
/* 2593 */       Log.debug("NewRemoteObjHook: placing obj into qtree, obj=" + newObj);
/* 2594 */       quadtree.addElement(node);
/* 2595 */       if (Log.loggingDebug) {
/* 2596 */         WorldManagerPlugin.log.debug("NewRemoteObjHook: placed obj into qtree, obj=" + newObj);
/*      */       }
/*      */ 
/* 2599 */       HashSet types = new HashSet();
/* 2600 */       types.add(WorldManagerClient.MSG_TYPE_UPDATEWNODE);
/* 2601 */       types.add(WorldManagerClient.MSG_TYPE_MOB_PATH);
/* 2602 */       SubjectFilter newSubFilter = new SubjectFilter(types, newObjOid);
/* 2603 */       Long newSub = Long.valueOf(Engine.getAgent().createSubscription(newSubFilter, WorldManagerPlugin.this));
/* 2604 */       WorldManagerPlugin.this.remoteMobSubscription.put(newObjOid, newSub);
/* 2605 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class FixedPerceiverMap
/*      */   {
/* 2516 */     protected Lock lock = LockFactory.makeLock("FixedPerceiverLock");
/*      */ 
/* 2518 */     Map<String, FixedPerceiver<WMWorldNode>> sessionPerceiverMap = new HashMap();
/*      */ 
/* 2520 */     Map<FixedPerceiver<WMWorldNode>, String> perceiverSessionMap = new HashMap();
/*      */ 
/*      */     public void register(String remoteSessionId, FixedPerceiver<WMWorldNode> p)
/*      */     {
/* 2489 */       this.lock.lock();
/*      */       try {
/* 2491 */         this.sessionPerceiverMap.put(remoteSessionId, p);
/* 2492 */         this.perceiverSessionMap.put(p, remoteSessionId);
/*      */       } finally {
/* 2494 */         this.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public String getSessionId(FixedPerceiver<WMWorldNode> p) {
/* 2499 */       this.lock.lock();
/*      */       try {
/* 2501 */         String str = (String)this.perceiverSessionMap.get(p);
/*      */         return str; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     public FixedPerceiver<WMWorldNode> getPerceiver(String sessionId)
/*      */     {
/* 2508 */       this.lock.lock();
/*      */       try {
/* 2510 */         FixedPerceiver localFixedPerceiver = (FixedPerceiver)this.sessionPerceiverMap.get(sessionId);
/*      */         return localFixedPerceiver; } finally { this.lock.unlock(); } throw localObject;
/*      */     }
/*      */   }
/*      */ 
/*      */   class PerceiverRegionsHook
/*      */     implements Hook
/*      */   {
/*      */     PerceiverRegionsHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2399 */       WorldManagerClient.PerceiverRegionsMessage pMsg = (WorldManagerClient.PerceiverRegionsMessage)msg;
/*      */ 
/* 2402 */       String otherSessionId = pMsg.getSenderName();
/* 2403 */       if (Log.loggingDebug)
/* 2404 */         WorldManagerPlugin.log.debug("PerceiverRegionsHook: otherSessionId=" + otherSessionId);
/* 2405 */       if (otherSessionId == null) {
/* 2406 */         throw new AORuntimeException("other session id is null");
/*      */       }
/*      */ 
/* 2409 */       String mySessionId = Engine.getAgent().getName();
/* 2410 */       if (mySessionId.equals(otherSessionId)) {
/* 2411 */         Log.debug("PerceiverRegionsHook: ignoring, session id is same as self");
/* 2412 */         return false;
/*      */       }
/*      */ 
/* 2415 */       OID instanceOid = pMsg.getInstanceOid();
/* 2416 */       QuadTree quadtree = (QuadTree)WorldManagerPlugin.this.quadtrees.get(instanceOid);
/* 2417 */       if (quadtree == null) {
/* 2418 */         Log.error("PerceiverRegionsHook: unknown instanceOid=" + instanceOid);
/*      */ 
/* 2420 */         return false;
/*      */       }
/*      */ 
/* 2424 */       Geometry region = pMsg.getRegion();
/* 2425 */       if (region == null) {
/* 2426 */         throw new AORuntimeException("region is null");
/*      */       }
/*      */ 
/* 2430 */       if (WorldManagerPlugin.this.fixedPerceiverMap.getPerceiver(otherSessionId) != null) {
/* 2431 */         WorldManagerPlugin.log.warn("PerceiverRegionsHook: map exists");
/* 2432 */         return true;
/*      */       }
/* 2434 */       setupPerceiver(otherSessionId, quadtree, region);
/*      */ 
/* 2436 */       if (pMsg.getTargetSessionId() == null)
/*      */       {
/* 2439 */         WorldManagerPlugin.log.debug("PerceiverRegionsHook: sending our own geo msg out");
/* 2440 */         Geometry myFixedPerceiverRegions = Geometry.maxGeometry();
/* 2441 */         WorldManagerClient.sendPerceiverRegionsMsg(instanceOid, myFixedPerceiverRegions, otherSessionId);
/*      */       }
/*      */       else {
/* 2444 */         WorldManagerPlugin.log.debug("PerceiverRegionsHook: PerceiverRegionsMsg has a target - so not sending my own out");
/*      */       }
/* 2446 */       return true;
/*      */     }
/*      */ 
/*      */     private void setupPerceiver(String remoteSessionId, QuadTree<WMWorldNode> quadtree, Geometry region)
/*      */     {
/* 2454 */       FixedPerceiver p = new FixedPerceiver(region);
/*      */ 
/* 2456 */       p.registerCallback(WorldManagerPlugin.this);
/* 2457 */       p.setFilter(new PerceiverFilter() { static final long serialVersionUID = 1L;
/*      */ 
/* 2460 */         public boolean matches(Perceiver<WMWorldNode> p, WMWorldNode node) { boolean val = node.isLocal();
/* 2461 */           if (Log.loggingDebug)
/* 2462 */             WorldManagerPlugin.log.debug("PerceiverFilter: node local? " + val);
/* 2463 */           return val;
/*      */         }
/*      */       });
/* 2470 */       if (Log.loggingDebug) {
/* 2471 */         WorldManagerPlugin.log.debug("setupPerceiver: adding remote session " + remoteSessionId + " into our map");
/*      */       }
/* 2473 */       WorldManagerPlugin.this.fixedPerceiverMap.register(remoteSessionId, p);
/*      */ 
/* 2476 */       WorldManagerPlugin.log.debug("setupPerceiver: adding fixed perceiver to quad tree");
/* 2477 */       quadtree.addFixedPerceiver(p);
/* 2478 */       WorldManagerPlugin.log.debug("setupPerceiver: done adding fixed perceiver");
/*      */     }
/*      */   }
/*      */ 
/*      */   class RefreshWNodeHook
/*      */     implements Hook
/*      */   {
/*      */     RefreshWNodeHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2378 */       WorldManagerClient.RefreshWNodeMessage rMsg = (WorldManagerClient.RefreshWNodeMessage)msg;
/*      */ 
/* 2381 */       OID oid = rMsg.getSubject();
/* 2382 */       Entity entity = WorldManagerPlugin.this.getWorldManagerEntity(oid);
/* 2383 */       if (entity == null) {
/* 2384 */         WorldManagerPlugin.log.error("RefreshWNodeHook: could not find sub object for oid=" + oid);
/* 2385 */         return true;
/*      */       }
/* 2387 */       AOObject obj = (AOObject)entity;
/* 2388 */       BasicWorldNode copyNode = obj.baseWorldNode();
/*      */ 
/* 2391 */       WorldManagerClient.UpdateWorldNodeMessage uMsg = new WorldManagerClient.UpdateWorldNodeMessage(oid, copyNode);
/* 2392 */       Engine.getAgent().sendBroadcast(uMsg);
/* 2393 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class OrientReqHook
/*      */     implements Hook
/*      */   {
/*      */     OrientReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2352 */       WorldManagerClient.OrientReqMessage orientReqMsg = (WorldManagerClient.OrientReqMessage)msg;
/*      */ 
/* 2355 */       OID oid = orientReqMsg.getSubject();
/* 2356 */       Quaternion q = orientReqMsg.getQuaternion();
/* 2357 */       Entity entity = WorldManagerPlugin.this.getWorldManagerEntity(oid);
/* 2358 */       if (entity == null) {
/* 2359 */         WorldManagerPlugin.log.error("OrientReqHook: could not find sub object for oid=" + oid);
/* 2360 */         return true;
/*      */       }
/* 2362 */       AOObject obj = (AOObject)entity;
/* 2363 */       WorldNode wnode = obj.worldNode();
/* 2364 */       InterpolatedWorldNode bnode = (InterpolatedWorldNode)wnode;
/* 2365 */       bnode.setOrientation(q);
/*      */ 
/* 2369 */       WorldManagerClient.OrientMessage orientMsg = new WorldManagerClient.OrientMessage(oid, q);
/*      */ 
/* 2371 */       Engine.getAgent().sendBroadcast(orientMsg);
/* 2372 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class ComReqHook
/*      */     implements Hook
/*      */   {
/*      */     ComReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2333 */       WorldManagerClient.ComReqMessage comReqMsg = (WorldManagerClient.ComReqMessage)msg;
/*      */ 
/* 2336 */       if (Log.loggingDebug) {
/* 2337 */         WorldManagerPlugin.log.debug("ComReqHook: got com msg from " + comReqMsg.getSubject() + ", msg=" + comReqMsg.getString());
/*      */       }
/*      */ 
/* 2342 */       WorldManagerClient.ComMessage comMsg = new WorldManagerClient.ComMessage(comReqMsg.getSubject(), comReqMsg.getChatterName(), comReqMsg.getChannel(), comReqMsg.getString());
/*      */ 
/* 2345 */       Engine.getAgent().sendBroadcast(comMsg);
/* 2346 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetWNodeReqHook
/*      */     implements Hook
/*      */   {
/*      */     GetWNodeReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2313 */       SubjectMessage getWNodeMsg = (SubjectMessage)msg;
/* 2314 */       if (Log.loggingDebug)
/* 2315 */         WorldManagerPlugin.log.debug("GetWNodeReqHook: got get wnode msg=" + getWNodeMsg);
/* 2316 */       OID oid = getWNodeMsg.getSubject();
/*      */ 
/* 2318 */       AOObject obj = (AOObject)WorldManagerPlugin.this.getWorldManagerEntity(oid);
/* 2319 */       if (obj == null) {
/* 2320 */         Log.error("GetWNodeReqHook: could not find obj for oid=" + oid);
/* 2321 */         Engine.getAgent().sendObjectResponse(msg, null);
/* 2322 */         return true;
/*      */       }
/* 2324 */       BasicWorldNode newWNode = obj.baseWorldNode();
/* 2325 */       Engine.getAgent().sendObjectResponse(msg, newWNode);
/*      */ 
/* 2327 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class UpdateObjectHook
/*      */     implements Hook
/*      */   {
/*      */     UpdateObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2263 */       WorldManagerClient.UpdateMessage updateReq = (WorldManagerClient.UpdateMessage)msg;
/* 2264 */       OID notifyOid = updateReq.getTarget();
/* 2265 */       OID updateOid = updateReq.getSubject();
/*      */ 
/* 2267 */       if (Log.loggingDebug) {
/* 2268 */         Log.debug("UpdateObjectHook: notifyOid=" + notifyOid + " updateOid=" + updateOid);
/*      */       }
/*      */ 
/* 2271 */       Entity updateEntity = WorldManagerPlugin.this.getWorldManagerEntity(updateOid);
/* 2272 */       if (updateEntity == null) {
/* 2273 */         WorldManagerPlugin.log.warn("UpdateObjectHook: could not find sub object for oid=" + updateOid);
/* 2274 */         return false;
/*      */       }
/*      */ 
/* 2277 */       if (!(updateEntity instanceof AOObject)) {
/* 2278 */         WorldManagerPlugin.log.warn("UpdateObjectHook: updateObj is not AOObject: " + updateOid);
/*      */ 
/* 2280 */         return false;
/*      */       }
/* 2282 */       AOObject updateObj = (AOObject)updateEntity;
/* 2283 */       if (updateObj.worldNode() == null) {
/* 2284 */         WorldManagerPlugin.log.warn("UpdateObjectHook: updateObj has no world node: " + updateOid);
/*      */ 
/* 2286 */         return false;
/*      */       }
/*      */ 
/* 2296 */       WorldManagerPlugin.this.sendTargetedPropertyMessage(notifyOid, updateObj);
/*      */ 
/* 2298 */       WorldManagerPlugin.this.sendWNodeMessage(notifyOid, updateObj);
/*      */ 
/* 2300 */       List soundData = (List)updateEntity.getProperty(WorldManagerClient.TEMPL_SOUND_DATA_LIST);
/*      */ 
/* 2303 */       if (soundData != null) {
/* 2304 */         WorldManagerPlugin.this.sendObjectSoundMessage(notifyOid, updateObj, soundData);
/*      */       }
/*      */ 
/* 2307 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class WorldManagerTransferHook
/*      */     implements Hook
/*      */   {
/*      */     WorldManagerTransferHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1985 */       EnginePlugin.TransferObjectMessage transferMsg = (EnginePlugin.TransferObjectMessage)msg;
/* 1986 */       AOObject obj = (AOObject)transferMsg.getEntity();
/* 1987 */       if (Log.loggingDebug) {
/* 1988 */         Log.debug("WorldManagerTransferHook: obj=" + obj + ", sessionid=" + msg.getSenderName());
/*      */       }
/*      */ 
/* 1992 */       WMWorldNode wnode = new WMWorldNode();
/* 1993 */       wnode.setInstanceOid(obj.worldNode().getInstanceOid());
/* 1994 */       wnode.setLoc(obj.getLoc());
/* 1995 */       wnode.setOrientation(obj.getOrientation());
/* 1996 */       wnode.setFollowsTerrain(Boolean.TRUE);
/* 1997 */       obj.worldNode(wnode);
/* 1998 */       wnode.setObject(obj);
/*      */ 
/* 2000 */       QuadTree quadtree = (QuadTree)WorldManagerPlugin.this.quadtrees.get(wnode.getInstanceOid());
/* 2001 */       if (quadtree == null) {
/* 2002 */         WorldManagerPlugin.log.error("WorldManagerTransferHook: unknown instanceOid=" + wnode.getInstanceOid() + " oid=" + obj.getOid());
/*      */ 
/* 2004 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.FALSE);
/* 2005 */         return false;
/*      */       }
/*      */ 
/* 2009 */       OID masterOid = obj.getMasterOid();
/* 2010 */       WorldManagerPlugin.this.registerWorldManagerEntity(obj);
/*      */ 
/* 2016 */       WorldManagerPlugin.this.subscribeForMob(masterOid);
/* 2017 */       if (Log.loggingDebug) {
/* 2018 */         Log.debug("WorldManagerTransferHook: bound obj " + obj);
/*      */       }
/*      */ 
/* 2021 */       WorldManagerPlugin.this.spawnObject(obj, quadtree);
/* 2022 */       if (Log.loggingDebug) {
/* 2023 */         Log.debug("WorldManagerTransferHook: complete, spawned obj " + obj);
/*      */       }
/* 2025 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.TRUE);
/*      */ 
/* 2027 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceDeleteHook
/*      */     implements EnginePlugin.DeleteHook
/*      */   {
/*      */     InstanceDeleteHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onDelete(Entity entity)
/*      */     {
/* 1931 */       WorldManagerPlugin.this.quadtrees.remove(entity.getOid());
/* 1932 */       WorldManagerPlugin.this.unsubscribeForObject(entity.getOid());
/* 1933 */       WorldManagerPlugin.this.unhostInstance(entity.getOid());
/*      */     }
/*      */ 
/*      */     public void onDelete(OID oid, Namespace namespace)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceUnloadHook
/*      */     implements EnginePlugin.UnloadHook
/*      */   {
/*      */     InstanceUnloadHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onUnload(Entity entity)
/*      */     {
/* 1922 */       WorldManagerPlugin.this.quadtrees.remove(entity.getOid());
/* 1923 */       WorldManagerPlugin.this.unsubscribeForObject(entity.getOid());
/* 1924 */       WorldManagerPlugin.this.unhostInstance(entity.getOid());
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceLoadHook
/*      */     implements EnginePlugin.LoadHook
/*      */   {
/*      */     InstanceLoadHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onLoad(Entity entity)
/*      */     {
/* 1913 */       WorldManagerPlugin.WorldManagerInstance instance = (WorldManagerPlugin.WorldManagerInstance)entity;
/* 1914 */       WorldManagerPlugin.this.initializeInstance(instance);
/* 1915 */       WorldManagerPlugin.this.subscribeForObject(entity.getOid());
/*      */     }
/*      */   }
/*      */ 
/*      */   class WorldManagerGenerateSubObjectHook extends EnginePlugin.GenerateSubObjectHook
/*      */   {
/*      */     public WorldManagerGenerateSubObjectHook()
/*      */     {
/* 1702 */       super();
/*      */     }
/*      */ 
/*      */     public EnginePlugin.SubObjData generateSubObject(Template template, Namespace namespace, OID masterOid)
/*      */     {
/* 1708 */       if (Log.loggingDebug) {
/* 1709 */         WorldManagerPlugin.log.debug("GenerateSubObjectHook: masterOid=" + masterOid + " namespace=" + namespace + " template=" + template);
/*      */       }
/*      */ 
/* 1713 */       Boolean persistent = (Boolean)template.get(Namespace.OBJECT_MANAGER, ":persistent");
/*      */ 
/* 1715 */       if (persistent == null) {
/* 1716 */         persistent = Boolean.valueOf(false);
/*      */       }
/* 1718 */       if (namespace == WorldManagerClient.INSTANCE_NAMESPACE) {
/* 1719 */         return generateInstanceSubObject(masterOid, persistent);
/*      */       }
/*      */ 
/* 1722 */       Map props = template.getSubMap(Namespace.WORLD_MANAGER);
/* 1723 */       if (props == null) {
/* 1724 */         Log.warn("GenerateSubObjectHook: no props in ns " + Namespace.WORLD_MANAGER);
/* 1725 */         return null;
/*      */       }
/*      */ 
/* 1728 */       OID instanceOid = (OID)props.get(WorldManagerClient.TEMPL_INSTANCE);
/* 1729 */       if (instanceOid == null) {
/* 1730 */         Log.error("GenerateSubObjectHook: missing instanceOid");
/* 1731 */         return null;
/*      */       }
/* 1733 */       if (WorldManagerPlugin.this.quadtrees.get(instanceOid) == null) {
/* 1734 */         Log.error("GenerateSubObjectHook: unknown instanceOid=" + instanceOid);
/*      */ 
/* 1736 */         return null;
/*      */       }
/*      */ 
/* 1740 */       Point loc = (Point)props.get(WorldManagerClient.TEMPL_LOC);
/* 1741 */       if (loc == null) {
/* 1742 */         Log.warn("GenerateSubObjectHook: no loc in templ");
/* 1743 */         return null;
/*      */       }
/*      */ 
/* 1746 */       String objName = (String)props.get(WorldManagerClient.TEMPL_NAME);
/* 1747 */       if (objName == null) {
/* 1748 */         objName = template.getName();
/* 1749 */         if (objName == null) {
/* 1750 */           objName = "(null)";
/*      */         }
/*      */       }
/*      */ 
/* 1754 */       Quaternion orient = (Quaternion)props.get(WorldManagerClient.TEMPL_ORIENT);
/* 1755 */       if (orient == null) {
/* 1756 */         orient = new Quaternion();
/*      */       }
/*      */ 
/* 1759 */       AOVector scale = (AOVector)props.get(WorldManagerClient.TEMPL_SCALE);
/* 1760 */       if (scale == null) {
/* 1761 */         scale = new AOVector(1.0F, 1.0F, 1.0F);
/*      */       }
/*      */ 
/* 1764 */       Integer perceptionRadius = (Integer)props.get(WorldManagerClient.TEMPL_PERCEPTION_RADIUS);
/*      */ 
/* 1767 */       AOObject wObj = WorldManagerPlugin.this.generateWorldManagerSubObject(template, masterOid);
/*      */ 
/* 1769 */       wObj.setName(objName);
/* 1770 */       wObj.scale(scale);
/*      */ 
/* 1773 */       DisplayContext dc = (DisplayContext)props.get(WorldManagerClient.TEMPL_DISPLAY_CONTEXT);
/* 1774 */       if (dc != null) {
/* 1775 */         dc = (DisplayContext)dc.clone();
/* 1776 */         dc.setObjRef(wObj.getOid());
/* 1777 */         wObj.displayContext(dc);
/*      */       }
/*      */       else {
/* 1780 */         Log.debug("GenerateSubObjectHook: object has no display context, oid=" + masterOid);
/*      */       }
/* 1782 */       if (Log.loggingDebug)
/* 1783 */         WorldManagerPlugin.log.debug("GenerateSubObjectHook: created entity " + wObj + ", loc=" + loc);
/*      */       WMWorldNode wnode;
/*      */       WMWorldNode wnode;
/* 1787 */       if (perceptionRadius != null) {
/* 1788 */         wnode = new WMWorldNode(perceptionRadius.intValue());
/*      */       }
/*      */       else {
/* 1791 */         wnode = new WMWorldNode();
/*      */       }
/* 1793 */       wnode.setInstanceOid(instanceOid);
/* 1794 */       wnode.setLoc(loc);
/* 1795 */       wnode.setOrientation(orient);
/* 1796 */       Boolean followsTerrain = (Boolean)props.get(WorldManagerClient.TEMPL_FOLLOWS_TERRAIN);
/* 1797 */       if (followsTerrain == null)
/* 1798 */         followsTerrain = Boolean.TRUE;
/* 1799 */       wnode.setFollowsTerrain(followsTerrain);
/* 1800 */       wObj.worldNode(wnode);
/* 1801 */       wnode.setObject(wObj);
/* 1802 */       wObj.setPersistenceFlag(persistent.booleanValue());
/*      */ 
/* 1805 */       EntityManager.registerEntityByNamespace(wObj, Namespace.WORLD_MANAGER);
/*      */ 
/* 1807 */       if (persistent.booleanValue()) {
/* 1808 */         Engine.getPersistenceManager().persistEntity(wObj);
/*      */       }
/*      */ 
/* 1814 */       WorldManagerPlugin.this.subscribeForMob(masterOid);
/*      */ 
/* 1816 */       return new EnginePlugin.SubObjData();
/*      */     }
/*      */ 
/*      */     public EnginePlugin.SubObjData generateInstanceSubObject(OID masterOid, Boolean persistent)
/*      */     {
/* 1822 */       WorldManagerPlugin.WorldManagerInstance instance = WorldManagerPlugin.this.createInstanceEntity(masterOid);
/* 1823 */       instance.setPersistenceFlag(persistent.booleanValue());
/*      */ 
/* 1825 */       if (persistent.booleanValue()) {
/* 1826 */         Engine.getPersistenceManager().persistEntity(instance);
/*      */       }
/* 1828 */       WorldManagerPlugin.this.subscribeForObject(masterOid);
/* 1829 */       WorldManagerPlugin.this.hostInstance(masterOid, instance.getQuadTree().getLocalGeometry());
/*      */ 
/* 1835 */       return new EnginePlugin.SubObjData();
/*      */     }
/*      */   }
/*      */ 
/*      */   class DespawnReqHook
/*      */     implements Hook
/*      */   {
/*      */     DespawnReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1652 */       WorldManagerClient.DespawnReqMessage wrldMsg = (WorldManagerClient.DespawnReqMessage)msg;
/*      */ 
/* 1654 */       OID oid = wrldMsg.getSubject();
/*      */ 
/* 1656 */       if (Log.loggingDebug) {
/* 1657 */         WorldManagerPlugin.log.debug("DespawnReqHook: oid=" + oid);
/*      */       }
/* 1659 */       Entity entity = WorldManagerPlugin.this.getWorldManagerEntity(oid);
/*      */ 
/* 1661 */       if ((entity == null) || (!(entity instanceof AOObject))) {
/* 1662 */         WorldManagerPlugin.log.error("DespawnReqHook: entity null or not found, oid=" + oid);
/* 1663 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.FALSE);
/* 1664 */         return false;
/*      */       }
/*      */ 
/* 1667 */       if (wrldMsg.getPreMessage() != null) {
/* 1668 */         Engine.getAgent().sendBroadcast(wrldMsg.getPreMessage());
/*      */       }
/*      */ 
/* 1671 */       AOObject obj = (AOObject)entity;
/* 1672 */       WorldNode wnode = obj.worldNode();
/*      */       try
/*      */       {
/* 1675 */         WorldManagerPlugin.this.despawnObject(obj);
/*      */       }
/*      */       catch (Exception e) {
/* 1678 */         Log.exception("despawnObject failed", e);
/* 1679 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.FALSE);
/* 1680 */         return false;
/*      */       }
/*      */ 
/* 1683 */       if (wrldMsg.getPostMessage() != null) {
/* 1684 */         Engine.getAgent().sendBroadcast(wrldMsg.getPostMessage());
/*      */       }
/*      */ 
/* 1688 */       if (wnode != null) {
/* 1689 */         Message despawnedMsg = new WorldManagerClient.DespawnedMessage(oid, wnode.getInstanceOid(), obj.getType());
/*      */ 
/* 1692 */         Engine.getAgent().sendBroadcast(despawnedMsg);
/*      */       }
/*      */ 
/* 1695 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.TRUE);
/* 1696 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SpawnReqHook
/*      */     implements Hook
/*      */   {
/*      */     SpawnReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1582 */       WorldManagerClient.SpawnReqMessage wrldMsg = (WorldManagerClient.SpawnReqMessage)msg;
/*      */ 
/* 1584 */       OID oid = wrldMsg.getSubject();
/* 1585 */       if (Log.loggingDebug) {
/* 1586 */         Log.debug("SpawnReqHook: spawning oid=" + oid + ", msg=" + msg);
/*      */       }
/* 1588 */       Entity entity = WorldManagerPlugin.this.getWorldManagerEntity(oid);
/* 1589 */       if ((entity == null) || (!(entity instanceof AOObject))) {
/* 1590 */         WorldManagerPlugin.log.error("SpawnReqHook: entity null or not found, oid=" + oid);
/*      */ 
/* 1592 */         Engine.getAgent().sendObjectResponse(msg, Integer.valueOf(-1));
/* 1593 */         return false;
/*      */       }
/*      */ 
/* 1596 */       AOObject obj = (AOObject)entity;
/* 1597 */       WorldNode wnode = obj.worldNode();
/* 1598 */       if (wnode.isSpawned()) {
/* 1599 */         WorldManagerPlugin.log.error("SpawnReqHook: object already spawned oid=" + oid);
/* 1600 */         Engine.getAgent().sendObjectResponse(msg, Integer.valueOf(-3));
/* 1601 */         return false;
/*      */       }
/*      */ 
/* 1604 */       QuadTree quadtree = (QuadTree)WorldManagerPlugin.this.quadtrees.get(wnode.getInstanceOid());
/*      */ 
/* 1607 */       if (quadtree == null) {
/* 1608 */         WorldManagerPlugin.log.error("SpawnReqHook: unknown instanceOid=" + wnode.getInstanceOid() + " oid=" + oid);
/*      */ 
/* 1610 */         Engine.getAgent().sendObjectResponse(msg, Integer.valueOf(-2));
/* 1611 */         return false;
/*      */       }
/*      */ 
/* 1614 */       if (wrldMsg.getPreMessage() != null) {
/* 1615 */         Engine.getAgent().sendBroadcast(wrldMsg.getPreMessage());
/*      */       }
/*      */ 
/* 1618 */       Integer newsAndFreesCount = null;
/*      */       try {
/* 1620 */         newsAndFreesCount = WorldManagerPlugin.this.spawnObject(obj, quadtree);
/*      */       }
/*      */       catch (Exception e) {
/* 1623 */         Log.exception("spawnObject failed", e);
/*      */ 
/* 1625 */         Engine.getAgent().sendObjectResponse(msg, Integer.valueOf(-1));
/* 1626 */         return false;
/*      */       }
/*      */ 
/* 1629 */       if (wrldMsg.getPostMessage() != null) {
/* 1630 */         Engine.getAgent().sendBroadcast(wrldMsg.getPostMessage());
/*      */       }
/*      */ 
/* 1634 */       Message spawnedMsg = new WorldManagerClient.SpawnedMessage(oid, wnode.getInstanceOid(), obj.getType());
/*      */ 
/* 1636 */       Engine.getAgent().sendBroadcast(spawnedMsg);
/*      */ 
/* 1641 */       Engine.getAgent().sendObjectResponse(msg, newsAndFreesCount);
/*      */ 
/* 1643 */       if (obj.isUser()) {
/* 1644 */         WorldManagerPlugin.this.sendRegionUpdate(obj);
/*      */       }
/* 1646 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DisplayContextReqHook
/*      */     implements Hook
/*      */   {
/*      */     DisplayContextReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1569 */       WorldManagerClient.DisplayContextReqMessage rMsg = (WorldManagerClient.DisplayContextReqMessage)msg;
/*      */ 
/* 1571 */       OID oid = rMsg.getSubject();
/* 1572 */       DisplayContext dc = WorldManagerPlugin.this.getDisplayContext(oid);
/* 1573 */       if (Log.loggingDebug)
/* 1574 */         WorldManagerPlugin.log.debug("DisplayContextHook: oid=" + oid + ", dc=" + dc);
/* 1575 */       Engine.getAgent().sendObjectResponse(msg, dc);
/* 1576 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class ObjectInfoReqHook
/*      */     implements Hook
/*      */   {
/*      */     ObjectInfoReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1552 */       WorldManagerClient.ObjInfoReqMessage objInfoMsg = (WorldManagerClient.ObjInfoReqMessage)msg;
/*      */ 
/* 1555 */       OID oid = objInfoMsg.getSubject();
/*      */ 
/* 1557 */       WorldManagerClient.ObjectInfo objInfo = WorldManagerPlugin.this.makeObjectInfo(oid);
/*      */ 
/* 1559 */       ResponseMessage respMsg = new WorldManagerClient.ObjInfoRespMessage(objInfoMsg, msg.getSenderName(), objInfo);
/*      */ 
/* 1562 */       Engine.getAgent().sendResponse(respMsg);
/* 1563 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetObjectsInHook
/*      */     implements Hook
/*      */   {
/*      */     GetObjectsInHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1466 */       WorldManagerClient.GetObjectsInMessage message = (WorldManagerClient.GetObjectsInMessage)msg;
/* 1467 */       OID subjectOid = message.getSubject();
/* 1468 */       BasicWorldNode subjectWorldNode = ((AOObject)WorldManagerPlugin.this.getWorldManagerEntity(subjectOid)).baseWorldNode();
/* 1469 */       OID instanceOid = subjectWorldNode.getInstanceOid();
/* 1470 */       List objectsIn = null;
/* 1471 */       if (instanceOid != null)
/* 1472 */         objectsIn = WorldManagerPlugin.this.getInstanceObjectsIn(instanceOid, message.getLoc(), message.getRadius(), message.getObjectType());
/*      */       else {
/* 1474 */         objectsIn = WorldManagerPlugin.this.getObjectsIn(message.getLoc(), message.getRadius(), message.getObjectType());
/*      */       }
/* 1476 */       Engine.getAgent().sendObjectResponse(message, objectsIn);
/* 1477 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class MobPathReqHook
/*      */     implements Hook
/*      */   {
/*      */     MobPathReqHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1408 */       WorldManagerClient.MobPathReqMessage pathReqMsg = (WorldManagerClient.MobPathReqMessage)msg;
/* 1409 */       if (Log.loggingDebug)
/* 1410 */         WorldManagerPlugin.log.debug("Received MobPathReqMessage " + pathReqMsg);
/* 1411 */       OID oid = pathReqMsg.getSubject();
/* 1412 */       AOObject obj = (AOObject)WorldManagerPlugin.this.getWorldManagerEntity(oid);
/* 1413 */       if (obj == null) {
/* 1414 */         Log.error("MobPathReqHook: unknown oid=" + oid);
/* 1415 */         return true;
/*      */       }
/* 1417 */       InterpolatedWorldNode wnode = (InterpolatedWorldNode)obj.worldNode();
/* 1418 */       float speed = pathReqMsg.getSpeed();
/* 1419 */       boolean nomove = obj.getBooleanProperty("world.nomove");
/* 1420 */       if (nomove) {
/* 1421 */         WorldManagerClient.MobPathCorrectionMessage correction = new WorldManagerClient.MobPathCorrectionMessage(oid, System.currentTimeMillis(), "linear", 0.0F, "", new LinkedList());
/*      */ 
/* 1424 */         Engine.getAgent().sendBroadcast(correction);
/*      */       }
/*      */       else
/*      */       {
/* 1429 */         if (wnode.getPathInterpolator() != null) {
/* 1430 */           if (Log.loggingDebug)
/* 1431 */             WorldManagerPlugin.log.debug("MobPathReqHook: calling getLoc on oid " + oid);
/* 1432 */           wnode.getLoc();
/*      */         }
/* 1434 */         long startTime = pathReqMsg.getStartTime();
/* 1435 */         String interpKind = pathReqMsg.getInterpKind();
/* 1436 */         String terrainString = pathReqMsg.getTerrainString();
/* 1437 */         List pathPoints = pathReqMsg.getPathPoints();
/* 1438 */         WorldManagerClient.MobPathMessage pathMsg = new WorldManagerClient.MobPathMessage(oid, startTime, interpKind, speed, terrainString, pathPoints);
/*      */ 
/* 1441 */         obj.setProperty(WorldManagerClient.MOB_PATH_PROPERTY, pathMsg);
/* 1442 */         Engine.getAgent().sendBroadcast(pathMsg);
/* 1443 */         if (Log.loggingDebug)
/* 1444 */           WorldManagerPlugin.log.debug("Sending MobPathMessage " + pathMsg);
/* 1445 */         if (speed != 0.0F) {
/* 1446 */           PathInterpolator pathInterpolator = interpKind.equalsIgnoreCase("spline") ? new PathSpline(oid, startTime, speed, terrainString, pathPoints) : new PathLinear(oid, startTime, speed, terrainString, pathPoints);
/*      */ 
/* 1450 */           wnode.setPathInterpolator(pathInterpolator);
/*      */         }
/*      */         else
/*      */         {
/* 1454 */           wnode.setPathInterpolator(null);
/*      */         }
/*      */       }
/* 1457 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class CaptureInterpWorldNode extends InterpolatedWorldNode
/*      */   {
/*      */     public static final long serialVersionUID = 1L;
/*      */ 
/*      */     CaptureInterpWorldNode(InterpolatedWorldNode node)
/*      */     {
/* 1311 */       node.lock.lock();
/*      */       try {
/* 1313 */         this.instanceOid = node.getInstanceOid();
/* 1314 */         this.interpLoc = node.getInterpLoc();
/* 1315 */         this.lastInterp = node.getLastInterp();
/* 1316 */         this.rawLoc = node.getRawLoc();
/* 1317 */         this.dir = node.getDir();
/* 1318 */         this.pathInterpolator = node.getPathInterpolator();
/* 1319 */         this.spawned = node.isSpawned();
/* 1320 */         this.orient = node.getOrientation();
/* 1321 */         this.lastUpdate = node.getLastUpdate();
/*      */       }
/*      */       finally
/*      */       {
/* 1326 */         node.lock.unlock();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void setPathInterpolatorValues(long time, AOVector newDir, Point newLoc, Quaternion orientation)
/*      */     {
/* 1334 */       this.lastInterp = time;
/* 1335 */       this.interpLoc = ((Point)newLoc.clone());
/* 1336 */       this.dir = newDir;
/* 1337 */       this.orient = orientation;
/*      */     }
/*      */   }
/*      */ 
/*      */   class MobDeleteHook
/*      */     implements EnginePlugin.DeleteHook
/*      */   {
/*      */     MobDeleteHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onDelete(Entity entity)
/*      */     {
/* 1005 */       if (!(entity instanceof AOObject))
/* 1006 */         return;
/* 1007 */       WorldManagerPlugin.this.unsubscribeForMob(entity.getOid());
/* 1008 */       WorldManagerPlugin.this.despawnObject((AOObject)entity);
/* 1009 */       Engine.getPersistenceManager().clearDirty(entity);
/*      */     }
/*      */ 
/*      */     public void onDelete(OID oid, Namespace namespace)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   class MobUnloadHook
/*      */     implements EnginePlugin.UnloadHook
/*      */   {
/*      */     MobUnloadHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onUnload(Entity entity)
/*      */     {
/*  968 */       if (!(entity instanceof AOObject))
/*  969 */         return;
/*  970 */       WorldManagerPlugin.this.unsubscribeForMob(entity.getOid());
/*  971 */       WorldManagerPlugin.this.despawnObject((AOObject)entity);
/*      */ 
/*  977 */       Engine.getPersistenceManager().clearDirty(entity);
/*      */ 
/*  980 */       AOObject aObj = (AOObject)entity;
/*  981 */       if (aObj.getType() == ObjectTypes.mob) {
/*  982 */         Log.debug("UNLOAD: not saving mob: " + aObj.getName());
/*  983 */         return;
/*      */       }
/*      */ 
/*  989 */       entity.lock();
/*      */       byte[] entityData;
/*      */       try {
/*  991 */         entityData = entity.toBytes();
/*      */       }
/*      */       finally {
/*  994 */         entity.unlock();
/*      */       }
/*      */ 
/*  997 */       Engine.getDatabase().saveObject(null, entityData, WorldManagerClient.NAMESPACE);
/*      */     }
/*      */   }
/*      */ 
/*      */   class MobLoadHook
/*      */     implements EnginePlugin.LoadHook
/*      */   {
/*      */     MobLoadHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onLoad(Entity entity)
/*      */     {
/*  961 */       WorldManagerPlugin.this.subscribeForMob(entity.getOid());
/*      */     }
/*      */   }
/*      */ 
/*      */   class Updater
/*      */     implements Runnable
/*      */   {
/*  901 */     Lock dirLightLock = LockFactory.makeLock("DirLightLock");
/*      */ 
/*      */     Updater()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */       {
/*      */         try
/*      */         {
/*  262 */           update();
/*      */         } catch (AORuntimeException e) {
/*  264 */           Log.exception("WorldManagerPluging.Updater.run caught AORuntimeException", e);
/*      */         } catch (Exception e) {
/*  266 */           Log.exception("WorldManagerPluging.Updater.run caught exception", e);
/*      */         }
/*      */         try
/*      */         {
/*  270 */           Thread.sleep(1000L);
/*      */         } catch (InterruptedException e) {
/*  272 */           Log.warn("Updater: " + e);
/*  273 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void update() {
/*  279 */       WorldManagerPlugin.log.debug("Update.update: in update");
/*      */ 
/*  282 */       for (Entity e : EntityManager.getAllEntitiesByNamespace(Namespace.WORLD_MANAGER))
/*      */       {
/*  284 */         if (!(e instanceof AOObject)) {
/*      */           continue;
/*      */         }
/*  287 */         AOObject obj = (AOObject)e;
/*  288 */         WMWorldNode wnode = (WMWorldNode)obj.worldNode();
/*  289 */         if (wnode == null) {
/*      */           continue;
/*      */         }
/*  292 */         if (!wnode.isSpawned()) {
/*      */           continue;
/*      */         }
/*  295 */         if (!wnode.isLocal())
/*      */         {
/*      */           continue;
/*      */         }
/*  299 */         Point loc = null;
/*  300 */         if ((obj.isMob()) || (obj.isUser()))
/*      */         {
/*  302 */           if (obj.getPersistenceFlag()) {
/*  303 */             Long lastSaved = (Long)obj.getProperty(WorldManagerClient.WMGR_LAST_SAVED_PROP);
/*  304 */             if (lastSaved == null) {
/*  305 */               lastSaved = Long.valueOf(0L);
/*      */             }
/*  307 */             Long currentTime = Long.valueOf(System.currentTimeMillis());
/*  308 */             Long elapsed = Long.valueOf(currentTime.longValue() - lastSaved.longValue());
/*  309 */             if ((elapsed.longValue() > WorldManagerClient.WMGR_SAVE_INTERVAL_MS.longValue()) && 
/*  310 */               (Log.loggingDebug)) {
/*  311 */               Log.debug("update: elapsedTime=" + elapsed + ", marking obj dirty: " + obj);
/*      */ 
/*  313 */               obj.setProperty(WorldManagerClient.WMGR_LAST_SAVED_PROP, currentTime);
/*  314 */               Engine.getPersistenceManager().setDirty(obj);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  322 */           loc = wnode.getLoc();
/*  323 */           if (zoneObject(obj, wnode, loc)) {
/*      */             continue;
/*      */           }
/*      */         }
/*  327 */         if (obj.isMob())
/*      */         {
/*  333 */           if (wnode.getPathInterpolator() != null) {
/*  334 */             if (Log.loggingDebug)
/*  335 */               WorldManagerPlugin.log.debug("Update.update: sending out wnode update for oid " + obj.getOid());
/*  336 */             WorldManagerPlugin.this.sendWNodeMessage(obj.getOid(), obj);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  341 */         if (obj.isUser()) {
/*  342 */           if (Log.loggingDebug) {
/*  343 */             WorldManagerPlugin.log.debug("Update.update: updating regions for oid " + obj.getOid());
/*      */           }
/*      */ 
/*  346 */           QuadTreeNode quadNode = wnode.getQuadNode();
/*  347 */           if (quadNode != null) {
/*  348 */             List regionList = quadNode.getRegionByLoc(loc);
/*  349 */             if (regionList != null)
/*  350 */               synchronized (this) {
/*  351 */                 updateRegion(obj, regionList);
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private boolean zoneObject(AOObject obj, WMWorldNode wnode, Point loc)
/*      */     {
/*  361 */       QuadTreeNode quadNode = wnode.getQuadNode();
/*      */ 
/*  364 */       if (quadNode == null) {
/*  365 */         return false;
/*      */       }
/*  367 */       QuadTree quadtree = (QuadTree)WorldManagerPlugin.this.quadtrees.get(wnode.getInstanceOid());
/*      */ 
/*  369 */       if (quadtree == null) {
/*  370 */         WorldManagerPlugin.log.error("zoneObject: unknown instanceOid=" + wnode.getInstanceOid() + " oid=" + obj.getOid());
/*      */ 
/*  372 */         return false;
/*      */       }
/*      */ 
/*  377 */       if ((quadNode.getNodeType() != QuadTreeNode.NodeType.LOCAL) && (quadNode.containsPointWithHysteresis(loc)))
/*      */       {
/*  380 */         if (Log.loggingDebug) {
/*  381 */           WorldManagerPlugin.log.debug("Update.update: obj moved into non-local node, obj=" + obj + ", wnode=" + wnode);
/*      */         }
/*      */ 
/*  384 */         OID oid = obj.getOid();
/*      */ 
/*  387 */         if (!quadtree.removeElement(wnode)) {
/*  388 */           throw new AORuntimeException("Update.update: failed to remove element from quadtree: oid=" + oid);
/*      */         }
/*      */ 
/*  392 */         if (!WorldManagerPlugin.this.removeWorldManagerEntity(oid)) {
/*  393 */           Log.warn("Update.update: could not remove entity " + oid);
/*      */         }
/*  396 */         else if (Log.loggingDebug) {
/*  397 */           WorldManagerPlugin.log.debug("Update.update: removed entity from map " + oid);
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/*  402 */           Thread.sleep(2L);
/*      */         }
/*      */         catch (InterruptedException e1) {
/*  405 */           e1.printStackTrace();
/*      */         }
/*      */ 
/*  410 */         HashMap propMap = new HashMap();
/*  411 */         propMap.put(WorldManagerClient.MSG_PROP_LOC, loc);
/*  412 */         if (!WorldManagerPlugin.this.transferObject(propMap, obj)) {
/*  413 */           WorldManagerPlugin.log.error("Update.update: transfer failed for obj " + obj);
/*      */         }
/*      */ 
/*  431 */         if (Log.loggingDebug) {
/*  432 */           WorldManagerPlugin.log.debug("Update.update: done zoning oid " + oid);
/*      */         }
/*  434 */         return true;
/*      */       }
/*  436 */       return false;
/*      */     }
/*      */ 
/*      */     RegionConfig getPriorityRegionConfig(List<Region> regionList, String configType)
/*      */     {
/*  442 */       Region highestPriRegion = null;
/*  443 */       for (Region region : regionList)
/*      */       {
/*  445 */         RegionConfig config = region.getConfig(configType);
/*  446 */         if (config == null)
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/*  452 */         if (highestPriRegion == null)
/*      */         {
/*  454 */           highestPriRegion = region;
/*  455 */           continue;
/*      */         }
/*      */ 
/*  459 */         if (highestPriRegion.getPriority().intValue() > region.getPriority().intValue())
/*      */         {
/*  461 */           highestPriRegion = region;
/*      */         }
/*      */       }
/*  464 */       return highestPriRegion == null ? null : highestPriRegion.getConfig(configType);
/*      */     }
/*      */ 
/*      */     List<RegionConfig> getRegionConfigs(List<Region> regionList, String configType)
/*      */     {
/*  470 */       LinkedList configs = null;
/*  471 */       for (Region region : regionList) {
/*  472 */         RegionConfig config = region.getConfig(configType);
/*  473 */         if (config != null) {
/*  474 */           if (configs == null)
/*  475 */             configs = new LinkedList();
/*  476 */           configs.add(config);
/*      */         }
/*      */       }
/*  479 */       return configs;
/*      */     }
/*      */ 
/*      */     List<Region> getCustomRegionConfigs(List<Region> regionList)
/*      */     {
/*  484 */       List result = null;
/*  485 */       for (Region region : regionList) {
/*  486 */         if ((region.getProperty("onEnter") != null) || (region.getProperty("onLeave") != null))
/*      */         {
/*  488 */           if (result == null)
/*  489 */             result = new LinkedList();
/*  490 */           result.add(region);
/*      */         }
/*      */       }
/*  493 */       return result;
/*      */     }
/*      */ 
/*      */     void updateRegion(AOObject obj, List<Region> regionList)
/*      */     {
/*  503 */       List sConfig = getRegionConfigs(regionList, SoundRegionConfig.RegionType);
/*  504 */       updateSoundRegion(obj, sConfig);
/*      */ 
/*  507 */       FogRegionConfig fConfig = (FogRegionConfig)getPriorityRegionConfig(regionList, FogRegionConfig.RegionType);
/*  508 */       updateFogRegion(obj, fConfig);
/*      */ 
/*  511 */       RoadRegionConfig rConfig = (RoadRegionConfig)getPriorityRegionConfig(regionList, RoadRegionConfig.RegionType);
/*  512 */       updateRoadRegion(obj, rConfig);
/*      */ 
/*  515 */       RegionConfig dirLightConfig = getPriorityRegionConfig(regionList, LightData.DirLightRegionType);
/*  516 */       updateDirLightRegion(obj, dirLightConfig);
/*      */ 
/*  519 */       RegionConfig ambientConfig = getPriorityRegionConfig(regionList, LightData.AmbientLightRegionType);
/*  520 */       updateAmbientLightRegion(obj, ambientConfig);
/*      */ 
/*  522 */       List customRegions = getCustomRegionConfigs(regionList);
/*  523 */       updateCustomRegions(obj, customRegions);
/*      */     }
/*      */ 
/*      */     void updateFogRegion(AOObject obj, FogRegionConfig fogConfig)
/*      */     {
/*  529 */       FogRegionConfig curFog = (FogRegionConfig)obj.getProperty(FogRegionConfig.RegionType);
/*  530 */       if (fogConfig == null) {
/*  531 */         if (curFog != null)
/*      */         {
/*  533 */           obj.setProperty(FogRegionConfig.RegionType, null);
/*  534 */           Fog fog = WorldManagerPlugin.this.getInstanceFog(obj.worldNode().getInstanceOid());
/*  535 */           WorldManagerClient.FogMessage fogMsg = new WorldManagerClient.FogMessage(obj.getOid(), fog);
/*      */ 
/*  537 */           Engine.getAgent().sendBroadcast(fogMsg);
/*      */         }
/*      */ 
/*      */       }
/*  541 */       else if ((curFog == null) || (!fogConfig.equals(curFog)))
/*      */       {
/*  543 */         if (Log.loggingDebug) {
/*  544 */           WorldManagerPlugin.log.debug("updateFogRegion: new fog region: oldFog=" + curFog + ", newFog=" + fogConfig);
/*      */         }
/*  546 */         obj.setProperty(FogRegionConfig.RegionType, fogConfig);
/*  547 */         WorldManagerClient.FogMessage fogMsg = new WorldManagerClient.FogMessage(obj.getOid(), fogConfig);
/*  548 */         Engine.getAgent().sendBroadcast(fogMsg);
/*      */       }
/*      */     }
/*      */ 
/*      */     void updateCustomRegions(AOObject obj, List<Region> newRegions)
/*      */     {
/*  555 */       List currentRegions = (List)obj.getProperty(WorldManagerPlugin.REGION_MEMBERSHIP);
/*      */ 
/*  558 */       if (currentRegions == null) {
/*  559 */         if (newRegions == null)
/*  560 */           return;
/*  561 */         currentRegions = new LinkedList();
/*  562 */         obj.setProperty(WorldManagerPlugin.REGION_MEMBERSHIP, (Serializable)currentRegions);
/*      */       }
/*      */ 
/*  565 */       List left = new LinkedList();
/*      */ 
/*  567 */       ListIterator iter = currentRegions.listIterator();
/*  568 */       while (iter.hasNext()) {
/*  569 */         Region currentRegion = (Region)iter.next();
/*  570 */         boolean inside = false;
/*  571 */         if (newRegions != null) {
/*  572 */           for (Region newRegion : newRegions) {
/*  573 */             if (newRegion == currentRegion)
/*  574 */               inside = true;
/*      */           }
/*      */         }
/*  577 */         if (!inside) {
/*  578 */           left.add(currentRegion);
/*  579 */           iter.remove();
/*      */         }
/*      */       }
/*      */ 
/*  583 */       handleLeaveRegion(obj, left);
/*      */ 
/*  585 */       List entered = new LinkedList();
/*  586 */       if (newRegions != null) {
/*  587 */         for (Region newRegion : newRegions) {
/*  588 */           boolean existing = false;
/*  589 */           for (Region currentRegion : currentRegions) {
/*  590 */             if (currentRegion == newRegion)
/*  591 */               existing = true;
/*      */           }
/*  593 */           if (!existing)
/*  594 */             entered.add(newRegion);
/*      */         }
/*  596 */         currentRegions.addAll(entered);
/*  597 */         handleEnterRegion(obj, entered);
/*      */       }
/*      */     }
/*      */ 
/*      */     void handleLeaveRegion(AOObject obj, List<Region> left)
/*      */     {
/*  604 */       for (Region region : left) {
/*  605 */         String onLeave = (String)region.getProperty("onLeave");
/*  606 */         if (onLeave == null)
/*      */           continue;
/*  608 */         handleRegionChange(obj, region, "leave", onLeave);
/*      */       }
/*      */     }
/*      */ 
/*      */     void handleEnterRegion(AOObject obj, List<Region> left)
/*      */     {
/*  614 */       for (Region region : left) {
/*  615 */         String onEnter = (String)region.getProperty("onEnter");
/*  616 */         if (onEnter == null)
/*      */           continue;
/*  618 */         handleRegionChange(obj, region, "enter", onEnter);
/*      */       }
/*      */     }
/*      */ 
/*      */     void handleRegionChange(AOObject obj, Region region, String action, String triggerName)
/*      */     {
/*  625 */       if (Log.loggingDebug) {
/*  626 */         Log.debug("Custom RegionTrigger: " + obj + " regionName=" + region.getName() + " action=" + action + " trigger=" + triggerName);
/*      */       }
/*      */ 
/*  630 */       RegionTrigger trigger = (RegionTrigger)WorldManagerPlugin.this.regionTriggers.get(triggerName);
/*      */ 
/*  632 */       if (trigger == null) {
/*  633 */         Log.error("unknown RegionTrigger name=" + triggerName + ", object=" + obj + " region=" + region + " action=" + action);
/*      */ 
/*  635 */         return;
/*      */       }
/*      */       try
/*      */       {
/*  639 */         if (action.equals("enter"))
/*  640 */           trigger.enter(obj, region);
/*  641 */         else if (action.equals("leave"))
/*  642 */           trigger.leave(obj, region);
/*      */       }
/*      */       catch (Exception e) {
/*  645 */         Log.exception("RegionTrigger exception trigger name=" + triggerName, e);
/*      */       }
/*      */     }
/*      */ 
/*      */     void updateSoundRegion(AOObject obj, List<RegionConfig> soundConfig)
/*      */     {
/*  651 */       List curSound = (List)obj.getProperty(SoundManager.AMBIENTSOUND);
/*      */ 
/*  653 */       if (curSound == null) {
/*  654 */         if (soundConfig == null)
/*  655 */           return;
/*  656 */         curSound = new LinkedList();
/*  657 */         obj.setProperty(SoundManager.AMBIENTSOUND, (Serializable)curSound);
/*      */       }
/*      */ 
/*  662 */       List turnOff = new LinkedList();
/*  663 */       ListIterator iter = curSound.listIterator();
/*  664 */       while (iter.hasNext()) {
/*  665 */         SoundData data = (SoundData)iter.next();
/*  666 */         String fileName = data.getFileName();
/*  667 */         boolean on = false;
/*  668 */         if (soundConfig != null) {
/*  669 */           for (RegionConfig config : soundConfig) {
/*  670 */             SoundRegionConfig sConfig = (SoundRegionConfig)config;
/*  671 */             if (sConfig.containsSound(fileName)) {
/*  672 */               on = true;
/*  673 */               break;
/*      */             }
/*      */           }
/*      */         }
/*  677 */         if (!on) {
/*  678 */           turnOff.add(data);
/*  679 */           iter.remove();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  684 */       List turnOn = new LinkedList();
/*  685 */       if (soundConfig != null) {
/*  686 */         for (RegionConfig config : soundConfig) {
/*  687 */           SoundRegionConfig sConfig = (SoundRegionConfig)config;
/*  688 */           for (SoundData data : sConfig.getSoundData()) {
/*  689 */             boolean on = false;
/*  690 */             String fileName = data.getFileName();
/*  691 */             for (SoundData curData : curSound) {
/*  692 */               if (curData.getFileName().equals(fileName)) {
/*  693 */                 on = true;
/*      */               }
/*      */             }
/*  696 */             if (!on) {
/*  697 */               turnOn.add(data);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  703 */       if ((turnOn.size() == 0) && (turnOff.size() == 0)) {
/*  704 */         return;
/*      */       }
/*      */ 
/*  709 */       WorldManagerClient.SoundMessage soundMsg = new WorldManagerClient.SoundMessage(obj.getOid());
/*  710 */       soundMsg.setTarget(obj.getOid());
/*  711 */       soundMsg.setType(2);
/*      */ 
/*  713 */       for (SoundData data : turnOff) {
/*  714 */         soundMsg.removeSound(data.getFileName());
/*      */       }
/*      */ 
/*  719 */       List turnedOn = new LinkedList();
/*  720 */       for (SoundData data : turnOn) {
/*  721 */         if (!turnedOn.contains(data.getFileName())) {
/*  722 */           soundMsg.addSound(data);
/*  723 */           curSound.add(data);
/*      */         }
/*      */       }
/*      */ 
/*  727 */       if (curSound.size() == 0) {
/*  728 */         obj.setProperty(SoundManager.AMBIENTSOUND, null);
/*      */       }
/*      */ 
/*  733 */       Engine.getAgent().sendBroadcast(soundMsg);
/*      */     }
/*      */ 
/*      */     void updateRoadRegion(AOObject obj, RoadRegionConfig roadConfig)
/*      */     {
/*  738 */       RoadRegionConfig curRoadRegion = (RoadRegionConfig)obj.getProperty(RoadRegionConfig.RegionType);
/*      */ 
/*  741 */       if (roadConfig == null) {
/*  742 */         if (curRoadRegion != null) {
/*  743 */           obj.setProperty(RoadRegionConfig.RegionType, null);
/*  744 */           WorldManagerClient.FreeRoadMessage freeRoadMsg = new WorldManagerClient.FreeRoadMessage(obj.getOid());
/*      */ 
/*  746 */           Engine.getAgent().sendBroadcast(freeRoadMsg);
/*      */         }
/*  748 */         return;
/*      */       }
/*      */ 
/*  751 */       if (curRoadRegion != null)
/*      */       {
/*  753 */         return;
/*      */       }
/*      */ 
/*  757 */       WorldManagerClient.RoadMessage roadMsg = new WorldManagerClient.RoadMessage(obj.getOid(), roadConfig.getRoads());
/*      */ 
/*  760 */       Engine.getAgent().sendBroadcast(roadMsg);
/*  761 */       obj.setProperty(RoadRegionConfig.RegionType, roadConfig);
/*  762 */       WorldManagerPlugin.log.debug("updateRoadRegion: sent road region");
/*      */     }
/*      */ 
/*      */     void updateDirLightRegion(AOObject obj, RegionConfig regionConfig)
/*      */     {
/*  771 */       OID curLightOid = (OID)obj.getProperty(LightData.DirLightRegionType);
/*  772 */       OID masterOid = obj.getMasterOid();
/*      */ 
/*  774 */       if (regionConfig == null)
/*      */       {
/*  776 */         if (curLightOid != null)
/*      */         {
/*  778 */           if (Log.loggingDebug)
/*  779 */             WorldManagerPlugin.log.debug("updateDirLightRegion: free light: " + curLightOid);
/*  780 */           Message freeMsg = new WorldManagerClient.FreeObjectMessage(masterOid, curLightOid);
/*      */ 
/*  783 */           Engine.getAgent().sendBroadcast(freeMsg);
/*      */ 
/*  786 */           obj.setProperty(LightData.DirLightRegionType, null);
/*      */         }
/*  788 */         return;
/*      */       }
/*      */ 
/*  791 */       Light dirLight = null;
/*      */ 
/*  795 */       this.dirLightLock.lock();
/*      */       try
/*      */       {
/*  798 */         dirLight = (Light)regionConfig.getProperty("spawnLight");
/*      */ 
/*  800 */         if (dirLight == null)
/*      */         {
/*  803 */           Quaternion orient = (Quaternion)regionConfig.getProperty("orient");
/*  804 */           Color specular = (Color)regionConfig.getProperty("specular");
/*  805 */           Color diffuse = (Color)regionConfig.getProperty("diffuse");
/*  806 */           String name = (String)regionConfig.getProperty("name");
/*  807 */           if (Log.loggingDebug) {
/*  808 */             WorldManagerPlugin.log.debug("updateDirLightRegion: none found, creating spawned light, diffuse=" + diffuse + ", specular=" + specular + ", orient=" + orient);
/*      */           }
/*      */ 
/*  812 */           dirLight = new Light();
/*  813 */           dirLight.setOid((OID)regionConfig.getProperty("_oid"));
/*  814 */           dirLight.setName("light_" + dirLight.getOid());
/*  815 */           LightData lightData = new LightData();
/*  816 */           lightData.setName(name);
/*  817 */           lightData.setDiffuse(diffuse);
/*  818 */           lightData.setSpecular(specular);
/*  819 */           lightData.setAttenuationRange(100.0F);
/*  820 */           lightData.setAttenuationConstant(1.0F);
/*  821 */           lightData.setOrientation(orient);
/*  822 */           dirLight.setLightData(lightData);
/*  823 */           regionConfig.setProperty("spawnLight", dirLight);
/*  824 */           if (Log.loggingDebug)
/*  825 */             WorldManagerPlugin.log.debug("updateDirLightRegion: spawned dir light=" + dirLight + ", ld=" + dirLight.getLightData());
/*      */         }
/*      */       }
/*      */       finally {
/*  829 */         this.dirLightLock.unlock();
/*      */       }
/*  831 */       OID regionLightOid = dirLight.getOid();
/*  832 */       if ((curLightOid != null) && (curLightOid.equals(regionLightOid))) {
/*  833 */         return;
/*      */       }
/*      */ 
/*  836 */       if (curLightOid != null)
/*      */       {
/*  838 */         if (Log.loggingDebug)
/*  839 */           WorldManagerPlugin.log.debug("updateDirLightRegion: need to free existing light: " + curLightOid);
/*  840 */         Message freeMsg = new WorldManagerClient.FreeObjectMessage(masterOid, curLightOid);
/*      */ 
/*  843 */         Engine.getAgent().sendBroadcast(freeMsg);
/*      */       }
/*      */ 
/*  847 */       if ((curLightOid == null) || (!curLightOid.equals(regionLightOid))) {
/*  848 */         LightData lightData = dirLight.getLightData();
/*  849 */         if (Log.loggingDebug)
/*  850 */           WorldManagerPlugin.log.debug("updateDirLightRegion: sending over new light: " + regionLightOid + ", ld=" + lightData);
/*  851 */         Message newDirLightMsg = new WorldManagerClient.NewDirLightMessage(masterOid, dirLight.getOid(), lightData);
/*      */ 
/*  854 */         Engine.getAgent().sendBroadcast(newDirLightMsg);
/*      */ 
/*  857 */         if (Log.loggingDebug)
/*  858 */           WorldManagerPlugin.log.debug("updateDirLightRegion: setting users new current light to " + regionLightOid);
/*  859 */         obj.setProperty(LightData.DirLightRegionType, regionLightOid);
/*      */       }
/*      */     }
/*      */ 
/*      */     void updateAmbientLightRegion(AOObject obj, RegionConfig ambientConfig)
/*      */     {
/*  865 */       Color curAmbient = (Color)obj.getProperty(LightData.AmbientLightRegionType);
/*      */ 
/*  868 */       if (ambientConfig == null) {
/*  869 */         if (curAmbient != null)
/*      */         {
/*  872 */           WorldManagerPlugin.log.debug("updateAmbientLightRegion: user had light, but region does not, sending black");
/*  873 */           obj.setProperty(LightData.AmbientLightRegionType, null);
/*  874 */           Engine.getAgent().sendBroadcast(new WorldManagerClient.SetAmbientLightMessage(obj.getMasterOid(), new Color(0, 0, 0)));
/*  875 */           return;
/*      */         }
/*      */ 
/*  880 */         return;
/*      */       }
/*      */ 
/*  885 */       Color ambientColor = (Color)ambientConfig.getProperty("color");
/*  886 */       if (ambientColor == null) {
/*  887 */         WorldManagerPlugin.log.error("updateAmbientLight: ambient color not defined");
/*  888 */         return;
/*      */       }
/*  890 */       if (ambientColor.equals(curAmbient))
/*      */       {
/*  892 */         return;
/*      */       }
/*      */ 
/*  896 */       WorldManagerPlugin.log.debug("updateAmbientLightRegion: colors differ, updating client");
/*  897 */       obj.setProperty(LightData.AmbientLightRegionType, ambientColor);
/*  898 */       Engine.getAgent().sendBroadcast(new WorldManagerClient.SetAmbientLightMessage(obj.getMasterOid(), ambientColor));
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.WorldManagerPlugin
 * JD-Core Version:    0.6.0
 */