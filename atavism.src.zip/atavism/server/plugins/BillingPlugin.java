/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageTypeFilter;
/*     */ import atavism.msgsys.ResponseMessage;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.EnginePlugin;
/*     */ import atavism.server.engine.EnginePlugin.GenerateSubObjectHook;
/*     */ import atavism.server.engine.EnginePlugin.SubObjData;
/*     */ import atavism.server.engine.Hook;
/*     */ import atavism.server.engine.HookManager;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.messages.LoginMessage;
/*     */ import atavism.server.messages.LogoutMessage;
/*     */ import atavism.server.objects.Entity;
/*     */ import atavism.server.objects.EntityManager;
/*     */ import atavism.server.objects.Template;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class BillingPlugin extends EnginePlugin
/*     */ {
/*  40 */   protected Lock lock = LockFactory.makeLock("BillingPlugin");
/*     */ 
/*  54 */   private static final Logger log = new Logger("BillingPlugin");
/*     */ 
/*     */   public BillingPlugin()
/*     */   {
/*  43 */     super("Billing");
/*  44 */     setPluginType("Billing");
/*     */   }
/*     */ 
/*     */   public void onActivate()
/*     */   {
/*  57 */     super.onActivate();
/*     */ 
/*  60 */     registerHooks();
/*     */ 
/*  62 */     MessageTypeFilter responderFilter = new MessageTypeFilter();
/*     */ 
/*  64 */     responderFilter.addType(BillingClient.MSG_TYPE_GET_TOKEN_BALANCE);
/*  65 */     responderFilter.addType(BillingClient.MSG_TYPE_DECREMENT_TOKEN_BALANCE);
/*  66 */     responderFilter.addType(LogoutMessage.MSG_TYPE_LOGOUT);
/*  67 */     responderFilter.addType(LoginMessage.MSG_TYPE_LOGIN);
/*  68 */     Engine.getAgent().createSubscription(responderFilter, this, 8);
/*     */ 
/*  70 */     registerPluginNamespace(BillingClient.NAMESPACE, new BillingSubObjectHook());
/*     */ 
/*  72 */     if (Log.loggingDebug)
/*  73 */       log.debug("BillingPlugin activated");
/*     */   }
/*     */ 
/*     */   public void registerHooks() {
/*  77 */     getHookManager().addHook(BillingClient.MSG_TYPE_GET_TOKEN_BALANCE, new GetTokenBalanceHook());
/*     */ 
/*  79 */     getHookManager().addHook(BillingClient.MSG_TYPE_DECREMENT_TOKEN_BALANCE, new UpdateTokenBalanceHook());
/*     */ 
/*  81 */     getHookManager().addHook(LogoutMessage.MSG_TYPE_LOGOUT, new LogOutHook());
/*     */ 
/*  83 */     getHookManager().addHook(LoginMessage.MSG_TYPE_LOGIN, new LoginHook());
/*     */   }
/*     */ 
/*     */   public static EnginePlugin.SubObjData createBillingSubObject(Template template, Namespace namespace, OID masterOid)
/*     */   {
/*  96 */     if (Log.loggingDebug) {
/*  97 */       log.debug("createBillingSubObject: masterOid=" + masterOid + ", template=" + template);
/*     */     }
/*     */ 
/* 100 */     if (masterOid == null) {
/* 101 */       log.error("createBillingSubObject: no master oid");
/* 102 */       return null;
/*     */     }
/*     */ 
/* 105 */     if (Log.loggingDebug) {
/* 106 */       log.debug("createBillingSubObject: masterOid=" + masterOid + ", template=" + template);
/*     */     }
/* 108 */     Map props = template.getSubMap(BillingClient.NAMESPACE);
/*     */ 
/* 110 */     if (props == null) {
/* 111 */       log.warn("createBillingSubObject: no props in ns " + BillingClient.NAMESPACE);
/*     */ 
/* 113 */       return null;
/*     */     }
/*     */ 
/* 117 */     Entity tinfo = new Entity(masterOid);
/* 118 */     tinfo.setName(template.getName());
/*     */ 
/* 121 */     for (Map.Entry entry : props.entrySet()) {
/* 122 */       String key = (String)entry.getKey();
/* 123 */       Serializable value = (Serializable)entry.getValue();
/* 124 */       if (!key.startsWith(":")) {
/* 125 */         tinfo.setProperty(key, value);
/*     */       }
/*     */     }
/*     */ 
/* 129 */     if (Log.loggingDebug) {
/* 130 */       log.debug("createBillingSubObject: created entity " + tinfo);
/*     */     }
/*     */ 
/* 133 */     EntityManager.registerEntityByNamespace(tinfo, BillingClient.NAMESPACE);
/*     */ 
/* 136 */     return new EnginePlugin.SubObjData();
/*     */   }
/*     */ 
/*     */   public static void runEchoTest()
/*     */   {
/*     */   }
/*     */ 
/*     */   private Float getTokenBalance(Integer accountId, String worldId)
/*     */   {
/* 155 */     this.lock.lock();
/*     */     try {
/* 157 */       Float localFloat1 = Float.valueOf(100.0F);
/*     */       return localFloat1;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 179 */       log.exception("getTokenBalance - " + e.toString(), e);
/* 180 */       Float localFloat2 = new Float(0.0F);
/*     */       return localFloat2; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   private Float updateTokenBalance(Integer accountId, String worldId, Float amount, HashSet<Serializable> purchasedItems, OID playerOid)
/*     */   {
/* 189 */     this.lock.lock();
/*     */     try {
/* 191 */       if (amount.floatValue() > 0.0D) {
/* 192 */         log.error("updateTokenBalance - Amount must be nonpositive.");
/* 193 */         localFloat1 = new Float(0.0F);
/*     */         return localFloat1;
/*     */       }
/* 196 */       Float localFloat1 = Float.valueOf(100.0F + amount.floatValue());
/*     */       return localFloat1;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 233 */       log.exception("updateTokenBalance - " + e.toString(), e);
/* 234 */       Float localFloat2 = new Float(0.0F);
/*     */       return localFloat2; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   // ERROR //
/*     */   private void handleLoginLogOutMessage(String type, Integer accountId, OID playerOid)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	atavism/server/plugins/BillingPlugin:lock	Ljava/util/concurrent/locks/Lock;
/*     */     //   4: invokeinterface 71 1 0
/*     */     //   9: aload_0
/*     */     //   10: getfield 9	atavism/server/plugins/BillingPlugin:lock	Ljava/util/concurrent/locks/Lock;
/*     */     //   13: invokeinterface 74 1 0
/*     */     //   18: goto +17 -> 35
/*     */     //   21: astore 4
/*     */     //   23: aload_0
/*     */     //   24: getfield 9	atavism/server/plugins/BillingPlugin:lock	Ljava/util/concurrent/locks/Lock;
/*     */     //   27: invokeinterface 74 1 0
/*     */     //   32: aload 4
/*     */     //   34: athrow
/*     */     //   35: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   21	23	21	finally
/*     */   }
/*     */ 
/*     */   class LoginHook
/*     */     implements Hook
/*     */   {
/*     */     LoginHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 350 */       LoginMessage loginMsg = (LoginMessage)msg;
/* 351 */       OID playerOid = loginMsg.getSubject();
/* 352 */       Integer accountId = (Integer)EnginePlugin.getObjectProperty(playerOid, Namespace.WORLD_MANAGER, "AccountId");
/*     */ 
/* 355 */       String endPoint = Engine.properties.getProperty("atavism.service_endpoint");
/* 356 */       if ((endPoint != null) && (endPoint.length() > 0)) {
/* 357 */         BillingPlugin.this.handleLoginLogOutMessage("in", accountId, playerOid);
/*     */       }
/* 359 */       Engine.getAgent().sendResponse(new ResponseMessage(loginMsg));
/* 360 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class LogOutHook
/*     */     implements Hook
/*     */   {
/*     */     LogOutHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 334 */       LogoutMessage logoutMsg = (LogoutMessage)msg;
/* 335 */       OID playerOid = logoutMsg.getSubject();
/* 336 */       Integer accountId = (Integer)EnginePlugin.getObjectProperty(playerOid, Namespace.WORLD_MANAGER, "AccountId");
/*     */ 
/* 339 */       String endPoint = Engine.properties.getProperty("atavism.service_endpoint");
/* 340 */       if ((endPoint != null) && (endPoint.length() > 0)) {
/* 341 */         BillingPlugin.this.handleLoginLogOutMessage("out", accountId, playerOid);
/*     */       }
/* 343 */       Engine.getAgent().sendResponse(new ResponseMessage(logoutMsg));
/* 344 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class UpdateTokenBalanceHook
/*     */     implements Hook
/*     */   {
/*     */     UpdateTokenBalanceHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 315 */       WorldManagerClient.ExtensionMessage message = (WorldManagerClient.ExtensionMessage)msg;
/*     */ 
/* 317 */       OID playerOid = message.getSubject();
/* 318 */       Integer accountId = (Integer)EnginePlugin.getObjectProperty(playerOid, Namespace.WORLD_MANAGER, "AccountId");
/* 319 */       String worldId = Engine.getWorldName();
/* 320 */       Float balance = Float.valueOf(0.0F);
/*     */ 
/* 322 */       String endPoint = Engine.properties.getProperty("atavism.service_endpoint");
/* 323 */       if ((endPoint != null) && (endPoint.length() > 0)) {
/* 324 */         balance = BillingPlugin.this.updateTokenBalance(accountId, worldId, (Float)message.getProperty("amount"), (HashSet)message.getProperty("purchasedItems"), playerOid);
/*     */       }
/* 326 */       Engine.getAgent().sendObjectResponse(msg, balance);
/*     */ 
/* 328 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class GetTokenBalanceHook
/*     */     implements Hook
/*     */   {
/*     */     GetTokenBalanceHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 296 */       WorldManagerClient.ExtensionMessage message = (WorldManagerClient.ExtensionMessage)msg;
/*     */ 
/* 298 */       OID playerOid = message.getSubject();
/* 299 */       Integer accountId = (Integer)EnginePlugin.getObjectProperty(playerOid, Namespace.WORLD_MANAGER, "AccountId");
/* 300 */       String worldId = Engine.getWorldName();
/* 301 */       BillingPlugin.log.info("GET TOKEN BALANCE VARIABLES: " + accountId + " : " + worldId);
/* 302 */       Float balance = Float.valueOf(0.0F);
/*     */ 
/* 304 */       String endPoint = Engine.properties.getProperty("atavism.service_endpoint");
/* 305 */       if ((endPoint != null) && (endPoint.length() > 0)) {
/* 306 */         balance = BillingPlugin.this.getTokenBalance(accountId, worldId);
/*     */       }
/* 308 */       Engine.getAgent().sendObjectResponse(msg, balance);
/* 309 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class BillingSubObjectHook extends EnginePlugin.GenerateSubObjectHook
/*     */   {
/*     */     public BillingSubObjectHook()
/*     */     {
/*  88 */       super();
/*     */     }
/*     */     public EnginePlugin.SubObjData generateSubObject(Template template, Namespace namespace, OID masterOid) {
/*  91 */       return BillingPlugin.createBillingSubObject(template, namespace, masterOid);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.BillingPlugin
 * JD-Core Version:    0.6.0
 */