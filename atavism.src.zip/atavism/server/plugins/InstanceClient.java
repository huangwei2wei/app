/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.msgsys.GenericMessage;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageType;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.msgsys.TargetMessage;
/*      */ import atavism.server.engine.BasicWorldNode;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.Namespace;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.engine.TerrainConfig;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.objects.Color;
/*      */ import atavism.server.objects.Fog;
/*      */ import atavism.server.objects.LightData;
/*      */ import atavism.server.objects.Marker;
/*      */ import atavism.server.objects.OceanData;
/*      */ import atavism.server.objects.Region;
/*      */ import atavism.server.objects.Template;
/*      */ import atavism.server.util.Log;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ public class InstanceClient
/*      */ {
/*      */   public static final int FLAG_OID = 1;
/*      */   public static final int FLAG_NAME = 2;
/*      */   public static final int FLAG_TEMPLATE_NAME = 4;
/*      */   public static final int FLAG_SKYBOX = 8;
/*      */   public static final int FLAG_FOG = 16;
/*      */   public static final int FLAG_AMBIENT_LIGHT = 32;
/*      */   public static final int FLAG_DIR_LIGHT = 64;
/*      */   public static final int FLAG_OCEAN = 128;
/*      */   public static final int FLAG_WORLDFILE = 256;
/*      */   public static final int FLAG_TERRAIN = 512;
/*      */   public static final int FLAG_REGION_CONFIG = 1024;
/*      */   public static final int FLAG_PLAYER_POPULATION = 2048;
/*      */   public static final int FLAG_POPULATION_LIMIT = 4096;
/*      */   public static final int FLAG_MULTIPLE = 8192;
/*      */   public static final int FLAG_ALL_INFO = -8193;
/*      */   public static final long REGION_BOUNDARY = 1L;
/*      */   public static final long REGION_PROPERTIES = 2L;
/*      */   public static final long REGION_ALL = 3L;
/*      */   public static final int RESULT_OK = 0;
/*      */   public static final int RESULT_ERROR_UNKNOWN_OBJECT = -1;
/*      */   public static final int RESULT_ERROR_INTERNAL = -2;
/*      */   public static final int RESULT_ERROR_NO_WORLD_MANAGER = -3;
/*      */   public static final int RESULT_ERROR_RETRY = -4;
/*  917 */   public static Namespace NAMESPACE = null;
/*      */   public static final String TEMPL_INSTANCE_TEMPLATE_NAME = "templateName";
/*      */   public static final String TEMPL_WORLD_FILE_NAME = "worldFileName";
/*      */   public static final String TEMPL_INIT_SCRIPT_FILE_NAME = "initScriptFileName";
/*      */   public static final String TEMPL_LOAD_SCRIPT_FILE_NAME = "loadScriptFileName";
/*      */   public static final String TEMPL_TERRAIN_CONFIG_FILE = "terrainConfigFile";
/*      */   public static final String TEMPL_INSTANCE_NAME = "name";
/*      */   public static final String TEMPL_LOADER_OVERRIDE_NAME = "loaderOverrideName";
/*      */   public static final String TEMPL_UNIQUE_NAME = "uniqueName";
/*      */   public static final String TEMPL_COLLISION_POINTS = "collisionPoints";
/*      */   public static final String TEMPL_ASSET_INFO = "assetInfo";
/*      */   public static final String TEMPL_WORLD_COLLECTION_FILES = "worldCollectionFiles";
/*      */   public static final String TEMPL_WORLD_COLLECTION_DATABASE_KEYS = "worldCollectionDatabaseKeys";
/*      */   public static final String TEMPL_POPULATION_LIMIT = "populationLimit";
/*      */   public static final String COLLECTION_STATIC_OBJECTS = "static_objects";
/*      */   public static final String COLLECTION_MARKER_OBJECTS = "marker_objects";
/* 1006 */   public static final MessageType MSG_TYPE_REGISTER_INSTANCE_TEMPLATE = MessageType.intern("ao.REGISTER_INSTANCE_TEMPLATE");
/*      */ 
/* 1008 */   public static final MessageType MSG_TYPE_CREATE_INSTANCE = MessageType.intern("ao.CREATE_INSTANCE");
/*      */ 
/* 1010 */   public static final MessageType MSG_TYPE_GET_INSTANCE_INFO = MessageType.intern("ao.GET_INSTANCE_INFO");
/*      */ 
/* 1012 */   public static final MessageType MSG_TYPE_GET_MARKER = MessageType.intern("ao.GET_MARKER");
/*      */ 
/* 1014 */   public static final MessageType MSG_TYPE_GET_REGION = MessageType.intern("ao.GET_REGION");
/*      */ 
/* 1016 */   public static final MessageType MSG_TYPE_LOAD_INSTANCE = MessageType.intern("ao.LOAD_INSTANCE");
/*      */ 
/* 1018 */   public static final MessageType MSG_TYPE_UNLOAD_INSTANCE = MessageType.intern("ao.UNLOAD_INSTANCE");
/*      */ 
/* 1020 */   public static final MessageType MSG_TYPE_DELETE_INSTANCE = MessageType.intern("ao.DELETE_INSTANCE");
/*      */ 
/* 1022 */   public static final MessageType MSG_TYPE_LOAD_INSTANCE_CONTENT = MessageType.intern("ao.LOAD_INSTANCE_CONTENT");
/*      */ 
/* 1024 */   public static final MessageType MSG_TYPE_INSTANCE_UNLOADED = MessageType.intern("ao.INSTANCE_UNLOADED");
/*      */ 
/* 1026 */   public static final MessageType MSG_TYPE_INSTANCE_DELETED = MessageType.intern("ao.INSTANCE_DELETED");
/*      */ 
/* 1028 */   public static final MessageType MSG_TYPE_INSTANCE_LOADED = MessageType.intern("ao.INSTANCE_LOADED");
/*      */ 
/* 1031 */   public static MessageType MSG_TYPE_INSTANCE_ENTRY_REQ = MessageType.intern("ao.INSTANCE_ENTRY_REQ");
/*      */ 
/* 1033 */   public static MessageType MSG_TYPE_GET_ENTITY_OIDS = MessageType.intern("ao.GET_ENTITY_OIDS");
/*      */ 
/* 1036 */   public static MessageType MSG_TYPE_LOAD_INSTANCE_BY_NAME = MessageType.intern("ao.LOAD_INSTANCE_BY_NAME");
/*      */ 
/* 1039 */   public static MessageType MSG_TYPE_GET_NAVMESH_PATH = MessageType.intern("ao.GET_NAVMESH_PATH");
/*      */ 
/*      */   public static boolean registerInstanceTemplate(Template template)
/*      */   {
/*   76 */     RegisterInstanceTemplateMessage message = new RegisterInstanceTemplateMessage(template);
/*      */ 
/*   78 */     return Engine.getAgent().sendRPCReturnBoolean(message).booleanValue();
/*      */   }
/*      */ 
/*      */   public static OID createInstance(String templateName, Template override)
/*      */   {
/*  112 */     CreateInstanceMessage message = new CreateInstanceMessage(templateName, override);
/*      */ 
/*  114 */     return Engine.getAgent().sendRPCReturnOID(message);
/*      */   }
/*      */ 
/*      */   public static int loadInstance(OID instanceOid)
/*      */   {
/*  140 */     SubjectMessage message = new SubjectMessage(MSG_TYPE_LOAD_INSTANCE, instanceOid);
/*      */ 
/*  142 */     return Engine.getAgent().sendRPCReturnInt(message).intValue();
/*      */   }
/*      */ 
/*      */   public static boolean unloadInstance(OID instanceOid)
/*      */   {
/*  162 */     SubjectMessage message = new SubjectMessage(MSG_TYPE_UNLOAD_INSTANCE, instanceOid);
/*      */ 
/*  164 */     return Engine.getAgent().sendRPCReturnBoolean(message).booleanValue();
/*      */   }
/*      */ 
/*      */   public static boolean deleteInstance(OID instanceOid)
/*      */   {
/*  184 */     SubjectMessage message = new SubjectMessage(MSG_TYPE_DELETE_INSTANCE, instanceOid);
/*      */ 
/*  186 */     return Engine.getAgent().sendRPCReturnBoolean(message).booleanValue();
/*      */   }
/*      */ 
/*      */   public static OID loadInstance(String instanceName)
/*      */   {
/*  196 */     GenericMessage message = new GenericMessage(MSG_TYPE_LOAD_INSTANCE_BY_NAME);
/*  197 */     message.setProperty("instanceName", instanceName);
/*  198 */     OID instanceOid = (OID)Engine.getAgent().sendRPCReturnObject(message);
/*      */ 
/*  200 */     return instanceOid;
/*      */   }
/*      */ 
/*      */   public static OID getInstanceOid(String instanceName)
/*      */   {
/*  210 */     GetInstanceInfoMessage message = new GetInstanceInfoMessage(instanceName, 1);
/*      */ 
/*  213 */     InstanceInfo info = (InstanceInfo)Engine.getAgent().sendRPCReturnObject(message);
/*      */ 
/*  215 */     if (info != null) {
/*  216 */       return info.oid;
/*      */     }
/*  218 */     return null;
/*      */   }
/*      */ 
/*      */   public static List<OID> getInstanceOids(String instanceName)
/*      */   {
/*  228 */     GetInstanceInfoMessage message = new GetInstanceInfoMessage(instanceName, 8193);
/*      */ 
/*  231 */     List info = (List)Engine.getAgent().sendRPCReturnObject(message);
/*      */ 
/*  233 */     if (info != null) {
/*  234 */       List oids = new ArrayList(info.size());
/*  235 */       for (InstanceInfo ii : info)
/*  236 */         oids.add(ii.oid);
/*  237 */       return oids;
/*      */     }
/*      */ 
/*  240 */     return null;
/*      */   }
/*      */ 
/*      */   public static List<OID> getMatchingEntityOids(String entityName)
/*      */   {
/*  251 */     GetMatchingEntityOidsMessage message = new GetMatchingEntityOidsMessage(entityName);
/*      */ 
/*  253 */     List oids = (List)Engine.getAgent().sendRPCReturnObject(message);
/*      */ 
/*  255 */     return oids;
/*      */   }
/*      */ 
/*      */   public static List<Point> getNavMeshPath(OID mobOid, Point startLoc, Point endLoc)
/*      */   {
/*  264 */     GetNavMeshPathMessage message = new GetNavMeshPathMessage(mobOid, startLoc, endLoc);
/*      */ 
/*  266 */     List points = (List)Engine.getAgent().sendRPCReturnObject(message);
/*  267 */     return points;
/*      */   }
/*      */ 
/*      */   public static InstanceInfo getInstanceInfo(OID instanceOid, int flags)
/*      */   {
/*  311 */     GetInstanceInfoMessage message = new GetInstanceInfoMessage(instanceOid, flags);
/*      */ 
/*  313 */     return (InstanceInfo)Engine.getAgent().sendRPCReturnObject(message);
/*      */   }
/*      */ 
/*      */   public static List<InstanceInfo> getInstanceInfoByName(String instanceName, int flags)
/*      */   {
/*  327 */     GetInstanceInfoMessage message = new GetInstanceInfoMessage(instanceName, flags | 0x2000);
/*      */ 
/*  329 */     return (List)Engine.getAgent().sendRPCReturnObject(message);
/*      */   }
/*      */ 
/*      */   public static Marker getMarker(OID defaultInstanceOid, String markerName)
/*      */   {
/*  340 */     List oidList = ObjectManagerClient.getMatchingObjects(defaultInstanceOid, markerName, Marker.OBJECT_TYPE, null);
/*  341 */     if (oidList.size() == 1) {
/*  342 */       OID oid = (OID)oidList.get(0);
/*  343 */       BasicWorldNode wNode = WorldManagerClient.getWorldNode(oid);
/*  344 */       return new Marker(wNode.getLoc(), wNode.getOrientation());
/*      */     }
/*  346 */     if (oidList.size() == 0)
/*  347 */       Log.warn("No matching markers found for marker name: " + markerName);
/*      */     else {
/*  349 */       Log.warn("Multiple (" + oidList.size() + ") matching markers found for marker name: " + markerName);
/*      */     }
/*  351 */     return null;
/*      */   }
/*      */ 
/*      */   public static Point getMarkerPoint(OID instanceOid, String markerName)
/*      */   {
/*  361 */     Marker marker = getMarker(instanceOid, markerName);
/*  362 */     if (marker != null) {
/*  363 */       return marker.getPoint();
/*      */     }
/*  365 */     return null;
/*      */   }
/*      */ 
/*      */   public static Region getRegion(OID instanceOid, String regionName, long flags)
/*      */   {
/*  389 */     GetRegionMessage message = new GetRegionMessage(instanceOid, regionName, flags);
/*      */ 
/*  391 */     return (Region)Engine.getAgent().sendRPCReturnObject(message);
/*      */   }
/*      */ 
/*      */   public static boolean objectInstanceEntry(OID oid, BasicWorldNode instanceLoc, int flags, BasicWorldNode restoreWnode)
/*      */   {
/*  424 */     InstanceEntryReqMessage message = new InstanceEntryReqMessage(oid, instanceLoc, flags, restoreWnode);
/*      */ 
/*  426 */     return Engine.getAgent().sendRPCReturnBoolean(message).booleanValue();
/*      */   }
/*      */ 
/*      */   public static boolean objectInstanceEntry(OID oid, BasicWorldNode instanceLoc, int flags)
/*      */   {
/*  434 */     return objectInstanceEntry(oid, instanceLoc, flags, null);
/*      */   }
/*      */ 
/*      */   public static boolean objectInstanceEntry(OID oid, String instanceName, BasicWorldNode instanceLoc, int flags)
/*      */   {
/*  445 */     OID instanceOid = getInstanceOid(instanceName);
/*  446 */     if (instanceOid == null) {
/*  447 */       Log.error("objectInstanceEntry: unknown instance name=" + instanceName + " for oid=" + oid);
/*      */ 
/*  449 */       return false;
/*      */     }
/*  451 */     instanceLoc.setInstanceOid(instanceOid);
/*  452 */     InstanceEntryReqMessage message = new InstanceEntryReqMessage(oid, instanceLoc, flags);
/*      */ 
/*  454 */     return Engine.getAgent().sendRPCReturnBoolean(message).booleanValue();
/*      */   }
/*      */ 
/*      */   public static class GetNavMeshPathMessage extends Message
/*      */   {
/*      */     Point startLoc;
/*      */     Point endLoc;
/*      */     OID mobOid;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetNavMeshPathMessage()
/*      */     {
/*  873 */       super();
/*      */     }
/*      */ 
/*      */     public GetNavMeshPathMessage(OID mobOid, Point startLoc, Point endLoc)
/*      */     {
/*  878 */       super();
/*  879 */       this.startLoc = startLoc;
/*  880 */       this.endLoc = endLoc;
/*  881 */       this.mobOid = mobOid;
/*      */     }
/*      */ 
/*      */     public Point getStartLoc()
/*      */     {
/*  886 */       return this.startLoc;
/*      */     }
/*      */ 
/*      */     public void setStartLoc(Point startLoc) {
/*  890 */       this.startLoc = startLoc;
/*      */     }
/*      */ 
/*      */     public Point getEndLoc() {
/*  894 */       return this.endLoc;
/*      */     }
/*      */ 
/*      */     public void setEndLoc(Point endLoc) {
/*  898 */       this.endLoc = endLoc;
/*      */     }
/*      */ 
/*      */     public OID getMobOid() {
/*  902 */       return this.mobOid;
/*      */     }
/*      */ 
/*      */     public void setMobOid(OID mobOid) {
/*  906 */       this.mobOid = mobOid;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetMatchingEntityOidsMessage extends Message
/*      */   {
/*  865 */     private String entityName = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetMatchingEntityOidsMessage(String name)
/*      */     {
/*  857 */       super();
/*  858 */       this.entityName = name;
/*      */     }
/*      */ 
/*      */     public String getEntityName() {
/*  862 */       return this.entityName;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class InstanceEntryReqMessage extends TargetMessage
/*      */   {
/*      */     public static final int FLAG_NONE = 0;
/*      */     public static final int FLAG_PUSH = 1;
/*      */     public static final int FLAG_POP = 2;
/*      */     private BasicWorldNode instanceLoc;
/*      */     private int flags;
/*      */     private BasicWorldNode restoreLoc;
/*      */     private transient Object processingState;
/*  845 */     private boolean manifestChecked = false;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public InstanceEntryReqMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public InstanceEntryReqMessage(OID oid)
/*      */     {
/*  718 */       super(oid);
/*      */     }
/*      */ 
/*      */     public InstanceEntryReqMessage(OID oid, BasicWorldNode instanceLoc)
/*      */     {
/*  725 */       super(oid);
/*  726 */       setWorldNode(instanceLoc);
/*      */     }
/*      */ 
/*      */     public InstanceEntryReqMessage(OID oid, BasicWorldNode instanceLoc, int flags)
/*      */     {
/*  734 */       super(oid);
/*  735 */       setWorldNode(instanceLoc);
/*  736 */       setFlags(flags);
/*      */     }
/*      */ 
/*      */     public InstanceEntryReqMessage(OID oid, BasicWorldNode instanceLoc, int flags, BasicWorldNode restoreLoc)
/*      */     {
/*  745 */       super(oid);
/*  746 */       setWorldNode(instanceLoc);
/*  747 */       setFlags(flags);
/*  748 */       setRestoreNode(restoreLoc);
/*      */     }
/*      */ 
/*      */     public InstanceEntryReqMessage(OID oid, int flags)
/*      */     {
/*  755 */       super(oid);
/*  756 */       setFlags(flags);
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getWorldNode()
/*      */     {
/*  777 */       return this.instanceLoc;
/*      */     }
/*      */ 
/*      */     public void setWorldNode(BasicWorldNode instanceLoc)
/*      */     {
/*  784 */       this.instanceLoc = instanceLoc;
/*      */     }
/*      */ 
/*      */     public int getFlags()
/*      */     {
/*  791 */       return this.flags;
/*      */     }
/*      */ 
/*      */     public void setFlags(int flags)
/*      */     {
/*  798 */       this.flags = flags;
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getRestoreNode()
/*      */     {
/*  805 */       return this.restoreLoc;
/*      */     }
/*      */ 
/*      */     public void setRestoreNode(BasicWorldNode restoreLoc)
/*      */     {
/*  814 */       this.restoreLoc = restoreLoc;
/*      */     }
/*      */ 
/*      */     public Object getProcessingState()
/*      */     {
/*  822 */       return this.processingState;
/*      */     }
/*      */ 
/*      */     public void setProcessingState(Object state)
/*      */     {
/*  830 */       this.processingState = state;
/*      */     }
/*      */ 
/*      */     public void setManifestChecked(boolean checked) {
/*  834 */       this.manifestChecked = checked;
/*      */     }
/*      */ 
/*      */     public boolean getManifestChecked() {
/*  838 */       return this.manifestChecked;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetRegionMessage extends Message
/*      */   {
/*      */     private OID instanceOid;
/*      */     private String regionName;
/*      */     private long flags;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetRegionMessage()
/*      */     {
/*  665 */       setMsgType(InstanceClient.MSG_TYPE_GET_REGION);
/*      */     }
/*      */ 
/*      */     public GetRegionMessage(OID instanceOid, String name, long flags) {
/*  669 */       setMsgType(InstanceClient.MSG_TYPE_GET_REGION);
/*  670 */       setInstanceOid(instanceOid);
/*  671 */       setRegionName(name);
/*  672 */       setFlags(flags);
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/*  676 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/*  680 */       this.instanceOid = oid;
/*      */     }
/*      */ 
/*      */     public void setRegionName(String name) {
/*  684 */       this.regionName = name;
/*      */     }
/*      */ 
/*      */     public String getRegionName() {
/*  688 */       return this.regionName;
/*      */     }
/*      */ 
/*      */     public long getFlags() {
/*  692 */       return this.flags;
/*      */     }
/*      */ 
/*      */     public void setFlags(long flags) {
/*  696 */       this.flags = flags;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class InstanceInfo
/*      */   {
/*      */     public OID oid;
/*      */     public boolean loaded;
/*      */     public String name;
/*      */     public String templateName;
/*      */     public String skybox;
/*      */     public Fog fog;
/*      */     public Color ambientLight;
/*      */     public LightData dirLight;
/*      */     public OceanData ocean;
/*      */     public String worldFile;
/*      */     public TerrainConfig terrainConfig;
/*      */     public List<String> regionConfig;
/*      */     public int playerPopulation;
/*      */     public int populationLimit;
/*      */   }
/*      */ 
/*      */   public static class GetInstanceInfoMessage extends Message
/*      */   {
/*      */     private OID instanceOid;
/*      */     private String instanceName;
/*      */     private int flags;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetInstanceInfoMessage()
/*      */     {
/*  533 */       super();
/*      */     }
/*      */ 
/*      */     public GetInstanceInfoMessage(String instanceName, int flags) {
/*  537 */       super();
/*  538 */       setInstanceName(instanceName);
/*  539 */       setFlags(flags);
/*      */     }
/*      */ 
/*      */     public GetInstanceInfoMessage(OID instanceOid, int flags) {
/*  543 */       super();
/*  544 */       setInstanceOid(instanceOid);
/*  545 */       setFlags(flags);
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid() {
/*  549 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID oid) {
/*  553 */       this.instanceOid = oid;
/*      */     }
/*      */ 
/*      */     public String getInstanceName() {
/*  557 */       return this.instanceName;
/*      */     }
/*      */ 
/*      */     public void setInstanceName(String name) {
/*  561 */       this.instanceName = name;
/*      */     }
/*      */ 
/*      */     public int getFlags() {
/*  565 */       return this.flags;
/*      */     }
/*      */ 
/*      */     public void setFlags(int flags) {
/*  569 */       this.flags = flags;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateInstanceMessage extends Message
/*      */   {
/*      */     private String templateName;
/*      */     private Template overrideTemplate;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public CreateInstanceMessage()
/*      */     {
/*  494 */       super();
/*      */     }
/*      */ 
/*      */     public CreateInstanceMessage(String templateName, Template override)
/*      */     {
/*  499 */       super();
/*  500 */       setTemplateName(templateName);
/*  501 */       setOverrideTemplate(override);
/*      */     }
/*      */ 
/*      */     public String getTemplateName()
/*      */     {
/*  506 */       return this.templateName;
/*      */     }
/*      */ 
/*      */     public void setTemplateName(String templateName)
/*      */     {
/*  511 */       this.templateName = templateName;
/*      */     }
/*      */ 
/*      */     public Template getOverrideTemplate()
/*      */     {
/*  516 */       return this.overrideTemplate;
/*      */     }
/*      */ 
/*      */     public void setOverrideTemplate(Template override)
/*      */     {
/*  521 */       this.overrideTemplate = override;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class RegisterInstanceTemplateMessage extends Message
/*      */   {
/*      */     Template template;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public RegisterInstanceTemplateMessage()
/*      */     {
/*  467 */       super();
/*      */     }
/*      */ 
/*      */     public RegisterInstanceTemplateMessage(Template template)
/*      */     {
/*  472 */       super();
/*  473 */       this.template = template;
/*      */     }
/*      */ 
/*      */     public Template getTemplate()
/*      */     {
/*  478 */       return this.template;
/*      */     }
/*      */ 
/*      */     public void setTemplate(Template template)
/*      */     {
/*  483 */       this.template = template;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.InstanceClient
 * JD-Core Version:    0.6.0
 */