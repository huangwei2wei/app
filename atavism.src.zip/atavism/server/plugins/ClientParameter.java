/*    */ package atavism.server.plugins;
/*    */ 
/*    */ import atavism.msgsys.MessageAgent;
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.EnginePlugin;
/*    */ import atavism.server.engine.Namespace;
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class ClientParameter
/*    */ {
/*    */   public static final String ClientParameterExtensionType = "ClientParameter";
/*    */ 
/*    */   public static String GetClientParameter(OID playerOid, String parameterName)
/*    */   {
/* 12 */     return (String)EnginePlugin.getObjectProperty(playerOid, Namespace.WORLD_MANAGER, "clientparm." + parameterName);
/*    */   }
/*    */ 
/*    */   public static void SetClientParameter(OID playerOid, String parameterName, String parameterValue)
/*    */   {
/* 17 */     ClientParameterMessage msg = new ClientParameterMessage(playerOid);
/* 18 */     msg.setProperty(parameterName, parameterValue);
/* 19 */     Engine.getAgent().sendBroadcast(msg);
/*    */   }
/*    */   public static class ClientParameterMessage extends WorldManagerClient.TargetedExtensionMessage { private static final long serialVersionUID = 1L;
/*    */ 
/* 24 */     public ClientParameterMessage(OID oid) { super(oid);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.ClientParameter
 * JD-Core Version:    0.6.0
 */