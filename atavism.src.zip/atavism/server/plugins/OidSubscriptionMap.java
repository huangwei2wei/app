/*    */ package atavism.server.plugins;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.util.LockFactory;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class OidSubscriptionMap
/*    */ {
/* 80 */   Map<OID, Long> oidToSubMap = new HashMap();
/* 81 */   Map<Long, OID> subToOidMap = new HashMap();
/* 82 */   Lock lock = LockFactory.makeLock("OidSubscriptionLock");
/*    */ 
/*    */   public void put(OID oid, Long sub)
/*    */   {
/* 19 */     this.lock.lock();
/*    */     try {
/* 21 */       this.oidToSubMap.put(oid, sub);
/* 22 */       this.subToOidMap.put(sub, oid);
/*    */     }
/*    */     finally {
/* 25 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Long getSub(OID oid) {
/* 30 */     this.lock.lock();
/*    */     try {
/* 32 */       Long localLong = (Long)this.oidToSubMap.get(oid);
/*    */       return localLong; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public OID getOid(OID sub)
/*    */   {
/* 40 */     this.lock.lock();
/*    */     try {
/* 42 */       OID localOID = (OID)this.subToOidMap.get(sub);
/*    */       return localOID; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public Long removeSub(OID oid)
/*    */   {
/* 50 */     this.lock.lock();
/*    */     try {
/* 52 */       Long sub = (Long)this.oidToSubMap.remove(oid);
/* 53 */       if (this.subToOidMap.remove(sub) == null) {
/* 54 */         throw new RuntimeException("remove failed: sub=" + sub);
/*    */       }
/* 56 */       Long localLong1 = sub;
/*    */       return localLong1; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public OID removeOid(Long sub) {
/* 63 */     this.lock.lock();
/*    */     try {
/* 65 */       OID oid = (OID)this.subToOidMap.remove(sub);
/* 66 */       if (this.oidToSubMap.remove(oid) == null) {
/* 67 */         throw new RuntimeException("remove failed");
/*    */       }
/* 69 */       OID localOID1 = oid;
/*    */       return localOID1; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public Lock getLock()
/*    */   {
/* 77 */     return this.lock;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.OidSubscriptionMap
 * JD-Core Version:    0.6.0
 */