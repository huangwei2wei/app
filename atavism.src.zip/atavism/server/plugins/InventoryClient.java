/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.msgsys.SubjectMessage;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.EventParser;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.messages.ClientMessage;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class InventoryClient
/*     */ {
/* 342 */   public static final MessageType MSG_TYPE_ADD_ITEM = MessageType.intern("ao.ADD_ITEM");
/* 343 */   public static final MessageType MSG_TYPE_CREATE_INV = MessageType.intern("ao.CREATE_INV");
/* 344 */   public static final MessageType MSG_TYPE_INV_UPDATE = MessageType.intern("ao.INV_UPDATE");
/* 345 */   public static final MessageType MSG_TYPE_ACTIVATE = MessageType.intern("ao.ACTIVATE");
/* 346 */   public static final MessageType MSG_TYPE_LOOTALL = MessageType.intern("ao.LOOTALL");
/* 347 */   public static final MessageType MSG_TYPE_INV_FIND = MessageType.intern("ao.INV_FIND");
/* 348 */   public static final MessageType MSG_TYPE_INV_REMOVE = MessageType.intern("ao.INV_REMOVE");
/* 349 */   public static final MessageType MSG_TYPE_DESTROY_ITEM = MessageType.intern("ao.DESTROY_ITEM");
/*     */   public static final String INV_METHOD_OID = "oid";
/*     */   public static final String INV_METHOD_TEMPLATE = "template";
/*     */   public static final String INV_METHOD_TEMPLATE_LIST = "templateList";
/*     */   public static final String TEMPL_ITEMS = ":inv_items";
/*     */   public static final String TEMPL_EQUIP_INFO = "item_equipInfo";
/*     */   public static final String TEMPL_ACTIVATE_HOOK = "item_activateHook";
/*     */   public static final String TEMPL_ICON = "item_icon";
/*     */   public static final String TEMPL_DCMAP = "item_dcmap";
/*     */   public static final String TEMPL_VALUE = "item_value";
/* 369 */   public static Namespace NAMESPACE = null;
/* 370 */   public static Namespace ITEM_NAMESPACE = null;
/*     */ 
/*     */   public static void getInventory(OID objOid)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static void activateObject(OID objOid, OID activatorOid, OID targetOid)
/*     */   {
/*  30 */     ActivateMessage msg = new ActivateMessage(objOid, activatorOid, targetOid);
/*  31 */     if (Log.loggingDebug) {
/*  32 */       Log.debug("InventoryClient.activateObject: activator=" + msg.getActivatorOid() + ", objOid=" + msg.getSubject() + ", targetOid=" + msg.getTargetOid());
/*     */     }
/*  34 */     Engine.getAgent().sendBroadcast(msg);
/*     */   }
/*     */ 
/*     */   public static boolean lootAll(OID looterOid, OID containerOid) {
/*  38 */     LootAllMessage msg = new LootAllMessage(looterOid, containerOid);
/*  39 */     if (Log.loggingDebug)
/*  40 */       Log.debug("InventoryClient.lootAll: looterOid=" + looterOid + ", container=" + containerOid);
/*  41 */     return Engine.getAgent().sendRPCReturnBoolean(msg).booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean addItem(OID containerOid, OID mobOid, OID rootContainerOid, OID itemOid) {
/*  45 */     AddItemMessage msg = new AddItemMessage(containerOid, mobOid, rootContainerOid, itemOid);
/*     */ 
/*  47 */     return Engine.getAgent().sendRPCReturnBoolean(msg).booleanValue();
/*     */   }
/*     */ 
/*     */   public static OID removeItem(OID mobOid, OID itemOid) {
/*  51 */     Message msg = new RemoveOrFindItemMessage(MSG_TYPE_INV_REMOVE, mobOid, "oid", itemOid);
/*  52 */     return Engine.getAgent().sendRPCReturnOID(msg);
/*     */   }
/*     */ 
/*     */   public static OID removeItem(OID mobOid, int templateID) {
/*  56 */     Message msg = new RemoveOrFindItemMessage(MSG_TYPE_INV_REMOVE, mobOid, "template", Integer.valueOf(templateID));
/*  57 */     return Engine.getAgent().sendRPCReturnOID(msg);
/*     */   }
/*     */ 
/*     */   public static List<OID> removeItems(OID mobOid, ArrayList<Integer> templateNames) {
/*  61 */     Message msg = new RemoveOrFindItemMessage(MSG_TYPE_INV_REMOVE, mobOid, "templateList", templateNames);
/*  62 */     return (List)Engine.getAgent().sendRPCReturnObject(msg);
/*     */   }
/*     */ 
/*     */   public static OID findItem(OID mobOid, int templateID) {
/*  66 */     Message msg = new RemoveOrFindItemMessage(MSG_TYPE_INV_FIND, mobOid, "template", Integer.valueOf(templateID));
/*  67 */     OID oid = Engine.getAgent().sendRPCReturnOID(msg);
/*  68 */     Log.debug("findItem: got response");
/*  69 */     return oid;
/*     */   }
/*     */ 
/*     */   public static List<OID> findItems(OID mobOid, ArrayList<Integer> templateIDs) {
/*  73 */     Message msg = new RemoveOrFindItemMessage(MSG_TYPE_INV_FIND, mobOid, "templateList", templateIDs);
/*  74 */     return (List)Engine.getAgent().sendRPCReturnObject(msg);
/*     */   }
/*     */ 
/*     */   public static class LootAllMessage extends SubjectMessage
/*     */   {
/*     */     OID containerOid;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public LootAllMessage()
/*     */     {
/* 325 */       super();
/*     */     }
/*     */     public LootAllMessage(OID looterOid, OID containerOid) {
/* 328 */       super(looterOid);
/* 329 */       setContainerOid(containerOid);
/*     */     }
/*     */     public void setContainerOid(OID containerOid) {
/* 332 */       this.containerOid = containerOid;
/*     */     }
/*     */     public OID getContainerOid() {
/* 335 */       return this.containerOid;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ActivateMessage extends SubjectMessage
/*     */   {
/*     */     protected OID activatorOid;
/*     */     protected OID targetOid;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public ActivateMessage()
/*     */     {
/* 300 */       super();
/*     */     }
/*     */ 
/*     */     public ActivateMessage(OID objOid, OID activatorOid, OID targetOid) {
/* 304 */       super(objOid);
/* 305 */       setActivatorOid(activatorOid);
/* 306 */       setTargetOid(targetOid);
/*     */     }
/*     */     public void setActivatorOid(OID oid) {
/* 309 */       this.activatorOid = oid; } 
/* 310 */     public OID getActivatorOid() { return this.activatorOid; }
/*     */ 
/*     */     public void setTargetOid(OID oid) {
/* 313 */       this.targetOid = oid; } 
/* 314 */     public OID getTargetOid() { return this.targetOid;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ItemInfo
/*     */     implements Serializable
/*     */   {
/*     */     public OID itemOid;
/*     */     public String itemName;
/*     */     public String itemIcon;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public ItemInfo()
/*     */     {
/*     */     }
/*     */ 
/*     */     public ItemInfo(OID itemOid, String itemName, String itemIcon)
/*     */     {
/* 277 */       this.itemOid = itemOid;
/* 278 */       this.itemName = itemName;
/* 279 */       this.itemIcon = itemIcon;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 283 */       return "[ItemInfo: itemOid=" + this.itemOid + ",itemName=" + this.itemName + ",itemIcon=" + this.itemIcon + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class InvUpdateMessage extends SubjectMessage
/*     */     implements ClientMessage, EventParser
/*     */   {
/* 234 */     Map<InvPos, InventoryClient.ItemInfo> invMap = new HashMap();
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public InvUpdateMessage()
/*     */     {
/* 178 */       super();
/*     */     }
/*     */ 
/*     */     public InvUpdateMessage(OID mobOid) {
/* 182 */       super(mobOid);
/*     */     }
/*     */ 
/*     */     public void addItem(int bagNum, int bagPos, OID itemOid, String itemName, String itemIcon) {
/* 186 */       InvPos invPos = new InvPos(bagNum, bagPos);
/* 187 */       this.invMap.put(invPos, new InventoryClient.ItemInfo(itemOid, itemName, itemIcon));
/*     */     }
/*     */ 
/*     */     public int getNumEntries()
/*     */     {
/* 194 */       return this.invMap.size();
/*     */     }
/*     */ 
/*     */     public Map<InvPos, InventoryClient.ItemInfo> getEntries() {
/* 198 */       return new HashMap(this.invMap);
/*     */     }
/*     */ 
/*     */     public AOByteBuffer toBuffer()
/*     */     {
/* 237 */       AOByteBuffer buf = new AOByteBuffer(400);
/* 238 */       buf.putOID(getSubject());
/* 239 */       buf.putInt(43);
/* 240 */       buf.putInt(getNumEntries());
/*     */ 
/* 242 */       for (InvPos invPos : this.invMap.keySet()) {
/* 243 */         InventoryClient.ItemInfo itemInfo = (InventoryClient.ItemInfo)this.invMap.get(invPos);
/* 244 */         buf.putOID(itemInfo.itemOid);
/* 245 */         buf.putInt(invPos.bagNum.intValue());
/* 246 */         buf.putInt(invPos.bagPos.intValue());
/* 247 */         buf.putString(itemInfo.itemName);
/* 248 */         buf.putString(itemInfo.itemIcon);
/*     */       }
/* 250 */       buf.flip();
/* 251 */       return buf;
/*     */     }
/*     */ 
/*     */     public void parseBytes(AOByteBuffer buf)
/*     */     {
/* 256 */       buf.getOID();
/* 257 */       buf.getInt();
/* 258 */       int nEntry = buf.getInt();
/* 259 */       for (int ii = 0; ii < nEntry; ii++) {
/* 260 */         OID itemOid = buf.getOID();
/* 261 */         InvPos invPos = new InvPos();
/* 262 */         invPos.bagNum = Integer.valueOf(buf.getInt());
/* 263 */         invPos.bagPos = Integer.valueOf(buf.getInt());
/* 264 */         this.invMap.put(invPos, new InventoryClient.ItemInfo(itemOid, buf.getString(), buf.getString()));
/*     */       }
/*     */     }
/*     */ 
/*     */     public static class InvPos
/*     */       implements Serializable
/*     */     {
/*     */       public Integer bagNum;
/*     */       public Integer bagPos;
/*     */       private static final long serialVersionUID = 1L;
/*     */ 
/*     */       public InvPos()
/*     */       {
/*     */       }
/*     */ 
/*     */       public InvPos(int bagNum, int bagPos)
/*     */       {
/* 207 */         this.bagNum = Integer.valueOf(bagNum);
/* 208 */         this.bagPos = Integer.valueOf(bagPos);
/*     */       }
/*     */ 
/*     */       public String toString()
/*     */       {
/* 215 */         return "[InvPos bagNum=" + this.bagNum + ", bagPos=" + this.bagPos + "]";
/*     */       }
/*     */ 
/*     */       public boolean equals(Object other) {
/* 219 */         InvPos otherI = (InvPos)other;
/* 220 */         if ((this.bagNum == null) || (this.bagPos == null)) {
/* 221 */           return false;
/*     */         }
/* 223 */         return (this.bagNum.equals(otherI.bagNum)) && (this.bagPos.equals(otherI.bagPos));
/*     */       }
/*     */ 
/*     */       public int hashCode() {
/* 227 */         return this.bagNum.hashCode() ^ this.bagPos.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class RemoveOrFindItemMessage extends SubjectMessage
/*     */   {
/*     */     private String method;
/*     */     private Object payload;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public RemoveOrFindItemMessage()
/*     */     {
/*     */     }
/*     */ 
/*     */     public RemoveOrFindItemMessage(MessageType msgType, OID mobOid, String method, Serializable payload)
/*     */     {
/* 145 */       super(mobOid);
/* 146 */       setMethod(method);
/* 147 */       setPayload(payload);
/*     */     }
/*     */ 
/*     */     public String getMethod() {
/* 151 */       return this.method;
/*     */     }
/*     */ 
/*     */     public void setMethod(String method) {
/* 155 */       this.method = method;
/*     */     }
/*     */ 
/*     */     public Object getPayload() {
/* 159 */       return this.payload;
/*     */     }
/*     */ 
/*     */     public void setPayload(Object payload) {
/* 163 */       this.payload = payload;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class AddItemMessage extends SubjectMessage
/*     */   {
/*     */     OID container;
/*     */     OID rootContainer;
/*     */     OID item;
/*     */     OID mob;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public AddItemMessage()
/*     */     {
/*  80 */       super();
/*     */     }
/*     */ 
/*     */     public AddItemMessage(OID containerOid, OID mob, OID rootContainer, OID itemOid)
/*     */     {
/*  91 */       super(containerOid);
/*  92 */       setContainer(containerOid);
/*  93 */       setMob(mob);
/*  94 */       setRootContainer(rootContainer);
/*  95 */       setItem(itemOid);
/*     */     }
/*     */ 
/*     */     public void setContainer(OID oid) {
/*  99 */       this.container = oid;
/*     */     }
/*     */ 
/*     */     public OID getContainer() {
/* 103 */       return this.container;
/*     */     }
/*     */ 
/*     */     public void setRootContainer(OID oid) {
/* 107 */       this.rootContainer = oid;
/*     */     }
/*     */ 
/*     */     public OID getRootContainer() {
/* 111 */       return this.rootContainer;
/*     */     }
/*     */ 
/*     */     public void setItem(OID oid) {
/* 115 */       this.item = oid;
/*     */     }
/*     */ 
/*     */     public OID getItem() {
/* 119 */       return this.item;
/*     */     }
/*     */ 
/*     */     public void setMob(OID oid) {
/* 123 */       this.mob = oid;
/*     */     }
/*     */ 
/*     */     public OID getMob() {
/* 127 */       return this.mob;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.InventoryClient
 * JD-Core Version:    0.6.0
 */