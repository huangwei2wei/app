/*    */ package atavism.server.plugins;
/*    */ 
/*    */ import atavism.msgsys.MessageAgent;
/*    */ import atavism.msgsys.MessageType;
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Namespace;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.util.Log;
/*    */ import java.util.HashSet;
/*    */ 
/*    */ public class BillingClient
/*    */ {
/* 16 */   public static Namespace NAMESPACE = null;
/*    */ 
/* 18 */   public static final MessageType MSG_TYPE_DECREMENT_TOKEN_BALANCE = MessageType.intern("ao.DECREMENT_TOKEN_BALANCE");
/* 19 */   public static final MessageType MSG_TYPE_GET_TOKEN_BALANCE = MessageType.intern("ao.GET_TOKEN_BALANCE");
/* 20 */   public static final MessageType MSG_TYPE_BILLING_BALANCE = MessageType.intern("ao.BILLING_BALANCE");
/*    */ 
/* 22 */   public static final MessageType MSG_GET_PLAYER = MessageType.intern("ao.GET_PLAYER");
/*    */ 
/*    */   public static Float decrementTokenBalance(OID playerOid, Float amount)
/*    */   {
/* 30 */     if (amount.floatValue() > 0.0D) {
/* 31 */       Log.error("BillingClient.DecrementTokenBalance - Amount must be nonpositive.");
/* 32 */       return null;
/*    */     }
/* 34 */     WorldManagerClient.ExtensionMessage updateRequest = new WorldManagerClient.ExtensionMessage(MSG_TYPE_DECREMENT_TOKEN_BALANCE, "ao.DECREMENT_TOKEN_BALANCE", playerOid);
/*    */ 
/* 36 */     updateRequest.setProperty("amount", amount);
/*    */ 
/* 38 */     HashSet purchasedItems = new HashSet();
/*    */ 
/* 48 */     updateRequest.setProperty("purchasedItems", purchasedItems);
/*    */ 
/* 50 */     Float updatedBalance = (Float)Engine.getAgent().sendRPCReturnObject(updateRequest);
/* 51 */     return updatedBalance;
/*    */   }
/*    */ 
/*    */   public static Float getTokenBalance(OID playerOid)
/*    */   {
/* 60 */     WorldManagerClient.ExtensionMessage request = new WorldManagerClient.ExtensionMessage(MSG_TYPE_GET_TOKEN_BALANCE, "ao.GET_TOKEN_BALANCE", playerOid);
/*    */ 
/* 63 */     Float balance = (Float)Engine.getAgent().sendRPCReturnObject(request);
/* 64 */     return balance;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.BillingClient
 * JD-Core Version:    0.6.0
 */