/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.management.Management;
/*      */ import atavism.msgsys.BooleanResponseMessage;
/*      */ import atavism.msgsys.GenericMessage;
/*      */ import atavism.msgsys.GenericResponseMessage;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageTypeFilter;
/*      */ import atavism.msgsys.NoRecipientsException;
/*      */ import atavism.msgsys.ResponseCallback;
/*      */ import atavism.msgsys.ResponseMessage;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.server.engine.BasicWorldNode;
/*      */ import atavism.server.engine.Database;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.EnginePlugin;
/*      */ import atavism.server.engine.Hook;
/*      */ import atavism.server.engine.HookManager;
/*      */ import atavism.server.engine.Manager;
/*      */ import atavism.server.engine.Namespace;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.engine.PersistenceManager;
/*      */ import atavism.server.engine.WMWorldNode;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.messages.OIDNamespaceMessage;
/*      */ import atavism.server.objects.AOObject;
/*      */ import atavism.server.objects.Entity;
/*      */ import atavism.server.objects.EntityManager;
/*      */ import atavism.server.objects.ObjectType;
/*      */ import atavism.server.objects.ObjectTypes;
/*      */ import atavism.server.objects.Template;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.Logger;
/*      */ import atavism.server.util.Table;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class ObjectManagerPlugin extends EnginePlugin
/*      */ {
/*      */   private static final int INSTANCE_OK = 0;
/*      */   private static final int INSTANCE_LOADING = 1;
/*      */   private static final int INSTANCE_UNLOADING = 2;
/*      */   private static final int INSTANCE_DELETING = 3;
/* 1603 */   public static int nextFreeTemplateID = -2;
/*      */ 
/* 1605 */   public static String ITEM_TEMPLATE = "item";
/* 1606 */   public static String MOB_TEMPLATE = "mob";
/*      */ 
/* 1608 */   protected static final Logger log = new Logger("ObjectManagerPlugin");
/*      */ 
/* 1610 */   protected HashMap<String, Manager<Template>> templateManager = new HashMap();
/*      */ 
/* 1613 */   private Map<OID, InstanceState> instanceContent = new HashMap();
/*      */ 
/*      */   public ObjectManagerPlugin()
/*      */   {
/*   27 */     super("ObjectManager");
/*   28 */     setPluginType("ObjectManager");
/*      */   }
/*      */ 
/*      */   public void onActivate() {
/*      */     try {
/*   33 */       log.debug("ObjectManagerPlugin.onActivate started");
/*      */ 
/*   35 */       registerTemplate(new Template("BaseTemplate", -1, "BaseTemplate"));
/*      */ 
/*   38 */       registerHooks();
/*      */ 
/*   45 */       MessageTypeFilter filter = new MessageTypeFilter();
/*   46 */       filter.addType(ObjectManagerClient.MSG_TYPE_SET_PERSISTENCE);
/*   47 */       filter.addType(ObjectManagerClient.MSG_TYPE_MODIFY_NAMESPACE);
/*   48 */       filter.addType(ObjectManagerClient.MSG_TYPE_LOAD_OBJECT);
/*   49 */       filter.addType(ObjectManagerClient.MSG_TYPE_UNLOAD_OBJECT);
/*   50 */       filter.addType(ObjectManagerClient.MSG_TYPE_DELETE_OBJECT);
/*   51 */       filter.addType(ObjectManagerClient.MSG_TYPE_LOAD_OBJECT_DATA);
/*   52 */       filter.addType(ObjectManagerClient.MSG_TYPE_SAVE_OBJECT);
/*   53 */       filter.addType(ObjectManagerClient.MSG_TYPE_SAVE_OBJECT_DATA);
/*   54 */       filter.addType(ObjectManagerClient.MSG_TYPE_GENERATE_OBJECT);
/*   55 */       filter.addType(ObjectManagerClient.MSG_TYPE_REGISTER_TEMPLATE);
/*   56 */       filter.addType(ObjectManagerClient.MSG_TYPE_GET_TEMPLATE);
/*   57 */       filter.addType(ObjectManagerClient.MSG_TYPE_GET_TEMPLATE_NAMES);
/*   58 */       filter.addType(ObjectManagerClient.MSG_TYPE_FIX_WNODE_REQ);
/*   59 */       filter.addType(InstanceClient.MSG_TYPE_UNLOAD_INSTANCE);
/*   60 */       filter.addType(InstanceClient.MSG_TYPE_DELETE_INSTANCE);
/*   61 */       filter.addType(InstanceClient.MSG_TYPE_LOAD_INSTANCE_CONTENT);
/*   62 */       filter.addType(ObjectManagerClient.MSG_TYPE_GET_NAMED_OBJECT);
/*   63 */       filter.addType(ObjectManagerClient.MSG_TYPE_GET_MATCHING_OBJECTS);
/*   64 */       filter.addType(Management.MSG_TYPE_GET_PLUGIN_STATUS);
/*   65 */       filter.addType(ObjectManagerClient.MSG_TYPE_GET_OBJECT_STATUS);
/*   66 */       Engine.getAgent().createSubscription(filter, this, 8);
/*      */ 
/*   69 */       List namespaces = new ArrayList();
/*   70 */       namespaces.add(Namespace.OBJECT_MANAGER);
/*   71 */       registerPluginNamespaces(namespaces, null);
/*      */ 
/*   73 */       log.debug("onActivate completed");
/*      */     } catch (Exception e) {
/*   75 */       throw new AORuntimeException("activate failed", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void registerHooks()
/*      */   {
/*   81 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_SET_PERSISTENCE, new SetPersistenceHook());
/*      */ 
/*   83 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_MODIFY_NAMESPACE, new ModifyNamespaceHook());
/*   84 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_LOAD_OBJECT, new LoadObjectHook());
/*      */ 
/*   86 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_UNLOAD_OBJECT, new UnloadObjectHook());
/*      */ 
/*   88 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_DELETE_OBJECT, new DeleteObjectHook());
/*      */ 
/*   90 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_LOAD_OBJECT_DATA, new LoadObjectDataHook());
/*      */ 
/*   92 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_SAVE_OBJECT_DATA, new SaveObjectDataHook());
/*      */ 
/*   94 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_SAVE_OBJECT, new SaveObjectHook());
/*      */ 
/*   96 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_GENERATE_OBJECT, new GenerateObjectHook());
/*      */ 
/*   98 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_REGISTER_TEMPLATE, new RegisterTemplateHook());
/*      */ 
/*  100 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_GET_TEMPLATE, new GetTemplateHook());
/*      */ 
/*  102 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_GET_TEMPLATE_NAMES, new GetTemplateNamesHook());
/*      */ 
/*  104 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_FIX_WNODE_REQ, new FixWorldNodeHook());
/*      */ 
/*  107 */     getHookManager().addHook(InstanceClient.MSG_TYPE_UNLOAD_INSTANCE, new UnloadInstanceHook());
/*      */ 
/*  109 */     getHookManager().addHook(InstanceClient.MSG_TYPE_DELETE_INSTANCE, new DeleteInstanceHook());
/*      */ 
/*  111 */     getHookManager().addHook(InstanceClient.MSG_TYPE_LOAD_INSTANCE_CONTENT, new LoadInstanceContentHook());
/*      */ 
/*  113 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_GET_NAMED_OBJECT, new GetNamedObjectHook());
/*      */ 
/*  115 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_GET_MATCHING_OBJECTS, new GetMatchingObjectsHook());
/*      */ 
/*  117 */     getHookManager().addHook(Management.MSG_TYPE_GET_PLUGIN_STATUS, new GetPluginStatusHook());
/*      */ 
/*  119 */     getHookManager().addHook(ObjectManagerClient.MSG_TYPE_GET_OBJECT_STATUS, new GetObjectStatusHook());
/*      */   }
/*      */ 
/*      */   void resolveDeps(OID masterOid, Namespace namespace, Map<Namespace, Collection<Namespace>> depMap)
/*      */   {
/*  795 */     if (Log.loggingDebug) {
/*  796 */       log.debug("resolveDeps: masterOid=" + masterOid + ", ns=" + namespace);
/*      */     }
/*  798 */     Collection depNamespaces = (Collection)depMap.get(namespace);
/*  799 */     if (depNamespaces == null) {
/*  800 */       if (Log.loggingDebug)
/*  801 */         log.debug("resolveDeps: no deps for ns " + namespace);
/*  802 */       return;
/*      */     }
/*      */     int i;
/*  804 */     if (Log.loggingDebug) {
/*  805 */       if (depNamespaces == null) {
/*  806 */         Log.debug("resolveDeps: depNamespaces is null");
/*      */       } else {
/*  808 */         Log.debug("resolveDeps: depNamespaces.size() " + depNamespaces.size());
/*  809 */         i = 0;
/*  810 */         for (Object object : depNamespaces) {
/*  811 */           Log.debug("resolveDeps: depNamespaces element " + i++ + " " + object);
/*      */         }
/*      */       }
/*      */     }
/*  815 */     for (Namespace depNS : depNamespaces) {
/*  816 */       if (Log.loggingDebug) {
/*  817 */         log.debug("resolveDeps: ns " + namespace + " depends on ns " + depNS);
/*      */       }
/*      */ 
/*  820 */       Collection childDeps = (Collection)depMap.get(depNS);
/*  821 */       if (childDeps != null) {
/*  822 */         if (Log.loggingDebug)
/*  823 */           log.debug("resolveDeps: ns " + namespace + ", depNS=" + depNS + ", has further deps, recursing");
/*  824 */         resolveDeps(masterOid, depNS, depMap);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  830 */     if (Log.loggingDebug)
/*  831 */       log.debug("resolveDeps: ns " + namespace + ": resolved all deps, removing from table");
/*  832 */     depMap.remove(namespace);
/*      */ 
/*  836 */     ObjectManagerClient.SubObjectDepsReadyMessage msg = new ObjectManagerClient.SubObjectDepsReadyMessage(masterOid, namespace);
/*      */ 
/*  838 */     Boolean resp = Engine.getAgent().sendRPCReturnBoolean(msg);
/*  839 */     if (resp.equals(Boolean.FALSE)) {
/*  840 */       log.error("dependency failed");
/*      */     }
/*  842 */     if (Log.loggingDebug)
/*  843 */       log.debug("resolveDeps: ns " + namespace + ": got response msg, result=" + resp);
/*      */   }
/*      */ 
/*      */   GenericResponseMessage generateSubObject(OID masterOid, Namespace namespace, Template template)
/*      */   {
/*  854 */     ObjectManagerClient.GenerateSubObjectMessage msg = new ObjectManagerClient.GenerateSubObjectMessage(masterOid, namespace, template);
/*  855 */     GenericResponseMessage respMsg = (GenericResponseMessage)Engine.getAgent().sendRPC(msg);
/*  856 */     return respMsg;
/*      */   }
/*      */ 
/*      */   private void addInstance(MasterObject instance)
/*      */   {
/* 1358 */     InstanceState instanceState = new InstanceState(instance);
/* 1359 */     synchronized (this.instanceContent) {
/* 1360 */       InstanceState previous = (InstanceState)this.instanceContent.put(instance.getOid(), instanceState);
/*      */ 
/* 1362 */       if (previous != null) {
/* 1363 */         Log.error("addInstance: duplicate instance [OLD " + previous + "] [NEW " + instanceState + "]");
/*      */       }
/*      */     }
/*      */ 
/* 1367 */     if (Log.loggingDebug)
/* 1368 */       Log.debug("addInstance: added instanceOid=" + instance.getOid());
/*      */   }
/*      */ 
/*      */   private void removeInstance(MasterObject instance)
/*      */   {
/* 1373 */     synchronized (this.instanceContent) {
/* 1374 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(instance.getOid());
/* 1375 */       if (instanceState == null) {
/* 1376 */         Log.error("removeInstance: unknown instanceOid=" + instance.getOid());
/*      */ 
/* 1378 */         return;
/*      */       }
/* 1380 */       if (instanceState.entities.size() > 0) {
/* 1381 */         Log.warn("removeInstance: wrong state: " + instanceState);
/*      */       }
/* 1383 */       this.instanceContent.remove(instance.getOid());
/*      */     }
/* 1385 */     if (Log.loggingDebug)
/* 1386 */       Log.debug("removeInstance: removed instanceOid=" + instance.getOid());
/*      */   }
/*      */ 
/*      */   private void addInstanceContent(OID instanceOid, MasterObject entity)
/*      */   {
/* 1392 */     if (Log.loggingDebug) {
/* 1393 */       Log.debug("addInstanceContent: instanceOid=" + instanceOid + " oid=" + entity.getOid());
/*      */     }
/* 1395 */     synchronized (this.instanceContent) {
/* 1396 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(instanceOid);
/* 1397 */       if (instanceState == null) {
/* 1398 */         Log.error("addInstanceContent: unknown instanceOid=" + instanceOid + " for " + entity);
/*      */ 
/* 1400 */         return;
/*      */       }
/* 1402 */       instanceState.entities.add(entity);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void removeInstanceContent(OID instanceOid, MasterObject entity)
/*      */   {
/* 1408 */     synchronized (this.instanceContent) {
/* 1409 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(instanceOid);
/* 1410 */       if (instanceState == null) {
/* 1411 */         Log.error("removeInstanceContent: unknown instanceOid=" + instanceOid);
/*      */ 
/* 1413 */         return;
/*      */       }
/* 1415 */       if (Log.loggingDebug) {
/* 1416 */         Log.debug("removeInstanceContent: instanceOid=" + instanceOid + " oid=" + entity.getOid() + " count=" + instanceState.entities.size());
/*      */       }
/*      */ 
/* 1419 */       instanceState.entities.remove(entity);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean isInstanceOk(OID instanceOid, int newStatus)
/*      */   {
/* 1425 */     synchronized (this.instanceContent) {
/* 1426 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(instanceOid);
/* 1427 */       if (instanceState != null) {
/* 1428 */         boolean result = instanceState.status == 0;
/* 1429 */         if ((result) && (newStatus != -1))
/* 1430 */           instanceState.status = newStatus;
/* 1431 */         return result;
/*      */       }
/*      */ 
/* 1434 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean isInstanceLoading(OID instanceOid)
/*      */   {
/* 1440 */     synchronized (this.instanceContent) {
/* 1441 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(instanceOid);
/* 1442 */       if (instanceState != null) {
/* 1443 */         return (instanceState.status == 0) || (instanceState.status == 1);
/*      */       }
/*      */ 
/* 1446 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setInstanceStatus(OID instanceOid, int newStatus)
/*      */   {
/* 1452 */     synchronized (this.instanceContent) {
/* 1453 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(instanceOid);
/* 1454 */       instanceState.status = newStatus;
/*      */     }
/*      */   }
/*      */ 
/*      */   private OID getInstanceNamedObject(OID instanceOid, String name, ObjectType objectType)
/*      */   {
/* 1461 */     synchronized (this.instanceContent) {
/* 1462 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(instanceOid);
/* 1463 */       if (instanceState == null)
/* 1464 */         return null;
/* 1465 */       if (objectType != null)
/* 1466 */         for (MasterObject entity : instanceState.entities) {
/* 1467 */           String entityName = entity.getName();
/* 1468 */           if ((entity.getType() == objectType) && (entityName != null) && (entityName.equals(name)))
/*      */           {
/* 1470 */             return entity.getOid();
/*      */           }
/*      */         }
/*      */       else {
/* 1474 */         for (MasterObject entity : instanceState.entities) {
/* 1475 */           String entityName = entity.getName();
/* 1476 */           if ((entityName != null) && (entityName.equals(name)))
/* 1477 */             return entity.getOid();
/*      */         }
/*      */       }
/* 1480 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */   private OID getNamedObject(String name, ObjectType objectType)
/*      */   {
/* 1486 */     Entity[] entities = EntityManager.getAllEntitiesByNamespace(Namespace.OBJECT_MANAGER);
/*      */ 
/* 1488 */     if (objectType != null)
/* 1489 */       for (Entity entity : entities) {
/* 1490 */         String entityName = entity.getName();
/* 1491 */         if ((entity.getType() == objectType) && (entityName != null) && (entityName.equals(name)))
/*      */         {
/* 1493 */           return entity.getOid();
/*      */         }
/*      */       }
/*      */     else {
/* 1497 */       for (Entity entity : entities) {
/* 1498 */         String entityName = entity.getName();
/* 1499 */         if ((entityName != null) && (entityName.equals(name)))
/* 1500 */           return entity.getOid();
/*      */       }
/*      */     }
/* 1503 */     return null;
/*      */   }
/*      */ 
/*      */   private List<OID> getMatchingObjects(OID oid, String name, ObjectType objectType, Map<Namespace, Map<String, Serializable>> filters)
/*      */   {
/* 1516 */     List rv = new LinkedList();
/*      */ 
/* 1518 */     Collection entities = new HashSet();
/* 1519 */     if (oid == null) {
/* 1520 */       Entity[] entityArray = EntityManager.getAllEntitiesByNamespace(Namespace.OBJECT_MANAGER);
/* 1521 */       for (Entity entity : entityArray)
/* 1522 */         entities.add(entity);
/*      */     }
/*      */     else {
/* 1525 */       InstanceState instanceState = (InstanceState)this.instanceContent.get(oid);
/* 1526 */       if (instanceState == null)
/* 1527 */         return rv;
/* 1528 */       for (Entity entity : instanceState.entities) {
/* 1529 */         entities.add(entity);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1534 */     for (Entity entity : entities) {
/* 1535 */       if (name != null) {
/* 1536 */         String entityName = entity.getName();
/* 1537 */         if ((entityName == null) || (!entityName.equals(name)))
/*      */         {
/*      */           continue;
/*      */         }
/*      */       }
/* 1542 */       if ((objectType != null) && 
/* 1543 */         (!entity.getType().isA(objectType)))
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/* 1548 */       boolean possibleMatch = true;
/* 1549 */       if (filters != null) {
/* 1550 */         for (Map.Entry namespaceEntry : filters.entrySet()) {
/* 1551 */           Namespace namespace = (Namespace)namespaceEntry.getKey();
/* 1552 */           Map namespaceFilters = (Map)namespaceEntry.getValue();
/* 1553 */           List keys = new LinkedList();
/* 1554 */           List filterValues = new LinkedList();
/* 1555 */           for (Map.Entry filter : namespaceFilters.entrySet()) {
/* 1556 */             keys.add(filter.getKey());
/* 1557 */             filterValues.add(filter.getValue());
/*      */           }
/* 1559 */           List objectValues = EnginePlugin.getObjectProperties(entity.getOid(), namespace, keys);
/* 1560 */           if (objectValues == null) {
/* 1561 */             possibleMatch = false;
/*      */ 
/* 1563 */             break;
/*      */           }
/* 1565 */           for (int i = 0; i < keys.size(); i++) {
/* 1566 */             String key = (String)keys.get(i);
/* 1567 */             Serializable filterVal = (Serializable)filterValues.get(i);
/* 1568 */             Serializable val = (Serializable)objectValues.get(i);
/* 1569 */             if ((filterVal == null) && (val == null))
/*      */               continue;
/* 1571 */             if (((filterVal == null) || (val != null)) && ((filterVal != null) || (val == null)) && (filterVal.equals(val))) {
/*      */               continue;
/*      */             }
/* 1574 */             possibleMatch = false;
/*      */ 
/* 1576 */             break;
/*      */           }
/*      */ 
/* 1579 */           if (!possibleMatch)
/*      */             break;
/*      */         }
/*      */       }
/* 1583 */       if (possibleMatch) {
/* 1584 */         rv.add(entity.getOid());
/*      */       }
/*      */     }
/*      */ 
/* 1588 */     return rv;
/*      */   }
/*      */ 
/*      */   protected boolean registerTemplate(Template tmpl) {
/* 1592 */     String templateType = tmpl.getTemplateType();
/* 1593 */     if (!this.templateManager.containsKey(templateType)) {
/* 1594 */       this.templateManager.put(templateType, new Manager(templateType + "Manager"));
/*      */     }
/* 1596 */     return ((Manager)this.templateManager.get(templateType)).register(tmpl.getTemplateID(), tmpl);
/*      */   }
/*      */ 
/*      */   public static int getNextFreeTemplateID() {
/* 1600 */     return nextFreeTemplateID--;
/*      */   }
/*      */ 
/*      */   private static class InstanceState
/*      */   {
/*      */     public ObjectManagerPlugin.MasterObject instance;
/*      */     public int status;
/* 1353 */     public Set<ObjectManagerPlugin.MasterObject> entities = new HashSet();
/*      */ 
/*      */     public InstanceState(ObjectManagerPlugin.MasterObject instance)
/*      */     {
/* 1332 */       this.instance = instance;
/* 1333 */       this.status = 0;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1338 */       return "instanceOid=" + this.instance.getOid() + " status=" + statusToString(this.status) + " entityCount=" + this.entities.size();
/*      */     }
/*      */ 
/*      */     public static String statusToString(int status)
/*      */     {
/* 1344 */       if (status == 0) return "OK";
/* 1345 */       if (status == 1) return "LOADING";
/* 1346 */       if (status == 2) return "UNLOADING";
/* 1347 */       if (status == 3) return "DELETING";
/* 1348 */       return "" + status + " (unknown)";
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MasterObject extends Entity
/*      */   {
/* 1318 */     private transient int loadedNamespaces = 0;
/*      */     private transient OID instanceOid;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public MasterObject()
/*      */     {
/*      */     }
/*      */ 
/*      */     public MasterObject(String name)
/*      */     {
/* 1274 */       super();
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid()
/*      */     {
/* 1280 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public void setInstanceOid(OID instanceOid2)
/*      */     {
/* 1285 */       this.instanceOid = instanceOid2;
/*      */     }
/*      */ 
/*      */     public int getLoadedNamespaces()
/*      */     {
/* 1290 */       return this.loadedNamespaces;
/*      */     }
/*      */ 
/*      */     public void setLoadedNamespaces(int namespaceBits)
/*      */     {
/* 1295 */       this.loadedNamespaces = namespaceBits;
/*      */     }
/*      */ 
/*      */     public void addLoadedNamespace(Namespace namespace)
/*      */     {
/* 1300 */       this.loadedNamespaces |= 1 << namespace.getNumber();
/*      */     }
/*      */ 
/*      */     public void removeLoadedNamespace(Namespace namespace)
/*      */     {
/* 1305 */       this.loadedNamespaces &= (1 << namespace.getNumber() ^ 0xFFFFFFFF);
/*      */     }
/*      */ 
/*      */     public boolean isNamespaceLoaded(Namespace namespace)
/*      */     {
/* 1310 */       return (this.loadedNamespaces & 1 << namespace.getNumber()) != 0;
/*      */     }
/*      */ 
/*      */     public boolean loadComplete()
/*      */     {
/* 1315 */       return getSubObjectNamespacesInt().intValue() == this.loadedNamespaces;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetObjectStatusHook
/*      */     implements Hook
/*      */   {
/* 1262 */     int lastLoginCount = 0;
/*      */ 
/*      */     GetObjectStatusHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1222 */       OID oid = ((SubjectMessage)msg).getSubject();
/* 1223 */       ObjectManagerClient.ObjectStatus objectStatus = new ObjectManagerClient.ObjectStatus();
/* 1224 */       objectStatus.oid = oid;
/* 1225 */       ObjectManagerPlugin.MasterObject masterObject = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(oid, Namespace.OBJECT_MANAGER);
/*      */ 
/* 1227 */       if (masterObject == null) {
/* 1228 */         String name = Engine.getDatabase().getObjectName(oid, Namespace.OBJECT_MANAGER);
/*      */ 
/* 1230 */         objectStatus.name = name;
/* 1231 */         Engine.getAgent().sendObjectResponse(msg, objectStatus);
/* 1232 */         return true;
/*      */       }
/* 1234 */       if (masterObject.isDeleted()) {
/* 1235 */         Engine.getAgent().sendObjectResponse(msg, objectStatus);
/* 1236 */         return true;
/*      */       }
/*      */ 
/* 1239 */       objectStatus.name = masterObject.getName();
/* 1240 */       objectStatus.type = masterObject.getType();
/* 1241 */       objectStatus.persistent = masterObject.getPersistenceFlag();
/* 1242 */       objectStatus.namespaces = new ArrayList(masterObject.getSubObjectNamespaces());
/*      */ 
/* 1244 */       objectStatus.loadedNamespaces = new ArrayList(objectStatus.namespaces.size());
/*      */ 
/* 1246 */       int loadedNS = masterObject.getLoadedNamespaces();
/* 1247 */       int nsBit = 2;
/* 1248 */       int nsInt = 1;
/* 1249 */       while (nsBit != 0) {
/* 1250 */         if ((loadedNS & nsBit) != 0) {
/* 1251 */           Namespace namespace = Namespace.getNamespaceFromInt(Integer.valueOf(nsInt));
/* 1252 */           objectStatus.loadedNamespaces.add(namespace);
/*      */         }
/* 1254 */         nsBit <<= 1;
/* 1255 */         nsInt++;
/*      */       }
/*      */ 
/* 1258 */       Engine.getAgent().sendObjectResponse(msg, objectStatus);
/* 1259 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetPluginStatusHook
/*      */     implements Hook
/*      */   {
/* 1216 */     int lastLoginCount = 0;
/*      */ 
/*      */     GetPluginStatusHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1203 */       LinkedHashMap status = new LinkedHashMap();
/*      */ 
/* 1205 */       status.put("plugin", ObjectManagerPlugin.this.getName());
/*      */       try {
/* 1207 */         status.put("account", Integer.valueOf(Engine.getDatabase().getAccountCount(Engine.getWorldName())));
/*      */       }
/*      */       catch (Exception e) {
/* 1210 */         Log.exception("GetPluginStatusHook", e);
/*      */       }
/* 1212 */       Engine.getAgent().sendObjectResponse(msg, status);
/* 1213 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetMatchingObjectsHook
/*      */     implements Hook
/*      */   {
/*      */     GetMatchingObjectsHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1193 */       ObjectManagerClient.GetMatchingObjectsMessage message = (ObjectManagerClient.GetMatchingObjectsMessage)msg;
/* 1194 */       List rv = ObjectManagerPlugin.this.getMatchingObjects(message.getInstanceOid(), message.getName(), message.getObjectType(), message.getFilters());
/*      */ 
/* 1196 */       Engine.getAgent().sendObjectResponse(message, rv);
/* 1197 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetNamedObjectHook
/*      */     implements Hook
/*      */   {
/*      */     GetNamedObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1177 */       ObjectManagerClient.GetNamedObjectMessage message = (ObjectManagerClient.GetNamedObjectMessage)msg;
/* 1178 */       OID oid = null;
/* 1179 */       if (message.getInstanceOid() != null) {
/* 1180 */         oid = ObjectManagerPlugin.this.getInstanceNamedObject(message.getInstanceOid(), message.getName(), message.getObjectType());
/*      */       }
/* 1182 */       else if (message.getName() != null) {
/* 1183 */         oid = ObjectManagerPlugin.this.getNamedObject(message.getName(), message.getObjectType());
/*      */       }
/* 1185 */       Engine.getAgent().sendOIDResponse(message, oid);
/* 1186 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class FixWorldNodeHook
/*      */     implements Hook
/*      */   {
/*      */     FixWorldNodeHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1124 */       ObjectManagerClient.FixWorldNodeMessage message = (ObjectManagerClient.FixWorldNodeMessage)msg;
/*      */ 
/* 1127 */       BasicWorldNode worldNode = message.getWorldNode();
/*      */ 
/* 1129 */       Entity entity = null;
/*      */       try {
/* 1131 */         entity = Engine.getDatabase().loadEntity(message.getOid(), WorldManagerClient.NAMESPACE);
/*      */       }
/*      */       catch (AORuntimeException e)
/*      */       {
/* 1135 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/* 1136 */         return false;
/*      */       }
/*      */ 
/* 1139 */       if (entity == null) {
/* 1140 */         Log.error("FixWorldNodeHook: unknown oid=" + message.getOid());
/* 1141 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/* 1142 */         return false;
/*      */       }
/* 1144 */       if (!(entity instanceof AOObject)) {
/* 1145 */         Log.error("FixWorldNodeHook: not instanceof AOObject oid=" + message.getOid() + " class=" + entity.getClass().getName());
/*      */ 
/* 1147 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/* 1148 */         return false;
/*      */       }
/*      */ 
/* 1151 */       AOObject obj = (AOObject)entity;
/* 1152 */       WMWorldNode wnode = (WMWorldNode)obj.worldNode();
/* 1153 */       wnode.setInstanceOid(worldNode.getInstanceOid());
/* 1154 */       if (worldNode.getLoc() != null)
/* 1155 */         wnode.setLoc(worldNode.getLoc());
/* 1156 */       if (worldNode.getOrientation() != null)
/* 1157 */         wnode.setOrientation(worldNode.getOrientation());
/* 1158 */       if (worldNode.getDir() != null) {
/* 1159 */         wnode.setDir(worldNode.getDir());
/*      */       }
/* 1161 */       Engine.getPersistenceManager().persistEntity(obj);
/*      */ 
/* 1163 */       if (Log.loggingDebug) {
/* 1164 */         ObjectManagerPlugin.log.debug("FixWorldNodeHook: done oid=" + message.getOid() + " wnode=" + obj.worldNode());
/*      */       }
/*      */ 
/* 1167 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(true));
/* 1168 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetTemplateNamesHook
/*      */     implements Hook
/*      */   {
/*      */     GetTemplateNamesHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message message, int flags)
/*      */     {
/* 1113 */       GenericMessage msg = (GenericMessage)message;
/* 1114 */       String templateType = (String)msg.getProperty("templateType");
/* 1115 */       List templateIDs = ((Manager)ObjectManagerPlugin.this.templateManager.get(templateType)).keyList();
/* 1116 */       Engine.getAgent().sendObjectResponse(message, templateIDs);
/* 1117 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetTemplateHook
/*      */     implements Hook
/*      */   {
/*      */     GetTemplateHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1098 */       ObjectManagerClient.GetTemplateMessage msg = (ObjectManagerClient.GetTemplateMessage)m;
/*      */ 
/* 1100 */       String templateType = msg.getTemplateType();
/* 1101 */       int templateID = msg.getTemplateID();
/* 1102 */       Template template = (Template)((Manager)ObjectManagerPlugin.this.templateManager.get(templateType)).get(Integer.valueOf(templateID));
/* 1103 */       Engine.getAgent().sendObjectResponse(msg, template);
/* 1104 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class RegisterTemplateHook
/*      */     implements Hook
/*      */   {
/*      */     RegisterTemplateHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1079 */       ObjectManagerClient.RegisterTemplateMessage msg = (ObjectManagerClient.RegisterTemplateMessage)m;
/*      */ 
/* 1081 */       Template template = msg.getTemplate();
/* 1082 */       boolean successStatus = ObjectManagerPlugin.this.registerTemplate(template);
/* 1083 */       if (Log.loggingDebug) {
/* 1084 */         ObjectManagerPlugin.log.debug("handleRegisterTemplateMsg: registered template: " + template + ", success=" + successStatus);
/*      */       }
/* 1086 */       ObjectManagerPlugin.log.debug("handleRegisterTemplateMsg: sending response message");
/* 1087 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(successStatus));
/* 1088 */       ObjectManagerPlugin.log.debug("handleRegisterTemplateMsg: response message sent");
/* 1089 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SetPersistenceHook
/*      */     implements Hook
/*      */   {
/*      */     SetPersistenceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1029 */       ObjectManagerClient.SetPersistenceMessage msg = (ObjectManagerClient.SetPersistenceMessage)m;
/* 1030 */       OID oid = msg.getSubject();
/* 1031 */       Entity master = EntityManager.getEntityByNamespace(oid, Namespace.OBJECT_MANAGER);
/* 1032 */       if (master == null) {
/* 1033 */         Log.error("SetPersistenceHook: no master entity found for oid " + oid);
/* 1034 */         Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(false));
/*      */       }
/* 1036 */       Boolean persistVal = msg.getPersistVal();
/*      */ 
/* 1038 */       if (Log.loggingDebug) {
/* 1039 */         ObjectManagerPlugin.log.debug("SetPersistenceHook: masterOid=" + oid + ", persistVal=" + persistVal);
/*      */       }
/*      */ 
/* 1043 */       List namespaces = master.getSubObjectNamespaces();
/*      */ 
/* 1046 */       for (Namespace namespace : namespaces) {
/* 1047 */         if (Log.loggingDebug)
/* 1048 */           ObjectManagerPlugin.log.debug("SetPersistenceHook: masterOid=" + oid + ", sending setpersistence msg to sub ns " + namespace);
/* 1049 */         Message persistSubMsg = new ObjectManagerClient.SetSubPersistenceMessage(oid, namespace, persistVal);
/*      */ 
/* 1051 */         Engine.getAgent().sendRPC(persistSubMsg);
/*      */       }
/*      */ 
/* 1055 */       master.setPersistenceFlag(persistVal.booleanValue());
/*      */ 
/* 1058 */       if (persistVal.booleanValue()) {
/* 1059 */         Engine.getPersistenceManager().setDirty(master);
/* 1060 */         ObjectManagerPlugin.log.debug("SetPersistenceHook: set master object dirty");
/*      */       }
/*      */       else
/*      */       {
/* 1064 */         Engine.getDatabase().deleteObjectData(oid);
/*      */       }
/*      */ 
/* 1067 */       ObjectManagerPlugin.log.debug("SetPersistenceHook: done with persistence");
/* 1068 */       Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(true));
/* 1069 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class InstanceRPCCallback
/*      */     implements ResponseCallback
/*      */   {
/*      */     OID instanceOid;
/*      */     String operation;
/*      */ 
/*      */     public InstanceRPCCallback(OID instanceOid, String operation)
/*      */     {
/* 1008 */       this.instanceOid = instanceOid;
/* 1009 */       this.operation = operation;
/*      */     }
/*      */ 
/*      */     public void handleResponse(ResponseMessage response)
/*      */     {
/* 1014 */       Log.debug(this.operation + ": got response, instanceOid=" + this.instanceOid);
/*      */     }
/*      */   }
/*      */ 
/*      */   class DeleteInstanceHook
/*      */     implements Hook
/*      */   {
/*      */     DeleteInstanceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  960 */       SubjectMessage message = (SubjectMessage)m;
/*  961 */       OID instanceOid = message.getSubject();
/*      */ 
/*  964 */       ObjectManagerPlugin.MasterObject entity = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(instanceOid, Namespace.OBJECT_MANAGER);
/*      */ 
/*  966 */       if (entity == null) {
/*  967 */         Log.error("DeleteInstanceHook: instance not loaded oid=" + instanceOid);
/*      */ 
/*  969 */         Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*  970 */         return true;
/*      */       }
/*      */ 
/*  973 */       if (!ObjectManagerPlugin.this.isInstanceOk(instanceOid, 3)) {
/*  974 */         Log.error("DeleteInstanceHook: instance not available instanceOid=" + instanceOid);
/*      */ 
/*  976 */         Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*  977 */         return true;
/*      */       }
/*      */ 
/*  980 */       ObjectManagerPlugin.InstanceState instanceState = (ObjectManagerPlugin.InstanceState)ObjectManagerPlugin.this.instanceContent.get(instanceOid);
/*  981 */       if (instanceState != null) {
/*  982 */         List objects = new ArrayList(instanceState.entities);
/*      */ 
/*  984 */         for (ObjectManagerPlugin.MasterObject obj : objects)
/*      */         {
/*  986 */           if (!obj.getType().isPlayer()) {
/*  987 */             ObjectManagerClient.deleteObject(obj.getOid());
/*      */           }
/*      */         }
/*      */       }
/*  991 */       SubjectMessage deletedMessage = new SubjectMessage(InstanceClient.MSG_TYPE_INSTANCE_DELETED, instanceOid);
/*      */ 
/*  993 */       Engine.getAgent().sendBroadcastRPC(deletedMessage, new ObjectManagerPlugin.InstanceRPCCallback(instanceOid, "InstanceDeleted"));
/*      */ 
/*  996 */       ObjectManagerClient.deleteObject(instanceOid);
/*      */ 
/*  998 */       Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(true));
/*      */ 
/* 1000 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class UnloadInstanceHook
/*      */     implements Hook
/*      */   {
/*      */     UnloadInstanceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  910 */       SubjectMessage message = (SubjectMessage)m;
/*  911 */       OID instanceOid = message.getSubject();
/*      */ 
/*  914 */       ObjectManagerPlugin.MasterObject entity = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(instanceOid, Namespace.OBJECT_MANAGER);
/*      */ 
/*  916 */       if (entity == null) {
/*  917 */         Log.error("UnloadInstanceHook: instance not loaded oid=" + instanceOid);
/*      */ 
/*  919 */         Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*  920 */         return true;
/*      */       }
/*      */ 
/*  923 */       if (!ObjectManagerPlugin.this.isInstanceOk(instanceOid, 2)) {
/*  924 */         Log.error("UnloadInstanceHook: instance not available instanceOid=" + instanceOid);
/*      */ 
/*  926 */         Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*  927 */         return true;
/*      */       }
/*      */ 
/*  930 */       ObjectManagerPlugin.InstanceState instanceState = (ObjectManagerPlugin.InstanceState)ObjectManagerPlugin.this.instanceContent.get(instanceOid);
/*  931 */       if (instanceState != null) {
/*  932 */         List objects = new ArrayList(instanceState.entities);
/*      */ 
/*  934 */         for (ObjectManagerPlugin.MasterObject obj : objects)
/*      */         {
/*  936 */           if (!obj.getType().isPlayer()) {
/*  937 */             ObjectManagerClient.unloadObject(obj.getOid());
/*      */           }
/*      */         }
/*      */       }
/*  941 */       SubjectMessage unloadedMessage = new SubjectMessage(InstanceClient.MSG_TYPE_INSTANCE_UNLOADED, instanceOid);
/*      */ 
/*  943 */       Engine.getAgent().sendBroadcastRPC(unloadedMessage, new ObjectManagerPlugin.InstanceRPCCallback(instanceOid, "InstanceUnloaded"));
/*      */ 
/*  946 */       ObjectManagerClient.unloadObject(instanceOid);
/*      */ 
/*  948 */       Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(true));
/*      */ 
/*  950 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class LoadInstanceContentHook
/*      */     implements Hook
/*      */   {
/*      */     LoadInstanceContentHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  869 */       SubjectMessage message = (SubjectMessage)m;
/*  870 */       OID instanceOid = message.getSubject();
/*      */ 
/*  873 */       ObjectManagerPlugin.MasterObject entity = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(instanceOid, Namespace.OBJECT_MANAGER);
/*      */ 
/*  875 */       if (entity == null) {
/*  876 */         Log.error("LoadInstanceContentHook: instance not loaded instanceOid=" + instanceOid);
/*      */ 
/*  878 */         Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*  879 */         return true;
/*      */       }
/*      */ 
/*  882 */       if (!ObjectManagerPlugin.this.isInstanceOk(instanceOid, 1)) {
/*  883 */         Log.error("LoadInstanceContentHook: instance not available instanceOid=" + instanceOid);
/*      */ 
/*  885 */         Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*  886 */         return true;
/*      */       }
/*      */ 
/*  889 */       List content = Engine.getDatabase().getInstanceContent(instanceOid, ObjectTypes.player);
/*      */ 
/*  892 */       for (OID oid : content) {
/*  893 */         if (ObjectManagerClient.loadObject(oid) != null) {
/*  894 */           WorldManagerClient.spawn(oid);
/*      */         }
/*      */       }
/*  897 */       ObjectManagerPlugin.this.setInstanceStatus(instanceOid, 0);
/*      */ 
/*  899 */       Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(true));
/*      */ 
/*  901 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GenerateObjectHook
/*      */     implements Hook
/*      */   {
/*  790 */     Table<OID, Namespace, Collection<Namespace>> depTable = new Table();
/*      */ 
/*      */     GenerateObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  652 */       ObjectManagerClient.GenerateObjectMessage msg = (ObjectManagerClient.GenerateObjectMessage)m;
/*      */ 
/*  656 */       int templateID = msg.getTemplateID();
/*  657 */       String templateType = msg.getTemplateType();
/*  658 */       Log.debug("ANDREW: getting template: " + templateID + " of templateType: " + templateType);
/*  659 */       Template template = (Template)((Manager)ObjectManagerPlugin.this.templateManager.get(templateType)).get(Integer.valueOf(templateID));
/*  660 */       if (template == null) {
/*  661 */         Log.error("template not found: " + templateType + ":" + templateID);
/*  662 */         Engine.getAgent().sendOIDResponse(msg, null);
/*  663 */         return false;
/*      */       }
/*      */ 
/*  668 */       Template overrideTemplate = msg.getOverrideTemplate();
/*      */       Template finalTemplate;
/*      */       Template finalTemplate;
/*  669 */       if (overrideTemplate != null) {
/*  670 */         finalTemplate = template.merge(overrideTemplate);
/*      */       }
/*      */       else {
/*  673 */         finalTemplate = template;
/*      */       }
/*      */ 
/*  676 */       Boolean persistent = (Boolean)finalTemplate.get(Namespace.OBJECT_MANAGER, ":persistent");
/*      */ 
/*  678 */       if (persistent == null) {
/*  679 */         persistent = Boolean.valueOf(false);
/*      */       }
/*  681 */       if (Log.loggingDebug) {
/*  682 */         ObjectManagerPlugin.log.debug("GenerateObjectHook: generating entity: " + finalTemplate.getName() + ", template=" + finalTemplate);
/*      */       }
/*      */ 
/*  686 */       String entityName = (String)finalTemplate.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME);
/*  687 */       if (entityName == null) {
/*  688 */         entityName = finalTemplate.getName();
/*      */       }
/*  690 */       OID instanceOid = (OID)finalTemplate.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE);
/*      */ 
/*  692 */       ObjectType objectType = (ObjectType)finalTemplate.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE);
/*      */ 
/*  696 */       ObjectManagerPlugin.MasterObject masterObj = new ObjectManagerPlugin.MasterObject(entityName);
/*  697 */       masterObj.setPersistenceFlag(persistent.booleanValue());
/*  698 */       masterObj.setInstanceOid(instanceOid);
/*  699 */       if (objectType != null) {
/*  700 */         masterObj.setType(objectType);
/*      */       }
/*      */ 
/*  703 */       Map objMgrProps = finalTemplate.getSubMap(Namespace.OBJECT_MANAGER);
/*      */ 
/*  705 */       if (objMgrProps != null)
/*      */       {
/*  707 */         for (Map.Entry entry : objMgrProps.entrySet()) {
/*  708 */           if (!((String)entry.getKey()).startsWith(":")) {
/*  709 */             masterObj.setProperty((String)entry.getKey(), (Serializable)entry.getValue());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  714 */       EntityManager.registerEntityByNamespace(masterObj, Namespace.OBJECT_MANAGER);
/*  715 */       if (Log.loggingDebug) {
/*  716 */         ObjectManagerPlugin.log.debug("GenerateObjectHook: created master obj: " + masterObj);
/*      */       }
/*      */ 
/*  720 */       Set namespaces = finalTemplate.getNamespaces();
/*  721 */       namespaces.remove(Namespace.OBJECT_MANAGER);
/*  722 */       masterObj.setSubObjectNamespaces(namespaces);
/*      */ 
/*  724 */       if (persistent.booleanValue()) {
/*  725 */         Engine.getPersistenceManager().persistEntity(masterObj);
/*      */       }
/*      */ 
/*  732 */       for (Namespace namespace : namespaces)
/*      */       {
/*  734 */         Template subTemplate = finalTemplate.restrict(namespace);
/*  735 */         subTemplate.put(Namespace.OBJECT_MANAGER, ":persistent", persistent);
/*      */ 
/*  737 */         if (Log.loggingDebug) {
/*  738 */           ObjectManagerPlugin.log.debug("GenerateObjectHook: creating subobj for ns=" + namespace + ", subTemplate=" + subTemplate);
/*      */         }
/*  740 */         GenericResponseMessage respMsg = ObjectManagerPlugin.this.generateSubObject(masterObj.getOid(), namespace, subTemplate);
/*      */ 
/*  744 */         masterObj.addLoadedNamespace(namespace);
/*      */ 
/*  747 */         List depNamespaces = (List)respMsg.getData();
/*      */ 
/*  749 */         if (Log.loggingDebug) {
/*  750 */           ObjectManagerPlugin.log.debug("GenerateObjectHook: created subobj for ns=" + namespace);
/*      */         }
/*      */ 
/*  756 */         if ((depNamespaces == null) || (depNamespaces.isEmpty()))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/*  761 */         this.depTable.put(masterObj.getOid(), namespace, depNamespaces);
/*      */       }
/*      */ 
/*  765 */       Map depMap = this.depTable.getSubMap(masterObj.getOid());
/*  766 */       if ((depMap != null) && (!depMap.isEmpty()))
/*      */       {
/*  768 */         while (!depMap.isEmpty()) {
/*  769 */           Namespace ns = (Namespace)depMap.keySet().iterator().next();
/*  770 */           ObjectManagerPlugin.this.resolveDeps(masterObj.getOid(), ns, depMap);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  777 */       if (namespaces.contains(WorldManagerClient.INSTANCE_NAMESPACE)) {
/*  778 */         ObjectManagerPlugin.this.addInstance(masterObj);
/*      */       }
/*  780 */       if ((instanceOid != null) && (!masterObj.getType().isPlayer())) {
/*  781 */         ObjectManagerPlugin.this.addInstanceContent(instanceOid, masterObj);
/*      */       }
/*      */ 
/*  785 */       Engine.getAgent().sendOIDResponse(msg, masterObj.getOid());
/*  786 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SaveObjectDataHook
/*      */     implements Hook
/*      */   {
/*      */     SaveObjectDataHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  621 */       ObjectManagerClient.SaveObjectDataMessage msg = (ObjectManagerClient.SaveObjectDataMessage)m;
/*  622 */       OID oid = msg.getSubject();
/*  623 */       String persistenceKey = msg.getKey();
/*  624 */       if (msg.getNamespace() == Namespace.TRANSIENT) {
/*  625 */         ObjectManagerPlugin.log.warn("SaveObjectDataHook: ignoring transient namespace for oid=" + oid + " key=" + persistenceKey);
/*  626 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.FALSE);
/*  627 */         return false;
/*      */       }
/*      */ 
/*  630 */       if (Log.loggingDebug) {
/*  631 */         ObjectManagerPlugin.log.debug("SaveObjectDataHook: oid=" + oid);
/*      */       }
/*  633 */       byte[] data = (byte[])msg.getDataBytes();
/*      */ 
/*  636 */       Engine.getDatabase().saveObject(persistenceKey, data, msg.getNamespace());
/*      */ 
/*  639 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.TRUE);
/*  640 */       if (Log.loggingDebug)
/*  641 */         ObjectManagerPlugin.log.debug("SaveObjectDataHook: sent response for obj=" + oid);
/*  642 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class LoadObjectDataHook
/*      */     implements Hook
/*      */   {
/*      */     LoadObjectDataHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  598 */       ObjectManagerClient.LoadObjectDataMessage msg = (ObjectManagerClient.LoadObjectDataMessage)m;
/*  599 */       OID oid = msg.getSubject();
/*  600 */       String persistenceKey = msg.getKey();
/*      */ 
/*  603 */       Entity entity = null;
/*  604 */       if (persistenceKey != null) {
/*  605 */         entity = Engine.getDatabase().loadEntity(persistenceKey);
/*      */       }
/*  607 */       else if (oid != null) {
/*  608 */         entity = Engine.getDatabase().loadEntity(oid, msg.getNamespace());
/*      */       }
/*      */       else
/*      */       {
/*  612 */         ObjectManagerPlugin.log.error("LoadObjectDataHook: oid and key both null");
/*      */       }
/*  614 */       Engine.getAgent().sendObjectResponse(msg, entity);
/*  615 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class SaveObjectProcessor
/*      */     implements ResponseCallback
/*      */   {
/*      */     ObjectManagerClient.SaveObjectMessage msg;
/*      */     OID oid;
/*      */     String key;
/*      */     ObjectManagerPlugin.MasterObject masterObj;
/*      */     List<Message> pendingRPC;
/*      */ 
/*      */     public SaveObjectProcessor(ObjectManagerClient.SaveObjectMessage message)
/*      */     {
/*  501 */       this.msg = message;
/*  502 */       this.oid = this.msg.getOid();
/*  503 */       this.key = this.msg.getKey();
/*  504 */       this.masterObj = ((ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(this.oid, Namespace.OBJECT_MANAGER));
/*      */     }
/*      */ 
/*      */     public void processMessage()
/*      */     {
/*  509 */       if (Log.loggingDebug) {
/*  510 */         Log.debug("SaveObjectHook: oid=" + this.oid);
/*      */       }
/*  512 */       if (!this.masterObj.getPersistenceFlag()) {
/*  513 */         Log.warn("Ignoring saveObject for non-persistent object oid=" + this.oid);
/*  514 */         Engine.getAgent().sendBooleanResponse(this.msg, Boolean.FALSE);
/*  515 */         return;
/*      */       }
/*      */ 
/*  519 */       List namespaces = this.masterObj.getSubObjectNamespaces();
/*  520 */       if (Log.loggingDebug) {
/*  521 */         String s = "";
/*  522 */         for (Namespace ns : namespaces) {
/*  523 */           if (s != "")
/*  524 */             s = s + ",";
/*  525 */           s = s + ns;
/*      */         }
/*  527 */         Log.debug("SaveObjectHook: masterObj namespaces " + s);
/*      */       }
/*      */ 
/*  530 */       this.pendingRPC = new ArrayList(namespaces.size());
/*      */ 
/*  533 */       synchronized (this.pendingRPC) {
/*  534 */         for (Namespace namespace : namespaces) {
/*  535 */           if (Log.loggingDebug) {
/*  536 */             Log.debug("SaveObjectHook: oid=" + this.oid + ", sending save subobj msg to ns=" + namespace);
/*      */           }
/*  538 */           Message saveSubMsg = new OIDNamespaceMessage(ObjectManagerClient.MSG_TYPE_SAVE_SUBOBJECT, this.oid, namespace);
/*      */ 
/*  541 */           this.pendingRPC.add(saveSubMsg);
/*      */ 
/*  543 */           Engine.getAgent().sendRPC(saveSubMsg, this);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void handleResponse(ResponseMessage response)
/*      */     {
/*  550 */       synchronized (this.pendingRPC) {
/*  551 */         Message request = null;
/*  552 */         for (Message message : this.pendingRPC) {
/*  553 */           if (message.getMsgId() == response.getRequestId()) {
/*  554 */             this.pendingRPC.remove(message);
/*  555 */             request = message;
/*  556 */             break;
/*      */           }
/*      */         }
/*  559 */         if (request == null)
/*  560 */           Log.error("SaveObjectHook: unexpected response " + response);
/*  561 */         if (!((BooleanResponseMessage)response).getBooleanVal().booleanValue()) {
/*  562 */           ObjectManagerPlugin.log.warn("SaveObjectHook: sub object load failed for oid=" + this.oid + " " + request);
/*      */         }
/*      */       }
/*      */ 
/*  566 */       if (this.pendingRPC.size() == 0) {
/*  567 */         saveMasterObject();
/*  568 */         Engine.getAgent().sendBooleanResponse(this.msg, Boolean.TRUE);
/*      */       }
/*      */     }
/*      */ 
/*      */     void saveMasterObject()
/*      */     {
/*  574 */       if (Log.loggingDebug) {
/*  575 */         Log.debug("SaveObjectHook: saving master object oid=" + this.oid);
/*      */       }
/*      */ 
/*  580 */       Engine.getPersistenceManager().callSaveHooks(this.masterObj);
/*  581 */       Engine.getDatabase().saveObject(this.key, this.masterObj.toBytes(), this.masterObj.getNamespace());
/*      */ 
/*  585 */       if (Log.loggingDebug)
/*  586 */         Log.debug("SaveObjectHook: success oid=" + this.oid);
/*      */     }
/*      */   }
/*      */ 
/*      */   class SaveObjectHook
/*      */     implements Hook
/*      */   {
/*      */     SaveObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  491 */       ObjectManagerClient.SaveObjectMessage msg = (ObjectManagerClient.SaveObjectMessage)m;
/*      */ 
/*  493 */       new ObjectManagerPlugin.SaveObjectProcessor(msg).processMessage();
/*  494 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DeleteObjectHook
/*      */     implements Hook
/*      */   {
/*      */     DeleteObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  424 */       ObjectManagerClient.DeleteObjectMessage msg = (ObjectManagerClient.DeleteObjectMessage)m;
/*      */ 
/*  426 */       OID oid = msg.getOid();
/*      */ 
/*  429 */       ObjectManagerPlugin.MasterObject entity = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(oid, Namespace.OBJECT_MANAGER);
/*      */ 
/*  432 */       if (entity == null) {
/*  433 */         ObjectManagerPlugin.log.debug("DeleteObjectHook: no such entity oid=" + oid);
/*      */ 
/*  437 */         Engine.getDatabase().deleteObjectData(oid);
/*  438 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(true));
/*  439 */         return false;
/*      */       }
/*      */ 
/*  442 */       if (entity.isDeleted()) {
/*  443 */         return true;
/*      */       }
/*  445 */       entity.setDeleted();
/*      */ 
/*  448 */       List namespaces = entity.getSubObjectNamespaces();
/*  449 */       int failure = 0;
/*      */ 
/*  451 */       for (Namespace namespace : namespaces) {
/*  452 */         if (Log.loggingDebug) {
/*  453 */           ObjectManagerPlugin.log.debug("DeleteObjectHook: oid=" + oid + ", sending delete subobj msg, ns=" + namespace);
/*      */         }
/*      */ 
/*  456 */         ObjectManagerClient.DeleteSubObjectMessage deleteSubMsg = new ObjectManagerClient.DeleteSubObjectMessage(oid, namespace);
/*      */ 
/*  458 */         Boolean rv = Engine.getAgent().sendRPCReturnBoolean(deleteSubMsg);
/*  459 */         if (!rv.booleanValue()) {
/*  460 */           ObjectManagerPlugin.log.error("DeleteObjectHook: sub object delete failed oid=" + oid + " ns=" + namespace);
/*      */ 
/*  462 */           failure++;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  467 */       Engine.getDatabase().deleteObjectData(oid);
/*  468 */       EntityManager.removeEntityByNamespace(entity, Namespace.OBJECT_MANAGER);
/*      */ 
/*  470 */       if (namespaces.contains(WorldManagerClient.INSTANCE_NAMESPACE)) {
/*  471 */         ObjectManagerPlugin.this.removeInstance(entity);
/*      */       }
/*  473 */       if ((entity.getInstanceOid() != null) && (!entity.getType().isPlayer()))
/*      */       {
/*  475 */         ObjectManagerPlugin.this.removeInstanceContent(entity.getInstanceOid(), entity);
/*      */       }
/*      */ 
/*  478 */       if (Log.loggingDebug) {
/*  479 */         ObjectManagerPlugin.log.debug("DeleteObjectHook: deleted oid=" + oid + ", " + failure + " failures");
/*      */       }
/*      */ 
/*  483 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(failure == 0));
/*      */ 
/*  485 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class UnloadObjectHook
/*      */     implements Hook
/*      */   {
/*      */     UnloadObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  352 */       ObjectManagerClient.UnloadObjectMessage msg = (ObjectManagerClient.UnloadObjectMessage)m;
/*  353 */       OID oid = msg.getOid();
/*      */ 
/*  355 */       ObjectManagerPlugin.MasterObject entity = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(oid, Namespace.OBJECT_MANAGER);
/*      */ 
/*  360 */       if (entity == null) {
/*  361 */         ObjectManagerPlugin.log.error("UnloadObjectHook: no such entity oid=" + oid);
/*  362 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/*  363 */         return false;
/*      */       }
/*      */ 
/*  367 */       Collection namespaces = msg.getNamespaces();
/*  368 */       if (namespaces == null)
/*  369 */         namespaces = entity.getSubObjectNamespaces();
/*  370 */       int failure = 0;
/*      */ 
/*  373 */       for (Namespace namespace : namespaces) {
/*  374 */         if (Log.loggingDebug) {
/*  375 */           ObjectManagerPlugin.log.debug("UnloadObjectHook: oid=" + oid + ", sending unload subobj msg, ns=" + namespace);
/*      */         }
/*      */ 
/*  378 */         ObjectManagerClient.UnloadSubObjectMessage unloadSubMsg = new ObjectManagerClient.UnloadSubObjectMessage(oid, namespace);
/*      */ 
/*  380 */         Boolean rv = Engine.getAgent().sendRPCReturnBoolean(unloadSubMsg);
/*  381 */         if (!rv.booleanValue()) {
/*  382 */           ObjectManagerPlugin.log.error("UnloadObjectHook: sub object unload failed oid=" + oid + " ns=" + namespace);
/*      */ 
/*  384 */           failure++;
/*      */         }
/*  386 */         else if (msg.getNamespaces() != null) {
/*  387 */           entity.removeLoadedNamespace(namespace);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  392 */       if (msg.getNamespaces() == null) {
/*  393 */         EntityManager.removeEntityByNamespace(entity, Namespace.OBJECT_MANAGER);
/*      */ 
/*  395 */         if ((entity.getPersistenceFlag()) && (Engine.getPersistenceManager().isDirty(entity)))
/*      */         {
/*  397 */           Engine.getPersistenceManager().persistEntity(entity);
/*      */         }
/*      */       }
/*  400 */       if (namespaces.contains(WorldManagerClient.INSTANCE_NAMESPACE)) {
/*  401 */         ObjectManagerPlugin.this.removeInstance(entity);
/*      */       }
/*  403 */       if ((entity.getInstanceOid() != null) && (!entity.getType().isPlayer()) && (namespaces.contains(WorldManagerClient.NAMESPACE)))
/*      */       {
/*  406 */         ObjectManagerPlugin.this.removeInstanceContent(entity.getInstanceOid(), entity);
/*      */       }
/*      */ 
/*  409 */       if (Log.loggingDebug) {
/*  410 */         ObjectManagerPlugin.log.debug("UnloadObjectHook: unloaded oid=" + oid + ", " + failure + " failures");
/*      */       }
/*      */ 
/*  414 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(failure == 0));
/*      */ 
/*  416 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class LoadObjectHook
/*      */     implements Hook
/*      */   {
/*      */     LoadObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  146 */       ObjectManagerClient.LoadObjectMessage msg = (ObjectManagerClient.LoadObjectMessage)m;
/*  147 */       OID oid = msg.getOid();
/*      */ 
/*  149 */       String persistenceKey = null;
/*      */ 
/*  152 */       ObjectManagerPlugin.MasterObject entity = null;
/*  153 */       if (oid == null)
/*      */       {
/*  155 */         persistenceKey = msg.getKey();
/*  156 */         if (persistenceKey == null) {
/*  157 */           Log.warn("LoadObjectHook: no key or oid");
/*  158 */           Engine.getAgent().sendOIDResponse(msg, null);
/*  159 */           return false;
/*      */         }
/*      */ 
/*  163 */         Entity temp = Engine.getDatabase().loadEntity(persistenceKey);
/*  164 */         if (temp == null) {
/*  165 */           ObjectManagerPlugin.log.error("LoadObjectHook: unknown object, key=" + persistenceKey);
/*      */ 
/*  167 */           Engine.getAgent().sendOIDResponse(msg, null);
/*  168 */           return false;
/*      */         }
/*  170 */         if ((!(temp instanceof ObjectManagerPlugin.MasterObject)) || (temp.getSubObjectNamespacesInt() == null))
/*      */         {
/*  172 */           ObjectManagerPlugin.log.error("LoadObjectHook: not a master object, key=" + persistenceKey + " oid=" + temp.getOid());
/*      */ 
/*  174 */           Engine.getAgent().sendOIDResponse(msg, null);
/*  175 */           return false;
/*      */         }
/*      */ 
/*  179 */         entity = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(temp.getOid(), Namespace.OBJECT_MANAGER);
/*      */ 
/*  181 */         if (entity != null) {
/*  182 */           if (entity.loadComplete()) {
/*  183 */             Log.debug("LoadObjectHook: object already loaded oid=" + oid + " entity=" + entity);
/*      */ 
/*  185 */             Engine.getAgent().sendOIDResponse(msg, oid);
/*  186 */             return false;
/*      */           }
/*      */         }
/*      */         else {
/*  190 */           entity = (ObjectManagerPlugin.MasterObject)temp;
/*  191 */           EntityManager.registerEntityByNamespace(entity, Namespace.OBJECT_MANAGER);
/*      */         }
/*      */ 
/*  195 */         oid = entity.getOid();
/*      */       }
/*      */       else {
/*  198 */         if (Log.loggingDebug) {
/*  199 */           ObjectManagerPlugin.log.debug("LoadObjectHook: master oid=" + oid);
/*      */         }
/*  201 */         entity = (ObjectManagerPlugin.MasterObject)EntityManager.getEntityByNamespace(oid, Namespace.OBJECT_MANAGER);
/*      */ 
/*  203 */         if (entity != null) {
/*  204 */           if (entity.loadComplete()) {
/*  205 */             Point location = new Point();
/*  206 */             OID instanceOid = Engine.getDatabase().getLocation(oid, WorldManagerClient.NAMESPACE, location);
/*      */ 
/*  208 */             Log.debug("LoadObjectHook: object already loaded oid=" + oid + " entity=" + entity + " with instanceOid: " + entity.getInstanceOid() + " and instanceOid from the database: " + instanceOid);
/*      */ 
/*  211 */             if (!instanceOid.equals(entity.getInstanceOid()));
/*  233 */             Engine.getAgent().sendOIDResponse(msg, oid);
/*  234 */             return false;
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  244 */           entity = (ObjectManagerPlugin.MasterObject)Engine.getDatabase().loadEntity(oid, Namespace.OBJECT_MANAGER);
/*      */ 
/*  247 */           if (entity != null) {
/*  248 */             EntityManager.registerEntityByNamespace(entity, Namespace.OBJECT_MANAGER);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  253 */       if ((entity == null) || (entity.isDeleted())) {
/*  254 */         ObjectManagerPlugin.log.error("LoadObjectHook: no such entity with oid " + oid + " or key " + persistenceKey);
/*      */ 
/*  256 */         Engine.getAgent().sendOIDResponse(msg, null);
/*  257 */         return false;
/*      */       }
/*      */ 
/*  260 */       Collection namespaces = msg.getNamespaces();
/*  261 */       if (namespaces == null) {
/*  262 */         namespaces = entity.getSubObjectNamespaces();
/*      */       }
/*  264 */       OID instanceOid = null;
/*  265 */       Point location = null;
/*  266 */       if ((namespaces.contains(WorldManagerClient.NAMESPACE)) && (!entity.isNamespaceLoaded(WorldManagerClient.NAMESPACE)))
/*      */       {
/*  268 */         location = new Point();
/*  269 */         instanceOid = Engine.getDatabase().getLocation(oid, WorldManagerClient.NAMESPACE, location);
/*      */ 
/*  271 */         if (instanceOid == null) {
/*  272 */           Log.error("LoadObjectHook: world manager object missing instanceOid, entity=" + entity);
/*  273 */           Engine.getAgent().sendOIDResponse(msg, null);
/*  274 */           return false;
/*      */         }
/*  276 */         Log.debug("POP: got instance on load: " + instanceOid);
/*  277 */         if (ObjectManagerPlugin.this.instanceContent.get(instanceOid) == null) {
/*  278 */           int rc = InstanceClient.loadInstance(instanceOid);
/*  279 */           if (rc != 0) {
/*  280 */             if (rc != -1)
/*  281 */               Log.error("LoadObjectHook: internal error loading instanceOid=" + instanceOid + " for oid=" + oid + ", rc=" + rc);
/*  282 */             Engine.getAgent().sendOIDResponse(msg, null);
/*  283 */             return false;
/*      */           }
/*      */         }
/*  286 */         if (!ObjectManagerPlugin.this.isInstanceLoading(instanceOid)) {
/*  287 */           Log.error("LoadObjectHook: instance unavailable for oid=" + oid + " instanceOid=" + instanceOid + " " + ObjectManagerPlugin.this.instanceContent.get(instanceOid));
/*      */ 
/*  290 */           Engine.getAgent().sendOIDResponse(msg, null);
/*  291 */           return false;
/*      */         }
/*  293 */         entity.setInstanceOid(instanceOid);
/*      */       }
/*      */ 
/*  297 */       for (Namespace namespace : namespaces) {
/*  298 */         if (entity.isNamespaceLoaded(namespace))
/*      */           continue;
/*  300 */         if (Log.loggingDebug)
/*  301 */           ObjectManagerPlugin.log.debug("LoadObjectHook: masterOid=" + oid + ", sending load subobj msg, ns=" + namespace);
/*      */         ObjectManagerClient.LoadSubObjectMessage loadSubMsg;
/*      */         ObjectManagerClient.LoadSubObjectMessage loadSubMsg;
/*  304 */         if (namespace == WorldManagerClient.NAMESPACE) {
/*  305 */           loadSubMsg = new WorldManagerClient.LoadSubObjectMessage(oid, namespace, location, instanceOid);
/*      */         }
/*      */         else
/*      */         {
/*  310 */           loadSubMsg = new ObjectManagerClient.LoadSubObjectMessage(oid, namespace);
/*      */         }
/*      */ 
/*      */         Boolean rv;
/*      */         try
/*      */         {
/*  317 */           rv = Engine.getAgent().sendRPCReturnBoolean(loadSubMsg);
/*      */         }
/*      */         catch (NoRecipientsException e) {
/*  320 */           ObjectManagerPlugin.log.exception("LoadObjectHook: sub object load failed, maybe instance does not exist", e);
/*  321 */           Engine.getAgent().sendOIDResponse(msg, null);
/*  322 */           return false;
/*      */         }
/*      */ 
/*  325 */         if (!rv.booleanValue()) {
/*  326 */           ObjectManagerPlugin.log.error("LoadObjectHook: sub object load failed: " + namespace);
/*      */ 
/*  328 */           Engine.getAgent().sendOIDResponse(msg, null);
/*  329 */           return false;
/*      */         }
/*      */ 
/*  332 */         entity.addLoadedNamespace(namespace);
/*      */       }
/*      */ 
/*  335 */       if (namespaces.contains(WorldManagerClient.INSTANCE_NAMESPACE)) {
/*  336 */         ObjectManagerPlugin.this.addInstance(entity);
/*      */       }
/*  338 */       if ((instanceOid != null) && (!entity.getType().isPlayer())) {
/*  339 */         ObjectManagerPlugin.this.addInstanceContent(instanceOid, entity);
/*      */       }
/*      */ 
/*  343 */       Engine.getAgent().sendOIDResponse(msg, oid);
/*  344 */       if (Log.loggingDebug)
/*  345 */         ObjectManagerPlugin.log.debug("LoadObjectHook: sent success response for master obj=" + oid);
/*  346 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class ModifyNamespaceHook
/*      */     implements Hook
/*      */   {
/*      */     ModifyNamespaceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flag)
/*      */     {
/*  125 */       ObjectManagerClient.ModifyNamespaceMessage message = (ObjectManagerClient.ModifyNamespaceMessage)msg;
/*  126 */       OID oid = message.getOid();
/*  127 */       Collection namespaces = message.getNamespaces();
/*  128 */       String command = message.getCommand();
/*  129 */       Entity masterEntity = EntityManager.getEntityByNamespace(oid, Namespace.OBJECT_MANAGER);
/*  130 */       Boolean rv = Boolean.valueOf(masterEntity != null);
/*  131 */       if (rv.booleanValue()) {
/*  132 */         for (Namespace ns : namespaces) {
/*  133 */           masterEntity.addSubObjectNamespace(ns);
/*      */         }
/*  135 */         Engine.getPersistenceManager().setDirty(masterEntity);
/*      */       }
/*  137 */       Engine.getAgent().sendBooleanResponse(msg, rv);
/*  138 */       return true;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.ObjectManagerPlugin
 * JD-Core Version:    0.6.0
 */