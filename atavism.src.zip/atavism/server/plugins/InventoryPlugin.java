/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageCallback;
/*     */ import atavism.msgsys.MessageTypeFilter;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.EnginePlugin;
/*     */ import atavism.server.engine.EnginePlugin.DeleteHook;
/*     */ import atavism.server.engine.EnginePlugin.GenerateSubObjectHook;
/*     */ import atavism.server.engine.EnginePlugin.LoadHook;
/*     */ import atavism.server.engine.EnginePlugin.SaveHook;
/*     */ import atavism.server.engine.EnginePlugin.SubObjData;
/*     */ import atavism.server.engine.EnginePlugin.UnloadHook;
/*     */ import atavism.server.engine.Hook;
/*     */ import atavism.server.engine.HookManager;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.objects.AOObject;
/*     */ import atavism.server.objects.Entity;
/*     */ import atavism.server.objects.Template;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import atavism.server.util.ObjectLockManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public abstract class InventoryPlugin extends EnginePlugin
/*     */   implements MessageCallback
/*     */ {
/*  29 */   public static String INVENTORY_PLUGIN_NAME = "Inventory";
/*     */ 
/* 479 */   protected static final Logger log = new Logger("InventoryPlugin");
/*     */ 
/* 485 */   protected Lock lock = LockFactory.makeLock("InventoryPlugin");
/*     */   public static final String INVENTORY_PROP_BAG_KEY = "inv.bag";
/*     */   public static final String INVENTORY_PROP_BACKREF_KEY = "inv.backref";
/*     */ 
/*     */   public InventoryPlugin()
/*     */   {
/*  25 */     super(INVENTORY_PLUGIN_NAME);
/*  26 */     setPluginType("Inventory");
/*     */   }
/*     */ 
/*     */   public void onActivate()
/*     */   {
/*     */     try
/*     */     {
/*  34 */       registerHooks();
/*     */ 
/*  36 */       MessageTypeFilter filter = new MessageTypeFilter();
/*  37 */       filter.addType(InventoryClient.MSG_TYPE_ACTIVATE);
/*  38 */       filter.addType(WorldManagerClient.MSG_TYPE_UPDATE_OBJECT);
/*  39 */       filter.addType(InventoryClient.MSG_TYPE_DESTROY_ITEM);
/*  40 */       Engine.getAgent().createSubscription(filter, this);
/*     */ 
/*  42 */       filter = new MessageTypeFilter();
/*  43 */       filter.addType(InventoryClient.MSG_TYPE_ADD_ITEM);
/*  44 */       filter.addType(InventoryClient.MSG_TYPE_INV_REMOVE);
/*  45 */       filter.addType(InventoryClient.MSG_TYPE_CREATE_INV);
/*  46 */       filter.addType(InventoryClient.MSG_TYPE_LOOTALL);
/*  47 */       filter.addType(InventoryClient.MSG_TYPE_INV_FIND);
/*  48 */       Engine.getAgent().createSubscription(filter, this, 8);
/*     */ 
/*  51 */       List namespaces = new ArrayList();
/*  52 */       namespaces.add(Namespace.BAG);
/*  53 */       namespaces.add(Namespace.AGISITEM);
/*  54 */       registerPluginNamespaces(namespaces, new InventoryGenerateSubObjectHook());
/*     */ 
/*  57 */       registerLoadHook(Namespace.BAG, new InventoryLoadHook());
/*  58 */       registerLoadHook(Namespace.AGISITEM, new ItemLoadHook());
/*  59 */       registerUnloadHook(Namespace.BAG, new InventoryUnloadHook());
/*  60 */       registerUnloadHook(Namespace.AGISITEM, new ItemUnloadHook());
/*  61 */       registerDeleteHook(Namespace.BAG, new InventoryDeleteHook());
/*  62 */       registerDeleteHook(Namespace.AGISITEM, new ItemDeleteHook());
/*  63 */       registerSaveHook(Namespace.BAG, new InventorySaveHook());
/*  64 */       registerSaveHook(Namespace.AGISITEM, new ItemSaveHook());
/*     */     } catch (Exception e) {
/*  66 */       throw new AORuntimeException("activate failed", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void registerHooks() {
/*  71 */     getHookManager().addHook(InventoryClient.MSG_TYPE_ADD_ITEM, new AddItemHook());
/*     */ 
/*  73 */     getHookManager().addHook(InventoryClient.MSG_TYPE_ACTIVATE, new ItemActivateHook());
/*     */ 
/*  75 */     getHookManager().addHook(InventoryClient.MSG_TYPE_LOOTALL, new LootAllHook());
/*     */ 
/*  77 */     getHookManager().addHook(InventoryClient.MSG_TYPE_INV_FIND, new FindItemHook());
/*     */ 
/*  79 */     getHookManager().addHook(InventoryClient.MSG_TYPE_INV_REMOVE, new RemoveItemHook());
/*     */ 
/*  81 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_UPDATE_OBJECT, new UpdateObjHook());
/*     */ 
/*  83 */     getHookManager().addHook(InventoryClient.MSG_TYPE_DESTROY_ITEM, new DestroyItemHook());
/*     */   }
/*     */ 
/*     */   public abstract void updateObject(OID paramOID1, OID paramOID2);
/*     */ 
/*     */   public abstract boolean equipItem(AOObject paramAOObject, OID paramOID, boolean paramBoolean);
/*     */ 
/*     */   protected abstract boolean activateObject(OID paramOID1, OID paramOID2, OID paramOID3);
/*     */ 
/*     */   protected abstract EnginePlugin.SubObjData createInvSubObj(OID paramOID, Template paramTemplate);
/*     */ 
/*     */   protected abstract EnginePlugin.SubObjData createItemSubObj(OID paramOID, Template paramTemplate);
/*     */ 
/*     */   protected abstract void loadInventory(Entity paramEntity);
/*     */ 
/*     */   protected abstract void loadItem(Entity paramEntity);
/*     */ 
/*     */   protected abstract void unloadInventory(Entity paramEntity);
/*     */ 
/*     */   protected abstract void unloadItem(Entity paramEntity);
/*     */ 
/*     */   protected abstract void deleteInventory(Entity paramEntity);
/*     */ 
/*     */   protected void deleteInventory(OID oid)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected abstract void deleteItem(Entity paramEntity);
/*     */ 
/*     */   protected void deleteItem(OID oid)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected abstract void saveInventory(Entity paramEntity, Namespace paramNamespace);
/*     */ 
/*     */   protected abstract void saveItem(Entity paramEntity, Namespace paramNamespace);
/*     */ 
/*     */   protected abstract void sendInvUpdate(OID paramOID);
/*     */ 
/*     */   protected abstract boolean addItem(OID paramOID1, OID paramOID2, OID paramOID3);
/*     */ 
/*     */   protected abstract boolean removeItemFromBag(OID paramOID1, OID paramOID2);
/*     */ 
/*     */   protected abstract boolean lootAll(OID paramOID1, OID paramOID2);
/*     */ 
/*     */   protected abstract boolean containsItem(OID paramOID1, OID paramOID2);
/*     */ 
/*     */   protected abstract OID findItem(OID paramOID, int paramInt);
/*     */ 
/*     */   protected abstract ArrayList<OID> findItems(OID paramOID, ArrayList<Integer> paramArrayList);
/*     */ 
/*     */   protected abstract OID removeItem(OID paramOID1, OID paramOID2, boolean paramBoolean);
/*     */ 
/*     */   protected abstract OID removeItem(OID paramOID, int paramInt, boolean paramBoolean);
/*     */ 
/*     */   protected abstract ArrayList<OID> removeItems(OID paramOID, ArrayList<Integer> paramArrayList, boolean paramBoolean);
/*     */ 
/*     */   protected boolean destroyItem(OID containerOid, OID itemOid)
/*     */   {
/* 476 */     throw new RuntimeException("not implemented");
/*     */   }
/*     */ 
/*     */   public Lock getLock()
/*     */   {
/* 482 */     return this.lock;
/*     */   }
/*     */ 
/*     */   class RemoveItemHook
/*     */     implements Hook
/*     */   {
/*     */     RemoveItemHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 329 */       InventoryClient.RemoveOrFindItemMessage delMsg = (InventoryClient.RemoveOrFindItemMessage)msg;
/* 330 */       OID mobOid = delMsg.getSubject();
/* 331 */       String method = delMsg.getMethod();
/*     */ 
/* 333 */       InventoryPlugin.log.debug("RemoveItemHook: got message");
/* 334 */       if (method.equals("oid")) {
/* 335 */         OID oid = (OID)delMsg.getPayload();
/* 336 */         OID result = InventoryPlugin.this.removeItem(mobOid, oid, true);
/* 337 */         Engine.getAgent().sendOIDResponse(delMsg, result);
/* 338 */       } else if (method.equals("template")) {
/* 339 */         int templateID = ((Integer)delMsg.getPayload()).intValue();
/* 340 */         OID result = InventoryPlugin.this.removeItem(mobOid, templateID, true);
/* 341 */         Engine.getAgent().sendOIDResponse(delMsg, result);
/*     */       }
/* 343 */       else if (method.equals("templateList")) {
/* 344 */         ArrayList templateList = (ArrayList)delMsg.getPayload();
/* 345 */         ArrayList result = InventoryPlugin.this.removeItems(mobOid, templateList, true);
/* 346 */         Engine.getAgent().sendObjectResponse(delMsg, result);
/*     */       }
/*     */       else {
/* 349 */         Log.error("RemoveItemHook: unknown method=" + method);
/*     */       }
/* 351 */       InventoryPlugin.this.sendInvUpdate(mobOid);
/* 352 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class FindItemHook
/*     */     implements Hook
/*     */   {
/*     */     FindItemHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 301 */       InventoryClient.RemoveOrFindItemMessage findMsg = (InventoryClient.RemoveOrFindItemMessage)msg;
/* 302 */       OID mobOid = findMsg.getSubject();
/* 303 */       String method = findMsg.getMethod();
/*     */ 
/* 305 */       InventoryPlugin.log.debug("FindItemHook: got message");
/* 306 */       if (method.equals("template")) {
/* 307 */         int template = ((Integer)findMsg.getPayload()).intValue();
/* 308 */         OID resultOid = InventoryPlugin.this.findItem(mobOid, template);
/* 309 */         Engine.getAgent().sendOIDResponse(findMsg, resultOid);
/*     */       }
/* 311 */       else if (method.equals("templateList")) {
/* 312 */         ArrayList templateList = (ArrayList)findMsg.getPayload();
/* 313 */         ArrayList resultList = InventoryPlugin.this.findItems(mobOid, templateList);
/* 314 */         Engine.getAgent().sendObjectResponse(findMsg, resultList);
/*     */       }
/*     */       else {
/* 317 */         Log.error("FindItemHook: unknown method=" + method);
/*     */       }
/* 319 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class LootAllHook
/*     */     implements Hook
/*     */   {
/*     */     LootAllHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 280 */       InventoryClient.LootAllMessage lMsg = (InventoryClient.LootAllMessage)msg;
/* 281 */       OID looterOid = lMsg.getSubject();
/* 282 */       OID containerOid = lMsg.getContainerOid();
/* 283 */       if (Log.loggingDebug) {
/* 284 */         InventoryPlugin.log.debug("LootAllHook: looter=" + looterOid + ", container=" + containerOid);
/*     */       }
/*     */ 
/* 287 */       boolean rv = InventoryPlugin.this.lootAll(looterOid, containerOid);
/*     */ 
/* 290 */       Engine.getAgent().sendBooleanResponse(lMsg, Boolean.valueOf(rv));
/* 291 */       return rv;
/*     */     }
/*     */   }
/*     */ 
/*     */   class ItemActivateHook
/*     */     implements Hook
/*     */   {
/*     */     ItemActivateHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 254 */       InventoryClient.ActivateMessage aMsg = (InventoryClient.ActivateMessage)msg;
/*     */ 
/* 256 */       OID activatorOid = aMsg.getActivatorOid();
/* 257 */       OID objOid = aMsg.getSubject();
/* 258 */       OID targetOid = aMsg.getTargetOid();
/* 259 */       if (Log.loggingDebug) {
/* 260 */         InventoryPlugin.log.debug("ItemActivateHook: activatorOid=" + activatorOid + ", objOid=" + objOid + ", targetOid=" + targetOid);
/*     */       }
/*     */ 
/* 263 */       Lock objLock = InventoryPlugin.this.getObjectLockManager().getLock(activatorOid);
/* 264 */       objLock.lock();
/*     */       try {
/* 266 */         boolean bool = InventoryPlugin.this.activateObject(objOid, activatorOid, targetOid);
/*     */         return bool; } finally { objLock.unlock(); } throw localObject;
/*     */     }
/*     */   }
/*     */ 
/*     */   class DestroyItemHook
/*     */     implements Hook
/*     */   {
/*     */     DestroyItemHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 220 */       WorldManagerClient.ExtensionMessage destroyMsg = (WorldManagerClient.ExtensionMessage)msg;
/* 221 */       OID ownerOid = destroyMsg.getSubject();
/* 222 */       OID itemOid = (OID)destroyMsg.getProperty("itemOid");
/*     */ 
/* 224 */       if (Log.loggingDebug) {
/* 225 */         InventoryPlugin.log.debug("DestroyItemHook: ownerOid=" + ownerOid + ", itemOid=" + itemOid);
/*     */       }
/* 227 */       boolean rv = false;
/*     */ 
/* 237 */       rv = InventoryPlugin.this.containsItem(ownerOid, itemOid);
/* 238 */       if (!rv) {
/* 239 */         InventoryPlugin.log.debug("DestroyItemHook: item " + itemOid + " not owned by owner " + ownerOid);
/* 240 */         return true;
/*     */       }
/* 242 */       rv = ObjectManagerClient.deleteObject(itemOid).booleanValue();
/* 243 */       if (rv) {
/* 244 */         InventoryPlugin.this.sendInvUpdate(ownerOid);
/*     */       }
/* 246 */       if (Log.loggingDebug)
/* 247 */         InventoryPlugin.log.debug("DestroyItemHook.deleteObject: success=" + rv);
/* 248 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class AddItemHook
/*     */     implements Hook
/*     */   {
/*     */     AddItemHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 190 */       InventoryClient.AddItemMessage aMsg = (InventoryClient.AddItemMessage)msg;
/* 191 */       OID containerOid = aMsg.getContainer();
/* 192 */       OID itemOid = aMsg.getItem();
/* 193 */       OID mobOid = aMsg.getMob();
/* 194 */       if (Log.loggingDebug) {
/* 195 */         InventoryPlugin.log.debug("addItemHook: containerOid=" + containerOid + ", itemOid=" + itemOid);
/*     */       }
/*     */ 
/* 198 */       Lock objLock = InventoryPlugin.this.getObjectLockManager().getLock(mobOid);
/* 199 */       objLock.lock();
/*     */       try {
/* 201 */         boolean rv = InventoryPlugin.this.addItem(mobOid, containerOid, itemOid);
/*     */ 
/* 203 */         if (Log.loggingDebug) {
/* 204 */           InventoryPlugin.log.debug("addItemHook: containerOid=" + containerOid + ", itemOid=" + itemOid + ", result=" + rv);
/*     */         }
/*     */ 
/* 207 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(rv));
/*     */ 
/* 210 */         InventoryPlugin.this.sendInvUpdate(mobOid);
/* 211 */         boolean bool1 = rv;
/*     */         return bool1; } finally { objLock.unlock(); } throw localObject;
/*     */     }
/*     */   }
/*     */ 
/*     */   class UpdateObjHook
/*     */     implements Hook
/*     */   {
/*     */     UpdateObjHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 169 */       WorldManagerClient.UpdateMessage cMsg = (WorldManagerClient.UpdateMessage)msg;
/* 170 */       OID oid = cMsg.getSubject();
/*     */ 
/* 173 */       OID nOid = cMsg.getTarget();
/* 174 */       if (!oid.equals(nOid)) {
/* 175 */         return true;
/*     */       }
/* 177 */       Lock objLock = InventoryPlugin.this.getObjectLockManager().getLock(oid);
/* 178 */       objLock.lock();
/*     */       try {
/* 180 */         InventoryPlugin.this.updateObject(oid, cMsg.getTarget());
/* 181 */         int i = 1;
/*     */         return i; } finally { objLock.unlock(); } throw localObject;
/*     */     }
/*     */   }
/*     */ 
/*     */   class ItemSaveHook
/*     */     implements EnginePlugin.SaveHook
/*     */   {
/*     */     ItemSaveHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onSave(Entity e, Namespace namespace)
/*     */     {
/* 162 */       InventoryPlugin.this.saveItem(e, namespace);
/*     */     }
/*     */   }
/*     */ 
/*     */   class InventorySaveHook
/*     */     implements EnginePlugin.SaveHook
/*     */   {
/*     */     InventorySaveHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onSave(Entity e, Namespace namespace)
/*     */     {
/* 156 */       InventoryPlugin.this.saveInventory(e, namespace);
/*     */     }
/*     */   }
/*     */ 
/*     */   class ItemDeleteHook
/*     */     implements EnginePlugin.DeleteHook
/*     */   {
/*     */     ItemDeleteHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onDelete(Entity e)
/*     */     {
/* 147 */       InventoryPlugin.this.deleteItem(e);
/*     */     }
/*     */     public void onDelete(OID oid, Namespace namespace) {
/* 150 */       InventoryPlugin.this.deleteItem(oid);
/*     */     }
/*     */   }
/*     */ 
/*     */   class ItemUnloadHook
/*     */     implements EnginePlugin.UnloadHook
/*     */   {
/*     */     ItemUnloadHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onUnload(Entity e)
/*     */     {
/* 141 */       InventoryPlugin.this.unloadItem(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   class ItemLoadHook
/*     */     implements EnginePlugin.LoadHook
/*     */   {
/*     */     ItemLoadHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onLoad(Entity e)
/*     */     {
/* 135 */       InventoryPlugin.this.loadItem(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   class InventoryDeleteHook
/*     */     implements EnginePlugin.DeleteHook
/*     */   {
/*     */     InventoryDeleteHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onDelete(Entity e)
/*     */     {
/* 126 */       InventoryPlugin.this.deleteInventory(e);
/*     */     }
/*     */     public void onDelete(OID oid, Namespace namespace) {
/* 129 */       InventoryPlugin.this.deleteInventory(oid);
/*     */     }
/*     */   }
/*     */ 
/*     */   class InventoryUnloadHook
/*     */     implements EnginePlugin.UnloadHook
/*     */   {
/*     */     InventoryUnloadHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onUnload(Entity e)
/*     */     {
/* 120 */       InventoryPlugin.this.unloadInventory(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   class InventoryLoadHook
/*     */     implements EnginePlugin.LoadHook
/*     */   {
/*     */     InventoryLoadHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onLoad(Entity e)
/*     */     {
/* 114 */       InventoryPlugin.this.loadInventory(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   class InventoryGenerateSubObjectHook extends EnginePlugin.GenerateSubObjectHook
/*     */   {
/*     */     public InventoryGenerateSubObjectHook()
/*     */     {
/*  94 */       super();
/*     */     }
/*     */ 
/*     */     public EnginePlugin.SubObjData generateSubObject(Template template, Namespace namespace, OID masterOid) {
/*  98 */       if (Log.loggingDebug) {
/*  99 */         InventoryPlugin.log.debug("GenerateSubObjectHook: masterOid=" + masterOid + ", template=" + template);
/*     */       }
/* 101 */       if (namespace.equals(Namespace.BAG))
/* 102 */         return InventoryPlugin.this.createInvSubObj(masterOid, template);
/* 103 */       if (namespace.equals(Namespace.AGISITEM)) {
/* 104 */         return InventoryPlugin.this.createItemSubObj(masterOid, template);
/*     */       }
/* 106 */       InventoryPlugin.log.error("InventoryGenerateSubObjectHook: unknown namespace: " + namespace);
/*     */ 
/* 108 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.InventoryPlugin
 * JD-Core Version:    0.6.0
 */