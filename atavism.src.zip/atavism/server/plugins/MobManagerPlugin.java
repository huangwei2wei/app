/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.agis.objects.SpawnGenerator;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageTypeFilter;
/*     */ import atavism.msgsys.ResponseMessage;
/*     */ import atavism.msgsys.SubjectMessage;
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.EnginePlugin;
/*     */ import atavism.server.engine.EnginePlugin.DeleteHook;
/*     */ import atavism.server.engine.EnginePlugin.UnloadHook;
/*     */ import atavism.server.engine.Hook;
/*     */ import atavism.server.engine.HookManager;
/*     */ import atavism.server.engine.InterpolatedWorldNode;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.objects.Entity;
/*     */ import atavism.server.objects.EntityManager;
/*     */ import atavism.server.objects.ObjectFactory;
/*     */ import atavism.server.objects.ObjectStub;
/*     */ import atavism.server.objects.ObjectStubFactory;
/*     */ import atavism.server.objects.ObjectTracker;
/*     */ import atavism.server.objects.ObjectType;
/*     */ import atavism.server.objects.SpawnData;
/*     */ import atavism.server.objects.Template;
/*     */ import atavism.server.objects.WEObjFactory;
/*     */ import atavism.server.objects.World;
/*     */ import atavism.server.pathing.PathInfo;
/*     */ import atavism.server.pathing.PathSearcher;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class MobManagerPlugin extends EnginePlugin
/*     */ {
/* 300 */   private static Map<String, Class> spawnGeneratorClasses = new HashMap();
/*     */ 
/* 303 */   private static Map<OID, ObjectTracker> trackers = new HashMap();
/*     */   private static Collection<ObjectType> trackedObjectTypes;
/* 308 */   protected static final Logger log = new Logger("MobManagerPlugin");
/*     */ 
/* 311 */   protected PathInfo pathInfo = null;
/* 312 */   protected boolean askedForPathInfo = false;
/*     */ 
/*     */   public MobManagerPlugin()
/*     */   {
/*  21 */     super("MobManager");
/*  22 */     setPluginType("MobManager");
/*     */   }
/*     */   public void onActivate() {
/*     */     try {
/*  26 */       log.debug("onActivate()");
/*     */ 
/*  28 */       registerHooks();
/*  29 */       registerUnloadHook(Namespace.MOB, new MobUnloadHook());
/*  30 */       registerDeleteHook(Namespace.MOB, new MobDeleteHook());
/*     */ 
/*  32 */       MessageTypeFilter filter = new MessageTypeFilter();
/*  33 */       filter.addType(MobManagerClient.MSG_TYPE_CREATE_SPAWN_GEN);
/*  34 */       filter.addType(InstanceClient.MSG_TYPE_INSTANCE_DELETED);
/*  35 */       filter.addType(InstanceClient.MSG_TYPE_INSTANCE_UNLOADED);
/*  36 */       Engine.getAgent().createSubscription(filter, this, 8);
/*     */ 
/*  39 */       MessageTypeFilter filter2 = new MessageTypeFilter();
/*  40 */       filter2.addType(MobManagerClient.MSG_TYPE_SET_AGGRO_RADIUS);
/*  41 */       Engine.getAgent().createSubscription(filter2, this);
/*  42 */       ObjectFactory.register("WEObjFactory", new WEObjFactory());
/*     */     }
/*     */     catch (Exception e) {
/*  45 */       throw new AORuntimeException("activate failed", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void registerHooks()
/*     */   {
/*  52 */     getHookManager().addHook(MobManagerClient.MSG_TYPE_CREATE_SPAWN_GEN, new CreateSpawnGenHook());
/*     */ 
/*  54 */     getHookManager().addHook(MobManagerClient.MSG_TYPE_SET_AGGRO_RADIUS, new SetAggroRadiusHook());
/*     */ 
/*  56 */     getHookManager().addHook(InstanceClient.MSG_TYPE_INSTANCE_DELETED, new InstanceUnloadedHook());
/*     */ 
/*  58 */     getHookManager().addHook(InstanceClient.MSG_TYPE_INSTANCE_UNLOADED, new InstanceUnloadedHook());
/*     */   }
/*     */ 
/*     */   public static ObjectStub createObject(int templateID, OID instanceOid, Point loc, Quaternion orient)
/*     */   {
/*  65 */     return createObject(templateID, instanceOid, loc, orient, true);
/*     */   }
/*     */ 
/*     */   public static ObjectStub createObject(int templateID, OID instanceOid, Point loc, Quaternion orient, boolean followsTerrain)
/*     */   {
/*  71 */     if (Log.loggingDebug) {
/*  72 */       log.debug("createObject: template=" + templateID + ", point=" + loc + ", calling into objectmanager to generate");
/*     */     }
/*  74 */     Template override = new Template();
/*  75 */     override.put(WorldManagerClient.NAMESPACE, WorldManagerClient.TEMPL_INSTANCE, instanceOid);
/*  76 */     override.put(WorldManagerClient.NAMESPACE, WorldManagerClient.TEMPL_LOC, loc);
/*  77 */     if (orient != null)
/*  78 */       override.put(WorldManagerClient.NAMESPACE, WorldManagerClient.TEMPL_ORIENT, orient);
/*  79 */     override.put(WorldManagerClient.NAMESPACE, WorldManagerClient.TEMPL_FOLLOWS_TERRAIN, new Boolean(followsTerrain));
/*     */ 
/*  81 */     return createObject(templateID, override, null);
/*     */   }
/*     */ 
/*     */   public static ObjectStub createObject(int templateID, Template override, OID instanceOid)
/*     */   {
/*  87 */     if (Log.loggingDebug) {
/*  88 */       log.debug("createObject: template=" + templateID + ", override=" + override + ", instanceOid=" + instanceOid + " calling into objectmanager to generate");
/*     */     }
/*     */ 
/*  93 */     if (instanceOid != null) {
/*  94 */       override.put(WorldManagerClient.NAMESPACE, WorldManagerClient.TEMPL_INSTANCE, instanceOid);
/*     */     }
/*  96 */     OID objId = ObjectManagerClient.generateObject(templateID, ObjectManagerPlugin.MOB_TEMPLATE, override);
/*     */ 
/*  98 */     if (Log.loggingDebug) {
/*  99 */       log.debug("generated object oid=" + objId);
/*     */     }
/* 101 */     if (objId == null) {
/* 102 */       Log.warn("MobManagerPlugin: oid is null, skipping");
/* 103 */       return null;
/*     */     }
/*     */ 
/* 106 */     BasicWorldNode bwNode = WorldManagerClient.getWorldNode(objId);
/* 107 */     InterpolatedWorldNode iwNode = new InterpolatedWorldNode(bwNode);
/* 108 */     ObjectStub obj = new ObjectStub(objId, iwNode, templateID);
/* 109 */     EntityManager.registerEntityByNamespace(obj, Namespace.MOB);
/* 110 */     if (Log.loggingDebug)
/* 111 */       log.debug("createObject: obj=" + obj);
/* 112 */     return obj;
/*     */   }
/*     */ 
/*     */   public PathInfo getPathInfo()
/*     */   {
/* 203 */     return this.pathInfo;
/*     */   }
/*     */ 
/*     */   public void setPathInfo(PathInfo pathInfo) {
/* 207 */     this.pathInfo = pathInfo;
/* 208 */     PathSearcher.createPathSearcher(pathInfo, World.getGeometry());
/*     */   }
/*     */ 
/*     */   public static void setTrackedObjectTypes(Collection<ObjectType> objectTypes)
/*     */   {
/* 217 */     if (objectTypes != null)
/* 218 */       trackedObjectTypes = new ArrayList(objectTypes);
/*     */     else
/* 220 */       trackedObjectTypes = null;
/*     */   }
/*     */ 
/*     */   public static List<ObjectType> getTrackedObjectTypes()
/*     */   {
/* 226 */     return new ArrayList(trackedObjectTypes);
/*     */   }
/*     */ 
/*     */   public static ObjectTracker getTracker(OID instanceOID)
/*     */   {
/* 231 */     synchronized (trackers) {
/* 232 */       ObjectTracker tracker = (ObjectTracker)trackers.get(instanceOID);
/* 233 */       if (tracker == null) {
/* 234 */         if (Log.loggingDebug)
/* 235 */           log.debug("Creating ObjectTracker for instanceOid=" + instanceOID + "with types: " + trackedObjectTypes);
/* 236 */         tracker = new ObjectTracker(Namespace.MOB, instanceOID, new ObjectStubFactory(), trackedObjectTypes);
/*     */ 
/* 238 */         trackers.put(instanceOID, tracker);
/*     */       }
/* 240 */       return tracker;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void removeTracker(OID instanceOid)
/*     */   {
/* 246 */     synchronized (trackers) {
/* 247 */       trackers.remove(instanceOid);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setAggroRadiusTracker(OID mob, OID target, int reactionRadius)
/*     */   {
/* 267 */     OID instanceOID = WorldManagerClient.getObjectInfo(mob).instanceOid;
/* 268 */     Log.debug("AJ: AggroRadius with instanceOid: " + instanceOID + " and trackers: " + trackers);
/* 269 */     synchronized (trackers) {
/* 270 */       ObjectTracker tracker = (ObjectTracker)trackers.get(instanceOID);
/* 271 */       if (tracker == null)
/* 272 */         return;
/* 273 */       if (reactionRadius == -1)
/* 274 */         tracker.removeAggroRadius(mob, target);
/*     */       else
/* 276 */         tracker.addAggroRadius(mob, target, Integer.valueOf(reactionRadius));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void registerSpawnGeneratorClass(String name, Class spawnGenClass)
/*     */   {
/* 288 */     synchronized (spawnGeneratorClasses) {
/* 289 */       spawnGeneratorClasses.put(name, spawnGenClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class getSpawnGeneratorClass(String name)
/*     */   {
/* 297 */     return (Class)spawnGeneratorClasses.get(name);
/*     */   }
/*     */ 
/*     */   class SetAggroRadiusHook
/*     */     implements Hook
/*     */   {
/*     */     SetAggroRadiusHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 253 */       MobManagerClient.SetAggroRadiusMessage message = (MobManagerClient.SetAggroRadiusMessage)msg;
/*     */ 
/* 256 */       OID mob = message.getMob();
/* 257 */       OID target = message.getTarget();
/* 258 */       int reactionRadius = message.getRadius();
/* 259 */       MobManagerPlugin.setAggroRadiusTracker(mob, target, reactionRadius);
/*     */ 
/* 261 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class InstanceUnloadedHook
/*     */     implements Hook
/*     */   {
/*     */     InstanceUnloadedHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 190 */       SubjectMessage message = (SubjectMessage)msg;
/* 191 */       OID instanceOid = message.getSubject();
/*     */ 
/* 193 */       SpawnGenerator.cleanupInstance(instanceOid);
/* 194 */       MobManagerPlugin.removeTracker(instanceOid);
/*     */ 
/* 196 */       Engine.getAgent().sendResponse(new ResponseMessage(message));
/* 197 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class CreateSpawnGenHook
/*     */     implements Hook
/*     */   {
/*     */     CreateSpawnGenHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 142 */       MobManagerClient.CreateSpawnGeneratorMessage message = (MobManagerClient.CreateSpawnGeneratorMessage)msg;
/*     */ 
/* 145 */       SpawnData spawnData = message.getSpawnData();
/* 146 */       ObjectFactory factory = ObjectFactory.getFactory(spawnData.getFactoryName());
/*     */ 
/* 148 */       if (factory == null) {
/* 149 */         Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/* 150 */         if (Log.loggingDebug) {
/* 151 */           Log.debug("CreateSpawnGenHook: unknown factory=" + spawnData.getFactoryName());
/*     */         }
/* 153 */         return true;
/*     */       }
/*     */ 
/* 156 */       SpawnGenerator spawnGen = null;
/* 157 */       String spawnGenClassName = (String)spawnData.getProperty("className");
/* 158 */       if (spawnGenClassName == null) {
/* 159 */         spawnGenClassName = spawnData.getClassName();
/*     */       }
/* 161 */       if (spawnGenClassName == null)
/* 162 */         spawnGen = new SpawnGenerator(spawnData);
/*     */       else {
/*     */         try
/*     */         {
/* 166 */           Class spawnGenClass = (Class)MobManagerPlugin.spawnGeneratorClasses.get(spawnGenClassName);
/*     */ 
/* 168 */           if (spawnGenClass == null) {
/* 169 */             throw new AORuntimeException("spawn generator class not registered");
/*     */           }
/* 171 */           spawnGen = (SpawnGenerator)spawnGenClass.newInstance();
/* 172 */           spawnGen.initialize(spawnData);
/*     */         }
/*     */         catch (Exception ex) {
/* 175 */           Log.exception("CreateSpawnGenHook: failed instantiating class " + spawnGenClassName, ex);
/* 176 */           Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/* 177 */           return true;
/*     */         }
/*     */       }
/* 180 */       spawnGen.setObjectFactory(factory);
/* 181 */       spawnGen.activate();
/* 182 */       Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(true));
/* 183 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   class MobDeleteHook
/*     */     implements EnginePlugin.DeleteHook
/*     */   {
/*     */     MobDeleteHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onDelete(Entity entity)
/*     */     {
/* 129 */       if ((entity instanceof ObjectStub))
/* 130 */         ((ObjectStub)entity).unload();
/*     */     }
/*     */ 
/*     */     public void onDelete(OID oid, Namespace namespace)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   class MobUnloadHook
/*     */     implements EnginePlugin.UnloadHook
/*     */   {
/*     */     MobUnloadHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void onUnload(Entity entity)
/*     */     {
/* 119 */       if ((entity instanceof ObjectStub))
/* 120 */         ((ObjectStub)entity).unload();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.MobManagerPlugin
 * JD-Core Version:    0.6.0
 */