/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.agis.events.AbilityStatusEvent;
/*      */ import atavism.agis.events.AbilityStatusMessage;
/*      */ import atavism.agis.events.ConcludeQuest;
/*      */ import atavism.agis.events.QuestResponse;
/*      */ import atavism.agis.events.RequestQuestInfo;
/*      */ import atavism.agis.plugins.AnimationClient;
/*      */ import atavism.agis.plugins.AnimationClient.InvokeEffectMessage;
/*      */ import atavism.agis.plugins.CombatClient;
/*      */ import atavism.agis.plugins.CombatClient.AbilityUpdateMessage;
/*      */ import atavism.agis.plugins.CombatClient.DamageMessage;
/*      */ import atavism.agis.plugins.QuestClient;
/*      */ import atavism.agis.plugins.QuestClient.QuestResponseMessage;
/*      */ import atavism.management.Management;
/*      */ import atavism.msgsys.FilterUpdate;
/*      */ import atavism.msgsys.GenericMessage;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageAgent.DomainClient;
/*      */ import atavism.msgsys.MessageCallback;
/*      */ import atavism.msgsys.MessageType;
/*      */ import atavism.msgsys.MessageTypeFilter;
/*      */ import atavism.msgsys.NoRecipientsException;
/*      */ import atavism.msgsys.ResponseCallback;
/*      */ import atavism.msgsys.ResponseMessage;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.msgsys.TargetMessage;
/*      */ import atavism.server.engine.BasicWorldNode;
/*      */ import atavism.server.engine.Database;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.EnginePlugin;
/*      */ import atavism.server.engine.Event;
/*      */ import atavism.server.engine.EventServer;
/*      */ import atavism.server.engine.Hook;
/*      */ import atavism.server.engine.HookManager;
/*      */ import atavism.server.engine.Namespace;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.events.ActivateItemEvent;
/*      */ import atavism.server.events.AmbientLightEvent;
/*      */ import atavism.server.events.AttachEvent;
/*      */ import atavism.server.events.AuthorizedLoginEvent;
/*      */ import atavism.server.events.AuthorizedLoginResponseEvent;
/*      */ import atavism.server.events.AutoAttackEvent;
/*      */ import atavism.server.events.ComEvent;
/*      */ import atavism.server.events.CommandEvent;
/*      */ import atavism.server.events.DetachEvent;
/*      */ import atavism.server.events.DirLocOrientEvent;
/*      */ import atavism.server.events.ExtensionMessageEvent;
/*      */ import atavism.server.events.FreeTerrainDecalEvent;
/*      */ import atavism.server.events.LoadingStateEvent;
/*      */ import atavism.server.events.ModelInfoEvent;
/*      */ import atavism.server.events.NewLightEvent;
/*      */ import atavism.server.events.NewTerrainDecalEvent;
/*      */ import atavism.server.events.NotifyFreeObjectEvent;
/*      */ import atavism.server.events.NotifyPlayAnimationEvent;
/*      */ import atavism.server.events.UITheme;
/*      */ import atavism.server.events.WorldFileEvent;
/*      */ import atavism.server.math.AOVector;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.math.Quaternion;
/*      */ import atavism.server.messages.LoginMessage;
/*      */ import atavism.server.messages.LogoutMessage;
/*      */ import atavism.server.messages.PerceptionFilter;
/*      */ import atavism.server.messages.PerceptionMessage;
/*      */ import atavism.server.messages.PerceptionMessage.ObjectNote;
/*      */ import atavism.server.messages.PerceptionTrigger;
/*      */ import atavism.server.messages.PropertyMessage;
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.network.ClientConnection;
/*      */ import atavism.server.network.ClientConnection.AcceptCallback;
/*      */ import atavism.server.network.ClientConnection.MessageCallback;
/*      */ import atavism.server.network.ClientTCPMessageIO;
/*      */ import atavism.server.network.PacketAggregator;
/*      */ import atavism.server.network.rdp.RDPServer;
/*      */ import atavism.server.network.rdp.RDPServerSocket;
/*      */ import atavism.server.objects.Color;
/*      */ import atavism.server.objects.DisplayContext;
/*      */ import atavism.server.objects.FogRegionConfig;
/*      */ import atavism.server.objects.InstanceEntryCallback;
/*      */ import atavism.server.objects.InstanceRestorePoint;
/*      */ import atavism.server.objects.Light;
/*      */ import atavism.server.objects.LightData;
/*      */ import atavism.server.objects.ObjectType;
/*      */ import atavism.server.objects.ObjectTypes;
/*      */ import atavism.server.objects.OceanData;
/*      */ import atavism.server.objects.Player;
/*      */ import atavism.server.objects.PlayerManager;
/*      */ import atavism.server.objects.ProxyExtensionHook;
/*      */ import atavism.server.objects.ProxyLoginCallback;
/*      */ import atavism.server.objects.Template;
/*      */ import atavism.server.objects.TerrainDecalData;
/*      */ import atavism.server.objects.World;
/*      */ import atavism.server.util.AOMeter;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.Base64;
/*      */ import atavism.server.util.CountLogger;
/*      */ import atavism.server.util.CountLogger.Counter;
/*      */ import atavism.server.util.DebugUtils;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.Logger;
/*      */ import atavism.server.util.ObjectLockManager;
/*      */ import atavism.server.util.SQCallback;
/*      */ import atavism.server.util.SQThreadPool;
/*      */ import atavism.server.util.SecureToken;
/*      */ import atavism.server.util.SecureTokenManager;
/*      */ import atavism.server.util.SecureTokenSpec;
/*      */ import atavism.server.util.ServerVersion;
/*      */ import atavism.server.util.SquareQueue;
/*      */ import atavism.server.util.TimeHistogram;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Serializable;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ public class ProxyPlugin extends EnginePlugin
/*      */   implements MessageCallback, ClientConnection.AcceptCallback, ClientConnection.MessageCallback
/*      */ {
/*      */   public static final int PERCEPTION_GAIN_THRESHOLD = 20;
/*      */   Thread periodicGC;
/*  112 */   CountLogger countLogger = new CountLogger("ProxyMsg", 5000, 2);
/*      */   CountLogger.Counter countMsgPerception;
/*      */   CountLogger.Counter countMsgPerceptionGain;
/*      */   CountLogger.Counter countMsgPerceptionLost;
/*      */   CountLogger.Counter countMsgUpdateWNodeIn;
/*      */   CountLogger.Counter countMsgUpdateWNodeOut;
/*      */   CountLogger.Counter countMsgPropertyIn;
/*      */   CountLogger.Counter countMsgPropertyOut;
/*      */   CountLogger.Counter countMsgTargetedProperty;
/*      */   CountLogger.Counter countMsgWNodeCorrectIn;
/*      */   CountLogger.Counter countMsgWNodeCorrectOut;
/*      */   CountLogger.Counter countMsgMobPathIn;
/*      */   CountLogger.Counter countMsgMobPathOut;
/*  681 */   protected Lock commandMapLock = LockFactory.makeLock("CommandMapLock");
/*      */ 
/*  683 */   Map<String, RegisteredCommand> commandMap = new HashMap();
/*      */ 
/*  685 */   CommandAccessCheck defaultCommandAccess = new DefaultCommandAccess(null);
/*      */ 
/*  819 */   private static final Player loginSerializer = new Player(null, null);
/*      */ 
/*  958 */   SquareQueue<Player, Message> messageQQ = new SquareQueue("Message");
/*      */ 
/*  961 */   SQThreadPool messageThreadPool = new SQThreadPool(this.messageQQ, new MessageCallback(this));
/*      */ 
/* 1142 */   SquareQueue<Player, Event> eventQQ = new SquareQueue("Event");
/*      */ 
/* 1144 */   SQThreadPool eventThreadPool = new SQThreadPool(this.eventQQ, new EventCallback());
/*      */ 
/* 1241 */   AOMeter clientMsgMeter = new AOMeter("ClientEventProcessorMeter");
/*      */ 
/* 2356 */   public boolean defaultAllowClientToClientMessage = false;
/*      */ 
/* 2358 */   protected HashMap<String, MessageType> extensionMessageRegistry = new HashMap();
/*      */   protected PerceptionFilter perceptionFilter;
/*      */   protected long perceptionSubId;
/*      */   protected PerceptionFilter responderFilter;
/*      */   protected long responderSubId;
/* 4375 */   protected RDPServerSocket serverSocket = null;
/*      */   protected int clientPort;
/* 4379 */   protected static final Logger log = new Logger("ProxyPlugin");
/*      */ 
/* 4381 */   PlayerMessageCallback playerMessageCallback = new PlayerMessageCallback();
/*      */ 
/* 4383 */   protected PlayerManager playerManager = new PlayerManager();
/*      */ 
/* 4385 */   protected TimeHistogram proxyQueueHistogram = null;
/*      */ 
/* 4387 */   protected TimeHistogram proxyCallbackHistogram = null;
/*      */ 
/* 4389 */   protected List<MessageType> extraPlayerMessageTypes = null;
/*      */ 
/* 4391 */   private ProxyLoginCallback proxyLoginCallback = new DefaultProxyLoginCallback(null);
/*      */ 
/* 4393 */   private InstanceEntryCallback instanceEntryCallback = new DefaultInstanceEntryCallback(null);
/*      */ 
/* 4395 */   private int instanceEntryCount = 0;
/*      */ 
/* 4397 */   private int chatSentCount = 0;
/*      */ 
/* 4399 */   private int privateChatSentCount = 0;
/*      */ 
/* 4401 */   public static final MessageType MSG_TYPE_VOICE_PARMS = MessageType.intern("ao.VOICE_PARMS");
/*      */ 
/* 4404 */   public static final MessageType MSG_TYPE_PLAYER_PATH_REQ = MessageType.intern("ao.PLAYER_PATH_REQ");
/*      */ 
/* 4407 */   public static final MessageType MSG_TYPE_UPDATE_PLAYER_IGNORE_LIST = MessageType.intern("ao.UPDATE_PLAYER_IGNORE_LIST");
/*      */ 
/* 4410 */   public static final MessageType MSG_TYPE_GET_MATCHING_PLAYERS = MessageType.intern("ao.GET_MATCHING_PLAYERS");
/*      */ 
/* 4413 */   public static final MessageType MSG_TYPE_PLAYER_IGNORE_LIST = MessageType.intern("ao.PLAYER_IGNORE_LIST");
/*      */ 
/* 4416 */   public static final MessageType MSG_TYPE_PLAYER_IGNORE_LIST_REQ = MessageType.intern("ao.PLAYER_IGNORE_LIST_REQ");
/*      */ 
/* 4419 */   public static final MessageType MSG_TYPE_RELAY_UPDATE_PLAYER_IGNORE_LIST = MessageType.intern("ao.RELAY_UPDATE_PLAYER_IGNORE_LIST");
/*      */ 
/* 4422 */   public static final MessageType MSG_TYPE_GET_PLAYER_LOGIN_STATUS = MessageType.intern("ao.GET_PLAYER_LOGIN_STATUS");
/*      */ 
/* 4425 */   public static final MessageType MSG_TYPE_LOGOUT_PLAYER = MessageType.intern("ao.LOGOUT_PLAYER");
/*      */ 
/* 4428 */   public static final MessageType MSG_TYPE_ADD_STATIC_PERCEPTION = MessageType.intern("ao.ADD_STATIC_PERCEPTION");
/*      */ 
/* 4431 */   public static final MessageType MSG_TYPE_REMOVE_STATIC_PERCEPTION = MessageType.intern("ao.REMOVE_STATIC_PERCEPTION");
/*      */ 
/* 4434 */   public static final MessageType MSG_TYPE_LOGIN_SPAWNED = MessageType.intern("ao.LOGIN_SPAWNED");
/*      */ 
/* 4437 */   public static final MessageType MSG_TYPE_ACCOUNT_LOGIN = MessageType.intern("ao.ACCOUNT_LOGIN");
/*      */ 
/* 4445 */   protected static String voiceServerHost = "";
/*      */ 
/* 4447 */   protected static Integer voiceServerPort = null;
/*      */ 
/* 4455 */   public String serverCapabilitiesSentToClient = "DirLocOrient";
/*      */ 
/* 4460 */   static int serverSocketReceiveBufferSize = 131072;
/*      */ 
/* 4466 */   public static int MaxConcurrentUsers = 1000;
/*      */ 
/* 4472 */   public static int idleTimeout = 900;
/*      */ 
/* 4478 */   public static int silenceTimeout = 60;
/*      */ 
/* 4484 */   public static int maxMessagesBeforeConnectionReset = 15000;
/*      */ 
/* 4490 */   public static int maxByteCountBeforeConnectionReset = 2000000;
/*      */ 
/* 4495 */   public String capacityError = "Login Failed: Servers at capacity, please try again later.";
/*      */ 
/* 4500 */   public String tokenError = "Login Failed: Secure token invalid.";
/*      */ 
/* 4505 */   private ClientTCPMessageIO clientTCPMessageIO = null;
/*      */ 
/* 4550 */   Set<OID> adminSet = new HashSet();
/*      */ 
/* 4552 */   HashMap<OID, ClientConnection> clientConnections = new HashMap();
/*      */ 
/* 4555 */   Set<String> filteredProps = null;
/*      */ 
/* 4559 */   Set<String> playerSpecificProps = null;
/*      */ 
/* 4563 */   Set<String> cachedPlayerSpecificFilterProps = null;
/*      */ 
/* 4566 */   String serverVersion = null;
/*      */ 
/* 4568 */   protected Map<String, List<ProxyExtensionHook>> extensionHooks = new HashMap();
/*      */ 
/* 4570 */   boolean devMode = true;
/*      */ 
/*      */   public ProxyPlugin()
/*      */   {
/*   70 */     setPluginType("Proxy");
/*      */     String proxyPluginName;
/*      */     try
/*      */     {
/*   73 */       proxyPluginName = Engine.getAgent().getDomainClient().allocName("PLUGIN", new StringBuilder().append(getPluginType()).append("#").toString());
/*      */     }
/*      */     catch (IOException e) {
/*   76 */       throw new AORuntimeException("Could not allocate proxy plugin name", e);
/*      */     }
/*      */ 
/*   80 */     setName(proxyPluginName);
/*      */ 
/*   82 */     this.serverVersion = new StringBuilder().append("2.5.0 ").append(ServerVersion.getBuildNumber()).toString();
/*      */ 
/*   87 */     setMessageHandler(null);
/*   88 */     this.countMsgPerception = this.countLogger.addCounter("ao.PERCEPTION_INFO");
/*   89 */     this.countMsgPerceptionGain = this.countLogger.addCounter("Perception.gain");
/*   90 */     this.countMsgPerceptionLost = this.countLogger.addCounter("Perception.lost");
/*   91 */     this.countMsgUpdateWNodeIn = this.countLogger.addCounter("ao.UPDATEWNODE.in");
/*   92 */     this.countMsgUpdateWNodeOut = this.countLogger.addCounter("ao.UPDATEWNODE.out");
/*   93 */     this.countMsgPropertyIn = this.countLogger.addCounter("ao.PROPERTY.in");
/*   94 */     this.countMsgPropertyOut = this.countLogger.addCounter("ao.PROPERTY.out");
/*   95 */     this.countMsgTargetedProperty = this.countLogger.addCounter("ao.TARGETED_PROPERTY");
/*      */ 
/*   97 */     this.countMsgWNodeCorrectIn = this.countLogger.addCounter("ao.WNODECORRECT.in");
/*   98 */     this.countMsgWNodeCorrectOut = this.countLogger.addCounter("ao.WNODECORRECT.out");
/*   99 */     this.countMsgMobPathIn = this.countLogger.addCounter("ao.MOB_PATH.in");
/*  100 */     this.countMsgMobPathOut = this.countLogger.addCounter("ao.MOB_PATH.out");
/*      */ 
/*  102 */     addProxyExtensionHook("ao.heartbeat", new PlayerHeartbeat(null));
/*      */ 
/*  104 */     new Thread(new PlayerTimeout(null), "PlayerTimeout").start();
/*      */   }
/*      */ 
/*      */   public boolean isDevMode()
/*      */   {
/*  142 */     return this.devMode;
/*      */   }
/*      */ 
/*      */   public void setDevMode(boolean mode)
/*      */   {
/*  150 */     this.devMode = mode;
/*      */   }
/*      */ 
/*      */   public List<MessageType> getExtraPlayerMessageTypes() {
/*  154 */     return this.extraPlayerMessageTypes;
/*      */   }
/*      */ 
/*      */   public void setExtraPlayerMessageTypes(List<MessageType> extraPlayerMessageTypes)
/*      */   {
/*  165 */     this.extraPlayerMessageTypes = extraPlayerMessageTypes;
/*      */   }
/*      */ 
/*      */   public void addExtraPlayerMessageType(MessageType messageType)
/*      */   {
/*  175 */     if (this.extraPlayerMessageTypes == null)
/*  176 */       this.extraPlayerMessageTypes = new LinkedList();
/*  177 */     this.extraPlayerMessageTypes.add(messageType);
/*      */   }
/*      */ 
/*      */   public void addExtraPlayerExtensionMessageType(MessageType messageType)
/*      */   {
/*  187 */     addExtraPlayerMessageType(messageType);
/*  188 */     getHookManager().addHook(messageType, new ExtensionHook());
/*      */   }
/*      */ 
/*      */   public void addProxyExtensionHook(String subType, ProxyExtensionHook hook)
/*      */   {
/*  202 */     synchronized (this.extensionHooks) {
/*  203 */       List hookList = (List)this.extensionHooks.get(subType);
/*  204 */       if (hookList == null) {
/*  205 */         hookList = new ArrayList();
/*  206 */         this.extensionHooks.put(subType, hookList);
/*      */       }
/*  208 */       hookList.add(hook);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, List<ProxyExtensionHook>> getProxyExtensionHooks(String subType)
/*      */   {
/*  214 */     return this.extensionHooks;
/*      */   }
/*      */ 
/*      */   public void onActivate()
/*      */   {
/*      */     try
/*      */     {
/*  239 */       PacketAggregator.initializeAggregation(Engine.getProperties());
/*      */ 
/*  241 */       String logProxyHistograms = Engine.properties.getProperty("atavism.log_proxy_histograms");
/*      */ 
/*  243 */       if ((logProxyHistograms != null) && (logProxyHistograms.equals("true"))) {
/*  244 */         int interval = 5000;
/*  245 */         String intervalString = Engine.properties.getProperty("atavism.log_proxy_histograms_interval");
/*      */ 
/*  247 */         if (intervalString != null) {
/*  248 */           int newInterval = Integer.parseInt(intervalString);
/*  249 */           if (newInterval > 0)
/*  250 */             interval = newInterval;
/*      */         }
/*  252 */         this.proxyQueueHistogram = new TimeHistogram("TimeInQ", Integer.valueOf(interval));
/*  253 */         this.proxyCallbackHistogram = new TimeHistogram("TimeInCallback", Integer.valueOf(interval));
/*      */ 
/*  255 */         this.countLogger.start();
/*      */       }
/*      */ 
/*  259 */       this.filteredProps = new HashSet();
/*  260 */       this.playerSpecificProps = new HashSet();
/*  261 */       this.cachedPlayerSpecificFilterProps = new HashSet();
/*      */ 
/*  263 */       addFilteredProperty("inv.bag");
/*  264 */       addFilteredProperty(":loc");
/*  265 */       addFilteredProperty("masterOid");
/*  266 */       addFilteredProperty("agisobj.basedc");
/*  267 */       addFilteredProperty("aoobj.dc");
/*  268 */       addFilteredProperty("aoobj.followsterrainflag");
/*  269 */       addFilteredProperty("aoobj.perceiver");
/*  270 */       addFilteredProperty("aoobj.scale");
/*  271 */       addFilteredProperty("aoobj.mobflag");
/*  272 */       addFilteredProperty("aoobj.structflag");
/*  273 */       addFilteredProperty("aoobj.userflag");
/*  274 */       addFilteredProperty("aoobj.itemflag");
/*  275 */       addFilteredProperty("aoobj.lightflag");
/*  276 */       addFilteredProperty("namespace");
/*  277 */       addFilteredProperty("regenEffectMap");
/*  278 */       addFilteredProperty(WorldManagerClient.MOB_PATH_PROPERTY);
/*  279 */       addFilteredProperty(WorldManagerClient.TEMPL_SOUND_DATA_LIST);
/*  280 */       addFilteredProperty(WorldManagerClient.TEMPL_TERRAIN_DECAL_DATA);
/*  281 */       addFilteredProperty("instanceStack");
/*  282 */       addFilteredProperty("currentInstanceName");
/*  283 */       addFilteredProperty("ignored_oids");
/*      */ 
/*  286 */       registerHooks();
/*      */ 
/*  290 */       PluginMessageCallback pluginMessageCallback = new PluginMessageCallback();
/*  291 */       MessageTypeFilter filter = new MessageTypeFilter();
/*  292 */       filter.addType(WorldManagerClient.MSG_TYPE_SYS_CHAT);
/*  293 */       Engine.getAgent().createSubscription(filter, pluginMessageCallback);
/*      */ 
/*  297 */       this.perceptionFilter = new PerceptionFilter();
/*  298 */       LinkedList types = new LinkedList();
/*  299 */       types.add(WorldManagerClient.MSG_TYPE_PERCEPTION_INFO);
/*  300 */       types.add(WorldManagerClient.MSG_TYPE_ANIMATION);
/*  301 */       types.add(WorldManagerClient.MSG_TYPE_DISPLAY_CONTEXT);
/*  302 */       types.add(WorldManagerClient.MSG_TYPE_DETACH);
/*  303 */       types.add(PropertyMessage.MSG_TYPE_PROPERTY);
/*  304 */       types.add(WorldManagerClient.MSG_TYPE_COM);
/*  305 */       types.add(CombatClient.MSG_TYPE_DAMAGE);
/*  306 */       types.add(WorldManagerClient.MSG_TYPE_UPDATEWNODE);
/*  307 */       types.add(WorldManagerClient.MSG_TYPE_MOB_PATH);
/*  308 */       types.add(WorldManagerClient.MSG_TYPE_WNODECORRECT);
/*  309 */       types.add(WorldManagerClient.MSG_TYPE_ORIENT);
/*  310 */       types.add(WorldManagerClient.MSG_TYPE_SOUND);
/*  311 */       types.add(AnimationClient.MSG_TYPE_INVOKE_EFFECT);
/*  312 */       types.add(WorldManagerClient.MSG_TYPE_EXTENSION);
/*  313 */       types.add(WorldManagerClient.MSG_TYPE_P2P_EXTENSION);
/*      */ 
/*  316 */       types.add(InventoryClient.MSG_TYPE_INV_UPDATE);
/*      */ 
/*  318 */       types.add(CombatClient.MSG_TYPE_ABILITY_STATUS);
/*  319 */       types.add(CombatClient.MSG_TYPE_ABILITY_UPDATE);
/*  320 */       types.add(WorldManagerClient.MSG_TYPE_FOG);
/*  321 */       types.add(WorldManagerClient.MSG_TYPE_ROAD);
/*  322 */       types.add(WorldManagerClient.MSG_TYPE_NEW_DIRLIGHT);
/*  323 */       types.add(WorldManagerClient.MSG_TYPE_SET_AMBIENT);
/*  324 */       types.add(WorldManagerClient.MSG_TYPE_TARGETED_PROPERTY);
/*  325 */       types.add(WorldManagerClient.MSG_TYPE_FREE_OBJECT);
/*  326 */       types.add(MSG_TYPE_VOICE_PARMS);
/*  327 */       types.add(MSG_TYPE_UPDATE_PLAYER_IGNORE_LIST);
/*  328 */       types.add(MSG_TYPE_GET_MATCHING_PLAYERS);
/*  329 */       types.add(MSG_TYPE_ADD_STATIC_PERCEPTION);
/*  330 */       types.add(MSG_TYPE_REMOVE_STATIC_PERCEPTION);
/*      */ 
/*  332 */       if (this.extraPlayerMessageTypes != null)
/*  333 */         types.addAll(this.extraPlayerMessageTypes);
/*  334 */       this.perceptionFilter.setTypes(types);
/*      */ 
/*  340 */       this.perceptionFilter.setMatchAllSubjects(true);
/*      */ 
/*  342 */       PerceptionTrigger perceptionTrigger = new PerceptionTrigger();
/*  343 */       this.perceptionSubId = Engine.getAgent().createSubscription(this.perceptionFilter, this.playerMessageCallback, 0, perceptionTrigger);
/*      */ 
/*  347 */       this.responderFilter = new PerceptionFilter();
/*  348 */       types.clear();
/*  349 */       types.add(InstanceClient.MSG_TYPE_INSTANCE_ENTRY_REQ);
/*  350 */       types.add(MSG_TYPE_PLAYER_IGNORE_LIST_REQ);
/*  351 */       types.add(MSG_TYPE_GET_PLAYER_LOGIN_STATUS);
/*  352 */       types.add(MSG_TYPE_LOGOUT_PLAYER);
/*  353 */       this.responderFilter.setTypes(types);
/*  354 */       this.responderSubId = Engine.getAgent().createSubscription(this.responderFilter, this.playerMessageCallback, 8);
/*      */ 
/*  358 */       types.clear();
/*  359 */       types.add(Management.MSG_TYPE_GET_PLUGIN_STATUS);
/*  360 */       Engine.getAgent().createSubscription(new MessageTypeFilter(types), pluginMessageCallback, 8);
/*      */ 
/*  363 */       MessageTypeFilter filter3 = new MessageTypeFilter();
/*      */ 
/*  365 */       filter3.addType(MSG_TYPE_ACCOUNT_LOGIN);
/*  366 */       Engine.getAgent().createSubscription(filter3, this);
/*      */ 
/*  371 */       this.serverSocket = new RDPServerSocket();
/*  372 */       String log_rdp_counters = Engine.getProperty("atavism.log_rdp_counters");
/*      */ 
/*  374 */       if ((log_rdp_counters == null) || (log_rdp_counters.equals("false")))
/*  375 */         RDPServer.setCounterLogging(false);
/*  376 */       RDPServer.startRDPServer();
/*  377 */       this.serverSocket.registerAcceptCallback(this);
/*      */ 
/*  379 */       initializeVoiceServerInformation();
/*  380 */       registerExtensionSubtype("voice_parms", MSG_TYPE_VOICE_PARMS);
/*  381 */       registerExtensionSubtype("player_path_req", MSG_TYPE_PLAYER_PATH_REQ);
/*      */ 
/*  383 */       registerExtensionSubtype("player_path_req", MSG_TYPE_PLAYER_PATH_REQ);
/*      */ 
/*  385 */       registerExtensionSubtype("ao.UPDATE_PLAYER_IGNORE_LIST", MSG_TYPE_UPDATE_PLAYER_IGNORE_LIST);
/*      */ 
/*  387 */       registerExtensionSubtype("ao.GET_MATCHING_PLAYERS", MSG_TYPE_GET_MATCHING_PLAYERS);
/*      */ 
/*  389 */       registerExtensionSubtype("ao.PLAYER_IGNORE_LIST_REQ", MSG_TYPE_PLAYER_IGNORE_LIST_REQ);
/*      */ 
/*  392 */       InetSocketAddress bindAddress = getBindAddress();
/*  393 */       if (Log.loggingDebug) {
/*  394 */         Log.debug(new StringBuilder().append("BIND: binding for client tcp and rdp packets on port ").append(bindAddress.getPort()).append(" with rdpsocket: ").append(this.serverSocket.toString()).toString());
/*      */       }
/*      */ 
/*  398 */       this.serverSocket.bind(Integer.valueOf(Integer.parseInt(Engine.getProperty("atavism.proxy.bindport"))), serverSocketReceiveBufferSize);
/*  399 */       Log.debug("BIND: bound server socket");
/*  400 */       this.clientTCPMessageIO = ClientTCPMessageIO.setup(bindAddress, this, this);
/*  401 */       Log.debug("BIND: setup clientTCPMessage");
/*  402 */       this.clientTCPMessageIO.start("ClientIO");
/*  403 */       Log.debug("BIND: started clientTCPMessage");
/*      */ 
/*  406 */       InetSocketAddress externalAddress = getExternalAddress(bindAddress);
/*  407 */       Log.debug("BIND: got external address");
/*  408 */       setPluginInfo(new StringBuilder().append("host=").append(externalAddress.getHostName()).append(",port=").append(externalAddress.getPort()).toString());
/*  409 */       Log.debug("Registering proxy plugin");
/*  410 */       Engine.registerStatusReportingPlugin(this);
/*  411 */       Log.debug("Proxy: activation done");
/*      */     } catch (Exception e) {
/*  413 */       throw new AORuntimeException("activate failed", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private InetSocketAddress getBindAddress() throws IOException
/*      */   {
/*  419 */     String propStr = Engine.getProperty("atavism.proxy.bindport");
/*      */     int port;
/*      */     int port;
/*  421 */     if (propStr != null) {
/*  422 */       port = Integer.parseInt(propStr.trim());
/*      */     }
/*      */     else {
/*  425 */       port = Integer.parseInt(Engine.getProperty("atavism.proxyport").trim());
/*      */     }
/*      */ 
/*  429 */     propStr = Engine.getProperty("atavism.proxy.bindaddress");
/*  430 */     InetAddress address = null;
/*  431 */     if (propStr != null) {
/*  432 */       address = InetAddress.getByName(propStr.trim());
/*      */     }
/*  434 */     return new InetSocketAddress(address, port);
/*      */   }
/*      */ 
/*      */   private InetSocketAddress getExternalAddress(InetSocketAddress bindAddress) throws IOException
/*      */   {
/*  439 */     String propStr = Engine.getProperty("atavism.proxy.externalport");
/*      */     int port;
/*      */     int port;
/*  441 */     if (propStr != null)
/*  442 */       port = Integer.parseInt(propStr.trim());
/*      */     else {
/*  444 */       port = bindAddress.getPort();
/*      */     }
/*      */ 
/*  448 */     propStr = Engine.getProperty("atavism.proxy.externaladdress");
/*      */     InetAddress address;
/*      */     InetAddress address;
/*  450 */     if (propStr != null) {
/*  451 */       address = InetAddress.getByName(propStr.trim());
/*      */     } else {
/*  453 */       address = bindAddress.getAddress();
/*  454 */       if (address.isAnyLocalAddress())
/*      */       {
/*  456 */         address = InetAddress.getLocalHost();
/*      */       }
/*      */     }
/*  459 */     return new InetSocketAddress(address, port);
/*      */   }
/*      */ 
/*      */   public Map<String, String> getStatusMap() {
/*  463 */     Map status = new HashMap();
/*  464 */     status.put("players", Integer.toString(this.playerManager.getPlayerCount()));
/*  465 */     return status;
/*      */   }
/*      */ 
/*      */   public void registerCommand(String command, CommandParser parser)
/*      */   {
/*  618 */     this.commandMapLock.lock();
/*      */     try {
/*  620 */       this.commandMap.put(command, new RegisteredCommand(parser, this.defaultCommandAccess));
/*      */     }
/*      */     finally {
/*  623 */       this.commandMapLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerCommand(String command, CommandParser parser, CommandAccessCheck access)
/*      */   {
/*  639 */     this.commandMapLock.lock();
/*      */     try {
/*  641 */       this.commandMap.put(command, new RegisteredCommand(parser, access));
/*      */     } finally {
/*  643 */       this.commandMapLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   void registerHooks()
/*      */   {
/*  698 */     log.debug("registering hooks");
/*      */ 
/*  700 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_DISPLAY_CONTEXT, new DisplayContextHook());
/*      */ 
/*  703 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_DETACH, new DetachHook());
/*      */ 
/*  706 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_ANIMATION, new AnimationHook());
/*      */ 
/*  709 */     getHookManager().addHook(AnimationClient.MSG_TYPE_INVOKE_EFFECT, new InvokeEffectHook());
/*      */ 
/*  712 */     getHookManager().addHook(PropertyMessage.MSG_TYPE_PROPERTY, new PropertyHook());
/*      */ 
/*  715 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_EXTENSION, new ExtensionHook());
/*      */ 
/*  718 */     getHookManager().addHook(CombatClient.MSG_TYPE_ABILITY_STATUS, new AbilityStatusHook());
/*      */ 
/*  721 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_TARGETED_PROPERTY, new TargetedPropertyHook());
/*      */ 
/*  724 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_PERCEPTION_INFO, new PerceptionHook());
/*      */ 
/*  727 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_COM, new ComHook());
/*      */ 
/*  730 */     getHookManager().addHook(CombatClient.MSG_TYPE_DAMAGE, new DamageHook());
/*      */ 
/*  733 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_SYS_CHAT, new SysChatHook());
/*      */ 
/*  736 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_UPDATEWNODE, new UpdateWNodeHook());
/*      */ 
/*  739 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_MOB_PATH, new UpdateMobPathHook());
/*      */ 
/*  742 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_WNODECORRECT, new WNodeCorrectHook());
/*      */ 
/*  745 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_ORIENT, new OrientHook());
/*      */ 
/*  748 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_SOUND, new SoundHook());
/*      */ 
/*  751 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_FOG, new FogHook());
/*      */ 
/*  754 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_ROAD, new RoadHook());
/*      */ 
/*  757 */     getHookManager().addHook(InventoryClient.MSG_TYPE_INV_UPDATE, new InvUpdateHook());
/*      */ 
/*  760 */     getHookManager().addHook(CombatClient.MSG_TYPE_ABILITY_UPDATE, new AbilityUpdateHook());
/*      */ 
/*  763 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_NEW_DIRLIGHT, new NewDirLightHook());
/*      */ 
/*  766 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_FREE_OBJECT, new FreeObjectHook());
/*      */ 
/*  769 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_SET_AMBIENT, new SetAmbientHook());
/*      */ 
/*  772 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_P2P_EXTENSION, new P2PExtensionHook());
/*      */ 
/*  774 */     getHookManager().addHook(MSG_TYPE_VOICE_PARMS, new VoiceParmsHook());
/*  775 */     getHookManager().addHook(MSG_TYPE_PLAYER_PATH_REQ, new PlayerPathReqHook());
/*      */ 
/*  777 */     getHookManager().addHook(InstanceClient.MSG_TYPE_INSTANCE_ENTRY_REQ, new InstanceEntryReqHook());
/*      */ 
/*  779 */     getHookManager().addHook(Management.MSG_TYPE_GET_PLUGIN_STATUS, new GetPluginStatusHook());
/*      */ 
/*  782 */     getHookManager().addHook(MSG_TYPE_UPDATE_PLAYER_IGNORE_LIST, new UpdatePlayerIgnoreListHook());
/*      */ 
/*  784 */     getHookManager().addHook(MSG_TYPE_GET_MATCHING_PLAYERS, new GetMatchingPlayersHook());
/*      */ 
/*  786 */     getHookManager().addHook(MSG_TYPE_PLAYER_IGNORE_LIST_REQ, new PlayerIgnoreListReqHook());
/*      */ 
/*  788 */     getHookManager().addHook(MSG_TYPE_GET_PLAYER_LOGIN_STATUS, new GetPlayerLoginStatusHook(null));
/*      */ 
/*  790 */     getHookManager().addHook(MSG_TYPE_LOGOUT_PLAYER, new LogoutPlayerHook(null));
/*      */ 
/*  792 */     getHookManager().addHook(MSG_TYPE_ADD_STATIC_PERCEPTION, new AddStaticPerceptionHook(null));
/*      */ 
/*  794 */     getHookManager().addHook(MSG_TYPE_REMOVE_STATIC_PERCEPTION, new RemoveStaticPerceptionHook(null));
/*      */ 
/*  796 */     getHookManager().addHook(MSG_TYPE_ACCOUNT_LOGIN, new AccountLoginHook(null));
/*      */   }
/*      */ 
/*      */   void callEngineOnMessage(Message message, int flags)
/*      */   {
/*  822 */     super.handleMessage(message, flags);
/*      */   }
/*      */ 
/*      */   protected void initializeVoiceServerInformation()
/*      */   {
/*  828 */     voiceServerHost = Engine.properties.getProperty("atavism.voiceserver");
/*      */ 
/*  830 */     String s = Engine.properties.getProperty("atavism.voiceport");
/*  831 */     if (s != null) {
/*  832 */       voiceServerPort = Integer.valueOf(Integer.parseInt(s));
/*      */     }
/*  834 */     if (Log.loggingDebug)
/*  835 */       log.debug(new StringBuilder().append("initializeVoiceServerInformation: voiceServerHost ").append(voiceServerHost).append(", voiceServerPort ").append(voiceServerPort).toString());
/*      */   }
/*      */ 
/*      */   public void acceptConnection(ClientConnection con)
/*      */   {
/*  972 */     Log.info(new StringBuilder().append("ProxyPlugin: CONNECTION remote=").append(con).toString());
/*  973 */     con.registerMessageCallback(this);
/*      */   }
/*      */ 
/*      */   public void processPacket(ClientConnection con, AOByteBuffer buf)
/*      */   {
/*      */     try
/*      */     {
/*  986 */       if (Log.loggingNet) {
/*  987 */         if (ClientConnection.getLogMessageContents()) {
/*  988 */           Log.net(new StringBuilder().append("ProxyPlugin.processPacket: con ").append(con).append(", length ").append(buf.limit()).append(", packet ").append(DebugUtils.byteArrayToHexString(buf)).toString());
/*      */         }
/*      */         else
/*      */         {
/*  992 */           Log.net(new StringBuilder().append("ProxyPlugin.processPacket: con ").append(con).append(", buf ").append(buf).toString());
/*      */         }
/*      */       }
/*      */ 
/*  996 */       Event event = Engine.getEventServer().parseBytes(buf, con);
/*  997 */       if (event == null) {
/*  998 */         Log.error(new StringBuilder().append("Engine: could not parse packet data, remote=").append(con).toString());
/*  999 */         return;
/*      */       }
/*      */ 
/* 1002 */       Player player = (Player)con.getAssociation();
/* 1003 */       if (player == null) {
/* 1004 */         player = loginSerializer;
/* 1005 */         if ((event instanceof AuthorizedLoginEvent)) {
/* 1006 */           Log.info(new StringBuilder().append("ProxyPlugin: LOGIN_RECV remote=").append(con).append(" playerOid=").append(((AuthorizedLoginEvent)event).getOid()).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1011 */       this.playerManager.processEvent(player, event, this.eventQQ);
/*      */     }
/*      */     catch (AORuntimeException e) {
/* 1014 */       Log.exception("ProxyPlugin.processPacket caught exception", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Set<OID> getPlayerOids()
/*      */   {
/* 1153 */     List players = new ArrayList(this.playerManager.getPlayerCount());
/*      */ 
/* 1155 */     this.playerManager.getPlayers(players);
/* 1156 */     Set result = new HashSet(players.size());
/* 1157 */     for (Player player : players) {
/* 1158 */       result.add(player.getOid());
/*      */     }
/* 1160 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> getPlayerNames()
/*      */   {
/* 1169 */     List players = new ArrayList(this.playerManager.getPlayerCount());
/*      */ 
/* 1171 */     Log.debug(new StringBuilder().append("ProxyPlugin.getPlayerNames: count is ").append(this.playerManager.getPlayerCount()).toString());
/*      */ 
/* 1173 */     this.playerManager.getPlayers(players);
/* 1174 */     List result = new ArrayList(players.size());
/* 1175 */     for (Player player : players) {
/* 1176 */       result.add(player.getName());
/*      */     }
/* 1178 */     return result;
/*      */   }
/*      */ 
/*      */   public List<Player> getPlayers()
/*      */   {
/* 1186 */     List players = new ArrayList(this.playerManager.getPlayerCount());
/*      */ 
/* 1188 */     this.playerManager.getPlayers(players);
/* 1189 */     return players;
/*      */   }
/*      */ 
/*      */   public Player getPlayer(OID oid)
/*      */   {
/* 1199 */     return this.playerManager.getPlayer(oid);
/*      */   }
/*      */ 
/*      */   public void addPlayerMessage(Message message, Player player)
/*      */   {
/* 1206 */     message.setEnqueueTime();
/* 1207 */     this.messageQQ.insert(player, message);
/*      */   }
/*      */ 
/*      */   public void addFilteredProperty(String filteredProperty)
/*      */   {
/* 1218 */     this.filteredProps.add(filteredProperty);
/* 1219 */     this.cachedPlayerSpecificFilterProps.add(filteredProperty);
/*      */   }
/*      */ 
/*      */   public void addPlayerSpecificProperty(String filteredProperty)
/*      */   {
/* 1231 */     this.playerSpecificProps.add(filteredProperty);
/* 1232 */     this.cachedPlayerSpecificFilterProps.add(filteredProperty);
/*      */   }
/*      */ 
/*      */   protected void recreatePlayerSpecificCache() {
/* 1236 */     this.cachedPlayerSpecificFilterProps = new HashSet();
/* 1237 */     this.cachedPlayerSpecificFilterProps.addAll(this.filteredProps);
/* 1238 */     this.cachedPlayerSpecificFilterProps.addAll(this.playerSpecificProps);
/*      */   }
/*      */ 
/*      */   protected boolean processLogin(ClientConnection con, AuthorizedLoginEvent loginEvent)
/*      */   {
/* 1257 */     OID playerOid = loginEvent.getOid();
/*      */ 
/* 1259 */     String version = loginEvent.getVersion();
/* 1260 */     int nPlayers = this.playerManager.getPlayerCount();
/*      */ 
/* 1262 */     String[] clientVersionCapabilities = null;
/* 1263 */     if ((version != null) && (version.length() > 0)) {
/* 1264 */       clientVersionCapabilities = version.split(",");
/*      */     }
/* 1266 */     LinkedList clientCapabilities = new LinkedList();
/* 1267 */     String clientVersion = "";
/* 1268 */     if ((clientVersionCapabilities != null) && (clientVersionCapabilities.length > 0))
/*      */     {
/* 1270 */       clientVersion = clientVersionCapabilities[0];
/* 1271 */       for (int i = 1; i < clientVersionCapabilities.length; i++) {
/* 1272 */         clientCapabilities.add(clientVersionCapabilities[i].trim());
/*      */       }
/*      */     }
/*      */ 
/* 1276 */     int versionCompare = ServerVersion.compareVersionStrings(clientVersion, "2.5.0");
/*      */ 
/* 1278 */     if ((versionCompare != 1) && (versionCompare != 0))
/*      */     {
/* 1280 */       Log.warn(new StringBuilder().append("processLogin: unsupported version ").append(clientVersion).append(" from player: ").append(playerOid).toString());
/*      */ 
/* 1282 */       AuthorizedLoginResponseEvent loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, "Login Failed: Unsupported client version", this.serverVersion);
/*      */ 
/* 1285 */       con.send(loginResponse.toBytes());
/* 1286 */       return false;
/*      */     }
/*      */ 
/* 1290 */     if (!isAdmin(playerOid)) {
/* 1291 */       Log.debug("processLogin: player is not admin");
/* 1292 */       if (nPlayers >= MaxConcurrentUsers) {
/* 1293 */         Log.warn(new StringBuilder().append("processLogin: too many users, failed for player: ").append(playerOid).toString());
/*      */ 
/* 1295 */         Event loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, this.capacityError, this.serverVersion);
/*      */ 
/* 1297 */         con.send(loginResponse.toBytes());
/* 1298 */         return false;
/*      */       }
/*      */     } else {
/* 1301 */       Log.debug("processLogin: player is admin, bypassing max check");
/*      */     }
/*      */ 
/* 1307 */     SecureToken token = SecureTokenManager.getInstance().importToken(loginEvent.getWorldToken());
/*      */ 
/* 1309 */     boolean validToken = true;
/* 1310 */     if (!token.getValid()) {
/* 1311 */       Log.debug("token is not valid");
/* 1312 */       validToken = false;
/*      */     }
/* 1314 */     OID characterOid = (OID)token.getProperty("character_oid");
/* 1315 */     Log.debug(new StringBuilder().append("PlayerOID: ").append(playerOid).toString());
/* 1316 */     Log.debug(new StringBuilder().append("CharacterOID: ").append(characterOid).toString());
/* 1317 */     if (!playerOid.equals(characterOid)) {
/* 1318 */       Log.debug("playerOid does not match character_oid");
/* 1319 */       validToken = false;
/*      */     }
/* 1321 */     if (!token.getProperty("proxy_server").equals(Engine.getAgent().getName()))
/*      */     {
/* 1323 */       Log.debug("proxy_server does not match engine agent name");
/* 1324 */       validToken = false;
/*      */     }
/* 1326 */     if (!validToken) {
/* 1327 */       Log.error("processLogin: invalid proxy token");
/* 1328 */       Event loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, this.tokenError, this.serverVersion);
/*      */ 
/* 1330 */       con.send(loginResponse.toBytes());
/* 1331 */       return false;
/*      */     }
/*      */     try
/*      */     {
/* 1335 */       TargetMessage getPlayerLoginStatus = new TargetMessage(MSG_TYPE_GET_PLAYER_LOGIN_STATUS, playerOid);
/*      */ 
/* 1338 */       PlayerLoginStatus loginStatus = (PlayerLoginStatus)Engine.getAgent().sendRPCReturnObject(getPlayerLoginStatus);
/*      */ 
/* 1340 */       if (this.proxyLoginCallback.duplicateLogin(loginStatus, con)) {
/* 1341 */         if (loginStatus != null) {
/* 1342 */           Log.info(new StringBuilder().append("processLogin: LOGIN_DUPLICATE remote=").append(con).append(" playerOid=").append(playerOid).append(" name=").append(loginStatus.name).append(" existingCon=").append(loginStatus.clientCon).append(" existingProxy=").append(loginStatus.proxyPluginName).toString());
/*      */         }
/*      */         else
/*      */         {
/* 1348 */           Log.info(new StringBuilder().append("processLogin: LOGIN_DUPLICATE remote=").append(con).append(" playerOid=").append(playerOid).append(" loginStatus is null").toString());
/*      */         }
/*      */ 
/* 1352 */         AuthorizedLoginResponseEvent loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, "Login Failed: Already connected", this.serverVersion);
/*      */ 
/* 1355 */         con.send(loginResponse.toBytes());
/* 1356 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (NoRecipientsException e)
/*      */     {
/*      */     }
/*      */ 
/* 1374 */     Player player = new Player(playerOid, con);
/* 1375 */     player.setStatus(1);
/* 1376 */     if (!this.playerManager.addPlayer(player))
/*      */     {
/* 1378 */       player = this.playerManager.getPlayer(playerOid);
/* 1379 */       Log.info(new StringBuilder().append("processLogin: LOGIN_DUPLICATE remote=").append(con).append(" playerOid=").append(playerOid).append(" existing=").append(player.getConnection()).toString());
/*      */ 
/* 1382 */       AuthorizedLoginResponseEvent loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, "Login Failed: Already connected", this.serverVersion);
/*      */ 
/* 1385 */       con.send(loginResponse.toBytes());
/* 1386 */       return false;
/*      */     }
/* 1388 */     con.setAssociation(player);
/*      */ 
/* 1390 */     player.setVersion(clientVersion);
/* 1391 */     player.setCapabilities(clientCapabilities);
/*      */ 
/* 1393 */     String errorMessage = this.proxyLoginCallback.preLoad(player, con);
/* 1394 */     if (errorMessage != null) {
/* 1395 */       this.playerManager.removePlayer(playerOid);
/* 1396 */       Event loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, errorMessage, this.serverVersion);
/*      */ 
/* 1398 */       con.send(loginResponse.toBytes());
/* 1399 */       return false;
/*      */     }
/*      */ 
/* 1405 */     if (Log.loggingDebug) {
/* 1406 */       Log.debug(new StringBuilder().append("processLogin: loading object: ").append(playerOid).append(", con=").append(con).toString());
/*      */     }
/*      */ 
/* 1409 */     if (!loadPlayerObject(player)) {
/* 1410 */       Log.error(new StringBuilder().append("processLogin: could not load object ").append(playerOid).toString());
/* 1411 */       this.playerManager.removePlayer(playerOid);
/* 1412 */       Event loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, "Login Failed", this.serverVersion);
/*      */ 
/* 1414 */       con.send(loginResponse.toBytes());
/* 1415 */       return false;
/*      */     }
/* 1417 */     if (Log.loggingDebug) {
/* 1418 */       Log.debug(new StringBuilder().append("processLogin: loaded player object: ").append(playerOid).toString());
/*      */     }
/*      */ 
/* 1421 */     errorMessage = this.proxyLoginCallback.postLoad(player, con);
/* 1422 */     if (errorMessage != null) {
/* 1423 */       this.playerManager.removePlayer(playerOid);
/* 1424 */       Event loginResponse = new AuthorizedLoginResponseEvent(playerOid, false, errorMessage, this.serverVersion);
/*      */ 
/* 1426 */       con.send(loginResponse.toBytes());
/* 1427 */       return false;
/*      */     }
/*      */ 
/* 1433 */     AuthorizedLoginResponseEvent loginResponse = new AuthorizedLoginResponseEvent(playerOid, true, "Login Succeeded", new StringBuilder().append(this.serverVersion).append(", ").append(this.serverCapabilitiesSentToClient).toString());
/*      */ 
/* 1436 */     con.send(loginResponse.toBytes());
/* 1437 */     if (Log.loggingDebug) {
/* 1438 */       Log.debug(new StringBuilder().append("Login response sent for playerOid=").append(playerOid).append(" the authorized login response message is : ").append(loginResponse.getMessage()).toString());
/*      */     }
/*      */ 
/* 1445 */     this.playerManager.addStaticPerception(player, playerOid);
/*      */ 
/* 1447 */     boolean loginOK = processLoginHelper(con, player);
/* 1448 */     if (!loginOK)
/*      */     {
/* 1454 */       con.setAssociation(null);
/* 1455 */       if (this.perceptionFilter.removeTarget(playerOid)) {
/* 1456 */         FilterUpdate filterUpdate = new FilterUpdate(1);
/* 1457 */         filterUpdate.removeFieldValue(1, playerOid);
/* 1458 */         Engine.getAgent().applyFilterUpdate(this.perceptionSubId, filterUpdate);
/*      */ 
/* 1460 */         this.responderFilter.removeTarget(playerOid);
/* 1461 */         Engine.getAgent().applyFilterUpdate(this.responderSubId, filterUpdate);
/*      */       }
/*      */ 
/* 1464 */       this.playerManager.removeStaticPerception(player, playerOid);
/* 1465 */       this.playerManager.removePlayer(playerOid);
/* 1466 */       con.close();
/*      */     } else {
/* 1468 */       this.proxyLoginCallback.postSpawn(player, con);
/*      */ 
/* 1470 */       this.playerManager.loginComplete(player, this.eventQQ);
/*      */ 
/* 1472 */       SubjectMessage loginSpawned = new SubjectMessage(MSG_TYPE_LOGIN_SPAWNED);
/*      */ 
/* 1474 */       loginSpawned.setSubject(playerOid);
/* 1475 */       Engine.getAgent().sendBroadcast(loginSpawned);
/*      */ 
/* 1482 */       processPlayerIgnoreList(player);
/*      */ 
/* 1486 */       OID accountID = (OID)EnginePlugin.getObjectProperty(playerOid, WorldManagerClient.NAMESPACE, "accountId");
/*      */ 
/* 1498 */       this.clientConnections.put(accountID, con);
/*      */     }
/* 1500 */     return loginOK;
/*      */   }
/*      */ 
/*      */   protected boolean loadPlayerObject(Player player)
/*      */   {
/* 1510 */     InstanceRestorePoint restorePoint = null;
/* 1511 */     LinkedList restoreStack = null;
/* 1512 */     boolean first = true;
/* 1513 */     OID playerOid = player.getOid();
/*      */ 
/* 1516 */     List namespaces = new ArrayList();
/* 1517 */     OID oidResult = ObjectManagerClient.loadSubObject(playerOid, namespaces);
/*      */ 
/* 1519 */     if (oidResult == null) {
/* 1520 */       return false;
/*      */     }
/*      */ 
/* 1523 */     Point location = new Point();
/* 1524 */     OID instanceOid = Engine.getDatabase().getLocation(playerOid, WorldManagerClient.NAMESPACE, location);
/*      */     while (true)
/*      */     {
/* 1528 */       OID result = null;
/*      */ 
/* 1530 */       if (instanceEntryAllowed(playerOid, instanceOid, location))
/*      */       {
/* 1532 */         InstanceClient.InstanceInfo instanceInfo = InstanceClient.getInstanceInfo(instanceOid, -8193);
/* 1533 */         if ((instanceInfo.populationLimit < 1) || (instanceInfo.playerPopulation < instanceInfo.populationLimit)) {
/* 1534 */           result = ObjectManagerClient.loadObject(playerOid);
/* 1535 */           Log.debug(new StringBuilder().append("POP: loading player into instance: ").append(instanceOid).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1540 */       if ((restoreStack != null) && (!restorePoint.getFallbackFlag())) {
/* 1541 */         EnginePlugin.setObjectProperty(playerOid, Namespace.OBJECT_MANAGER, "instanceStack", restoreStack);
/*      */       }
/*      */ 
/* 1547 */       if (result != null) {
/* 1548 */         if (restorePoint == null) break;
/* 1549 */         EnginePlugin.setObjectProperty(playerOid, Namespace.OBJECT_MANAGER, "currentInstanceName", restorePoint.getInstanceName()); break;
/*      */       }
/*      */ 
/* 1557 */       if (first)
/*      */       {
/* 1559 */         String instanceName = (String)EnginePlugin.getObjectProperty(playerOid, Namespace.OBJECT_MANAGER, "currentInstanceName");
/*      */ 
/* 1562 */         Log.debug(new StringBuilder().append("Failed initial load, retrying with current instanceName=").append(instanceName).toString());
/*      */ 
/* 1564 */         if (instanceName != null) {
/* 1565 */           instanceOid = this.instanceEntryCallback.selectInstance(player, instanceName);
/*      */ 
/* 1568 */           if (instanceOid != null)
/*      */           {
/* 1570 */             InstanceClient.InstanceInfo instanceInfo = InstanceClient.getInstanceInfo(instanceOid, -8193);
/* 1571 */             if ((instanceInfo.populationLimit > 0) && (instanceInfo.playerPopulation >= instanceInfo.populationLimit)) {
/* 1572 */               Log.debug(new StringBuilder().append("POP: got population: ").append(instanceInfo.playerPopulation).append(" and limit: ").append(instanceInfo.populationLimit).toString());
/* 1573 */               instanceOid = handleFullInstance(instanceInfo.templateName, instanceInfo);
/* 1574 */               instanceInfo = InstanceClient.getInstanceInfo(instanceOid, -8193);
/*      */             }
/* 1576 */             Log.debug(new StringBuilder().append("Failed initial load, retrying with instanceOid=").append(instanceOid).append(" and instanceName: ").append(instanceInfo.name).toString());
/*      */ 
/* 1578 */             BasicWorldNode wnode = new BasicWorldNode();
/* 1579 */             wnode.setInstanceOid(instanceOid);
/* 1580 */             ObjectManagerClient.fixWorldNode(playerOid, wnode);
/* 1581 */             first = false;
/* 1582 */             continue;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1589 */       if ((restorePoint != null) && (restorePoint.getFallbackFlag())) {
/* 1590 */         return false;
/*      */       }
/*      */ 
/* 1594 */       restoreStack = (LinkedList)EnginePlugin.getObjectProperty(playerOid, Namespace.OBJECT_MANAGER, "instanceStack");
/*      */ 
/* 1598 */       if ((restoreStack == null) || (restoreStack.size() == 0)) {
/* 1599 */         return false;
/*      */       }
/*      */ 
/* 1604 */       int size = restoreStack.size();
/* 1605 */       restorePoint = (InstanceRestorePoint)restoreStack.get(size - 1);
/*      */ 
/* 1607 */       instanceOid = restorePoint.getInstanceOid();
/* 1608 */       if (restorePoint.getInstanceName() != null) {
/* 1609 */         instanceOid = this.instanceEntryCallback.selectInstance(player, restorePoint.getInstanceName());
/*      */       }
/*      */ 
/* 1613 */       if (instanceOid != null) {
/* 1614 */         BasicWorldNode wnode = new BasicWorldNode();
/* 1615 */         wnode.setInstanceOid(instanceOid);
/* 1616 */         if (!first) {
/* 1617 */           wnode.setLoc(restorePoint.getLoc());
/* 1618 */           wnode.setOrientation(restorePoint.getOrientation());
/* 1619 */           wnode.setDir(new AOVector(0.0F, 0.0F, 0.0F));
/*      */         }
/* 1621 */         boolean rc = ObjectManagerClient.fixWorldNode(playerOid, wnode);
/* 1622 */         if (!rc) {
/* 1623 */           return false;
/*      */         }
/* 1625 */         location = restorePoint.getLoc();
/*      */       }
/* 1627 */       first = false;
/*      */ 
/* 1629 */       if (!restorePoint.getFallbackFlag()) {
/* 1630 */         restoreStack.remove(size - 1);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1635 */     return true;
/*      */   }
/*      */ 
/*      */   protected boolean processLoginHelper(ClientConnection con, Player player)
/*      */   {
/* 1649 */     OID playerOid = player.getOid();
/*      */ 
/* 1652 */     WorldManagerClient.ObjectInfo objInfo = WorldManagerClient.getObjectInfo(playerOid);
/*      */ 
/* 1654 */     if (objInfo == null) {
/* 1655 */       Log.error(new StringBuilder().append("processLogin: Could not get player ObjectInfo oid=").append(playerOid).toString());
/*      */ 
/* 1657 */       return false;
/*      */     }
/*      */ 
/* 1660 */     if (World.FollowsTerrainOverride != null) {
/* 1661 */       Log.debug("using follows terrain override");
/* 1662 */       objInfo.followsTerrain = World.FollowsTerrainOverride.booleanValue();
/*      */     }
/* 1664 */     if (Log.loggingDebug) {
/* 1665 */       Log.debug(new StringBuilder().append("processLogin: got object info: ").append(objInfo).toString());
/*      */     }
/* 1667 */     player.setName(objInfo.name);
/*      */ 
/* 1669 */     InstanceClient.InstanceInfo instanceInfo = InstanceClient.getInstanceInfo(objInfo.instanceOid, -8193);
/*      */ 
/* 1672 */     if (instanceInfo == null) {
/* 1673 */       Log.error(new StringBuilder().append("processLogin: unknown instanceOid=").append(objInfo.instanceOid).toString());
/*      */ 
/* 1675 */       return false;
/*      */     }
/*      */ 
/* 1682 */     LoginMessage loginMessage = new LoginMessage(playerOid, objInfo.name);
/* 1683 */     loginMessage.setInstanceOid(objInfo.instanceOid);
/* 1684 */     AsyncRPCCallback asyncRPCCallback = new AsyncRPCCallback(player, "processLogin: got LoginMessage response");
/*      */ 
/* 1686 */     int expectedResponses = Engine.getAgent().sendBroadcastRPC(loginMessage, asyncRPCCallback);
/*      */ 
/* 1688 */     asyncRPCCallback.waitForResponses(expectedResponses);
/*      */ 
/* 1699 */     Log.debug(new StringBuilder().append("processLogin: sending template (scene) name: ").append(instanceInfo.templateName).toString());
/*      */ 
/* 1702 */     Event worldFileEvent = new WorldFileEvent(instanceInfo.templateName);
/* 1703 */     con.send(worldFileEvent.toBytes());
/*      */ 
/* 1706 */     Log.debug("INFO: process login helper");
/* 1707 */     con.send(objInfo.toBuffer(playerOid));
/*      */ 
/* 1710 */     DisplayContext dc = WorldManagerClient.getDisplayContext(playerOid);
/* 1711 */     ModelInfoEvent modelInfoEvent = new ModelInfoEvent(playerOid);
/* 1712 */     modelInfoEvent.setDisplayContext(dc);
/* 1713 */     if (Log.loggingDebug) {
/* 1714 */       Log.debug(new StringBuilder().append("processLogin: got dc: ").append(dc).toString());
/*      */     }
/* 1716 */     con.send(modelInfoEvent.toBytes());
/*      */ 
/* 1719 */     Map childMap = dc.getChildDCMap();
/* 1720 */     if ((childMap != null) && (!childMap.isEmpty())) {
/* 1721 */       for (String slot : childMap.keySet()) {
/* 1722 */         DisplayContext attachDC = (DisplayContext)childMap.get(slot);
/* 1723 */         if (attachDC == null) {
/* 1724 */           throw new AORuntimeException(new StringBuilder().append("attach DC is null for obj: ").append(playerOid).toString());
/*      */         }
/*      */ 
/* 1727 */         OID attacheeOID = attachDC.getObjRef();
/* 1728 */         if (attacheeOID == null) {
/* 1729 */           throw new AORuntimeException(new StringBuilder().append("attachee oid is null for obj: ").append(playerOid).toString());
/*      */         }
/*      */ 
/* 1733 */         if (Log.loggingDebug) {
/* 1734 */           Log.debug(new StringBuilder().append("processLogin: sending attach message to ").append(playerOid).append(" attaching to obj ").append(playerOid).append(", object being attached=").append(attacheeOID).append(" to slot ").append(slot).append(", attachmentDC=").append(attachDC).toString());
/*      */         }
/*      */ 
/* 1740 */         AttachEvent event = new AttachEvent(playerOid, attacheeOID, slot, attachDC);
/*      */ 
/* 1742 */         con.send(event.toBytes());
/*      */       }
/* 1744 */       Log.debug("processLogin: done with processing attachments");
/*      */     }
/*      */ 
/* 1749 */     if (this.perceptionFilter.addTarget(playerOid)) {
/* 1750 */       FilterUpdate filterUpdate = new FilterUpdate(1);
/* 1751 */       filterUpdate.addFieldValue(1, playerOid);
/* 1752 */       Engine.getAgent().applyFilterUpdate(this.perceptionSubId, filterUpdate);
/* 1753 */       this.responderFilter.addTarget(playerOid);
/* 1754 */       Engine.getAgent().applyFilterUpdate(this.responderSubId, filterUpdate);
/*      */     }
/*      */ 
/* 1759 */     WorldManagerClient.updateObject(playerOid, playerOid);
/*      */ 
/* 1762 */     List uiThemes = World.getThemes();
/* 1763 */     if (Log.loggingDebug)
/* 1764 */       Log.debug(new StringBuilder().append("processLogin: setting themes: ").append(uiThemes).toString());
/* 1765 */     Event uiThemeEvent = new UITheme(uiThemes);
/* 1766 */     con.send(uiThemeEvent.toBytes());
/*      */ 
/* 1841 */     WorldManagerClient.TargetedExtensionMessage spawnBegin = new WorldManagerClient.TargetedExtensionMessage(playerOid, playerOid);
/*      */ 
/* 1843 */     spawnBegin.setExtensionType("ao.SCENE_BEGIN");
/* 1844 */     spawnBegin.setProperty("action", "login");
/* 1845 */     spawnBegin.setProperty("name", instanceInfo.name);
/*      */ 
/* 1847 */     spawnBegin.setProperty("templateName", instanceInfo.templateName);
/*      */ 
/* 1850 */     WorldManagerClient.TargetedExtensionMessage spawnEnd = new WorldManagerClient.TargetedExtensionMessage(playerOid, playerOid);
/*      */ 
/* 1852 */     spawnEnd.setExtensionType("ao.SCENE_END");
/* 1853 */     spawnEnd.setProperty("action", "login");
/* 1854 */     spawnEnd.setProperty("name", instanceInfo.name);
/*      */ 
/* 1856 */     spawnEnd.setProperty("templateName", instanceInfo.templateName);
/*      */ 
/* 1862 */     Integer perceptionCount = WorldManagerClient.spawn(playerOid, spawnBegin, spawnEnd);
/*      */ 
/* 1864 */     if (perceptionCount.intValue() < 0) {
/* 1865 */       Log.error(new StringBuilder().append("processLogin: spawn failed error=").append(perceptionCount).append(" playerOid=").append(playerOid).toString());
/*      */ 
/* 1870 */       return perceptionCount.intValue() != -2;
/*      */     }
/*      */ 
/* 1884 */     if ((perceptionCount.intValue() == 0) && (player.supportsLoadingState())) {
/* 1885 */       player.setLoadingState(1);
/* 1886 */       con.send(new LoadingStateEvent(false).toBytes());
/*      */     }
/*      */ 
/* 1889 */     if (Log.loggingDebug) {
/* 1890 */       Log.debug(new StringBuilder().append("processLogin: During login, perceptionCount is ").append(perceptionCount).toString());
/*      */ 
/* 1892 */       Log.debug(new StringBuilder().append("processLogin: spawned player, master playerOid=").append(playerOid).toString());
/*      */     }
/*      */ 
/* 1897 */     if (Log.loggingDebug) {
/* 1898 */       Log.debug(new StringBuilder().append("processLogin: sending over instance information for player ").append(playerOid).append(", instance=").append(instanceInfo.name).append(", instanceOid=").append(instanceInfo.oid).toString());
/*      */     }
/*      */ 
/* 1904 */     updateInstancePerception(player.getOid(), null, instanceInfo.oid, instanceInfo.name);
/*      */ 
/* 1907 */     return true;
/*      */   }
/*      */ 
/*      */   public ProxyLoginCallback getProxyLoginCallback()
/*      */   {
/* 1914 */     return this.proxyLoginCallback;
/*      */   }
/*      */ 
/*      */   public void setProxyLoginCallback(ProxyLoginCallback callback)
/*      */   {
/* 1922 */     this.proxyLoginCallback = callback;
/*      */   }
/*      */ 
/*      */   private boolean instanceEntryAllowed(OID playerOid, OID instanceOid, Point location)
/*      */   {
/* 1948 */     if (instanceOid == null) {
/* 1949 */       return false;
/*      */     }
/* 1951 */     return this.instanceEntryCallback.instanceEntryAllowed(playerOid, instanceOid, location);
/*      */   }
/*      */ 
/*      */   public InstanceEntryCallback getInstanceEntryCallback()
/*      */   {
/* 1959 */     return this.instanceEntryCallback;
/*      */   }
/*      */ 
/*      */   public void setInstanceEntryCallback(InstanceEntryCallback callback)
/*      */   {
/* 1967 */     this.instanceEntryCallback = callback;
/*      */   }
/*      */ 
/*      */   public void processRequestQuestInfo(ClientConnection con, RequestQuestInfo event)
/*      */   {
/* 1987 */     OID npcOid = event.getQuestNpcOid();
/* 1988 */     Player player = verifyPlayer("processRequestQuestInfo", event, con);
/* 1989 */     if (Log.loggingDebug) {
/* 1990 */       Log.debug(new StringBuilder().append("processRequestQuestInfo: player=").append(player).append(", npc=").append(npcOid).toString());
/*      */     }
/* 1992 */     QuestClient.requestQuestInfo(npcOid, player.getOid());
/*      */   }
/*      */ 
/*      */   public void processQuestResponse(ClientConnection con, QuestResponse event)
/*      */   {
/* 1999 */     Player player = verifyPlayer("processQuestResponse", event, con);
/* 2000 */     boolean acceptStatus = event.getResponse();
/* 2001 */     OID npcOid = event.getQuestNpcOid();
/* 2002 */     OID questOid = event.getQuestId();
/*      */ 
/* 2004 */     if (Log.loggingDebug) {
/* 2005 */       Log.debug(new StringBuilder().append("processQuestResponse: player=").append(player).append(", npcOid=").append(npcOid).append(", acceptStatus=").append(acceptStatus).toString());
/*      */     }
/*      */ 
/* 2009 */     QuestClient.QuestResponseMessage msg = new QuestClient.QuestResponseMessage(npcOid, player.getOid(), questOid, acceptStatus);
/*      */ 
/* 2012 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public void processReqConcludeQuest(ClientConnection con, ConcludeQuest event)
/*      */   {
/* 2020 */     Player player = verifyPlayer("processReqConcludeQuest", event, con);
/* 2021 */     OID mobOid = event.getQuestNpcOid();
/* 2022 */     if (Log.loggingDebug) {
/* 2023 */       Log.debug(new StringBuilder().append("processReqConclude: player=").append(player).append(", mobOid=").append(mobOid).toString());
/*      */     }
/* 2025 */     QuestClient.requestConclude(mobOid, player.getOid());
/*      */   }
/*      */ 
/*      */   public void connectionReset(ClientConnection con)
/*      */   {
/* 2037 */     Player player = (Player)con.getAssociation();
/*      */ 
/* 2039 */     if (player == null) {
/* 2040 */       Log.info(new StringBuilder().append("ProxyPlugin: DISCONNECT remote=").append(con).toString());
/* 2041 */       return;
/*      */     }
/* 2043 */     Log.info(new StringBuilder().append("ProxyPlugin: DISCONNECT remote=").append(con).append(" playerOid=").append(player.getOid()).append(" name=").append(player.getName()).toString());
/*      */ 
/* 2046 */     if (this.playerManager.logout(player)) {
/* 2047 */       ConnectionResetMessage message = new ConnectionResetMessage(con, player);
/*      */ 
/* 2049 */       message.setEnqueueTime(System.currentTimeMillis());
/* 2050 */       this.messageQQ.insert(player, message);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void processConnectionResetInternal(ConnectionResetMessage message)
/*      */   {
/* 2080 */     long startTime = System.currentTimeMillis();
/* 2081 */     ClientConnection con = message.getConnection();
/* 2082 */     Player player = message.getPlayer();
/* 2083 */     OID playerOid = player.getOid();
/*      */ 
/* 2085 */     Log.info(new StringBuilder().append("ProxyPlugin: LOGOUT_BEGIN remote=").append(con).append(" playerOid=").append(player.getOid()).append(" name=").append(player.getName()).toString());
/*      */ 
/* 2089 */     if (player.getStatus() != 3) {
/* 2090 */       log.error(new StringBuilder().append("processConnectionReset: player status is ").append(Player.statusToString(player.getStatus())).append(" should be ").append(Player.statusToString(3)).toString());
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 2097 */       if (!WorldManagerClient.despawn(playerOid)) {
/* 2098 */         log.warn(new StringBuilder().append("processConnectionReset: despawn player failed for ").append(playerOid).toString());
/*      */       }
/*      */ 
/* 2102 */       if (this.perceptionFilter.removeTarget(playerOid)) {
/* 2103 */         FilterUpdate filterUpdate = new FilterUpdate(1);
/* 2104 */         filterUpdate.removeFieldValue(1, playerOid);
/* 2105 */         Engine.getAgent().applyFilterUpdate(this.perceptionSubId, filterUpdate);
/*      */ 
/* 2107 */         this.responderFilter.removeTarget(playerOid);
/* 2108 */         Engine.getAgent().applyFilterUpdate(this.responderSubId, filterUpdate);
/*      */       }
/*      */ 
/* 2116 */       LogoutMessage logoutMessage = new LogoutMessage(playerOid, player.getName());
/*      */ 
/* 2118 */       AsyncRPCCallback asyncRPCCallback = new AsyncRPCCallback(player, "processLogout: got LogoutMessage response");
/*      */ 
/* 2120 */       int expectedResponses = Engine.getAgent().sendBroadcastRPCBlocking(logoutMessage, asyncRPCCallback);
/*      */ 
/* 2123 */       OID accountID = (OID)EnginePlugin.getObjectProperty(playerOid, WorldManagerClient.NAMESPACE, "accountId");
/* 2124 */       Log.debug(new StringBuilder().append("Removing connection from client connection map for account: ").append(accountID).toString());
/* 2125 */       this.clientConnections.remove(accountID);
/*      */ 
/* 2128 */       if (!ObjectManagerClient.unloadObject(playerOid).booleanValue())
/* 2129 */         log.warn(new StringBuilder().append("processConnectionReset: unloadObject failed oid=").append(playerOid).toString());
/*      */     }
/*      */     catch (NoRecipientsException nre)
/*      */     {
/* 2133 */       log.exception("ProxyPlugin.processConnectionResetInternal(): ", nre);
/*      */     }
/*      */ 
/* 2138 */     this.messageQQ.removeKey(player);
/* 2139 */     this.eventQQ.removeKey(player);
/*      */ 
/* 2141 */     this.playerManager.removeStaticPerception(player, playerOid);
/* 2142 */     this.playerManager.removePlayer(playerOid);
/*      */ 
/* 2144 */     Log.info(new StringBuilder().append("ProxyPlugin: LOGOUT_END remote=").append(con).append(" playerOid=").append(player.getOid()).append(" name=").append(player.getName()).append(" in-queue=").append(startTime - message.getEnqueueTime()).append(" processing=").append(System.currentTimeMillis() - startTime).append(" nPlayers=").append(this.playerManager.getPlayerCount()).toString());
/*      */ 
/* 2150 */     synchronized (player) {
/* 2151 */       player.clearConnection();
/* 2152 */       player.notifyAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void processDirLocOrient(ClientConnection con, DirLocOrientEvent event)
/*      */   {
/* 2162 */     if (Log.loggingDebug) {
/* 2163 */       Log.debug(new StringBuilder().append("processDirLocOrient: got dir loc orient event: ").append(event).toString());
/*      */     }
/* 2165 */     Player player = verifyPlayer("processDirLoc", event, con);
/*      */ 
/* 2168 */     BasicWorldNode wnode = new BasicWorldNode();
/* 2169 */     wnode.setDir(event.getDir());
/* 2170 */     wnode.setLoc(event.getLoc());
/* 2171 */     wnode.setOrientation(event.getQuaternion());
/*      */ 
/* 2173 */     WorldManagerClient.updateWorldNode(player.getOid(), wnode);
/*      */   }
/*      */ 
/*      */   protected void processCom(ClientConnection con, ComEvent event)
/*      */   {
/* 2181 */     Player player = verifyPlayer("processCom", event, con);
/*      */ 
/* 2183 */     Log.info(new StringBuilder().append("ProxyPlugin: CHAT_SENT player=").append(player).append(" channel=").append(event.getChannelId()).append(" msg=[").append(event.getMessage()).append("]").toString());
/*      */ 
/* 2186 */     incrementChatCount();
/* 2187 */     WorldManagerClient.sendChatMsg(player.getOid(), player.getName(), event.getChannelId(), event.getMessage());
/*      */   }
/*      */ 
/*      */   protected void processCommand(ClientConnection con, CommandEvent event)
/*      */   {
/* 2198 */     Player player = verifyPlayer("processCommand", event, con);
/*      */ 
/* 2200 */     String cmd = event.getCommand().split(" ")[0];
/* 2201 */     if (Log.loggingDebug) {
/* 2202 */       log.debug(new StringBuilder().append("processCommand: cmd=").append(cmd).append(", fullCmd=").append(event.getCommand()).toString());
/* 2207 */     }
/*      */ this.commandMapLock.lock();
/*      */     RegisteredCommand command;
/*      */     try {
/* 2209 */       command = (RegisteredCommand)this.commandMap.get(cmd);
/*      */     } finally {
/* 2211 */       this.commandMapLock.unlock();
/*      */     }
/* 2213 */     if (command == null) {
/* 2214 */       Log.warn(new StringBuilder().append("processCommand: no parser for command: ").append(event.getCommand()).toString());
/*      */ 
/* 2216 */       command = (RegisteredCommand)this.commandMap.get("/unknowncmd");
/* 2217 */       if (command != null) {
/* 2218 */         Engine.setCurrentPlugin(this);
/* 2219 */         command.parser.parse(event);
/* 2220 */         Engine.setCurrentPlugin(null);
/*      */       }
/* 2222 */       return;
/*      */     }
/*      */ 
/* 2225 */     Engine.setCurrentPlugin(this);
/* 2226 */     if (command.access.allowed(event, this))
/*      */     {
/* 2228 */       command.parser.parse(event);
/*      */     }
/* 2230 */     else Log.warn(new StringBuilder().append("Player ").append(player).append(" not allowed to run command '").append(event.getCommand()).append("'").toString());
/*      */ 
/* 2232 */     Engine.setCurrentPlugin(null);
/*      */   }
/*      */ 
/*      */   protected void processAutoAttack(ClientConnection con, AutoAttackEvent event)
/*      */   {
/* 2239 */     CombatClient.autoAttack(event.getAttackerOid(), event.getTargetOid(), event.getAttackStatus());
/*      */   }
/*      */ 
/*      */   protected void processActivateItem(ClientConnection con, ActivateItemEvent event)
/*      */   {
/* 2245 */     InventoryClient.activateObject(event.getItemOid(), event.getObjectOid(), event.getTargetOid());
/*      */   }
/*      */ 
/*      */   protected void processAbilityStatusEvent(ClientConnection con, AbilityStatusEvent event)
/*      */   {
/* 2251 */     Player player = (Player)con.getAssociation();
/* 2252 */     AbilityStatusMessage msg = new AbilityStatusMessage(CombatClient.MSG_TYPE_ABILITY_STATUS, player.getOid(), event.getPropertyMap());
/*      */ 
/* 2255 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   protected void processExtensionMessageEvent(ClientConnection con, ExtensionMessageEvent event)
/*      */   {
/* 2260 */     String key = (String)event.getPropertyMap().get("ext_msg_subtype");
/* 2261 */     OID target = event.getTargetOid();
/* 2262 */     Player player = (Player)con.getAssociation();
/*      */ 
/* 2264 */     if (Log.loggingDebug) {
/* 2265 */       Log.debug(new StringBuilder().append("processExtensionMessageEvent: ").append(player).append(" subType=").append(key).append(" target=").append(target).toString());
/*      */     }
/*      */ 
/* 2268 */     List proxyHookList = (List)this.extensionHooks.get(key);
/* 2269 */     if (proxyHookList != null) {
/* 2270 */       for (ProxyExtensionHook hook : proxyHookList) {
/* 2271 */         hook.processExtensionEvent(event, player, this);
/*      */       }
/* 2273 */       return;
/*      */     }
/*      */ 
/* 2276 */     if (target != null) {
/* 2277 */       WorldManagerClient.TargetedExtensionMessage msg = new WorldManagerClient.TargetedExtensionMessage(WorldManagerClient.MSG_TYPE_EXTENSION, target, player.getOid(), event.getClientTargeted(), event.getPropertyMap());
/*      */ 
/* 2281 */       if (event.getClientTargeted().booleanValue()) {
/* 2282 */         msg.setMsgType(WorldManagerClient.MSG_TYPE_P2P_EXTENSION);
/* 2283 */         if (allowClientToClientMessage(player, target, msg))
/* 2284 */           Engine.getAgent().sendBroadcast(msg);
/*      */       } else {
/* 2286 */         MessageType msgType = getExtensionMessageType(key);
/* 2287 */         if (msgType == null) {
/* 2288 */           Log.error(new StringBuilder().append("processExtensionMessageEvent: key '").append(key).append("' has no corresponding MessageType").toString());
/*      */ 
/* 2290 */           return;
/*      */         }
/* 2292 */         msg.setMsgType(msgType);
/* 2293 */         Engine.getAgent().sendBroadcast(msg);
/*      */       }
/*      */     } else {
/* 2296 */       MessageType msgType = getExtensionMessageType(key);
/* 2297 */       if (msgType == null) {
/* 2298 */         Log.error(new StringBuilder().append("processExtensionMessageEvent: key '").append(key).append("' has no corresponding MessageType").toString());
/*      */ 
/* 2300 */         return;
/*      */       }
/* 2302 */       WorldManagerClient.ExtensionMessage msg = new WorldManagerClient.ExtensionMessage(msgType, player.getOid(), event.getPropertyMap());
/*      */ 
/* 2304 */       Engine.getAgent().sendBroadcast(msg);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerExtensionSubtype(String subtype, MessageType type)
/*      */   {
/* 2314 */     this.extensionMessageRegistry.put(subtype, type);
/*      */   }
/*      */ 
/*      */   public MessageType unregisterExtensionSubtype(String subtype)
/*      */   {
/* 2321 */     return (MessageType)this.extensionMessageRegistry.remove(subtype);
/*      */   }
/*      */ 
/*      */   public MessageType getExtensionMessageType(String subtype)
/*      */   {
/* 2328 */     return (MessageType)this.extensionMessageRegistry.get(subtype);
/*      */   }
/*      */ 
/*      */   public boolean allowClientToClientMessage(Player sender, OID targetOid, WorldManagerClient.TargetedExtensionMessage message)
/*      */   {
/* 2349 */     return this.defaultAllowClientToClientMessage;
/*      */   }
/*      */ 
/*      */   protected boolean specialCaseNewProcessing(PerceptionMessage.ObjectNote objectNote, Player player)
/*      */   {
/* 2775 */     long start = System.currentTimeMillis();
/*      */ 
/* 2777 */     ClientConnection con = player.getConnection();
/*      */ 
/* 2779 */     OID objOid = objectNote.getSubject();
/* 2780 */     ObjectType objType = objectNote.getObjectType();
/*      */ 
/* 2784 */     if (objType == ObjectTypes.light) {
/* 2785 */       Log.debug("specialCaseNewProcessing: got a light object");
/* 2786 */       LightData lightData = (LightData)EnginePlugin.getObjectProperty(objOid, Namespace.WORLD_MANAGER, Light.LightDataPropertyKey);
/*      */ 
/* 2789 */       if (Log.loggingDebug)
/* 2790 */         Log.debug(new StringBuilder().append("specialCaseNewProcessing: light data=").append(lightData).toString());
/* 2791 */       NewLightEvent lightEvent = new NewLightEvent(player.getOid(), objOid, lightData);
/*      */ 
/* 2793 */       con.send(lightEvent.toBytes());
/* 2794 */       return true;
/*      */     }
/*      */ 
/* 2797 */     if (objType.equals(WorldManagerClient.TEMPL_OBJECT_TYPE_TERRAIN_DECAL)) {
/* 2798 */       Log.debug("specialCaseNewProcessing: got a terrain decal object");
/* 2799 */       TerrainDecalData decalData = (TerrainDecalData)EnginePlugin.getObjectProperty(objOid, Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_TERRAIN_DECAL_DATA);
/*      */ 
/* 2802 */       if (Log.loggingDebug) {
/* 2803 */         Log.debug(new StringBuilder().append("specialCaseNewProcessing: terrain decal data=").append(decalData).toString());
/*      */       }
/* 2805 */       NewTerrainDecalEvent decalEvent = new NewTerrainDecalEvent(objOid, decalData);
/*      */ 
/* 2807 */       con.send(decalEvent.toBytes());
/* 2808 */       return true;
/*      */     }
/*      */ 
/* 2811 */     if (objType.equals(WorldManagerClient.TEMPL_OBJECT_TYPE_POINT_SOUND)) {
/* 2812 */       Log.debug("specialCaseNewProcessing: got a point sound object");
/* 2813 */       List soundData = (List)EnginePlugin.getObjectProperty(objOid, Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_SOUND_DATA_LIST);
/*      */ 
/* 2816 */       if (Log.loggingDebug) {
/* 2817 */         Log.debug(new StringBuilder().append("specialCaseNewProcessing: sound data=").append(soundData).toString());
/*      */       }
/* 2819 */       WorldManagerClient.SoundMessage soundMsg = new WorldManagerClient.SoundMessage(objOid);
/* 2820 */       soundMsg.setSoundData(soundData);
/* 2821 */       con.send(soundMsg.toBuffer());
/* 2822 */       return true;
/*      */     }
/*      */ 
/* 2825 */     WorldManagerClient.PerceptionInfo perceptionInfo = (WorldManagerClient.PerceptionInfo)objectNote.getObjectInfo();
/*      */ 
/* 2829 */     if (perceptionInfo.objectInfo == null)
/*      */     {
/* 2831 */       return true;
/*      */     }
/*      */ 
/* 2836 */     WorldManagerClient.MobPathMessage pathMsg = (WorldManagerClient.MobPathMessage)perceptionInfo.objectInfo.getProperty(WorldManagerClient.MOB_PATH_PROPERTY);
/*      */ 
/* 2838 */     Log.debug(new StringBuilder().append("INFO: special case with player/npc: ").append(perceptionInfo.objectInfo.name).toString());
/* 2839 */     con.send(perceptionInfo.objectInfo.toBuffer(player.getOid()));
/*      */ 
/* 2841 */     if (perceptionInfo.displayContext != null) {
/* 2842 */       ModelInfoEvent modelInfoEvent = new ModelInfoEvent(objOid);
/* 2843 */       modelInfoEvent.setDisplayContext(perceptionInfo.displayContext);
/* 2844 */       con.send(modelInfoEvent.toBytes());
/*      */     }
/* 2846 */     else if (Log.loggingDebug) {
/* 2847 */       Log.debug(new StringBuilder().append("No display context for ").append(objOid).toString());
/*      */     }
/*      */ 
/* 2851 */     if (pathMsg != null)
/*      */     {
/* 2853 */       if (pathMsg.pathExpired()) {
/* 2854 */         if (Log.loggingDebug) {
/* 2855 */           Log.debug(new StringBuilder().append("specialCaseNewProcessing: for mob ").append(objOid).append(", last mob path expired ").append(pathMsg.toString()).toString());
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 2860 */         if (Log.loggingDebug) {
/* 2861 */           Log.debug(new StringBuilder().append("specialCaseNewProcessing: for mob ").append(objOid).append(", sending last mob path ").append(pathMsg.toString()).toString());
/*      */         }
/* 2863 */         AOByteBuffer pathBuf = pathMsg.toBuffer();
/* 2864 */         con.send(pathBuf);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2869 */     Map childMap = null;
/* 2870 */     if (perceptionInfo.displayContext != null)
/* 2871 */       childMap = perceptionInfo.displayContext.getChildDCMap();
/* 2872 */     if ((childMap != null) && (!childMap.isEmpty())) {
/* 2873 */       for (String slot : childMap.keySet()) {
/* 2874 */         DisplayContext attachDC = (DisplayContext)childMap.get(slot);
/* 2875 */         if (attachDC == null) {
/* 2876 */           throw new AORuntimeException(new StringBuilder().append("attach DC is null for obj: ").append(objOid).toString());
/*      */         }
/*      */ 
/* 2879 */         OID attacheeOID = attachDC.getObjRef();
/* 2880 */         if (attacheeOID == null) {
/* 2881 */           throw new AORuntimeException(new StringBuilder().append("attachee oid is null for obj: ").append(objOid).toString());
/*      */         }
/*      */ 
/* 2885 */         if (Log.loggingDebug) {
/* 2886 */           Log.debug(new StringBuilder().append("specialCaseNewProcessing: sending attach message to ").append(player.getOid()).append(" attaching to obj ").append(objOid).append(", object being attached=").append(attacheeOID).append(" to slot ").append(slot).append(", attachmentDC=").append(attachDC).toString());
/*      */         }
/*      */ 
/* 2896 */         AttachEvent event = new AttachEvent(objOid, attacheeOID, slot, attachDC);
/*      */ 
/* 2898 */         con.send(event.toBytes());
/*      */       }
/* 2900 */       if (Log.loggingDebug) {
/* 2901 */         Log.debug("specialCaseNewProcessing: done with processing attachments");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2917 */     long finish = System.currentTimeMillis();
/* 2918 */     if (Log.loggingDebug) {
/* 2919 */       Log.debug(new StringBuilder().append("specialCaseNewProcessing: finished.\tplayerOid=").append(player.getOid()).append(", oid=").append(objOid).append(" in ").append(finish - start).append(" ms").toString());
/*      */     }
/*      */ 
/* 2922 */     return false;
/*      */   }
/*      */ 
/*      */   protected boolean specialCaseFreeProcessing(PerceptionMessage.ObjectNote objectNote, Player player)
/*      */   {
/* 2938 */     if (player.getOid().equals(objectNote.getSubject())) {
/* 2939 */       Log.debug("ignoring free object message to self");
/* 2940 */       return true;
/*      */     }
/*      */ 
/* 2943 */     ClientConnection con = player.getConnection();
/* 2944 */     if (!con.isOpen()) {
/* 2945 */       con = null;
/*      */     }
/* 2947 */     OID objOid = objectNote.getSubject();
/*      */ 
/* 2949 */     if (objectNote.getObjectType() == ObjectTypes.road) {
/* 2950 */       if (Log.loggingDebug) {
/* 2951 */         Log.debug(new StringBuilder().append("specialCaseFreeProcessing: playerOid=").append(player.getOid()).append(", roadSegmentOid=").append(objOid).toString());
/*      */       }
/* 2953 */       handleFreeRoad(con, objOid);
/* 2954 */       return true;
/*      */     }
/* 2956 */     if (objectNote.getObjectType().equals(WorldManagerClient.TEMPL_OBJECT_TYPE_TERRAIN_DECAL))
/*      */     {
/* 2958 */       if (Log.loggingDebug) {
/* 2959 */         Log.debug(new StringBuilder().append("specialCaseFreeProcessing: playerOid=").append(player.getOid()).append(", decalOid=").append(objOid).toString());
/*      */       }
/* 2961 */       FreeTerrainDecalEvent decalEvent = new FreeTerrainDecalEvent(objOid);
/* 2962 */       if (con != null)
/* 2963 */         con.send(decalEvent.toBytes());
/* 2964 */       return true;
/*      */     }
/*      */ 
/* 2968 */     if (Log.loggingDebug) {
/* 2969 */       Log.debug(new StringBuilder().append("specialCaseFreeProcessing: playerOid=").append(player.getOid()).append(", objOid=").append(objOid).toString());
/*      */     }
/*      */ 
/* 2972 */     NotifyFreeObjectEvent freeEvent = new NotifyFreeObjectEvent(player.getOid(), objOid);
/*      */ 
/* 2975 */     if (con != null) {
/* 2976 */       con.send(freeEvent.toBytes());
/*      */     }
/* 2978 */     return false;
/*      */   }
/*      */ 
/*      */   protected void handleFreeRoad(ClientConnection con, OID objOid)
/*      */   {
/* 2985 */     WorldManagerClient.FreeRoadMessage freeRoadMsg = new WorldManagerClient.FreeRoadMessage(objOid);
/*      */ 
/* 2987 */     AOByteBuffer buf = freeRoadMsg.toBuffer();
/* 2988 */     if (con != null)
/* 2989 */       con.send(buf);
/*      */   }
/*      */ 
/*      */   public static void addStaticPerception(OID playerOid, OID oid)
/*      */   {
/* 3129 */     addStaticPerception(playerOid, oid, null, null, false);
/*      */   }
/*      */ 
/*      */   public static void addStaticPerception(OID oid, OID oid2, String name, ObjectType type)
/*      */   {
/* 3134 */     addStaticPerception(oid, oid2, name, type, true);
/*      */   }
/*      */ 
/*      */   private static void addStaticPerception(OID playerOid, OID oid, String name, ObjectType type, boolean hasObjectInfo)
/*      */   {
/* 3139 */     AddStaticPerceptionMessage message = new AddStaticPerceptionMessage(MSG_TYPE_ADD_STATIC_PERCEPTION);
/*      */ 
/* 3141 */     message.setTarget(playerOid);
/* 3142 */     message.setSubject(oid);
/* 3143 */     message.setName(name);
/* 3144 */     message.setType(type);
/* 3145 */     message.setHasObjectInfo(hasObjectInfo);
/* 3146 */     Engine.getAgent().sendBroadcast(message);
/*      */   }
/*      */ 
/*      */   public static void removeStaticPerception(OID playerOid, OID oid) {
/* 3150 */     TargetMessage message = new TargetMessage(MSG_TYPE_REMOVE_STATIC_PERCEPTION);
/*      */ 
/* 3152 */     message.setTarget(playerOid);
/* 3153 */     message.setSubject(oid);
/* 3154 */     Engine.getAgent().sendBroadcast(message);
/*      */   }
/*      */ 
/*      */   protected void processPlayerIgnoreList(Player player)
/*      */   {
/* 3266 */     if (player.getStatus() == 3) {
/* 3267 */       Log.error("ProxyPlugin.processPlayerIgnoreList: Aborting... player.getStatus() is STATUS_LOGOUT");
/* 3268 */       return;
/*      */     }
/*      */ 
/* 3276 */     sendPlayerIgnoreList(player);
/*      */   }
/*      */ 
/*      */   protected void sendPlayerIgnoreList(Player player)
/*      */   {
/* 3287 */     String missing = " Missing ";
/*      */   }
/*      */ 
/*      */   public void updateIgnoredOids(Player player, List<OID> nowIgnored, List<OID> noLongerIgnored)
/*      */   {
/*      */   }
/*      */ 
/*      */   public List<Object> matchingPlayers(Player player, String playerName, Boolean exactMatch)
/*      */   {
/* 3399 */     boolean match = exactMatch == null ? true : exactMatch.booleanValue();
/* 3400 */     List matchLists = Engine.getDatabase().getOidsAndNamesMatchingName(playerName, match);
/*      */ 
/* 3402 */     List oids = (List)matchLists.get(0);
/* 3403 */     List names = (List)matchLists.get(1);
/* 3404 */     if (Log.loggingDebug) {
/* 3405 */       log.debug(new StringBuilder().append("ProxyPlugin.matchingPlayers: For player ").append(player.getOid()).append(", found ").append(oids == null ? 0 : oids.size()).append(" players: ").append(Database.makeOidCollectionString(oids)).append(" ").append(match ? "exactly matching" : "starting with").append(" name '").append(playerName).append("':").append(Database.makeNameCollectionString(names)).toString());
/*      */     }
/*      */ 
/* 3412 */     return matchLists;
/*      */   }
/*      */   public static OID handleFullInstance(String instanceTemplateName, InstanceClient.InstanceInfo instanceInfo) {
/* 4157 */     Log.debug(new StringBuilder().append("POP: instance full with template: ").append(instanceTemplateName).toString());
/*      */ 
/* 4159 */     int instanceNum = 1;
/* 4160 */     String instanceName = "";
/*      */     OID instanceOid;
/*      */     while (true) { instanceName = new StringBuilder().append(instanceTemplateName).append("_").append(instanceNum).toString();
/* 4165 */       instanceOid = InstanceClient.getInstanceOid(instanceName);
/* 4166 */       if (instanceOid != null) {
/* 4167 */         instanceInfo = InstanceClient.getInstanceInfo(instanceOid, -8193);
/* 4168 */         if (instanceInfo.populationLimit < 1) break; if (instanceInfo.playerPopulation < instanceInfo.populationLimit)
/* 4169 */           break;
/*      */       }
/*      */       else {
/* 4172 */         Template overrideTemplate = new Template();
/* 4173 */         overrideTemplate.put(Namespace.INSTANCE, "name", instanceName);
/* 4174 */         instanceOid = InstanceClient.createInstance(instanceTemplateName, overrideTemplate);
/* 4175 */         if (instanceOid != null) {
/*      */           break;
/*      */         }
/*      */       }
/* 4179 */       instanceNum++;
/*      */     }
/*      */ 
/* 4182 */     return instanceOid;
/*      */   }
/*      */ 
/*      */   private void updateInstancePerception(OID playerOid, OID prevInstanceOid, OID destInstanceOid, String destInstanceName)
/*      */   {
/* 4187 */     if (prevInstanceOid != null)
/*      */     {
/* 4189 */       removeStaticPerception(playerOid, prevInstanceOid);
/*      */     }
/*      */ 
/* 4193 */     addStaticPerception(playerOid, destInstanceOid, destInstanceName, ObjectTypes.instance);
/*      */   }
/*      */ 
/*      */   protected void pushInstanceRestorePoint(Player player, BasicWorldNode loc)
/*      */   {
/* 4198 */     OID playerOid = player.getOid();
/* 4199 */     InstanceRestorePoint restorePoint = new InstanceRestorePoint();
/* 4200 */     restorePoint.setInstanceOid(loc.getInstanceOid());
/* 4201 */     restorePoint.setLoc(loc.getLoc());
/* 4202 */     restorePoint.setOrientation(loc.getOrientation());
/*      */ 
/* 4204 */     InstanceClient.InstanceInfo instanceInfo = InstanceClient.getInstanceInfo(loc.getInstanceOid(), 2);
/*      */ 
/* 4206 */     restorePoint.setInstanceName(instanceInfo.name);
/*      */ 
/* 4209 */     LinkedList restoreStack = (LinkedList)EnginePlugin.getObjectProperty(playerOid, Namespace.OBJECT_MANAGER, "instanceStack");
/*      */ 
/* 4213 */     if (restoreStack == null) {
/* 4214 */       restoreStack = new LinkedList();
/*      */     }
/*      */ 
/* 4217 */     restoreStack.add(restorePoint);
/*      */ 
/* 4219 */     EnginePlugin.setObjectProperty(playerOid, Namespace.OBJECT_MANAGER, "instanceStack", restoreStack);
/*      */   }
/*      */ 
/*      */   protected void sendOceanData(OceanData oceanData, Player player)
/*      */   {
/* 4224 */     WorldManagerClient.TargetedExtensionMessage oceanMsg = new ClientParameter.ClientParameterMessage(player.getOid());
/*      */ 
/* 4226 */     oceanMsg.setProperty("Ocean.DisplayOcean", oceanData.displayOcean.toString());
/*      */ 
/* 4228 */     if (oceanData.useParams != null) {
/* 4229 */       oceanMsg.setProperty("Ocean.UseParams", oceanData.useParams.toString());
/*      */     }
/*      */ 
/* 4232 */     if (oceanData.waveHeight != null) {
/* 4233 */       oceanMsg.setProperty("Ocean.WaveHeight", oceanData.waveHeight.toString());
/*      */     }
/*      */ 
/* 4236 */     if (oceanData.seaLevel != null) {
/* 4237 */       oceanMsg.setProperty("Ocean.SeaLevel", oceanData.seaLevel.toString());
/*      */     }
/*      */ 
/* 4240 */     if (oceanData.bumpScale != null) {
/* 4241 */       oceanMsg.setProperty("Ocean.BumpScale", oceanData.bumpScale.toString());
/*      */     }
/*      */ 
/* 4244 */     if (oceanData.bumpSpeedX != null) {
/* 4245 */       oceanMsg.setProperty("Ocean.BumpSpeedX", oceanData.bumpSpeedX.toString());
/*      */     }
/*      */ 
/* 4248 */     if (oceanData.bumpSpeedZ != null) {
/* 4249 */       oceanMsg.setProperty("Ocean.BumpSpeedZ", oceanData.bumpSpeedZ.toString());
/*      */     }
/*      */ 
/* 4252 */     if (oceanData.textureScaleX != null) {
/* 4253 */       oceanMsg.setProperty("Ocean.TextureScaleX", oceanData.textureScaleX.toString());
/*      */     }
/*      */ 
/* 4256 */     if (oceanData.textureScaleZ != null) {
/* 4257 */       oceanMsg.setProperty("Ocean.TextureScaleZ", oceanData.textureScaleZ.toString());
/*      */     }
/*      */ 
/* 4260 */     if (oceanData.deepColor != null) {
/* 4261 */       oceanMsg.setProperty("Ocean.DeepColor", oceanData.deepColor.toString());
/*      */     }
/*      */ 
/* 4264 */     if (oceanData.shallowColor != null) {
/* 4265 */       oceanMsg.setProperty("Ocean.ShallowColor", oceanData.shallowColor.toString());
/*      */     }
/*      */ 
/* 4268 */     player.getConnection().send(oceanMsg.toBuffer(player.getVersion()));
/*      */   }
/*      */ 
/*      */   protected Player verifyPlayer(String context, Event event, ClientConnection con)
/*      */   {
/* 4277 */     Player player = (Player)con.getAssociation();
/* 4278 */     if (!player.getOid().equals(event.getObjectOid())) {
/* 4279 */       throw new AORuntimeException(new StringBuilder().append(context).append(": con doesn't match player ").append(player).append(" against eventOid ").append(event.getObjectOid()).toString());
/*      */     }
/*      */ 
/* 4282 */     return player;
/*      */   }
/*      */ 
/*      */   public void incrementChatCount()
/*      */   {
/* 4360 */     this.chatSentCount += 1;
/*      */   }
/*      */ 
/*      */   public void incrementPrivateChatCount() {
/* 4364 */     this.privateChatSentCount += 1;
/*      */   }
/*      */ 
/*      */   public void addAdmin(OID oid)
/*      */   {
/* 4512 */     if (Log.loggingDebug)
/* 4513 */       log.debug(new StringBuilder().append("ProxyPlugin.addAdmin: adding oid ").append(oid).toString());
/* 4514 */     this.lock.lock();
/*      */     try {
/* 4516 */       this.adminSet.add(oid);
/*      */     } finally {
/* 4518 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Set<OID> getAdmins()
/*      */   {
/* 4526 */     this.lock.lock();
/*      */     try {
/* 4528 */       HashSet localHashSet = new HashSet(this.adminSet);
/*      */       return localHashSet; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean isAdmin(OID playerOid)
/*      */   {
/* 4538 */     this.lock.lock();
/*      */     try {
/* 4540 */       if (playerOid == null) {
/* 4541 */         bool = false;
/*      */         return bool;
/*      */       }
/* 4543 */       boolean bool = this.adminSet.contains(playerOid);
/*      */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   protected Object createMBeanInstance()
/*      */   {
/* 4579 */     return new ProxyJMX();
/*      */   }
/*      */ 
/*      */   class PeriodicGC
/*      */     implements Runnable
/*      */   {
/*      */     PeriodicGC()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 4701 */       int count = 1;
/*      */       while (true) {
/*      */         try {
/* 4704 */           Thread.sleep(60000L);
/*      */         } catch (InterruptedException ex) {
/*      */         }
/* 4707 */         System.out.println("Proxy running GC " + count);
/* 4708 */         System.gc();
/* 4709 */         count++;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected class ProxyJMX
/*      */     implements ProxyPlugin.ProxyJMXMBean
/*      */   {
/*      */     protected ProxyJMX()
/*      */     {
/*      */     }
/*      */ 
/*      */     public int getMaxConcurrentUsers()
/*      */     {
/* 4623 */       return ProxyPlugin.MaxConcurrentUsers;
/*      */     }
/*      */ 
/*      */     public void setMaxConcurrentUsers(int users) {
/* 4627 */       if (users >= 0)
/* 4628 */         ProxyPlugin.MaxConcurrentUsers = users;
/*      */     }
/*      */ 
/*      */     public int getIdleTimeout() {
/* 4632 */       return ProxyPlugin.idleTimeout;
/*      */     }
/*      */ 
/*      */     public void setIdleTimeout(int timeout) {
/* 4636 */       if (timeout > 0)
/* 4637 */         ProxyPlugin.idleTimeout = timeout;
/*      */     }
/*      */ 
/*      */     public int getSilenceTimeout() {
/* 4641 */       return ProxyPlugin.silenceTimeout;
/*      */     }
/*      */ 
/*      */     public void setSilenceTimeout(int timeout) {
/* 4645 */       if (timeout > 0)
/* 4646 */         ProxyPlugin.silenceTimeout = timeout;
/*      */     }
/*      */ 
/*      */     public int getCurrentUsers() {
/* 4650 */       return ProxyPlugin.this.playerManager.getPlayerCount();
/*      */     }
/*      */ 
/*      */     public int getPeakUsers() {
/* 4654 */       return ProxyPlugin.this.playerManager.getPeakPlayerCount();
/*      */     }
/*      */ 
/*      */     public int getLoginCount() {
/* 4658 */       return ProxyPlugin.this.playerManager.getLoginCount();
/*      */     }
/*      */ 
/*      */     public int getLogoutCount() {
/* 4662 */       return ProxyPlugin.this.playerManager.getLogoutCount();
/*      */     }
/*      */ 
/*      */     public int getClientPort() {
/* 4666 */       return ProxyPlugin.this.clientPort;
/*      */     }
/*      */ 
/*      */     public int getMaxMessagesBeforeConnectionReset() {
/* 4670 */       return ProxyPlugin.maxMessagesBeforeConnectionReset;
/*      */     }
/*      */ 
/*      */     public void setMaxMessagesBeforeConnectionReset(int count) {
/* 4674 */       if (count > 0)
/* 4675 */         ProxyPlugin.maxMessagesBeforeConnectionReset = count;
/*      */     }
/*      */ 
/*      */     public int getMaxByteCountBeforeConnectionReset() {
/* 4679 */       return ProxyPlugin.maxByteCountBeforeConnectionReset;
/*      */     }
/*      */ 
/*      */     public void setMaxByteCountBeforeConnectionReset(int bytes) {
/* 4683 */       if (bytes > 0)
/* 4684 */         ProxyPlugin.maxByteCountBeforeConnectionReset = bytes;
/*      */     }
/*      */ 
/*      */     public String getCapacityErrorMessage() {
/* 4688 */       return ProxyPlugin.this.capacityError;
/*      */     }
/*      */ 
/*      */     public void setCapacityErrorMessage(String errorMessage) {
/* 4692 */       if (errorMessage != null)
/* 4693 */         ProxyPlugin.this.capacityError = errorMessage;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface ProxyJMXMBean
/*      */   {
/*      */     public abstract int getMaxConcurrentUsers();
/*      */ 
/*      */     public abstract void setMaxConcurrentUsers(int paramInt);
/*      */ 
/*      */     public abstract int getIdleTimeout();
/*      */ 
/*      */     public abstract void setIdleTimeout(int paramInt);
/*      */ 
/*      */     public abstract int getSilenceTimeout();
/*      */ 
/*      */     public abstract void setSilenceTimeout(int paramInt);
/*      */ 
/*      */     public abstract int getCurrentUsers();
/*      */ 
/*      */     public abstract int getPeakUsers();
/*      */ 
/*      */     public abstract int getLoginCount();
/*      */ 
/*      */     public abstract int getLogoutCount();
/*      */ 
/*      */     public abstract int getClientPort();
/*      */ 
/*      */     public abstract int getMaxMessagesBeforeConnectionReset();
/*      */ 
/*      */     public abstract void setMaxMessagesBeforeConnectionReset(int paramInt);
/*      */ 
/*      */     public abstract int getMaxByteCountBeforeConnectionReset();
/*      */ 
/*      */     public abstract void setMaxByteCountBeforeConnectionReset(int paramInt);
/*      */ 
/*      */     public abstract String getCapacityErrorMessage();
/*      */ 
/*      */     public abstract void setCapacityErrorMessage(String paramString);
/*      */   }
/*      */ 
/*      */   static class AsyncRPCCallback
/*      */     implements ResponseCallback
/*      */   {
/*      */     Player player;
/*      */     String debugPrefix;
/* 4356 */     int responders = 0;
/*      */ 
/*      */     AsyncRPCCallback(Player player, String debugPrefix)
/*      */     {
/* 4330 */       this.player = player;
/* 4331 */       this.debugPrefix = debugPrefix;
/*      */     }
/*      */ 
/*      */     public synchronized void handleResponse(ResponseMessage response) {
/* 4335 */       this.responders -= 1;
/* 4336 */       Log.debug(this.debugPrefix + ", fromAgent=" + response.getSenderName() + " playerOid=" + this.player.getOid());
/*      */ 
/* 4338 */       if (this.responders == 0)
/* 4339 */         notify();
/*      */     }
/*      */ 
/*      */     public synchronized void waitForResponses(int expectedResponses) {
/* 4343 */       this.responders += expectedResponses;
/* 4344 */       while (this.responders != 0)
/*      */         try {
/* 4346 */           wait();
/*      */         }
/*      */         catch (InterruptedException e)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class PlayerHeartbeat
/*      */     implements ProxyExtensionHook
/*      */   {
/*      */     public void processExtensionEvent(ExtensionMessageEvent event, Player player, ProxyPlugin proxy)
/*      */     {
/* 4319 */       Map props = new HashMap();
/* 4320 */       props.put("ext_msg_subtype", "ao.heartbeat");
/* 4321 */       WorldManagerClient.TargetedExtensionMessage msg = new WorldManagerClient.TargetedExtensionMessage(WorldManagerClient.MSG_TYPE_EXTENSION, player.getOid(), player.getOid(), Boolean.valueOf(false), props);
/*      */ 
/* 4324 */       Engine.getAgent().sendBroadcast(msg);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class PlayerTimeout
/*      */     implements Runnable
/*      */   {
/*      */     private PlayerTimeout()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */       {
/*      */         try
/*      */         {
/* 4289 */           Log.debug("PlayerTimeout thread running..");
/* 4290 */           timeoutPlayers();
/*      */         } catch (Exception e) {
/* 4292 */           Log.exception("PlayerTimeout", e);
/*      */         }
/*      */         try {
/* 4295 */           Thread.sleep(10000L);
/*      */         } catch (InterruptedException e) {
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void timeoutPlayers() {
/* 4302 */       List timedoutPlayers = ProxyPlugin.this.playerManager.getTimedoutPlayers(ProxyPlugin.idleTimeout * 1000, ProxyPlugin.silenceTimeout * 1000);
/*      */ 
/* 4304 */       for (Player player : timedoutPlayers)
/* 4305 */         if (!ProxyPlugin.this.isAdmin(player.getOid())) {
/* 4306 */           Log.info("ProxyPlugin: IDLE_TIMEOUT remote=" + player.getConnection() + " player=" + player);
/*      */ 
/* 4308 */           player.getConnection().close();
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceEntryReqHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     InstanceEntryReqHook()
/*      */     {
/* 3823 */       super();
/*      */     }
/* 3825 */     public void processMessage(Message msg, int flags, Player player) { InstanceClient.InstanceEntryReqMessage entryMessage = (InstanceClient.InstanceEntryReqMessage)msg;
/*      */ 
/* 3827 */       ProxyPlugin.InstanceEntryState state = (ProxyPlugin.InstanceEntryState)entryMessage.getProcessingState();
/*      */ 
/* 3829 */       if (state == null) {
/* 3830 */         state = new ProxyPlugin.InstanceEntryState();
/* 3831 */         entryMessage.setProcessingState(state);
/*      */       }
/*      */ 
/* 3841 */       if (state.step == 1)
/* 3842 */         entryStep1(entryMessage, state, player);
/* 3843 */       else if (state.step == 2)
/* 3844 */         entryStep2(entryMessage, state, player);
/*      */     }
/*      */ 
/*      */     protected void entryStep1(InstanceClient.InstanceEntryReqMessage entryMessage, ProxyPlugin.InstanceEntryState state, Player player)
/*      */     {
/* 3850 */       BasicWorldNode destination = entryMessage.getWorldNode();
/* 3851 */       int entryFlags = entryMessage.getFlags();
/*      */ 
/* 3853 */       String flagStr = "";
/* 3854 */       if ((entryFlags & 0x1) != 0)
/* 3855 */         flagStr = flagStr + "push,";
/* 3856 */       if ((entryFlags & 0x2) != 0) {
/* 3857 */         flagStr = flagStr + "pop,";
/*      */       }
/* 3859 */       Log.info("ProxyPlugin: INSTANCE_BEGIN player=" + player + " destination=" + destination + " flags=" + flagStr);
/*      */ 
/* 3862 */       if (((entryFlags & 0x1) != 0) && ((entryFlags & 0x2) != 0))
/*      */       {
/* 3864 */         Log.error("InstanceEntryReqHook: push and pop flags cannot be combined oid=" + player.getOid());
/*      */ 
/* 3866 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3868 */         return;
/*      */       }
/*      */ 
/* 3871 */       if (((entryFlags & 0x1) != 0) && 
/* 3872 */         (destination == null)) {
/* 3873 */         Log.error("InstanceEntryReqHook: push without destination oid=" + player.getOid());
/*      */ 
/* 3875 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3877 */         return;
/*      */       }
/*      */ 
/* 3880 */       if (((entryFlags & 0x2) != 0) && 
/* 3881 */         (destination != null)) {
/* 3882 */         Log.error("InstanceEntryReqHook: pop with destination oid=" + player.getOid());
/*      */ 
/* 3884 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3886 */         return;
/*      */       }
/*      */ 
/* 3890 */       if (player.getStatus() != 2) {
/* 3891 */         Log.error("InstanceEntryReqHook: invalid player status " + player);
/*      */ 
/* 3893 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3895 */         return;
/*      */       }
/*      */ 
/* 3898 */       if ((entryFlags & 0x2) != 0)
/*      */       {
/* 3900 */         LinkedList restoreStack = (LinkedList)EnginePlugin.getObjectProperty(player.getOid(), Namespace.OBJECT_MANAGER, "instanceStack");
/*      */ 
/* 3905 */         if ((restoreStack == null) || (restoreStack.size() == 0)) {
/* 3906 */           Log.error("InstanceEntryReqHook: player has no stack to pop " + player);
/*      */ 
/* 3908 */           Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3910 */           return;
/*      */         }
/* 3912 */         state.restoreStack = restoreStack;
/* 3913 */         InstanceRestorePoint restorePoint = (InstanceRestorePoint)restoreStack.get(restoreStack.size() - 1);
/*      */ 
/* 3915 */         if (restoreStack.size() == 1) {
/* 3916 */           if (restorePoint.getFallbackFlag()) {
/* 3917 */             Log.warn("InstanceEntryReqHook: popping to fallback restore point " + player);
/*      */           }
/*      */           else {
/* 3920 */             Log.warn("InstanceEntryReqHook: popping last instance restore point " + player);
/*      */           }
/*      */         }
/* 3923 */         destination = new BasicWorldNode();
/* 3924 */         OID instanceOid = restorePoint.getInstanceOid();
/* 3925 */         if (restorePoint.getInstanceName() != null) {
/* 3926 */           instanceOid = ProxyPlugin.this.instanceEntryCallback.selectInstance(player, restorePoint.getInstanceName());
/*      */         }
/*      */ 
/* 3929 */         if (instanceOid != null) {
/* 3930 */           destination.setInstanceOid(instanceOid);
/* 3931 */           destination.setLoc(restorePoint.getLoc());
/* 3932 */           destination.setOrientation(restorePoint.getOrientation());
/* 3933 */           destination.setDir(new AOVector(0.0F, 0.0F, 0.0F));
/*      */         }
/* 3935 */         entryMessage.setWorldNode(destination);
/*      */       }
/*      */ 
/* 3938 */       if (!ProxyPlugin.this.instanceEntryAllowed(player.getOid(), destination.getInstanceOid(), destination.getLoc()))
/*      */       {
/* 3940 */         Log.info("ProxyPlugin: INSTANCE_REJECT player=" + player + " current=" + state.previousLoc + " destination=" + destination);
/*      */ 
/* 3943 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3945 */         return;
/*      */       }
/*      */ 
/* 3948 */       state.instanceInfo = InstanceClient.getInstanceInfo(destination.getInstanceOid(), -8193);
/*      */ 
/* 3951 */       if (state.instanceInfo.oid == null) {
/* 3952 */         Log.error("InstanceEntryReqHook: unknown instanceOid=" + destination.getInstanceOid());
/*      */ 
/* 3954 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3956 */         return;
/*      */       }
/*      */ 
/* 3959 */       if ((state.instanceInfo.populationLimit > 0) && (state.instanceInfo.playerPopulation >= state.instanceInfo.populationLimit)) {
/* 3960 */         Log.debug("POP: got population: " + state.instanceInfo.playerPopulation + " and limit: " + state.instanceInfo.populationLimit);
/* 3961 */         OID instanceOid = ProxyPlugin.handleFullInstance(state.instanceInfo.templateName, state.instanceInfo);
/* 3962 */         destination.setInstanceOid(instanceOid);
/* 3963 */         state.instanceInfo = InstanceClient.getInstanceInfo(destination.getInstanceOid(), -8193);
/*      */       }
/*      */ 
/* 3967 */       if (Log.loggingDebug) {
/* 3968 */         Log.debug("InstanceEntryReqHook: instance terrain config: " + state.instanceInfo.terrainConfig);
/*      */       }
/*      */ 
/* 3971 */       WorldManagerClient.TargetedExtensionMessage instanceBegin = new WorldManagerClient.TargetedExtensionMessage(player.getOid(), player.getOid());
/*      */ 
/* 3973 */       instanceBegin.setExtensionType("ao.SCENE_BEGIN");
/* 3974 */       instanceBegin.setProperty("action", "instance");
/* 3975 */       instanceBegin.setProperty("name", state.instanceInfo.name);
/*      */ 
/* 3977 */       instanceBegin.setProperty("templateName", state.instanceInfo.templateName);
/*      */ 
/* 3982 */       boolean rc = WorldManagerClient.despawn(player.getOid(), instanceBegin, null);
/*      */ 
/* 3984 */       if (!rc) {
/* 3985 */         Log.error("InstanceEntryReqHook: despawn failed " + player);
/* 3986 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 3988 */         return;
/*      */       }
/*      */ 
/* 3992 */       state.previousLoc = WorldManagerClient.getWorldNode(player.getOid());
/*      */ 
/* 3995 */       Log.info("ProxyPlugin: INSTANCE_STEP1 player=" + player + " current=" + state.previousLoc + " destination=" + destination + " destName=" + state.instanceInfo.name);
/*      */ 
/* 4001 */       ArrayList unloadWM = new ArrayList(1);
/* 4002 */       unloadWM.add(WorldManagerClient.NAMESPACE);
/* 4003 */       rc = ObjectManagerClient.unloadSubObject(player.getOid(), unloadWM).booleanValue();
/* 4004 */       if (!rc) {
/* 4005 */         Log.error("InstanceEntryReqHook: unload wm sub-object failed " + player);
/*      */ 
/* 4007 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 4009 */         return;
/*      */       }
/* 4011 */       state.step = 2;
/* 4012 */       ProxyPlugin.this.messageQQ.insert(player, entryMessage);
/*      */     }
/*      */ 
/*      */     protected void entryStep2(InstanceClient.InstanceEntryReqMessage entryMessage, ProxyPlugin.InstanceEntryState state, Player player)
/*      */     {
/* 4018 */       int entryFlags = entryMessage.getFlags();
/* 4019 */       ClientConnection con = player.getConnection();
/* 4020 */       BasicWorldNode destination = entryMessage.getWorldNode();
/* 4021 */       BasicWorldNode previousLoc = state.previousLoc;
/*      */ 
/* 4023 */       BasicWorldNode restoreLoc = null;
/* 4024 */       if ((entryFlags & 0x1) != 0) {
/* 4025 */         restoreLoc = entryMessage.getRestoreNode();
/* 4026 */         if (restoreLoc == null)
/* 4027 */           restoreLoc = previousLoc; 
/*      */       }
/*      */       InstanceClient.InstanceInfo instanceInfo;
/*      */       while (true) {
/* 4031 */         boolean rc = ObjectManagerClient.fixWorldNode(player.getOid(), destination);
/*      */ 
/* 4033 */         if (!rc) {
/* 4034 */           Log.error("InstanceEntryReqHook: fixWorldNode failed " + player + " node=" + destination);
/*      */ 
/* 4036 */           Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 4038 */           return;
/*      */         }
/*      */ 
/* 4041 */         instanceInfo = InstanceClient.getInstanceInfo(destination.getInstanceOid(), 2);
/*      */ 
/* 4044 */         EnginePlugin.setObjectProperty(player.getOid(), Namespace.OBJECT_MANAGER, "currentInstanceName", instanceInfo.name);
/*      */ 
/* 4052 */         Log.debug("instanceReq: sending template (scene) name: " + state.instanceInfo.templateName);
/*      */ 
/* 4055 */         Event worldFileEvent = new WorldFileEvent(state.instanceInfo.templateName, destination.getLoc());
/* 4056 */         con.send(worldFileEvent.toBytes());
/*      */ 
/* 4061 */         WorldManagerClient.WorldNodeCorrectMessage correctMsg = new WorldManagerClient.WorldNodeCorrectMessage(player.getOid(), destination);
/*      */ 
/* 4063 */         con.send(correctMsg.toBuffer());
/*      */ 
/* 4065 */         if ((entryFlags & 0x1) != 0) {
/* 4066 */           ProxyPlugin.this.pushInstanceRestorePoint(player, restoreLoc);
/*      */         }
/* 4068 */         WorldManagerClient.TargetedExtensionMessage instanceEnd = new WorldManagerClient.TargetedExtensionMessage(player.getOid(), player.getOid());
/*      */ 
/* 4070 */         instanceEnd.setExtensionType("ao.SCENE_END");
/* 4071 */         instanceEnd.setProperty("action", "instance");
/* 4072 */         instanceEnd.setProperty("name", state.instanceInfo.name);
/*      */ 
/* 4074 */         instanceEnd.setProperty("templateName", state.instanceInfo.templateName);
/*      */ 
/* 4078 */         ArrayList loadWM = new ArrayList(1);
/* 4079 */         loadWM.add(WorldManagerClient.NAMESPACE);
/* 4080 */         OID oid = ObjectManagerClient.loadSubObject(player.getOid(), loadWM);
/*      */ 
/* 4082 */         if (oid == null) {
/* 4083 */           Log.error("InstanceEntryReqHook: load wm sub-object failed " + player);
/*      */ 
/* 4085 */           if ((previousLoc != null) && (destination != previousLoc)) {
/* 4086 */             Log.error("InstanceEntryReqHook: attempting to restore previous location " + player + " previous=" + previousLoc);
/*      */ 
/* 4088 */             destination = previousLoc;
/* 4089 */             entryFlags &= -3;
/* 4090 */             continue;
/*      */           }
/*      */         }
/*      */ 
/* 4094 */         Integer result = WorldManagerClient.spawn(player.getOid(), null, instanceEnd);
/*      */ 
/* 4096 */         if (result.intValue() >= 0) break;
/* 4097 */         Log.error("InstanceEntryReqHook: spawn failed " + player);
/* 4098 */         if ((result.intValue() == -2) && (previousLoc != null) && (destination != previousLoc))
/*      */         {
/* 4100 */           Log.error("InstanceEntryReqHook: attempting to restore previous location " + player + " previous=" + previousLoc);
/*      */ 
/* 4102 */           destination = previousLoc;
/* 4103 */           entryFlags &= -3;
/* 4104 */           continue;
/*      */         }
/* 4106 */         Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.FALSE);
/*      */ 
/* 4108 */         return;
/*      */       }
/*      */ 
/* 4117 */       WorldManagerClient.correctWorldNode(player.getOid(), destination);
/*      */ 
/* 4120 */       ProxyPlugin.this.updateInstancePerception(player.getOid(), previousLoc.getInstanceOid(), destination.getInstanceOid(), instanceInfo.name);
/*      */ 
/* 4127 */       Log.info("ProxyPlugin: INSTANCE_END player=" + player + " destination=" + destination);
/*      */ 
/* 4131 */       if ((entryFlags & 0x2) != 0) {
/* 4132 */         LinkedList restoreStack = state.restoreStack;
/* 4133 */         InstanceRestorePoint top = (InstanceRestorePoint)restoreStack.get(restoreStack.size() - 1);
/*      */ 
/* 4135 */         if (!top.getFallbackFlag()) {
/* 4136 */           restoreStack.remove(restoreStack.size() - 1);
/* 4137 */           EnginePlugin.setObjectProperty(player.getOid(), Namespace.OBJECT_MANAGER, "instanceStack", restoreStack);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4144 */       ProxyPlugin.access$1008(ProxyPlugin.this);
/* 4145 */       Engine.getAgent().sendBooleanResponse(entryMessage, Boolean.TRUE);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class InstanceEntryState
/*      */   {
/* 3814 */     int step = 1;
/*      */     InstanceClient.InstanceInfo instanceInfo;
/*      */     LinkedList restoreStack;
/*      */     BasicWorldNode previousLoc;
/*      */   }
/*      */ 
/*      */   private class AccountLoginHook
/*      */     implements Hook
/*      */   {
/*      */     private AccountLoginHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 3800 */       Log.debug("AccountLoginHook hit");
/* 3801 */       GenericMessage tMsg = (GenericMessage)msg;
/* 3802 */       OID accountId = (OID)tMsg.getProperty("accountId");
/* 3803 */       Log.debug("AccountLoginHook accountId=" + accountId + "; map=" + ProxyPlugin.this.clientConnections);
/* 3804 */       if (ProxyPlugin.this.clientConnections.containsKey(accountId)) {
/* 3805 */         Log.debug("Closing client connection");
/* 3806 */         ((ClientConnection)ProxyPlugin.this.clientConnections.get(accountId)).close();
/* 3807 */         ProxyPlugin.this.clientConnections.remove(accountId);
/*      */       }
/* 3809 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class LogoutPlayerRPCThread
/*      */     implements Runnable
/*      */   {
/*      */     private Player player;
/*      */     private Message message;
/*      */ 
/*      */     public LogoutPlayerRPCThread(Message message, Player player)
/*      */     {
/* 3743 */       this.player = player;
/* 3744 */       this.message = message;
/*      */     }
/*      */ 
/*      */     public void run() {
/* 3748 */       Log.debug("[CYC] ProxyPlugin.LogoutPlayerRPCThread.run(): start");
/*      */       try {
/* 3750 */         Log.debug("[CYC] ProxyPlugin.LogoutPlayerRPCThread.run(): try { logoutPlayer(); }");
/* 3751 */         logoutPlayer();
/*      */       } catch (Exception e) {
/* 3753 */         Log.exception("LogoutPlayer", e);
/* 3754 */         Engine.getAgent().sendObjectResponse(this.message, null);
/*      */       }
/* 3756 */       Log.debug("[CYC] ProxyPlugin.LogoutPlayerRPCThread.run(): done");
/*      */     }
/*      */ 
/*      */     public void logoutPlayer() {
/* 3760 */       Log.debug("[CYC] ProxyPlugin.LogoutPlayerRPCThread.logoutPlayer(): start");
/* 3761 */       ProxyPlugin.PlayerLoginStatus loginStatus = new ProxyPlugin.PlayerLoginStatus();
/* 3762 */       loginStatus.oid = this.player.getOid();
/* 3763 */       loginStatus.status = this.player.getStatus();
/* 3764 */       loginStatus.name = this.player.getName();
/* 3765 */       loginStatus.clientCon = this.player.getConnection().toString();
/* 3766 */       loginStatus.proxyPluginName = ProxyPlugin.this.getName();
/*      */ 
/* 3769 */       WorldManagerClient.ComMessage comMessage = new WorldManagerClient.ComMessage(this.player.getOid(), "", 0, "Your player logged in from a different location.");
/*      */ 
/* 3772 */       this.player.getConnection().sendInternal(comMessage.toBuffer());
/*      */       try {
/* 3774 */         Thread.sleep(20L);
/*      */       } catch (InterruptedException ignore) {
/*      */       }
/* 3777 */       this.player.getConnection().close();
/*      */ 
/* 3779 */       synchronized (this.player) {
/* 3780 */         while (this.player.getConnection() != null)
/*      */           try {
/* 3782 */             this.player.wait();
/*      */           }
/*      */           catch (InterruptedException ignore) {
/*      */           }
/*      */       }
/* 3787 */       Log.debug("[CYC] ProxyPlugin.LogoutPlayerRPCThread.logoutPlayer(): Engine.getAgent().sendObjectResponse() message=" + this.message + ", loginStatus=" + loginStatus);
/*      */ 
/* 3789 */       Engine.getAgent().sendObjectResponse(this.message, loginStatus);
/* 3790 */       Log.debug("[CYC] ProxyPlugin.LogoutPlayerRPCThread.logoutPlayer(): done");
/*      */     }
/*      */   }
/*      */ 
/*      */   private class LogoutPlayerHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     private LogoutPlayerHook()
/*      */     {
/* 3734 */       super();
/*      */     }
/* 3736 */     public void processMessage(Message message, int flags, Player player) { new Thread(new ProxyPlugin.LogoutPlayerRPCThread(ProxyPlugin.this, message, player), "LogoutPlayer" + player.getOid()).start();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class GetPlayerLoginStatusHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     private GetPlayerLoginStatusHook()
/*      */     {
/* 3720 */       super();
/*      */     }
/* 3722 */     public void processMessage(Message msg, int flags, Player player) { Log.debug("GetPlayerLoginStatusHook: player=" + player);
/* 3723 */       ProxyPlugin.PlayerLoginStatus loginStatus = new ProxyPlugin.PlayerLoginStatus();
/* 3724 */       loginStatus.oid = player.getOid();
/* 3725 */       loginStatus.status = player.getStatus();
/* 3726 */       loginStatus.name = player.getName();
/* 3727 */       loginStatus.clientCon = player.getConnection().toString();
/* 3728 */       loginStatus.proxyPluginName = ProxyPlugin.this.getName();
/* 3729 */       Log.debug("GetPlayerLoginStatusHook: response=" + loginStatus);
/* 3730 */       Engine.getAgent().sendObjectResponse(msg, loginStatus);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class PlayerLoginStatus
/*      */   {
/*      */     public OID oid;
/*      */     public int status;
/*      */     public String name;
/*      */     public String clientCon;
/*      */     public String proxyPluginName;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public String toString()
/*      */     {
/* 3702 */       return "[PlayerLoginStatus: oid=" + this.oid + ", status=" + this.status + ", name=" + this.name + ", proxyPluginName=" + this.proxyPluginName + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetPluginStatusHook
/*      */     implements Hook
/*      */   {
/*      */     GetPluginStatusHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 3684 */       LinkedHashMap status = new LinkedHashMap();
/* 3685 */       status.put("plugin", ProxyPlugin.this.getName());
/* 3686 */       status.put("user", Integer.valueOf(ProxyPlugin.this.playerManager.getPlayerCount()));
/* 3687 */       status.put("login", Integer.valueOf(ProxyPlugin.this.playerManager.getLoginCount()));
/* 3688 */       status.put("login_sec", Integer.valueOf(ProxyPlugin.this.playerManager.getLoginSeconds()));
/* 3689 */       status.put("instance_entry", Integer.valueOf(ProxyPlugin.this.instanceEntryCount));
/* 3690 */       status.put("chat", Integer.valueOf(ProxyPlugin.this.chatSentCount));
/* 3691 */       status.put("private_chat", Integer.valueOf(ProxyPlugin.this.privateChatSentCount));
/* 3692 */       Engine.getAgent().sendObjectResponse(msg, status);
/* 3693 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class AbilityUpdateHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     AbilityUpdateHook()
/*      */     {
/* 3670 */       super();
/*      */     }
/* 3672 */     public void processMessage(Message msg, int flags, Player player) { CombatClient.AbilityUpdateMessage pMsg = (CombatClient.AbilityUpdateMessage)msg;
/* 3673 */       if (Log.loggingDebug) {
/* 3674 */         ProxyPlugin.log.debug("AbilityUpdateHook: got AbilityUpdate message: " + msg);
/*      */       }
/*      */ 
/* 3677 */       ClientConnection con = player.getConnection();
/* 3678 */       con.send(pMsg.toBuffer());
/*      */     }
/*      */   }
/*      */ 
/*      */   class RoadHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     RoadHook()
/*      */     {
/* 3653 */       super();
/*      */     }
/* 3655 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.RoadMessage roadMsg = (WorldManagerClient.RoadMessage)msg;
/* 3656 */       Set roads = roadMsg.getRoads();
/* 3657 */       if (Log.loggingDebug)
/* 3658 */         ProxyPlugin.log.debug("RoadHook: got " + roads.size() + " roads");
/* 3659 */       OID targetOid = roadMsg.getTarget();
/* 3660 */       ClientConnection con = player.getConnection();
/* 3661 */       List bufList = roadMsg.toBuffer();
/* 3662 */       for (AOByteBuffer buf : bufList) {
/* 3663 */         con.send(buf);
/*      */       }
/* 3665 */       if (Log.loggingDebug)
/* 3666 */         ProxyPlugin.log.debug("RoadHook: sent new roads to targetOid " + targetOid);
/*      */     }
/*      */   }
/*      */ 
/*      */   class FogHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     FogHook()
/*      */     {
/* 3631 */       super();
/*      */     }
/* 3633 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.FogMessage fogMsg = (WorldManagerClient.FogMessage)msg;
/* 3634 */       FogRegionConfig fogConfig = fogMsg.getFogConfig();
/* 3635 */       OID targetOid = fogMsg.getTarget();
/* 3636 */       ClientConnection con = player.getConnection();
/*      */ 
/* 3638 */       WorldManagerClient.FogMessage fogMessage = new WorldManagerClient.FogMessage(null, fogConfig);
/* 3639 */       con.send(fogMessage.toBuffer());
/* 3640 */       if (Log.loggingDebug)
/* 3641 */         ProxyPlugin.log.debug("FogHook: sending new fog to targetOid " + targetOid + fogConfig);
/*      */     }
/*      */   }
/*      */ 
/*      */   class InvUpdateHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     InvUpdateHook()
/*      */     {
/* 3615 */       super();
/*      */     }
/* 3617 */     public void processMessage(Message msg, int flags, Player player) { InventoryClient.InvUpdateMessage uMsg = (InventoryClient.InvUpdateMessage)msg;
/*      */ 
/* 3620 */       if (!player.getOid().equals(uMsg.getSubject()))
/* 3621 */         return;
/* 3622 */       ClientConnection con = player.getConnection();
/* 3623 */       if (Log.loggingDebug) {
/* 3624 */         ProxyPlugin.log.debug("InvUpdateHook: sending update to player " + player.getOid() + " msgOid=" + uMsg.getSubject());
/*      */       }
/*      */ 
/* 3627 */       con.send(uMsg.toBuffer());
/*      */     }
/*      */   }
/*      */ 
/*      */   class SoundHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     SoundHook()
/*      */     {
/* 3601 */       super();
/*      */     }
/* 3603 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.SoundMessage sMsg = (WorldManagerClient.SoundMessage)msg;
/*      */ 
/* 3606 */       OID target = sMsg.getTarget();
/* 3607 */       if ((target != null) && (!target.equals(player.getOid()))) {
/* 3608 */         return;
/*      */       }
/* 3610 */       ClientConnection con = player.getConnection();
/* 3611 */       con.send(sMsg.toBuffer());
/*      */     }
/*      */   }
/*      */ 
/*      */   class OrientHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     OrientHook()
/*      */     {
/* 3586 */       super();
/*      */     }
/* 3588 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.OrientMessage oMsg = (WorldManagerClient.OrientMessage)msg;
/*      */ 
/* 3591 */       AOByteBuffer buf = oMsg.toBuffer();
/*      */ 
/* 3593 */       ClientConnection con = player.getConnection();
/* 3594 */       con.send(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   class WNodeCorrectHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     WNodeCorrectHook()
/*      */     {
/* 3567 */       super();
/*      */     }
/* 3569 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.WorldNodeCorrectMessage wMsg = (WorldManagerClient.WorldNodeCorrectMessage)msg;
/*      */ 
/* 3571 */       OID oid = wMsg.getSubject();
/*      */ 
/* 3573 */       if (Log.loggingDebug) {
/* 3574 */         ProxyPlugin.log.debug("WNodeCorrectHook.processMessage: oid=" + oid + ", msg=" + msg);
/*      */       }
/*      */ 
/* 3580 */       AOByteBuffer buf = wMsg.toBuffer();
/* 3581 */       ClientConnection con = player.getConnection();
/* 3582 */       con.send(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   class UpdateMobPathHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     UpdateMobPathHook()
/*      */     {
/* 3554 */       super();
/*      */     }
/* 3556 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.MobPathMessage pathMsg = (WorldManagerClient.MobPathMessage)msg;
/* 3557 */       OID subjectOid = pathMsg.getSubject();
/* 3558 */       if (Log.loggingDebug) {
/* 3559 */         ProxyPlugin.log.debug("UpdateMobPathHook.processMessage: subjectOid=" + subjectOid + ", msg=" + msg);
/*      */       }
/* 3561 */       AOByteBuffer buf = pathMsg.toBuffer();
/* 3562 */       ClientConnection con = player.getConnection();
/* 3563 */       con.send(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   class UpdateWNodeHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     UpdateWNodeHook()
/*      */     {
/* 3532 */       super();
/*      */     }
/* 3534 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.UpdateWorldNodeMessage wMsg = (WorldManagerClient.UpdateWorldNodeMessage)msg;
/* 3535 */       OID subjectOid = wMsg.getSubject();
/* 3536 */       OID playerOid = player.getOid();
/* 3537 */       if (Log.loggingDebug) {
/* 3538 */         Log.debug("UpdateWNodeHook.processMessage: subjectOid=" + subjectOid + ", playerOid=" + playerOid + " msg=" + msg);
/*      */       }
/*      */ 
/* 3541 */       if (playerOid.equals(subjectOid))
/*      */       {
/* 3543 */         if (Log.loggingDebug) {
/* 3544 */           Log.debug("UpdateWNodeHook.processMessage: subjectOid=" + subjectOid + ", ignoring msg since playerOid matches subjectOid");
/*      */         }
/*      */ 
/* 3547 */         return;
/*      */       }
/*      */ 
/* 3550 */       player.getConnection().send(wMsg.getEventBuf());
/*      */     }
/*      */   }
/*      */ 
/*      */   class SysChatHook
/*      */     implements Hook
/*      */   {
/*      */     SysChatHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 3516 */       WorldManagerClient.SysChatMessage sysMsg = (WorldManagerClient.SysChatMessage)msg;
/*      */ 
/* 3518 */       AOByteBuffer buf = sysMsg.toBuffer();
/*      */ 
/* 3520 */       if (Log.loggingDebug)
/* 3521 */         ProxyPlugin.log.debug("syschathook:\t " + sysMsg.getString());
/* 3522 */       Collection players = new ArrayList(ProxyPlugin.this.playerManager.getPlayerCount());
/*      */ 
/* 3524 */       ProxyPlugin.this.playerManager.getPlayers(players);
/* 3525 */       for (Player pp : players) {
/* 3526 */         pp.getConnection().send(buf);
/*      */       }
/* 3528 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DamageHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     DamageHook()
/*      */     {
/* 3495 */       super();
/*      */     }
/* 3497 */     public void processMessage(Message msg, int flags, Player player) { CombatClient.DamageMessage dmgMsg = (CombatClient.DamageMessage)msg;
/*      */ 
/* 3499 */       OID attackerOid = dmgMsg.getAttackerOid();
/* 3500 */       OID targetOid = dmgMsg.getTargetOid();
/*      */ 
/* 3503 */       AOByteBuffer buf = dmgMsg.toBuffer();
/*      */ 
/* 3505 */       ClientConnection con = player.getConnection();
/* 3506 */       if (Log.loggingDebug) {
/* 3507 */         ProxyPlugin.log.debug("DamageHook: attackerOid= " + attackerOid + ", attacks targetOid=" + targetOid + " for " + dmgMsg.getDmg() + " damage");
/*      */       }
/*      */ 
/* 3510 */       con.send(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   class ComHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     ComHook()
/*      */     {
/* 3452 */       super();
/*      */     }
/* 3454 */     public void processMessage(Message msg, int flags, Player player) { AOByteBuffer buf = null;
/* 3455 */       if ((msg instanceof WorldManagerClient.ComMessage)) {
/* 3456 */         WorldManagerClient.ComMessage comMsg = (WorldManagerClient.ComMessage)msg;
/* 3457 */         OID oid = comMsg.getSubject();
/* 3458 */         if (player.oidIgnored(oid)) {
/* 3459 */           if (Log.loggingDebug) {
/* 3460 */             Log.debug("ComHook.processMessage: Ignoring chat from player " + oid + " to player " + player.getOid() + " because originator is in the player's ignored list");
/*      */           }
/*      */ 
/* 3465 */           return;
/*      */         }
/* 3467 */         buf = comMsg.toBuffer();
/* 3468 */         Log.info("ProxyPlugin: CHAT_RECV player=" + player + " from=" + comMsg.getSubject() + " private=false" + " msg=[" + comMsg.getString() + "]");
/*      */       }
/* 3471 */       else if ((msg instanceof WorldManagerClient.TargetedComMessage)) {
/* 3472 */         WorldManagerClient.TargetedComMessage comMsg = (WorldManagerClient.TargetedComMessage)msg;
/* 3473 */         OID oid = comMsg.getSubject();
/* 3474 */         if (player.oidIgnored(oid)) {
/* 3475 */           if (Log.loggingDebug) {
/* 3476 */             Log.debug("ComHook.processMessage: Ignoring chat from player " + oid + " to player " + player.getOid() + " because originator is in the player's ignored list");
/*      */           }
/*      */ 
/* 3481 */           return;
/*      */         }
/* 3483 */         buf = comMsg.toBuffer();
/* 3484 */         Log.info("ProxyPlugin: CHAT_RECV player=" + player + " from=" + comMsg.getSubject() + " private=true" + " msg=[" + comMsg.getString() + "]");
/*      */       }
/*      */       else
/*      */       {
/* 3488 */         return;
/*      */       }
/* 3490 */       ClientConnection con = player.getConnection();
/* 3491 */       con.send(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   class PlayerPathReqHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     PlayerPathReqHook()
/*      */     {
/* 3432 */       super();
/*      */     }
/* 3434 */     public void processMessage(Message msg, int flags, Player player) { OID playerOid = player.getOid();
/* 3435 */       BasicWorldNode wnode = WorldManagerClient.getWorldNode(playerOid);
/* 3436 */       WorldManagerClient.ExtensionMessage extMsg = (WorldManagerClient.ExtensionMessage)msg;
/* 3437 */       WorldManagerClient.PlayerPathWMReqMessage reqMsg = new WorldManagerClient.PlayerPathWMReqMessage(playerOid, wnode.getInstanceOid(), (String)extMsg.getProperty("room_id"), (AOVector)extMsg.getProperty("start"), ((Float)extMsg.getProperty("speed")).floatValue(), (Quaternion)extMsg.getProperty("start_orient"), (AOVector)extMsg.getProperty("dest"), (Quaternion)extMsg.getProperty("dest_orient"), (List)extMsg.getProperty("boundary"), (List)extMsg.getProperty("obstacles"), ((Float)extMsg.getProperty("avatar_width")).floatValue());
/*      */ 
/* 3448 */       Engine.getAgent().sendBroadcast(reqMsg);
/*      */     }
/*      */   }
/*      */ 
/*      */   class PlayerIgnoreListReqHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     PlayerIgnoreListReqHook()
/*      */     {
/* 3415 */       super();
/*      */     }
/*      */ 
/*      */     public void processMessage(Message msg, int flags, Player player)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetMatchingPlayersHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     GetMatchingPlayersHook()
/*      */     {
/* 3364 */       super();
/*      */     }
/* 3366 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.TargetedExtensionMessage extMsg = (WorldManagerClient.TargetedExtensionMessage)msg;
/* 3367 */       String playerName = (String)extMsg.getProperty("player_name");
/* 3368 */       Boolean exactMatch = (Boolean)extMsg.getProperty("exact_match");
/* 3369 */       boolean match = exactMatch == null ? true : exactMatch.booleanValue();
/* 3370 */       List matchLists = Engine.getDatabase().getOidsAndNamesMatchingName(playerName, match);
/*      */ 
/* 3372 */       WorldManagerClient.TargetedExtensionMessage response = new WorldManagerClient.TargetedExtensionMessage("player_ignore_list", player.getOid());
/*      */ 
/* 3374 */       response.setSubject(player.getOid());
/* 3375 */       List oids = (List)matchLists.get(0);
/* 3376 */       List names = (List)matchLists.get(1);
/* 3377 */       response.setProperty("ignored_oids", (Serializable)oids);
/* 3378 */       response.setProperty("ignored_player_names", (Serializable)names);
/* 3379 */       if (Log.loggingDebug) {
/* 3380 */         ProxyPlugin.log.debug(new StringBuilder().append("ProxyPlugin.GetMatchingPlayersHook: For player ").append(player.getOid()).append(", found ").append(oids == null ? 0 : oids.size()).append(" players: ").append(Database.makeOidCollectionString(oids)).append(" ").append(match ? "exactly matching" : "starting with").append(" name '").append(playerName).append("':").append(Database.makeNameCollectionString(names)).toString());
/*      */       }
/*      */ 
/* 3387 */       player.getConnection().send(response.toBuffer(player.getVersion()));
/*      */     }
/*      */   }
/*      */ 
/*      */   class UpdatePlayerIgnoreListHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     UpdatePlayerIgnoreListHook()
/*      */     {
/* 3315 */       super();
/*      */     }
/* 3317 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.TargetedExtensionMessage extMsg = (WorldManagerClient.TargetedExtensionMessage)msg;
/* 3318 */       LinkedList nowIgnored = (LinkedList)extMsg.getProperty("now_ignored");
/*      */ 
/* 3320 */       LinkedList noLongerIgnored = (LinkedList)extMsg.getProperty("no_longer_ignored");
/*      */ 
/* 3322 */       ProxyPlugin.this.updateIgnoredOids(player, nowIgnored, noLongerIgnored);
/*      */     }
/*      */   }
/*      */ 
/*      */   class VoiceParmsHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     VoiceParmsHook()
/*      */     {
/* 3227 */       super();
/*      */     }
/*      */     public void processMessage(Message msg, int flags, Player player) {
/* 3230 */       WorldManagerClient.TargetedExtensionMessage extMsg = new WorldManagerClient.TargetedExtensionMessage("voice_parms_response", player.getOid());
/*      */ 
/* 3232 */       extMsg.setProperty("host", ProxyPlugin.voiceServerHost);
/* 3233 */       extMsg.setProperty("port", ProxyPlugin.voiceServerPort);
/*      */ 
/* 3235 */       SecureTokenSpec tokenSpec = new SecureTokenSpec(2, Engine.getAgent().getName(), System.currentTimeMillis() + 30000L);
/*      */ 
/* 3238 */       tokenSpec.setProperty("player_oid", player.getOid());
/* 3239 */       byte[] authToken = SecureTokenManager.getInstance().generateToken(tokenSpec);
/*      */ 
/* 3241 */       extMsg.setProperty("auth_token", Base64.encodeBytes(authToken));
/*      */ 
/* 3244 */       ClientConnection con = player.getConnection();
/*      */ 
/* 3247 */       AOByteBuffer buf = extMsg.toBuffer(player.getVersion());
/* 3248 */       if (buf != null) {
/* 3249 */         con.send(buf);
/* 3250 */         if (Log.loggingDebug)
/* 3251 */           ProxyPlugin.log.debug("VoiceParmsHook: sent voice_parm_response ext msg for player " + player.getOid());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class RemoveStaticPerceptionHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     private RemoveStaticPerceptionHook()
/*      */     {
/* 3205 */       super();
/*      */     }
/* 3207 */     public void processMessage(Message msg, int flags, Player player) { TargetMessage message = (TargetMessage)msg;
/* 3208 */       boolean proxyPerceptionLoss = ProxyPlugin.this.playerManager.removeStaticPerception(player, message.getSubject());
/*      */ 
/* 3210 */       Log.debug("ProxyPlugin.RemoveStaticPerceptionHook(): proxyPerceptionLoss = " + proxyPerceptionLoss + ", playerOid=" + player.getOid() + ", oid=" + message.getSubject());
/*      */ 
/* 3214 */       if (proxyPerceptionLoss) {
/* 3215 */         FilterUpdate proxyPerceptionUpdate = new FilterUpdate(1);
/* 3216 */         proxyPerceptionUpdate.removeFieldValue(2, message.getSubject());
/*      */ 
/* 3218 */         Engine.getAgent().applyFilterUpdate(ProxyPlugin.this.perceptionSubId, proxyPerceptionUpdate, 0);
/*      */       }
/*      */ 
/* 3221 */       NotifyFreeObjectEvent freeEvent = new NotifyFreeObjectEvent(player.getOid(), message.getSubject());
/*      */ 
/* 3223 */       player.getConnection().send(freeEvent.toBytes());
/*      */     }
/*      */   }
/*      */ 
/*      */   private class AddStaticPerceptionHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     private AddStaticPerceptionHook()
/*      */     {
/* 3157 */       super();
/*      */     }
/* 3159 */     public void processMessage(Message msg, int flags, Player player) { ProxyPlugin.AddStaticPerceptionMessage message = (ProxyPlugin.AddStaticPerceptionMessage)msg;
/* 3160 */       if (Log.loggingDebug) {
/* 3161 */         Log.debug("AddStaticPerceptionHook: player=" + player.getOid() + ", subject=" + message.getSubject());
/*      */       }
/*      */ 
/* 3165 */       if (!message.hasObjectInfo()) {
/* 3166 */         ObjectManagerClient.ObjectStatus objectStatus = ObjectManagerClient.getObjectStatus(message.getSubject());
/*      */ 
/* 3168 */         if ((objectStatus == null) || (objectStatus.namespaces == null)) {
/* 3169 */           Log.error("AddStaticPerceptionHook: ignoring unknown subject=" + message.getSubject() + " added to " + player);
/*      */ 
/* 3173 */           return;
/*      */         }
/* 3175 */         message.setName(objectStatus.name);
/* 3176 */         message.setType(objectStatus.type);
/*      */       }
/*      */ 
/* 3179 */       boolean perceptionGain = ProxyPlugin.this.playerManager.addStaticPerception(player, message.getSubject());
/*      */ 
/* 3182 */       if (perceptionGain) {
/* 3183 */         FilterUpdate perceptionUpdate = new FilterUpdate(1);
/* 3184 */         perceptionUpdate.addFieldValue(2, message.getSubject());
/*      */ 
/* 3186 */         Engine.getAgent().applyFilterUpdate(ProxyPlugin.this.perceptionSubId, perceptionUpdate, 0);
/*      */ 
/* 3190 */         WorldManagerClient.ObjectInfo info = new WorldManagerClient.ObjectInfo();
/* 3191 */         info.oid = message.getSubject();
/* 3192 */         info.name = message.getName();
/* 3193 */         info.objType = message.getType();
/* 3194 */         info.dir = new AOVector(0.0F, 0.0F, 0.0F);
/* 3195 */         Log.debug("INFO: add static perception hook");
/* 3196 */         player.getConnection().send(info.toBuffer(player.getOid()));
/*      */ 
/* 3199 */         WorldManagerClient.updateObject(player.getOid(), message.getSubject());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class AddStaticPerceptionMessage extends TargetMessage
/*      */   {
/*      */     private String name;
/*      */     private ObjectType type;
/*      */     private boolean objectInfoProvided;
/*      */ 
/*      */     public AddStaticPerceptionMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public AddStaticPerceptionMessage(MessageType type)
/*      */     {
/* 3094 */       super();
/*      */     }
/*      */ 
/*      */     public String getName() {
/* 3098 */       return this.name;
/*      */     }
/*      */ 
/*      */     public void setName(String name) {
/* 3102 */       this.name = name;
/*      */     }
/*      */ 
/*      */     public ObjectType getType() {
/* 3106 */       return this.type;
/*      */     }
/*      */ 
/*      */     public void setType(ObjectType type) {
/* 3110 */       this.type = type;
/*      */     }
/*      */ 
/*      */     public boolean hasObjectInfo() {
/* 3114 */       return this.objectInfoProvided;
/*      */     }
/*      */ 
/*      */     public void setHasObjectInfo(boolean flag) {
/* 3118 */       this.objectInfoProvided = flag;
/*      */     }
/*      */   }
/*      */ 
/*      */   class PerceptionHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     PerceptionHook()
/*      */     {
/* 2997 */       super();
/*      */     }
/* 2999 */     public void processMessage(Message msg, int flags, Player player) { PerceptionMessage perceptionMessage = (PerceptionMessage)msg;
/*      */ 
/* 3001 */       List gain = perceptionMessage.getGainObjects();
/*      */ 
/* 3003 */       List lost = perceptionMessage.getLostObjects();
/*      */ 
/* 3006 */       if (Log.loggingDebug) {
/* 3007 */         Log.debug(new StringBuilder().append("PerceptionHook.processMessage: start ").append(gain == null ? 0 : gain.size()).append(" gain and ").append(lost == null ? 0 : lost.size()).append(" lost").toString());
/*      */       }
/*      */ 
/* 3011 */       if (player.getOid().equals(World.DEBUG_OID)) {
/* 3012 */         Log.info(new StringBuilder().append("PerceptionHook: oid=").append(World.DEBUG_OID).append(" start ").append(gain == null ? 0 : gain.size()).append(" gain and ").append(lost == null ? 0 : lost.size()).append(" lost").toString());
/*      */       }
/*      */ 
/* 3016 */       ClientConnection con = player.getConnection();
/*      */ 
/* 3018 */       synchronized (ProxyPlugin.this.playerManager) {
/* 3019 */         List newSubjects = new LinkedList();
/* 3020 */         List deleteSubjects = new LinkedList();
/* 3021 */         if (lost != null) {
/* 3022 */           ProxyPlugin.this.playerManager.removeWorldPerception(player, lost, deleteSubjects);
/*      */         }
/* 3024 */         if (gain != null)
/* 3025 */           ProxyPlugin.this.playerManager.addWorldPerception(player, gain, newSubjects);
/* 3026 */         if ((deleteSubjects.size() > 0) || (newSubjects.size() > 0)) {
/* 3027 */           FilterUpdate perceptionUpdate = new FilterUpdate(deleteSubjects.size() + newSubjects.size());
/*      */ 
/* 3029 */           for (OID oid : deleteSubjects) {
/* 3030 */             perceptionUpdate.removeFieldValue(2, oid);
/*      */           }
/*      */ 
/* 3033 */           for (OID oid : newSubjects) {
/* 3034 */             perceptionUpdate.addFieldValue(2, oid);
/*      */           }
/*      */ 
/* 3038 */           if (player.getOid().equals(World.DEBUG_OID)) {
/* 3039 */             Log.info(new StringBuilder().append("subject changes: ").append(newSubjects.size()).append(" gained ").append(deleteSubjects.size()).append(" lost").toString());
/*      */           }
/*      */ 
/* 3045 */           Engine.getAgent().applyFilterUpdate(ProxyPlugin.this.perceptionSubId, perceptionUpdate, 0, perceptionMessage);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3051 */       boolean loadingState = false;
/* 3052 */       if ((player.supportsLoadingState()) && ((player.getLoadingState() == 0) || ((gain != null) && (gain.size() > 20)) || ((lost != null) && (lost.size() > 20))))
/*      */       {
/* 3058 */         con.send(new LoadingStateEvent(true).toBytes());
/* 3059 */         loadingState = true;
/*      */       }
/*      */ 
/* 3062 */       if (lost != null) {
/* 3063 */         for (PerceptionMessage.ObjectNote objectNote : lost) {
/* 3064 */           ProxyPlugin.this.specialCaseFreeProcessing(objectNote, player);
/*      */         }
/*      */       }
/*      */ 
/* 3068 */       if (gain != null) {
/* 3069 */         for (PerceptionMessage.ObjectNote objectNote : gain) {
/*      */           try {
/* 3071 */             ProxyPlugin.this.specialCaseNewProcessing(objectNote, player);
/* 3072 */             WorldManagerClient.updateObject(player.getOid(), objectNote.getSubject());
/*      */           }
/*      */           catch (Exception e) {
/* 3075 */             Log.exception(new StringBuilder().append("specialCaseNewProcessing: player=").append(player).append(" oid=").append(objectNote.getSubject()).toString(), e);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3082 */       if (loadingState) {
/* 3083 */         player.setLoadingState(1);
/* 3084 */         con.send(new LoadingStateEvent(false).toBytes());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class TargetedPropertyHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     TargetedPropertyHook()
/*      */     {
/* 2721 */       super();
/*      */     }
/* 2723 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.TargetedPropertyMessage propMsg = (WorldManagerClient.TargetedPropertyMessage)msg;
/*      */ 
/* 2725 */       OID targetOid = propMsg.getTarget();
/* 2726 */       OID subjectOid = propMsg.getSubject();
/*      */ 
/* 2728 */       if (Log.loggingDebug) {
/* 2729 */         Set keySet = propMsg.keySet();
/* 2730 */         for (String key : keySet) {
/* 2731 */           ProxyPlugin.log.debug("handleTargetedPropertyMsg: playerOid=" + player.getOid() + ", targetOid=" + targetOid + ", oid = " + subjectOid + ", got key " + key + ", value=" + propMsg.getProperty(key));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2739 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2742 */       AOByteBuffer buf = null;
/* 2743 */       if ((ProxyPlugin.this.playerSpecificProps.size() > 0) && (subjectOid != player.getOid())) {
/* 2744 */         buf = propMsg.toBuffer(player.getVersion(), ProxyPlugin.this.cachedPlayerSpecificFilterProps);
/*      */       }
/*      */       else
/* 2747 */         buf = propMsg.toBuffer(player.getVersion(), ProxyPlugin.this.filteredProps);
/* 2748 */       if (buf != null) {
/* 2749 */         con.send(buf);
/* 2750 */         if (Log.loggingDebug)
/* 2751 */           ProxyPlugin.log.debug("sent targeted prop msg for targetOid " + targetOid + ", subjectOid=" + subjectOid);
/*      */       }
/* 2753 */       else if (Log.loggingDebug) {
/* 2754 */         ProxyPlugin.log.debug("filtered out targeted prop msg for targetOid " + targetOid + ", subjectOid=" + subjectOid + " because all props were filtered");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class PropertyHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     PropertyHook()
/*      */     {
/* 2677 */       super();
/*      */     }
/* 2679 */     public boolean processMessage(Message msg, int flags) { return true; }
/*      */ 
/*      */     public void processMessage(Message msg, int flags, Player player)
/*      */     {
/* 2683 */       PropertyMessage propMsg = (PropertyMessage)msg;
/*      */ 
/* 2685 */       OID subjectOid = propMsg.getSubject();
/*      */ 
/* 2687 */       if (Log.loggingDebug) {
/* 2688 */         Set keySet = propMsg.keySet();
/* 2689 */         for (String key : keySet) {
/* 2690 */           ProxyPlugin.log.debug("handlePropertyMsg: player=" + player + ", oid=" + subjectOid + ", got key " + key + ", value=" + propMsg.getProperty(key));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2696 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2698 */       AOByteBuffer buf = null;
/* 2699 */       if ((ProxyPlugin.this.playerSpecificProps.size() > 0) && (subjectOid != player.getOid())) {
/* 2700 */         buf = propMsg.toBuffer(player.getVersion(), ProxyPlugin.this.cachedPlayerSpecificFilterProps);
/*      */       }
/*      */       else {
/* 2703 */         buf = propMsg.toBuffer(player.getVersion(), ProxyPlugin.this.filteredProps);
/*      */       }
/* 2705 */       if (buf != null) {
/* 2706 */         con.send(buf);
/* 2707 */         if (Log.loggingDebug)
/* 2708 */           ProxyPlugin.log.debug("sent prop msg for player " + player + ", subjectId=" + subjectOid);
/*      */       }
/* 2710 */       else if (Log.loggingDebug) {
/* 2711 */         ProxyPlugin.log.debug("filtered out prop msg for player " + player + ", subjectId=" + subjectOid + " because all props were filtered");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class P2PExtensionHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     P2PExtensionHook()
/*      */     {
/* 2645 */       super();
/*      */     }
/* 2647 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.TargetedExtensionMessage extMsg = (WorldManagerClient.TargetedExtensionMessage)msg;
/*      */ 
/* 2649 */       OID objOid = extMsg.getSubject();
/*      */ 
/* 2651 */       Set keySet = extMsg.keySet();
/* 2652 */       for (String key : keySet) {
/* 2653 */         if (Log.loggingDebug) {
/* 2654 */           ProxyPlugin.log.debug("P2PExtensionHook: playerOid=" + player.getOid() + ", oid = " + objOid + ", got key " + key + ", value=" + extMsg.getProperty(key));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2660 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2663 */       AOByteBuffer buf = extMsg.toBuffer(player.getVersion());
/* 2664 */       if (buf != null) {
/* 2665 */         con.send(buf);
/* 2666 */         if (Log.loggingDebug)
/* 2667 */           ProxyPlugin.log.debug("P2PExtensionHook: sent ext msg for notifyOid " + objOid);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class ExtensionHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     ExtensionHook()
/*      */     {
/* 2585 */       super();
/*      */     }
/* 2587 */     public void processMessage(Message msg, int flags, Player player) { AOByteBuffer buf = null;
/*      */ 
/* 2589 */       ClientConnection con = player.getConnection();
/* 2590 */       OID subject = null;
/* 2591 */       OID target = null;
/* 2592 */       String subType = null;
/*      */ 
/* 2594 */       if ((msg instanceof WorldManagerClient.TargetedExtensionMessage)) {
/* 2595 */         WorldManagerClient.TargetedExtensionMessage extMsg = (WorldManagerClient.TargetedExtensionMessage)msg;
/*      */ 
/* 2597 */         subject = extMsg.getSubject();
/* 2598 */         target = extMsg.getTarget();
/* 2599 */         subType = extMsg.getExtensionType();
/*      */ 
/* 2601 */         if (Log.loggingDebug) {
/* 2602 */           Set keySet = extMsg.keySet();
/* 2603 */           for (String key : keySet) {
/* 2604 */             ProxyPlugin.log.debug("ExtensionHook: playerOid=" + player.getOid() + ", oid=" + subject + ", key " + key + ", value=" + extMsg.getProperty(key));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2611 */         buf = extMsg.toBuffer(player.getVersion());
/*      */       }
/*      */       else {
/* 2614 */         WorldManagerClient.ExtensionMessage extMsg = (WorldManagerClient.ExtensionMessage)msg;
/*      */ 
/* 2616 */         subject = extMsg.getSubject();
/* 2617 */         subType = extMsg.getExtensionType();
/*      */ 
/* 2619 */         if (Log.loggingDebug) {
/* 2620 */           Set keySet = extMsg.keySet();
/* 2621 */           for (String key : keySet) {
/* 2622 */             ProxyPlugin.log.debug("ExtensionHook: playerOid=" + player.getOid() + ", oid=" + subject + ", key " + key + ", value=" + extMsg.getProperty(key));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2629 */         buf = extMsg.toBuffer(player.getVersion());
/*      */       }
/*      */ 
/* 2632 */       if (buf != null) {
/* 2633 */         con.send(buf);
/* 2634 */         if (Log.loggingDebug)
/* 2635 */           ProxyPlugin.log.debug("ExtensionHook: sent subType " + subType + " for playerOid=" + player.getOid() + ", target=" + target + ", subject=" + subject);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class AbilityStatusHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     AbilityStatusHook()
/*      */     {
/* 2570 */       super();
/*      */     }
/* 2572 */     public void processMessage(Message msg, int flags, Player player) { AOByteBuffer buf = null;
/* 2573 */       ClientConnection con = player.getConnection();
/* 2574 */       AbilityStatusMessage asMsg = (AbilityStatusMessage)msg;
/* 2575 */       buf = asMsg.toBuffer();
/* 2576 */       if (buf != null)
/* 2577 */         con.send(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   class InvokeEffectHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     InvokeEffectHook()
/*      */     {
/* 2547 */       super();
/*      */     }
/* 2549 */     public void processMessage(Message msg, int flags, Player player) { AnimationClient.InvokeEffectMessage effectMsg = (AnimationClient.InvokeEffectMessage)msg;
/*      */ 
/* 2551 */       OID objOid = effectMsg.getSubject();
/*      */ 
/* 2553 */       if (Log.loggingDebug) {
/* 2554 */         ProxyPlugin.log.debug("InvokeEffectHook: got msg=" + effectMsg.toString());
/*      */       }
/*      */ 
/* 2557 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2560 */       AOByteBuffer buf = effectMsg.toBuffer(player.getVersion());
/* 2561 */       if (buf != null) {
/* 2562 */         con.send(buf);
/* 2563 */         if (Log.loggingDebug)
/* 2564 */           ProxyPlugin.log.debug("InvokeEffectHook: sent ext msg for notifyOid " + objOid);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class AnimationHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     AnimationHook()
/*      */     {
/* 2518 */       super();
/*      */     }
/*      */     public void processMessage(Message msg, int flags, Player player) {
/* 2521 */       WorldManagerClient.AnimationMessage animMsg = (WorldManagerClient.AnimationMessage)msg;
/*      */ 
/* 2524 */       OID playerOid = player.getOid();
/* 2525 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2527 */       OID objOid = animMsg.getSubject();
/* 2528 */       List animList = animMsg.getAnimationList();
/*      */ 
/* 2531 */       NotifyPlayAnimationEvent animEvent = new NotifyPlayAnimationEvent(objOid);
/*      */ 
/* 2533 */       animEvent.setAnimList(animList);
/*      */ 
/* 2536 */       con.send(animEvent.toBytes());
/* 2537 */       if (Log.loggingDebug)
/* 2538 */         ProxyPlugin.log.debug("AnimationHook: send anim msg for playerOid " + playerOid + ", objId=" + objOid + ", animEvent=" + animEvent);
/*      */     }
/*      */   }
/*      */ 
/*      */   class DetachHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     DetachHook()
/*      */     {
/* 2494 */       super();
/*      */     }
/* 2496 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.DetachMessage dMsg = (WorldManagerClient.DetachMessage)msg;
/*      */ 
/* 2498 */       OID dcObjOid = dMsg.getSubject();
/* 2499 */       OID objBeingDetached = dMsg.getObjBeingDetached();
/* 2500 */       String socket = dMsg.getSocketName();
/* 2501 */       if (Log.loggingDebug) {
/* 2502 */         ProxyPlugin.log.debug("DetachHook: dcObjOid=" + dcObjOid + ", objBeingDetached=" + objBeingDetached + ", socket=" + socket);
/*      */       }
/*      */ 
/* 2507 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2509 */       DetachEvent detachEvent = new DetachEvent(dcObjOid, objBeingDetached, socket);
/*      */ 
/* 2511 */       con.send(detachEvent.toBytes());
/*      */     }
/*      */   }
/*      */ 
/*      */   class SetAmbientHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     SetAmbientHook()
/*      */     {
/* 2470 */       super();
/*      */     }
/* 2472 */     public void processMessage(Message m, int flags, Player player) { WorldManagerClient.SetAmbientLightMessage msg = (WorldManagerClient.SetAmbientLightMessage)m;
/* 2473 */       Color ambientLight = msg.getColor();
/* 2474 */       OID playerOid = msg.getTarget();
/*      */ 
/* 2476 */       if (!playerOid.equals(player.getOid())) {
/* 2477 */         Log.error("Message target and perceiver mismatch");
/*      */       }
/*      */ 
/* 2480 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2482 */       if (Log.loggingDebug) {
/* 2483 */         ProxyPlugin.log.debug("SetAmbientHook: targetOid=" + playerOid + ", ambient=" + ambientLight);
/*      */       }
/*      */ 
/* 2486 */       Event ambientLightEvent = new AmbientLightEvent(ambientLight);
/* 2487 */       con.send(ambientLightEvent.toBytes());
/*      */     }
/*      */   }
/*      */ 
/*      */   class FreeObjectHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     FreeObjectHook()
/*      */     {
/* 2458 */       super();
/*      */     }
/* 2460 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.FreeObjectMessage message = (WorldManagerClient.FreeObjectMessage)msg;
/*      */ 
/* 2462 */       player.getConnection().send(message.toBuffer());
/*      */     }
/*      */   }
/*      */ 
/*      */   class NewDirLightHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     NewDirLightHook()
/*      */     {
/* 2435 */       super();
/*      */     }
/* 2437 */     public void processMessage(Message m, int flags, Player player) { WorldManagerClient.NewDirLightMessage msg = (WorldManagerClient.NewDirLightMessage)m;
/* 2438 */       OID playerOid = msg.getTarget();
/* 2439 */       OID lightOid = msg.getSubject();
/* 2440 */       LightData lightData = msg.getLightData();
/*      */ 
/* 2442 */       if (!playerOid.equals(player.getOid())) {
/* 2443 */         Log.error("Message target and perceiver mismatch");
/*      */       }
/*      */ 
/* 2446 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2448 */       if (Log.loggingDebug) {
/* 2449 */         ProxyPlugin.log.debug("NewDirLightHook: notifyOid=" + playerOid + ", lightOid=" + lightOid + ", light=" + lightData);
/*      */       }
/* 2451 */       NewLightEvent lightEvent = new NewLightEvent(playerOid, lightOid, lightData);
/*      */ 
/* 2453 */       con.send(lightEvent.toBytes());
/*      */     }
/*      */   }
/*      */ 
/*      */   class DisplayContextHook extends ProxyPlugin.BasicProxyHook
/*      */   {
/*      */     DisplayContextHook()
/*      */     {
/* 2377 */       super();
/*      */     }
/* 2379 */     public void processMessage(Message msg, int flags, Player player) { WorldManagerClient.DisplayContextMessage dcMsg = (WorldManagerClient.DisplayContextMessage)msg;
/*      */ 
/* 2381 */       OID dcObjOid = dcMsg.getSubject();
/* 2382 */       DisplayContext dc = dcMsg.getDisplayContext();
/* 2383 */       if (Log.loggingDebug) {
/* 2384 */         ProxyPlugin.log.debug("handleDC: oid=" + dcObjOid + " dc=" + dc);
/*      */       }
/* 2386 */       ClientConnection con = player.getConnection();
/*      */ 
/* 2389 */       if (dc != null) {
/* 2390 */         ModelInfoEvent event = new ModelInfoEvent(dcObjOid);
/* 2391 */         event.setDisplayContext(dc);
/* 2392 */         event.setForceInstantLoad(dcMsg.getForceInstantLoad());
/* 2393 */         con.send(event.toBytes());
/*      */       }
/*      */ 
/* 2397 */       Map childMap = dc.getChildDCMap();
/* 2398 */       if ((childMap != null) && (!childMap.isEmpty())) {
/* 2399 */         for (String slot : childMap.keySet()) {
/* 2400 */           DisplayContext attachDC = (DisplayContext)childMap.get(slot);
/* 2401 */           if (attachDC == null) {
/* 2402 */             throw new AORuntimeException("attach DC is null for obj: " + dcObjOid);
/*      */           }
/*      */ 
/* 2405 */           OID attacheeOID = attachDC.getObjRef();
/* 2406 */           if (attacheeOID == null) {
/* 2407 */             throw new AORuntimeException("attachee oid is null for obj: " + dcObjOid);
/*      */           }
/*      */ 
/* 2411 */           if (Log.loggingDebug) {
/* 2412 */             ProxyPlugin.log.debug("DisplayContextHook: sending attach message to " + player.getOid() + " attaching to obj " + dcObjOid + ", object being attached=" + attacheeOID + " to slot " + slot + ", attachmentDC=" + attachDC);
/*      */           }
/*      */ 
/* 2422 */           AttachEvent event = new AttachEvent(dcObjOid, attacheeOID, slot, attachDC);
/*      */ 
/* 2424 */           con.send(event.toBytes());
/*      */         }
/* 2426 */         ProxyPlugin.log.debug("DisplayContextHook: done with processing attachments");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   abstract class BasicProxyHook
/*      */     implements ProxyHook
/*      */   {
/*      */     BasicProxyHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2366 */       return true;
/*      */     }
/*      */ 
/*      */     public abstract void processMessage(Message paramMessage, int paramInt, Player paramPlayer);
/*      */   }
/*      */ 
/*      */   class ConnectionResetMessage extends Message
/*      */   {
/*      */     ClientConnection con;
/*      */     Player player;
/*      */     public static final long serialVersionUID = 1L;
/*      */ 
/*      */     ConnectionResetMessage(ClientConnection con, Player player)
/*      */     {
/* 2056 */       this.con = con;
/* 2057 */       this.player = player;
/*      */     }
/*      */ 
/*      */     public Player getPlayer() {
/* 2061 */       return this.player;
/*      */     }
/*      */ 
/*      */     public ClientConnection getConnection() {
/* 2065 */       return this.con;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class DefaultInstanceEntryCallback
/*      */     implements InstanceEntryCallback
/*      */   {
/*      */     public boolean instanceEntryAllowed(OID playerOid, OID instanceOid, Point location)
/*      */     {
/* 1974 */       return true;
/*      */     }
/*      */ 
/*      */     public OID selectInstance(Player player, String instanceName) {
/* 1978 */       return InstanceClient.getInstanceOid(instanceName);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class DefaultProxyLoginCallback
/*      */     implements ProxyLoginCallback
/*      */   {
/*      */     public boolean duplicateLogin(ProxyPlugin.PlayerLoginStatus existingLogin, ClientConnection con)
/*      */     {
/* 1930 */       return existingLogin != null;
/*      */     }
/*      */ 
/*      */     public String preLoad(Player player, ClientConnection con) {
/* 1934 */       return null;
/*      */     }
/*      */ 
/*      */     public String postLoad(Player player, ClientConnection con) {
/* 1938 */       return null;
/*      */     }
/*      */ 
/*      */     public void postSpawn(Player player, ClientConnection con)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public class EventCallback
/*      */     implements SQCallback
/*      */   {
/*      */     public EventCallback()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void doWork(Object value, Object key)
/*      */     {
/* 1035 */       Event event = (Event)value;
/* 1036 */       if (event == null) {
/* 1037 */         Log.dumpStack(new StringBuilder().append("EventCallback.doWork: event object is null, for key ").append(key).toString());
/*      */ 
/* 1039 */         return;
/*      */       }
/* 1041 */       ClientConnection con = event.getConnection();
/* 1042 */       Player player = (Player)key;
/*      */       try
/*      */       {
/* 1046 */         long startTime = System.currentTimeMillis();
/* 1047 */         long inQueue = startTime - event.getEnqueueTime();
/*      */ 
/* 1049 */         if ((player == ProxyPlugin.loginSerializer) && ((event instanceof AuthorizedLoginEvent)))
/*      */         {
/* 1051 */           AuthorizedLoginEvent loginEvent = (AuthorizedLoginEvent)event;
/* 1052 */           OID playerOid = loginEvent.getOid();
/*      */ 
/* 1054 */           Log.info(new StringBuilder().append("ProxyPlugin: LOGIN_BEGIN remote=").append(con).append(" playerOid=").append(playerOid).append(" in-queue=").append(inQueue).append(" ms").toString());
/*      */ 
/* 1058 */           boolean loginOK = ProxyPlugin.this.processLogin(con, loginEvent);
/*      */ 
/* 1060 */           Player newPlayer = ProxyPlugin.this.playerManager.getPlayer(playerOid);
/* 1061 */           String playerName = null;
/* 1062 */           if (newPlayer != null)
/* 1063 */             playerName = newPlayer.getName();
/* 1064 */           Log.info(new StringBuilder().append("ProxyPlugin: LOGIN_END remote=").append(con).append(loginOK ? " SUCCESS " : " FAILURE ").append(" playerOid=").append(playerOid).append(" name=").append(playerName).append(" in-queue=").append(inQueue).append(" ms").append(" processing=").append(System.currentTimeMillis() - startTime).append(" ms").append(" nPlayers=").append(ProxyPlugin.this.playerManager.getPlayerCount()).toString());
/*      */ 
/* 1070 */           return;
/*      */         }
/*      */ 
/* 1073 */         if (player == ProxyPlugin.loginSerializer) {
/* 1074 */           Log.error(new StringBuilder().append("ClientEvent: Illegal event for loginSerializer: ").append(event.getClass().getName()).append(", con=").append(con).toString());
/*      */ 
/* 1078 */           return;
/*      */         }
/*      */ 
/* 1081 */         if (Log.loggingDebug) {
/* 1082 */           Log.debug(new StringBuilder().append("ClientEvent: player=").append(player).append(", in-queue=").append(inQueue).append(" ms: ").append(event.getName()).toString());
/*      */         }
/* 1084 */         if ((Log.loggingInfo) && (inQueue > 2000L)) {
/* 1085 */           Log.info(new StringBuilder().append("LONG IN-QUEUE: ").append(inQueue).append(" ms: player=").append(player).append(" ").append(event.getName()).toString());
/*      */         }
/*      */ 
/* 1089 */         Lock objLock = ProxyPlugin.this.getObjectLockManager().getLock(player.getOid());
/* 1090 */         objLock.lock();
/*      */         try {
/* 1092 */           if (Log.loggingDebug)
/* 1093 */             Log.debug(new StringBuilder().append("ClientEvent: event detail: ").append(event).toString());
/* 1094 */           if ((event instanceof ComEvent))
/* 1095 */             ProxyPlugin.this.processCom(con, (ComEvent)event);
/* 1096 */           else if ((event instanceof DirLocOrientEvent))
/* 1097 */             ProxyPlugin.this.processDirLocOrient(con, (DirLocOrientEvent)event);
/* 1098 */           else if ((event instanceof CommandEvent))
/* 1099 */             ProxyPlugin.this.processCommand(con, (CommandEvent)event);
/* 1100 */           else if ((event instanceof AutoAttackEvent))
/* 1101 */             ProxyPlugin.this.processAutoAttack(con, (AutoAttackEvent)event);
/* 1102 */           else if ((event instanceof ExtensionMessageEvent)) {
/* 1103 */             ProxyPlugin.this.processExtensionMessageEvent(con, (ExtensionMessageEvent)event);
/*      */           }
/* 1105 */           else if ((event instanceof AbilityStatusEvent)) {
/* 1106 */             ProxyPlugin.this.processAbilityStatusEvent(con, (AbilityStatusEvent)event);
/*      */           }
/* 1108 */           else if ((event instanceof RequestQuestInfo))
/* 1109 */             ProxyPlugin.this.processRequestQuestInfo(con, (RequestQuestInfo)event);
/* 1110 */           else if ((event instanceof QuestResponse))
/* 1111 */             ProxyPlugin.this.processQuestResponse(con, (QuestResponse)event);
/* 1112 */           else if ((event instanceof ConcludeQuest))
/* 1113 */             ProxyPlugin.this.processReqConcludeQuest(con, (ConcludeQuest)event);
/* 1114 */           else if ((event instanceof ActivateItemEvent))
/* 1115 */             ProxyPlugin.this.processActivateItem(con, (ActivateItemEvent)event);
/*      */           else {
/* 1117 */             throw new RuntimeException(new StringBuilder().append("Unknown event: ").append(event).toString());
/*      */           }
/* 1119 */           long elapsed = System.currentTimeMillis() - startTime;
/* 1120 */           if (Log.loggingDebug) {
/* 1121 */             Log.debug(new StringBuilder().append("ClientEvent: processed event ").append(event).append(", player=").append(player).append(", processing=").append(elapsed).append(" ms").toString());
/*      */ 
/* 1124 */             ProxyPlugin.this.clientMsgMeter.add(Long.valueOf(elapsed));
/*      */           }
/* 1126 */           if (elapsed > 2000L)
/* 1127 */             Log.info(new StringBuilder().append("LONG PROCESS: ").append(elapsed).append(" ms: player=").append(player).append(" ").append(event.getName()).toString());
/*      */         }
/*      */         finally
/*      */         {
/* 1131 */           objLock.unlock();
/*      */         }
/*      */       } catch (Exception e) {
/* 1134 */         throw new RuntimeException("ProxyPlugin.EventCallback", e);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class MessageCallback
/*      */     implements SQCallback
/*      */   {
/*      */     protected ProxyPlugin proxyPlugin;
/*      */ 
/*      */     public MessageCallback(ProxyPlugin proxyPlugin)
/*      */     {
/*  847 */       this.proxyPlugin = proxyPlugin;
/*      */     }
/*      */ 
/*      */     public void doWork(Object value, Object key)
/*      */     {
/*  863 */       Message message = (Message)value;
/*  864 */       Player player = (Player)key;
/*  865 */       if (message == null) {
/*  866 */         Log.dumpStack("DOMESSAGE: Message for oid=" + player.getOid() + " is not a Message: " + value);
/*      */ 
/*  868 */         return;
/*      */       }
/*      */ 
/*  871 */       if ((message instanceof ProxyPlugin.ConnectionResetMessage)) {
/*  872 */         if (player == ProxyPlugin.loginSerializer)
/*  873 */           ProxyPlugin.this.processConnectionResetInternal((ProxyPlugin.ConnectionResetMessage)message);
/*      */         else {
/*  875 */           ProxyPlugin.this.messageQQ.insert(ProxyPlugin.loginSerializer, message);
/*      */         }
/*  877 */         return;
/*      */       }
/*      */ 
/*  882 */       int status = player.getStatus();
/*  883 */       if ((status == 3) || (status == 0))
/*      */       {
/*  885 */         Log.debug("Ignoring message: id=" + message.getMsgId() + " type=" + message.getMsgType() + " for " + player);
/*      */ 
/*  887 */         if (message.isRPC()) {
/*  888 */           if (message.getMsgType() == InstanceClient.MSG_TYPE_INSTANCE_ENTRY_REQ)
/*  889 */             Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*  890 */           else if (message.getMsgType() == ProxyPlugin.MSG_TYPE_PLAYER_IGNORE_LIST_REQ)
/*  891 */             Engine.getAgent().sendObjectResponse(message, null);
/*  892 */           else if (message.getMsgType() == ProxyPlugin.MSG_TYPE_GET_PLAYER_LOGIN_STATUS)
/*  893 */             Engine.getAgent().sendObjectResponse(message, null);
/*  894 */           else if (message.getMsgType() == ProxyPlugin.MSG_TYPE_LOGOUT_PLAYER)
/*  895 */             Engine.getAgent().sendObjectResponse(message, null);
/*      */           else {
/*  897 */             throw new RuntimeException("Unexpected RPC message " + message + " for player " + player);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  910 */         return;
/*      */       }
/*      */       try
/*      */       {
/*  914 */         long inQueue = 0L;
/*  915 */         if (Log.loggingDebug) {
/*  916 */           inQueue = System.nanoTime() - message.getEnqueueTime();
/*  917 */           Log.debug("DOINGSVRMESSAGE: Message for oid=" + player.getOid() + ",msgId=" + message.getMsgId() + ",in-queue=" + inQueue / 1000L + " usec: " + message.getMsgType());
/*      */         }
/*      */ 
/*  922 */         if ((Log.loggingInfo) && (ProxyPlugin.this.proxyQueueHistogram != null)) {
/*  923 */           ProxyPlugin.this.proxyQueueHistogram.addTime(inQueue);
/*      */         }
/*      */ 
/*  926 */         List hooks = ProxyPlugin.this.getHookManager().getHooks(message.getMsgType());
/*      */ 
/*  928 */         long callbackStart = System.nanoTime();
/*      */ 
/*  930 */         for (Hook hook : hooks) {
/*  931 */           ((ProxyHook)hook).processMessage(message, 0, player);
/*      */         }
/*  933 */         long callbackTime = 0L;
/*  934 */         if ((Log.loggingDebug) || (Log.loggingInfo)) {
/*  935 */           callbackTime = System.nanoTime() - callbackStart;
/*      */         }
/*  937 */         if (Log.loggingDebug) {
/*  938 */           Log.debug("DONESVRMESSAGE: Message for oid=" + player.getOid() + ",msgId=" + message.getMsgId() + ",in-queue=" + inQueue / 1000L + " usec: " + ",execute=" + callbackTime / 1000L + " usec: " + message.getMsgType());
/*      */         }
/*      */ 
/*  944 */         if ((Log.loggingInfo) && (ProxyPlugin.this.proxyCallbackHistogram != null))
/*  945 */           ProxyPlugin.this.proxyCallbackHistogram.addTime(callbackTime);
/*      */       }
/*      */       catch (Exception ex) {
/*  948 */         Log.exception("SQ MessageCallback", ex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class MatchedMessage
/*      */   {
/*      */     final Long sub;
/*      */     final Message message;
/*      */     final long enqueueTime;
/*      */ 
/*      */     MatchedMessage(Long sub, Message message)
/*      */     {
/*  802 */       this.sub = sub;
/*  803 */       this.message = message;
/*  804 */       this.enqueueTime = System.currentTimeMillis();
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  808 */       return "MatchedMessage[subId=" + this.sub + ", enqueueTime=" + this.enqueueTime + ",msg=" + this.message;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class DefaultCommandAccess
/*      */     implements ProxyPlugin.CommandAccessCheck
/*      */   {
/*      */     public boolean allowed(CommandEvent event, ProxyPlugin proxy)
/*      */     {
/*  689 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class RegisteredCommand
/*      */   {
/*      */     public ProxyPlugin.CommandParser parser;
/*      */     public ProxyPlugin.CommandAccessCheck access;
/*      */ 
/*      */     public RegisteredCommand(ProxyPlugin.CommandParser p, ProxyPlugin.CommandAccessCheck a)
/*      */     {
/*  672 */       this.parser = p;
/*  673 */       this.access = a;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface CommandAccessCheck
/*      */   {
/*      */     public abstract boolean allowed(CommandEvent paramCommandEvent, ProxyPlugin paramProxyPlugin);
/*      */   }
/*      */ 
/*      */   public static abstract interface CommandParser
/*      */   {
/*      */     public abstract void parse(CommandEvent paramCommandEvent);
/*      */   }
/*      */ 
/*      */   public class PlayerMessageCallback
/*      */     implements MessageCallback
/*      */   {
/*      */     public PlayerMessageCallback()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void handleMessage(Message message, int flags)
/*      */     {
/*  518 */       if ((message instanceof TargetMessage)) {
/*  519 */         if (message.getMsgType() == WorldManagerClient.MSG_TYPE_TARGETED_PROPERTY) {
/*  520 */           ProxyPlugin.this.countMsgTargetedProperty.add();
/*      */         }
/*      */ 
/*  523 */         OID playerOid = ((TargetMessage)message).getTarget();
/*  524 */         Player player = ProxyPlugin.this.playerManager.getPlayer(playerOid);
/*  525 */         if (player == null) {
/*  526 */           Log.debug("TargetMessage: player " + playerOid + " not found");
/*      */ 
/*  529 */           if (message.isRPC()) {
/*  530 */             if (message.getMsgType() == InstanceClient.MSG_TYPE_INSTANCE_ENTRY_REQ) {
/*  531 */               Engine.getAgent().sendBooleanResponse(message, Boolean.valueOf(false));
/*      */             }
/*  533 */             else if (message.getMsgType() == ProxyPlugin.MSG_TYPE_PLAYER_IGNORE_LIST_REQ)
/*  534 */               Engine.getAgent().sendObjectResponse(message, null);
/*  535 */             else if (message.getMsgType() == ProxyPlugin.MSG_TYPE_GET_PLAYER_LOGIN_STATUS)
/*  536 */               Engine.getAgent().sendObjectResponse(message, null);
/*  537 */             else if (message.getMsgType() == ProxyPlugin.MSG_TYPE_LOGOUT_PLAYER)
/*  538 */               Engine.getAgent().sendObjectResponse(message, null);
/*      */             else {
/*  540 */               throw new RuntimeException("Unexpected RPC message " + message + " for player " + player);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  547 */           message.setEnqueueTime();
/*  548 */           ProxyPlugin.this.messageQQ.insert(player, message);
/*      */         }
/*  550 */         return;
/*  551 */       }if ((message instanceof SubjectMessage)) {
/*  552 */         List perceivers = ProxyPlugin.this.playerManager.getPerceivers(((SubjectMessage)message).getSubject());
/*      */ 
/*  554 */         if (perceivers == null) {
/*  555 */           Log.warn("No perceivers for " + message);
/*  556 */           return;
/*      */         }
/*  558 */         if ((message instanceof WorldManagerClient.UpdateWorldNodeMessage)) {
/*  559 */           WorldManagerClient.UpdateWorldNodeMessage wMsg = (WorldManagerClient.UpdateWorldNodeMessage)message;
/*  560 */           DirLocOrientEvent dloEvent = new DirLocOrientEvent(wMsg.getSubject(), wMsg.getWorldNode());
/*      */ 
/*  562 */           wMsg.setEventBuf(dloEvent.toBytes());
/*      */         }
/*      */ 
/*  566 */         if (message.getMsgType() == WorldManagerClient.MSG_TYPE_UPDATEWNODE) {
/*  567 */           ProxyPlugin.this.countMsgUpdateWNodeIn.add();
/*  568 */           ProxyPlugin.this.countMsgUpdateWNodeOut.add(perceivers.size());
/*  569 */         } else if (message.getMsgType() == PropertyMessage.MSG_TYPE_PROPERTY) {
/*  570 */           ProxyPlugin.this.countMsgPropertyIn.add();
/*  571 */           ProxyPlugin.this.countMsgPropertyOut.add(perceivers.size());
/*  572 */         } else if (message.getMsgType() == WorldManagerClient.MSG_TYPE_WNODECORRECT) {
/*  573 */           ProxyPlugin.this.countMsgWNodeCorrectIn.add();
/*  574 */           ProxyPlugin.this.countMsgWNodeCorrectOut.add(perceivers.size());
/*  575 */         } else if (message.getMsgType() == WorldManagerClient.MSG_TYPE_MOB_PATH) {
/*  576 */           ProxyPlugin.this.countMsgMobPathIn.add();
/*  577 */           ProxyPlugin.this.countMsgMobPathOut.add(perceivers.size());
/*      */         }
/*      */       } else {
/*  579 */         if ((message instanceof PerceptionMessage)) {
/*  580 */           PerceptionMessage pMsg = (PerceptionMessage)message;
/*  581 */           ProxyPlugin.this.countMsgPerception.add();
/*  582 */           ProxyPlugin.this.countMsgPerceptionGain.add(pMsg.getGainObjectCount());
/*  583 */           ProxyPlugin.this.countMsgPerceptionLost.add(pMsg.getLostObjectCount());
/*      */ 
/*  585 */           OID playerOid = pMsg.getTarget();
/*  586 */           Log.debug("PERCEP: got perception message with player: " + playerOid);
/*  587 */           Player player = ProxyPlugin.this.playerManager.getPlayer(playerOid);
/*  588 */           if (player == null) {
/*  589 */             Log.debug("PerceptionMessage: player " + playerOid + " not found");
/*      */           }
/*      */           else {
/*  592 */             message.setEnqueueTime();
/*  593 */             ProxyPlugin.this.messageQQ.insert(player, message);
/*  594 */             Log.debug("PERCEP: added perception message to messageQQ: ");
/*      */           }
/*  596 */           return;
/*      */         }
/*  598 */         Log.error("PlayerMessageCallback unknown type=" + message.getMsgType());
/*      */ 
/*  600 */         return;
/*      */       }
/*      */       List perceivers;
/*  603 */       message.setEnqueueTime();
/*  604 */       ProxyPlugin.this.messageQQ.insert(perceivers, message);
/*      */     }
/*      */   }
/*      */ 
/*      */   public class PluginMessageCallback
/*      */     implements MessageCallback
/*      */   {
/*  492 */     ExecutorService executor = Executors.newSingleThreadExecutor();
/*      */ 
/*      */     public PluginMessageCallback()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void handleMessage(Message message, int flags)
/*      */     {
/*  489 */       this.executor.execute(new ProxyPlugin.ReceivedMessage(ProxyPlugin.this, message, flags));
/*      */     }
/*      */   }
/*      */ 
/*      */   class ReceivedMessage
/*      */     implements Runnable
/*      */   {
/*      */     Message message;
/*      */     int flags;
/*      */ 
/*      */     ReceivedMessage(Message message, int flags)
/*      */     {
/*  470 */       this.message = message;
/*  471 */       this.flags = flags;
/*      */     }
/*      */ 
/*      */     public void run() {
/*  475 */       ProxyPlugin.this.callEngineOnMessage(this.message, this.flags);
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.ProxyPlugin
 * JD-Core Version:    0.6.0
 */