/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.OID;
/*     */ import java.io.Serializable;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class VoiceClient
/*     */ {
/* 316 */   public static MessageType MSG_TYPE_VOICECLIENT = MessageType.intern("ao.VOICECLIENT");
/*     */ 
/* 322 */   public static MessageType MSG_TYPE_VOICE_MEMBER_ADDED = MessageType.intern("ao.VOICE_MEMBER_ADDED");
/*     */ 
/* 328 */   public static MessageType MSG_TYPE_VOICE_MEMBER_REMOVED = MessageType.intern("ao.VOICE_MEMBER_REMOVED");
/*     */   public static final int SUCCESS = 1;
/*     */   public static final int SUCCESS_TRUE = 2;
/*     */   public static final int SUCCESS_FALSE = 3;
/*     */   public static final int ERROR_NO_SUCH_GROUP = -1;
/*     */   public static final int ERROR_GROUP_ALREADY_EXISTS = -2;
/*     */   public static final int ERROR_NO_SUCH_MEMBER = -3;
/*     */   public static final int ERROR_MEMBER_ALREADY_EXISTS = -4;
/*     */   public static final int ERROR_NO_SUCH_OPCODE = -5;
/*     */   public static final int ERROR_PLAYER_NOT_CONNECTED = -6;
/*     */   public static final int ERROR_MISSING_ADD_PROPERTY = -7;
/*     */   public static final int ERROR_MISSING_MAX_VOICES = -8;
/*     */   public static final int ERROR_MISSING_POSITIONAL = -9;
/*     */ 
/*     */   public static int addVoiceGroup(OID oid, boolean positional, int maxVoices)
/*     */   {
/*  25 */     return sendNewGroupMessage("addVoiceGroup", oid, positional, maxVoices);
/*     */   }
/*     */ 
/*     */   public static int removeVoiceGroup(OID groupOid)
/*     */   {
/*  35 */     return sendVoicePluginRPC("removeVoiceGroup", groupOid);
/*     */   }
/*     */ 
/*     */   public static int isPositional(OID groupOid)
/*     */   {
/*  48 */     return sendVoicePluginRPC("isPositional", groupOid);
/*     */   }
/*     */ 
/*     */   public int addMemberAllowed(OID groupOid, OID memberOid, String authToken)
/*     */   {
/*  61 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage("addMemberAllowed", groupOid, memberOid);
/*  62 */     msg.setProperty("authToken", authToken);
/*  63 */     return Engine.getAgent().sendRPCReturnInt(msg).intValue();
/*     */   }
/*     */ 
/*     */   public int setAllowedMembers(OID groupOid, Set<OID> allowedMembers)
/*     */   {
/*  74 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage("addMemberAllowed", groupOid);
/*  75 */     msg.setProperty("allowedMembers", (Serializable)allowedMembers);
/*  76 */     return Engine.getAgent().sendRPCReturnInt(msg).intValue();
/*     */   }
/*     */ 
/*     */   public Set<OID> getAllowedMembers(OID groupOid)
/*     */   {
/*  85 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage("getAllowedMembers", groupOid);
/*  86 */     return (Set)Engine.getAgent().sendRPCReturnObject(msg);
/*     */   }
/*     */ 
/*     */   public static int addMember(OID groupOid, OID memberOid, int priority, boolean allowedSpeaker)
/*     */   {
/* 102 */     return sendAddMemberMessage(groupOid, memberOid, priority, allowedSpeaker);
/*     */   }
/*     */ 
/*     */   public static int isMember(OID groupOid, OID memberOid)
/*     */   {
/* 113 */     return sendVoicePluginRPC("isMember", groupOid, memberOid);
/*     */   }
/*     */ 
/*     */   public static int removeMember(OID groupOid, OID memberOid)
/*     */   {
/* 125 */     return sendVoicePluginRPC("isPositional", groupOid, memberOid);
/*     */   }
/*     */ 
/*     */   public static int isMemberSpeaking(OID groupOid, OID memberOid)
/*     */   {
/* 136 */     return sendVoicePluginRPC("isMemberSpeaking", groupOid, memberOid);
/*     */   }
/*     */ 
/*     */   public static int isListener(OID groupOid, OID memberOid)
/*     */   {
/* 147 */     return sendVoicePluginRPC("isListener", groupOid, memberOid);
/*     */   }
/*     */ 
/*     */   public static int setAllowedSpeaker(OID groupOid, OID memberOid, boolean add)
/*     */   {
/* 162 */     return sendVoicePluginRPC("setAllowedSpeaker", groupOid, memberOid, add);
/*     */   }
/*     */ 
/*     */   public static int setMemberSpeaking(OID groupOid, OID memberOid, boolean add)
/*     */   {
/* 182 */     return sendVoicePluginRPC("setMemberSpeaking", groupOid, memberOid, add);
/*     */   }
/*     */ 
/*     */   public static int setListener(OID groupOid, OID memberOid, boolean add)
/*     */   {
/* 197 */     return sendVoicePluginRPC("setListener", groupOid, memberOid, add);
/*     */   }
/*     */ 
/*     */   public static int isAllowedSpeaker(OID groupOid, OID memberOid)
/*     */   {
/* 213 */     return sendVoicePluginRPC("isAllowedSpeaker", groupOid, memberOid);
/*     */   }
/*     */ 
/*     */   public static OID getPlayerGroup(OID memberOid)
/*     */   {
/* 223 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage("getPlayerGroup", memberOid);
/* 224 */     return Engine.getAgent().sendRPCReturnOID(msg);
/*     */   }
/*     */ 
/*     */   public static String errorString(int errorCode)
/*     */   {
/* 231 */     switch (errorCode) {
/*     */     case -1:
/* 233 */       return "There is no group with the supplied groupOid";
/*     */     case -2:
/* 235 */       return "The group with the supplied groupOid already exists";
/*     */     case -3:
/* 237 */       return "There is no member in the group identified by the supplied groupOid with the supplied memberOid";
/*     */     case -4:
/* 239 */       return "There is already a member with the supplied memberOid in the group identified by the groupOid";
/*     */     case -5:
/* 241 */       return "The VoicePlugin doesn't recognize the supplied voice message opcode";
/*     */     case -6:
/* 243 */       return "The player identified by the memberOid is not currently connected to the VoicePlugin";
/*     */     case -7:
/* 245 */       return "There is no 'add' property in the message";
/*     */     case -8:
/* 247 */       return "There is no 'maxVoices' property in the message";
/*     */     case -9:
/* 249 */       return "There is no 'positional' property in the message";
/*     */     }
/* 251 */     return "No error corresponding to the supplied error code";
/*     */   }
/*     */ 
/*     */   protected static WorldManagerClient.ExtensionMessage makeVoicePluginMessage(String opcode, OID groupOid)
/*     */   {
/* 261 */     WorldManagerClient.ExtensionMessage msg = new WorldManagerClient.ExtensionMessage();
/* 262 */     msg.setMsgType(MSG_TYPE_VOICECLIENT);
/* 263 */     msg.setProperty("opcode", opcode);
/* 264 */     msg.setProperty("groupOid", groupOid);
/* 265 */     return msg;
/*     */   }
/*     */ 
/*     */   protected static WorldManagerClient.ExtensionMessage makeVoicePluginMessage(String opcode, OID groupOid, OID memberOid) {
/* 269 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage(opcode, groupOid);
/* 270 */     msg.setProperty("memberOid", memberOid);
/* 271 */     return msg;
/*     */   }
/*     */ 
/*     */   protected static WorldManagerClient.ExtensionMessage makeVoicePluginMessage(String opcode, OID groupOid, OID memberOid, boolean add) {
/* 275 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage(opcode, groupOid, memberOid);
/* 276 */     msg.setProperty("add", Boolean.valueOf(add));
/* 277 */     return msg;
/*     */   }
/*     */ 
/*     */   protected static int sendNewGroupMessage(String opcode, OID groupOid, boolean positional, int maxVoices) {
/* 281 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage(opcode, groupOid);
/* 282 */     msg.setProperty("positional", Boolean.valueOf(positional));
/* 283 */     msg.setProperty("maxVoices", Integer.valueOf(maxVoices));
/* 284 */     return Engine.getAgent().sendRPCReturnInt(msg).intValue();
/*     */   }
/*     */ 
/*     */   protected static int sendAddMemberMessage(OID groupOid, OID memberOid, int priority, boolean allowedSpeaker) {
/* 288 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage("addMember", groupOid, memberOid);
/* 289 */     msg.setProperty("priority", Integer.valueOf(priority));
/* 290 */     msg.setProperty("allowedSpeaker", Boolean.valueOf(allowedSpeaker));
/* 291 */     return Engine.getAgent().sendRPCReturnInt(msg).intValue();
/*     */   }
/*     */ 
/*     */   protected static int sendVoicePluginRPC(String opcode, OID groupOid) {
/* 295 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage(opcode, groupOid);
/* 296 */     return Engine.getAgent().sendRPCReturnInt(msg).intValue();
/*     */   }
/*     */ 
/*     */   protected static int sendVoicePluginRPC(String opcode, OID groupOid, OID memberOid) {
/* 300 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage(opcode, groupOid, memberOid);
/* 301 */     return Engine.getAgent().sendRPCReturnInt(msg).intValue();
/*     */   }
/*     */ 
/*     */   protected static int sendVoicePluginRPC(String opcode, OID groupOid, OID memberOid, boolean add) {
/* 305 */     WorldManagerClient.ExtensionMessage msg = makeVoicePluginMessage(opcode, groupOid, memberOid, add);
/* 306 */     return Engine.getAgent().sendRPCReturnInt(msg).intValue();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.VoiceClient
 * JD-Core Version:    0.6.0
 */