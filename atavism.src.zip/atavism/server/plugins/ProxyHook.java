package atavism.server.plugins;

import atavism.msgsys.Message;
import atavism.server.engine.Hook;
import atavism.server.objects.Player;

public abstract interface ProxyHook extends Hook
{
  public abstract void processMessage(Message paramMessage, int paramInt, Player paramPlayer);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.ProxyHook
 * JD-Core Version:    0.6.0
 */