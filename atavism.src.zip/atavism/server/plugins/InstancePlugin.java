/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.agis.plugins.AgisMobClient;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageTypeFilter;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.server.engine.Database;
/*      */ import atavism.server.engine.DefaultWorldLoaderOverride;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.EnginePlugin;
/*      */ import atavism.server.engine.EnginePlugin.DeleteHook;
/*      */ import atavism.server.engine.EnginePlugin.GenerateSubObjectHook;
/*      */ import atavism.server.engine.EnginePlugin.SubObjData;
/*      */ import atavism.server.engine.EnginePlugin.UnloadHook;
/*      */ import atavism.server.engine.Hook;
/*      */ import atavism.server.engine.HookManager;
/*      */ import atavism.server.engine.Namespace;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.engine.PersistenceManager;
/*      */ import atavism.server.engine.PluginStatus;
/*      */ import atavism.server.engine.PropertyMatcher.Factory;
/*      */ import atavism.server.engine.PropertySearch;
/*      */ import atavism.server.engine.SearchClause;
/*      */ import atavism.server.engine.SearchManager;
/*      */ import atavism.server.engine.SearchSelection;
/*      */ import atavism.server.engine.Searchable;
/*      */ import atavism.server.engine.TerrainConfig;
/*      */ import atavism.server.engine.WorldCollectionLoaderContext;
/*      */ import atavism.server.engine.WorldLoaderOverride;
/*      */ import atavism.server.messages.PopulationFilter;
/*      */ import atavism.server.objects.Entity;
/*      */ import atavism.server.objects.EntityManager;
/*      */ import atavism.server.objects.EntitySearchable;
/*      */ import atavism.server.objects.Instance;
/*      */ import atavism.server.objects.InstanceTemplate;
/*      */ import atavism.server.objects.ObjectTypes;
/*      */ import atavism.server.objects.Region;
/*      */ import atavism.server.objects.Region.Search;
/*      */ import atavism.server.objects.SpawnData;
/*      */ import atavism.server.objects.Template;
/*      */ import atavism.server.util.FileUtil;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.Logger;
/*      */ import java.io.File;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ 
/*      */ public class InstancePlugin extends EnginePlugin
/*      */ {
/*   63 */   protected static final Logger log = new Logger("InstancePlugin");
/*      */ 
/*  187 */   private static Map<String, Class> loaderOverrideClasses = new HashMap();
/*      */ 
/* 1126 */   Map<String, Template> instanceTemplates = new HashMap();
/* 1127 */   List<String> pendingUniqueNames = new ArrayList();
/* 1128 */   PopulationChangeCallback populationChangeCallback = null;
/*      */ 
/*      */   public InstancePlugin()
/*      */   {
/*   67 */     super("Instance");
/*   68 */     setPluginType("Instance");
/*   69 */     registerWorldLoaderOverrideClass("default", DefaultWorldLoaderOverride.class);
/*      */   }
/*      */ 
/*      */   public void onActivate()
/*      */   {
/*   78 */     setPluginAvailable(false);
/*      */ 
/*   80 */     registerHooks();
/*      */ 
/*   82 */     MessageTypeFilter filter = new MessageTypeFilter();
/*   83 */     filter.addType(InstanceClient.MSG_TYPE_REGISTER_INSTANCE_TEMPLATE);
/*   84 */     filter.addType(InstanceClient.MSG_TYPE_CREATE_INSTANCE);
/*   85 */     filter.addType(InstanceClient.MSG_TYPE_LOAD_INSTANCE);
/*   86 */     filter.addType(InstanceClient.MSG_TYPE_GET_INSTANCE_INFO);
/*   87 */     filter.addType(InstanceClient.MSG_TYPE_GET_MARKER);
/*   88 */     filter.addType(InstanceClient.MSG_TYPE_GET_REGION);
/*   89 */     filter.addType(InstanceClient.MSG_TYPE_GET_ENTITY_OIDS);
/*      */ 
/*   91 */     filter.addType(WorldManagerClient.MSG_TYPE_SPAWNED);
/*   92 */     filter.addType(WorldManagerClient.MSG_TYPE_DESPAWNED);
/*      */ 
/*   94 */     Engine.getAgent().createSubscription(filter, this, 8);
/*      */ 
/*   97 */     MessageTypeFilter noResponseFilter = new MessageTypeFilter();
/*   98 */     noResponseFilter.addType(WorldManagerClient.MSG_TYPE_UPDATE_OBJECT);
/*   99 */     Engine.getAgent().createSubscription(noResponseFilter, this);
/*      */ 
/*  101 */     PopulationFilter populationFilter = new PopulationFilter(ObjectTypes.player);
/*      */ 
/*  103 */     Engine.getAgent().createSubscription(populationFilter, this);
/*      */ 
/*  105 */     registerPluginNamespace(InstanceClient.NAMESPACE, new InstanceGenerateSubObjectHook());
/*      */ 
/*  108 */     registerUnloadHook(InstanceClient.NAMESPACE, new InstanceUnloadHook());
/*  109 */     registerDeleteHook(InstanceClient.NAMESPACE, new InstanceDeleteHook());
/*      */ 
/*  111 */     SearchManager.registerMatcher(PropertySearch.class, Entity.class, new PropertyMatcher.Factory());
/*      */ 
/*  113 */     SearchManager.registerSearchable(ObjectTypes.instance, new EntitySearchable(ObjectTypes.instance));
/*      */ 
/*  116 */     SearchManager.registerMatcher(Region.Search.class, Region.class, new PropertyMatcher.Factory());
/*      */ 
/*  118 */     SearchManager.registerSearchable(Region.OBJECT_TYPE, new RegionSearch());
/*      */   }
/*      */ 
/*      */   protected void registerHooks()
/*      */   {
/*  125 */     getHookManager().addHook(InstanceClient.MSG_TYPE_REGISTER_INSTANCE_TEMPLATE, new RegisterInstanceTemplateHook());
/*      */ 
/*  128 */     getHookManager().addHook(InstanceClient.MSG_TYPE_CREATE_INSTANCE, new CreateInstanceHook());
/*      */ 
/*  131 */     getHookManager().addHook(InstanceClient.MSG_TYPE_LOAD_INSTANCE, new LoadInstanceHook());
/*      */ 
/*  134 */     getHookManager().addHook(InstanceClient.MSG_TYPE_GET_INSTANCE_INFO, new GetInstanceInfoHook());
/*      */ 
/*  137 */     getHookManager().addHook(InstanceClient.MSG_TYPE_GET_REGION, new GetRegionHook());
/*      */ 
/*  140 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_SPAWNED, new PopulationHook());
/*      */ 
/*  143 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_DESPAWNED, new PopulationHook());
/*      */ 
/*  146 */     getHookManager().addHook(InstanceClient.MSG_TYPE_GET_ENTITY_OIDS, new GetMatchingEntityOidsHook());
/*      */ 
/*  151 */     getHookManager().addHook(WorldManagerClient.MSG_TYPE_UPDATE_OBJECT, new UpdateObjectHook());
/*      */   }
/*      */ 
/*      */   protected void sendSpawnGenerators(Instance instance)
/*      */   {
/*  157 */     List spawnDataList = instance.getSpawnData();
/*  158 */     for (SpawnData spawnData : spawnDataList)
/*  159 */       MobManagerClient.createSpawnGenerator(spawnData);
/*      */   }
/*      */ 
/*      */   public static void registerWorldLoaderOverrideClass(String name, Class loaderOverrideClass)
/*      */   {
/*  175 */     synchronized (loaderOverrideClasses) {
/*  176 */       loaderOverrideClasses.put(name, loaderOverrideClass);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Class getWorldLoaderOverrideClass(String name)
/*      */   {
/*  184 */     return (Class)loaderOverrideClasses.get(name);
/*      */   }
/*      */ 
/*      */   private OID waitForUniqueName(String instanceName)
/*      */   {
/*  466 */     OID instanceOid = null;
/*  467 */     synchronized (this.pendingUniqueNames) {
/*  468 */       while (this.pendingUniqueNames.contains(instanceName))
/*      */         try {
/*  470 */           this.pendingUniqueNames.wait();
/*      */         } catch (InterruptedException ex) {
/*      */         }
/*  473 */       Instance instance = getInstance(instanceName);
/*  474 */       if (instance == null)
/*  475 */         instanceOid = getPersistentInstanceOid(instanceName);
/*      */       else {
/*  477 */         instanceOid = instance.getOid();
/*      */       }
/*  479 */       if (instanceOid == null) {
/*  480 */         this.pendingUniqueNames.add(instanceName);
/*      */       }
/*  482 */       return instanceOid;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void releaseUniqueName(String instanceName)
/*      */   {
/*  488 */     synchronized (this.pendingUniqueNames) {
/*  489 */       this.pendingUniqueNames.remove(instanceName);
/*  490 */       this.pendingUniqueNames.notifyAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   private Instance getInstance(String name)
/*      */   {
/*  991 */     Entity[] entities = (Entity[])EntityManager.getAllEntitiesByNamespace(InstanceClient.NAMESPACE);
/*      */ 
/*  993 */     for (Entity entity : entities) {
/*  994 */       if (((entity instanceof Instance)) && 
/*  995 */         (name.equals(entity.getName()))) {
/*  996 */         return (Instance)entity;
/*      */       }
/*      */     }
/*  999 */     return null;
/*      */   }
/*      */ 
/*      */   private List<OID> getMatchingEntityOids(String name)
/*      */   {
/* 1004 */     Entity[] entities = EntityManager.getAllEntitiesByNamespace(InstanceClient.NAMESPACE);
/* 1005 */     List rv = new ArrayList();
/*      */ 
/* 1007 */     for (Entity entity : entities) {
/* 1008 */       if (name.equals(entity.getName())) {
/* 1009 */         rv.add(entity.getOid());
/*      */       }
/*      */     }
/* 1012 */     return rv;
/*      */   }
/*      */ 
/*      */   public OID getPersistentInstanceOid(String name)
/*      */   {
/* 1020 */     return Engine.getDatabase().getOidByName(name, InstanceClient.NAMESPACE);
/*      */   }
/*      */ 
/*      */   private boolean fileExist(String fileName)
/*      */   {
/* 1044 */     File file = new File(FileUtil.expandFileName(fileName));
/* 1045 */     return (file.exists()) && (file.canRead());
/*      */   }
/*      */ 
/*      */   private WorldLoaderOverride createLoaderOverride(String loaderName)
/*      */   {
/* 1050 */     Class loaderClass = null;
/*      */     try {
/* 1052 */       loaderClass = (Class)loaderOverrideClasses.get(loaderName);
/*      */ 
/* 1054 */       if (loaderClass == null) {
/* 1055 */         Log.error("World loader override class not registered, name=" + loaderName);
/*      */       }
/*      */ 
/* 1058 */       return (WorldLoaderOverride)loaderClass.newInstance();
/*      */     }
/*      */     catch (Exception ex) {
/* 1061 */       Log.exception("failed instantiating world loader, name=" + loaderName + " class=" + loaderClass.getName(), ex);
/*      */     }
/* 1063 */     return null;
/*      */   }
/*      */ 
/*      */   protected final PluginStatus selectWorldManagerPlugin()
/*      */   {
/* 1070 */     List plugins = Engine.getDatabase().getPluginStatus("WorldManager");
/*      */ 
/* 1072 */     Iterator iterator = plugins.iterator();
/* 1073 */     while (iterator.hasNext()) {
/* 1074 */       PluginStatus plugin = (PluginStatus)iterator.next();
/* 1075 */       if (plugin.run_id != Engine.getAgent().getDomainStartTime()) {
/* 1076 */         iterator.remove();
/*      */       }
/*      */     }
/* 1079 */     if (plugins.size() == 0)
/* 1080 */       return null;
/* 1081 */     return selectBestWorldManager(plugins);
/*      */   }
/*      */ 
/*      */   protected PluginStatus selectBestWorldManager(List<PluginStatus> plugins)
/*      */   {
/* 1087 */     PluginStatus selection = null;
/* 1088 */     int selectionEntityCount = 2147483647;
/* 1089 */     for (PluginStatus plugin : plugins) { Map status = Engine.makeMapOfString(plugin.status);
/*      */       int entityCount;
/*      */       try { entityCount = Integer.parseInt((String)status.get("entities"));
/*      */       } catch (Exception e)
/*      */       {
/* 1096 */         Log.exception("selectBestWorldManager: wmgr " + plugin.plugin_name + " invalid entity count: " + (String)status.get("entities"), e);
/*      */       }
/*      */ 
/* 1099 */       continue;
/*      */ 
/* 1101 */       if (entityCount < selectionEntityCount) {
/* 1102 */         selection = plugin;
/* 1103 */         selectionEntityCount = entityCount;
/*      */       }
/*      */     }
/* 1106 */     return selection;
/*      */   }
/*      */ 
/*      */   public void registerPopulationChangeCallback(PopulationChangeCallback populationChangeCallback)
/*      */   {
/* 1123 */     this.populationChangeCallback = populationChangeCallback;
/*      */   }
/*      */ 
/*      */   public static class PopulationChangeCallback
/*      */   {
/*      */     public void onInstancePopulationChange(OID instanceOid, String name, int population)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public class RegionSearch
/*      */     implements Searchable
/*      */   {
/*      */     public RegionSearch()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Collection runSearch(SearchClause search, SearchSelection selection)
/*      */     {
/* 1028 */       Region.Search regionSearch = (Region.Search)search;
/*      */ 
/* 1031 */       Instance instance = (Instance)EntityManager.getEntityByNamespace(regionSearch.getInstanceOid(), InstanceClient.NAMESPACE);
/*      */ 
/* 1033 */       if (instance == null) {
/* 1034 */         Log.error("runSearch: unknown instanceOid=" + regionSearch.getInstanceOid());
/* 1035 */         return null;
/*      */       }
/*      */ 
/* 1038 */       return instance.runRegionSearch(search, selection);
/*      */     }
/*      */   }
/*      */ 
/*      */   class UpdateObjectHook
/*      */     implements Hook
/*      */   {
/*      */     UpdateObjectHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  961 */       WorldManagerClient.UpdateMessage updateReq = (WorldManagerClient.UpdateMessage)msg;
/*  962 */       OID notifyOid = updateReq.getTarget();
/*  963 */       OID updateOid = updateReq.getSubject();
/*      */ 
/*  965 */       if (Log.loggingDebug) {
/*  966 */         InstancePlugin.log.debug("UpdateObjectHook: notifyOid=" + notifyOid + " updateOid=" + updateOid);
/*      */       }
/*      */ 
/*  969 */       Entity updateEntity = EntityManager.getEntityByNamespace(updateOid, InstanceClient.NAMESPACE);
/*  970 */       if (updateEntity == null) {
/*  971 */         InstancePlugin.log.debug("UpdateObjectHook: could not find sub object for oid=" + updateOid);
/*  972 */         return false;
/*      */       }
/*      */ 
/*  975 */       sendTargetedPropertyMessage(notifyOid, updateOid, updateEntity);
/*  976 */       return true;
/*      */     }
/*      */ 
/*      */     private void sendTargetedPropertyMessage(OID targetOid, OID updateOid, Entity updateEntity) {
/*  980 */       WorldManagerClient.TargetedPropertyMessage propMessage = new WorldManagerClient.TargetedPropertyMessage(targetOid, updateOid);
/*      */ 
/*  982 */       propMessage.setProperty("collisionPoints", updateEntity.getProperty("collisionPoints"));
/*      */ 
/*  984 */       Engine.getAgent().sendBroadcast(propMessage);
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetNavMeshHook
/*      */     implements Hook
/*      */   {
/*      */     GetNavMeshHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  937 */       InstanceClient.GetNavMeshPathMessage message = (InstanceClient.GetNavMeshPathMessage)msg;
/*  938 */       OID instanceOid = WorldManagerClient.getObjectInfo(message.getMobOid()).instanceOid;
/*      */ 
/*  940 */       Instance instance = (Instance)EntityManager.getEntityByNamespace(instanceOid, InstanceClient.NAMESPACE);
/*      */ 
/*  942 */       if (instance == null) {
/*  943 */         Log.error("GetNavMeshHook: unknown instanceOid=" + instanceOid + " msg=" + msg);
/*      */ 
/*  945 */         return true;
/*      */       }
/*      */ 
/*  951 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetMatchingEntityOidsHook
/*      */     implements Hook
/*      */   {
/*      */     GetMatchingEntityOidsHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  925 */       InstanceClient.GetMatchingEntityOidsMessage message = (InstanceClient.GetMatchingEntityOidsMessage)msg;
/*      */ 
/*  927 */       Entity[] entities = EntityManager.getAllEntitiesByNamespace(InstanceClient.NAMESPACE);
/*  928 */       List oids = InstancePlugin.this.getMatchingEntityOids(message.getEntityName());
/*  929 */       Engine.getAgent().sendObjectResponse(msg, oids);
/*  930 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class PopulationHook
/*      */     implements Hook
/*      */   {
/*      */     PopulationHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*      */       int delta;
/*  894 */       if ((msg instanceof WorldManagerClient.SpawnedMessage)) {
/*  895 */         WorldManagerClient.SpawnedMessage message = (WorldManagerClient.SpawnedMessage)msg;
/*  896 */         OID instanceOid = message.getInstanceOid();
/*  897 */         delta = 1;
/*      */       }
/*      */       else
/*      */       {
/*      */         int delta;
/*  899 */         if ((msg instanceof WorldManagerClient.DespawnedMessage)) {
/*  900 */           WorldManagerClient.DespawnedMessage message = (WorldManagerClient.DespawnedMessage)msg;
/*  901 */           OID instanceOid = message.getInstanceOid();
/*  902 */           delta = -1;
/*      */         }
/*      */         else {
/*  905 */           return true;
/*      */         }
/*      */       }
/*      */       int delta;
/*      */       OID instanceOid;
/*  907 */       Instance instance = (Instance)EntityManager.getEntityByNamespace(instanceOid, InstanceClient.NAMESPACE);
/*      */ 
/*  909 */       if (instance == null) {
/*  910 */         Log.error("PopulationHook: unknown instanceOid=" + instanceOid + " msg=" + msg);
/*      */ 
/*  912 */         return true;
/*      */       }
/*      */ 
/*  915 */       int population = instance.changePlayerPopulation(delta);
/*  916 */       if (InstancePlugin.this.populationChangeCallback != null)
/*  917 */         InstancePlugin.this.populationChangeCallback.onInstancePopulationChange(instanceOid, instance.getName(), population);
/*  918 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class CheckPopulationHook
/*      */     implements Hook
/*      */   {
/*      */     CheckPopulationHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  885 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetRegionHook
/*      */     implements Hook
/*      */   {
/*      */     GetRegionHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  840 */       InstanceClient.GetRegionMessage message = (InstanceClient.GetRegionMessage)msg;
/*      */ 
/*  842 */       Instance instance = (Instance)EntityManager.getEntityByNamespace(message.getInstanceOid(), InstanceClient.NAMESPACE);
/*      */ 
/*  844 */       if (instance == null) {
/*  845 */         Log.error("GetRegionHook: unknown instanceOid=" + message.getInstanceOid());
/*      */ 
/*  847 */         Engine.getAgent().sendObjectResponse(msg, null);
/*  848 */         return true;
/*      */       }
/*      */ 
/*  851 */       Region region = instance.getRegion(message.getRegionName());
/*  852 */       Log.debug("GetRegionHook: name=" + message.getRegionName() + " instanceOid=" + message.getInstanceOid() + " " + region);
/*      */ 
/*  855 */       if (region == null) {
/*  856 */         Log.error("GetRegionHook: unknown regionName=" + message.getRegionName() + " instanceOid=" + message.getInstanceOid());
/*      */ 
/*  859 */         Engine.getAgent().sendObjectResponse(msg, null);
/*  860 */         return true;
/*      */       }
/*      */ 
/*  863 */       Region result = new Region(region.getName());
/*  864 */       result.setPriority(region.getPriority());
/*  865 */       long fetchFlags = message.getFlags();
/*  866 */       if ((fetchFlags & 1L) != 0L)
/*  867 */         result.setBoundary(region.getBoundary());
/*  868 */       if ((fetchFlags & 0x2) != 0L)
/*  869 */         result.setProperties(region.getPropertyMapRef());
/*  870 */       Engine.getAgent().sendObjectResponse(msg, result);
/*  871 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetInstanceInfoHook
/*      */     implements Hook
/*      */   {
/*      */     GetInstanceInfoHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  721 */       InstanceClient.GetInstanceInfoMessage message = (InstanceClient.GetInstanceInfoMessage)msg;
/*      */ 
/*  723 */       if (((message.getFlags() & 0x2000) != 0) && (message.getInstanceOid() == null))
/*      */       {
/*  725 */         List list = getMultipleInstanceInfo(message.getFlags(), message.getInstanceName());
/*      */ 
/*  727 */         Engine.getAgent().sendObjectResponse(msg, list);
/*      */       }
/*      */       else {
/*  730 */         InstanceClient.InstanceInfo info = getInstanceInfo(message.getFlags(), message.getInstanceOid(), message.getInstanceName());
/*      */ 
/*  732 */         Engine.getAgent().sendObjectResponse(msg, info);
/*      */       }
/*  734 */       return true;
/*      */     }
/*      */ 
/*      */     public InstanceClient.InstanceInfo getInstanceInfo(int infoFlags, OID instanceOid, String instanceName)
/*      */     {
/*  740 */       InstanceClient.InstanceInfo info = new InstanceClient.InstanceInfo();
/*      */ 
/*  742 */       Instance instance = null;
/*  743 */       if (instanceOid == null) {
/*  744 */         if (instanceName == null) {
/*  745 */           return info;
/*      */         }
/*  747 */         instance = InstancePlugin.this.getInstance(instanceName);
/*  748 */         if (instance == null) {
/*  749 */           instanceOid = InstancePlugin.this.getPersistentInstanceOid(instanceName);
/*  750 */           if (instanceOid == null)
/*      */           {
/*  753 */             instanceOid = InstanceClient.loadInstance(instanceName);
/*  754 */             if (instanceOid == null)
/*  755 */               return info;
/*      */           }
/*      */         }
/*      */         else {
/*  759 */           instanceOid = instance.getOid();
/*  760 */           info.loaded = (instance.getState() == 3);
/*      */         }
/*      */       }
/*      */       else {
/*  764 */         instance = (Instance)EntityManager.getEntityByNamespace(instanceOid, InstanceClient.NAMESPACE);
/*      */ 
/*  766 */         if (instance == null) {
/*  767 */           return info;
/*      */         }
/*  769 */         info.loaded = (instance.getState() == 3);
/*      */       }
/*      */ 
/*  772 */       if ((infoFlags & 0x1) != 0) {
/*  773 */         info.oid = instanceOid;
/*      */       }
/*      */ 
/*  776 */       if (instance == null) {
/*  777 */         return info;
/*      */       }
/*      */ 
/*  780 */       getInstanceInfo(instance, infoFlags, info);
/*      */ 
/*  782 */       return info;
/*      */     }
/*      */ 
/*      */     public List<InstanceClient.InstanceInfo> getMultipleInstanceInfo(int infoFlags, String instanceName)
/*      */     {
/*  788 */       Entity[] entities = (Entity[])EntityManager.getAllEntitiesByNamespace(InstanceClient.NAMESPACE);
/*      */ 
/*  790 */       List list = new ArrayList();
/*  791 */       for (Entity entity : entities) {
/*  792 */         if ((!(entity instanceof Instance)) || (!instanceName.equals(((Instance)entity).getName()))) {
/*      */           continue;
/*      */         }
/*  795 */         Instance instance = (Instance)entity;
/*  796 */         InstanceClient.InstanceInfo info = new InstanceClient.InstanceInfo();
/*  797 */         info.loaded = (instance.getState() == 3);
/*  798 */         info.oid = instance.getOid();
/*  799 */         getInstanceInfo(instance, infoFlags, info);
/*  800 */         list.add(info);
/*      */       }
/*  802 */       return list;
/*      */     }
/*      */ 
/*      */     public void getInstanceInfo(Instance instance, int infoFlags, InstanceClient.InstanceInfo info)
/*      */     {
/*  808 */       if ((infoFlags & 0x2) != 0)
/*  809 */         info.name = instance.getName();
/*  810 */       if ((infoFlags & 0x4) != 0) {
/*  811 */         info.templateName = instance.getTemplateName();
/*      */       }
/*      */ 
/*  814 */       if ((infoFlags & 0x8) != 0)
/*  815 */         info.skybox = instance.getGlobalSkybox();
/*  816 */       if ((infoFlags & 0x10) != 0)
/*  817 */         info.fog = instance.getGlobalFog();
/*  818 */       if ((infoFlags & 0x20) != 0)
/*  819 */         info.ambientLight = instance.getGlobalAmbientLight();
/*  820 */       if ((infoFlags & 0x40) != 0)
/*  821 */         info.dirLight = instance.getGlobalDirectionalLight();
/*  822 */       if ((infoFlags & 0x80) != 0)
/*  823 */         info.ocean = instance.getOceanData();
/*  824 */       if ((infoFlags & 0x100) != 0)
/*  825 */         info.worldFile = instance.getWorldFileName();
/*  826 */       if ((infoFlags & 0x200) != 0)
/*  827 */         info.terrainConfig = instance.getTerrainConfig();
/*  828 */       if ((infoFlags & 0x400) != 0)
/*  829 */         info.regionConfig = instance.getRegionConfig();
/*  830 */       if ((infoFlags & 0x800) != 0)
/*  831 */         info.playerPopulation = instance.getPlayerPopulation();
/*  832 */       if ((infoFlags & 0x1000) != 0)
/*  833 */         info.populationLimit = instance.getPopulationLimit();
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceDeleteHook
/*      */     implements EnginePlugin.DeleteHook
/*      */   {
/*      */     InstanceDeleteHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onDelete(OID oid, Namespace namespace)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onDelete(Entity ee)
/*      */     {
/*  708 */       Instance instance = (Instance)ee;
/*  709 */       instance.setState(5);
/*      */ 
/*  712 */       Log.info("InstancePlugin: INSTANCE_DELETE instanceOid=" + instance.getOid() + " name=[" + instance.getName() + "]" + " templateName=[" + instance.getTemplateName() + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceUnloadHook
/*      */     implements EnginePlugin.UnloadHook
/*      */   {
/*      */     InstanceUnloadHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onUnload(Entity ee)
/*      */     {
/*  691 */       Instance instance = (Instance)ee;
/*  692 */       instance.setState(4);
/*  693 */       if (instance.getPersistenceFlag()) {
/*  694 */         Engine.getPersistenceManager().persistEntity(instance);
/*      */       }
/*  696 */       Log.info("InstancePlugin: INSTANCE_UNLOAD instanceOid=" + instance.getOid() + " name=[" + instance.getName() + "]" + " templateName=[" + instance.getTemplateName() + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   class InstanceGenerateSubObjectHook extends EnginePlugin.GenerateSubObjectHook
/*      */   {
/*      */     public InstanceGenerateSubObjectHook()
/*      */     {
/*  620 */       super();
/*      */     }
/*      */ 
/*      */     public EnginePlugin.SubObjData generateSubObject(Template template, Namespace namespace, OID instanceOid)
/*      */     {
/*  626 */       Instance instance = new Instance(instanceOid);
/*  627 */       instance.setType(ObjectTypes.instance);
/*      */ 
/*  629 */       instance.setName((String)template.get(InstanceClient.NAMESPACE, "name"));
/*      */ 
/*  632 */       String templateName = (String)template.get(InstanceClient.NAMESPACE, "templateName");
/*      */ 
/*  635 */       Log.debug("PORTAL: template name: " + templateName);
/*  636 */       instance.setTemplateName(templateName);
/*      */ 
/*  640 */       instance.setInitScriptFileName((String)template.get(InstanceClient.NAMESPACE, "initScriptFileName"));
/*      */ 
/*  643 */       instance.setLoadScriptFileName((String)template.get(InstanceClient.NAMESPACE, "loadScriptFileName"));
/*      */ 
/*  646 */       instance.setWorldLoaderOverrideName((String)template.get(InstanceClient.NAMESPACE, "loaderOverrideName"));
/*      */ 
/*  650 */       String terrainConfigFile = (String)template.get(InstanceClient.NAMESPACE, "terrainConfigFile");
/*      */ 
/*  653 */       if (terrainConfigFile != null) {
/*  654 */         TerrainConfig terrainConfig = new TerrainConfig();
/*  655 */         terrainConfig.setConfigType("file");
/*  656 */         terrainConfig.setConfigData(terrainConfigFile);
/*  657 */         instance.setTerrainConfig(terrainConfig);
/*      */       }
/*      */ 
/*  661 */       Map props = template.getSubMap(Namespace.INSTANCE);
/*      */ 
/*  663 */       for (Map.Entry entry : props.entrySet()) {
/*  664 */         String key = (String)entry.getKey();
/*  665 */         Serializable value = (Serializable)entry.getValue();
/*  666 */         if (!key.startsWith(":")) {
/*  667 */           instance.setProperty(key, value);
/*      */         }
/*      */       }
/*      */ 
/*  671 */       Boolean persistent = (Boolean)template.get(Namespace.OBJECT_MANAGER, ":persistent");
/*      */ 
/*  673 */       if (persistent == null)
/*  674 */         persistent = Boolean.valueOf(false);
/*  675 */       instance.setPersistenceFlag(persistent.booleanValue());
/*  676 */       instance.setState(1);
/*      */ 
/*  678 */       EntityManager.registerEntityByNamespace(instance, InstanceClient.NAMESPACE);
/*      */ 
/*  681 */       if (persistent.booleanValue()) {
/*  682 */         Engine.getPersistenceManager().persistEntity(instance);
/*      */       }
/*  684 */       return new EnginePlugin.SubObjData();
/*      */     }
/*      */   }
/*      */ 
/*      */   class LoadInstanceHook
/*      */     implements Hook
/*      */   {
/*      */     LoadInstanceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  496 */       SubjectMessage message = (SubjectMessage)msg;
/*  497 */       OID instanceOid = message.getSubject();
/*      */ 
/*  499 */       Instance instance = (Instance)EntityManager.getEntityByNamespace(instanceOid, InstanceClient.NAMESPACE);
/*      */ 
/*  501 */       if (instance != null) {
/*  502 */         if (Log.loggingDebug) {
/*  503 */           Log.debug("LoadInstanceHook: instance already loaded instanceOid=" + instanceOid + " state=" + instance.getState());
/*      */         }
/*  505 */         if (instance.getState() == 3) {
/*  506 */           Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(0));
/*      */         }
/*      */         else {
/*  509 */           Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-4));
/*      */         }
/*  511 */         return true;
/*      */       }
/*      */ 
/*  514 */       List namespaces = Engine.getDatabase().getObjectNamespaces(instanceOid);
/*      */ 
/*  516 */       if (namespaces == null) {
/*  517 */         Log.debug("LoadInstanceHook: unknown instanceOid=" + instanceOid);
/*  518 */         Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-1));
/*      */ 
/*  520 */         return true;
/*      */       }
/*  522 */       if (!namespaces.contains(InstanceClient.NAMESPACE)) {
/*  523 */         Log.error("LoadInstanceHook: not an instance oid=" + instanceOid);
/*      */ 
/*  525 */         Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-2));
/*      */ 
/*  527 */         return true;
/*      */       }
/*      */ 
/*  531 */       PluginStatus plugin = InstancePlugin.this.selectWorldManagerPlugin();
/*  532 */       if (plugin != null) {
/*  533 */         if (Log.loggingDebug) {
/*  534 */           Log.debug("LoadInstanceHook: assigned world manager " + plugin.plugin_name + " host=" + plugin.host_name + " for instanceOid=" + instanceOid);
/*      */         }
/*      */ 
/*  537 */         WorldManagerClient.hostInstance(instanceOid, plugin.plugin_name);
/*      */       }
/*      */       else {
/*  540 */         Log.error("LoadInstanceHook: no world manager for instance, instanceOid=" + instanceOid);
/*      */ 
/*  542 */         Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-3));
/*      */ 
/*  544 */         return true;
/*      */       }
/*      */ 
/*  547 */       OID result = ObjectManagerClient.loadObject(instanceOid);
/*  548 */       if (result == null) {
/*  549 */         Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-2));
/*      */ 
/*  551 */         return true;
/*      */       }
/*      */ 
/*  554 */       instance = (Instance)EntityManager.getEntityByNamespace(instanceOid, InstanceClient.NAMESPACE);
/*      */ 
/*  557 */       Log.info("InstancePlugin: LOAD_INSTANCE instanceOid=" + instanceOid + " name=[" + instance.getName() + "]" + " templateName=[" + instance.getTemplateName() + "]" + " wmName=" + plugin.plugin_name);
/*      */ 
/*  562 */       instance.setState(2);
/*      */ 
/*  564 */       String loaderName = instance.getWorldLoaderOverrideName();
/*  565 */       if (loaderName == null)
/*  566 */         loaderName = "default";
/*  567 */       instance.setWorldLoaderOverride(InstancePlugin.this.createLoaderOverride(loaderName));
/*      */ 
/*  569 */       if (!instance.loadWorldData())
/*      */       {
/*  571 */         Log.error("LoadInstanceHook: load world file failed fileName=" + instance.getWorldFileName() + " instanceOid=" + instanceOid);
/*      */ 
/*  575 */         Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-2));
/*      */ 
/*  577 */         return true;
/*      */       }
/*      */ 
/*  580 */       if (!instance.loadWorldCollections())
/*      */       {
/*  582 */         Log.error("LoadInstanceHook: load world collections failed loaderContext=" + instance.getWorldCollectionLoaderContext() + " instanceOid=" + instanceOid);
/*      */ 
/*  586 */         Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-2));
/*      */ 
/*  588 */         return true;
/*      */       }
/*      */ 
/*  591 */       SubjectMessage loadContentMessage = new SubjectMessage(InstanceClient.MSG_TYPE_LOAD_INSTANCE_CONTENT, instanceOid);
/*      */ 
/*  593 */       Engine.getAgent().sendRPC(loadContentMessage);
/*      */ 
/*  595 */       InstancePlugin.this.sendSpawnGenerators(instance);
/*      */ 
/*  597 */       if (!instance.runLoadScript())
/*      */       {
/*  599 */         Log.error("LoadInstanceHook: init world script failed fileName=" + instance.getInitScriptFileName() + " instanceOid=" + instanceOid);
/*      */ 
/*  603 */         Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(-2));
/*      */ 
/*  605 */         return true;
/*      */       }
/*      */ 
/*  608 */       instance.setWorldLoaderOverride(null);
/*  609 */       instance.setState(3);
/*      */ 
/*  611 */       Engine.getAgent().sendIntegerResponse(message, Integer.valueOf(0));
/*      */ 
/*  613 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class CreateInstanceHook
/*      */     implements Hook
/*      */   {
/*      */     String instanceName;
/*  461 */     Boolean uniqueNameFlag = Boolean.valueOf(false);
/*      */ 
/*      */     CreateInstanceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  235 */       InstanceClient.CreateInstanceMessage message = (InstanceClient.CreateInstanceMessage)msg;
/*  236 */       return new CreateInstanceHook(InstancePlugin.this).handleMessage(message);
/*      */     }
/*      */ 
/*      */     private boolean handleMessage(InstanceClient.CreateInstanceMessage message)
/*      */     {
/*      */       try {
/*  242 */         OID instanceOid = createInstance(message.getTemplateName(), message.getOverrideTemplate());
/*      */ 
/*  244 */         Engine.getAgent().sendOIDResponse(message, instanceOid);
/*      */       }
/*      */       finally {
/*  247 */         if (this.uniqueNameFlag.booleanValue())
/*  248 */           InstancePlugin.this.releaseUniqueName(this.instanceName);
/*      */       }
/*  250 */       return true;
/*      */     }
/*      */ 
/*      */     private OID createInstance(String templateName, Template overrideTemplate)
/*      */     {
/*  256 */       if (Log.loggingDebug) {
/*  257 */         Log.debug("CreateInstanceHook: templateName=" + templateName + " override=" + overrideTemplate);
/*      */       }
/*      */ 
/*  260 */       if (templateName == null) {
/*  261 */         return null;
/*      */       }
/*      */ 
/*  264 */       Template template = (Template)InstancePlugin.this.instanceTemplates.get(templateName);
/*      */ 
/*  266 */       if (template == null) {
/*  267 */         Log.error("CreateInstanceHook: unknown template name=" + templateName);
/*      */ 
/*  269 */         return null;
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  274 */         mergedTemplate = (Template)template.clone();
/*      */       } catch (CloneNotSupportedException ex) {
/*  276 */         return null;
/*      */       }
/*      */ 
/*  279 */       Template mergedTemplate = mergedTemplate.merge(overrideTemplate);
/*      */ 
/*  283 */       String worldManagerPlugin = (String)mergedTemplate.get(WorldManagerClient.INSTANCE_NAMESPACE, ":wmName");
/*      */ 
/*  286 */       if ((worldManagerPlugin == null) || (worldManagerPlugin.equals(""))) {
/*  287 */         PluginStatus plugin = InstancePlugin.this.selectWorldManagerPlugin();
/*  288 */         if (plugin != null) {
/*  289 */           if (Log.loggingDebug) {
/*  290 */             Log.debug("CreateInstanceHook: assigned world manager " + plugin.plugin_name + " host=" + plugin.host_name);
/*      */           }
/*  292 */           mergedTemplate.put(WorldManagerClient.INSTANCE_NAMESPACE, ":wmName", plugin.plugin_name);
/*      */ 
/*  295 */           worldManagerPlugin = plugin.plugin_name;
/*      */         }
/*      */         else {
/*  298 */           Log.error("CreateInstanceHook: no world manager for instance, templateName=" + templateName);
/*      */ 
/*  300 */           return null;
/*      */         }
/*      */       }
/*      */ 
/*  304 */       mergedTemplate.put(InstanceClient.NAMESPACE, "templateName", templateName);
/*      */ 
/*  307 */       this.uniqueNameFlag = ((Boolean)mergedTemplate.get(InstanceClient.NAMESPACE, "uniqueName"));
/*      */ 
/*  309 */       if (this.uniqueNameFlag == null) {
/*  310 */         this.uniqueNameFlag = Boolean.valueOf(false);
/*      */       }
/*  312 */       this.instanceName = ((String)mergedTemplate.get(InstanceClient.NAMESPACE, "name"));
/*      */ 
/*  316 */       if (this.uniqueNameFlag.booleanValue()) {
/*  317 */         OID instanceOid = InstancePlugin.this.waitForUniqueName(this.instanceName);
/*  318 */         if (instanceOid != null) {
/*  319 */           Log.debug("CreateInstanceHook: instance name already exists, name=" + this.instanceName + " instanceOid=" + instanceOid);
/*  320 */           return null;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  337 */       String initScript = (String)mergedTemplate.get(InstanceClient.NAMESPACE, "initScriptFileName");
/*      */ 
/*  340 */       if (initScript != null) {
/*  341 */         initScript = FileUtil.expandFileName(initScript);
/*  342 */         mergedTemplate.put(InstanceClient.NAMESPACE, "initScriptFileName", initScript);
/*      */       }
/*      */ 
/*  346 */       if ((initScript != null) && (!InstancePlugin.this.fileExist(initScript))) {
/*  347 */         Log.error("CreateInstanceHook: init file not found fileName=" + initScript);
/*      */ 
/*  349 */         return null;
/*      */       }
/*      */ 
/*  352 */       String loadScript = (String)mergedTemplate.get(InstanceClient.NAMESPACE, "loadScriptFileName");
/*      */ 
/*  355 */       if (loadScript != null) {
/*  356 */         loadScript = FileUtil.expandFileName(loadScript);
/*  357 */         mergedTemplate.put(InstanceClient.NAMESPACE, "loadScriptFileName", loadScript);
/*      */       }
/*      */ 
/*  361 */       if ((loadScript != null) && (!InstancePlugin.this.fileExist(loadScript))) {
/*  362 */         Log.error("CreateInstanceHook: load script file not found fileName=" + loadScript);
/*      */ 
/*  364 */         return null;
/*      */       }
/*      */ 
/*  367 */       OID instanceOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", mergedTemplate);
/*      */ 
/*  370 */       if (instanceOid == null) {
/*  371 */         Log.error("CreateInstanceHook: generateObject failed name=" + mergedTemplate.get(InstanceClient.NAMESPACE, "name") + " templateName=" + templateName + " wmName=" + worldManagerPlugin);
/*      */ 
/*  375 */         return null;
/*      */       }
/*      */ 
/*  378 */       Log.info("InstancePlugin: CREATE_INSTANCE instanceOid=" + instanceOid + " name=[" + this.instanceName + "]" + " templateName=[" + templateName + "]" + " wmName=" + worldManagerPlugin);
/*      */ 
/*  383 */       Instance instance = (Instance)EntityManager.getEntityByNamespace(instanceOid, InstanceClient.NAMESPACE);
/*      */ 
/*  386 */       String loaderName = instance.getWorldLoaderOverrideName();
/*  387 */       if (loaderName == null)
/*  388 */         loaderName = "default";
/*  389 */       instance.setWorldLoaderOverride(InstancePlugin.this.createLoaderOverride(loaderName));
/*      */ 
/*  391 */       if (!instance.loadWorldData()) {
/*  392 */         Log.error("CreateInstanceHook: load world file failed fileName=" + instance.getWorldFileName());
/*      */ 
/*  394 */         return null;
/*      */       }
/*      */ 
/*  398 */       WorldCollectionLoaderContext loaderContext = new WorldCollectionLoaderContext();
/*  399 */       String worldCollectionFiles = (String)mergedTemplate.get(InstanceClient.NAMESPACE, "worldCollectionFiles");
/*      */ 
/*  402 */       if (worldCollectionFiles != null) {
/*  403 */         for (String worldCollectionFile : worldCollectionFiles.split(",")) {
/*  404 */           loaderContext.addWorldCollectionFile(worldCollectionFile);
/*      */         }
/*      */       }
/*  407 */       String worldCollectionDatabaseKeys = (String)mergedTemplate.get(InstanceClient.NAMESPACE, "worldCollectionDatabaseKeys");
/*      */ 
/*  410 */       if (worldCollectionDatabaseKeys != null) {
/*  411 */         for (String worldCollectionKey : worldCollectionDatabaseKeys.split(",")) {
/*  412 */           loaderContext.addWorldCollectionDatabaseKey(worldCollectionKey);
/*      */         }
/*      */       }
/*  415 */       instance.setWorldCollectionLoaderContext(loaderContext);
/*      */ 
/*  417 */       if (!instance.loadWorldCollections()) {
/*  418 */         Log.error("CreateInstanceHook: load world collections failed loaderContext=" + instance.getWorldCollectionLoaderContext());
/*      */ 
/*  420 */         return null;
/*      */       }
/*      */ 
/*  429 */       InstancePlugin.this.sendSpawnGenerators(instance);
/*      */ 
/*  432 */       int populationLimit = ((Integer)mergedTemplate.get(InstanceClient.NAMESPACE, "populationLimit")).intValue();
/*      */ 
/*  435 */       instance.setPopulationLimit(populationLimit);
/*      */ 
/*  437 */       if (!instance.runInitScript()) {
/*  438 */         Log.error("CreateInstanceHook: init world script failed fileName=" + instance.getInitScriptFileName());
/*      */ 
/*  440 */         return null;
/*      */       }
/*      */ 
/*  443 */       instance.setWorldLoaderOverride(null);
/*  444 */       instance.setState(3);
/*      */ 
/*  448 */       InstanceTemplate iTmpl = AgisMobClient.getInstanceTemplate(templateName);
/*  449 */       AgisMobClient.spawnInstanceObjects(iTmpl, instanceOid);
/*      */ 
/*  453 */       SubjectMessage loadedMessage = new SubjectMessage(InstanceClient.MSG_TYPE_INSTANCE_LOADED, instanceOid);
/*      */ 
/*  455 */       Engine.getAgent().sendBroadcast(loadedMessage);
/*      */ 
/*  457 */       return instanceOid;
/*      */     }
/*      */   }
/*      */ 
/*      */   class RegisterInstanceTemplateHook
/*      */     implements Hook
/*      */   {
/*      */     RegisterInstanceTemplateHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/*  192 */       InstanceClient.RegisterInstanceTemplateMessage message = (InstanceClient.RegisterInstanceTemplateMessage)msg;
/*      */ 
/*  195 */       Template template = message.getTemplate();
/*      */ 
/*  197 */       if (Log.loggingDebug) {
/*  198 */         Log.debug("RegisterInstanceTemplateHook: template=" + template);
/*      */       }
/*  200 */       if (template == null) {
/*  201 */         Engine.getAgent().sendBooleanResponse(message, Boolean.FALSE);
/*  202 */         return true;
/*      */       }
/*      */ 
/*  205 */       if (template.getName() == null) {
/*  206 */         Log.error("RegisterInstanceTemplateHook: missing template name");
/*  207 */         Engine.getAgent().sendBooleanResponse(message, Boolean.FALSE);
/*  208 */         return true;
/*      */       }
/*      */ 
/*  221 */       InstancePlugin.this.instanceTemplates.put(template.getName(), template);
/*      */ 
/*  223 */       if (Log.loggingDebug) {
/*  224 */         Log.debug("RegisterInstanceTemplateHook: added template name=" + template.getName());
/*      */       }
/*  226 */       Engine.getAgent().sendBooleanResponse(message, Boolean.TRUE);
/*      */ 
/*  228 */       return true;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.InstancePlugin
 * JD-Core Version:    0.6.0
 */