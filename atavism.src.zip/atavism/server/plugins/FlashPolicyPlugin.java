/*     */ package atavism.server.plugins;
/*     */ 
/*     */ import atavism.management.Management;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageAgent.DomainClient;
/*     */ import atavism.msgsys.MessageCallback;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.EnginePlugin;
/*     */ import atavism.server.engine.Hook;
/*     */ import atavism.server.engine.HookManager;
/*     */ import atavism.server.network.TcpAcceptCallback;
/*     */ import atavism.server.network.TcpServer;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.LinkedHashMap;
/*     */ 
/*     */ public class FlashPolicyPlugin extends EnginePlugin
/*     */   implements MessageCallback, TcpAcceptCallback
/*     */ {
/*  27 */   protected final String DEFAULT_POLICY = "<?xml version=\"1.0\"?>\n<!DOCTYPE cross-domain-policy SYSTEM \"/xml/dtds/cross-domain-policy.dtd\">\n<cross-domain-policy>\n  <site-control permitted-cross-domain-policies=\"master-only\"/>\n  <allow-access-from domain=\"*\" to-ports=\"*\"/>\n</cross-domain-policy>\n";
/*     */ 
/*  35 */   protected final int DEFAULT_PORT = 843;
/*  36 */   protected final String POLICY_REQUEST_STRING = "<policy-file-request/>";
/*     */ 
/*  38 */   protected TcpServer tcpServer = new TcpServer();
/*     */ 
/*  40 */   protected int port = 843;
/*  41 */   protected String policy = null;
/*  42 */   protected ByteBuffer policyBuffer = null;
/*     */ 
/*  44 */   protected static final Logger log = new Logger("FlashPolicyPlugin");
/*     */ 
/*  50 */   public static int idleTimeout = 60;
/*     */ 
/*  52 */   boolean devMode = true;
/*     */ 
/*     */   public FlashPolicyPlugin() {
/*  63 */     setPluginType("FlashPolicy");
/*     */     String flashPolicyPluginName;
/*     */     try { flashPolicyPluginName = Engine.getAgent().getDomainClient().allocName("PLUGIN", getPluginType() + "#");
/*     */     } catch (IOException e)
/*     */     {
/*  69 */       throw new AORuntimeException("Could not allocate flash policy plugin name", e);
/*     */     }
/*     */ 
/*  72 */     setName(flashPolicyPluginName);
/*     */ 
/*  76 */     setMessageHandler(null);
/*     */   }
/*     */ 
/*     */   public void onActivate()
/*     */   {
/*     */     try
/*     */     {
/*  96 */       registerHooks();
/*     */ 
/*  98 */       int flashPolicyPort = 843;
/*  99 */       String policyStr = "<?xml version=\"1.0\"?>\n<!DOCTYPE cross-domain-policy SYSTEM \"/xml/dtds/cross-domain-policy.dtd\">\n<cross-domain-policy>\n  <site-control permitted-cross-domain-policies=\"master-only\"/>\n  <allow-access-from domain=\"*\" to-ports=\"*\"/>\n</cross-domain-policy>\n";
/*     */ 
/* 101 */       InetSocketAddress bindAddress = getBindAddress();
/* 102 */       if (Log.loggingDebug) {
/* 103 */         Log.debug("FlashPolicy: binding for incoming client connections at: " + bindAddress);
/*     */       }
/* 105 */       setPolicy(policyStr);
/*     */ 
/* 107 */       String flashPolicyFile = Engine.getProperty("atavism.flashpolicy.policyfile");
/* 108 */       if (flashPolicyFile != null) {
/* 109 */         flashPolicyFile = flashPolicyFile.trim();
/* 110 */         if (Log.loggingDebug)
/* 111 */           Log.debug("FlashPolicy: serving policy file from " + flashPolicyFile);
/*     */         try {
/* 113 */           StringBuffer fileData = new StringBuffer();
/* 114 */           BufferedReader reader = new BufferedReader(new FileReader(flashPolicyFile));
/* 115 */           char[] buf = new char[1024];
/* 116 */           int bytesRead = 0;
/* 117 */           while ((bytesRead = reader.read(buf)) != -1)
/*     */           {
/* 119 */             fileData.append(buf, 0, bytesRead);
/*     */           }
/* 121 */           reader.close();
/* 122 */           setPolicy(fileData.toString());
/*     */         } catch (IOException ex) {
/* 124 */           Log.warn("Unable to load policy file: " + ex);
/*     */         }
/*     */       }
/* 127 */       Log.debug("Set policy complete");
/*     */ 
/* 129 */       this.tcpServer = new TcpServer();
/* 130 */       this.tcpServer.bind(bindAddress);
/* 131 */       this.tcpServer.registerAcceptCallback(this);
/* 132 */       this.tcpServer.start();
/*     */ 
/* 134 */       Log.debug("Started server");
/*     */ 
/* 136 */       Engine.registerStatusReportingPlugin(this);
/* 137 */       Log.debug("FlashPolicy: activation done");
/*     */     } catch (Exception e) {
/* 139 */       Log.error("activate failed" + e);
/* 140 */       throw new AORuntimeException("activate failed", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private InetSocketAddress getBindAddress() throws IOException
/*     */   {
/* 146 */     String propStr = Engine.getProperty("atavism.flashpolicy.bindport");
/* 147 */     int port = 0;
/* 148 */     if (propStr != null) {
/* 149 */       port = Integer.parseInt(propStr.trim());
/*     */     }
/*     */ 
/* 153 */     propStr = Engine.getProperty("atavism.flashpolicy.bindaddress");
/* 154 */     InetAddress address = null;
/* 155 */     if (propStr != null) {
/* 156 */       address = InetAddress.getByName(propStr.trim());
/*     */     }
/* 158 */     return new InetSocketAddress(address, port);
/*     */   }
/*     */ 
/*     */   void registerHooks()
/*     */   {
/* 167 */     log.debug("registering hooks");
/*     */ 
/* 169 */     getHookManager().addHook(Management.MSG_TYPE_GET_PLUGIN_STATUS, new GetPluginStatusHook());
/*     */   }
/*     */ 
/*     */   protected Object createMBeanInstance()
/*     */   {
/* 190 */     return new FlashPolicyJMX();
/*     */   }
/*     */ 
/*     */   public void onTcpAccept(SocketChannel sc)
/*     */   {
/*     */     try
/*     */     {
/* 247 */       int DEFAULT_CAPACITY = 1024;
/* 248 */       int TIMEOUT = 2000;
/* 249 */       byte[] readData = new byte[DEFAULT_CAPACITY];
/* 250 */       ByteBuffer readBuffer = ByteBuffer.wrap(readData);
/*     */ 
/* 252 */       Selector selector = Selector.open();
/* 253 */       SelectionKey key = sc.register(selector, 1);
/*     */ 
/* 256 */       int keyCount = selector.select(TIMEOUT);
/* 257 */       if (keyCount == 0) {
/* 259 */         Log.info("Timed out waiting for data to read");
/*     */         return;
/* 262 */       }Log.info("Reading from socket channel");
/* 263 */       sc.read(readBuffer);
/* 264 */       Log.info("After read; position = " + readBuffer.position() + "; remaining = " + readBuffer.remaining() + "; limit = " + readBuffer.limit());
/* 265 */       readData[readBuffer.position()] = 0;
/* 266 */       String readStr = new String(readData, 0, readBuffer.position(), "US-ASCII");
/* 267 */       if (!readStr.startsWith("<policy-file-request/>")) {
/* 268 */         Log.info("Unrecognized flash policy request: " + readStr);
/*     */       }
/*     */       else {
/* 271 */         ByteBuffer writeBuffer = this.policyBuffer;
/*     */ 
/* 273 */         synchronized (writeBuffer) {
/* 274 */           writeBuffer.rewind();
/*     */ 
/* 277 */           sc.write(writeBuffer);
/*     */         }
/* 279 */         Log.debug("Recognized flash policy request: " + readStr);
/*     */       }
/*     */     } catch (IOException ex) {
/* 282 */       Log.warn("Failed to handle client connection: " + ex.getMessage());
/*     */     } finally {
/*     */       try {
/* 285 */         sc.close();
/*     */       }
/*     */       catch (IOException ex) {
/* 288 */         Log.warn("Failed to close client connection: " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setPolicy(String policy)
/*     */   {
/* 295 */     byte[] policyData = policy.getBytes();
/* 296 */     this.policyBuffer = ByteBuffer.wrap(policyData);
/*     */   }
/*     */ 
/*     */   protected class FlashPolicyJMX
/*     */     implements FlashPolicyPlugin.FlashPolicyJMXMBean
/*     */   {
/*     */     protected FlashPolicyJMX()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int getPort()
/*     */     {
/* 207 */       return FlashPolicyPlugin.this.port;
/*     */     }
/*     */ 
/*     */     public void setPort(int val) {
/* 211 */       FlashPolicyPlugin.this.port = val;
/*     */     }
/*     */ 
/*     */     public int getIdleTimeout()
/*     */     {
/* 216 */       return FlashPolicyPlugin.idleTimeout;
/*     */     }
/*     */ 
/*     */     public void setIdleTimeout(int timeout)
/*     */     {
/* 221 */       if (timeout > 0)
/* 222 */         FlashPolicyPlugin.idleTimeout = timeout;
/*     */     }
/*     */ 
/*     */     public String getPolicy()
/*     */     {
/* 228 */       return FlashPolicyPlugin.this.policy;
/*     */     }
/*     */ 
/*     */     public void setPolicy(String str)
/*     */     {
/* 233 */       FlashPolicyPlugin.this.setPolicy(str);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface FlashPolicyJMXMBean
/*     */   {
/*     */     public abstract int getPort();
/*     */ 
/*     */     public abstract void setPort(int paramInt);
/*     */ 
/*     */     public abstract int getIdleTimeout();
/*     */ 
/*     */     public abstract void setIdleTimeout(int paramInt);
/*     */ 
/*     */     public abstract String getPolicy();
/*     */ 
/*     */     public abstract void setPolicy(String paramString);
/*     */   }
/*     */ 
/*     */   class GetPluginStatusHook
/*     */     implements Hook
/*     */   {
/*     */     GetPluginStatusHook()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean processMessage(Message msg, int flags)
/*     */     {
/* 175 */       LinkedHashMap status = new LinkedHashMap();
/*     */ 
/* 177 */       status.put("plugin", FlashPolicyPlugin.this.getName());
/* 178 */       Engine.getAgent().sendObjectResponse(msg, status);
/* 179 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.FlashPolicyPlugin
 * JD-Core Version:    0.6.0
 */