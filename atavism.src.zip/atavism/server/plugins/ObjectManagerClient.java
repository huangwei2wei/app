/*      */ package atavism.server.plugins;
/*      */ 
/*      */ import atavism.msgsys.GenericMessage;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageType;
/*      */ import atavism.msgsys.NoRecipientsException;
/*      */ import atavism.msgsys.SubjectMessage;
/*      */ import atavism.server.engine.BasicWorldNode;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.Namespace;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.messages.OIDNamespaceMessage;
/*      */ import atavism.server.objects.Entity;
/*      */ import atavism.server.objects.Light;
/*      */ import atavism.server.objects.LightData;
/*      */ import atavism.server.objects.ObjectType;
/*      */ import atavism.server.objects.Template;
/*      */ import atavism.server.util.Log;
/*      */ import java.io.Serializable;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public class ObjectManagerClient
/*      */ {
/* 1122 */   public static final MessageType MSG_TYPE_SET_PERSISTENCE = MessageType.intern("ao.SET_PERSISTENCE");
/*      */ 
/* 1125 */   public static final MessageType MSG_TYPE_SET_SUBPERSISTENCE = MessageType.intern("ao.SET_SUBPERSISTENCE");
/*      */ 
/* 1127 */   public static final MessageType MSG_TYPE_MODIFY_NAMESPACE = MessageType.intern("ao.MODIFY_NAMESPACE");
/* 1128 */   public static final MessageType MSG_TYPE_LOAD_OBJECT = MessageType.intern("ao.LOAD_OBJECT");
/* 1129 */   public static final MessageType MSG_TYPE_LOAD_SUBOBJECT = MessageType.intern("ao.LOAD_SUBOBJECT");
/* 1130 */   public static final MessageType MSG_TYPE_UNLOAD_OBJECT = MessageType.intern("ao.UNLOAD_OBJECT");
/* 1131 */   public static final MessageType MSG_TYPE_UNLOAD_SUBOBJECT = MessageType.intern("ao.UNLOAD_SUBOBJECT");
/* 1132 */   public static final MessageType MSG_TYPE_DELETE_OBJECT = MessageType.intern("ao.DELETE_OBJECT");
/* 1133 */   public static final MessageType MSG_TYPE_DELETE_SUBOBJECT = MessageType.intern("ao.DELETE_SUBOBJECT");
/*      */ 
/* 1135 */   public static final MessageType MSG_TYPE_LOAD_OBJECT_DATA = MessageType.intern("ao.LOAD_OBJECT_DATA");
/* 1136 */   public static final MessageType MSG_TYPE_SAVE_OBJECT_DATA = MessageType.intern("ao.SAVE_OBJECT_DATA");
/* 1137 */   public static final MessageType MSG_TYPE_SAVE_OBJECT = MessageType.intern("ao.SAVE_OBJECT");
/* 1138 */   public static final MessageType MSG_TYPE_SAVE_SUBOBJECT = MessageType.intern("ao.SAVE_SUBOBJECT");
/*      */ 
/* 1140 */   public static final MessageType MSG_TYPE_GENERATE_OBJECT = MessageType.intern("ao.GENERATE_OBJECT");
/* 1141 */   public static final MessageType MSG_TYPE_GENERATE_SUB_OBJECT = MessageType.intern("ao.GENERATE_SUB_OBJECT");
/* 1142 */   public static final MessageType MSG_TYPE_SUB_OBJECT_DEPS_READY = MessageType.intern("ao.SUB_OBJECT_DEPS_READY");
/* 1143 */   public static final MessageType MSG_TYPE_REGISTER_TEMPLATE = MessageType.intern("ao.REGISTER_TEMPLATE");
/* 1144 */   public static final MessageType MSG_TYPE_GET_TEMPLATE = MessageType.intern("ao.GET_TEMPLATE");
/* 1145 */   public static final MessageType MSG_TYPE_GET_TEMPLATE_NAMES = MessageType.intern("ao.GET_TEMPLATE_NAMES");
/*      */ 
/* 1147 */   public static final MessageType MSG_TYPE_FIX_WNODE_REQ = MessageType.intern("ao.FIX_WNODE_REQ");
/*      */ 
/* 1149 */   public static final MessageType MSG_TYPE_GET_NAMED_OBJECT = MessageType.intern("ao.GET_NAMED_OBJECT");
/*      */ 
/* 1151 */   public static final MessageType MSG_TYPE_GET_MATCHING_OBJECTS = MessageType.intern("ao.GET_MATCHING_OBJECTS");
/*      */ 
/* 1153 */   public static final MessageType MSG_TYPE_GET_OBJECT_STATUS = MessageType.intern("ao.GET_OBJECT_STATUS");
/*      */   public static final String BASE_TEMPLATE = "BaseTemplate";
/*      */   public static final int BASE_TEMPLATE_ID = -1;
/*      */   public static final String TEMPL_PERSISTENT = ":persistent";
/*      */   public static final String TEMPL_INSTANCE_RESTORE_STACK = "instanceStack";
/*      */   public static final String TEMPL_CURRENT_INSTANCE_NAME = "currentInstanceName";
/*      */ 
/*      */   public static OID generateObject(int templateID, String templateType, Template overrideTemplate)
/*      */   {
/*   47 */     Message msg = new GenerateObjectMessage(templateID, templateType, overrideTemplate);
/*   48 */     return Engine.getAgent().sendRPCReturnOID(msg);
/*      */   }
/*      */ 
/*      */   public static OID generateObject(int templateID, String templateType, Point loc)
/*      */   {
/*   61 */     Template override = new Template();
/*   62 */     if (loc != null) {
/*   63 */       override.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, loc);
/*      */     }
/*   65 */     Message msg = new GenerateObjectMessage(templateID, templateType, override);
/*   66 */     return Engine.getAgent().sendRPCReturnOID(msg);
/*      */   }
/*      */ 
/*      */   public static OID generateObject(int templateID, String templateType, OID instanceOid, Point loc)
/*      */   {
/*   82 */     Template override = new Template();
/*   83 */     override.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, loc);
/*   84 */     override.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instanceOid);
/*   85 */     Message msg = new GenerateObjectMessage(templateID, templateType, override);
/*   86 */     return Engine.getAgent().sendRPCReturnOID(msg);
/*      */   }
/*      */ 
/*      */   public static OID generateLight(OID instanceOid, LightData lightData)
/*      */   {
/*   96 */     Template template = new Template(lightData.getName());
/*   97 */     template.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE, WorldManagerClient.TEMPL_OBJECT_TYPE_LIGHT);
/*      */ 
/*  100 */     template.put(Namespace.WORLD_MANAGER, Light.LightDataPropertyKey, lightData);
/*      */ 
/*  102 */     template.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, lightData.getInitLoc());
/*      */ 
/*  104 */     template.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instanceOid);
/*      */ 
/*  106 */     return generateObject(0, "BaseTemplate", template);
/*      */   }
/*      */ 
/*      */   public static OID loadObject(OID oid)
/*      */   {
/*  118 */     return loadSubObject(oid, null);
/*      */   }
/*      */ 
/*      */   public static OID loadObject(String key)
/*      */   {
/*  127 */     LoadObjectMessage msg = new LoadObjectMessage(key);
/*  128 */     OID oid = Engine.getAgent().sendRPCReturnOID(msg);
/*  129 */     if (Log.loggingDebug)
/*  130 */       Log.debug("ObjectManagerClient.loadObject: key=" + key + ", oid=" + oid);
/*  131 */     return oid;
/*      */   }
/*      */ 
/*      */   public static Boolean unloadObject(OID oid)
/*      */   {
/*  147 */     return unloadSubObject(oid, null);
/*      */   }
/*      */ 
/*      */   public static Boolean addSubObjectNamespace(OID oid, Collection<Namespace> namespaces) {
/*  151 */     ModifyNamespaceMessage message = new ModifyNamespaceMessage(oid, namespaces);
/*  152 */     message.setCommand("add");
/*  153 */     return Engine.getAgent().sendRPCReturnBoolean(message);
/*      */   }
/*      */ 
/*      */   public static OID loadSubObject(OID oid, Collection<Namespace> namespaces)
/*      */   {
/*  159 */     LoadObjectMessage msg = new LoadObjectMessage(oid, namespaces);
/*  160 */     OID respOid = Engine.getAgent().sendRPCReturnOID(msg);
/*  161 */     if (Log.loggingDebug) {
/*  162 */       String nsString = "null";
/*  163 */       if (namespaces != null) {
/*  164 */         nsString = "";
/*  165 */         for (Namespace ns : namespaces)
/*  166 */           nsString = nsString + ns;
/*      */       }
/*  168 */       Log.debug("ObjectManagerClient.loadSubObject: oid=" + oid + " ns=" + nsString + ", received response oid " + respOid);
/*      */     }
/*      */ 
/*  172 */     return respOid;
/*      */   }
/*      */ 
/*      */   public static Boolean unloadSubObject(OID oid, Collection<Namespace> namespaces)
/*      */   {
/*  178 */     Boolean rc = Boolean.valueOf(false);
/*      */     try {
/*  180 */       UnloadObjectMessage msg = new UnloadObjectMessage(oid, namespaces);
/*  181 */       rc = Engine.getAgent().sendRPCReturnBoolean(msg);
/*      */     } catch (NoRecipientsException nre) {
/*  183 */       Log.exception("ObjectManagerClient.unloadSubObject(): ", nre);
/*      */     }
/*  185 */     if (Log.loggingDebug) {
/*  186 */       Log.debug("ObjectManagerClient.unloadSubObject: oid=" + oid + ", received response " + rc);
/*      */     }
/*  188 */     return rc;
/*      */   }
/*      */ 
/*      */   public static Boolean deleteObject(OID oid)
/*      */   {
/*  200 */     DeleteObjectMessage msg = new DeleteObjectMessage(oid);
/*  201 */     Boolean rc = Engine.getAgent().sendRPCReturnBoolean(msg);
/*  202 */     if (Log.loggingDebug) {
/*  203 */       Log.debug("ObjectManagerClient.deleteObject: oid=" + oid + ", received response " + rc);
/*      */     }
/*  205 */     return rc;
/*      */   }
/*      */ 
/*      */   public static boolean saveObject(OID oid, String persistenceKey)
/*      */   {
/*  218 */     SaveObjectMessage msg = new SaveObjectMessage(oid, persistenceKey);
/*  219 */     return Engine.getAgent().sendRPCReturnBoolean(msg).booleanValue();
/*      */   }
/*      */ 
/*      */   public static boolean saveObject(OID oid)
/*      */   {
/*  229 */     SaveObjectMessage msg = new SaveObjectMessage(oid);
/*  230 */     return Engine.getAgent().sendRPCReturnBoolean(msg).booleanValue();
/*      */   }
/*      */   public static boolean saveObjectData(String persistenceKey, Entity entity, Namespace namespace) {
/*  247 */     entity.lock();
/*      */     byte[] entityData;
/*      */     try { entityData = entity.toBytes();
/*      */     } finally
/*      */     {
/*  252 */       entity.unlock();
/*      */     }
/*  254 */     SaveObjectDataMessage msg = new SaveObjectDataMessage(entity.getOid(), persistenceKey, entityData, namespace);
/*      */ 
/*  256 */     return Engine.getAgent().sendRPCReturnBoolean(msg).booleanValue();
/*      */   }
/*      */ 
/*      */   public static Entity loadObjectData(String persistenceKey)
/*      */   {
/*  264 */     LoadObjectDataMessage msg = new LoadObjectDataMessage(persistenceKey);
/*  265 */     return (Entity)Engine.getAgent().sendRPCReturnObject(msg);
/*      */   }
/*      */ 
/*      */   public static Entity loadObjectData(OID oid, Namespace namespace)
/*      */   {
/*  276 */     LoadObjectDataMessage msg = new LoadObjectDataMessage(oid, namespace);
/*  277 */     return (Entity)Engine.getAgent().sendRPCReturnObject(msg);
/*      */   }
/*      */ 
/*      */   public static boolean registerTemplate(Template template)
/*      */   {
/*  287 */     if (Log.loggingDebug)
/*  288 */       Log.debug("ObjectManagerClient: registering template: " + template);
/*  289 */     Message msg = new RegisterTemplateMessage(template);
/*  290 */     Boolean rv = Engine.getAgent().sendRPCReturnBoolean(msg);
/*  291 */     if (Log.loggingDebug)
/*  292 */       Log.debug("ObjectManagerClient: registered template: " + template);
/*  293 */     return rv.booleanValue();
/*      */   }
/*      */ 
/*      */   public static Template getTemplate(int templateID, String templateType)
/*      */   {
/*  300 */     if (Log.loggingDebug)
/*  301 */       Log.debug("ObjectManagerClient: get template: " + templateID + ":" + templateType);
/*  302 */     Message msg = new GetTemplateMessage(templateID, templateType);
/*  303 */     Template template = (Template)Engine.getAgent().sendRPCReturnObject(msg);
/*  304 */     if (Log.loggingDebug)
/*  305 */       Log.debug("ObjectManagerClient: got template: " + template);
/*  306 */     return template;
/*      */   }
/*      */ 
/*      */   public static void setPersistenceFlag(OID oid, boolean flag)
/*      */   {
/*  315 */     SetPersistenceMessage msg = new SetPersistenceMessage(oid, Boolean.valueOf(flag));
/*  316 */     Engine.getAgent().sendRPC(msg);
/*      */   }
/*      */ 
/*      */   public static boolean fixWorldNode(OID oid, BasicWorldNode worldNode)
/*      */   {
/*  330 */     FixWorldNodeMessage message = new FixWorldNodeMessage(oid, worldNode);
/*  331 */     return Engine.getAgent().sendRPCReturnBoolean(message).booleanValue();
/*      */   }
/*      */ 
/*      */   public static List<String> getTemplateNames(String templateType)
/*      */   {
/*  339 */     GenericMessage message = new GenericMessage();
/*  340 */     message.setMsgType(MSG_TYPE_GET_TEMPLATE_NAMES);
/*  341 */     message.setProperty("templateType", templateType);
/*  342 */     List templateNames = (List)Engine.getAgent().sendRPCReturnObject(message);
/*      */ 
/*  344 */     if (Log.loggingDebug) {
/*  345 */       Log.debug("ObjectManagerClient: got " + templateNames.size() + " template names");
/*      */     }
/*  347 */     return templateNames;
/*      */   }
/*      */ 
/*      */   public static OID getNamedObject(OID instanceOid, String name, ObjectType objectType)
/*      */   {
/*  371 */     GetNamedObjectMessage message = new GetNamedObjectMessage(instanceOid, name, objectType);
/*      */ 
/*  373 */     return Engine.getAgent().sendRPCReturnOID(message);
/*      */   }
/*      */ 
/*      */   public static List<OID> getMatchingObjects(OID instanceOid, String name, ObjectType objectType, Map<Namespace, Map<String, Serializable>> filters)
/*      */   {
/*  399 */     GetMatchingObjectsMessage message = new GetMatchingObjectsMessage(instanceOid, name, objectType, filters);
/*      */ 
/*  401 */     Object rv = Engine.getAgent().sendRPCReturnObject(message);
/*  402 */     if (rv == null)
/*  403 */       return null;
/*  404 */     return (List)rv;
/*      */   }
/*      */ 
/*      */   public static ObjectStatus getObjectStatus(OID oid)
/*      */   {
/*  417 */     SubjectMessage message = new SubjectMessage(MSG_TYPE_GET_OBJECT_STATUS, oid);
/*      */ 
/*  419 */     return (ObjectStatus)Engine.getAgent().sendRPCReturnObject(message);
/*      */   }
/*      */ 
/*      */   public static class ObjectStatus
/*      */   {
/*      */     public OID oid;
/*      */     public String name;
/*      */     public ObjectType type;
/*      */     public boolean persistent;
/*      */     public List<Namespace> namespaces;
/*      */     public List<Namespace> loadedNamespaces;
/*      */     private static final long serialVersionUID = 1L;
/*      */   }
/*      */ 
/*      */   public static class GetMatchingObjectsMessage extends Message
/*      */   {
/*      */     private OID instanceOid;
/*      */     private String name;
/*      */     private ObjectType objectType;
/*      */     private Map<Namespace, Map<String, Serializable>> filters;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetMatchingObjectsMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public GetMatchingObjectsMessage(OID instanceOid, String name, ObjectType objectType, Map<Namespace, Map<String, Serializable>> filters)
/*      */     {
/* 1051 */       super();
/* 1052 */       this.instanceOid = instanceOid;
/* 1053 */       this.name = name;
/* 1054 */       this.objectType = objectType;
/* 1055 */       this.filters = filters;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid()
/*      */     {
/* 1060 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1065 */       return this.name;
/*      */     }
/*      */ 
/*      */     public ObjectType getObjectType()
/*      */     {
/* 1070 */       return this.objectType;
/*      */     }
/*      */ 
/*      */     public Map<Namespace, Map<String, Serializable>> getFilters()
/*      */     {
/* 1075 */       return this.filters;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetNamedObjectMessage extends Message
/*      */   {
/*      */     private OID instanceOid;
/*      */     private String name;
/*      */     private ObjectType objectType;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetNamedObjectMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public GetNamedObjectMessage(OID instanceOid, String name, ObjectType objectType)
/*      */     {
/* 1014 */       super();
/* 1015 */       this.instanceOid = instanceOid;
/* 1016 */       this.name = name;
/* 1017 */       this.objectType = objectType;
/*      */     }
/*      */ 
/*      */     public OID getInstanceOid()
/*      */     {
/* 1022 */       return this.instanceOid;
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1027 */       return this.name;
/*      */     }
/*      */ 
/*      */     public ObjectType getObjectType()
/*      */     {
/* 1032 */       return this.objectType;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class FixWorldNodeMessage extends Message
/*      */   {
/*      */     private OID oid;
/*      */     private BasicWorldNode worldNode;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public FixWorldNodeMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public FixWorldNodeMessage(OID oid, BasicWorldNode worldNode)
/*      */     {
/*  980 */       super();
/*  981 */       setOid(oid);
/*  982 */       setWorldNode(worldNode);
/*      */     }
/*      */ 
/*      */     public OID getOid() {
/*  986 */       return this.oid;
/*      */     }
/*      */     public void setOid(OID oid) {
/*  989 */       this.oid = oid;
/*      */     }
/*      */ 
/*      */     public BasicWorldNode getWorldNode() {
/*  993 */       return this.worldNode;
/*      */     }
/*      */     public void setWorldNode(BasicWorldNode worldNode) {
/*  996 */       this.worldNode = worldNode;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SetSubPersistenceMessage extends ObjectManagerClient.SetPersistenceMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SetSubPersistenceMessage()
/*      */     {
/*  962 */       setMsgType(ObjectManagerClient.MSG_TYPE_SET_SUBPERSISTENCE);
/*      */     }
/*      */ 
/*      */     public SetSubPersistenceMessage(OID oid, Namespace namespace, Boolean persistVal) {
/*  966 */       super(namespace, persistVal);
/*  967 */       setMsgType(ObjectManagerClient.MSG_TYPE_SET_SUBPERSISTENCE);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SetPersistenceMessage extends OIDNamespaceMessage
/*      */   {
/*      */     private Boolean persistVal;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SetPersistenceMessage()
/*      */     {
/*  933 */       super();
/*      */     }
/*      */ 
/*      */     public SetPersistenceMessage(OID oid, Boolean persistVal) {
/*  937 */       super(oid);
/*  938 */       setPersistVal(persistVal);
/*      */     }
/*      */ 
/*      */     public SetPersistenceMessage(OID oid, Namespace namespace, Boolean persistVal) {
/*  942 */       super(oid, namespace);
/*  943 */       setPersistVal(persistVal);
/*      */     }
/*      */ 
/*      */     public Boolean getPersistVal() {
/*  947 */       return this.persistVal;
/*      */     }
/*      */ 
/*      */     public void setPersistVal(Boolean persistVal) {
/*  951 */       this.persistVal = persistVal;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetTemplateMessage extends Message
/*      */   {
/*  924 */     private int templateID = 0;
/*  925 */     private String templateType = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetTemplateMessage()
/*      */     {
/*  898 */       super();
/*      */     }
/*      */ 
/*      */     GetTemplateMessage(int templateID, String templateType)
/*      */     {
/*  903 */       setMsgType(ObjectManagerClient.MSG_TYPE_GET_TEMPLATE);
/*  904 */       setTemplateID(templateID);
/*  905 */       setTemplateType(templateType);
/*      */     }
/*      */ 
/*      */     public int getTemplateID() {
/*  909 */       return this.templateID;
/*      */     }
/*      */ 
/*      */     public void setTemplateID(int templateID) {
/*  913 */       this.templateID = templateID;
/*      */     }
/*      */ 
/*      */     public String getTemplateType() {
/*  917 */       return this.templateType;
/*      */     }
/*      */ 
/*      */     public void setTemplateType(String templateType) {
/*  921 */       this.templateType = templateType;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class RegisterTemplateMessage extends Message
/*      */   {
/*  890 */     private Template template = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public RegisterTemplateMessage()
/*      */     {
/*  873 */       super();
/*      */     }
/*      */ 
/*      */     RegisterTemplateMessage(Template template)
/*      */     {
/*  878 */       setMsgType(ObjectManagerClient.MSG_TYPE_REGISTER_TEMPLATE);
/*  879 */       setTemplate(template);
/*      */     }
/*      */ 
/*      */     public Template getTemplate() {
/*  883 */       return this.template;
/*      */     }
/*      */ 
/*      */     public void setTemplate(Template template) {
/*  887 */       this.template = template;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DeleteSubObjectMessage extends OIDNamespaceMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DeleteSubObjectMessage()
/*      */     {
/*  860 */       super();
/*      */     }
/*      */ 
/*      */     public DeleteSubObjectMessage(OID oid, Namespace namespace) {
/*  864 */       super(oid, namespace);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class UnloadSubObjectMessage extends OIDNamespaceMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public UnloadSubObjectMessage()
/*      */     {
/*  847 */       super();
/*      */     }
/*      */ 
/*      */     public UnloadSubObjectMessage(OID oid, Namespace namespace) {
/*  851 */       super(oid, namespace);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class LoadSubObjectMessage extends OIDNamespaceMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public LoadSubObjectMessage()
/*      */     {
/*  825 */       super();
/*      */     }
/*      */ 
/*      */     public LoadSubObjectMessage(OID oid, Namespace namespace) {
/*  829 */       super(oid, namespace);
/*      */     }
/*      */     /** @deprecated */
/*      */     public OID getMasterOid() {
/*  834 */       return getSubject();
/*      */     }
/*  838 */     /** @deprecated */
/*      */     public void setMasterOid(OID oid) { setSubject(oid);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GenerateSubObjectMessage extends OIDNamespaceMessage
/*      */   {
/*  816 */     Template template = null;
/*  817 */     boolean persistent = false;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GenerateSubObjectMessage()
/*      */     {
/*  784 */       super();
/*      */     }
/*      */ 
/*      */     public GenerateSubObjectMessage(OID oid, Namespace namespace, Template template) {
/*  788 */       super(oid, namespace);
/*  789 */       setTemplate(template);
/*      */     }
/*      */ 
/*      */     public void setTemplate(Template t) {
/*  793 */       this.template = t;
/*      */     }
/*      */     public Template getTemplate() {
/*  796 */       return this.template;
/*      */     }
/*      */     /** @deprecated */
/*      */     public OID getMasterOid() {
/*  801 */       return getSubject();
/*      */     }
/*  805 */     /** @deprecated */
/*      */     public void setMasterOid(OID masterOid) { setSubject(masterOid); }
/*      */ 
/*      */     public boolean getPersistenceFlag()
/*      */     {
/*  809 */       return this.persistent;
/*      */     }
/*      */ 
/*      */     public void setPersistenceFlag(boolean flag) {
/*  813 */       this.persistent = flag;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SubObjectDepsReadyMessage extends OIDNamespaceMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SubObjectDepsReadyMessage()
/*      */     {
/*  770 */       super();
/*      */     }
/*      */ 
/*      */     public SubObjectDepsReadyMessage(OID masterOid, Namespace namespace) {
/*  774 */       super(masterOid);
/*  775 */       setNamespace(namespace);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GenerateObjectMessage extends Message
/*      */   {
/*  753 */     private int templateID = 0;
/*  754 */     private String templateType = null;
/*  755 */     Template overrideTemplate = null;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GenerateObjectMessage()
/*      */     {
/*  714 */       super();
/*      */     }
/*      */ 
/*      */     GenerateObjectMessage(int templateID, String templateType)
/*      */     {
/*  719 */       setMsgType(ObjectManagerClient.MSG_TYPE_GENERATE_OBJECT);
/*  720 */       setTemplateID(templateID);
/*  721 */       setTemplateType(templateType);
/*      */     }
/*      */ 
/*      */     GenerateObjectMessage(int templateID, String templateType, Template overrideTemplate) {
/*  725 */       this(templateID, templateType);
/*  726 */       setOverrideTemplate(overrideTemplate);
/*      */     }
/*      */ 
/*      */     public int getTemplateID() {
/*  730 */       return this.templateID;
/*      */     }
/*      */ 
/*      */     public void setTemplateID(int templateID) {
/*  734 */       this.templateID = templateID;
/*      */     }
/*      */ 
/*      */     public String getTemplateType() {
/*  738 */       return this.templateType;
/*      */     }
/*      */ 
/*      */     public void setTemplateType(String templateType) {
/*  742 */       this.templateType = templateType;
/*      */     }
/*      */ 
/*      */     public void setOverrideTemplate(Template t) {
/*  746 */       this.overrideTemplate = t;
/*      */     }
/*      */ 
/*      */     public Template getOverrideTemplate() {
/*  750 */       return this.overrideTemplate;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class LoadObjectDataMessage extends SubjectMessage
/*      */   {
/*      */     private String key;
/*      */     private Namespace namespace;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public LoadObjectDataMessage()
/*      */     {
/*  680 */       super();
/*      */     }
/*      */     public LoadObjectDataMessage(OID oid, Namespace namespace) {
/*  683 */       super(oid);
/*  684 */       setNamespace(namespace);
/*      */     }
/*      */     public LoadObjectDataMessage(String persistenceKey) {
/*  687 */       super();
/*  688 */       setKey(persistenceKey);
/*      */     }
/*      */     public void setKey(String key) {
/*  691 */       this.key = key;
/*      */     }
/*      */     public String getKey() {
/*  694 */       return this.key;
/*      */     }
/*      */ 
/*      */     public Namespace getNamespace() {
/*  698 */       return this.namespace;
/*      */     }
/*      */ 
/*      */     public void setNamespace(Namespace namespace) {
/*  702 */       this.namespace = namespace;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SaveObjectDataMessage extends SubjectMessage
/*      */   {
/*      */     String key;
/*      */     Object dataBytes;
/*      */     Namespace namespace;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SaveObjectDataMessage()
/*      */     {
/*  642 */       super();
/*      */     }
/*      */     SaveObjectDataMessage(OID oid, String persistenceKey, byte[] data, Namespace namespace) {
/*  645 */       super(oid);
/*  646 */       setDataBytes(data);
/*  647 */       setKey(persistenceKey);
/*  648 */       setNamespace(namespace);
/*      */     }
/*      */     public void setDataBytes(byte[] dataBytes) {
/*  651 */       this.dataBytes = dataBytes;
/*      */     }
/*      */     public byte[] getDataBytes() {
/*  654 */       return (byte[])(byte[])this.dataBytes;
/*      */     }
/*      */ 
/*      */     public void setKey(String key) {
/*  658 */       this.key = key;
/*      */     }
/*      */     public String getKey() {
/*  661 */       return this.key;
/*      */     }
/*      */ 
/*      */     public Namespace getNamespace() {
/*  665 */       return this.namespace;
/*      */     }
/*      */     public void setNamespace(Namespace namespace) {
/*  668 */       this.namespace = namespace;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SaveObjectMessage extends Message
/*      */   {
/*      */     private OID oid;
/*      */     private String key;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SaveObjectMessage()
/*      */     {
/*  605 */       super();
/*      */     }
/*      */ 
/*      */     public SaveObjectMessage(OID oid)
/*      */     {
/*  610 */       setMsgType(ObjectManagerClient.MSG_TYPE_SAVE_OBJECT);
/*  611 */       setOid(oid);
/*      */     }
/*      */ 
/*      */     public SaveObjectMessage(OID oid, String key)
/*      */     {
/*  616 */       setMsgType(ObjectManagerClient.MSG_TYPE_SAVE_OBJECT);
/*  617 */       setKey(key);
/*  618 */       setOid(oid);
/*      */     }
/*      */     public OID getOid() {
/*  621 */       return this.oid;
/*      */     }
/*      */ 
/*      */     public void setOid(OID oid) {
/*  625 */       this.oid = oid;
/*      */     }
/*      */     public void setKey(String key) {
/*  628 */       this.key = key;
/*      */     }
/*      */     public String getKey() {
/*  631 */       return this.key;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DeleteObjectMessage extends Message
/*      */   {
/*      */     private OID oid;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public DeleteObjectMessage()
/*      */     {
/*  581 */       super();
/*      */     }
/*      */ 
/*      */     public DeleteObjectMessage(OID oid) {
/*  585 */       super();
/*  586 */       setOid(oid);
/*      */     }
/*      */ 
/*      */     public OID getOid() {
/*  590 */       return this.oid;
/*      */     }
/*      */ 
/*      */     public void setOid(OID oid) {
/*  594 */       this.oid = oid;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class UnloadObjectMessage extends Message
/*      */   {
/*      */     private OID oid;
/*      */     private Collection<Namespace> namespaces;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public UnloadObjectMessage()
/*      */     {
/*  537 */       super();
/*      */     }
/*      */ 
/*      */     public UnloadObjectMessage(OID oid) {
/*  541 */       super();
/*  542 */       setOid(oid);
/*      */     }
/*      */ 
/*      */     public UnloadObjectMessage(OID oid, Collection<Namespace> namespaces)
/*      */     {
/*  547 */       super();
/*  548 */       setOid(oid);
/*  549 */       setNamespaces(namespaces);
/*      */     }
/*      */ 
/*      */     public OID getOid() {
/*  553 */       return this.oid;
/*      */     }
/*      */ 
/*      */     public void setOid(OID oid) {
/*  557 */       this.oid = oid;
/*      */     }
/*      */ 
/*      */     public Collection<Namespace> getNamespaces() {
/*  561 */       return this.namespaces;
/*      */     }
/*      */ 
/*      */     public void setNamespaces(Collection<Namespace> namespaces) {
/*  565 */       this.namespaces = namespaces;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class LoadObjectMessage extends Message
/*      */   {
/*      */     private String key;
/*      */     private OID oid;
/*      */     private Collection<Namespace> namespaces;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public LoadObjectMessage()
/*      */     {
/*  480 */       super();
/*      */     }
/*      */ 
/*      */     public LoadObjectMessage(OID oid) {
/*  484 */       super();
/*  485 */       setOid(oid);
/*      */     }
/*      */ 
/*      */     public LoadObjectMessage(OID oid, Collection<Namespace> namespaces)
/*      */     {
/*  490 */       super();
/*  491 */       setOid(oid);
/*  492 */       setNamespaces(namespaces);
/*      */     }
/*      */ 
/*      */     public LoadObjectMessage(String key) {
/*  496 */       super();
/*  497 */       setKey(key);
/*      */     }
/*      */ 
/*      */     public OID getOid() {
/*  501 */       return this.oid;
/*      */     }
/*      */ 
/*      */     public void setOid(OID oid) {
/*  505 */       this.oid = oid;
/*      */     }
/*      */ 
/*      */     public Collection<Namespace> getNamespaces() {
/*  509 */       return this.namespaces;
/*      */     }
/*      */ 
/*      */     public void setNamespaces(Collection<Namespace> namespaces) {
/*  513 */       this.namespaces = namespaces;
/*      */     }
/*      */ 
/*      */     public void setKey(String key) {
/*  517 */       this.key = key;
/*      */     }
/*      */     public String getKey() {
/*  520 */       return this.key;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ModifyNamespaceMessage extends Message
/*      */   {
/*      */     private String command;
/*      */     private OID oid;
/*      */     private Collection<Namespace> namespaces;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public ModifyNamespaceMessage()
/*      */     {
/*  425 */       super();
/*      */     }
/*      */ 
/*      */     public ModifyNamespaceMessage(OID oid) {
/*  429 */       super();
/*  430 */       setOid(oid);
/*      */     }
/*      */ 
/*      */     public ModifyNamespaceMessage(OID oid, Collection<Namespace> namespaces)
/*      */     {
/*  435 */       super();
/*  436 */       setOid(oid);
/*  437 */       setNamespaces(namespaces);
/*      */     }
/*      */ 
/*      */     public OID getOid() {
/*  441 */       return this.oid;
/*      */     }
/*      */ 
/*      */     public void setOid(OID oid) {
/*  445 */       this.oid = oid;
/*      */     }
/*      */ 
/*      */     public Collection<Namespace> getNamespaces() {
/*  449 */       return this.namespaces;
/*      */     }
/*      */ 
/*      */     public void setNamespaces(Collection<Namespace> namespaces) {
/*  453 */       this.namespaces = namespaces;
/*      */     }
/*      */ 
/*      */     public void setCommand(String cmd) {
/*  457 */       this.command = cmd;
/*      */     }
/*      */     public String getCommand() {
/*  460 */       return this.command;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.plugins.ObjectManagerClient
 * JD-Core Version:    0.6.0
 */