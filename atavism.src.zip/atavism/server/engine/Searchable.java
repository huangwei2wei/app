package atavism.server.engine;

import java.util.Collection;

public abstract interface Searchable
{
  public abstract Collection runSearch(SearchClause paramSearchClause, SearchSelection paramSearchSelection);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Searchable
 * JD-Core Version:    0.6.0
 */