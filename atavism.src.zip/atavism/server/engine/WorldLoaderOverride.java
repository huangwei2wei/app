package atavism.server.engine;

import atavism.server.objects.LightData;
import atavism.server.objects.Region;
import atavism.server.objects.RegionConfig;
import atavism.server.objects.SpawnData;
import atavism.server.objects.Template;

public abstract interface WorldLoaderOverride
{
  public abstract boolean adjustLightData(String paramString1, String paramString2, LightData paramLightData);

  public abstract boolean adjustObjectTemplate(String paramString1, String paramString2, Template paramTemplate);

  public abstract boolean adjustRegion(String paramString1, String paramString2, Region paramRegion);

  public abstract boolean adjustRegionConfig(String paramString1, String paramString2, Region paramRegion, RegionConfig paramRegionConfig);

  public abstract boolean adjustSpawnData(String paramString1, String paramString2, SpawnData paramSpawnData);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WorldLoaderOverride
 * JD-Core Version:    0.6.0
 */