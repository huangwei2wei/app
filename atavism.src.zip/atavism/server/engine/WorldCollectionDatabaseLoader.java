/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.objects.DisplayContext;
/*     */ import atavism.server.objects.DisplayContext.Submesh;
/*     */ import atavism.server.objects.Entity;
/*     */ import atavism.server.objects.Instance;
/*     */ import atavism.server.objects.Marker;
/*     */ import atavism.server.objects.ObjectType;
/*     */ import atavism.server.objects.ObjectTypes;
/*     */ import atavism.server.objects.PersistableTemplate;
/*     */ import atavism.server.objects.Template;
/*     */ import atavism.server.plugins.ObjectManagerClient;
/*     */ import atavism.server.plugins.WorldManagerClient;
/*     */ import atavism.server.util.Logger;
/*     */ import atavism.server.util.XMLHelper;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public class WorldCollectionDatabaseLoader
/*     */   implements WorldCollectionLoader
/*     */ {
/*  32 */   protected static final Logger log = new Logger("WorldCollectionDatabaseLoader");
/*     */   protected String collectionName;
/*     */   protected WorldLoaderOverride worldLoaderOverride;
/*     */ 
/*     */   public WorldCollectionDatabaseLoader(String collectionName, WorldLoaderOverride override)
/*     */   {
/*  36 */     this.collectionName = collectionName;
/*  37 */     this.worldLoaderOverride = override;
/*     */   }
/*     */ 
/*     */   public boolean load(Instance instance)
/*     */   {
/*  49 */     log.debug("load: loading collection name: " + this.collectionName);
/*     */ 
/*  51 */     OID persistOid = Engine.getDatabase().getOidByName(this.collectionName, Namespace.INSTANCE);
/*  52 */     if (persistOid == null) {
/*  53 */       log.error("Failed to load from persistence key: " + this.collectionName);
/*  54 */       return false;
/*     */     }
/*  56 */     Entity persistEntity = Engine.getDatabase().loadEntity(persistOid, Namespace.INSTANCE);
/*  57 */     if (persistEntity == null) {
/*  58 */       log.error("Failed to load from persistence key: " + this.collectionName);
/*  59 */       return false;
/*     */     }
/*     */ 
/*  63 */     List persistableTemplates = new LinkedList();
/*     */ 
/*  65 */     List list = (List)persistEntity.getProperty("static_objects");
/*  66 */     if (list != null) {
/*  67 */       persistableTemplates.addAll(list);
/*     */     }
/*     */ 
/*  71 */     list = (List)persistEntity.getProperty("marker_objects");
/*  72 */     if (list != null) {
/*  73 */       persistableTemplates.addAll(list);
/*     */     }
/*  75 */     for (PersistableTemplate persistableTemplate : persistableTemplates) {
/*  76 */       Template overrideTemplate = null;
/*  77 */       overrideTemplate = persistableTemplate.toTemplate();
/*     */ 
/*  79 */       String name = (String)overrideTemplate.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME);
/*  80 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instance.getOid());
/*     */ 
/*  82 */       if (this.worldLoaderOverride.adjustObjectTemplate(this.collectionName, name, overrideTemplate)) {
/*  83 */         OID objOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", overrideTemplate);
/*     */ 
/*  86 */         if (objOid != null) {
/*  87 */           WorldManagerClient.spawn(objOid);
/*  88 */           log.debug("WorldCollectionDatabaseLoader: generated and spawned oid " + objOid);
/*  89 */           log.debug("WorldCollectionDatabaseLoader: obj name=" + name + ", map=" + persistableTemplate.getPropMap().get("NS.level_editor"));
/*     */         }
/*     */         else {
/*  92 */           log.error("Could not create object=" + name);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   public static String generateWorldCollectionFile(String collectionName) {
/* 104 */     DocumentBuilder docBuilder = XMLHelper.makeDocBuilder();
/* 105 */     Document doc = docBuilder.newDocument();
/* 106 */     Element worldObjectCollection = doc.createElement("WorldObjectCollection");
/* 107 */     worldObjectCollection.setAttribute("Version", "2");
/* 108 */     buildWorldCollectionXml(collectionName, worldObjectCollection);
/* 109 */     doc.appendChild(worldObjectCollection);
/* 110 */     String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" + XMLHelper.toXML(worldObjectCollection);
/* 111 */     log.info("XML for " + collectionName + ":\n" + xml);
/* 112 */     return xml;
/*     */   }
/*     */ 
/*     */   private static boolean buildWorldCollectionXml(String collectionName, Node node)
/*     */   {
/* 123 */     OID persistOid = Engine.getDatabase().getOidByName(collectionName, Namespace.INSTANCE);
/* 124 */     if (persistOid == null) {
/* 125 */       log.error("Failed to load from persistence key: " + collectionName);
/* 126 */       return false;
/*     */     }
/* 128 */     Entity persistEntity = Engine.getDatabase().loadEntity(persistOid, Namespace.INSTANCE);
/* 129 */     if (persistEntity == null) {
/* 130 */       log.error("Failed to load from persistence key: " + collectionName);
/* 131 */       return false;
/*     */     }
/*     */ 
/* 135 */     List persistableTemplates = new LinkedList();
/*     */ 
/* 137 */     List list = (List)persistEntity.getProperty("static_objects");
/* 138 */     if (list != null) {
/* 139 */       persistableTemplates.addAll(list);
/*     */     }
/*     */ 
/* 142 */     list = (List)persistEntity.getProperty("marker_objects");
/* 143 */     if (list != null) {
/* 144 */       persistableTemplates.addAll(list);
/*     */     }
/*     */ 
/* 147 */     Document doc = node.getOwnerDocument();
/* 148 */     for (PersistableTemplate persistableTemplate : persistableTemplates) {
/* 149 */       Template template = null;
/* 150 */       template = persistableTemplate.toTemplate();
/*     */ 
/* 152 */       String name = (String)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME);
/* 153 */       ObjectType objType = (ObjectType)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE);
/* 154 */       if (objType.isA(Marker.OBJECT_TYPE)) {
/* 155 */         Element childNode = doc.createElement("Waypoint");
/* 156 */         childNode.setAttribute("Name", name);
/* 157 */         Point pos = (Point)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC);
/* 158 */         Element posNode = doc.createElement("Position");
/* 159 */         posNode.setAttribute("x", Float.toString(pos.getX()));
/* 160 */         posNode.setAttribute("y", Float.toString(pos.getY()));
/* 161 */         posNode.setAttribute("z", Float.toString(pos.getZ()));
/* 162 */         childNode.appendChild(posNode);
/* 163 */         Quaternion orient = (Quaternion)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_ORIENT);
/* 164 */         Element orientNode = doc.createElement("Orientation");
/* 165 */         orientNode.setAttribute("x", Float.toString(orient.getX()));
/* 166 */         orientNode.setAttribute("y", Float.toString(orient.getY()));
/* 167 */         orientNode.setAttribute("z", Float.toString(orient.getZ()));
/* 168 */         orientNode.setAttribute("w", Float.toString(orient.getW()));
/* 169 */         childNode.appendChild(orientNode);
/*     */ 
/* 171 */         node.appendChild(childNode);
/* 172 */       } else if (objType.isA(ObjectTypes.structure)) {
/* 173 */         Element childNode = doc.createElement("StaticObject");
/* 174 */         childNode.setAttribute("Name", name);
/* 175 */         DisplayContext dispContext = (DisplayContext)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_DISPLAY_CONTEXT);
/* 176 */         childNode.setAttribute("Mesh", dispContext.getMeshFile());
/* 177 */         if (dispContext.getSubmeshes().size() > 0) {
/* 178 */           Element submeshesNode = doc.createElement("SubMeshes");
/* 179 */           for (DisplayContext.Submesh submesh : dispContext.getSubmeshes()) {
/* 180 */             Element submeshInfoNode = doc.createElement("SubMeshInfo");
/* 181 */             submeshInfoNode.setAttribute("Name", submesh.name);
/* 182 */             submeshInfoNode.setAttribute("MaterialName", submesh.material);
/* 183 */             submeshInfoNode.setAttribute("Show", "True");
/* 184 */             submeshesNode.appendChild(submeshInfoNode);
/*     */           }
/* 186 */           childNode.appendChild(submeshesNode);
/*     */         }
/* 188 */         Point pos = (Point)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC);
/* 189 */         Element posNode = doc.createElement("Position");
/* 190 */         posNode.setAttribute("x", Float.toString(pos.getX()));
/* 191 */         posNode.setAttribute("y", Float.toString(pos.getY()));
/* 192 */         posNode.setAttribute("z", Float.toString(pos.getZ()));
/* 193 */         childNode.appendChild(posNode);
/* 194 */         Quaternion orient = (Quaternion)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_ORIENT);
/* 195 */         Element orientNode = doc.createElement("Orientation");
/* 196 */         orientNode.setAttribute("x", Float.toString(orient.getX()));
/* 197 */         orientNode.setAttribute("y", Float.toString(orient.getY()));
/* 198 */         orientNode.setAttribute("z", Float.toString(orient.getZ()));
/* 199 */         orientNode.setAttribute("w", Float.toString(orient.getW()));
/* 200 */         childNode.appendChild(orientNode);
/* 201 */         AOVector scale = (AOVector)template.get(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_SCALE);
/* 202 */         Element scaleNode = doc.createElement("Scale");
/* 203 */         scaleNode.setAttribute("x", Float.toString(scale.getX()));
/* 204 */         scaleNode.setAttribute("y", Float.toString(scale.getY()));
/* 205 */         scaleNode.setAttribute("z", Float.toString(scale.getZ()));
/* 206 */         childNode.appendChild(scaleNode);
/*     */ 
/* 209 */         node.appendChild(childNode);
/*     */       }
/*     */     }
/* 212 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WorldCollectionDatabaseLoader
 * JD-Core Version:    0.6.0
 */