package atavism.server.engine;

import atavism.server.objects.AOObject;
import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface AOEventListener extends Remote
{
  public abstract String getName()
    throws RemoteException;

  public abstract void handleEvent(Event paramEvent, AOObject paramAOObject)
    throws RemoteException;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.AOEventListener
 * JD-Core Version:    0.6.0
 */