package atavism.server.engine;

public abstract interface MatcherFactory
{
  public abstract Matcher createMatcher(SearchClause paramSearchClause);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.MatcherFactory
 * JD-Core Version:    0.6.0
 */