/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.messages.ClientMessage;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TerrainConfig
/*    */   implements Serializable, ClientMessage
/*    */ {
/*    */   private String configType;
/*    */   private String configData;
/*    */   public static final String configTypeFILE = "file";
/*    */   public static final String configTypeXMLSTRING = "xmlstring";
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 19 */     if (getConfigType() == "file")
/* 20 */       return new StringBuilder().append("[TerrainConfig type=").append(getConfigType()).append(" file=").append(getConfigData()).append("]").toString();
/* 21 */     if (getConfigType() == "xmlstring") {
/* 22 */       return new StringBuilder().append("[TerrainConfig type=").append(getConfigType()).append(" size=").append(getConfigData() == null ? -1 : getConfigData().length()).append("]").toString();
/*    */     }
/*    */ 
/* 25 */     return "[TerrainConfig null]";
/*    */   }
/*    */ 
/*    */   public void setConfigType(String type) {
/* 29 */     this.configType = type;
/*    */   }
/*    */   public String getConfigType() {
/* 32 */     return this.configType;
/*    */   }
/*    */ 
/*    */   public String getConfigData() {
/* 36 */     return this.configData;
/*    */   }
/*    */   public void setConfigData(String configData) {
/* 39 */     this.configData = configData;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBuffer() {
/* 43 */     AOByteBuffer buf = new AOByteBuffer(500);
/* 44 */     buf.putOID(null);
/* 45 */     buf.putInt(66);
/* 46 */     buf.putString(getConfigType());
/* 47 */     buf.putString(getConfigData());
/* 48 */     buf.flip();
/* 49 */     return buf;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.TerrainConfig
 * JD-Core Version:    0.6.0
 */