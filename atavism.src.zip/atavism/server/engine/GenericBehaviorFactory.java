/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.util.Log;
/*    */ 
/*    */ public class GenericBehaviorFactory
/*    */   implements BehaviorFactory
/*    */ {
/* 19 */   protected Class bhvClass = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public GenericBehaviorFactory(Class c)
/*    */   {
/*  7 */     this.bhvClass = c;
/*    */   }
/*    */   public Behavior generate() {
/*    */     try {
/* 11 */       return (Behavior)this.bhvClass.newInstance();
/*    */     }
/*    */     catch (Exception e) {
/* 14 */       Log.exception("GenericBehaviorFactory.generate: could not generate behavior: ", e);
/* 15 */     }return null;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.GenericBehaviorFactory
 * JD-Core Version:    0.6.0
 */