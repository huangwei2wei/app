/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.pathing.PathInterpolator;
/*     */ import atavism.server.pathing.PathLocAndDir;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.HashSet;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class BasicInterpolator
/*     */   implements Interpolator<BasicInterpolatable>, Runnable
/*     */ {
/* 102 */   transient HashSet<BasicInterpolatable> interpSet = new HashSet();
/*     */ 
/*     */   public BasicInterpolator()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BasicInterpolator(int updateInterval)
/*     */   {
/*  15 */     startUpdates(updateInterval);
/*     */   }
/*     */ 
/*     */   public synchronized void register(BasicInterpolatable obj)
/*     */   {
/*  20 */     this.interpSet.add(obj);
/*     */   }
/*     */   public synchronized void unregister(BasicInterpolatable obj) {
/*  23 */     this.interpSet.remove(obj);
/*     */   }
/*     */ 
/*     */   public void interpolate(BasicInterpolatable obj) {
/*  27 */     long time = System.currentTimeMillis();
/*  28 */     long lastInterp = obj.getLastInterp();
/*  29 */     long timeDelta = time - lastInterp;
/*     */ 
/*  31 */     if (timeDelta < 100L) {
/*  32 */       return;
/*     */     }
/*     */ 
/*  35 */     PathInterpolator pathInterpolator = obj.getPathInterpolator();
/*  36 */     PathLocAndDir locAndDir = null;
/*  37 */     Point interpLoc = null;
/*     */     AOVector dir;
/*  40 */     if (pathInterpolator != null) {
/*  41 */       Log.debug("BasicInterpolator.interpolate calling pathInterpolator");
/*  42 */       locAndDir = pathInterpolator.interpolate(time);
/*  43 */       if (locAndDir == null) {
/*  44 */         AOVector dir = new AOVector(0.0F, 0.0F, 0.0F);
/*  45 */         Point p = pathInterpolator.getLastPoint();
/*  46 */         if (p != null)
/*  47 */           interpLoc = p;
/*     */       }
/*     */       else {
/*  50 */         interpLoc = locAndDir.getLoc();
/*  51 */         AOVector dir = locAndDir.getDir();
/*  52 */         if (Log.loggingDebug)
/*  53 */           Log.debug("BasicInterpolator.interpolate pathInterpolator returned loc = " + interpLoc);
/*     */       }
/*     */     }
/*     */     else {
/*  57 */       dir = obj.getDir();
/*  58 */       if ((dir == null) || (dir.isZero())) {
/*  59 */         obj.setLastInterp(time);
/*  60 */         return;
/*     */       }
/*  62 */       interpLoc = obj.getInterpLoc();
/*  63 */       if (interpLoc == null) {
/*  64 */         return;
/*     */       }
/*  66 */       AOVector dirCopy = new AOVector(dir);
/*  67 */       dirCopy.scale((float)(timeDelta / 1000.0D));
/*  68 */       interpLoc.add((int)dirCopy.getX(), (int)dirCopy.getY(), (int)dirCopy.getZ());
/*     */     }
/*  70 */     AOVector ndir = new AOVector(dir.getX(), 0.0F, dir.getZ());
/*  71 */     float length = ndir.length();
/*     */     Quaternion orient;
/*     */     Quaternion orient;
/*  72 */     if (length != 0.0F)
/*     */     {
/*  74 */       ndir.normalize();
/*  75 */       orient = Quaternion.fromVectorRotation(new AOVector(0.0F, 0.0F, 1.0F), ndir);
/*     */     }
/*     */     else {
/*  78 */       orient = Quaternion.Identity;
/*     */     }
/*  80 */     obj.setPathInterpolatorValues(time, dir, interpLoc, orient);
/*     */   }
/*     */ 
/*     */   public void startUpdates(int interval) {
/*  84 */     if (Log.loggingDebug)
/*  85 */       Log.debug("BasicInterpolator.startUpdates: updating with interval=" + interval);
/*  86 */     Engine.getExecutor().scheduleAtFixedRate(this, interval, interval, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  91 */     if (Log.loggingDebug)
/*  92 */       Log.debug("BasicInterpolator.run: interpolating all objects");
/*     */     HashSet objects;
/*  94 */     synchronized (this) {
/*  95 */       objects = (HashSet)this.interpSet.clone();
/*     */     }
/*  97 */     for (BasicInterpolatable obj : objects)
/*  98 */       interpolate(obj);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.BasicInterpolator
 * JD-Core Version:    0.6.0
 */