/*    */ package atavism.server.engine;
/*    */ 
/*    */ public class BasicPerceiverFilter
/*    */   implements PerceiverFilter<WMWorldNode>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public boolean matches(Perceiver<WMWorldNode> perceiver, WMWorldNode elem)
/*    */   {
/*  8 */     MobilePerceiver p = (MobilePerceiver)perceiver;
/*    */ 
/* 11 */     return p.getElement() != elem;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.BasicPerceiverFilter
 * JD-Core Version:    0.6.0
 */