package atavism.server.engine;

import java.util.Map;

public abstract interface StatusMapCallback
{
  public abstract Map<String, String> getStatusMap();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.StatusMapCallback
 * JD-Core Version:    0.6.0
 */