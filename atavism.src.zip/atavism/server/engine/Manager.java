/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Manager<E>
/*     */   implements Serializable
/*     */ {
/* 132 */   private Map<Integer, E> map = new HashMap();
/* 133 */   private String name = null;
/* 134 */   private transient Lock lock = null;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Manager()
/*     */   {
/*  14 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public Manager(String name) {
/*  18 */     this.name = name;
/*  19 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public Manager(Manager<E> inMgr) {
/*  23 */     this.name = inMgr.getName();
/*  24 */     setupTransient();
/*  25 */     setMap(new HashMap(inMgr.getMap()));
/*     */   }
/*     */ 
/*     */   private void setupTransient()
/*     */   {
/*  30 */     this.lock = LockFactory.makeLock("ManagerLock:" + this.name);
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  38 */     in.defaultReadObject();
/*  39 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  43 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  47 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public Map<Integer, E> getMap()
/*     */   {
/*  55 */     return this.map;
/*     */   }
/*     */ 
/*     */   public void setMap(Map<Integer, E> map)
/*     */   {
/*  63 */     this.map = map;
/*     */   }
/*     */ 
/*     */   public boolean set(int id, E e) {
/*  67 */     return register(id, e);
/*     */   }
/*     */ 
/*     */   public E remove(String name)
/*     */   {
/*  72 */     this.lock.lock();
/*     */     try {
/*  74 */       Object localObject1 = this.map.remove(name);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public boolean register(int id, E e)
/*     */   {
/*  81 */     this.lock.lock();
/*     */     try {
/*  83 */       if (this.map.put(Integer.valueOf(id), e) != null) {
/*  84 */         Log.warn("Manager: obj with same id already in manager: " + id);
/*     */       }
/*  86 */       int i = 1;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public E get(Integer id)
/*     */   {
/*  94 */     this.lock.lock();
/*     */     try {
/*  96 */       Object localObject1 = this.map.get(id);
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public Collection<Integer> keySet()
/*     */   {
/* 104 */     this.lock.lock();
/*     */     try {
/* 106 */       HashSet localHashSet = new HashSet(this.map.keySet());
/*     */       return localHashSet; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public List<Integer> keyList()
/*     */   {
/* 114 */     this.lock.lock();
/*     */     try {
/* 116 */       ArrayList localArrayList = new ArrayList(this.map.keySet());
/*     */       return localArrayList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Collection<E> values()
/*     */   {
/* 124 */     this.lock.lock();
/*     */     try {
/* 126 */       LinkedList localLinkedList = new LinkedList(this.map.values());
/*     */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Manager
 * JD-Core Version:    0.6.0
 */