/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.objects.Boundary;
/*     */ import atavism.server.objects.Region;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class QuadTreeNode<ElementType extends QuadTreeElement<ElementType>>
/*     */ {
/* 421 */   private Set<Perceiver<ElementType>> perceivers = new HashSet();
/*     */ 
/* 679 */   Set<ElementType> nodeElements = new HashSet();
/*     */ 
/* 682 */   QuadTreeNode<ElementType> parent = null;
/*     */ 
/* 779 */   ArrayList<Region> regions = null;
/*     */ 
/* 784 */   ArrayList<QuadTreeNode<ElementType>> children = null;
/* 785 */   QuadTree<ElementType> tree = null;
/*     */ 
/* 806 */   NodeType type = NodeType.LOCAL;
/*     */ 
/* 808 */   Geometry geometry = null;
/* 809 */   int depth = 0;
/*     */ 
/* 827 */   Set<ElementType> perceiverExtentObjects = null;
/*     */ 
/* 829 */   public transient Lock lock = null;
/*     */ 
/* 831 */   static final Logger log = new Logger("QuadTreeNode");
/* 832 */   protected static boolean logPath = false;
/*     */ 
/*     */   QuadTreeNode(QuadTree<ElementType> tree, QuadTreeNode<ElementType> parent, Geometry g, NodeType type)
/*     */   {
/*  24 */     this.parent = parent;
/*  25 */     this.tree = tree;
/*  26 */     this.geometry = g;
/*  27 */     this.type = type;
/*  28 */     if (parent != null) {
/*  29 */       this.depth = (parent.getDepth() + 1);
/*     */     }
/*     */     else {
/*  32 */       this.depth = 0;
/*     */     }
/*  34 */     this.lock = LockFactory.makeLock(new StringBuilder().append("QuadTreeNodeLock-").append(this.geometry.toString()).toString());
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  38 */     return new StringBuilder().append("[QuadTreeNode: depth=").append(getDepth()).append(" numObjects=").append(getNodeElements().size()).append(" ").append(this.geometry).append("]").toString();
/*     */   }
/*     */ 
/*     */   void recurseToString()
/*     */   {
/*     */     try
/*     */     {
/*  48 */       this.lock.lock();
/*  49 */       int depth = getDepth();
/*  50 */       String ws = "";
/*  51 */       for (int i = 0; i < depth; i++) {
/*  52 */         ws = new StringBuilder().append(ws).append("- ").toString();
/*     */       }
/*     */ 
/*  56 */       if (Log.loggingDebug) {
/*  57 */         log.debug(new StringBuilder().append(ws).append(toString()).toString());
/*     */       }
/*     */ 
/*  60 */       if (isLeaf())
/*     */       {
/*     */         return;
/*     */       }
/*  65 */       ((QuadTreeNode)this.children.get(0)).recurseToString();
/*  66 */       ((QuadTreeNode)this.children.get(1)).recurseToString();
/*  67 */       ((QuadTreeNode)this.children.get(2)).recurseToString();
/*  68 */       ((QuadTreeNode)this.children.get(3)).recurseToString();
/*     */     }
/*     */     finally {
/*  71 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsPoint(Point loc)
/*     */   {
/*  80 */     this.lock.lock();
/*     */     try {
/*  82 */       if (loc == null) {
/*  83 */         bool = false;
/*     */         return bool;
/*     */       }
/*  85 */       boolean bool = this.geometry.contains(loc);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean containsPointWithHysteresis(Point loc)
/*     */   {
/*  93 */     this.lock.lock();
/*     */     try {
/*  95 */       if (loc == null) {
/*  96 */         int i = 0;
/*     */         return i;
/*     */       }
/*  98 */       int hysteresis = this.tree.getHysteresis();
/*  99 */       if (hysteresis == 0) {
/* 100 */         boolean bool1 = this.geometry.contains(loc);
/*     */         return bool1;
/*     */       }
/* 103 */       Geometry hystericalGeometry = new Geometry(this.geometry.getMinX() + hysteresis, this.geometry.getMaxX() - hysteresis, this.geometry.getMinZ() + hysteresis, this.geometry.getMaxZ() - hysteresis);
/*     */ 
/* 107 */       boolean ret = hystericalGeometry.contains(loc);
/* 108 */       if (Log.loggingDebug) {
/* 109 */         Log.debug(new StringBuilder().append("QuadTreeNode.containsPointWithHysteresis: point=").append(loc).append(", geom=").append(hystericalGeometry).append(", ret = ").append(ret).append(", node=").append(this).toString());
/*     */       }
/* 111 */       boolean bool2 = ret;
/*     */       return bool2; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   boolean isLeaf()
/*     */   {
/* 121 */     return getChildren() == null;
/*     */   }
/*     */ 
/*     */   int getDepth()
/*     */   {
/* 126 */     return this.depth;
/*     */   }
/*     */ 
/*     */   QuadTreeNode<ElementType> getParent() {
/* 130 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public QuadTree<ElementType> getTree() {
/* 134 */     this.lock.lock();
/*     */     try {
/* 136 */       QuadTree localQuadTree = this.tree;
/*     */       return localQuadTree; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   QuadTreeNode<ElementType> whichChild(Point loc)
/*     */   {
/* 150 */     this.lock.lock();
/*     */     try {
/* 152 */       if (this.children == null) {
/* 153 */         log.warn("whichChild: no children");
/* 154 */         Object localObject1 = null;
/*     */         return localObject1;
/*     */       }
/* 157 */       for (QuadTreeNode child : this.children)
/* 158 */         if (child.containsPoint(loc))
/*     */         {
/* 160 */           QuadTreeNode localQuadTreeNode1 = child;
/*     */           return localQuadTreeNode1;
/*     */         }
/* 163 */       log.warn(new StringBuilder().append("whichChild: did not find child for point ").append(loc).append(", thisNode=").append(this).toString());
/*     */ 
/* 165 */       ??? = null;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   Set<ElementType> getElements(Point loc, int radius)
/*     */   {
/* 174 */     this.lock.lock();
/*     */     try {
/* 176 */       if (isLeaf()) {
/* 177 */         if (distanceTo(loc) < radius) {
/* 178 */           ownElements = getNodeElements();
/* 179 */           ownElements.addAll(this.perceiverExtentObjects);
/* 180 */           Set localSet1 = ownElements;
/*     */           return localSet1;
/*     */         }
/* 183 */         Set ownElements = new HashSet();
/*     */         return ownElements;
/*     */       }
/* 187 */       Set objSet = new HashSet();
/* 188 */       for (Object i$ = this.children.iterator(); ((Iterator)i$).hasNext(); ) { QuadTreeNode child = (QuadTreeNode)((Iterator)i$).next();
/* 189 */         if (child.distanceTo(loc) < radius) {
/* 190 */           objSet.addAll(child.getElements(loc, radius));
/* 191 */           objSet.addAll(this.perceiverExtentObjects);
/*     */         }
/*     */       }
/* 194 */       i$ = objSet;
/*     */       return i$; } finally { this.lock.unlock(); } throw localObject1;
/*     */   }
/*     */ 
/*     */   public Set<ElementType> getElementsBetween(Point loc1, Point loc2)
/*     */   {
/* 208 */     this.lock.lock();
/*     */     try {
/* 210 */       if (isLeaf()) {
/* 211 */         if ((logPath) && 
/* 212 */           (Log.loggingDebug)) {
/* 213 */           log.debug(new StringBuilder().append("getElementsBetween leaf: geometry = ").append(this.geometry).append("; nodeElements.size() = ").append(this.nodeElements.size()).append("; loc1 = ").append(loc1).append("; loc2 = ").append(loc2).toString());
/*     */         }
/*     */ 
/* 216 */         if (segmentIntersectsNode(loc1, loc2)) {
/* 217 */           elems = new HashSet();
/* 218 */           addCloseElements(elems, this.nodeElements, loc1, loc2);
/* 219 */           addCloseElements(elems, this.perceiverExtentObjects, loc1, loc2);
/* 220 */           Set localSet1 = elems;
/*     */           return localSet1;
/*     */         }
/* 223 */         Set elems = new HashSet();
/*     */         return elems;
/*     */       }
/* 227 */       Set elems = new HashSet();
/* 228 */       for (Object i$ = this.children.iterator(); ((Iterator)i$).hasNext(); ) { QuadTreeNode child = (QuadTreeNode)((Iterator)i$).next();
/* 229 */         if ((logPath) && 
/* 230 */           (Log.loggingDebug)) {
/* 231 */           log.debug(new StringBuilder().append("getElementsBetween: child = ").append(child).append("; loc1 = ").append(loc1).append("; loc2 = ").append(loc2).toString());
/*     */         }
/*     */ 
/* 234 */         if (child.segmentIntersectsNode(loc1, loc2)) {
/* 235 */           elems.addAll(child.getElementsBetween(loc1, loc2));
/* 236 */           addCloseElements(elems, this.perceiverExtentObjects, loc1, loc2);
/*     */         }
/*     */       }
/* 239 */       i$ = elems;
/*     */       return i$; } finally { this.lock.unlock(); } throw localObject1;
/*     */   }
/*     */ 
/*     */   void addCloseElements(Set<ElementType> elems, Set<ElementType> adds, Point loc1, Point loc2)
/*     */   {
/* 250 */     for (QuadTreeElement elem : adds) {
/* 251 */       int radius = elem.getObjectRadius();
/* 252 */       Point center = elem.getLoc();
/* 253 */       if ((logPath) && 
/* 254 */         (Log.loggingDebug)) {
/* 255 */         log.debug(new StringBuilder().append("addCloseElements: elem = ").append(elem).append("; center = ").append(center).append("; radius = ").append(radius).toString());
/*     */       }
/* 257 */       if (segmentCloserThanDistance(loc1, loc2, center.getX(), center.getZ(), radius))
/* 258 */         elems.add(elem);
/*     */     }
/*     */   }
/*     */ 
/*     */   void addElement(ElementType elem)
/*     */   {
/* 264 */     this.lock.lock();
/*     */     try {
/* 266 */       this.nodeElements.add(elem);
/*     */     }
/*     */     finally {
/* 269 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean removeElement(ElementType elem)
/*     */   {
/* 275 */     if (Log.loggingDebug)
/* 276 */       log.debug(new StringBuilder().append("removing element ").append(elem).append(" from quadtreenode ").append(this).toString());
/* 277 */     this.lock.lock();
/*     */     try {
/* 279 */       boolean bool = this.nodeElements.remove(elem);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   Set<ElementType> getNodeElements()
/*     */   {
/*     */     try
/*     */     {
/* 291 */       this.lock.lock();
/* 292 */       HashSet localHashSet = new HashSet(this.nodeElements);
/*     */       return localHashSet; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   int numElements()
/*     */   {
/*     */     try
/*     */     {
/* 302 */       this.lock.lock();
/* 303 */       int i = this.nodeElements.size();
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   boolean containsElement(ElementType obj)
/*     */   {
/*     */     try
/*     */     {
/* 315 */       this.lock.lock();
/* 316 */       boolean bool = this.nodeElements.contains(obj);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void addPerceiverExtentObject(ElementType elem, Point loc, int radius)
/*     */   {
/* 329 */     this.lock.lock();
/*     */     try {
/* 331 */       if (isLeaf()) {
/* 332 */         if (distanceTo(loc) < radius) {
/* 333 */           if (this.perceiverExtentObjects == null)
/* 334 */             this.perceiverExtentObjects = new HashSet();
/* 335 */           if (Log.loggingDebug) {
/* 336 */             log.debug(new StringBuilder().append("addPerceiverExtentObject; adding: ").append(toString()).append(" elem: ").append(elem).append(", loc: ").append(loc).append(" radius: ").append(radius).toString());
/*     */           }
/* 338 */           this.perceiverExtentObjects.add(elem);
/*     */         }
/*     */       }
/*     */       else {
/* 342 */         for (QuadTreeNode child : this.children)
/* 343 */           child.addPerceiverExtentObject(elem, loc, radius);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 348 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removePerceiverExtentObject(ElementType elem)
/*     */   {
/* 357 */     this.lock.lock();
/*     */     try {
/* 359 */       if (isLeaf()) {
/* 360 */         if (this.perceiverExtentObjects == null) return;
/* 362 */         if (Log.loggingDebug)
/* 363 */           log.debug(new StringBuilder().append("removePerceiverExtentObject; removing: ").append(toString()).append(" elem: ").append(elem).toString());
/* 364 */         this.perceiverExtentObjects.remove(elem);
/*     */       }
/*     */       else {
/* 367 */         for (QuadTreeNode child : this.children)
/* 368 */           child.removePerceiverExtentObject(elem);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 373 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   void addPerceiver(Perceiver<ElementType> p) {
/* 378 */     this.tree.getLock().lock();
/*     */     try {
/* 380 */       this.lock.lock();
/*     */       try {
/* 382 */         this.perceivers.add(p);
/*     */       } finally {
/* 384 */         this.lock.unlock();
/*     */       }
/*     */     } finally {
/* 387 */       this.tree.getLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   void removePerceiver(Perceiver<ElementType> p) {
/* 391 */     this.tree.getLock().lock();
/*     */     try {
/* 393 */       this.lock.lock();
/*     */       try {
/* 395 */         this.perceivers.remove(p);
/*     */       } finally {
/* 397 */         this.lock.unlock();
/*     */       }
/*     */     } finally {
/* 400 */       this.tree.getLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   Set<Perceiver<ElementType>> getPerceivers() {
/* 405 */     this.tree.getLock().lock();
/*     */     try {
/* 407 */       this.lock.lock();
/*     */       try {
/* 409 */         HashSet localHashSet = new HashSet(this.perceivers);
/*     */ 
/* 411 */         this.lock.unlock();
/*     */ 
/* 414 */         this.tree.getLock().unlock(); return localHashSet;
/*     */       }
/*     */       finally
/*     */       {
/* 411 */         this.lock.unlock();
/*     */       }
/*     */     } finally {
/* 414 */       this.tree.getLock().unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   float distanceTo(Point loc)
/*     */   {
/* 428 */     float dist = -1.0F;
/* 429 */     float minX = this.geometry.getMinX();
/* 430 */     float minZ = this.geometry.getMinZ();
/* 431 */     float maxX = this.geometry.getMaxX();
/* 432 */     float maxZ = this.geometry.getMaxZ();
/* 433 */     float ptX = loc.getX();
/* 434 */     float ptZ = loc.getZ();
/*     */ 
/* 437 */     if (containsPoint(loc)) {
/* 438 */       dist = 0.0F;
/*     */     }
/* 441 */     else if ((minX < ptX) && (ptX < maxX)) {
/* 442 */       if (ptZ > maxZ) {
/* 443 */         dist = ptZ - maxZ;
/*     */       }
/*     */       else {
/* 446 */         dist = minZ - ptZ;
/*     */       }
/*     */ 
/*     */     }
/* 450 */     else if ((minZ < ptZ) && (ptZ < maxZ)) {
/* 451 */       if (ptX > maxX) {
/* 452 */         dist = ptX - maxX;
/*     */       }
/*     */       else {
/* 455 */         dist = minX - ptX;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 460 */       Iterator iter = this.geometry.getCorners().iterator();
/* 461 */       while (iter.hasNext()) {
/* 462 */         Point corner = (Point)iter.next();
/* 463 */         float cornerDist = Point.distanceTo(corner, loc);
/* 464 */         if ((dist == -1.0F) || (cornerDist < dist)) {
/* 465 */           dist = cornerDist;
/*     */         }
/*     */       }
/*     */     }
/* 469 */     return dist;
/*     */   }
/*     */ 
/*     */   boolean segmentIntersectsNode(Point loc1, Point loc2)
/*     */   {
/* 476 */     float minX = this.geometry.getMinX();
/* 477 */     float minZ = this.geometry.getMinZ();
/* 478 */     float maxX = this.geometry.getMaxX();
/* 479 */     float maxZ = this.geometry.getMaxZ();
/* 480 */     float centerX = (minX + maxX) * 0.5F;
/* 481 */     float centerZ = (minZ + maxZ) * 0.5F;
/* 482 */     float nodeRadius = (float)Math.sqrt((minX - centerX) * (minX - centerX) + (minZ - centerZ) * (minZ - centerZ));
/*     */ 
/* 484 */     return segmentCloserThanDistance(loc1, loc2, centerX, centerZ, nodeRadius);
/*     */   }
/*     */ 
/*     */   static boolean segmentCloserThanDistance(Point loc1, Point loc2, float centerX, float centerZ, float radius)
/*     */   {
/* 489 */     if ((logPath) && 
/* 490 */       (Log.loggingDebug)) {
/* 491 */       log.debug(new StringBuilder().append("segmentCloserThanDistance: centerX = ").append(centerX).append("; centerZ = ").append(centerZ).append("; radius = ").append(radius).toString());
/*     */     }
/*     */ 
/* 494 */     AOVector pt1 = new AOVector(loc1.getX(), 0.0F, loc1.getZ());
/* 495 */     AOVector pt2 = new AOVector(loc2.getX(), 0.0F, loc2.getZ());
/* 496 */     pt2.sub(pt1);
/* 497 */     AOVector center = new AOVector(centerX, 0.0F, centerZ);
/* 498 */     AOVector m = AOVector.sub(pt1, center);
/* 499 */     float b = m.dotProduct(pt2);
/* 500 */     float c = m.dotProduct(m) - radius * radius;
/* 501 */     float disc = b * b - c;
/* 502 */     if ((logPath) && 
/* 503 */       (Log.loggingDebug)) {
/* 504 */       log.debug(new StringBuilder().append("segmentCloserThanDistance: b = ").append(b).append("; c = ").append(c).append("; disc = ").append(disc).append("; pt1 = ").append(pt1).append("; pt2 = ").append(pt2).append("; m = ").append(m).toString());
/*     */     }
/*     */ 
/* 507 */     if (((c > 0.0F) && (b > 0.0F)) || (disc < 0.0F)) {
/* 508 */       if ((logPath) && 
/* 509 */         (Log.loggingDebug)) {
/* 510 */         log.debug(new StringBuilder().append("segmentCloserThanDistance false: b = ").append(b).append("; c = ").append(c).append("; disc = ").append(disc).toString());
/*     */       }
/* 512 */       return false;
/*     */     }
/*     */ 
/* 515 */     float t = -b - (float)Math.sqrt(disc);
/*     */ 
/* 517 */     boolean result = t < 1.0F;
/* 518 */     if ((logPath) && 
/* 519 */       (Log.loggingDebug)) {
/* 520 */       log.debug(new StringBuilder().append("segmentCloserThanDistance: result = ").append(result ? "true" : "false").append("; t = ").append(t).toString());
/*     */     }
/*     */ 
/* 523 */     return result;
/*     */   }
/*     */ 
/*     */   void divide(QuadTree<ElementType>.NewsAndFrees newsAndFrees) {
/* 527 */     this.tree.getLock().lock();
/*     */     try {
/* 529 */       this.lock.lock();
/*     */       try {
/* 531 */         this.children = new ArrayList(4);
/*     */ 
/* 533 */         Geometry[] newGeometry = this.geometry.divide();
/* 534 */         for (int i = 0; i < 4; i++) {
/* 535 */           this.children.add(new QuadTreeNode(getTree(), this, newGeometry[i], this.type));
/*     */ 
/* 537 */           if (Log.loggingDebug) {
/* 538 */             log.debug(new StringBuilder().append("divide: dividing=").append(toString()).append("- new child[").append(i).append("]=").append(this.children.get(i)).toString());
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 545 */         for (QuadTreeElement elem : this.nodeElements) {
/* 546 */           QuadTreeNode childNode = whichChild(elem.getCurrentLoc());
/* 547 */           if (Log.loggingDebug) {
/* 548 */             log.debug(new StringBuilder().append("divide: moving element ").append(elem).append(" TO CHILD ").append(childNode).toString());
/*     */           }
/* 550 */           if (childNode == null) {
/* 551 */             log.debug("divide: world node is no longer in this quad tree node, skipping it.  it should be moved when the updater thread notices its not longer in the quad tree node anymore");
/* 552 */             continue;
/*     */           }
/*     */ 
/* 555 */           childNode.addElement(elem);
/*     */ 
/* 558 */           elem.setQuadNode(childNode);
/*     */         }
/*     */ 
/* 563 */         if (this.perceiverExtentObjects != null) {
/* 564 */           for (QuadTreeElement elem : this.perceiverExtentObjects) {
/* 565 */             addPerceiverExtentObject(elem, elem.getCurrentLoc(), elem.getPerceptionRadius());
/*     */           }
/* 567 */           this.perceiverExtentObjects = null;
/*     */         }
/*     */ 
/* 571 */         for (Iterator i$ = this.children.iterator(); i$.hasNext(); ) { node = (QuadTreeNode)i$.next();
/* 572 */           for (Perceiver p : getPerceivers())
/* 573 */             if (p.overlaps(node.getGeometry())) {
/* 574 */               node.addPerceiver(p);
/* 575 */               p.addQuadTreeNode(node);
/*     */             }
/*     */         }
/* 581 */         QuadTreeNode node;
/* 581 */         for (Iterator i$ = this.children.iterator(); i$.hasNext(); ) { node = (QuadTreeNode)i$.next();
/* 582 */           Set removePerceivers = new HashSet(this.perceivers);
/*     */ 
/* 584 */           removePerceivers.removeAll(node.perceivers);
/* 585 */           for (i$ = removePerceivers.iterator(); i$.hasNext(); ) { p = (Perceiver)i$.next();
/* 586 */             for (QuadTreeElement elem : node.getNodeElements())
/* 587 */               newsAndFrees.noteFreedElement(p, elem);
/*     */           }
/*     */         }
/*     */         QuadTreeNode node;
/*     */         Iterator i$;
/*     */         Perceiver p;
/* 593 */         for (Perceiver p : getPerceivers()) {
/* 594 */           p.removeQuadTreeNode(this);
/*     */         }
/* 596 */         this.perceivers.clear();
/* 597 */         this.nodeElements.clear();
/*     */ 
/* 600 */         if (this.regions != null) {
/* 601 */           ArrayList currentRegions = this.regions;
/* 602 */           this.regions = null;
/* 603 */           for (Region region : currentRegions)
/* 604 */             addRegion(region);
/*     */         }
/*     */       }
/*     */       finally {
/* 608 */         this.lock.unlock();
/*     */       }
/*     */     } finally {
/* 611 */       this.tree.getLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean updateElement(ElementType elem)
/*     */   {
/* 628 */     this.lock.lock();
/*     */     try {
/* 630 */       if (!this.nodeElements.contains(elem)) {
/* 631 */         throw new AORuntimeException(new StringBuilder().append("QuadTreeNode: element not in our managed list: ").append(elem).append(" -- for node ").append(toString()).toString());
/*     */       }
/*     */ 
/* 635 */       Point elemLoc = elem.getLoc();
/* 636 */       if (elemLoc == null)
/*     */       {
/* 638 */         throw new AORuntimeException("quadtreenode: element location is null, could be because someone just acquired this object -- acquirehandler should remove element");
/*     */       }
/*     */ 
/* 645 */       if ((!containsPoint(elemLoc)) || (getChildren() != null)) {
/* 646 */         if (Log.loggingDebug) {
/* 647 */           log.debug(new StringBuilder().append("updateElement: element is no longer in current node or we are not a leaf node, updating.  elem=").append(elem).toString());
/*     */         }
/* 649 */         removeElement(elem);
/*     */ 
/* 651 */         newNode = getTree().addElement(elem);
/* 652 */         if (newNode == null)
/*     */         {
/* 656 */           log.debug("updateObject: obj moved to a remote node");
/*     */ 
/* 665 */           int i = 0;
/*     */           return i;
/*     */         }
/* 667 */         if (!newNode.containsElement(elem)) {
/* 668 */           throw new AORuntimeException("quadtreenode.updateobj: new node doesnt point to the object we just added to it");
/*     */         }
/*     */       }
/* 671 */       QuadTreeNode newNode = 1;
/*     */       return newNode; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public ArrayList<QuadTreeNode<ElementType>> getChildren()
/*     */   {
/* 686 */     return this.children;
/*     */   }
/*     */ 
/*     */   public QuadTreeNode<ElementType> getChild(int i) {
/* 690 */     return (QuadTreeNode)this.children.get(i);
/*     */   }
/*     */ 
/*     */   public QuadTreeNode<ElementType> getChild(Point p) {
/* 694 */     for (QuadTreeNode node : this.children) {
/* 695 */       if (node.geometry.contains(p)) {
/* 696 */         return node;
/*     */       }
/*     */     }
/* 699 */     return null;
/*     */   }
/*     */ 
/*     */   public ArrayList<Region> getRegions()
/*     */   {
/* 706 */     return this.regions;
/*     */   }
/*     */ 
/*     */   public void addRegion(Region region)
/*     */   {
/* 713 */     this.lock.lock();
/*     */     try
/*     */     {
/*     */       Boundary boundary;
/* 715 */       if (this.children == null)
/*     */       {
/* 717 */         boundary = region.getBoundary();
/*     */ 
/* 720 */         List points = boundary.getPoints();
/* 721 */         for (Point point : points) {
/* 722 */           if (containsPoint(point)) {
/* 723 */             if (this.regions == null) {
/* 724 */               this.regions = new ArrayList(5);
/*     */             }
/* 726 */             this.regions.add(region);
/*     */             return;
/*     */           }
/*     */         }
/* 732 */         Collection corners = this.geometry.getCorners();
/* 733 */         for (Point point : corners)
/* 734 */           if (boundary.contains(point)) {
/* 735 */             if (this.regions == null) {
/* 736 */               this.regions = new ArrayList(5);
/*     */             }
/* 738 */             this.regions.add(region);
/*     */             return;
/*     */           }
/*     */       } else {
/* 744 */         ((QuadTreeNode)this.children.get(0)).addRegion(region);
/* 745 */         ((QuadTreeNode)this.children.get(1)).addRegion(region);
/* 746 */         ((QuadTreeNode)this.children.get(2)).addRegion(region);
/* 747 */         ((QuadTreeNode)this.children.get(3)).addRegion(region);
/*     */       }
/*     */     }
/*     */     finally {
/* 751 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Region> getRegionByLoc(Point loc)
/*     */   {
/* 760 */     this.lock.lock();
/*     */     try {
/* 762 */       if (this.regions == null) {
/* 763 */         Object localObject1 = null;
/*     */         return localObject1;
/*     */       }
/* 764 */       Object matchRegions = new ArrayList();
/* 765 */       for (Region region : this.regions) {
/* 766 */         Boundary boundary = region.getBoundary();
/* 767 */         if ((boundary != null) && (boundary.contains(loc))) {
/* 768 */           ((List)matchRegions).add(region);
/*     */         }
/*     */       }
/* 771 */       ??? = (Iterator)matchRegions;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public Geometry getGeometry()
/*     */   {
/*     */     try
/*     */     {
/* 792 */       this.lock.lock();
/* 793 */       Geometry localGeometry = (Geometry)this.geometry.clone();
/*     */       return localGeometry; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   void setNodeType(NodeType type)
/*     */   {
/* 801 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public NodeType getNodeType()
/*     */   {
/* 812 */     return this.type;
/*     */   }
/*     */ 
/*     */   public Set<ElementType> getPerceiverExtentObjects()
/*     */   {
/* 820 */     return this.perceiverExtentObjects;
/*     */   }
/*     */ 
/*     */   public static enum NodeType
/*     */   {
/* 804 */     LOCAL, REMOTE, MIXED;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.QuadTreeNode
 * JD-Core Version:    0.6.0
 */