/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.network.TcpAcceptCallback;
/*     */ import atavism.server.network.TcpServer;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class SocketPolicyHandler
/*     */   implements TcpAcceptCallback
/*     */ {
/*  22 */   protected final String DEFAULT_POLICY = "<?xml version=\"1.0\"?>\n<!DOCTYPE cross-domain-policy SYSTEM \"/xml/dtds/cross-domain-policy.dtd\">\n<cross-domain-policy>\n  <site-control permitted-cross-domain-policies=\"master-only\"/>\n  <allow-access-from domain=\"*\" to-ports=\"*\"/>\n</cross-domain-policy>\n";
/*     */ 
/*  30 */   protected final int DEFAULT_PORT = 843;
/*  31 */   protected final String POLICY_REQUEST_STRING = "<policy-file-request/>";
/*     */ 
/*  33 */   protected TcpServer tcpServer = new TcpServer();
/*     */ 
/*  35 */   protected int port = 843;
/*  36 */   protected String policy = null;
/*  37 */   protected ByteBuffer policyBuffer = null;
/*     */ 
/*  43 */   public static int idleTimeout = 60;
/*     */ 
/*  45 */   boolean devMode = true;
/*     */ 
/*     */   public SocketPolicyHandler(Properties properties)
/*     */   {
/*     */     try
/*     */     {
/*  51 */       String policyStr = "<?xml version=\"1.0\"?>\n<!DOCTYPE cross-domain-policy SYSTEM \"/xml/dtds/cross-domain-policy.dtd\">\n<cross-domain-policy>\n  <site-control permitted-cross-domain-policies=\"master-only\"/>\n  <allow-access-from domain=\"*\" to-ports=\"*\"/>\n</cross-domain-policy>\n";
/*     */ 
/*  53 */       InetSocketAddress bindAddress = getBindAddress(properties);
/*  54 */       if (Log.loggingDebug) {
/*  55 */         Log.debug("SocketPolicy: binding for incoming client connections at: " + bindAddress);
/*     */       }
/*  57 */       setPolicy(policyStr);
/*     */ 
/*  59 */       String socketPolicyFile = properties.getProperty("atavism.socketpolicy.policyfile");
/*  60 */       if (socketPolicyFile != null) {
/*  61 */         socketPolicyFile = socketPolicyFile.trim();
/*  62 */         if (Log.loggingDebug)
/*  63 */           Log.debug("SocketPolicy: serving policy file from " + socketPolicyFile);
/*     */         try {
/*  65 */           StringBuffer fileData = new StringBuffer();
/*  66 */           BufferedReader reader = new BufferedReader(new FileReader(socketPolicyFile));
/*  67 */           char[] buf = new char[1024];
/*  68 */           int bytesRead = 0;
/*  69 */           while ((bytesRead = reader.read(buf)) != -1)
/*     */           {
/*  71 */             fileData.append(buf, 0, bytesRead);
/*     */           }
/*  73 */           reader.close();
/*  74 */           setPolicy(fileData.toString());
/*     */         } catch (IOException ex) {
/*  76 */           Log.warn("Unable to load policy file: " + ex);
/*     */         }
/*     */       }
/*  79 */       Log.debug("Set policy complete");
/*     */ 
/*  81 */       this.tcpServer = new TcpServer();
/*  82 */       this.tcpServer.bind(bindAddress);
/*  83 */       this.tcpServer.registerAcceptCallback(this);
/*  84 */       this.tcpServer.start();
/*     */ 
/*  86 */       Log.debug("Started server");
/*     */ 
/*  88 */       Log.debug("SocketPolicy: activation done");
/*     */     } catch (Exception e) {
/*  90 */       Log.error("activate failed" + e);
/*  91 */       throw new AORuntimeException("activate failed", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private InetSocketAddress getBindAddress(Properties properties) throws IOException
/*     */   {
/*  97 */     String propStr = properties.getProperty("atavism.socketpolicy.bindport");
/*  98 */     int port = 0;
/*  99 */     if (propStr != null) {
/* 100 */       port = Integer.parseInt(propStr.trim());
/*     */     }
/*     */ 
/* 104 */     propStr = properties.getProperty("atavism.socketpolicy.bindaddress");
/* 105 */     InetAddress address = null;
/* 106 */     if (propStr != null) {
/* 107 */       address = InetAddress.getByName(propStr.trim());
/*     */     }
/* 109 */     return new InetSocketAddress(address, port);
/*     */   }
/*     */ 
/*     */   protected Object createMBeanInstance()
/*     */   {
/* 119 */     return new SocketPolicyJMX();
/*     */   }
/*     */ 
/*     */   public void onTcpAccept(SocketChannel sc)
/*     */   {
/*     */     try
/*     */     {
/* 176 */       int DEFAULT_CAPACITY = 1024;
/* 177 */       int TIMEOUT = 2000;
/* 178 */       byte[] readData = new byte[DEFAULT_CAPACITY];
/* 179 */       ByteBuffer readBuffer = ByteBuffer.wrap(readData);
/*     */ 
/* 181 */       Selector selector = Selector.open();
/* 182 */       SelectionKey key = sc.register(selector, 1);
/*     */ 
/* 185 */       int keyCount = selector.select(TIMEOUT);
/* 186 */       if (keyCount == 0) {
/* 188 */         Log.info("Timed out waiting for data to read");
/*     */         return;
/* 191 */       }Log.info("Reading from socket channel");
/* 192 */       sc.read(readBuffer);
/* 193 */       Log.info("After read; position = " + readBuffer.position() + "; remaining = " + readBuffer.remaining() + "; limit = " + readBuffer.limit());
/* 194 */       readData[readBuffer.position()] = 0;
/* 195 */       String readStr = new String(readData, 0, readBuffer.position(), "US-ASCII");
/* 196 */       if (!readStr.startsWith("<policy-file-request/>")) {
/* 197 */         Log.info("Unrecognized socket policy request: " + readStr);
/*     */       }
/*     */       else {
/* 200 */         ByteBuffer writeBuffer = this.policyBuffer;
/*     */ 
/* 202 */         synchronized (writeBuffer) {
/* 203 */           writeBuffer.rewind();
/*     */ 
/* 206 */           sc.write(writeBuffer);
/*     */         }
/* 208 */         Log.debug("Recognized socket policy request: " + readStr);
/*     */       }
/*     */     } catch (IOException ex) {
/* 211 */       Log.warn("Failed to handle client connection: " + ex.getMessage());
/*     */     } finally {
/*     */       try {
/* 214 */         sc.close();
/*     */       }
/*     */       catch (IOException ex) {
/* 217 */         Log.warn("Failed to close client connection: " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setPolicy(String policy)
/*     */   {
/* 224 */     byte[] policyData = policy.getBytes();
/* 225 */     this.policyBuffer = ByteBuffer.wrap(policyData);
/*     */   }
/*     */ 
/*     */   protected class SocketPolicyJMX
/*     */     implements SocketPolicyHandler.SocketPolicyJMXMBean
/*     */   {
/*     */     protected SocketPolicyJMX()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int getPort()
/*     */     {
/* 136 */       return SocketPolicyHandler.this.port;
/*     */     }
/*     */ 
/*     */     public void setPort(int val) {
/* 140 */       SocketPolicyHandler.this.port = val;
/*     */     }
/*     */ 
/*     */     public int getIdleTimeout()
/*     */     {
/* 145 */       return SocketPolicyHandler.idleTimeout;
/*     */     }
/*     */ 
/*     */     public void setIdleTimeout(int timeout)
/*     */     {
/* 150 */       if (timeout > 0)
/* 151 */         SocketPolicyHandler.idleTimeout = timeout;
/*     */     }
/*     */ 
/*     */     public String getPolicy()
/*     */     {
/* 157 */       return SocketPolicyHandler.this.policy;
/*     */     }
/*     */ 
/*     */     public void setPolicy(String str)
/*     */     {
/* 162 */       SocketPolicyHandler.this.setPolicy(str);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface SocketPolicyJMXMBean
/*     */   {
/*     */     public abstract int getPort();
/*     */ 
/*     */     public abstract void setPort(int paramInt);
/*     */ 
/*     */     public abstract int getIdleTimeout();
/*     */ 
/*     */     public abstract void setIdleTimeout(int paramInt);
/*     */ 
/*     */     public abstract String getPolicy();
/*     */ 
/*     */     public abstract void setPolicy(String paramString);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.SocketPolicyHandler
 * JD-Core Version:    0.6.0
 */