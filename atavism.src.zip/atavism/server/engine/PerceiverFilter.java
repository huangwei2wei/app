package atavism.server.engine;

import java.io.Serializable;

public abstract interface PerceiverFilter<ElementType extends QuadTreeElement<ElementType>> extends Serializable
{
  public abstract boolean matches(Perceiver<ElementType> paramPerceiver, ElementType paramElementType);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.PerceiverFilter
 * JD-Core Version:    0.6.0
 */