/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.marshalling.Marshallable;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class OID
/*    */   implements Serializable, Marshallable, Comparable<OID>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private long data;
/*    */ 
/*    */   public static OID fromLong(long l)
/*    */   {
/* 19 */     if (l == 0L) {
/* 20 */       return null;
/*    */     }
/* 22 */     OID rv = new OID();
/* 23 */     rv.data = l;
/* 24 */     return rv;
/*    */   }
/*    */ 
/*    */   public long toLong() {
/* 28 */     return this.data;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     StringBuilder sb = new StringBuilder();
/* 34 */     String hexString = Long.toHexString(this.data);
/* 35 */     for (int i = hexString.length(); i < 16; i++) {
/* 36 */       sb.append('0');
/*    */     }
/* 38 */     sb.append(hexString);
/* 39 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public static OID fromString(String oidString) throws NumberFormatException {
/* 43 */     Long oidLong = Long.valueOf(Long.parseLong(oidString, 16));
/* 44 */     return fromLong(oidLong.longValue());
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public void setData(long l)
/*    */   {
/* 52 */     this.data = l;
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public long getData()
/*    */   {
/* 60 */     return this.data;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 64 */     if ((other instanceof OID)) {
/* 65 */       return ((OID)other).data == this.data;
/*    */     }
/* 67 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 71 */     return (int)this.data;
/*    */   }
/*    */ 
/*    */   public int compareTo(OID other) {
/* 75 */     if (this.data < other.data)
/* 76 */       return -1;
/* 77 */     if (this.data > other.data) {
/* 78 */       return 1;
/*    */     }
/* 80 */     return 0;
/*    */   }
/*    */ 
/*    */   public static OID parseLong(String str) throws NumberFormatException {
/* 84 */     return fromLong(Long.parseLong(str));
/*    */   }
/*    */ 
/*    */   public void marshalObject(AOByteBuffer buf) {
/* 88 */     buf.putOID(this);
/*    */   }
/*    */ 
/*    */   public Object unmarshalObject(AOByteBuffer buf) {
/* 92 */     return buf.getOID();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.OID
 * JD-Core Version:    0.6.0
 */