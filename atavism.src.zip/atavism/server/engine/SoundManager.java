/*   */ package atavism.server.engine;
/*   */ 
/*   */ import atavism.server.objects.Entity;
/*   */ 
/*   */ public class SoundManager
/*   */ {
/* 6 */   public static final String AMBIENTSOUND = (String)Entity.registerTransientPropertyKey("sndMgr.Ambient");
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.SoundManager
 * JD-Core Version:    0.6.0
 */