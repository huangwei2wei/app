/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.marshalling.Marshallable;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class Namespace
/*     */   implements Marshallable, Serializable
/*     */ {
/*     */   private transient String name;
/* 120 */   private int number = 0;
/*     */ 
/* 272 */   private static Map<String, Namespace> namespaceStringToNamespace = new HashMap();
/* 273 */   private static Map<Integer, Namespace> namespaceIntToNamespace = new HashMap();
/*     */ 
/* 279 */   public static Namespace TRANSIENT = null;
/*     */ 
/* 284 */   public static Namespace OBJECT_MANAGER = null;
/*     */ 
/* 289 */   public static Namespace WORLD_MANAGER = null;
/*     */ 
/* 294 */   public static Namespace COMBAT = null;
/*     */ 
/* 299 */   public static Namespace MOB = null;
/*     */ 
/* 305 */   public static Namespace BAG = null;
/*     */ 
/* 311 */   public static Namespace AGISITEM = null;
/*     */ 
/* 316 */   public static Namespace QUEST = null;
/*     */ 
/* 321 */   public static Namespace INSTANCE = null;
/*     */ 
/* 326 */   public static Namespace WM_INSTANCE = null;
/*     */ 
/* 331 */   public static Namespace VOICE = null;
/*     */ 
/* 336 */   public static Namespace TRAINER = null;
/*     */ 
/* 341 */   public static Namespace CLASSABILITY = null;
/*     */ 
/* 346 */   public static Namespace BILLING = null;
/*     */   public static final int transientNamespaceNumber = 1;
/*     */   public static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Namespace()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Namespace(String name, int number)
/*     */   {
/*  55 */     this.name = name;
/*  56 */     this.number = number;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  64 */     return this.name;
/*     */   }
/*     */ 
/*     */   public int getNumber()
/*     */   {
/*  72 */     return this.number;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  76 */     return "[Namespace " + this.name + ":" + this.number + "]";
/*     */   }
/*     */ 
/*     */   public void marshalObject(AOByteBuffer buf)
/*     */   {
/*  84 */     buf.putByte((byte)this.number);
/*     */   }
/*     */ 
/*     */   public Object unmarshalObject(AOByteBuffer buf)
/*     */   {
/*  92 */     int b = buf.getByte();
/*  93 */     Namespace ns = getNamespaceFromIntOrError(Integer.valueOf(b));
/*  94 */     return ns;
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 103 */     this.number = in.readInt();
/*     */   }
/*     */ 
/*     */   private Object readResolve()
/*     */     throws ObjectStreamException
/*     */   {
/* 109 */     Namespace ns = getNamespaceFromIntOrError(Integer.valueOf(this.number));
/* 110 */     return ns;
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 116 */     out.writeInt(this.number);
/*     */   }
/*     */ 
/*     */   public static Namespace intern(String name)
/*     */   {
/* 136 */     return getOrCreateNamespace(name);
/*     */   }
/*     */ 
/*     */   public static Namespace addDBNamespace(String name, int number)
/*     */   {
/* 146 */     Namespace ns = new Namespace(name, number);
/* 147 */     namespaceStringToNamespace.put(name, ns);
/* 148 */     namespaceIntToNamespace.put(Integer.valueOf(number), ns);
/* 149 */     return ns;
/*     */   }
/*     */ 
/*     */   public static void encacheNamespaceMapping()
/*     */   {
/* 159 */     if (Log.loggingDebug)
/* 160 */       Log.debug("Reading namespaces from the database");
/* 161 */     Engine.getDatabase().encacheNamespaceMapping();
/*     */ 
/* 163 */     TRANSIENT = intern("NS.transient");
/* 164 */     OBJECT_MANAGER = intern("NS.master");
/* 165 */     WORLD_MANAGER = intern("NS.wmgr");
/* 166 */     atavism.server.plugins.WorldManagerClient.NAMESPACE = WORLD_MANAGER;
/* 167 */     WM_INSTANCE = intern("NS.wminstance");
/* 168 */     atavism.server.plugins.WorldManagerClient.INSTANCE_NAMESPACE = WM_INSTANCE;
/* 169 */     COMBAT = intern("NS.combat");
/* 170 */     atavism.agis.plugins.CombatClient.NAMESPACE = COMBAT;
/* 171 */     MOB = intern("NS.mob");
/* 172 */     BAG = intern("NS.inv");
/* 173 */     atavism.server.plugins.InventoryClient.NAMESPACE = BAG;
/* 174 */     AGISITEM = intern("NS.item");
/* 175 */     atavism.server.plugins.InventoryClient.ITEM_NAMESPACE = AGISITEM;
/* 176 */     QUEST = intern("NS.quest");
/* 177 */     INSTANCE = intern("NS.instance");
/* 178 */     atavism.server.plugins.InstanceClient.NAMESPACE = INSTANCE;
/* 179 */     VOICE = intern("NS.voice");
/* 180 */     TRAINER = intern("NS.trainer");
/* 181 */     atavism.agis.plugins.TrainerClient.NAMESPACE = TRAINER;
/* 182 */     CLASSABILITY = intern("NS.classability");
/* 183 */     atavism.agis.plugins.ClassAbilityClient.NAMESPACE = CLASSABILITY;
/* 184 */     BILLING = intern("NS.billing");
/* 185 */     atavism.server.plugins.BillingClient.NAMESPACE = BILLING;
/* 186 */     if (Log.loggingDebug)
/* 187 */       Log.debug("Read " + namespaceIntToNamespace.size() + " namespaces from the database");
/*     */   }
/*     */ 
/*     */   public static Namespace getNamespace(String nsString)
/*     */   {
/* 195 */     Namespace ns = (Namespace)namespaceStringToNamespace.get(nsString);
/* 196 */     if (ns == null)
/* 197 */       throw new AORuntimeException("Database.getNamespaceInt Did not namespace int for namespace '" + nsString + "'");
/* 198 */     return ns;
/*     */   }
/*     */ 
/*     */   public static Namespace getNamespaceIfExists(String nsString)
/*     */   {
/* 206 */     return (Namespace)namespaceStringToNamespace.get(nsString);
/*     */   }
/*     */ 
/*     */   public static Namespace getNamespaceFromInt(Integer nsInt)
/*     */   {
/* 214 */     return (Namespace)namespaceIntToNamespace.get(nsInt);
/*     */   }
/*     */ 
/*     */   protected static Namespace getNamespaceFromIntOrError(Integer nsInt) {
/* 218 */     Namespace ns = (Namespace)namespaceIntToNamespace.get(nsInt);
/* 219 */     if (ns != null) {
/* 220 */       return ns;
/*     */     }
/* 222 */     return Engine.getDatabase().findExistingNamespace(nsInt);
/*     */   }
/*     */ 
/*     */   public static Integer compressNamespaceList(Set<Namespace> namespaces)
/*     */   {
/* 232 */     if ((namespaces == null) || (namespaces.size() == 0))
/* 233 */       return null;
/* 234 */     int result = 0;
/* 235 */     for (Namespace n : namespaces)
/* 236 */       result |= 1 << n.number;
/* 237 */     return Integer.valueOf(result);
/*     */   }
/*     */ 
/*     */   public static List<Namespace> decompressNamespaceList(Integer namespacesInteger)
/*     */   {
/* 245 */     List namespaces = new LinkedList();
/* 246 */     if (namespacesInteger == null)
/* 247 */       return namespaces;
/* 248 */     int n = namespacesInteger.intValue();
/* 249 */     for (int i = 0; i < 32; i++) {
/* 250 */       if ((n & 0x1) != 0)
/* 251 */         namespaces.add(getNamespaceFromInt(Integer.valueOf(i)));
/* 252 */       n >>= 1;
/* 253 */       if (n == 0)
/*     */         break;
/*     */     }
/* 256 */     return namespaces;
/*     */   }
/*     */ 
/*     */   private static Namespace getOrCreateNamespace(String nsString) {
/* 260 */     Namespace ns = (Namespace)namespaceStringToNamespace.get(nsString);
/* 261 */     if (ns != null) {
/* 262 */       return ns;
/*     */     }
/* 264 */     return createNamespace(nsString);
/*     */   }
/*     */ 
/*     */   private static Namespace createNamespace(String nsString) {
/* 268 */     Log.info("Creating namespace '" + nsString + "'");
/* 269 */     return Engine.getDatabase().createNamespace(nsString);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Namespace
 * JD-Core Version:    0.6.0
 */