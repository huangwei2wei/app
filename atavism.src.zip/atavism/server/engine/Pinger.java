package atavism.server.engine;

import atavism.server.util.Log;

public class Pinger
  implements Runnable
{
  public void run()
  {
    while (true)
      try
      {
        Database db = Engine.getDatabase();

        if (db != null) {
          db.ping();
        }

        Thread.sleep(300000L);

        continue;
      }
      catch (Exception e)
      {
        Log.exception("Pinger.run caught exception", e);
      }
  }
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Pinger
 * JD-Core Version:    0.6.0
 */