package atavism.server.engine;

import atavism.server.math.Quaternion;
import atavism.server.objects.AOObject;
import java.io.Serializable;
import java.util.Set;

public abstract interface WorldNode extends Locatable, Interpolatable, Serializable
{
  public abstract AOObject getObject();

  public abstract void setObject(AOObject paramAOObject);

  public abstract WorldNode getParent();

  public abstract void setParent(WorldNode paramWorldNode);

  public abstract Quaternion getOrientation();

  public abstract void setOrientation(Quaternion paramQuaternion);

  public abstract Set<WorldNode> getChildren();

  public abstract void setChildren(Set<WorldNode> paramSet);

  public abstract void addChild(WorldNode paramWorldNode);

  public abstract void removeChild(WorldNode paramWorldNode);

  public abstract boolean isSpawned();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WorldNode
 * JD-Core Version:    0.6.0
 */