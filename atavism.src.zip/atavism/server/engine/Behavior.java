/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageCallback;
/*     */ import atavism.msgsys.MessageDispatch;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.msgsys.SubjectMessage;
/*     */ import atavism.server.objects.ObjectStub;
/*     */ import atavism.server.objects.SpawnData;
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public abstract class Behavior
/*     */   implements MessageCallback, MessageDispatch, Serializable
/*     */ {
/*     */   protected ObjectStub obj;
/* 124 */   protected transient Lock lock = null;
/*     */ 
/* 126 */   public static MessageType MSG_TYPE_COMMAND = MessageType.intern("ao.COMMAND");
/* 127 */   public static MessageType MSG_TYPE_EVENT = MessageType.intern("ao.EVENT");
/*     */ 
/*     */   public Behavior()
/*     */   {
/*  16 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public Behavior(SpawnData data)
/*     */   {
/*  21 */     setupTransient();
/*     */   }
/*     */ 
/*     */   private void setupTransient() {
/*  25 */     this.lock = LockFactory.makeLock("BehavLock");
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/*  29 */     in.defaultReadObject();
/*  30 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public ObjectStub getObjectStub() {
/*  34 */     return this.obj;
/*     */   }
/*     */   public void setObjectStub(ObjectStub obj) {
/*  37 */     this.obj = obj;
/*     */   }
/*     */   public void initialize() {
/*     */   }
/*     */   public abstract void activate();
/*     */ 
/*     */   public abstract void deactivate();
/*     */ 
/*     */   public abstract void handleMessage(Message paramMessage, int paramInt);
/*     */ 
/*     */   public void dispatchMessage(Message message, int flags, MessageCallback callback) {
/*  51 */     Engine.defaultDispatchMessage(message, flags, callback);
/*     */   }
/*     */ 
/*     */   public static class EventMessage extends SubjectMessage
/*     */   {
/*     */     private String event;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public EventMessage()
/*     */     {
/* 100 */       setMsgType(Behavior.MSG_TYPE_EVENT);
/*     */     }
/*     */ 
/*     */     EventMessage(OID objOid) {
/* 104 */       super(objOid);
/*     */     }
/*     */ 
/*     */     EventMessage(ObjectStub obj) {
/* 108 */       super(obj.getOid());
/*     */     }
/*     */ 
/*     */     public void setEvent(String event) {
/* 112 */       this.event = event;
/*     */     }
/*     */ 
/*     */     public String getEvent() {
/* 116 */       return this.event;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CommandMessage extends SubjectMessage
/*     */   {
/*     */     private String cmd;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public CommandMessage()
/*     */     {
/*     */     }
/*     */ 
/*     */     public CommandMessage(OID objOid)
/*     */     {
/*  60 */       super(objOid);
/*     */     }
/*     */ 
/*     */     public CommandMessage(ObjectStub obj) {
/*  64 */       super(obj.getOid());
/*     */     }
/*     */ 
/*     */     public CommandMessage(String cmd)
/*     */     {
/*  69 */       setMsgType(Behavior.MSG_TYPE_COMMAND);
/*  70 */       this.cmd = cmd;
/*     */     }
/*     */ 
/*     */     public CommandMessage(OID objOid, String cmd) {
/*  74 */       super(objOid);
/*  75 */       this.cmd = cmd;
/*     */     }
/*     */ 
/*     */     public CommandMessage(ObjectStub obj, String cmd) {
/*  79 */       super(obj.getOid());
/*  80 */       this.cmd = cmd;
/*     */     }
/*     */ 
/*     */     public void setCmd(String cmd) {
/*  84 */       this.cmd = cmd;
/*     */     }
/*     */ 
/*     */     public String getCmd() {
/*  88 */       return this.cmd;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Behavior
 * JD-Core Version:    0.6.0
 */