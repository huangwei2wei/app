package atavism.server.engine;

public abstract interface SearchClause
{
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.SearchClause
 * JD-Core Version:    0.6.0
 */