/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class BasicWorldNode
/*     */   implements IBasicWorldNode, Serializable
/*     */ {
/*     */   protected OID instanceOid;
/* 133 */   protected Point loc = null;
/*     */ 
/* 137 */   protected AOVector dir = null;
/*     */ 
/* 141 */   protected Quaternion orient = null;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public BasicWorldNode()
/*     */   {
/*  20 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public BasicWorldNode(InterpolatedWorldNode inode)
/*     */   {
/*  27 */     setupTransient();
/*  28 */     this.instanceOid = inode.getInstanceOid();
/*  29 */     this.loc = inode.getLoc();
/*  30 */     this.dir = inode.getDir();
/*  31 */     this.orient = inode.getOrientation();
/*     */   }
/*     */ 
/*     */   public BasicWorldNode(OID instanceOid, AOVector dir, Point loc, Quaternion orient)
/*     */   {
/*  37 */     setupTransient();
/*  38 */     this.instanceOid = instanceOid;
/*  39 */     this.dir = dir;
/*  40 */     this.loc = loc;
/*  41 */     this.orient = orient;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  48 */     return "BasicWorldNode[instanceOid=" + this.instanceOid + " loc=" + this.loc + " dir=" + this.dir + " orient=" + this.orient + "]";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  54 */     BasicWorldNode other = (BasicWorldNode)obj;
/*  55 */     Log.debug("BWN equals with instanceOid: " + this.instanceOid + " and other instanceOid: " + other.instanceOid);
/*  56 */     if ((this.instanceOid != null) && (this.instanceOid.compareTo(other.instanceOid) != 0))
/*  57 */       return false;
/*  58 */     return (this.loc.equals(other.loc)) && (this.orient.equals(other.orient)) && (this.dir.equals(other.dir));
/*     */   }
/*     */ 
/*     */   protected void setupTransient()
/*     */   {
/*     */   }
/*     */ 
/*     */   public OID getInstanceOid()
/*     */   {
/*  71 */     return this.instanceOid;
/*     */   }
/*     */ 
/*     */   public void setInstanceOid(OID oid) {
/*  75 */     this.instanceOid = oid;
/*     */   }
/*     */ 
/*     */   public Point getLoc()
/*     */   {
/*  83 */     return this.loc;
/*     */   }
/*     */ 
/*     */   public void setLoc(Point loc)
/*     */   {
/*  91 */     this.loc = loc;
/*     */   }
/*     */ 
/*     */   public Quaternion getOrientation()
/*     */   {
/* 100 */     return this.orient;
/*     */   }
/*     */ 
/*     */   public void setOrientation(Quaternion orient)
/*     */   {
/* 108 */     this.orient = orient;
/*     */   }
/*     */ 
/*     */   public AOVector getDir()
/*     */   {
/* 116 */     return this.dir;
/*     */   }
/*     */ 
/*     */   public void setDir(AOVector dir)
/*     */   {
/* 124 */     this.dir = dir;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.BasicWorldNode
 * JD-Core Version:    0.6.0
 */