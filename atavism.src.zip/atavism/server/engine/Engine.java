/*      */ package atavism.server.engine;
/*      */ 
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageCallback;
/*      */ import atavism.msgsys.MessageCatalog;
/*      */ import atavism.msgsys.MessageType;
/*      */ import atavism.server.objects.EntityManager;
/*      */ import atavism.server.objects.World;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.InitLogAndPid;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.Logger;
/*      */ import atavism.server.util.NamedThreadFactory;
/*      */ import atavism.server.util.ServerVersion;
/*      */ import gnu.getopt.Getopt;
/*      */ import gnu.getopt.LongOpt;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileReader;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.RuntimeMXBean;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import javax.management.JMException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.ObjectName;
/*      */ import org.python.core.PyException;
/*      */ 
/*      */ public class Engine
/*      */ {
/*  704 */   private static ThreadLocal<EnginePlugin> currentPlugin = new ThreadLocal();
/*      */   private static Executor defaultMessageExecutor;
/* 1238 */   private static boolean runCPUTimeThread = false;
/*      */ 
/* 1243 */   private static int cpuTimeSamplingInterval = 250;
/*      */ 
/* 1248 */   private static Object mxbean = null;
/*      */ 
/* 1253 */   private static Thread cpuTimeThread = null;
/*      */ 
/* 1304 */   private static Thread statusReportingThread = null;
/*      */ 
/* 1309 */   private static Set<EnginePlugin> statusReportingPlugins = null;
/*      */ 
/* 1314 */   private static int statusReportingInterval = 5000;
/*      */ 
/* 1320 */   private static Lock statusReportingLock = LockFactory.makeLock("statusReportingLock");
/*      */   protected static Method cpuMethod;
/*      */   protected static int processorCount;
/* 1388 */   static final Logger log = new Logger("Engine");
/*      */ 
/* 1394 */   public static Properties properties = new Properties();
/*      */ 
/* 1400 */   public static int ExecutorThreadPoolSize = 10;
/*      */ 
/* 1405 */   private static ScriptManager scriptManager = null;
/*      */ 
/* 1412 */   public static int MAX_NETWORK_BUF_SIZE = 1000;
/*      */ 
/* 1419 */   public static String dumpStacksAndExitIfFileExists = "";
/*      */ 
/* 1424 */   private static Integer defaultWorldmgrport = Integer.valueOf(5040);
/*      */ 
/* 1429 */   private static String defaultMsgSvrHostname = "localhost";
/*      */ 
/* 1434 */   private static String engineHostName = "localhost";
/*      */ 
/* 1439 */   private static Integer defaultMsgSvrPort = Integer.valueOf(20374);
/*      */ 
/* 1444 */   private static Engine instance = null;
/*      */   private static final int DEFAULT_PERSISTENT_OBJ_SAVE_INTERVAL = 600000;
/* 1455 */   public long PersistentObjectSaveIntervalMS = 600000L;
/*      */ 
/* 1461 */   private static Lock pluginMapLock = LockFactory.makeLock("pluginMapLock");
/*      */ 
/* 1466 */   private static Map<String, EnginePlugin> pluginMap = new HashMap();
/*      */ 
/* 1471 */   private static Lock oidManagerLock = LockFactory.makeLock("oidManagerLock");
/*      */ 
/* 1476 */   private static OIDManager oidManager = null;
/*      */ 
/* 1481 */   private static EventServer eventServer = null;
/*      */ 
/* 1486 */   private static ScheduledThreadPoolExecutor executor = null;
/*      */ 
/* 1491 */   private static Interpolator interpolator = null;
/*      */ 
/* 1496 */   static PersistenceManager persistenceMgr = new PersistenceManager();
/*      */ 
/* 1501 */   private static Database db = null;
/*      */ 
/* 1506 */   private static MessageAgent agent = null;
/*      */ 
/* 1508 */   private static MBeanServer mbeanServer = null;
/*      */ 
/*      */   public Engine()
/*      */   {
/*   38 */     engineHostName = determineHostName();
/*   39 */     log.info("My local host name is '" + engineHostName + "'");
/*   40 */     if (isManagementEnabled()) {
/*   41 */       Log.debug("Enabling JMX management agent");
/*   42 */       createManagementAgent();
/*      */     }
/*      */ 
/*   45 */     mxbean = ManagementFactory.getOperatingSystemMXBean();
/*   46 */     cpuMethod = getCPUMethod();
/*   47 */     processorCount = Runtime.getRuntime().availableProcessors();
/*      */ 
/*   50 */     String cpuIntervalString = properties.getProperty("atavism.cputime_logging_interval");
/*   51 */     int cpuInterval = 0;
/*      */ 
/*   53 */     int logLevel = 1;
/*   54 */     if (cpuIntervalString != null) {
/*   55 */       int p = cpuIntervalString.indexOf(44);
/*   56 */       if (p > 0) {
/*   57 */         String logLevelString = cpuIntervalString.substring(p + 1);
/*   58 */         cpuIntervalString = cpuIntervalString.substring(0, p);
/*      */         try {
/*   60 */           int maybeLogLevel = Integer.parseInt(logLevelString.trim());
/*   61 */           if ((maybeLogLevel >= 0) && (maybeLogLevel <= 4))
/*   62 */             logLevel = maybeLogLevel;
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */       }
/*      */       try {
/*   68 */         cpuInterval = Integer.parseInt(cpuIntervalString.trim());
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*   74 */     if (cpuInterval > 0) {
/*   75 */       runCPUTimeThread = true;
/*   76 */       cpuTimeSamplingInterval = cpuInterval;
/*   77 */       log.debug("atavism.cputime_logging_interval set to " + cpuInterval + " ms");
/*      */     }
/*      */     else {
/*   80 */       runCPUTimeThread = false;
/*   81 */       cpuTimeSamplingInterval = cpuInterval;
/*   82 */       log.debug("atavism.cputime_logging_interval disabled");
/*      */     }
/*      */ 
/*   85 */     if (runCPUTimeThread) {
/*   86 */       cpuTimeThread = new Thread(new CPUTimeThread(logLevel), "CPUTime");
/*   87 */       cpuTimeThread.start();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static String determineHostName()
/*      */   {
/*   94 */     String hostName = System.getProperty("atavism.hostname");
/*   95 */     if (hostName == null)
/*   96 */       hostName = reverseLocalHostLookup();
/*   97 */     if (hostName == null) {
/*   98 */       log.warn("Could not determine host name from reverse lookup or atavism.hostname, using 'localhost'");
/*   99 */       hostName = "localhost";
/*      */     }
/*  101 */     return hostName;
/*      */   }
/*      */ 
/*      */   private static String reverseLocalHostLookup()
/*      */   {
/*  106 */     InetAddress localMachine = null;
/*      */     try {
/*  108 */       localMachine = InetAddress.getLocalHost();
/*  109 */       return localMachine.getHostName();
/*      */     }
/*      */     catch (UnknownHostException e) {
/*  112 */       log.warn("Could not get host name from local IP address " + localMachine);
/*      */     }
/*      */ 
/*  115 */     return null;
/*      */   }
/*      */ 
/*      */   public static Engine getInstance()
/*      */   {
/*  123 */     return instance;
/*      */   }
/*      */ 
/*      */   private static void saveProcessID(String svrName, String runDir)
/*      */   {
/*  135 */     RuntimeMXBean rt = ManagementFactory.getRuntimeMXBean();
/*  136 */     String pid = rt.getName();
/*  137 */     if (Log.loggingDebug) {
/*  138 */       log.info("PROCESS ID IS " + pid);
/*  139 */       log.info("server name is " + svrName);
/*      */     }
/*      */     try
/*      */     {
/*  143 */       if (runDir != null) {
/*  144 */         File outFile = new File(runDir + "\\" + svrName + ".bat");
/*  145 */         PrintWriter out = new PrintWriter(new FileWriter(outFile));
/*  146 */         out.println("set pid=" + pid.substring(0, pid.indexOf("@")));
/*  147 */         out.close();
/*      */       }
/*      */     } catch (IOException e) {
/*  150 */       Log.exception("Engine.saveProcessID caught exception", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void dumpAllThreadStacks()
/*      */   {
/*  158 */     StringBuilder traceStr = new StringBuilder(1000);
/*  159 */     dumpAllThreadStacks(traceStr, false);
/*  160 */     Log.error(traceStr.toString());
/*      */   }
/*      */ 
/*      */   public static void dumpAllThreadStacks(StringBuilder stringBuilder, boolean sortThreads)
/*      */   {
/*  172 */     Map traces = Thread.getAllStackTraces();
/*  173 */     stringBuilder.append("Dumping the thread stack for every thread in the process");
/*  174 */     Collection keySet = traces.keySet();
/*  175 */     if (sortThreads) {
/*  176 */       LinkedList threads = new LinkedList();
/*  177 */       threads.addAll(keySet);
/*  178 */       Collections.sort(threads, new Comparator() {
/*      */         public int compare(Thread t1, Thread t2) {
/*  180 */           return t1.getName().compareTo(t2.getName());
/*      */         }
/*      */       });
/*  183 */       keySet = threads;
/*      */     }
/*  185 */     for (Thread thread : keySet) {
/*  186 */       stringBuilder.append("\n\nDumping stack for thread " + thread.getName());
/*  187 */       printStack(stringBuilder, (StackTraceElement[])traces.get(thread));
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void printStack(StringBuilder stringBuilder, StackTraceElement[] elements) {
/*  191 */     for (StackTraceElement elem : elements) {
/*  192 */       stringBuilder.append("\n       at ");
/*  193 */       stringBuilder.append(elem.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public static EventServer getEventServer()
/*      */   {
/*  202 */     if (eventServer == null) {
/*  203 */       Log.warn("Engine.getEventServer: creating eventserver (was null)");
/*  204 */       eventServer = new EventServer();
/*      */     }
/*  206 */     return eventServer;
/*      */   }
/*      */ 
/*      */   public static ScheduledThreadPoolExecutor getExecutor()
/*      */   {
/*  214 */     if (executor == null) {
/*  215 */       executor = new ScheduledThreadPoolExecutor(ExecutorThreadPoolSize, new NamedThreadFactory("Scheduled"));
/*      */     }
/*      */ 
/*  219 */     return executor;
/*      */   }
/*      */ 
/*      */   public static Interpolator<?> getInterpolator()
/*      */   {
/*  227 */     return interpolator;
/*      */   }
/*      */ 
/*      */   public static void setInterpolator(Interpolator<?> interpolator)
/*      */   {
/*  236 */     interpolator = interpolator;
/*      */   }
/*      */ 
/*      */   public static void setBasicInterpolatorInterval(Integer interval)
/*      */   {
/*  245 */     interpolator = new BasicInterpolator(interval.intValue());
/*      */   }
/*      */ 
/*      */   public static ScriptManager getScriptManager()
/*      */   {
/*  252 */     return scriptManager;
/*      */   }
/*      */ 
/*      */   public static Database getDatabase()
/*      */   {
/*  260 */     if (db == null) {
/*  261 */       Log.warn("Engine.getDatabase: returning null database object");
/*      */     }
/*  263 */     return db;
/*      */   }
/*      */ 
/*      */   public static void setDatabase(Database db)
/*      */   {
/*  271 */     db = db;
/*      */   }
/*      */ 
/*      */   public static OIDManager getOIDManager()
/*      */   {
/*  280 */     oidManagerLock.lock();
/*      */     try {
/*  282 */       if (oidManager == null) {
/*  283 */         oidManager = new OIDManager();
/*      */       }
/*  285 */       OIDManager localOIDManager = oidManager;
/*      */       return localOIDManager; } finally { oidManagerLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static void setOIDManager(OIDManager o)
/*      */   {
/*  296 */     oidManagerLock.lock();
/*      */     try {
/*  298 */       if (oidManager != null) {
/*  299 */         throw new RuntimeException("Engine.setOIDManager: oid manager is not null");
/*      */       }
/*      */ 
/*  302 */       oidManager = o;
/*      */     } finally {
/*  304 */       oidManagerLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static PersistenceManager getPersistenceManager()
/*      */   {
/*  314 */     return persistenceMgr;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/*  326 */     if (args.length < 1) {
/*  327 */       System.err.println("java Engine [-i pre-script ...] [post-script ...]");
/*  328 */       System.exit(1);
/*      */     }
/*  330 */     String worldName = System.getProperty("atavism.worldname");
/*  331 */     String hostName = determineHostName();
/*  332 */     properties = InitLogAndPid.initLogAndPid(args, worldName, hostName);
/*      */ 
/*  335 */     instance = new Engine();
/*      */ 
/*  338 */     String svrName = System.getProperty("atavism.loggername");
/*  339 */     String agentType = System.getProperty("atavism.agenttype", svrName);
/*  340 */     String runDir = System.getProperty("atavism.rundir");
/*  341 */     if ((System.getProperty("os.name").contains("Windows")) && (svrName != null) && (runDir != null)) {
/*  342 */       saveProcessID(svrName, runDir);
/*      */     }
/*      */ 
/*  346 */     List postScripts = processPreScripts(args);
/*      */     try
/*      */     {
/*  352 */       db = new Database(getDBDriver());
/*  353 */       if (Log.loggingDebug) {
/*  354 */         log.debug("connecting to " + getDBHostname() + "user = " + getDBUser() + " passwd=" + getDBPassword());
/*      */       }
/*  356 */       db.connect(getDBUrl(), getDBUser(), getDBPassword());
/*      */     }
/*      */     catch (AORuntimeException e) {
/*  359 */       Log.exception("Engine.main: error connecting to the database", e);
/*  360 */       System.exit(1);
/*      */     }
/*  362 */     Log.info("connected to database");
/*      */ 
/*  364 */     Namespace.encacheNamespaceMapping();
/*  365 */     Log.info("encached the mapping of namespace strings to ints");
/*      */ 
/*  368 */     agent = new MessageAgent(svrName);
/*  369 */     agent.setDefaultSubscriptionFlags(1);
/*  370 */     agent.setAdvertisementFileName(agentType + "-ads.txt");
/*  371 */     List types = readAdvertisements(agentType);
/*  372 */     types.add(EnginePlugin.MSG_TYPE_PLUGIN_STATE);
/*  373 */     agent.addAdvertisements(types);
/*  374 */     agent.addNoProducersExpected(MessageType.intern("ao.SEARCH"));
/*  375 */     agent.addNoProducersExpected(MessageType.intern("ao.GET_PLUGIN_STATUS"));
/*  376 */     String message_agent_stats = properties.getProperty("atavism.message_agent_stats");
/*      */ 
/*  378 */     if ((message_agent_stats != null) && (message_agent_stats.equals("true")))
/*  379 */       agent.startStatsThread();
/*      */     try
/*      */     {
/*  382 */       agent.openListener();
/*  383 */       agent.connectToDomain(getMessageServerHostname(), getMessageServerPort());
/*      */ 
/*  385 */       agent.waitForRemoteAgents();
/*      */     }
/*      */     catch (Exception ex) {
/*  388 */       Log.exception("Engine.main: domain server " + getMessageServerHostname() + ":" + getMessageServerPort() + " failed", ex);
/*      */ 
/*  391 */       System.exit(1);
/*      */     }
/*      */ 
/*  395 */     executor = new ScheduledThreadPoolExecutor(ExecutorThreadPoolSize, new NamedThreadFactory("Scheduled"));
/*      */ 
/*  399 */     if (World.getGeometry() == null) {
/*  400 */       Log.warn("engine: world geometry is not set");
/*      */     }
/*      */ 
/*  404 */     setOIDManager(new OIDManager(db));
/*      */ 
/*  406 */     processPostScripts(postScripts);
/*      */     try
/*      */     {
/*      */       while (true)
/*      */       {
/*  415 */         if (dumpStacksAndExitIfFileExists.length() > 0) {
/*  416 */           File dumpFile = new File(dumpStacksAndExitIfFileExists);
/*  417 */           if (dumpFile.exists()) {
/*  418 */             StringBuilder sb = new StringBuilder();
/*  419 */             dumpAllThreadStacks(sb, true);
/*  420 */             Log.info(sb.toString());
/*  421 */             System.exit(0);
/*      */           }
/*  423 */           Thread.sleep(1000L);
/*  424 */           continue;
/*      */         }
/*  426 */         Thread.sleep(10000L);
/*      */       }
/*      */     } catch (Exception e) {
/*  429 */       Log.exception("Engine.main: error in Thread.sleep", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static List<MessageType> readAdvertisements(String agentName) {
/*  434 */     List result = new LinkedList();
/*      */ 
/*  436 */     String home = System.getenv("AO_HOME");
/*  437 */     String worldConfigDir = System.getenv("AO_WORLD_CONFIG");
/*  438 */     String commonFileName = home + "/config/common/" + agentName + "-ads.txt";
/*  439 */     File commonFile = new File(commonFileName);
/*  440 */     String worldFileName = worldConfigDir + "/" + agentName + "-ads.txt";
/*  441 */     File worldFile = new File(worldFileName);
/*  442 */     if ((!commonFile.exists()) && (!worldFile.exists())) {
/*  443 */       Log.warn("Missing advertisements file for agent " + agentName + " for world " + getWorldName() + " in either " + commonFileName + " or " + worldFileName);
/*      */ 
/*  445 */       return result;
/*      */     }
/*      */ 
/*  448 */     if (commonFile.exists())
/*  449 */       addAdvertisements(commonFileName, result);
/*  450 */     if (worldFile.exists())
/*  451 */       addAdvertisements(worldFileName, result);
/*  452 */     return result;
/*      */   }
/*      */ 
/*      */   static void addAdvertisements(String fileName, List<MessageType> result) {
/*      */     try {
/*  457 */       File file = new File(fileName);
/*  458 */       BufferedReader in = new BufferedReader(new FileReader(file));
/*  459 */       String originalLine = null;
/*  460 */       int count = 0;
/*  461 */       while ((originalLine = in.readLine()) != null) {
/*  462 */         count++;
/*  463 */         String line = originalLine.trim();
/*  464 */         int pos = line.indexOf("#");
/*  465 */         if (pos >= 0)
/*  466 */           line = line.substring(0, pos).trim();
/*  467 */         if (line.length() == 0)
/*      */           continue;
/*  469 */         if ((line.indexOf(" ") > 0) || (line.indexOf(",") > 0)) {
/*  470 */           Log.error("File '" + fileName + "', line " + count + ": unexpected character");
/*  471 */           continue;
/*      */         }
/*  473 */         MessageType type = MessageCatalog.getMessageType(line);
/*  474 */         if (type == null) {
/*  475 */           Log.error("File '" + fileName + "', line " + count + ": unknown message type " + line);
/*      */         }
/*  479 */         else if (!result.contains(type)) {
/*  480 */           result.add(type);
/*      */         }
/*      */       }
/*  483 */       in.close();
/*      */     }
/*      */     catch (IOException ex) {
/*  486 */       Log.exception(fileName, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List<String> processPreScripts(String[] args)
/*      */   {
/*  500 */     List preScripts = new LinkedList();
/*      */ 
/*  503 */     List postScripts = new LinkedList();
/*      */ 
/*  506 */     populateScriptList(args, preScripts, postScripts);
/*      */ 
/*  509 */     scriptManager = new ScriptManager();
/*  510 */     String scriptName = null;
/*      */     try {
/*  512 */       scriptManager.init();
/*  513 */       for (String initScriptFile : preScripts) {
/*  514 */         scriptName = initScriptFile;
/*  515 */         if (Log.loggingDebug) {
/*  516 */           log.debug("Engine: reading in script: " + initScriptFile);
/*      */         }
/*  518 */         File f = new File(initScriptFile);
/*  519 */         if (f.exists()) {
/*  520 */           if (Log.loggingDebug)
/*  521 */             log.debug("Executing init script file: " + initScriptFile);
/*  522 */           scriptManager.runFile(initScriptFile);
/*  523 */           log.debug("script completed");
/*      */         } else {
/*  525 */           Log.warn("didnt find local script file, skipping: " + initScriptFile);
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  529 */       Log.exception("Engine.processPreScripts: got exception running script '" + scriptName + "'", e);
/*  530 */       System.exit(1);
/*      */     }
/*  532 */     return postScripts;
/*      */   }
/*      */ 
/*      */   public static void processPostScripts(List<String> postScripts)
/*      */   {
/*  546 */     scriptManager = new ScriptManager();
/*  547 */     String scriptName = null;
/*      */     try {
/*  549 */       scriptManager.init();
/*  550 */       for (String scriptFilename : postScripts) {
/*  551 */         scriptName = scriptFilename;
/*  552 */         if (Log.loggingDebug)
/*  553 */           log.debug("Executing script file: " + scriptFilename);
/*  554 */         scriptManager.runFile(scriptFilename);
/*  555 */         log.debug("script completed");
/*      */       }
/*      */     } catch (Exception e) {
/*  558 */       Log.exception("Engine.processPostScripts: got exception running script '" + scriptName + "'", e);
/*  559 */       System.exit(1);
/*      */     }
/*      */   }
/*      */ 
/*      */   static void populateScriptList(String[] args, List<String> preScripts, List<String> postScripts)
/*      */   {
/*  576 */     LongOpt[] longopts = new LongOpt[1];
/*  577 */     longopts[0] = new LongOpt("pid", 1, null, 2);
/*  578 */     Getopt g = new Getopt("Engine", args, "i:w:m:t:rgP:", longopts);
/*      */     int c;
/*  582 */     while ((c = g.getopt()) != -1)
/*      */     {
/*      */       String arg;
/*  583 */       switch (c)
/*      */       {
/*      */       case 105:
/*  587 */         arg = g.getOptarg();
/*  588 */         if (Log.loggingDebug)
/*  589 */           log.debug("populateScriptList: option i: " + arg);
/*  590 */         preScripts.add(arg);
/*  591 */         break;
/*      */       case 63:
/*  594 */         break;
/*      */       case 2:
/*      */       case 109:
/*      */       case 116:
/*  600 */         arg = g.getOptarg();
/*  601 */         break;
/*      */       case 80:
/*      */       case 103:
/*      */       case 114:
/*  606 */         break;
/*      */       default:
/*  609 */         System.out.print("getopt() returned " + c + "\n");
/*      */       }
/*      */     }
/*  612 */     for (int i = g.getOptind(); i < args.length; i++) {
/*  613 */       if (Log.loggingDebug)
/*  614 */         log.debug("populateScriptList: nonoption args element: " + args[i]);
/*  615 */       postScripts.add(args[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getPersistentObjectSaveIntervalMS()
/*      */   {
/*  624 */     return this.PersistentObjectSaveIntervalMS;
/*      */   }
/*      */ 
/*      */   public void setPersistentObjectSaveIntervalMS(long interval)
/*      */   {
/*  632 */     this.PersistentObjectSaveIntervalMS = interval;
/*      */   }
/*      */ 
/*      */   public static EnginePlugin registerPlugin(String className)
/*      */   {
/*      */     try
/*      */     {
/*  643 */       if (Log.loggingDebug)
/*  644 */         log.debug("Engine.registerPlugin: loading class " + className);
/*  645 */       Class enginePluginClass = Class.forName(className);
/*  646 */       EnginePlugin enginePlugin = (EnginePlugin)enginePluginClass.newInstance();
/*  647 */       registerPlugin(enginePlugin);
/*  648 */       return enginePlugin;
/*      */     } catch (Exception e) {
/*  650 */       log.error("EnginePlugin.registerPugin failed: stack trace follows");
/*  651 */       e.printStackTrace();
/*  652 */     }throw new RuntimeException("could not load and/or activate class: " + e, e);
/*      */   }
/*      */ 
/*      */   public static void registerPlugin(EnginePlugin plugin)
/*      */   {
/*  662 */     if (Log.loggingDebug)
/*  663 */       log.debug("Engine.registerPlugin: registering " + plugin.getName());
/*  664 */     setCurrentPlugin(plugin);
/*  665 */     plugin.activate();
/*  666 */     setCurrentPlugin(null);
/*  667 */     pluginMapLock.lock();
/*      */     try {
/*  669 */       pluginMap.put(plugin.getName(), plugin);
/*      */     } finally {
/*  671 */       pluginMapLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static EnginePlugin getPlugin(String name)
/*      */   {
/*  681 */     pluginMapLock.lock();
/*      */     try {
/*  683 */       EnginePlugin localEnginePlugin = (EnginePlugin)pluginMap.get(name);
/*      */       return localEnginePlugin; } finally { pluginMapLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static EnginePlugin getCurrentPlugin()
/*      */   {
/*  694 */     return (EnginePlugin)currentPlugin.get();
/*      */   }
/*      */ 
/*      */   public static void setCurrentPlugin(EnginePlugin plugin)
/*      */   {
/*  701 */     currentPlugin.set(plugin);
/*      */   }
/*      */ 
/*      */   public static String getEngineHostName()
/*      */   {
/*  717 */     return engineHostName;
/*      */   }
/*      */ 
/*      */   public static String getDBDriver()
/*      */   {
/*  725 */     String driver = properties.getProperty("atavism.db_driver");
/*  726 */     if (driver == null)
/*  727 */       driver = "com.mysql.jdbc.Driver";
/*  728 */     return driver;
/*      */   }
/*      */ 
/*      */   public static void setDBDriver(String driver)
/*      */   {
/*  736 */     properties.setProperty("atavism.db_driver", driver);
/*      */   }
/*      */ 
/*      */   public static String getDBType()
/*      */   {
/*  744 */     String dbtype = properties.getProperty("atavism.db_type");
/*  745 */     if (dbtype == null) {
/*  746 */       return "mysql";
/*      */     }
/*  748 */     return dbtype;
/*      */   }
/*      */ 
/*      */   public static void setDBType(String dbtype)
/*      */   {
/*  756 */     properties.setProperty("atavism.db_type", dbtype);
/*      */   }
/*      */ 
/*      */   public static void setDBUrl(String url)
/*      */   {
/*  764 */     properties.setProperty("atavism.db_url", url);
/*      */   }
/*      */ 
/*      */   public static String getDBUrl()
/*      */   {
/*  772 */     String url = properties.getProperty("atavism.db_url");
/*  773 */     if (url == null)
/*  774 */       url = "jdbc:" + getDBType() + "://" + getDBHostname() + "/" + getDBName();
/*  775 */     return url;
/*      */   }
/*      */ 
/*      */   public static String getDBUser()
/*      */   {
/*  783 */     return properties.getProperty("atavism.db_user");
/*      */   }
/*      */ 
/*      */   public static void setDBUser(String username)
/*      */   {
/*  791 */     properties.setProperty("atavism.db_user", username);
/*      */   }
/*      */ 
/*      */   public static String getDBPassword()
/*      */   {
/*  799 */     return properties.getProperty("atavism.db_password");
/*      */   }
/*      */ 
/*      */   public static void setDBPassword(String password)
/*      */   {
/*  807 */     properties.setProperty("atavism.db_password", password);
/*      */   }
/*      */ 
/*      */   public static String getDBHostname()
/*      */   {
/*  815 */     return properties.getProperty("atavism.db_hostname");
/*      */   }
/*      */ 
/*      */   public static void setDBHostname(String hostname)
/*      */   {
/*  823 */     properties.setProperty("atavism.db_hostname", hostname);
/*      */   }
/*      */ 
/*      */   public static String getDBName()
/*      */   {
/*  831 */     String dbname = properties.getProperty("atavism.db_name");
/*  832 */     if (dbname == null) {
/*  833 */       return "atavism";
/*      */     }
/*  835 */     return dbname;
/*      */   }
/*      */ 
/*      */   public static void setDBName(String name)
/*      */   {
/*  844 */     properties.setProperty("atavism.db_name", name);
/*      */   }
/*      */ 
/*      */   public static String getMessageServerHostname()
/*      */   {
/*  852 */     String msgSvrHostname = defaultMsgSvrHostname;
/*  853 */     msgSvrHostname = properties.getProperty("atavism.msgsvr_hostname");
/*  854 */     if (msgSvrHostname == null) {
/*  855 */       msgSvrHostname = defaultMsgSvrHostname;
/*      */     }
/*  857 */     return msgSvrHostname;
/*      */   }
/*      */ 
/*      */   public static void setMessageServerHostname(String host)
/*      */   {
/*  865 */     properties.setProperty("atavism.msgsvr_port", host);
/*      */   }
/*      */ 
/*      */   public static Integer getMessageServerPort()
/*      */   {
/*  874 */     String sMsgSvrPort = properties.getProperty("atavism.msgsvr_port");
/*      */     int msgSvrPort;
/*      */     int msgSvrPort;
/*  875 */     if (sMsgSvrPort == null)
/*  876 */       msgSvrPort = defaultMsgSvrPort.intValue();
/*      */     else {
/*  878 */       msgSvrPort = Integer.parseInt(sMsgSvrPort.trim());
/*      */     }
/*  880 */     return Integer.valueOf(msgSvrPort);
/*      */   }
/*      */ 
/*      */   public static void setMessageServerPort(Integer port)
/*      */   {
/*  888 */     properties.setProperty("atavism.msgsvr_port", Integer.toString(port.intValue()));
/*      */   }
/*      */ 
/*      */   public static void setWorldMgrPort(Integer port)
/*      */   {
/*  896 */     properties.setProperty("atavism.worldmgrport", Integer.toString(port.intValue()));
/*      */   }
/*      */ 
/*      */   public static Integer getWorldMgrPort()
/*      */   {
/*  905 */     String sWorldMgrPort = properties.getProperty("atavism.worldmgrport");
/*      */     int port;
/*      */     int port;
/*  906 */     if (sWorldMgrPort == null)
/*  907 */       port = defaultWorldmgrport.intValue();
/*      */     else {
/*  909 */       port = Integer.parseInt(sWorldMgrPort.trim());
/*      */     }
/*  911 */     return Integer.valueOf(port);
/*      */   }
/*      */ 
/*      */   public static int getStatusReportingInterval()
/*      */   {
/*  920 */     return statusReportingInterval;
/*      */   }
/*      */ 
/*      */   public static void setStatusReportingInterval(int statusReportingInterval)
/*      */   {
/*  929 */     statusReportingInterval = statusReportingInterval;
/*      */   }
/*      */ 
/*      */   public static Properties getProperties() {
/*  933 */     return properties;
/*      */   }
/*      */ 
/*      */   public static String getProperty(String propName)
/*      */   {
/*  946 */     return properties.getProperty(propName);
/*      */   }
/*      */ 
/*      */   public static void setProperty(String propName, String propValue)
/*      */   {
/*  957 */     properties.setProperty(propName, propValue);
/*      */   }
/*      */ 
/*      */   public static Integer getIntProperty(String propName)
/*      */   {
/*  967 */     String intString = properties.getProperty(propName);
/*  968 */     if (intString == null)
/*  969 */       return null;
/*      */     try {
/*  971 */       return Integer.valueOf(intString.trim());
/*      */     }
/*      */     catch (NumberFormatException e) {
/*  974 */       Log.error("Property '" + propName + "' value '" + intString.trim() + "' is not an integer.");
/*  975 */     }return null;
/*      */   }
/*      */ 
/*      */   public static String getWorldName()
/*      */   {
/*  985 */     return System.getProperty("atavism.worldname");
/*      */   }
/*      */ 
/*      */   public static void setWorldName(String worldName)
/*      */   {
/*  994 */     properties.setProperty("atavism.worldname", worldName);
/*      */   }
/*      */ 
/*      */   public static String getLogLevel()
/*      */   {
/* 1004 */     String logLevelString = getProperty("atavism.log_level");
/* 1005 */     if (logLevelString == null) {
/* 1006 */       logLevelString = "1";
/*      */     }
/* 1008 */     return logLevelString;
/*      */   }
/*      */ 
/*      */   public static void setLogLevel(String level)
/*      */   {
/* 1016 */     properties.setProperty("atavism.log_level", level);
/*      */   }
/*      */ 
/*      */   public static boolean isManagementEnabled()
/*      */   {
/* 1025 */     String mgmt = properties.getProperty("com.sun.management.jmxremote");
/*      */ 
/* 1027 */     return mgmt != null;
/*      */   }
/*      */ 
/*      */   public static MessageAgent getAgent()
/*      */   {
/* 1039 */     return agent;
/*      */   }
/*      */ 
/*      */   public static Map<String, String> makeMapOfString(String str)
/*      */   {
/* 1048 */     Map propMap = new HashMap();
/* 1049 */     String[] keysAndValues = str.split(",");
/* 1050 */     for (String keyAndValue : keysAndValues) {
/* 1051 */       String[] ss = keyAndValue.split("=");
/* 1052 */       if (ss.length == 2)
/* 1053 */         propMap.put(ss[0], ss[1]);
/*      */       else
/* 1055 */         Log.error("Engine.makeMapOfString: Could not parse name/value string '" + str + "' at '" + keyAndValue + "'");
/*      */     }
/* 1057 */     return propMap;
/*      */   }
/*      */ 
/*      */   public static String makeStringFromMap(Map<String, String> propMap)
/*      */   {
/* 1066 */     String s = "";
/* 1067 */     if (propMap == null)
/* 1068 */       return s;
/* 1069 */     for (Map.Entry pair : propMap.entrySet()) {
/* 1070 */       if (s != "")
/* 1071 */         s = s + ",";
/* 1072 */       s = s + (String)pair.getKey() + "=" + (String)pair.getValue();
/*      */     }
/* 1074 */     return s;
/*      */   }
/*      */ 
/*      */   public static void defaultDispatchMessage(Message message, int flags, MessageCallback callback)
/*      */   {
/* 1125 */     if (Log.loggingDebug) {
/* 1126 */       Log.debug("defaultDispatchMessage " + message.getSenderName() + "," + message.getMsgId() + " " + message.getMsgType());
/*      */     }
/* 1128 */     if (defaultMessageExecutor == null) {
/* 1129 */       defaultMessageExecutor = Executors.newFixedThreadPool(10, new NamedThreadFactory("EngineDispatch"));
/*      */     }
/* 1131 */     defaultMessageExecutor.execute(new QueuedMessage(message, flags, callback));
/*      */   }
/*      */ 
/*      */   public static void registerStatusReportingPlugin(EnginePlugin plugin)
/*      */   {
/* 1141 */     statusReportingLock.lock();
/*      */     try {
/* 1143 */       if (Log.loggingDebug) {
/* 1144 */         Log.debug("Engine.registerStatusReportingPlugin: Registering plugin " + plugin.getName() + " of type " + plugin.getPluginType());
/*      */       }
/* 1146 */       if (statusReportingPlugins == null)
/*      */       {
/* 1148 */         statusReportingPlugins = new HashSet();
/*      */ 
/* 1150 */         if (mxbean == null)
/* 1151 */           mxbean = ManagementFactory.getOperatingSystemMXBean();
/* 1152 */         statusReportingThread = new Thread(new StatusReportingThread(), "StatusReporting");
/* 1153 */         statusReportingThread.start();
/*      */       }
/* 1155 */       if (!getDatabase().registerStatusReportingPlugin(plugin, getAgent().getDomainStartTime()))
/* 1156 */         log.error("Engine.registerStatusReportingPlugin: Registration of plugin '" + plugin.getName() + "' failed!");
/*      */       else
/* 1158 */         statusReportingPlugins.add(plugin);
/*      */     }
/*      */     finally {
/* 1161 */       statusReportingLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static Method getCPUMethod()
/*      */   {
/*      */     try
/*      */     {
/* 1171 */       Class operatingSystemMXBean = null;
/* 1172 */       operatingSystemMXBean = getParentInterface(mxbean.getClass(), "com.sun.management.OperatingSystemMXBean");
/*      */ 
/* 1174 */       if (operatingSystemMXBean == null) {
/* 1175 */         throw new ClassNotFoundException("OperatingSystemMXBean is not a super-class of the management bean");
/*      */       }
/* 1177 */       return operatingSystemMXBean.getMethod("getProcessCpuTime", new Class[0]);
/*      */     }
/*      */     catch (NoSuchMethodException ex) {
/* 1180 */       Log.exception("CPU time will not be reported", ex);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/* 1183 */       Log.exception("CPU time will not be reported", ex);
/*      */     }
/* 1185 */     return null;
/*      */   }
/*      */ 
/*      */   protected static long getProcessCpuTime(Method cpuMethod, Object mxbean)
/*      */   {
/* 1196 */     if (cpuMethod == null)
/* 1197 */       return 0L;
/*      */     try {
/* 1199 */       return ((Long)cpuMethod.invoke(mxbean, new Object[0])).longValue();
/*      */     }
/*      */     catch (IllegalAccessException ex) {
/* 1202 */       Log.exception("Failed getting CPU time", ex);
/*      */     }
/*      */     catch (InvocationTargetException ex) {
/* 1205 */       Log.exception("Failed getting CPU time", ex);
/*      */     }
/* 1207 */     return 0L;
/*      */   }
/*      */ 
/*      */   protected static Class getParentInterface(Class cl, String name)
/*      */   {
/* 1218 */     if (cl.getName().equals(name)) {
/* 1219 */       return cl;
/*      */     }
/* 1221 */     Class[] interfaces = cl.getInterfaces();
/* 1222 */     for (int ii = 0; ii < interfaces.length; ii++) {
/* 1223 */       Class match = getParentInterface(interfaces[ii], name);
/* 1224 */       if (match != null)
/* 1225 */         return match;
/*      */     }
/* 1227 */     return null;
/*      */   }
/*      */ 
/*      */   private void createManagementAgent()
/*      */   {
/* 1514 */     mbeanServer = ManagementFactory.getPlatformMBeanServer();
/*      */     try {
/* 1516 */       ObjectName name = new ObjectName("net.atavism:type=Engine");
/* 1517 */       mbeanServer.registerMBean(createMBeanInstance(), name);
/* 1518 */       Log.debug("Registered Engine with JMX management agent");
/*      */     } catch (JMException ex) {
/* 1520 */       Log.exception("Engine.createManagementAgent: exception in registerMBean", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Object createMBeanInstance()
/*      */   {
/* 1528 */     return new EngineJMX();
/*      */   }
/*      */ 
/*      */   public static MBeanServer getManagementAgent()
/*      */   {
/* 1534 */     return mbeanServer; } 
/* 1672 */   protected static class EngineJMX implements Engine.EngineJMXMBean { protected static String defaultPythonImports = "import sys\nfrom atavism.agis import *\nfrom atavism.agis.objects import *\nfrom atavism.agis.core import *\nfrom atavism.agis.events import *\nfrom atavism.agis.util import *\nfrom atavism.agis.plugins import *\nfrom atavism.msgsys import *\nfrom atavism.server.plugins import *\nfrom atavism.server.math import *\nfrom atavism.server.events import *\nfrom atavism.server.objects import *\nfrom atavism.server.worldmgr import *\nfrom atavism.server.engine import *";
/*      */     protected static ScriptManager mbeanScriptManager;
/*      */ 
/* 1570 */     public String getVersion() { return "2.5.0";
/*      */     }
/*      */ 
/*      */     public String getFullVersion()
/*      */     {
/* 1575 */       return ServerVersion.getVersionString();
/*      */     }
/*      */ 
/*      */     public String getBuildNumber()
/*      */     {
/* 1580 */       return ServerVersion.getBuildNumber();
/*      */     }
/*      */ 
/*      */     public String getBuildDate()
/*      */     {
/* 1585 */       return ServerVersion.getBuildDate();
/*      */     }
/*      */ 
/*      */     public String getBuildString()
/*      */     {
/* 1590 */       return ServerVersion.getBuildString();
/*      */     }
/*      */ 
/*      */     public String getAgentName() {
/* 1594 */       return Engine.agent.getName();
/*      */     }
/*      */ 
/*      */     public String getWorldName() {
/* 1598 */       return Engine.getWorldName();
/*      */     }
/*      */ 
/*      */     public String getPlugins() {
/* 1602 */       String plugins = "";
/* 1603 */       for (String name : Engine.pluginMap.keySet()) {
/* 1604 */         if (!plugins.equals(""))
/* 1605 */           plugins = plugins + ",";
/* 1606 */         plugins = plugins + name;
/*      */       }
/* 1608 */       return plugins;
/*      */     }
/*      */ 
/*      */     public int getLogLevel()
/*      */     {
/* 1613 */       return Log.getLogLevel();
/*      */     }
/*      */ 
/*      */     public String getLogLevelString()
/*      */     {
/* 1618 */       int level = Log.getLogLevel();
/* 1619 */       if (level == 0) return "TRACE";
/* 1620 */       if (level == 1) return "DEBUG";
/* 1621 */       if (level == 2) return "INFO";
/* 1622 */       if (level == 3) return "WARN";
/* 1623 */       if (level == 4) return "ERROR";
/* 1624 */       return "unknown";
/*      */     }
/*      */ 
/*      */     public void setLogLevel(int level)
/*      */     {
/* 1629 */       Log.setLogLevel(level);
/*      */     }
/*      */ 
/*      */     public long getPersistentObjectSaveIntervalMS()
/*      */     {
/* 1637 */       return Engine.getInstance().PersistentObjectSaveIntervalMS;
/*      */     }
/*      */ 
/*      */     public void setPersistentObjectSaveIntervalMS(long interval)
/*      */     {
/* 1645 */       Engine.getInstance().PersistentObjectSaveIntervalMS = interval;
/*      */     }
/*      */ 
/*      */     public boolean getCPUTimeMonitor()
/*      */     {
/* 1651 */       return Engine.runCPUTimeThread;
/*      */     }
/*      */ 
/*      */     public int getCPUTimeMonitorIntervalMS()
/*      */     {
/* 1657 */       return Engine.cpuTimeSamplingInterval;
/*      */     }
/*      */ 
/*      */     public void setCPUTimeMonitorIntervalMS(int milliSeconds)
/*      */     {
/* 1663 */       if (milliSeconds > 0)
/* 1664 */         Engine.access$102(milliSeconds);
/*      */     }
/*      */ 
/*      */     public int getEntities()
/*      */     {
/* 1669 */       return EntityManager.getEntityCount();
/*      */     }
/*      */ 
/*      */     public String runPythonScript(String script)
/*      */     {
/* 1690 */       initScriptManager();
/*      */       try {
/* 1692 */         ScriptManager.ScriptOutput output = mbeanScriptManager.runPYScript(script);
/* 1693 */         if ((output.stderr == null) || (output.stderr.equals(""))) {
/* 1694 */           return output.stdout;
/*      */         }
/* 1696 */         return "OUT: " + output.stdout + "\nERR: " + output.stderr;
/*      */       } catch (PyException e) {
/*      */       }
/* 1699 */       return e.toString();
/*      */     }
/*      */ 
/*      */     public String evalPythonScript(String script)
/*      */     {
/* 1705 */       initScriptManager();
/*      */       try {
/* 1707 */         return mbeanScriptManager.evalPYScriptAsString(script);
/*      */       } catch (PyException e) {
/*      */       }
/* 1710 */       return e.toString();
/*      */     }
/*      */ 
/*      */     protected static void initScriptManager()
/*      */     {
/* 1716 */       if (mbeanScriptManager != null) {
/* 1717 */         return;
/*      */       }
/* 1719 */       mbeanScriptManager = new ScriptManager();
/* 1720 */       mbeanScriptManager.initLocal();
/*      */       try {
/* 1722 */         mbeanScriptManager.runPYScript(defaultPythonImports);
/*      */       }
/*      */       catch (PyException e) {
/* 1725 */         Log.exception("EngineJMX.initScriptManager", e);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface EngineJMXMBean
/*      */   {
/*      */     public abstract String getVersion();
/*      */ 
/*      */     public abstract String getFullVersion();
/*      */ 
/*      */     public abstract String getBuildNumber();
/*      */ 
/*      */     public abstract String getBuildDate();
/*      */ 
/*      */     public abstract String getBuildString();
/*      */ 
/*      */     public abstract String getAgentName();
/*      */ 
/*      */     public abstract String getWorldName();
/*      */ 
/*      */     public abstract String getPlugins();
/*      */ 
/*      */     public abstract int getLogLevel();
/*      */ 
/*      */     public abstract String getLogLevelString();
/*      */ 
/*      */     public abstract void setLogLevel(int paramInt);
/*      */ 
/*      */     public abstract long getPersistentObjectSaveIntervalMS();
/*      */ 
/*      */     public abstract void setPersistentObjectSaveIntervalMS(long paramLong);
/*      */ 
/*      */     public abstract boolean getCPUTimeMonitor();
/*      */ 
/*      */     public abstract int getCPUTimeMonitorIntervalMS();
/*      */ 
/*      */     public abstract void setCPUTimeMonitorIntervalMS(int paramInt);
/*      */ 
/*      */     public abstract int getEntities();
/*      */ 
/*      */     public abstract String runPythonScript(String paramString);
/*      */ 
/*      */     public abstract String evalPythonScript(String paramString);
/*      */   }
/*      */ 
/*      */   static class StatusReportingThread
/*      */     implements Runnable
/*      */   {
/*      */     float lastCPUTime;
/*      */     long lastTime;
/*      */ 
/*      */     public void run()
/*      */     {
/* 1338 */       this.lastCPUTime = ((float)(Engine.getProcessCpuTime(Engine.cpuMethod, Engine.mxbean) / 1000000L) / 1000.0F);
/* 1339 */       this.lastTime = System.currentTimeMillis();
/*      */       while (true) {
/*      */         try {
/* 1342 */           Thread.sleep(Engine.statusReportingInterval);
/*      */         }
/*      */         catch (InterruptedException e) {
/* 1345 */           Engine.log.exception("StatusReportingThread.run exception", e);
/*      */         }
/*      */         try {
/* 1348 */           updateStatus();
/*      */         }
/*      */         catch (Exception e) {
/* 1351 */           Engine.log.exception("StatusReportingThread.run", e);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void updateStatus()
/*      */     {
/* 1359 */       if (Log.loggingDebug)
/* 1360 */         Log.debug("Engine.StatusReportingThread.run: count of status reporting plugins is " + Engine.statusReportingPlugins.size());
/* 1361 */       long currentTime = System.currentTimeMillis();
/* 1362 */       float currentCPUTime = (float)(Engine.getProcessCpuTime(Engine.cpuMethod, Engine.mxbean) / 1000000L) / 1000.0F;
/* 1363 */       float diff = currentCPUTime - this.lastCPUTime;
/* 1364 */       long msDiff = (currentTime - this.lastTime) * Engine.processorCount;
/* 1365 */       float secsDiff = (float)msDiff / 1000.0F;
/* 1366 */       int percentDiff = (int)(diff * 100.0F / secsDiff);
/* 1367 */       if (Log.loggingDebug) {
/* 1368 */         Log.debug("Engine.StatusReportingThread: " + Engine.statusReportingPlugins.size() + " plugins, " + percentDiff + "% CPU");
/*      */       }
/*      */ 
/* 1371 */       for (EnginePlugin plugin : Engine.statusReportingPlugins) {
/* 1372 */         plugin.setPercentCPULoad(percentDiff);
/* 1373 */         Engine.getDatabase().updatePluginStatus(plugin, System.currentTimeMillis() + Engine.statusReportingInterval);
/*      */       }
/* 1375 */       this.lastTime = currentTime;
/* 1376 */       this.lastCPUTime = currentCPUTime;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class CPUTimeThread
/*      */     implements Runnable
/*      */   {
/*      */     int logLevel;
/*      */ 
/*      */     public CPUTimeThread(int logLevel)
/*      */     {
/* 1261 */       this.logLevel = logLevel;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1271 */       float lastCPUTime = (float)(Engine.getProcessCpuTime(Engine.cpuMethod, Engine.mxbean) / 1000000L) / 1000.0F;
/* 1272 */       long lastTime = System.currentTimeMillis();
/* 1273 */       DecimalFormat timeFormatter = new DecimalFormat("####.000");
/*      */       while (true) {
/*      */         try {
/* 1276 */           Thread.sleep(Engine.cpuTimeSamplingInterval);
/*      */         }
/*      */         catch (Exception e) {
/* 1279 */           Engine.log.exception("CPUTimeThread.run exception", e);
/*      */         }
/* 1281 */         long currentTime = System.currentTimeMillis();
/* 1282 */         float currentCPUTime = (float)(Engine.getProcessCpuTime(Engine.cpuMethod, Engine.mxbean) / 1000000L) / 1000.0F;
/* 1283 */         float diff = currentCPUTime - lastCPUTime;
/* 1284 */         long msDiff = (currentTime - lastTime) * Engine.processorCount;
/* 1285 */         float secsDiff = (float)msDiff / 1000.0F;
/* 1286 */         int percentDiff = (int)(diff * 100.0F / secsDiff);
/* 1287 */         if (Log.getLogLevel() <= this.logLevel) {
/* 1288 */           Log.logAtLevel(this.logLevel, "Process CPU time: " + timeFormatter.format(currentCPUTime) + ", CPU time since last " + timeFormatter.format(diff) + ", " + percentDiff + "% CPU");
/*      */         }
/*      */ 
/* 1291 */         lastTime = currentTime;
/* 1292 */         lastCPUTime = currentCPUTime;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class QueuedMessage
/*      */     implements Runnable
/*      */   {
/*      */     Message message;
/*      */     int flags;
/*      */     MessageCallback callback;
/*      */ 
/*      */     QueuedMessage(Message message, int flags, MessageCallback callback)
/*      */     {
/* 1092 */       this.message = message;
/* 1093 */       this.flags = flags;
/* 1094 */       this.callback = callback;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/* 1103 */         this.callback.handleMessage(this.message, this.flags);
/*      */       }
/*      */       catch (Exception ex) {
/* 1106 */         Log.exception("Engine message handler: " + this.message.getMsgType(), ex);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Engine
 * JD-Core Version:    0.6.0
 */