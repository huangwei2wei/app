/*    */ package atavism.server.engine;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class PropertyMatcher
/*    */   implements Matcher
/*    */ {
/*    */   private Map queryProps;
/*    */ 
/*    */   public PropertyMatcher(SearchClause query)
/*    */   {
/* 11 */     this.queryProps = ((PropertySearch)query).getProperties();
/*    */   }
/*    */ 
/*    */   public boolean match(Object object)
/*    */   {
/* 16 */     Map target = (Map)object;
/* 17 */     if (target == null)
/*    */     {
/* 19 */       return this.queryProps.size() == 0;
/*    */     }
/*    */ 
/* 24 */     for (Map.Entry queryProp : this.queryProps.entrySet()) {
/* 25 */       Object queryKey = queryProp.getKey();
/* 26 */       Object queryValue = queryProp.getValue();
/* 27 */       Object targetValue = target.get(queryKey);
/* 28 */       if ((targetValue == null) && (
/* 29 */         (!target.containsKey(queryKey)) || (queryValue != null))) {
/* 30 */         return false;
/*    */       }
/* 32 */       if (queryValue == null)
/* 33 */         return false;
/* 34 */       if (!targetValue.equals(queryValue))
/* 35 */         return false;
/*    */     }
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   public static class Factory
/*    */     implements MatcherFactory
/*    */   {
/*    */     public Matcher createMatcher(SearchClause query)
/*    */     {
/* 48 */       return new PropertyMatcher(query);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.PropertyMatcher
 * JD-Core Version:    0.6.0
 */