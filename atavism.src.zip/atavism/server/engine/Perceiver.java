/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class Perceiver<ElementType extends QuadTreeElement<ElementType>>
/*     */   implements Serializable
/*     */ {
/*  39 */   transient Set<PerceiverCallback<ElementType>> callbacks = null;
/*     */ 
/* 112 */   private transient Set<QuadTreeNode<ElementType>> nodes = null;
/*     */ 
/* 122 */   private PerceiverFilter<ElementType> filter = null;
/*     */ 
/* 124 */   protected static final Logger log = new Logger("Perceiver");
/*     */ 
/*     */   public Perceiver()
/*     */   {
/*  16 */     setupTransient();
/*     */   }
/*     */ 
/*     */   void setupTransient() {
/*  20 */     this.nodes = new HashSet();
/*  21 */     this.callbacks = new HashSet();
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  27 */     in.defaultReadObject();
/*  28 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public void registerCallback(PerceiverCallback<ElementType> cb) {
/*  32 */     this.callbacks.add(cb);
/*     */   }
/*     */ 
/*     */   public void unregisterCallback(PerceiverCallback<ElementType> cb) {
/*  36 */     this.callbacks.remove(cb);
/*     */   }
/*     */ 
/*     */   public abstract boolean overlaps(Geometry paramGeometry);
/*     */ 
/*     */   public abstract boolean contains(Geometry paramGeometry);
/*     */ 
/*     */   public boolean shouldNotifyNewElement(ElementType elem)
/*     */   {
/*  48 */     if (this.filter == null) {
/*  49 */       if (Log.loggingDebug) {
/*  50 */         log.debug("shouldNotifyNewElement: filter is null");
/*     */       }
/*  52 */       return false;
/*     */     }
/*     */ 
/*  57 */     return this.filter.matches(this, elem);
/*     */   }
/*     */ 
/*     */   public boolean shouldFreeElement(ElementType elem)
/*     */   {
/*  66 */     return (this.filter == null) || (this.filter.matches(this, elem));
/*     */   }
/*     */ 
/*     */   public Integer processNewsAndFrees(PerceiverNewsAndFrees<ElementType> newsAndFrees, OID mobilePerceiverOid) {
/*  70 */     Integer perceiverOidCount = null;
/*  71 */     for (PerceiverCallback cb : this.callbacks) {
/*  72 */       Integer count = cb.processNewsAndFrees(this, newsAndFrees, mobilePerceiverOid);
/*  73 */       if (count != null)
/*  74 */         perceiverOidCount = count;
/*     */     }
/*  76 */     return perceiverOidCount;
/*     */   }
/*     */ 
/*     */   public boolean shouldUpdateBasedOnLoc(Point loc)
/*     */   {
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   public void addQuadTreeNode(QuadTreeNode<ElementType> node) {
/*  87 */     this.nodes.add(node);
/*     */   }
/*     */ 
/*     */   public void removeQuadTreeNode(QuadTreeNode<ElementType> node) {
/*  91 */     if (!this.nodes.remove(node))
/*  92 */       if ((this instanceof MobilePerceiver)) {
/*  93 */         MobilePerceiver p = (MobilePerceiver)this;
/*     */ 
/*  95 */         log.error("removeQuadTreeNode on " + p.getElement().getQuadTreeObject() + ": node " + node + " not in current perceiver list");
/*     */       }
/*     */       else
/*     */       {
/*  99 */         log.error("removeQuadTreeNode: node " + node + " not in current perceiver list");
/*     */       }
/*     */   }
/*     */ 
/*     */   public Set<QuadTreeNode<ElementType>> getQuadTreeNodes()
/*     */   {
/* 109 */     return new HashSet(this.nodes);
/*     */   }
/*     */ 
/*     */   public void setFilter(PerceiverFilter<ElementType> filter)
/*     */   {
/* 115 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */   public PerceiverFilter<ElementType> getFilter() {
/* 119 */     return this.filter;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Perceiver
 * JD-Core Version:    0.6.0
 */