package atavism.server.engine;

import atavism.server.math.AOVector;
import atavism.server.math.Point;
import atavism.server.math.Quaternion;
import atavism.server.pathing.PathInterpolator;

public abstract interface BasicInterpolatable extends Interpolatable
{
  public abstract AOVector getDir();

  public abstract void setDir(AOVector paramAOVector);

  public abstract Point getRawLoc();

  public abstract void setRawLoc(Point paramPoint);

  public abstract Point getInterpLoc();

  public abstract void setInterpLoc(Point paramPoint);

  public abstract long getLastInterp();

  public abstract void setLastInterp(long paramLong);

  public abstract Quaternion getOrientation();

  public abstract void setOrientation(Quaternion paramQuaternion);

  public abstract PathInterpolator getPathInterpolator();

  public abstract void setPathInterpolatorValues(long paramLong, AOVector paramAOVector, Point paramPoint, Quaternion paramQuaternion);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.BasicInterpolatable
 * JD-Core Version:    0.6.0
 */