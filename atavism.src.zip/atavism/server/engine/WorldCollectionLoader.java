package atavism.server.engine;

import atavism.server.objects.Instance;

public abstract interface WorldCollectionLoader
{
  public abstract boolean load(Instance paramInstance);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WorldCollectionLoader
 * JD-Core Version:    0.6.0
 */