package atavism.server.engine;

public abstract interface Interpolator<T extends Interpolatable>
{
  public abstract void register(T paramT);

  public abstract void unregister(T paramT);

  public abstract void interpolate(T paramT);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Interpolator
 * JD-Core Version:    0.6.0
 */