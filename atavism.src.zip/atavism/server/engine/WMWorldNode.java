/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class WMWorldNode extends InterpolatedWorldNode
/*     */   implements QuadTreeElement<WMWorldNode>
/*     */ {
/*  54 */   private MobilePerceiver<WMWorldNode> perceiver = null;
/*     */ 
/*  71 */   private transient QuadTreeNode<WMWorldNode> node = null;
/*     */ 
/*  82 */   private transient boolean local = false;
/*     */ 
/* 112 */   private int perceptionRadius = 0;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public WMWorldNode()
/*     */   {
/*     */   }
/*     */ 
/*     */   public WMWorldNode(int perceptionRadius)
/*     */   {
/*  19 */     this.perceptionRadius = perceptionRadius;
/*     */   }
/*     */ 
/*     */   public WMWorldNode(BasicWorldNode node) {
/*  23 */     super(node);
/*     */   }
/*     */ 
/*     */   public void setInterpLoc(Point p) {
/*  27 */     Lock myTreeLock = this.treeLock;
/*  28 */     if (myTreeLock != null) {
/*  29 */       myTreeLock.lock();
/*     */     }
/*  31 */     this.lock.lock();
/*     */     try {
/*  33 */       super.setInterpLoc(p);
/*  34 */       if (isSpawned())
/*  35 */         this.node.getTree().updateElement(this, (Point)p.clone());
/*     */     }
/*     */     finally {
/*  38 */       this.lock.unlock();
/*  39 */       if (myTreeLock != null)
/*  40 */         myTreeLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public MobilePerceiver<WMWorldNode> getPerceiver()
/*     */   {
/*  47 */     return this.perceiver;
/*     */   }
/*     */ 
/*     */   public void setPerceiver(MobilePerceiver<WMWorldNode> p) {
/*  51 */     this.perceiver = p;
/*     */   }
/*     */ 
/*     */   public QuadTreeNode<WMWorldNode> getQuadNode()
/*     */   {
/*  57 */     return this.node;
/*     */   }
/*     */ 
/*     */   public void setQuadNode(QuadTreeNode<WMWorldNode> node) {
/*  61 */     this.lock.lock();
/*     */     try {
/*  63 */       this.node = node;
/*  64 */       this.treeLock = (node == null ? null : node.getTree().getLock());
/*     */     }
/*     */     finally {
/*  67 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isLocal()
/*     */   {
/*  74 */     return this.local;
/*     */   }
/*     */ 
/*     */   public void isLocal(boolean local)
/*     */   {
/*  79 */     this.local = local;
/*     */   }
/*     */ 
/*     */   public boolean isSpawned()
/*     */   {
/*  85 */     return this.node != null;
/*     */   }
/*     */ 
/*     */   public int getPerceptionRadius() {
/*  89 */     return this.perceptionRadius;
/*     */   }
/*     */   public void setPerceptionRadius(int radius) {
/*  92 */     this.perceptionRadius = radius;
/*     */   }
/*     */ 
/*     */   public int getObjectRadius() {
/*  96 */     return 0;
/*     */   }
/*     */ 
/*     */   public Object getQuadTreeObject() {
/* 100 */     return getObject();
/*     */   }
/*     */ 
/*     */   public void setPathInterpolatorValues(long time, AOVector newDir, Point newLoc, Quaternion orientation)
/*     */   {
/* 107 */     if (!isSpawned())
/* 108 */       return;
/* 109 */     super.setPathInterpolatorValues(time, newDir, newLoc, orientation);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WMWorldNode
 * JD-Core Version:    0.6.0
 */