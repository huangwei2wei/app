/*     */ package atavism.server.engine;
/*     */ 
/*     */ class JukeboxWebEngineThread
/*     */   implements Runnable
/*     */ {
/*     */   public void run()
/*     */   {
/* 249 */     String[] args = new String[3];
/* 250 */     args[0] = "-i";
/*     */ 
/* 253 */     args[1] = System.getProperty("atavism.jukebox.arg1");
/* 254 */     args[2] = System.getProperty("atavism.jukebox.arg2");
/* 255 */     Engine.main(args);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.JukeboxWebEngineThread
 * JD-Core Version:    0.6.0
 */