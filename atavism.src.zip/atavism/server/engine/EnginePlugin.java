/*      */ package atavism.server.engine;
/*      */ 
/*      */ import atavism.msgsys.ExceptionResponseMessage;
/*      */ import atavism.msgsys.Filter;
/*      */ import atavism.msgsys.Message;
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.msgsys.MessageAgent.DomainClient;
/*      */ import atavism.msgsys.MessageCallback;
/*      */ import atavism.msgsys.MessageType;
/*      */ import atavism.msgsys.MessageTypeFilter;
/*      */ import atavism.server.messages.INamespaceFilter;
/*      */ import atavism.server.messages.INamespaceMessage;
/*      */ import atavism.server.messages.NamespaceFilter;
/*      */ import atavism.server.messages.OIDNamespaceMessage;
/*      */ import atavism.server.messages.PropertyMessage;
/*      */ import atavism.server.objects.Entity;
/*      */ import atavism.server.objects.EntityManager;
/*      */ import atavism.server.objects.Template;
/*      */ import atavism.server.plugins.ObjectManagerClient;
/*      */ import atavism.server.plugins.ObjectManagerClient.DeleteSubObjectMessage;
/*      */ import atavism.server.plugins.ObjectManagerClient.GenerateSubObjectMessage;
/*      */ import atavism.server.plugins.ObjectManagerClient.LoadSubObjectMessage;
/*      */ import atavism.server.plugins.ObjectManagerClient.SetPersistenceMessage;
/*      */ import atavism.server.plugins.ObjectManagerClient.SubObjectDepsReadyMessage;
/*      */ import atavism.server.plugins.ObjectManagerClient.UnloadSubObjectMessage;
/*      */ import atavism.server.util.AOMeter;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.ObjectLockManager;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import javax.management.JMException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.ObjectName;
/*      */ 
/*      */ public class EnginePlugin
/*      */   implements MessageCallback, StatusMapCallback
/*      */ {
/*  185 */   private LinkedList<PluginActivateHook> activateHookList = new LinkedList();
/*      */ 
/*  348 */   String pluginState = "Unknown";
/*      */ 
/*  360 */   private Map<String, String> pluginStateMap = Collections.synchronizedMap(new HashMap());
/*      */ 
/*  897 */   Collection<Namespace> localNamespaces = null;
/*      */ 
/*  969 */   AOMeter engPluginMeter = new AOMeter("EnginePluginOnMessageMeter");
/*      */ 
/*  997 */   private Long subObjectDepReadySub = null;
/*      */ 
/* 1002 */   private Lock depLock = LockFactory.makeLock("subObjectDepReadySub");
/*      */ 
/* 1010 */   Map<OID, Map<Namespace, Hook>> depsOutstanding = Collections.synchronizedMap(new HashMap());
/*      */ 
/* 2504 */   private MessageCallback messageHandler = new DebugPoolMessageHandler();
/* 2505 */   private HookManager hookManager = new HookManager();
/* 2506 */   private Map<Namespace, LoadHook> loadHookMap = Collections.synchronizedMap(new HashMap());
/*      */ 
/* 2508 */   private Map<Namespace, UnloadHook> unloadHookMap = Collections.synchronizedMap(new HashMap());
/*      */ 
/* 2510 */   private Map<Namespace, DeleteHook> deleteHookMap = Collections.synchronizedMap(new HashMap());
/*      */ 
/* 2513 */   private String name = null;
/*      */   private String pluginType;
/*      */   private String pluginInfo;
/* 2516 */   private int percentCPULoad = 0;
/* 2517 */   private boolean pluginAvailable = false;
/*      */ 
/* 2519 */   protected Lock lock = LockFactory.makeLock("EnginePluginLock");
/* 2520 */   private ObjectLockManager objLockManager = new ObjectLockManager();
/*      */ 
/* 2522 */   public static MessageType MSG_TYPE_PLUGIN_STATE = MessageType.intern("ao.PLUGIN_STATE");
/*      */ 
/* 2524 */   public static MessageType MSG_TYPE_GET_PROPERTY = MessageType.intern("ao.GET_PROPERTY");
/*      */ 
/* 2526 */   public static MessageType MSG_TYPE_GET_PROPERTY_NAMES = MessageType.intern("ao.GET_PROPERTY_NAMES");
/*      */ 
/* 2528 */   public static MessageType MSG_TYPE_SET_PROPERTY = MessageType.intern("ao.SET_PROPERTY");
/*      */ 
/* 2530 */   public static MessageType MSG_TYPE_SET_PROPERTY_NONBLOCK = MessageType.intern("ao.SET_PROPERTY_NONBLOCK");
/*      */ 
/* 2533 */   protected static Lock dumpAllThreadSubscriptionLock = LockFactory.makeLock("DumpAllThreadsLock");
/*      */ 
/* 2536 */   protected static Long dumpAllThreadSubscription = null;
/* 2537 */   protected static Long pluginStateSubscription = null;
/* 2538 */   protected static Long subObjectSubscription = null;
/* 2539 */   protected static Long selectionSubscription = null;
/* 2540 */   protected static INamespaceFilter selectionFilter = null;
/* 2541 */   protected static Long saveSubObjectSubscription = null;
/* 2542 */   protected static Long loadSubObjectSubscription = null;
/* 2543 */   protected static Long unloadSubObjectSubscription = null;
/* 2544 */   protected static Long deleteSubObjectSubscription = null;
/* 2545 */   protected static Long setSubObjectPersistenceSubscription = null;
/* 2546 */   protected static Long propertySubscription = null;
/*      */ 
/* 2552 */   public static MessageType MSG_TYPE_DUMP_ALL_THREAD_STACKS = MessageType.intern("ao.DUMP_ALL_THREAD_STACKS");
/*      */ 
/* 2558 */   public static final MessageType MSG_TYPE_TRANSFER_OBJECT = MessageType.intern("ao.TRANSFER_OBJECT");
/*      */ 
/*      */   public EnginePlugin()
/*      */   {
/*      */   }
/*      */ 
/*      */   public EnginePlugin(String name)
/*      */   {
/*   59 */     setName(name);
/*      */   }
/*      */ 
/*      */   public EnginePlugin(String name, PluginActivateHook activateHook)
/*      */   {
/*   72 */     this(name);
/*      */     try {
/*   74 */       registerActivateHook(activateHook);
/*      */     }
/*      */     catch (AORuntimeException e) {
/*   77 */       throw new RuntimeException("registerActivateHook failed", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getName()
/*      */   {
/*   90 */     return this.name;
/*      */   }
/*      */ 
/*      */   protected void setName(String name)
/*      */   {
/*  101 */     this.name = name;
/*      */   }
/*      */ 
/*      */   public void setPluginType(String pluginType)
/*      */   {
/*  109 */     this.pluginType = pluginType;
/*      */   }
/*      */ 
/*      */   public String getPluginType()
/*      */   {
/*  117 */     return this.pluginType;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getStatusMap()
/*      */   {
/*  123 */     return null;
/*      */   }
/*      */ 
/*      */   public String getPluginStatus()
/*      */   {
/*  131 */     return Engine.makeStringFromMap(getStatusMap());
/*      */   }
/*      */ 
/*      */   public void setPluginInfo(String pluginInfo)
/*      */   {
/*  139 */     this.pluginInfo = pluginInfo;
/*      */   }
/*      */ 
/*      */   public String getPluginInfo()
/*      */   {
/*  147 */     return this.pluginInfo;
/*      */   }
/*      */ 
/*      */   public void setPercentCPULoad(int percentCPULoad)
/*      */   {
/*  155 */     this.percentCPULoad = percentCPULoad;
/*      */   }
/*      */ 
/*      */   public int getPercentCPULoad()
/*      */   {
/*  163 */     return this.percentCPULoad;
/*      */   }
/*      */ 
/*      */   public void registerActivateHook(PluginActivateHook hook)
/*      */   {
/*  176 */     this.lock.lock();
/*      */     try {
/*  178 */       this.activateHookList.add(hook);
/*      */     }
/*      */     finally {
/*  181 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void activate()
/*      */   {
/*  198 */     if (Log.loggingDebug) {
/*  199 */       Log.debug("EnginePlugin.activate: plugin=" + getName());
/*      */     }
/*  201 */     this.pluginState = "Starting";
/*      */ 
/*  206 */     dumpAllThreadSubscriptionLock.lock();
/*      */     try {
/*  208 */       if (dumpAllThreadSubscription == null) {
/*  209 */         MessageTypeFilter filter = new MessageTypeFilter();
/*  210 */         filter.addType(MSG_TYPE_DUMP_ALL_THREAD_STACKS);
/*      */ 
/*  212 */         dumpAllThreadSubscription = Long.valueOf(Engine.getAgent().createSubscription(filter, this));
/*  213 */         if (Log.loggingDebug) {
/*  214 */           Log.debug("EnginePlugin.activate: plugin=" + getName() + ", created createSubscription for dumpAllStacks");
/*      */         }
/*  216 */         getHookManager().addHook(MSG_TYPE_DUMP_ALL_THREAD_STACKS, new DumpAllStacksMessageHook());
/*      */ 
/*  218 */         if (Log.loggingDebug)
/*  219 */           Log.debug("EnginePlugin.activate: registered DumpAllStacksMessageHook");
/*      */       }
/*      */     }
/*      */     finally {
/*  223 */       dumpAllThreadSubscriptionLock.unlock();
/*      */     }
/*      */ 
/*  226 */     Engine.getAgent().getDomainClient().awaitPluginDependents(getPluginType(), getName());
/*      */ 
/*  231 */     this.pluginAvailable = true;
/*      */ 
/*  236 */     onActivate();
/*  237 */     if (Log.loggingDebug) {
/*  238 */       Log.debug("EnginePlugin.activate: plugin=" + getName() + ", onActivate complete, calling activateHooks");
/*      */     }
/*  240 */     createManagementObject();
/*      */ 
/*  242 */     this.lock.lock();
/*      */     try {
/*  244 */       for (PluginActivateHook activateHook : this.activateHookList)
/*  245 */         activateHook.activate();
/*      */     }
/*      */     finally
/*      */     {
/*  249 */       this.lock.unlock();
/*      */     }
/*  251 */     if (Log.loggingDebug) {
/*  252 */       Log.debug("EnginePlugin.activate: plugin=" + getName() + ", activate hooks called");
/*      */     }
/*  254 */     if (this.pluginAvailable)
/*  255 */       Engine.getAgent().getDomainClient().pluginAvailable(getPluginType(), getName());
/*      */   }
/*      */ 
/*      */   public boolean getPluginAvailable()
/*      */   {
/*  262 */     return this.pluginAvailable;
/*      */   }
/*      */ 
/*      */   public void setPluginAvailable(boolean avail)
/*      */   {
/*  267 */     if ((!this.pluginAvailable) && (avail)) {
/*  268 */       Engine.getAgent().getDomainClient().pluginAvailable(getPluginType(), getName());
/*      */     }
/*  270 */     this.pluginAvailable = avail;
/*      */   }
/*      */ 
/*      */   public void onActivate()
/*      */   {
/*      */   }
/*      */ 
/*      */   public String getPluginState(String pluginName)
/*      */   {
/*  356 */     return (String)this.pluginStateMap.get(pluginName);
/*      */   }
/*      */ 
/*      */   protected void setMessageHandler(MessageCallback handler)
/*      */   {
/*  364 */     this.messageHandler = handler;
/*      */   }
/*      */ 
/*      */   protected MessageCallback getMessageHandler()
/*      */   {
/*  369 */     return this.messageHandler;
/*      */   }
/*      */ 
/*      */   public void createSubscription(Hook hook, MessageType msgType, int flags)
/*      */   {
/*  381 */     getHookManager().addHook(msgType, hook);
/*      */ 
/*  384 */     MessageTypeFilter filter = new MessageTypeFilter(msgType);
/*      */ 
/*  387 */     Engine.getAgent().createSubscription(filter, this, flags);
/*      */   }
/*      */ 
/*      */   public void handleMessage(Message msg, int flags)
/*      */   {
/*  400 */     if (this.messageHandler != null)
/*  401 */       this.messageHandler.handleMessage(msg, flags);
/*      */     else
/*  403 */       handleMessageImpl(msg, flags);
/*      */   }
/*      */ 
/*      */   protected void handleMessageImpl(Message msg, int flags)
/*      */   {
/*  415 */     MessageType msgType = msg.getMsgType();
/*  416 */     List hooks = this.hookManager.getHooks(msgType);
/*      */ 
/*  418 */     if (Log.loggingDebug) {
/*  419 */       Log.debug("EnginePlugin.handleMessage: got msg id " + msg.getMsgId() + ", matching " + hooks.size() + " hooks for msgtype " + msgType);
/*      */     }
/*      */ 
/*  422 */     long timer = 0L;
/*  423 */     if (Log.loggingDebug)
/*  424 */       timer = System.currentTimeMillis();
/*  425 */     for (Hook hook : hooks) {
/*  426 */       if (!hook.processMessage(msg, 0)) {
/*      */         break;
/*      */       }
/*      */     }
/*  430 */     if (Log.loggingDebug) {
/*  431 */       long elapsed = System.currentTimeMillis() - timer;
/*  432 */       Log.debug("EnginePlugin.handleMessage: processed msg " + msg.getMsgId() + ", type=" + msgType + ", time in ms=" + elapsed);
/*  433 */       this.engPluginMeter.add(Long.valueOf(elapsed));
/*      */     }
/*      */   }
/*      */ 
/*      */   public Collection<Namespace> getPluginNamespaces()
/*      */   {
/*  589 */     this.lock.lock();
/*      */     try {
/*  591 */       ArrayList localArrayList = new ArrayList(this.localNamespaces);
/*      */       return localArrayList; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void registerPluginNamespace(Namespace namespace, GenerateSubObjectHook genSubObjHook)
/*      */   {
/*  609 */     List namespaces = new LinkedList();
/*  610 */     namespaces.add(namespace);
/*      */ 
/*  612 */     registerPluginNamespaces(namespaces, genSubObjHook, null, null, null, null, null, null);
/*      */   }
/*      */ 
/*      */   public void registerPluginNamespaces(Collection<Namespace> namespaces, GenerateSubObjectHook genSubObjHook)
/*      */   {
/*  629 */     registerPluginNamespaces(namespaces, genSubObjHook, null, null, null, null, null, null);
/*      */   }
/*      */ 
/*      */   public void registerPluginNamespaces(Collection<Namespace> namespaces, GenerateSubObjectHook genSubObjHook, INamespaceFilter selectionFilter, INamespaceFilter subObjectFilter)
/*      */   {
/*  658 */     registerPluginNamespaces(namespaces, genSubObjHook, null, null, null, null, selectionFilter, subObjectFilter);
/*      */   }
/*      */ 
/*      */   public void registerPluginNamespaces(Collection<Namespace> namespaces, GenerateSubObjectHook genSubObjHook, Hook loadSubObjHook, Hook saveSubObjHook, Hook unloadSubObjHook, Hook deleteSubObjHook, INamespaceFilter selectionFilter, INamespaceFilter subObjectFilter)
/*      */   {
/*  707 */     if (Log.loggingDebug) {
/*  708 */       String s = "";
/*  709 */       for (Namespace namespace : namespaces) {
/*  710 */         if (s != "")
/*  711 */           s = s + ",";
/*  712 */         s = s + namespace;
/*      */       }
/*  714 */       Log.debug("EnginePlugin.registerPluginNamespaces: namespaces " + s);
/*      */     }
/*  716 */     this.lock.lock();
/*      */     try {
/*  718 */       this.localNamespaces = new ArrayList(namespaces);
/*      */ 
/*  720 */       if (saveSubObjHook == null) {
/*  721 */         saveSubObjHook = new SaveSubObjHook(this);
/*      */       }
/*  723 */       if (loadSubObjHook == null) {
/*  724 */         loadSubObjHook = new LoadSubObjHook(this);
/*      */       }
/*  726 */       if (unloadSubObjHook == null) {
/*  727 */         unloadSubObjHook = new UnloadSubObjHook(this);
/*      */       }
/*  729 */       if (deleteSubObjHook == null) {
/*  730 */         deleteSubObjHook = new DeleteSubObjHook(this);
/*      */       }
/*      */ 
/*  733 */       if (selectionFilter == null) {
/*  734 */         selectionFilter = new NamespaceFilter();
/*      */       }
/*  736 */       if (subObjectFilter == null) {
/*  737 */         subObjectFilter = new NamespaceFilter();
/*      */       }
/*      */ 
/*  740 */       getHookManager().addHook(ObjectManagerClient.MSG_TYPE_GENERATE_SUB_OBJECT, genSubObjHook);
/*  741 */       getHookManager().addHook(ObjectManagerClient.MSG_TYPE_SET_SUBPERSISTENCE, new SubPersistenceHook());
/*  742 */       getHookManager().addHook(ObjectManagerClient.MSG_TYPE_SAVE_SUBOBJECT, saveSubObjHook);
/*  743 */       getHookManager().addHook(ObjectManagerClient.MSG_TYPE_LOAD_SUBOBJECT, loadSubObjHook);
/*  744 */       getHookManager().addHook(ObjectManagerClient.MSG_TYPE_UNLOAD_SUBOBJECT, unloadSubObjHook);
/*  745 */       getHookManager().addHook(ObjectManagerClient.MSG_TYPE_DELETE_SUBOBJECT, deleteSubObjHook);
/*  746 */       getHookManager().addHook(MSG_TYPE_GET_PROPERTY, new GetPropertyHook());
/*  747 */       getHookManager().addHook(MSG_TYPE_GET_PROPERTY_NAMES, new GetPropertyNamesHook());
/*  748 */       getHookManager().addHook(MSG_TYPE_SET_PROPERTY, new SetPropertyHook());
/*  749 */       getHookManager().addHook(MSG_TYPE_SET_PROPERTY_NONBLOCK, new SetPropertyHook());
/*      */ 
/*  753 */       selectionFilter.addType(ObjectManagerClient.MSG_TYPE_GENERATE_SUB_OBJECT);
/*  754 */       selectionFilter.addType(ObjectManagerClient.MSG_TYPE_LOAD_SUBOBJECT);
/*  755 */       selectionFilter.setNamespaces(namespaces);
/*  756 */       selectionFilter = selectionFilter;
/*  757 */       selectionSubscription = Long.valueOf(Engine.getAgent().createSubscription(selectionFilter, this, 8));
/*      */ 
/*  762 */       subObjectFilter.addType(ObjectManagerClient.MSG_TYPE_SAVE_SUBOBJECT);
/*  763 */       subObjectFilter.addType(ObjectManagerClient.MSG_TYPE_UNLOAD_SUBOBJECT);
/*  764 */       subObjectFilter.addType(ObjectManagerClient.MSG_TYPE_DELETE_SUBOBJECT);
/*  765 */       subObjectFilter.addType(ObjectManagerClient.MSG_TYPE_SET_SUBPERSISTENCE);
/*  766 */       subObjectFilter.addType(MSG_TYPE_GET_PROPERTY);
/*  767 */       subObjectFilter.addType(MSG_TYPE_GET_PROPERTY_NAMES);
/*  768 */       subObjectFilter.addType(MSG_TYPE_SET_PROPERTY);
/*  769 */       subObjectFilter.setNamespaces(namespaces);
/*  770 */       subObjectSubscription = Long.valueOf(Engine.getAgent().createSubscription(subObjectFilter, this, 8));
/*      */ 
/*  779 */       NamespaceFilter propertyNonblockFilter = new NamespaceFilter(namespaces);
/*      */ 
/*  781 */       propertyNonblockFilter.addType(MSG_TYPE_SET_PROPERTY_NONBLOCK);
/*  782 */       propertySubscription = Long.valueOf(Engine.getAgent().createSubscription(propertyNonblockFilter, this));
/*      */     }
/*      */     finally
/*      */     {
/*  786 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerSaveHook(Namespace namespace, SaveHook saveHook)
/*      */   {
/*  799 */     Engine.getPersistenceManager().registerSaveHook(namespace, saveHook);
/*      */   }
/*      */ 
/*      */   public void registerLoadHook(Namespace namespace, LoadHook loadHook)
/*      */   {
/*  808 */     this.loadHookMap.put(namespace, loadHook);
/*      */   }
/*      */ 
/*      */   public void registerUnloadHook(Namespace namespace, UnloadHook unloadHook)
/*      */   {
/*  817 */     this.unloadHookMap.put(namespace, unloadHook);
/*      */   }
/*      */ 
/*      */   public void registerDeleteHook(Namespace namespace, DeleteHook deleteHook)
/*      */   {
/*  826 */     this.deleteHookMap.put(namespace, deleteHook);
/*      */   }
/*      */ 
/*      */   public void registerTransferHook(Filter filter, Hook hook)
/*      */   {
/*  906 */     getHookManager().addHook(MSG_TYPE_TRANSFER_OBJECT, hook);
/*  907 */     Engine.getAgent().createSubscription(filter, this);
/*      */   }
/*      */ 
/*      */   public boolean transferObject(HashMap<String, Serializable> propMap, Entity entity)
/*      */   {
/*  929 */     TransferObjectMessage transferMessage = new TransferObjectMessage(propMap, entity);
/*  930 */     return Engine.getAgent().sendRPCReturnBoolean(transferMessage).booleanValue();
/*      */   }
/*      */ 
/*      */   public HookManager getHookManager()
/*      */   {
/*  981 */     return this.hookManager;
/*      */   }
/*      */ 
/*      */   protected ObjectLockManager getObjectLockManager()
/*      */   {
/*  990 */     return this.objLockManager;
/*      */   }
/*      */ 
/*      */   private void addToDepsOutstanding(OID oid, Namespace namespace, Hook callback)
/*      */   {
/* 1016 */     Map deps = (Map)this.depsOutstanding.get(oid);
/* 1017 */     if (deps == null) {
/* 1018 */       deps = new HashMap();
/* 1019 */       this.depsOutstanding.put(oid, deps);
/*      */     }
/* 1021 */     Hook previousHook = (Hook)deps.get(namespace);
/* 1022 */     if (previousHook != null) {
/* 1023 */       Log.error("EnginePlugin.addToNamespaceDeps: for oid " + oid + " and namespace " + namespace + ", hook already exists");
/*      */     } else {
/* 1025 */       deps.put(namespace, callback);
/* 1026 */       logDepsOutstanding("addToDepsOutstanding", oid, namespace);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Hook removeFromDepsOutstanding(OID oid, Namespace namespace)
/*      */   {
/* 1034 */     logDepsOutstanding("removeFromDepsOutstanding", oid, namespace);
/* 1035 */     Map deps = (Map)this.depsOutstanding.get(oid);
/* 1036 */     if (deps == null) {
/* 1037 */       Log.error("EnginePlugin.removeFromDepsOutstanding: Map<Namespace, Hook> for oid " + oid + " not found");
/*      */     } else {
/* 1039 */       Hook hook = (Hook)deps.remove(namespace);
/* 1040 */       if (hook == null) {
/* 1041 */         Log.error("EnginePlugin.removeFromDepsOutstanding: for oid " + oid + ", namespace " + namespace + ", deps do not contain Hook");
/*      */       }
/*      */       else {
/* 1044 */         if (deps.size() == 0)
/* 1045 */           deps.remove(oid);
/* 1046 */         return hook;
/*      */       }
/*      */     }
/* 1049 */     return null;
/*      */   }
/*      */ 
/*      */   public void sendSubObjectResponse(Message origMsg, OID oid, Namespace oidNamespace)
/*      */   {
/* 1059 */     if (Log.loggingDebug)
/* 1060 */       Log.debug("EnginePlugin.sendSubObjectResponse: origMsg=" + origMsg + ", oid=" + oid + ", namespace " + oidNamespace);
/* 1061 */     sendSubObjectResponse(origMsg, oid, oidNamespace, (LinkedList)null, null);
/*      */   }
/*      */ 
/*      */   public void sendSubObjectResponse(Message origMsg, OID oid, Namespace oidNamespace, Namespace depNamespace, Hook callback)
/*      */   {
/* 1074 */     if (Log.loggingDebug) {
/* 1075 */       Log.debug("EnginePlugin.sendSubObjectResponse: origMsg=" + origMsg + ", oid=" + oid + ", oidNamespace " + oidNamespace + ", depNs=" + depNamespace);
/*      */     }
/*      */ 
/* 1078 */     LinkedList deps = new LinkedList();
/* 1079 */     deps.add(depNamespace);
/* 1080 */     sendSubObjectResponse(origMsg, oid, oidNamespace, deps, callback);
/*      */   }
/*      */ 
/*      */   public void sendSubObjectResponse(Message msg, OID oid, Namespace oidNamespace, LinkedList<Namespace> depNamespaces, Hook callback)
/*      */   {
/* 1099 */     INamespaceMessage origMsg = (INamespaceMessage)msg;
/* 1100 */     if (Log.loggingDebug) {
/* 1101 */       Log.debug("EnginePlugin.sendSubObjectResponse: origMsg=" + origMsg + ", oid=" + oid + ", depNs=" + depNamespaces + ", hook=" + callback);
/*      */     }
/* 1103 */     this.depLock.lock();
/*      */     try {
/* 1105 */       if (Log.loggingDebug) {
/* 1106 */         Log.debug("sendSubObjectResponse: oid=" + oid);
/*      */       }
/*      */ 
/* 1109 */       if ((depNamespaces != null) && (!depNamespaces.isEmpty())) {
/* 1110 */         if (Log.loggingDebug)
/* 1111 */           Log.debug("sendSubObjectResponse: oid=" + oid + ", depNamespaces=" + depNamespaces.toString());
/* 1112 */         if (this.subObjectDepReadySub == null) {
/* 1113 */           if (Log.loggingDebug) {
/* 1114 */             Log.debug("sendSubObjectResponse: oid=" + oid + ", need to create deps ready sub");
/*      */           }
/* 1116 */           getHookManager().addHook(ObjectManagerClient.MSG_TYPE_SUB_OBJECT_DEPS_READY, new SubObjectDepsReadyHook());
/*      */ 
/* 1121 */           Filter namespaceFilter = new NamespaceFilter(ObjectManagerClient.MSG_TYPE_SUB_OBJECT_DEPS_READY, getPluginNamespaces());
/*      */ 
/* 1126 */           this.subObjectDepReadySub = Long.valueOf(Engine.getAgent().createSubscription(namespaceFilter, this, 8));
/*      */ 
/* 1129 */           Log.debug("sendSubObjectResponse: created depsReady sub");
/*      */         }
/*      */         else {
/* 1132 */           Log.debug("sendSubObjectResponse: depsReady sub already in place");
/*      */         }
/*      */ 
/* 1138 */         if (callback == null) {
/* 1139 */           Log.error("EnginePlugin.sendSubObjectResponse: callback is null");
/*      */         }
/* 1141 */         addToDepsOutstanding(oid, oidNamespace, callback);
/*      */       }
/*      */ 
/* 1145 */       Namespace namespace = origMsg.getNamespace();
/* 1146 */       if (namespace == null) {
/* 1147 */         Log.error("EnginePlugin.sendSubObjectResponse: namespace is null");
/*      */       }
/* 1149 */       Entity subObj = EntityManager.getEntityByNamespace(oid, namespace);
/* 1150 */       if (subObj == null) {
/* 1151 */         Log.error("EnginePlugin.sendSubObjectResponse: subObj is null for oid " + oid);
/*      */       }
/* 1153 */       if (Log.loggingDebug)
/* 1154 */         Log.debug("EnginePlugin.sendSubObjectResponse: set entity " + subObj.getOid() + " namespace to " + namespace);
/*      */     }
/*      */     finally {
/* 1157 */       this.depLock.unlock();
/*      */     }
/*      */ 
/* 1161 */     Engine.getAgent().sendObjectResponse(msg, depNamespaces);
/*      */   }
/*      */ 
/*      */   protected void logDepsOutstanding(String prefix, OID oid, Namespace ns)
/*      */   {
/* 1577 */     if (Log.loggingDebug) {
/* 1578 */       String s = "";
/* 1579 */       Map deps = (Map)this.depsOutstanding.get(oid);
/* 1580 */       if (deps == null)
/* 1581 */         s = "None";
/*      */       else {
/* 1583 */         for (Namespace dep : deps.keySet()) {
/* 1584 */           if (s != "")
/* 1585 */             s = s + ",";
/* 1586 */           s = s + dep.getName();
/*      */         }
/*      */       }
/* 1589 */       Log.debug(prefix + ": masterOid " + oid + ", namespace " + ns + ", deps " + s);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean getPropertyImpl(GetPropertyMessage msg)
/*      */   {
/* 1942 */     Namespace ns = msg.getNamespace();
/* 1943 */     OID oid = msg.getSubject();
/*      */ 
/* 1945 */     List vals = new LinkedList();
/* 1946 */     Entity e = EntityManager.getEntityByNamespace(oid, ns);
/* 1947 */     if (e == null) {
/* 1948 */       Log.error("EnginePlugin.GetPropertyHook: could not find subobj for oid " + oid + " in namespace " + ns);
/* 1949 */       Engine.getAgent().sendObjectResponse(msg, null);
/* 1950 */       return false;
/*      */     }
/* 1952 */     List keys = msg.getKeys();
/* 1953 */     for (String key : keys) {
/* 1954 */       vals.add(e.getProperty(key));
/*      */     }
/* 1956 */     Engine.getAgent().sendObjectResponse(msg, vals);
/* 1957 */     if (Log.loggingDebug) {
/* 1958 */       String s = "";
/* 1959 */       for (int i = 0; i < keys.size(); i++) {
/* 1960 */         String key = (String)keys.get(i);
/* 1961 */         Serializable val = (Serializable)vals.get(i);
/* 1962 */         if (s != "")
/* 1963 */           s = s + ",";
/* 1964 */         s = s + key + "=" + val;
/*      */       }
/* 1966 */       Log.debug("EnginePlugin.GetPropertyHook: sent response, oid=" + oid + ", " + s);
/*      */     }
/* 1968 */     return true;
/*      */   }
/*      */ 
/*      */   protected boolean getPropertyNamesImpl(GetPropertyNamesMessage msg)
/*      */   {
/* 2000 */     Namespace ns = msg.getNamespace();
/* 2001 */     OID oid = msg.getSubject();
/*      */ 
/* 2003 */     List vals = new LinkedList();
/* 2004 */     Entity e = EntityManager.getEntityByNamespace(oid, ns);
/* 2005 */     if (e == null) {
/* 2006 */       Log.error("EnginePlugin.GetPropertyHook: could not find subobj for oid " + oid);
/* 2007 */       Engine.getAgent().sendObjectResponse(msg, null);
/* 2008 */       return false;
/*      */     }
/* 2010 */     Map propMap = e.getPropertyMap();
/* 2011 */     vals.addAll(propMap.keySet());
/*      */ 
/* 2013 */     Engine.getAgent().sendObjectResponse(msg, vals);
/* 2014 */     if (Log.loggingDebug) {
/* 2015 */       String s = "";
/* 2016 */       for (int i = 0; i < vals.size(); i++) {
/* 2017 */         Serializable val = (Serializable)vals.get(i);
/* 2018 */         if (s != "")
/* 2019 */           s = s + ",";
/* 2020 */         s = s + val;
/*      */       }
/* 2022 */       Log.debug("EnginePlugin.GetPropertyHook: sent response, oid=" + oid + ", " + s);
/*      */     }
/* 2024 */     return true;
/*      */   }
/*      */ 
/*      */   protected boolean setPropertyImpl(SetPropertyMessage msg)
/*      */   {
/* 2056 */     OID oid = msg.getSubject();
/* 2057 */     Namespace ns = msg.getNamespace();
/* 2058 */     String s = "";
/* 2059 */     if (Log.loggingDebug) {
/* 2060 */       for (Map.Entry entry : msg.getPropMap().entrySet()) {
/* 2061 */         String key = (String)entry.getKey();
/* 2062 */         Serializable val = (Serializable)entry.getValue();
/* 2063 */         if (s != "")
/* 2064 */           s = s + ",";
/* 2065 */         s = s + key + "=" + val;
/*      */       }
/* 2067 */       if (Log.loggingDebug) {
/* 2068 */         Log.debug("EnginePlugin.setPropertyImpl: oid=" + oid + " props " + s);
/*      */       }
/*      */     }
/* 2071 */     boolean reqResp = msg.getRequestResponse();
/*      */ 
/* 2073 */     List previousVals = null;
/* 2074 */     if (reqResp) {
/* 2075 */       previousVals = new LinkedList();
/*      */     }
/* 2077 */     Entity entity = EntityManager.getEntityByNamespace(oid, ns);
/* 2078 */     if (entity == null)
/*      */     {
/* 2080 */       for (Map.Entry entry : msg.getPropMap().entrySet()) {
/* 2081 */         String key = (String)entry.getKey();
/* 2082 */         Log.error("EnginePlugin.setPropertyImpl: could not find obj / subobj for oid " + oid + ", namespace " + ns + ", key=" + key);
/*      */       }
/* 2084 */       if (reqResp) {
/* 2085 */         Engine.getAgent().sendObjectResponse(msg, previousVals);
/*      */       }
/* 2087 */       return false;
/*      */     }
/* 2089 */     PropertyMessage propMsg = new PropertyMessage(oid);
/* 2090 */     for (Map.Entry entry : msg.getPropMap().entrySet()) {
/* 2091 */       String key = (String)entry.getKey();
/* 2092 */       Serializable newValue = (Serializable)entry.getValue();
/* 2093 */       Serializable previousValue = entity.setProperty(key, newValue);
/* 2094 */       propMsg.setProperty(key, newValue);
/* 2095 */       if (reqResp) {
/* 2096 */         previousVals.add(previousValue);
/*      */       }
/*      */     }
/* 2099 */     for (String key : msg.getRemovedProperties())
/*      */     {
/* 2101 */       Serializable previousValue = entity.removeProperty(key);
/*      */ 
/* 2103 */       propMsg.removeProperty(key);
/* 2104 */       if (reqResp)
/* 2105 */         previousVals.add(previousValue);
/*      */     }
/* 2107 */     if (reqResp) {
/* 2108 */       Engine.getAgent().sendObjectResponse(msg, previousVals);
/*      */     }
/* 2110 */     Engine.getAgent().sendBroadcast(propMsg);
/*      */ 
/* 2113 */     Engine.getPersistenceManager().setDirty(entity);
/* 2114 */     return true;
/*      */   }
/*      */ 
/*      */   public static Serializable getObjectProperty(OID oid, Namespace namespace, String key)
/*      */   {
/* 2127 */     GetPropertyMessage msg = new GetPropertyMessage(oid, namespace, key);
/* 2128 */     List vals = (List)Engine.getAgent().sendRPCReturnObject(msg);
/*      */ 
/* 2132 */     if (vals == null)
/* 2133 */       return null;
/* 2134 */     return (Serializable)vals.get(0);
/*      */   }
/*      */ 
/*      */   public static List<Serializable> getObjectProperties(OID oid, Namespace namespace, List<String> keys)
/*      */   {
/* 2146 */     GetPropertyMessage msg = new GetPropertyMessage(oid, namespace, keys);
/* 2147 */     return (List)Engine.getAgent().sendRPCReturnObject(msg);
/*      */   }
/*      */ 
/*      */   public static List<Serializable> getObjectProperties(OID oid, Namespace namespace, String[] keys)
/*      */   {
/* 2159 */     List list = new LinkedList();
/* 2160 */     for (String s : keys)
/* 2161 */       list.add(s);
/* 2162 */     return getObjectProperties(oid, namespace, list);
/*      */   }
/*      */ 
/*      */   public static List<String> getObjectPropertyNames(OID oid, Namespace namespace)
/*      */   {
/* 2174 */     GetPropertyNamesMessage msg = new GetPropertyNamesMessage(oid, namespace);
/* 2175 */     return (List)Engine.getAgent().sendRPCReturnObject(msg);
/*      */   }
/*      */ 
/*      */   public static Serializable setObjectProperty(OID oid, Namespace namespace, String key, Serializable value)
/*      */   {
/* 2189 */     SetPropertyMessage msg = new SetPropertyMessage(oid, namespace, key, value, true);
/* 2190 */     return (Serializable)Engine.getAgent().sendRPCReturnObject(msg);
/*      */   }
/*      */ 
/*      */   public static void setObjectPropertyNoResponse(OID oid, Namespace namespace, String key, Serializable value)
/*      */   {
/* 2203 */     SetPropertyMessage msg = new SetPropertyMessage(oid, namespace, key, value, false);
/* 2204 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static List<Serializable> setObjectProperties(OID oid, Namespace namespace, Map<String, Serializable> propMap)
/*      */   {
/* 2217 */     return setObjectProperties(oid, namespace, propMap, new LinkedList());
/*      */   }
/*      */ 
/*      */   public static List<Serializable> setObjectProperties(OID oid, Namespace namespace, Map<String, Serializable> propMap, Collection<String> removedProps)
/*      */   {
/* 2232 */     SetPropertyMessage msg = new SetPropertyMessage(oid, namespace, propMap, removedProps, true);
/* 2233 */     return (List)Engine.getAgent().sendRPCReturnObject(msg);
/*      */   }
/*      */ 
/*      */   public static List<Serializable> setObjectProperties(OID oid, Namespace namespace, Serializable[] keysAndValues)
/*      */   {
/* 2246 */     Map propMap = processKeysAndValues("setObjectProperties", keysAndValues);
/* 2247 */     if (propMap == null) {
/* 2248 */       return new LinkedList();
/*      */     }
/* 2250 */     return setObjectProperties(oid, namespace, propMap, new LinkedList());
/*      */   }
/*      */ 
/*      */   public static void setObjectPropertiesNoResponse(OID oid, Namespace namespace, Map<String, Serializable> propMap)
/*      */   {
/* 2262 */     setObjectPropertiesNoResponse(oid, namespace, propMap, new LinkedList());
/*      */   }
/*      */ 
/*      */   public static void setObjectPropertiesNoResponse(OID oid, Namespace namespace, Map<String, Serializable> propMap, Collection<String> removedProps)
/*      */   {
/* 2276 */     SetPropertyMessage msg = new SetPropertyMessage(oid, namespace, propMap, removedProps, false);
/* 2277 */     Engine.getAgent().sendBroadcast(msg);
/*      */   }
/*      */ 
/*      */   public static void setObjectPropertiesNoResponse(OID oid, Namespace namespace, Serializable[] keysAndValues)
/*      */   {
/* 2289 */     Map propMap = processKeysAndValues("setObjectPropertiesNoResponse", keysAndValues);
/* 2290 */     if (propMap == null) {
/* 2291 */       return;
/*      */     }
/* 2293 */     setObjectPropertiesNoResponse(oid, namespace, propMap, new LinkedList());
/*      */   }
/*      */ 
/*      */   protected static Map<String, Serializable> processKeysAndValues(String what, Serializable[] keysAndValues)
/*      */   {
/* 2300 */     int len = keysAndValues.length;
/* 2301 */     if ((len & 0x1) != 0) {
/* 2302 */       Log.dumpStack("Odd number of args to " + what);
/* 2303 */       return null;
/*      */     }
/* 2305 */     if (len == 0) {
/* 2306 */       return null;
/*      */     }
/* 2308 */     Map propMap = new HashMap();
/* 2309 */     for (int i = 0; i < len; i += 2)
/* 2310 */       propMap.put((String)keysAndValues[i], keysAndValues[(i + 1)]);
/* 2311 */     return propMap;
/*      */   }
/*      */ 
/*      */   private void createManagementObject()
/*      */   {
/* 2561 */     if (Engine.getManagementAgent() == null) {
/* 2562 */       Log.debug("Engine.getManagementAgent returned null");
/* 2563 */       return;
/*      */     }
/* 2565 */     Object mbean = createMBeanInstance();
/* 2566 */     if (mbean == null) {
/* 2567 */       Log.debug("EnginePlugin.createMBeanInstance returned null");
/* 2568 */       return;
/*      */     }
/*      */     try {
/* 2571 */       ObjectName name = new ObjectName("net.atavism:plugin=" + getName());
/* 2572 */       Engine.getManagementAgent().registerMBean(mbean, name);
/* 2573 */       Log.debug("Registered " + getName() + " with JMX management agent");
/*      */     } catch (JMException ex) {
/* 2575 */       Log.exception("createManagementObject: exception in registerMBean", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Object createMBeanInstance() {
/* 2580 */     return null;
/*      */   }
/*      */ 
/*      */   public static class TransferObjectMessage extends Message
/*      */   {
/*      */     private HashMap<String, Serializable> propMap;
/*      */     private Entity entity;
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public TransferObjectMessage()
/*      */     {
/* 2449 */       super();
/*      */     }
/*      */ 
/*      */     public TransferObjectMessage(HashMap<String, Serializable> propMap, Entity entity)
/*      */     {
/* 2459 */       super();
/* 2460 */       setPropMap(propMap);
/* 2461 */       setEntity(entity);
/*      */     }
/*      */ 
/*      */     public HashMap<String, Serializable> getPropMap()
/*      */     {
/* 2469 */       return this.propMap;
/*      */     }
/*      */ 
/*      */     public void setPropMap(HashMap<String, Serializable> propMap)
/*      */     {
/* 2477 */       this.propMap = propMap;
/*      */     }
/*      */ 
/*      */     public Entity getEntity()
/*      */     {
/* 2485 */       return this.entity;
/*      */     }
/*      */ 
/*      */     public void setEntity(Entity entity)
/*      */     {
/* 2493 */       this.entity = entity;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class PluginStateMessage extends Message
/*      */   {
/*      */     private String pluginName;
/*      */     private String state;
/*      */     private String targetPluginName;
/*      */     private String sessionId;
/*      */     public static final String BuiltInStateAvailable = "Available";
/*      */     public static final String BuiltInStateUnknown = "Unknown";
/*      */     public static final String BuiltInStateStarting = "Starting";
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public PluginStateMessage()
/*      */     {
/* 2328 */       setMsgType(EnginePlugin.MSG_TYPE_PLUGIN_STATE);
/*      */     }
/*      */ 
/*      */     public PluginStateMessage(String pluginName, String state)
/*      */     {
/* 2340 */       setMsgType(EnginePlugin.MSG_TYPE_PLUGIN_STATE);
/* 2341 */       setPluginName(pluginName);
/* 2342 */       setState(state);
/*      */     }
/*      */ 
/*      */     public void setPluginName(String pluginName)
/*      */     {
/* 2350 */       this.pluginName = pluginName;
/*      */     }
/*      */ 
/*      */     public String getPluginName()
/*      */     {
/* 2358 */       return this.pluginName;
/*      */     }
/*      */ 
/*      */     public void setState(String state)
/*      */     {
/* 2366 */       this.state = state;
/*      */     }
/*      */ 
/*      */     public String getState()
/*      */     {
/* 2374 */       return this.state;
/*      */     }
/*      */ 
/*      */     public void setTargetSession(String sessionId)
/*      */     {
/* 2384 */       this.sessionId = sessionId;
/*      */     }
/*      */ 
/*      */     public String getTargetSession()
/*      */     {
/* 2392 */       return this.sessionId;
/*      */     }
/*      */ 
/*      */     public void setTargetPluginName(String pluginName)
/*      */     {
/* 2402 */       this.targetPluginName = pluginName;
/*      */     }
/*      */ 
/*      */     public String getTargetPluginName()
/*      */     {
/* 2410 */       return this.targetPluginName;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SetPropertyHook
/*      */     implements Hook
/*      */   {
/*      */     SetPropertyHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 2040 */       EnginePlugin.SetPropertyMessage rMsg = (EnginePlugin.SetPropertyMessage)msg;
/* 2041 */       return EnginePlugin.this.setPropertyImpl(rMsg);
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetPropertyNamesHook
/*      */     implements Hook
/*      */   {
/*      */     GetPropertyNamesHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1986 */       EnginePlugin.GetPropertyNamesMessage rMsg = (EnginePlugin.GetPropertyNamesMessage)msg;
/* 1987 */       return EnginePlugin.this.getPropertyNamesImpl(rMsg);
/*      */     }
/*      */   }
/*      */ 
/*      */   class GetPropertyHook
/*      */     implements Hook
/*      */   {
/*      */     GetPropertyHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message msg, int flags)
/*      */     {
/* 1928 */       EnginePlugin.GetPropertyMessage rMsg = (EnginePlugin.GetPropertyMessage)msg;
/* 1929 */       return EnginePlugin.this.getPropertyImpl(rMsg);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SetPropertyMessage extends OIDNamespaceMessage
/*      */   {
/* 1903 */     private boolean reqResponse = false;
/*      */ 
/* 1908 */     Map<String, Serializable> propMap = new HashMap();
/* 1909 */     Collection<String> removedProperties = new HashSet();
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public SetPropertyMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public SetPropertyMessage(OID oid, Namespace namespace, String key, Serializable val, boolean reqResponse)
/*      */     {
/* 1785 */       super(oid, namespace);
/* 1786 */       if (!reqResponse)
/* 1787 */         setMsgType(EnginePlugin.MSG_TYPE_SET_PROPERTY_NONBLOCK);
/* 1788 */       this.propMap.put(key, val);
/* 1789 */       setRequestResponse(reqResponse);
/*      */     }
/*      */ 
/*      */     public SetPropertyMessage(OID oid, Namespace namespace, Map<String, Serializable> propMap, Collection<String> removedProps, boolean reqResponse)
/*      */     {
/* 1804 */       super(oid, namespace);
/* 1805 */       if (!reqResponse)
/* 1806 */         setMsgType(EnginePlugin.MSG_TYPE_SET_PROPERTY_NONBLOCK);
/* 1807 */       this.propMap = propMap;
/* 1808 */       this.removedProperties = removedProps;
/* 1809 */       setRequestResponse(reqResponse);
/*      */     }
/*      */ 
/*      */     /** @deprecated */
/*      */     public Serializable get(String key)
/*      */     {
/* 1817 */       return getProperty(key);
/*      */     }
/*      */ 
/*      */     public Serializable getProperty(String key)
/*      */     {
/* 1826 */       return (Serializable)this.propMap.get(key);
/*      */     }
/*      */ 
/*      */     public boolean containsKey(String key)
/*      */     {
/* 1836 */       return this.propMap.containsKey(key);
/*      */     }
/*      */ 
/*      */     /** @deprecated */
/*      */     public void put(String key, Serializable val)
/*      */     {
/* 1844 */       setProperty(key, val);
/*      */     }
/*      */ 
/*      */     public Serializable setProperty(String key, Serializable val)
/*      */     {
/* 1854 */       Serializable rv = (Serializable)this.propMap.put(key, val);
/* 1855 */       this.removedProperties.remove(key);
/* 1856 */       return rv;
/*      */     }
/*      */ 
/*      */     public void removeProperty(String key)
/*      */     {
/* 1865 */       this.propMap.remove(key);
/* 1866 */       this.removedProperties.add(key);
/*      */     }
/*      */ 
/*      */     public Map<String, Serializable> getPropMap()
/*      */     {
/* 1874 */       return this.propMap;
/*      */     }
/*      */ 
/*      */     public Collection<String> getRemovedProperties() {
/* 1878 */       return this.removedProperties;
/*      */     }
/*      */ 
/*      */     public void setRequestResponse(boolean val)
/*      */     {
/* 1887 */       this.reqResponse = val;
/* 1888 */       if (this.reqResponse)
/* 1889 */         setMsgType(EnginePlugin.MSG_TYPE_SET_PROPERTY);
/*      */       else
/* 1891 */         setMsgType(EnginePlugin.MSG_TYPE_SET_PROPERTY_NONBLOCK);
/*      */     }
/*      */ 
/*      */     public boolean getRequestResponse()
/*      */     {
/* 1898 */       return this.reqResponse;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetPropertyNamesMessage extends OIDNamespaceMessage
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetPropertyNamesMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public GetPropertyNamesMessage(OID oid, Namespace namespace)
/*      */     {
/* 1747 */       super(oid, namespace);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1754 */       return "[GetPropertyNamesMessage oid=" + getSubject() + ", super=" + super.toString() + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetPropertyMessage extends OIDNamespaceMessage
/*      */   {
/* 1723 */     List<String> keys = new LinkedList();
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     public GetPropertyMessage()
/*      */     {
/*      */     }
/*      */ 
/*      */     public GetPropertyMessage(OID oid, Namespace namespace, String key)
/*      */     {
/* 1660 */       super(oid, namespace);
/* 1661 */       addKey(key);
/*      */     }
/*      */ 
/*      */     public GetPropertyMessage(OID oid, Namespace namespace, List<String> keys)
/*      */     {
/* 1672 */       super(oid, namespace);
/* 1673 */       this.keys = keys;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1680 */       String s = "";
/* 1681 */       for (Serializable key : this.keys) {
/* 1682 */         if (s != "")
/* 1683 */           s = s + ",";
/* 1684 */         s = s + key;
/*      */       }
/* 1686 */       return "[GetPropertyMessage oid=" + getSubject() + ", keys=" + s + ", super=" + super.toString() + "]";
/*      */     }
/*      */ 
/*      */     public void addKey(String key)
/*      */     {
/* 1696 */       if (!this.keys.contains(key))
/* 1697 */         this.keys.add(key);
/*      */     }
/*      */ 
/*      */     public Serializable removeKey(Serializable key)
/*      */     {
/* 1708 */       return Boolean.valueOf(this.keys.remove(key));
/*      */     }
/*      */ 
/*      */     public List<String> getKeys()
/*      */     {
/* 1717 */       return this.keys;
/*      */     }
/*      */   }
/*      */ 
/*      */   class SubObjectDepsReadyHook
/*      */     implements Hook
/*      */   {
/*      */     SubObjectDepsReadyHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1614 */       ObjectManagerClient.SubObjectDepsReadyMessage msg = (ObjectManagerClient.SubObjectDepsReadyMessage)m;
/*      */ 
/* 1616 */       OID masterOid = msg.getSubject();
/* 1617 */       Namespace ns = msg.getNamespace();
/*      */ 
/* 1619 */       EnginePlugin.this.logDepsOutstanding("SubObjectDepsReadyHook.processMessage", masterOid, ns);
/*      */ 
/* 1622 */       Hook cb = EnginePlugin.this.removeFromDepsOutstanding(masterOid, ns);
/* 1623 */       if (cb == null) {
/* 1624 */         Log.error("SubObjectDepsReadyHook: the sub oid was not in the wait list: " + masterOid + ", namespace " + ns);
/* 1625 */         return false;
/*      */       }
/*      */ 
/* 1629 */       cb.processMessage(msg, 0);
/*      */ 
/* 1633 */       Engine.getAgent().sendBooleanResponse(m, Boolean.TRUE);
/* 1634 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DeleteSubObjHook
/*      */     implements Hook
/*      */   {
/*      */     EnginePlugin plugin;
/*      */ 
/*      */     public DeleteSubObjHook(EnginePlugin plugin)
/*      */     {
/* 1495 */       this.plugin = plugin;
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1511 */       ObjectManagerClient.DeleteSubObjectMessage msg = (ObjectManagerClient.DeleteSubObjectMessage)m;
/*      */ 
/* 1513 */       OID oid = msg.getSubject();
/* 1514 */       Namespace namespace = msg.getNamespace();
/*      */ 
/* 1516 */       EnginePlugin.DeleteHook deleteHook = (EnginePlugin.DeleteHook)this.plugin.deleteHookMap.get(namespace);
/*      */ 
/* 1518 */       Entity entity = EntityManager.getEntityByNamespace(oid, namespace);
/* 1519 */       if (entity == null) {
/* 1520 */         Log.error("DeleteSubObjectMessage: no such entity oid=" + oid + " ns=" + namespace);
/*      */ 
/* 1524 */         if (deleteHook != null) {
/*      */           try {
/* 1526 */             deleteHook.onDelete(oid, namespace);
/*      */           }
/*      */           catch (Exception e) {
/* 1529 */             Log.exception("DeleteHook.onDelete oid=" + oid + " ns=" + namespace + " " + deleteHook.getClass().getName(), e);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1535 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/* 1536 */         return false;
/*      */       }
/*      */ 
/* 1539 */       entity.getLock().lock();
/*      */       try {
/* 1541 */         if (entity.isDeleted()) {
/* 1542 */           Log.debug("DeleteSubObjectMessage: already deleted oid=" + oid);
/* 1543 */           e = 1;
/*      */           return e;
/*      */         }
/* 1545 */         entity.setDeleted();
/*      */       } finally {
/* 1547 */         entity.getLock().unlock();
/*      */       }
/*      */ 
/* 1550 */       boolean rc = EntityManager.removeEntityByNamespace(oid, namespace);
/* 1551 */       if ((rc) && (deleteHook != null)) {
/*      */         try {
/* 1553 */           deleteHook.onDelete(entity);
/*      */         }
/*      */         catch (Exception e) {
/* 1556 */           Log.exception("DeleteHook.onDelete oid=" + oid + " " + deleteHook.getClass().getName(), e);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1561 */       if (Log.loggingDebug) {
/* 1562 */         Log.debug("DeleteSubObjectMessage: deleted oid=" + oid + " ns=" + namespace + " result=" + rc);
/*      */       }
/*      */ 
/* 1565 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(rc));
/*      */ 
/* 1567 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class UnloadSubObjHook
/*      */     implements Hook
/*      */   {
/*      */     EnginePlugin plugin;
/*      */ 
/*      */     public UnloadSubObjHook(EnginePlugin plugin)
/*      */     {
/* 1431 */       this.plugin = plugin;
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1444 */       ObjectManagerClient.UnloadSubObjectMessage msg = (ObjectManagerClient.UnloadSubObjectMessage)m;
/*      */ 
/* 1446 */       OID oid = msg.getSubject();
/* 1447 */       Namespace namespace = msg.getNamespace();
/*      */ 
/* 1449 */       Entity entity = EntityManager.getEntityByNamespace(oid, namespace);
/* 1450 */       if (entity == null) {
/* 1451 */         Log.error("UnloadSubObjectMessage: no such entity oid=" + oid + " ns=" + namespace);
/*      */ 
/* 1453 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/* 1454 */         return false;
/*      */       }
/*      */ 
/* 1457 */       boolean rc = EntityManager.removeEntityByNamespace(oid, namespace);
/*      */ 
/* 1459 */       if (rc)
/*      */       {
/* 1461 */         EnginePlugin.UnloadHook unloadHook = (EnginePlugin.UnloadHook)this.plugin.unloadHookMap.get(namespace);
/* 1462 */         if (unloadHook != null) {
/*      */           try {
/* 1464 */             unloadHook.onUnload(entity);
/*      */           }
/*      */           catch (Exception e) {
/* 1467 */             Log.exception("UnloadHook.onUnload oid=" + oid + " " + unloadHook.getClass().getName() + "", e);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1474 */       if (Log.loggingDebug) {
/* 1475 */         Log.debug("UnloadSubObjectMessage: unloaded oid=" + oid + " ns=" + namespace + " result=" + rc);
/*      */       }
/*      */ 
/* 1478 */       if ((entity.getPersistenceFlag()) && (Engine.getPersistenceManager().isDirty(entity)))
/*      */       {
/* 1480 */         Engine.getPersistenceManager().persistEntity(entity);
/*      */       }
/*      */ 
/* 1483 */       Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(rc));
/*      */ 
/* 1485 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class LoadSubObjHook
/*      */     implements Hook
/*      */   {
/* 1424 */     EnginePlugin pluginRef = null;
/*      */ 
/*      */     public LoadSubObjHook(EnginePlugin plugin)
/*      */     {
/* 1376 */       this.pluginRef = plugin;
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1388 */       ObjectManagerClient.LoadSubObjectMessage msg = (ObjectManagerClient.LoadSubObjectMessage)m;
/* 1389 */       OID masterOid = msg.getSubject();
/* 1390 */       Namespace namespace = msg.getNamespace();
/*      */ 
/* 1393 */       Entity entity = null;
/*      */       try {
/* 1395 */         entity = Engine.getDatabase().loadEntity(masterOid, namespace);
/*      */       }
/*      */       catch (AORuntimeException e) {
/* 1398 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/* 1399 */         return false;
/*      */       }
/*      */ 
/* 1402 */       if (entity == null) {
/* 1403 */         Log.error("LoadSubObjHook: no such entity with oid " + masterOid + " and namespace " + namespace);
/* 1404 */         Engine.getAgent().sendBooleanResponse(msg, Boolean.valueOf(false));
/* 1405 */         return false;
/*      */       }
/*      */ 
/* 1409 */       EntityManager.registerEntityByNamespace(entity, namespace);
/*      */ 
/* 1412 */       EnginePlugin.LoadHook loadHook = (EnginePlugin.LoadHook)this.pluginRef.loadHookMap.get(namespace);
/* 1413 */       if (loadHook != null) {
/* 1414 */         loadHook.onLoad(entity);
/*      */       }
/*      */ 
/* 1417 */       if (Log.loggingDebug)
/* 1418 */         Log.debug("LoadSubObjHook: called loadhook, loaded object oid " + masterOid + " and namespace " + namespace);
/* 1419 */       Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(true));
/*      */ 
/* 1421 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SaveSubObjHook
/*      */     implements Hook
/*      */   {
/* 1368 */     EnginePlugin pluginRef = null;
/*      */ 
/*      */     public SaveSubObjHook(EnginePlugin plugin)
/*      */     {
/* 1324 */       this.pluginRef = plugin;
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1337 */       OIDNamespaceMessage msg = (OIDNamespaceMessage)m;
/* 1338 */       OID masterOid = msg.getSubject();
/* 1339 */       Namespace namespace = msg.getNamespace();
/*      */ 
/* 1342 */       Entity subObj = EntityManager.getEntityByNamespace(masterOid, namespace);
/* 1343 */       if (subObj == null) {
/* 1344 */         Log.error("SaveSubObjHook: could not find sub object for masterOid " + masterOid);
/* 1345 */         Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(false));
/* 1346 */         return true;
/*      */       }
/*      */ 
/* 1349 */       if (!subObj.getPersistenceFlag()) {
/* 1350 */         Log.error("SaveSubObjHook: ignoring save of non-persistent sub-object oid=" + masterOid + " namespace=" + namespace);
/* 1351 */         Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(false));
/* 1352 */         return true;
/*      */       }
/*      */ 
/* 1356 */       if (Log.loggingDebug)
/* 1357 */         Log.debug("SaveSubObjHook: saving object, subOid=" + subObj.getOid());
/* 1358 */       Engine.getPersistenceManager().persistEntity(subObj);
/*      */ 
/* 1360 */       if (Log.loggingDebug)
/* 1361 */         Log.debug("SaveSubObjHook: saved object subOid=" + subObj.getOid());
/* 1362 */       Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(true));
/*      */ 
/* 1364 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SubObjData
/*      */   {
/* 1311 */     public Hook dependencyHook = null;
/*      */ 
/* 1316 */     LinkedList<Namespace> namespaces = null;
/*      */ 
/*      */     public SubObjData()
/*      */     {
/*      */     }
/*      */ 
/*      */     public SubObjData(Namespace namespace, Hook dependencyHook)
/*      */     {
/* 1289 */       this.namespaces = new LinkedList();
/* 1290 */       if (namespace != null)
/* 1291 */         this.namespaces.add(namespace);
/* 1292 */       this.dependencyHook = dependencyHook;
/*      */     }
/*      */ 
/*      */     public SubObjData(LinkedList<Namespace> namespaces, Hook dependencyHook)
/*      */     {
/* 1301 */       if (namespaces != null)
/* 1302 */         this.namespaces = new LinkedList(namespaces);
/*      */       else
/* 1304 */         this.namespaces = new LinkedList();
/* 1305 */       this.dependencyHook = dependencyHook;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class GenerateSubObjectHook
/*      */     implements Hook
/*      */   {
/* 1268 */     public EnginePlugin plugin = null;
/*      */ 
/*      */     public GenerateSubObjectHook(EnginePlugin plugin)
/*      */     {
/* 1222 */       this.plugin = plugin;
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1234 */       ObjectManagerClient.GenerateSubObjectMessage msg = (ObjectManagerClient.GenerateSubObjectMessage)m;
/* 1235 */       Template template = msg.getTemplate();
/* 1236 */       Namespace namespace = msg.getNamespace();
/* 1237 */       OID masterOid = msg.getSubject();
/* 1238 */       if (masterOid == null) {
/* 1239 */         Log.error("GenerateSubObjectHook: no master oid");
/* 1240 */         return false;
/*      */       }
/* 1242 */       EnginePlugin.SubObjData subObjData = generateSubObject(template, namespace, masterOid);
/* 1243 */       Entity newObj = EntityManager.getEntityByNamespace(masterOid, namespace);
/* 1244 */       if (newObj == null) {
/* 1245 */         throw new RuntimeException("could not find newly created subobject, oid=" + masterOid + ", namespace " + namespace);
/*      */       }
/*      */ 
/* 1249 */       this.plugin.sendSubObjectResponse(m, masterOid, namespace, subObjData.namespaces, subObjData.dependencyHook);
/*      */ 
/* 1254 */       return true;
/*      */     }
/*      */ 
/*      */     public abstract EnginePlugin.SubObjData generateSubObject(Template paramTemplate, Namespace paramNamespace, OID paramOID);
/*      */   }
/*      */ 
/*      */   class SubPersistenceHook
/*      */     implements Hook
/*      */   {
/*      */     SubPersistenceHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/* 1173 */       ObjectManagerClient.SetPersistenceMessage msg = (ObjectManagerClient.SetPersistenceMessage)m;
/* 1174 */       OID masterOid = msg.getSubject();
/* 1175 */       Namespace namespace = msg.getNamespace();
/* 1176 */       Boolean persistVal = msg.getPersistVal();
/*      */ 
/* 1178 */       if (Log.loggingDebug) {
/* 1179 */         Log.debug("SubPersistenceHook: masterOid=" + masterOid + ", namespace=" + namespace);
/*      */       }
/*      */ 
/* 1182 */       Entity subObj = EntityManager.getEntityByNamespace(masterOid, namespace);
/* 1183 */       if (subObj == null) {
/* 1184 */         Log.error("SubPersistenceHook: could not find sub object");
/* 1185 */         Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(false));
/*      */       }
/*      */ 
/* 1188 */       if (subObj.getPersistenceFlag() == persistVal.booleanValue()) {
/* 1189 */         Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(true));
/* 1190 */         return true;
/*      */       }
/*      */ 
/* 1194 */       subObj.setPersistenceFlag(persistVal.booleanValue());
/* 1195 */       if (Log.loggingDebug)
/* 1196 */         Log.debug("SubPersistenceHook: masterOid=" + masterOid + ", set persist flag on subOid" + subObj.getOid() + ", to val=" + persistVal);
/* 1197 */       if (persistVal.booleanValue()) {
/* 1198 */         Engine.getPersistenceManager().setDirty(subObj);
/* 1199 */         Log.debug("SubPersistenceHook: set subobject dirty");
/*      */       }
/*      */ 
/* 1202 */       if (!persistVal.booleanValue()) {
/* 1203 */         Engine.getDatabase().deleteObjectData(masterOid, namespace);
/*      */       }
/*      */ 
/* 1207 */       Engine.getAgent().sendBooleanResponse(m, Boolean.valueOf(true));
/* 1208 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class TransferFilter extends MessageTypeFilter
/*      */   {
/*      */     public TransferFilter()
/*      */     {
/*  941 */       addType(EnginePlugin.MSG_TYPE_TRANSFER_OBJECT);
/*      */     }
/*      */ 
/*      */     public boolean matchRemaining(Message msg)
/*      */     {
/*  951 */       if ((msg instanceof EnginePlugin.TransferObjectMessage)) {
/*  952 */         EnginePlugin.TransferObjectMessage transferMsg = (EnginePlugin.TransferObjectMessage)msg;
/*  953 */         Map propMap = transferMsg.getPropMap();
/*  954 */         return matchesMap(propMap, msg);
/*      */       }
/*      */ 
/*  957 */       return false;
/*      */     }
/*      */ 
/*      */     public abstract boolean matchesMap(Map paramMap, Message paramMessage);
/*      */   }
/*      */ 
/*      */   public static abstract interface SaveHook
/*      */   {
/*      */     public abstract void onSave(Entity paramEntity, Namespace paramNamespace);
/*      */   }
/*      */ 
/*      */   public static abstract interface DeleteHook
/*      */   {
/*      */     public abstract void onDelete(Entity paramEntity);
/*      */ 
/*      */     public abstract void onDelete(OID paramOID, Namespace paramNamespace);
/*      */   }
/*      */ 
/*      */   public static abstract interface UnloadHook
/*      */   {
/*      */     public abstract void onUnload(Entity paramEntity);
/*      */   }
/*      */ 
/*      */   public static abstract interface LoadHook
/*      */   {
/*      */     public abstract void onLoad(Entity paramEntity);
/*      */   }
/*      */ 
/*      */   class PoolMessageHandler
/*      */     implements MessageCallback, ThreadFactory
/*      */   {
/*  561 */     protected final int MAX_THREADS = 10;
/*      */     protected ExecutorService executor;
/*  563 */     private int threadCount = 1;
/*      */ 
/*      */     PoolMessageHandler() {
/*  566 */       this.executor = Executors.newFixedThreadPool(10, this);
/*      */     }
/*      */ 
/*      */     public void handleMessage(Message msg, int flags)
/*      */     {
/*  574 */       this.executor.execute(new EnginePlugin.QueuedMessage(EnginePlugin.this, msg, flags));
/*      */     }
/*      */ 
/*      */     public Thread newThread(Runnable runnable)
/*      */     {
/*  579 */       return new Thread(runnable, EnginePlugin.this.getName() + "-" + this.threadCount++);
/*      */     }
/*      */   }
/*      */ 
/*      */   class DebugPoolMessageHandler extends EnginePlugin.PoolMessageHandler
/*      */   {
/*  483 */     private Set<Future<?>> workers = new HashSet();
/*  484 */     private long lastThreadDump = 0L;
/*  485 */     private final long THREAD_DUMP_TIMER = 30000L;
/*      */ 
/*      */     DebugPoolMessageHandler() {
/*  488 */       super();
/*      */     }
/*      */ 
/*      */     public void handleMessage(Message msg, int flags)
/*      */     {
/*  496 */       if (pruneWorkers())
/*      */       {
/*  502 */         Thread.yield();
/*      */       }
/*  504 */       if (pruneWorkers())
/*      */       {
/*  509 */         long now = System.currentTimeMillis();
/*  510 */         if ((this.lastThreadDump == 0L) || (now - this.lastThreadDump > 30000L)) {
/*  511 */           this.lastThreadDump = now;
/*      */ 
/*  513 */           Log.info("Exhausted thread worker pool for PoolMessageHandler");
/*  514 */           StringBuilder sb = new StringBuilder();
/*  515 */           Engine.dumpAllThreadStacks(sb, true);
/*  516 */           Log.info(sb.toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  521 */       synchronized (this.workers) {
/*  522 */         Future future = this.executor.submit(new EnginePlugin.QueuedMessage(EnginePlugin.this, msg, flags));
/*  523 */         this.workers.add(future);
/*      */       }
/*      */     }
/*      */ 
/*      */     private boolean pruneWorkers()
/*      */     {
/*  534 */       synchronized (this.workers) {
/*  535 */         Iterator iterator = this.workers.iterator();
/*  536 */         while (iterator.hasNext()) {
/*  537 */           Future worker = (Future)iterator.next();
/*  538 */           if (worker.isDone())
/*      */           {
/*      */             try {
/*  541 */               worker.get();
/*      */             } catch (InterruptedException e) {
/*  543 */               Log.warn("Encountered InterruptedException on worker that was done: " + e);
/*      */             } catch (ExecutionException e) {
/*  545 */               Log.error("Encountered ExecutionException on worker that was done: " + e);
/*      */             }
/*  547 */             iterator.remove();
/*      */           }
/*      */         }
/*  550 */         return this.workers.size() >= 10;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class QueuedMessage
/*      */     implements Runnable
/*      */   {
/*      */     Message message;
/*      */     int flags;
/*      */ 
/*      */     QueuedMessage(Message message, int flags)
/*      */     {
/*  450 */       this.message = message;
/*  451 */       this.flags = flags;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/*  460 */         EnginePlugin.this.handleMessageImpl(this.message, this.flags);
/*      */       }
/*      */       catch (Exception ex) {
/*  463 */         Log.exception("handleMessageImpl", ex);
/*  464 */         if ((this.flags & 0x1) != 0)
/*  465 */           Engine.getAgent().sendResponse(new ExceptionResponseMessage(this.message, ex));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class DumpAllStacksMessageHook
/*      */     implements Hook
/*      */   {
/*      */     DumpAllStacksMessageHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  335 */       if (Log.loggingDebug) {
/*  336 */         Log.debug("DumpAllStacksMessageHook: received MSG_TYPE_DUMP_ALL_STACKS");
/*      */       }
/*  338 */       StringBuilder sb = new StringBuilder();
/*  339 */       Engine.dumpAllThreadStacks(sb, true);
/*  340 */       Log.info(sb.toString());
/*  341 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   class PluginStateMessageHook
/*      */     implements Hook
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     PluginStateMessageHook()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean processMessage(Message m, int flags)
/*      */     {
/*  302 */       EnginePlugin.PluginStateMessage msg = (EnginePlugin.PluginStateMessage)m;
/*  303 */       if (Log.loggingDebug) {
/*  304 */         Log.debug("PluginStateHook: got plugin status message for plugin: " + msg.getPluginName() + ", state=" + msg.getState() + ", msg=" + m);
/*      */       }
/*  306 */       EnginePlugin.this.pluginStateMap.put(msg.getPluginName(), msg.getState());
/*      */ 
/*  311 */       if (msg.getTargetSession() == null) {
/*  312 */         if (EnginePlugin.this.pluginState == "Available") {
/*  313 */           Log.debug("PluginStateHook: not a response msg, sending out a response");
/*  314 */           EnginePlugin.PluginStateMessage respMsg = new EnginePlugin.PluginStateMessage(EnginePlugin.this.getName(), EnginePlugin.this.pluginState);
/*      */ 
/*  316 */           respMsg.setTargetSession(msg.getSenderName());
/*  317 */           respMsg.setTargetPluginName(EnginePlugin.this.name);
/*  318 */           Engine.getAgent().sendBroadcast(respMsg);
/*      */         }
/*      */       }
/*      */       else {
/*  322 */         Log.debug("PluginStatusHook: is response message");
/*      */       }
/*  324 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface PluginActivateHook
/*      */   {
/*      */     public abstract void activate();
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.EnginePlugin
 * JD-Core Version:    0.6.0
 */