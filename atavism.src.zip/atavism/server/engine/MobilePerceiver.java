/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.util.Log;
/*     */ 
/*     */ public class MobilePerceiver<ElementType extends QuadTreeElement<ElementType>> extends Perceiver<ElementType>
/*     */ {
/*  84 */   ElementType element = null;
/*     */ 
/* 104 */   private int radius = 0;
/* 105 */   private Point lastUpdateLoc = null;
/*     */ 
/* 113 */   private int perceiverUpdateDistance = 5;
/*     */ 
/* 115 */   private float perceiverUpdateDistanceSquared = 25.0F;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public MobilePerceiver()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MobilePerceiver(ElementType elem)
/*     */   {
/*  19 */     setElement(elem);
/*     */   }
/*     */ 
/*     */   public MobilePerceiver(ElementType elem, int radius) {
/*  23 */     setElement(elem);
/*  24 */     setRadius(radius);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  28 */     return "[MobilePerceiver:" + hashCode() + " elem=" + this.element + " radius=" + this.radius + "]";
/*     */   }
/*     */ 
/*     */   public boolean overlaps(Geometry g)
/*     */   {
/*  36 */     if (this.element.getQuadNode() == null) {
/*  37 */       return false;
/*     */     }
/*  39 */     Point loc = this.element.getCurrentLoc();
/*  40 */     Geometry geom = new Geometry(loc.getX() - this.radius, loc.getX() + this.radius, loc.getZ() - this.radius, loc.getZ() + this.radius);
/*     */ 
/*  42 */     return geom.overlaps(g);
/*     */   }
/*     */ 
/*     */   public boolean contains(Geometry g)
/*     */   {
/*  47 */     if (this.element.getQuadNode() == null) {
/*  48 */       return false;
/*     */     }
/*  50 */     Point loc = this.element.getCurrentLoc();
/*  51 */     Geometry geom = new Geometry(loc.getX() - this.radius, loc.getX() + this.radius, loc.getZ() - this.radius, loc.getZ() + this.radius);
/*     */ 
/*  53 */     return geom.contains(g);
/*     */   }
/*     */ 
/*     */   public boolean shouldUpdateBasedOnLoc(Point loc)
/*     */   {
/*  65 */     if ((this.lastUpdateLoc == null) || (Point.distanceToSquared(loc, this.lastUpdateLoc) > this.perceiverUpdateDistanceSquared))
/*     */     {
/*  67 */       Point previousLastUpdateLoc = this.lastUpdateLoc;
/*  68 */       this.lastUpdateLoc = ((Point)loc.clone());
/*  69 */       if (Log.loggingDebug) {
/*  70 */         Log.debug("MobilePerceiver.shouldUpdateBasedOnLoc: returning true; loc " + loc + ", previousLastUpdateLoc " + previousLastUpdateLoc);
/*     */       }
/*  72 */       return true;
/*     */     }
/*     */ 
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   public ElementType getElement() {
/*  79 */     return this.element;
/*     */   }
/*     */   public void setElement(ElementType elem) {
/*  82 */     this.element = elem;
/*     */   }
/*     */ 
/*     */   public int getRadius()
/*     */   {
/*  87 */     return this.radius;
/*     */   }
/*     */   public void setRadius(int radius) {
/*  90 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public int getPerceiverUpdateDistance() {
/*  94 */     return this.perceiverUpdateDistance;
/*     */   }
/*     */ 
/*     */   public void setPerceiverUpdateDistance(int perceiverUpdateDistance) {
/*  98 */     this.perceiverUpdateDistance = perceiverUpdateDistance;
/*  99 */     this.perceiverUpdateDistanceSquared = (perceiverUpdateDistance * perceiverUpdateDistance);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.MobilePerceiver
 * JD-Core Version:    0.6.0
 */