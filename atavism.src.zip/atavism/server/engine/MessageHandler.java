package atavism.server.engine;

import atavism.server.network.AOByteBuffer;
import atavism.server.network.ClientConnection;

public abstract interface MessageHandler
{
  public abstract String getName();

  public abstract Event handleMessage(ClientConnection paramClientConnection, AOByteBuffer paramAOByteBuffer);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.MessageHandler
 * JD-Core Version:    0.6.0
 */