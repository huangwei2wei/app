/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.objects.Entity;
/*     */ import atavism.server.plugins.ObjectManagerClient;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class PersistenceManager extends Thread
/*     */ {
/*  40 */   Map<Namespace, EnginePlugin.SaveHook> saveHookMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/* 103 */   int intervalMS = 10000;
/*     */ 
/* 182 */   Lock lock = LockFactory.makeLock("PersistenceManagerLock");
/* 183 */   Set<Entity> dirtySet = new HashSet();
/*     */ 
/* 185 */   static final Logger log = new Logger("PersistenceManager");
/*     */ 
/* 188 */   boolean started = false;
/*     */ 
/*     */   public PersistenceManager()
/*     */   {
/*  28 */     super("PersistenceManager");
/*     */   }
/*     */ 
/*     */   public void registerSaveHook(Namespace namespace, EnginePlugin.SaveHook saveHook)
/*     */   {
/*  38 */     this.saveHookMap.put(namespace, saveHook);
/*     */   }
/*     */ 
/*     */   public void setDirty(Entity entity)
/*     */   {
/*  48 */     this.lock.lock();
/*     */     try {
/*  50 */       if (!this.started) {
/*  51 */         log.debug("setDirty: manager not started, starting..");
/*  52 */         start();
/*     */       }
/*  54 */       if (Log.loggingDebug) {
/*  55 */         log.debug("setDirty: setting dirty, entity=" + entity + " PersistenceFlag=" + entity.getPersistenceFlag());
/*     */       }
/*  57 */       if (entity.getPersistenceFlag())
/*  58 */         this.dirtySet.add(entity);
/*     */     }
/*     */     finally {
/*  61 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearDirty(Entity entity)
/*     */   {
/*  68 */     this.lock.lock();
/*     */     try {
/*  70 */       if (Log.loggingDebug)
/*  71 */         log.debug("clearDirty: clearing dirty, entity=" + entity);
/*  72 */       this.dirtySet.remove(entity);
/*     */     } finally {
/*  74 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isDirty(Entity entity)
/*     */   {
/*  81 */     this.lock.lock();
/*     */     try {
/*  83 */       boolean bool = this.dirtySet.contains(entity);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*  90 */     this.lock.lock();
/*     */     try {
/*  92 */       if (!this.started) {
/*  93 */         log.debug("starting");
/*  94 */         this.started = true;
/*  95 */         super.start();
/*     */       }
/*     */     } finally {
/*  98 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     while (true)
/*     */       try
/*     */       {
/* 108 */         persistEntities();
/* 109 */         Thread.sleep(this.intervalMS);
/*     */ 
/* 117 */         continue;
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 112 */         Log.exception("PersistenceManager", e);
/* 113 */         throw new RuntimeException("PersistenceManager", e);
/*     */       }
/*     */       catch (Exception e) {
/* 116 */         Log.exception("PersistenceManager", e);
/*     */       } 
/*     */   }
/*     */ 
/*     */   void persistEntities() {
/* 129 */     this.lock.lock();
/*     */     Set dirtyCopy;
/*     */     try {
/* 131 */       log.debug("persistEntities: persisting " + this.dirtySet.size() + " entities");
/*     */ 
/* 133 */       dirtyCopy = new HashSet(this.dirtySet);
/* 134 */       this.dirtySet.clear();
/*     */     } finally {
/* 136 */       this.lock.unlock();
/*     */     }
/*     */ 
/* 139 */     for (Entity entity : dirtyCopy) {
/* 140 */       persistEntity(entity);
/*     */     }
/* 142 */     log.debug("persistEntities: done persisting");
/*     */   }
/*     */ 
/*     */   public void persistEntity(String persistenceKey, Entity e)
/*     */   {
/* 147 */     if (e.isDeleted()) {
/* 148 */       return;
/*     */     }
/* 150 */     clearDirty(e);
/*     */ 
/* 152 */     callSaveHooks(e);
/*     */ 
/* 154 */     if (!ObjectManagerClient.saveObjectData(persistenceKey, e, e.getNamespace()))
/*     */     {
/* 156 */       log.error("could not persist object: " + e);
/* 157 */       setDirty(e);
/*     */     } else {
/* 159 */       log.debug("persistEntity: saved entity: " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void persistEntity(Entity e) {
/* 163 */     persistEntity(null, e);
/*     */   }
/*     */ 
/*     */   public void callSaveHooks(Entity e) {
/* 167 */     Namespace namespace = e.getNamespace();
/* 168 */     if (namespace != null)
/*     */     {
/* 170 */       EnginePlugin.SaveHook cb = (EnginePlugin.SaveHook)this.saveHookMap.get(namespace);
/* 171 */       if (cb != null)
/*     */         try
/*     */         {
/* 174 */           cb.onSave(e, namespace);
/*     */         } catch (Exception ex) {
/* 176 */           throw new RuntimeException("onSave", ex);
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.PersistenceManager
 * JD-Core Version:    0.6.0
 */