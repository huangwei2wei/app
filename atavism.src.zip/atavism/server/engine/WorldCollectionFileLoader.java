/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.objects.Boundary;
/*     */ import atavism.server.objects.Color;
/*     */ import atavism.server.objects.DisplayContext;
/*     */ import atavism.server.objects.DisplayContext.Submesh;
/*     */ import atavism.server.objects.FogRegionConfig;
/*     */ import atavism.server.objects.Instance;
/*     */ import atavism.server.objects.LightData;
/*     */ import atavism.server.objects.Region;
/*     */ import atavism.server.objects.RegionConfig;
/*     */ import atavism.server.objects.Road;
/*     */ import atavism.server.objects.RoadRegionConfig;
/*     */ import atavism.server.objects.SoundData;
/*     */ import atavism.server.objects.SoundRegionConfig;
/*     */ import atavism.server.objects.SpawnData;
/*     */ import atavism.server.objects.Template;
/*     */ import atavism.server.objects.TerrainDecalData;
/*     */ import atavism.server.pathing.PathData;
/*     */ import atavism.server.pathing.PathInfo;
/*     */ import atavism.server.pathing.PathObject;
/*     */ import atavism.server.pathing.PathPolygon;
/*     */ import atavism.server.plugins.ObjectManagerClient;
/*     */ import atavism.server.plugins.WorldManagerClient;
/*     */ import atavism.server.plugins.WorldManagerClient.NewRegionMessage;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.XMLHelper;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public class WorldCollectionFileLoader extends WorldFileLoader
/*     */   implements WorldCollectionLoader
/*     */ {
/*     */   private static int DEFAULT_SOUND_PERCEPTION_RADIUS;
/*     */ 
/*     */   public WorldCollectionFileLoader(String worldCollectionFileName, WorldLoaderOverride override)
/*     */   {
/*  28 */     super(worldCollectionFileName, override);
/*     */   }
/*     */ 
/*     */   public boolean generate(Instance instance)
/*     */   {
/*  33 */     Node worldObjColNode = XMLHelper.getMatchingChild(this.worldDoc, "WorldObjectCollection");
/*     */ 
/*  35 */     if (worldObjColNode == null) {
/*  36 */       Log.error("No <WorldObjectCollection>");
/*  37 */       return false;
/*     */     }
/*     */ 
/*  41 */     String version = XMLHelper.getAttribute(worldObjColNode, "Version");
/*  42 */     if ((version == null) || ((!version.equals("2")) && (!version.equals("2.0")))) {
/*  43 */       Log.error("Unsupported version number in file " + this.worldFileName + ": " + version);
/*     */ 
/*  45 */       return false;
/*     */     }
/*  47 */     Log.debug("World collection '" + this.worldFileName + "' version: " + version);
/*     */ 
/*  50 */     List pointLightNodes = XMLHelper.getMatchingChildren(worldObjColNode, "PointLight");
/*  51 */     for (Node pointLightNode : pointLightNodes) {
/*  52 */       processPointLight(instance, pointLightNode);
/*     */     }
/*     */ 
/*  63 */     List boundaryNodes = XMLHelper.getMatchingChildren(worldObjColNode, "Boundary");
/*  64 */     for (Node boundaryNode : boundaryNodes) {
/*  65 */       processBoundary(instance, boundaryNode);
/*     */     }
/*     */ 
/*  69 */     List roadNodes = XMLHelper.getMatchingChildren(worldObjColNode, "Road");
/*  70 */     if (Log.loggingDebug)
/*  71 */       Log.debug("Road count=" + roadNodes.size());
/*  72 */     for (Node roadNode : roadNodes) {
/*  73 */       Road road = processRoad(roadNode);
/*  74 */       instance.getRoadConfig().addRoad(road);
/*  75 */       if (Log.loggingDebug) {
/*  76 */         Log.debug("Road: " + road + ", config=" + instance.getRoadConfig());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  81 */     LightData globalDirLight = instance.getGlobalDirectionalLight();
/*  82 */     if (Log.loggingDebug)
/*  83 */       Log.debug("Global dir light: " + globalDirLight);
/*  84 */     if (globalDirLight != null) {
/*  85 */       RegionConfig lightRegionConfig = new RegionConfig(LightData.DirLightRegionType);
/*     */ 
/*  87 */       lightRegionConfig.setProperty("orient", globalDirLight.getOrientation());
/*     */ 
/*  89 */       lightRegionConfig.setProperty("specular", globalDirLight.getSpecular());
/*     */ 
/*  91 */       lightRegionConfig.setProperty("diffuse", globalDirLight.getDiffuse());
/*     */ 
/*  93 */       lightRegionConfig.setProperty("name", "dirLight_GLOBAL");
/*  94 */       instance.getGlobalRegion().addConfig(lightRegionConfig);
/*     */     }
/*     */ 
/*  98 */     Color globalAmbientLight = instance.getGlobalAmbientLight();
/*  99 */     if (Log.loggingDebug)
/* 100 */       Log.debug("Global ambient light: " + globalAmbientLight);
/* 101 */     if (globalAmbientLight != null) {
/* 102 */       RegionConfig ambientConfig = new RegionConfig(LightData.AmbientLightRegionType);
/* 103 */       ambientConfig.setProperty("color", globalAmbientLight);
/* 104 */       instance.getGlobalRegion().addConfig(ambientConfig);
/*     */     }
/*     */ 
/* 108 */     List markerNodes = XMLHelper.getMatchingChildren(worldObjColNode, "Waypoint");
/* 109 */     for (Node markerNode : markerNodes) {
/* 110 */       processMarker(instance, markerNode);
/*     */     }
/*     */ 
/* 114 */     List terrainDecals = XMLHelper.getMatchingChildren(worldObjColNode, "TerrainDecal");
/*     */ 
/* 116 */     for (Node terrainDecal : terrainDecals) {
/* 117 */       String decalName = XMLHelper.getAttribute(terrainDecal, "Name");
/*     */ 
/* 119 */       String imageName = XMLHelper.getAttribute(terrainDecal, "ImageName");
/*     */ 
/* 121 */       int posX = (int)Math.round(Double.parseDouble(XMLHelper.getAttribute(terrainDecal, "PositionX")));
/*     */ 
/* 124 */       int posZ = (int)Math.round(Double.parseDouble(XMLHelper.getAttribute(terrainDecal, "PositionZ")));
/*     */ 
/* 127 */       float sizeX = Float.parseFloat(XMLHelper.getAttribute(terrainDecal, "SizeX"));
/*     */ 
/* 129 */       float sizeZ = Float.parseFloat(XMLHelper.getAttribute(terrainDecal, "SizeZ"));
/*     */ 
/* 131 */       float rotation = Float.parseFloat(XMLHelper.getAttribute(terrainDecal, "Rotation"));
/*     */ 
/* 134 */       int priority = Integer.parseInt(XMLHelper.getAttribute(terrainDecal, "Priority"));
/*     */ 
/* 136 */       int perceptionRadius = 0;
/* 137 */       String radiusStr = XMLHelper.getAttribute(terrainDecal, "PerceptionRadius");
/*     */ 
/* 139 */       if (radiusStr != null)
/* 140 */         perceptionRadius = (int)Float.parseFloat(radiusStr);
/* 141 */       TerrainDecalData data = new TerrainDecalData(imageName, posX, posZ, sizeX, sizeZ, rotation, priority);
/*     */ 
/* 144 */       Template overrideTemplate = new Template();
/* 145 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE, WorldManagerClient.TEMPL_OBJECT_TYPE_TERRAIN_DECAL);
/*     */ 
/* 148 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME, decalName);
/*     */ 
/* 151 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instance.getOid());
/*     */ 
/* 153 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, new Point(posX, 0.0F, posZ));
/*     */ 
/* 156 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_SCALE, new AOVector(1.0F, 1.0F, 1.0F));
/*     */ 
/* 158 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_PERCEPTION_RADIUS, Integer.valueOf(perceptionRadius));
/*     */ 
/* 161 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_TERRAIN_DECAL_DATA, data);
/*     */ 
/* 165 */       OID objOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", overrideTemplate);
/*     */ 
/* 167 */       if (objOid != null) {
/* 168 */         WorldManagerClient.spawn(objOid);
/*     */       }
/*     */       else {
/* 171 */         Log.error("Could not create decal=" + decalName + " imageName=" + imageName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 178 */     processWorldCollections(instance, worldObjColNode);
/*     */ 
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */   private void processPointLight(Instance instance, Node pointLightNode) {
/* 184 */     String lightName = XMLHelper.getAttribute(pointLightNode, "Name");
/* 185 */     String attenuationRange = XMLHelper.getAttribute(pointLightNode, "AttenuationRange");
/* 186 */     String attenuationConstant = XMLHelper.getAttribute(pointLightNode, "AttenuationConstant");
/* 187 */     String attenuationLinear = XMLHelper.getAttribute(pointLightNode, "AttenuationLinear");
/* 188 */     String attenuationQuadratic = XMLHelper.getAttribute(pointLightNode, "AttenuationQuadratic");
/* 189 */     Point lightLoc = getPoint(XMLHelper.getMatchingChild(pointLightNode, "Position"));
/* 190 */     Color specular = getColor(XMLHelper.getMatchingChild(pointLightNode, "Specular"));
/* 191 */     Color diffuse = getColor(XMLHelper.getMatchingChild(pointLightNode, "Diffuse"));
/*     */ 
/* 193 */     LightData lightData = new LightData();
/* 194 */     lightData.setName(lightName);
/* 195 */     lightData.setAttenuationRange(Float.parseFloat(attenuationRange));
/* 196 */     lightData.setAttenuationConstant(Float.parseFloat(attenuationConstant));
/* 197 */     lightData.setAttenuationLinear(Float.parseFloat(attenuationLinear));
/* 198 */     lightData.setAttenuationQuadradic(Float.parseFloat(attenuationQuadratic));
/* 199 */     lightData.setSpecular(specular);
/* 200 */     lightData.setDiffuse(diffuse);
/* 201 */     lightData.setInitLoc(lightLoc);
/* 202 */     if (Log.loggingDebug) {
/* 203 */       Log.debug("LightData=" + lightData);
/*     */     }
/*     */ 
/* 206 */     if (this.worldLoaderOverride.adjustLightData(this.worldFileName, lightName, lightData))
/*     */     {
/* 208 */       OID lightOid = ObjectManagerClient.generateLight(instance.getOid(), lightData);
/*     */ 
/* 210 */       if (Log.loggingDebug) {
/* 211 */         Log.debug("Generated light, oid=" + lightOid);
/*     */       }
/*     */ 
/* 214 */       boolean rv = WorldManagerClient.spawn(lightOid).intValue() >= 0;
/* 215 */       if (Log.loggingDebug)
/* 216 */         Log.debug("Light spawn rv=" + rv);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean processStaticObject(Instance instance, Node objNode) {
/* 221 */     String name = XMLHelper.getAttribute(objNode, "Name");
/* 222 */     String mesh = XMLHelper.getAttribute(objNode, "Mesh");
/*     */ 
/* 224 */     if (Log.loggingDebug)
/* 225 */       Log.debug("StaticObject " + name + " mesh '" + mesh + "'");
/* 226 */     Node posNode = XMLHelper.getMatchingChild(objNode, "Position");
/* 227 */     if (posNode == null) {
/* 228 */       Log.error("No <Position> node, name=" + name);
/* 229 */       return false;
/*     */     }
/* 231 */     Point loc = getPoint(posNode);
/*     */ 
/* 233 */     int perceptionRadius = 0;
/* 234 */     String radiusStr = XMLHelper.getAttribute(objNode, "PerceptionRadius");
/*     */ 
/* 236 */     if (radiusStr != null) {
/* 237 */       perceptionRadius = (int)Float.parseFloat(radiusStr);
/*     */     }
/* 239 */     Node scaleNode = XMLHelper.getMatchingChild(objNode, "Scale");
/* 240 */     AOVector scale = getVector(scaleNode);
/*     */ 
/* 242 */     Node rotNode = XMLHelper.getMatchingChild(objNode, "Rotation");
/* 243 */     Quaternion orient = null;
/* 244 */     if (rotNode != null) {
/* 245 */       float rotation = getPoint(rotNode).getY();
/* 246 */       orient = Quaternion.fromAngleAxisDegrees(rotation, new AOVector(0.0F, 1.0F, 0.0F));
/*     */     }
/*     */     else {
/* 249 */       Node orientNode = XMLHelper.getMatchingChild(objNode, "Orientation");
/* 250 */       orient = getQuaternion(orientNode);
/*     */     }
/*     */ 
/* 254 */     boolean castShadow = false;
/* 255 */     boolean receiveShadow = false;
/* 256 */     String shadowStr = XMLHelper.getAttribute(objNode, "CastShadows");
/*     */ 
/* 258 */     if (shadowStr != null)
/* 259 */       castShadow = shadowStr.equals("True");
/* 260 */     shadowStr = XMLHelper.getAttribute(objNode, "ReceiveShadows");
/* 261 */     if (shadowStr != null) {
/* 262 */       receiveShadow = shadowStr.equals("True");
/*     */     }
/*     */ 
/* 265 */     DisplayContext dc = new DisplayContext(mesh);
/* 266 */     dc.setCastShadow(castShadow);
/* 267 */     dc.setReceiveShadow(receiveShadow);
/* 268 */     Node subMeshNode = XMLHelper.getMatchingChild(objNode, "SubMeshes");
/* 269 */     if (subMeshNode != null) {
/* 270 */       List subMeshInfoList = XMLHelper.getMatchingChildren(subMeshNode, "SubMeshInfo");
/*     */ 
/* 272 */       for (Node subMeshInfo : subMeshInfoList) {
/* 273 */         String subMeshInfoName = XMLHelper.getAttribute(subMeshInfo, "Name");
/*     */ 
/* 275 */         String subMeshInfoMaterial = XMLHelper.getAttribute(subMeshInfo, "MaterialName");
/*     */ 
/* 277 */         if (Log.loggingDebug) {
/* 278 */           Log.debug("Submesh name=" + subMeshInfoName + ", material=" + subMeshInfoMaterial);
/*     */         }
/* 280 */         if (!XMLHelper.getAttribute(subMeshInfo, "Show").equals("True"))
/*     */         {
/* 282 */           Log.warn("SubMesh is not visible - skipping, name=" + subMeshInfoName);
/* 283 */           continue;
/*     */         }
/* 285 */         dc.addSubmesh(new DisplayContext.Submesh(subMeshInfoName, subMeshInfoMaterial));
/*     */       }
/*     */     }
/*     */ 
/* 289 */     Node pathObjectsNode = XMLHelper.getMatchingChild(objNode, "PathData");
/* 290 */     PathData pathData = null;
/* 291 */     if (pathObjectsNode != null) {
/* 292 */       int pathVersion = (int)Float.parseFloat(XMLHelper.getAttribute(pathObjectsNode, "version"));
/* 293 */       List pathObjects = new LinkedList();
/* 294 */       List pathObjectNodes = XMLHelper.getMatchingChildren(pathObjectsNode, "PathObject");
/*     */ 
/* 296 */       for (Node pathObjectNode : pathObjectNodes) {
/* 297 */         String modelName = XMLHelper.getAttribute(pathObjectNode, "modelName");
/* 298 */         String type = XMLHelper.getAttribute(pathObjectNode, "type");
/* 299 */         int firstTerrainIndex = (int)Float.parseFloat(XMLHelper.getAttribute(pathObjectNode, "firstTerrainIndex"));
/* 300 */         List boundingPolygons = processPathPolygons("BoundingPolygon", pathObjectNode);
/*     */ 
/* 302 */         assert (boundingPolygons.size() == 1);
/* 303 */         List polygons = processPathPolygons("PathPolygons", pathObjectNode);
/* 304 */         List portals = processPathArcs("PathPortals", pathObjectNode);
/* 305 */         List arcs = processPathArcs("PathArcs", pathObjectNode);
/* 306 */         PathPolygon boundingPolygon = (PathPolygon)boundingPolygons.get(0);
/* 307 */         pathObjects.add(new PathObject(modelName, type, firstTerrainIndex, boundingPolygon, polygons, portals, arcs));
/* 308 */         if (Log.loggingDebug) {
/* 309 */           Log.debug("Path object model name =" + modelName + ", bounding polygon = " + boundingPolygon + ", polygon count = " + polygons.size() + ", portals count = " + portals.size() + ", arcs count = " + arcs.size());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 315 */       if (pathObjects.size() > 0)
/* 316 */         pathData = new PathData(pathVersion, pathObjects);
/* 317 */       if (Log.loggingDebug)
/* 318 */         Log.debug("Read PathData for model object " + name);
/*     */     }
/* 320 */     if (Log.loggingDebug) {
/* 321 */       Log.debug("StaticObject name=" + name + " mesh=" + mesh + " loc=" + loc + " scale=" + scale + " orient=" + orient + " mesh=" + dc.getMeshFile() + " percRadius=" + perceptionRadius);
/*     */     }
/*     */ 
/* 326 */     List sounds = XMLHelper.getMatchingChildren(objNode, "Sound");
/*     */ 
/* 328 */     List soundData = getSoundDataList(sounds);
/*     */ 
/* 330 */     Node nameValuePairsNode = XMLHelper.getMatchingChild(objNode, "NameValuePairs");
/*     */ 
/* 333 */     String anim = null;
/* 334 */     Template overrideTemplate = new Template();
/*     */ 
/* 336 */     if (nameValuePairsNode != null) {
/* 337 */       Map props = XMLHelper.nameValuePairsHelper(nameValuePairsNode);
/*     */ 
/* 339 */       if (props.containsKey("animation"))
/* 340 */         anim = (String)props.get("animation");
/* 341 */       for (Map.Entry entry : props.entrySet()) {
/* 342 */         overrideTemplate.put(Namespace.WORLD_MANAGER, (String)entry.getKey(), (Serializable)entry.getValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 347 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME, name);
/* 348 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE, WorldManagerClient.TEMPL_OBJECT_TYPE_STRUCTURE);
/* 349 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_DISPLAY_CONTEXT, dc);
/* 350 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instance.getOid());
/* 351 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, loc);
/* 352 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_ORIENT, orient);
/* 353 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_SCALE, scale);
/* 354 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_PERCEPTION_RADIUS, Integer.valueOf(perceptionRadius));
/* 355 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_FOLLOWS_TERRAIN, Boolean.FALSE);
/*     */ 
/* 357 */     if (anim != null) {
/* 358 */       overrideTemplate.put(Namespace.WORLD_MANAGER, ":tmpl.anim", anim);
/*     */     }
/* 360 */     if (soundData.size() > 0) {
/* 361 */       overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_SOUND_DATA_LIST, (Serializable)soundData);
/*     */     }
/* 363 */     List partEffectNodes = XMLHelper.getMatchingChildren(objNode, "ParticleEffect");
/* 364 */     LinkedList particles = new LinkedList();
/* 365 */     for (Node partEffectNode : partEffectNodes) {
/* 366 */       LinkedList particleData = new LinkedList();
/* 367 */       String peName = XMLHelper.getAttribute(partEffectNode, "ParticleEffectName");
/* 368 */       String velScale = XMLHelper.getAttribute(partEffectNode, "VelocityScale");
/* 369 */       String particleScale = XMLHelper.getAttribute(partEffectNode, "ParticleScale");
/* 370 */       String attachName = XMLHelper.getAttribute(partEffectNode, "AttachmentPoint");
/* 371 */       particleData.add(peName);
/* 372 */       particleData.add(attachName);
/* 373 */       particleData.add(Float.valueOf(Float.parseFloat(velScale)));
/* 374 */       particleData.add(Float.valueOf(Float.parseFloat(particleScale)));
/* 375 */       particles.add(particleData);
/*     */     }
/* 377 */     if (!particles.isEmpty()) {
/* 378 */       overrideTemplate.put(Namespace.WORLD_MANAGER, "StaticParticles", particles);
/*     */     }
/* 380 */     if (this.worldLoaderOverride.adjustObjectTemplate(this.worldFileName, name, overrideTemplate))
/*     */     {
/* 382 */       OID objOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", overrideTemplate);
/*     */ 
/* 385 */       if (objOid != null) {
/* 386 */         WorldManagerClient.spawn(objOid);
/*     */       }
/*     */       else {
/* 389 */         Log.error("Could not create static object=" + name + " mesh=" + mesh + " loc=" + loc);
/*     */       }
/*     */ 
/* 393 */       if (pathData != null)
/* 394 */         instance.getPathInfo().getPathDictionary().put(name, pathData);
/*     */     }
/* 396 */     return true;
/*     */   }
/*     */ 
/*     */   private void processBoundary(Instance instance, Node boundaryNode)
/*     */   {
/* 402 */     String name = XMLHelper.getAttribute(boundaryNode, "Name");
/* 403 */     Boundary boundary = new Boundary(name);
/*     */ 
/* 407 */     String priS = XMLHelper.getAttribute(boundaryNode, "Priority");
/* 408 */     Integer pri = priS == null ? null : Integer.valueOf(Integer.parseInt(priS));
/*     */ 
/* 411 */     Node pointsNode = XMLHelper.getMatchingChild(boundaryNode, "PointCollection");
/* 412 */     List points = XMLHelper.getMatchingChildren(pointsNode, "Point");
/* 413 */     if (points == null) {
/* 414 */       Log.warn("No points for boundary, ignoring");
/* 415 */       return;
/*     */     }
/* 417 */     for (Node pointNode : points) {
/* 418 */       Point p = getPoint(pointNode);
/* 419 */       boundary.addPoint(p);
/*     */     }
/*     */ 
/* 423 */     Region region = new Region();
/* 424 */     region.setName(name);
/* 425 */     region.setPriority(pri);
/* 426 */     region.setBoundary(boundary);
/* 427 */     if (Log.loggingDebug) {
/* 428 */       Log.debug("processBoundary: new region=" + region);
/*     */     }
/* 430 */     Node nameValuePairsNode = XMLHelper.getMatchingChild(boundaryNode, "NameValuePairs");
/* 431 */     if (nameValuePairsNode != null) {
/* 432 */       region.setProperties(XMLHelper.nameValuePairsHelper(nameValuePairsNode));
/*     */     }
/*     */ 
/* 435 */     if (!this.worldLoaderOverride.adjustRegion(this.worldFileName, name, region))
/*     */     {
/* 437 */       return;
/*     */     }
/*     */ 
/* 440 */     List sounds = XMLHelper.getMatchingChildren(boundaryNode, "Sound");
/*     */ 
/* 442 */     List soundData = getSoundDataList(sounds);
/* 443 */     if (soundData.size() > 0) {
/* 444 */       SoundRegionConfig soundConfig = new SoundRegionConfig();
/* 445 */       soundConfig.setSoundData(soundData);
/* 446 */       if (this.worldLoaderOverride.adjustRegionConfig(this.worldFileName, name, region, soundConfig))
/*     */       {
/* 448 */         region.addConfig(soundConfig);
/*     */       }
/*     */     }
/*     */ 
/* 452 */     Node fogNode = getFogNode(boundaryNode);
/* 453 */     if (fogNode != null) {
/* 454 */       String nearS = XMLHelper.getAttribute(fogNode, "Near");
/* 455 */       String farS = XMLHelper.getAttribute(fogNode, "Far");
/*     */ 
/* 457 */       Node colorNode = XMLHelper.getMatchingChild(fogNode, "Color");
/* 458 */       String redS = XMLHelper.getAttribute(colorNode, "R");
/* 459 */       String greenS = XMLHelper.getAttribute(colorNode, "G");
/* 460 */       String blueS = XMLHelper.getAttribute(colorNode, "B");
/*     */ 
/* 462 */       int red = (int)(Float.parseFloat(redS) * 255.0F);
/* 463 */       int green = (int)(Float.parseFloat(greenS) * 255.0F);
/* 464 */       int blue = (int)(Float.parseFloat(blueS) * 255.0F);
/* 465 */       int near = (int)Float.parseFloat(nearS);
/* 466 */       int far = (int)Float.parseFloat(farS);
/* 467 */       FogRegionConfig fogConfig = new FogRegionConfig();
/* 468 */       fogConfig.setColor(new Color(red, green, blue));
/* 469 */       fogConfig.setNear(near);
/* 470 */       fogConfig.setFar(far);
/* 471 */       if (Log.loggingDebug)
/* 472 */         Log.debug("Fog region: " + fogConfig);
/* 473 */       if (this.worldLoaderOverride.adjustRegionConfig(this.worldFileName, name, region, fogConfig))
/*     */       {
/* 475 */         region.addConfig(fogConfig);
/*     */       }
/*     */     }
/*     */ 
/* 479 */     Node dirLightNode = XMLHelper.getMatchingChild(boundaryNode, "DirectionalLight");
/* 480 */     if (dirLightNode != null) {
/* 481 */       AOVector dir = getVector(XMLHelper.getMatchingChild(dirLightNode, "Direction"));
/* 482 */       Color diffuse = getColor(XMLHelper.getMatchingChild(dirLightNode, "Diffuse"));
/* 483 */       Color specular = getColor(XMLHelper.getMatchingChild(dirLightNode, "Specular"));
/* 484 */       RegionConfig regionConfig = new RegionConfig(LightData.DirLightRegionType);
/* 485 */       Quaternion orient = AOVector.UnitZ.getRotationTo(dir);
/* 486 */       if (orient == null) {
/* 487 */         if (Log.loggingDebug)
/* 488 */           Log.debug("Region light is near inverse, dir=" + dir);
/* 489 */         orient = new Quaternion(0.0F, 1.0F, 0.0F, 0.0F);
/*     */       }
/* 491 */       regionConfig.setProperty("orient", orient);
/* 492 */       regionConfig.setProperty("specular", specular);
/* 493 */       regionConfig.setProperty("diffuse", diffuse);
/* 494 */       String boundaryName = XMLHelper.getAttribute(boundaryNode, "Name");
/* 495 */       regionConfig.setProperty("name", "dirLight_" + boundaryName);
/* 496 */       if (this.worldLoaderOverride.adjustRegionConfig(this.worldFileName, name, region, regionConfig))
/*     */       {
/* 498 */         region.addConfig(regionConfig);
/* 499 */         if (Log.loggingDebug) {
/* 500 */           Log.debug("Added dir light region: specular=" + specular + " diffuse=" + diffuse + " dir=" + dir + " orient=" + orient);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 506 */     Node ambientNode = XMLHelper.getMatchingChild(boundaryNode, "AmbientLight");
/* 507 */     if (ambientNode != null) {
/* 508 */       Color ambientColor = getColor(XMLHelper.getMatchingChild(ambientNode, "Color"));
/* 509 */       RegionConfig regionConfig = new RegionConfig(LightData.AmbientLightRegionType);
/* 510 */       regionConfig.setProperty("color", ambientColor);
/* 511 */       if (this.worldLoaderOverride.adjustRegionConfig(this.worldFileName, name, region, regionConfig))
/*     */       {
/* 513 */         region.addConfig(regionConfig);
/* 514 */         Log.debug("Added ambient light region: color=" + ambientColor);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 519 */     Node waterNode = getWaterNode(boundaryNode);
/* 520 */     if (waterNode != null) {
/* 521 */       float height = Float.parseFloat(XMLHelper.getAttribute(waterNode, "Height"));
/* 522 */       String regionConfig = "<boundaries><boundary><name>" + name + "_WATER</name>";
/*     */ 
/* 524 */       regionConfig = regionConfig + "<points>";
/* 525 */       for (Point point : boundary.getPoints()) {
/* 526 */         regionConfig = regionConfig + "<point x=\"" + point.getX() + "\" y=\"" + point.getZ() + "\" />";
/*     */       }
/* 528 */       regionConfig = regionConfig + "</points>";
/*     */ 
/* 531 */       regionConfig = regionConfig + "<boundarySemantic type=\"WaterPlane\">";
/* 532 */       regionConfig = regionConfig + "<height>" + height + "</height>";
/* 533 */       regionConfig = regionConfig + "<name>" + name + "_WATERNAME</name>";
/* 534 */       regionConfig = regionConfig + "</boundarySemantic>";
/*     */ 
/* 537 */       regionConfig = regionConfig + "</boundary></boundaries>";
/*     */ 
/* 539 */       if (Log.loggingDebug)
/* 540 */         Log.debug("processBoundary: waterRegion: " + regionConfig);
/* 541 */       instance.addRegionConfig(regionConfig);
/*     */     }
/*     */ 
/* 549 */     List forestsNode = XMLHelper.getMatchingChildren(boundaryNode, "Forest");
/* 550 */     if (forestsNode != null) {
/* 551 */       for (Node forestNode : forestsNode) {
/* 552 */         String forestXML = processTreeBoundary(boundary.getPoints(), forestNode);
/* 553 */         if (Log.loggingDebug)
/* 554 */           Log.debug("processBoundary: Tree boundary: xml=" + forestXML);
/* 555 */         instance.addRegionConfig(forestXML);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 561 */     Node grassNode = XMLHelper.getMatchingChild(boundaryNode, "Grass");
/* 562 */     if (grassNode != null) {
/* 563 */       String grassXML = processGrassBoundary(boundary.getPoints(), grassNode);
/* 564 */       if (Log.loggingDebug)
/* 565 */         Log.debug("processBoundary: Grass boundary: xml=" + grassXML);
/* 566 */       instance.addRegionConfig(grassXML);
/*     */     }
/*     */ 
/* 569 */     Message msg = new WorldManagerClient.NewRegionMessage(instance.getOid(), region);
/*     */ 
/* 571 */     Engine.getAgent().sendBroadcast(msg);
/*     */ 
/* 573 */     instance.addRegion(region);
/*     */   }
/*     */ 
/*     */   private void processMarker(Instance instance, Node markerNode) {
/* 577 */     String name = XMLHelper.getAttribute(markerNode, "Name");
/* 578 */     Node posNode = XMLHelper.getMatchingChild(markerNode, "Position");
/* 579 */     Point loc = getPoint(posNode);
/*     */ 
/* 581 */     Node orientNode = XMLHelper.getMatchingChild(markerNode, "Orientation");
/* 582 */     Quaternion orient = getQuaternion(orientNode);
/* 583 */     if (Log.loggingDebug) {
/* 584 */       Log.debug("Marker " + name + ", loc=" + loc);
/*     */     }
/* 586 */     Template overrideTemplate = new Template();
/*     */ 
/* 588 */     Node nameValuePairsNode = XMLHelper.getMatchingChild(markerNode, "NameValuePairs");
/* 589 */     if (nameValuePairsNode != null) {
/* 590 */       Map props = XMLHelper.nameValuePairsHelper(nameValuePairsNode);
/*     */ 
/* 592 */       for (Map.Entry entry : props.entrySet()) {
/* 593 */         overrideTemplate.put(Namespace.WORLD_MANAGER, (String)entry.getKey(), (Serializable)entry.getValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 598 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME, name);
/* 599 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE, WorldManagerClient.TEMPL_OBJECT_TYPE_MARKER);
/* 600 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instance.getOid());
/* 601 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, loc);
/* 602 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_ORIENT, orient);
/*     */ 
/* 604 */     if (this.worldLoaderOverride.adjustObjectTemplate(this.worldFileName, name, overrideTemplate))
/*     */     {
/* 606 */       OID objOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", overrideTemplate);
/*     */ 
/* 608 */       if (objOid != null) {
/* 609 */         WorldManagerClient.spawn(objOid);
/*     */       }
/*     */       else {
/* 612 */         Log.error("Could not create marker=" + name + " worldFileName=" + this.worldFileName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 618 */     List partEffectNodes = XMLHelper.getMatchingChildren(markerNode, "ParticleEffect");
/* 619 */     for (Node partEffectNode : partEffectNodes) {
/* 620 */       processParticleEffect(instance, name, loc, orient, partEffectNode);
/*     */     }
/*     */ 
/* 624 */     List spawnGenNodes = XMLHelper.getMatchingChildren(markerNode, "SpawnGen");
/* 625 */     for (Node spawnGenNode : spawnGenNodes) {
/* 626 */       processSpawnGen(instance, name, loc, orient, nameValuePairsNode, spawnGenNode);
/*     */     }
/*     */ 
/* 634 */     List sounds = XMLHelper.getMatchingChildren(markerNode, "Sound");
/* 635 */     for (Node soundNode : sounds)
/* 636 */       processSound(instance, name, loc, soundNode);
/*     */   }
/*     */ 
/*     */   private void processParticleEffect(Instance instance, String markerName, Point loc, Quaternion orient, Node partEffectNode)
/*     */   {
/* 641 */     String peName = XMLHelper.getAttribute(partEffectNode, "ParticleEffectName");
/* 642 */     String velScale = XMLHelper.getAttribute(partEffectNode, "VelocityScale");
/* 643 */     String particleScale = XMLHelper.getAttribute(partEffectNode, "ParticleScale");
/*     */ 
/* 645 */     String objName = markerName + "-" + peName;
/* 646 */     Template overrideTemplate = new Template();
/* 647 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME, objName);
/* 648 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE, WorldManagerClient.TEMPL_OBJECT_TYPE_STRUCTURE);
/*     */ 
/* 650 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_DISPLAY_CONTEXT, new DisplayContext("tiny_cube.mesh"));
/*     */ 
/* 652 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instance.getOid());
/* 653 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, loc);
/* 654 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_ORIENT, orient);
/* 655 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_FOLLOWS_TERRAIN, Boolean.FALSE);
/*     */ 
/* 658 */     LinkedList particles = new LinkedList();
/* 659 */     LinkedList particleData = new LinkedList();
/* 660 */     particleData.add(peName);
/* 661 */     particleData.add("base");
/* 662 */     particleData.add(Float.valueOf(Float.parseFloat(velScale)));
/* 663 */     particleData.add(Float.valueOf(Float.parseFloat(particleScale)));
/* 664 */     particles.add(particleData);
/* 665 */     overrideTemplate.put(Namespace.WORLD_MANAGER, "StaticParticles", particles);
/*     */ 
/* 667 */     if (this.worldLoaderOverride.adjustObjectTemplate(this.worldFileName, objName, overrideTemplate))
/*     */     {
/* 669 */       OID fakeOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", overrideTemplate);
/*     */ 
/* 671 */       if (fakeOid != null) {
/* 672 */         WorldManagerClient.spawn(fakeOid);
/*     */       }
/*     */       else
/* 675 */         Log.error("Could not create object for particle system=" + markerName + " particle=" + peName + " loc=" + loc);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processSpawnGen(Instance instance, String markerName, Point loc, Quaternion orient, Node nameValuePairsNode, Node spawnGenNode)
/*     */   {
/* 682 */     String templateName = XMLHelper.getAttribute(spawnGenNode, "TemplateName");
/* 683 */     String spawnRadius = XMLHelper.getAttribute(spawnGenNode, "SpawnRadius");
/* 684 */     String numSpawns = XMLHelper.getAttribute(spawnGenNode, "NumSpawns");
/* 685 */     String respawnTime = XMLHelper.getAttribute(spawnGenNode, "RespawnTime");
/*     */ 
/* 687 */     Integer spawnRadiusVal = new Integer(0);
/* 688 */     Integer numSpawnsVal = new Integer(1);
/* 689 */     Integer respawnTimeVal = new Integer(0);
/*     */ 
/* 691 */     if (spawnRadius != null) {
/* 692 */       spawnRadiusVal = Integer.valueOf(Integer.parseInt(spawnRadius));
/*     */     }
/* 694 */     if (numSpawns != null)
/*     */     {
/* 696 */       numSpawnsVal = Integer.valueOf(Integer.parseInt(numSpawns));
/*     */     }
/* 698 */     if (respawnTime != null)
/*     */     {
/* 700 */       respawnTimeVal = Integer.valueOf(Integer.parseInt(respawnTime));
/*     */     }
/*     */ 
/* 703 */     SpawnData spawnData = new SpawnData(markerName, templateName, 1, "WEObjFactory", instance.getOid(), loc, orient, spawnRadiusVal, numSpawnsVal, respawnTimeVal);
/*     */ 
/* 708 */     if (nameValuePairsNode != null) {
/* 709 */       spawnData.setPropertyMap(XMLHelper.nameValuePairsHelper(nameValuePairsNode));
/*     */     }
/*     */ 
/* 712 */     if (this.worldLoaderOverride.adjustSpawnData(this.worldFileName, markerName, spawnData))
/*     */     {
/* 714 */       instance.addSpawnData(spawnData);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processSound(Instance instance, String markerName, Point markerLoc, Node soundNode) {
/* 718 */     String fileName = XMLHelper.getAttribute(soundNode, "Filename");
/* 719 */     String typeStr = XMLHelper.getAttribute(soundNode, "Type");
/* 720 */     NamedNodeMap attrMap = soundNode.getAttributes();
/* 721 */     Map propertyMap = new HashMap();
/* 722 */     for (int ii = 0; ii < attrMap.getLength(); ii++) {
/* 723 */       Node attr = attrMap.item(ii);
/* 724 */       String attrName = attr.getNodeName();
/* 725 */       if ((attrName.equals("Filename")) || (attrName.equals("Type")))
/*     */         continue;
/* 727 */       propertyMap.put(attrName, attr.getNodeValue());
/*     */     }
/*     */ 
/* 730 */     Template overrideTemplate = new Template();
/* 731 */     int perceptionRadius = DEFAULT_SOUND_PERCEPTION_RADIUS;
/* 732 */     String maxAtten = (String)propertyMap.get("MaxAttenuationDistance");
/* 733 */     if (maxAtten != null) {
/* 734 */       perceptionRadius = (int)Float.parseFloat(maxAtten);
/*     */     }
/*     */ 
/* 737 */     String objName = markerName + "-" + fileName;
/*     */ 
/* 740 */     DisplayContext fakeDC = new DisplayContext("tiny_cube.mesh");
/* 741 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE, WorldManagerClient.TEMPL_OBJECT_TYPE_POINT_SOUND);
/*     */ 
/* 744 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME, objName);
/*     */ 
/* 747 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_DISPLAY_CONTEXT, fakeDC);
/*     */ 
/* 749 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instance.getOid());
/*     */ 
/* 751 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, markerLoc);
/*     */ 
/* 753 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_SCALE, new AOVector(1.0F, 1.0F, 1.0F));
/*     */ 
/* 755 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_PERCEPTION_RADIUS, Integer.valueOf(perceptionRadius));
/*     */ 
/* 758 */     List soundList = new LinkedList();
/* 759 */     soundList.add(new SoundData(fileName, typeStr, propertyMap));
/* 760 */     overrideTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_SOUND_DATA_LIST, (Serializable)soundList);
/*     */ 
/* 764 */     if (this.worldLoaderOverride.adjustObjectTemplate(this.worldFileName, objName, overrideTemplate))
/*     */     {
/* 766 */       OID objOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", overrideTemplate);
/*     */ 
/* 768 */       if (objOid != null) {
/* 769 */         WorldManagerClient.spawn(objOid);
/*     */       }
/*     */       else
/* 772 */         Log.error("Could not create marker=" + markerName + " soundFileName=" + fileName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String processTreeBoundary(List<Point> points, Node forestNode)
/*     */   {
/* 780 */     String xml = "<boundaries><boundary>";
/*     */ 
/* 783 */     String name = XMLHelper.getAttribute(forestNode, "Name");
/* 784 */     xml = xml + "<name>" + name + "_FOREST</name>";
/* 785 */     if (Log.loggingDebug) {
/* 786 */       Log.debug("processTreeBoundary: name=" + name);
/*     */     }
/*     */ 
/* 789 */     xml = xml + "<points>";
/* 790 */     for (Point p : points) {
/* 791 */       xml = xml + "<point x=\"" + p.getX() + "\" y=\"" + p.getZ() + "\" />";
/*     */     }
/* 793 */     xml = xml + "</points>";
/*     */ 
/* 795 */     xml = xml + "<boundarySemantic type=\"SpeedTreeForest\">";
/*     */ 
/* 797 */     String seed = XMLHelper.getAttribute(forestNode, "Seed");
/* 798 */     xml = xml + "<seed>" + seed + "</seed>";
/* 799 */     if (Log.loggingDebug) {
/* 800 */       Log.debug("processTreeBoundary: seed=" + seed);
/*     */     }
/* 802 */     xml = xml + "<name>" + name + "</name>";
/*     */ 
/* 805 */     String windFile = XMLHelper.getAttribute(forestNode, "Filename");
/*     */ 
/* 807 */     xml = xml + "<windFilename>" + windFile + "</windFilename>";
/* 808 */     if (Log.loggingDebug) {
/* 809 */       Log.debug("processTreeBoundary: windFile=" + windFile);
/*     */     }
/*     */ 
/* 812 */     String windStr = XMLHelper.getAttribute(forestNode, "WindSpeed");
/*     */ 
/* 814 */     xml = xml + "<windStrength>" + windStr + "</windStrength>";
/* 815 */     if (Log.loggingDebug) {
/* 816 */       Log.debug("processTreeBoundary: windStrength=" + windStr);
/*     */     }
/*     */ 
/* 819 */     Node windDir = XMLHelper.getMatchingChild(forestNode, "WindDirection");
/* 820 */     String dirX = XMLHelper.getAttribute(windDir, "x");
/* 821 */     String dirY = XMLHelper.getAttribute(windDir, "y");
/* 822 */     String dirZ = XMLHelper.getAttribute(windDir, "z");
/* 823 */     xml = xml + "<windDirection x=\"" + dirX + "\" y=\"" + dirY + "\" z=\"" + dirZ + "\" />";
/*     */ 
/* 825 */     if (Log.loggingDebug) {
/* 826 */       Log.debug("processTreeBoundary: windDir: x=" + dirX + ",y=" + dirY + ",z=" + dirZ);
/*     */     }
/*     */ 
/* 829 */     List treeTypes = XMLHelper.getMatchingChildren(forestNode, "Tree");
/*     */ 
/* 835 */     if (treeTypes.isEmpty()) {
/* 836 */       Log.warn("processTreeBoundary: no trees in forest");
/* 837 */       return null;
/*     */     }
/*     */ 
/* 840 */     for (Node treeType : treeTypes) {
/* 841 */       String fileName = XMLHelper.getAttribute(treeType, "Filename");
/*     */ 
/* 843 */       xml = xml + "<treeType";
/* 844 */       xml = xml + " filename=\"" + fileName + "\"";
/* 845 */       if (Log.loggingDebug) {
/* 846 */         Log.debug("processTreeBoundary: TreeType Filename=" + fileName);
/*     */       }
/* 848 */       String scale = XMLHelper.getAttribute(treeType, "Scale");
/* 849 */       xml = xml + " size=\"" + scale + "\"";
/* 850 */       if (Log.loggingDebug) {
/* 851 */         Log.debug("processTreeBoundary: scale size=" + scale);
/*     */       }
/* 853 */       String scaleVariance = XMLHelper.getAttribute(treeType, "ScaleVariance");
/*     */ 
/* 855 */       xml = xml + " sizeVariance=\"" + scaleVariance + "\"";
/* 856 */       if (Log.loggingDebug) {
/* 857 */         Log.debug("processTreeBoundary: sizeVariance=" + scaleVariance);
/*     */       }
/* 859 */       String instances = XMLHelper.getAttribute(treeType, "Instances");
/*     */ 
/* 861 */       xml = xml + " numInstances=\"" + instances + "\" />";
/* 862 */       if (Log.loggingDebug)
/* 863 */         Log.debug("processTreeBoundary: instances=" + instances);
/*     */     }
/* 865 */     xml = xml + "</boundarySemantic></boundary></boundaries>";
/*     */ 
/* 867 */     return xml;
/*     */   }
/*     */ 
/*     */   protected String processGrassBoundary(List<Point> points, Node grassNode)
/*     */   {
/* 872 */     String xml = "<boundaries><boundary>";
/* 873 */     String name = XMLHelper.getAttribute(grassNode, "Name");
/* 874 */     xml = xml + "<name>" + name + "_GRASS</name>";
/* 875 */     if (Log.loggingDebug) {
/* 876 */       Log.debug("processTreeBoundary: name=" + name);
/*     */     }
/*     */ 
/* 879 */     xml = xml + "<points>";
/* 880 */     for (Point p : points) {
/* 881 */       xml = xml + "<point x=\"" + p.getX() + "\" y=\"" + p.getZ() + "\" />";
/*     */     }
/* 883 */     xml = xml + "</points>";
/* 884 */     xml = xml + "<boundarySemantic type=\"Vegetation\">";
/* 885 */     xml = xml + "<name>" + name + "</name>";
/*     */ 
/* 887 */     List plantTypes = XMLHelper.getMatchingChildren(grassNode, "PlantType");
/* 888 */     if (plantTypes == null) {
/* 889 */       throw new AORuntimeException("no plant types in a grass boundary");
/*     */     }
/* 891 */     for (Node plantTypeNode : plantTypes) {
/* 892 */       String numInstances = XMLHelper.getAttribute(plantTypeNode, "Instances");
/* 893 */       String imageName = XMLHelper.getAttribute(plantTypeNode, "ImageName");
/* 894 */       String colorMultLow = XMLHelper.getAttribute(plantTypeNode, "ColorMultLow");
/* 895 */       String colorMultHi = XMLHelper.getAttribute(plantTypeNode, "ColorMultHi");
/* 896 */       String scaleWidthLow = XMLHelper.getAttribute(plantTypeNode, "ScaleWidthLow");
/* 897 */       String scaleWidthHi = XMLHelper.getAttribute(plantTypeNode, "ScaleWidthHi");
/* 898 */       String scaleHeightLow = XMLHelper.getAttribute(plantTypeNode, "ScaleHeightLow");
/* 899 */       String scaleHeightHi = XMLHelper.getAttribute(plantTypeNode, "ScaleHeightHi");
/* 900 */       String windMagnitude = XMLHelper.getAttribute(plantTypeNode, "WindMagnitude");
/* 901 */       String red = XMLHelper.getAttribute(plantTypeNode, "R");
/* 902 */       String green = XMLHelper.getAttribute(plantTypeNode, "G");
/* 903 */       String blue = XMLHelper.getAttribute(plantTypeNode, "B");
/*     */ 
/* 906 */       xml = xml + "<PlantType numInstances=\"" + numInstances + "\" imageName=\"" + imageName + "\" atlasStartX=\"0\" atlasStartY=\"0\" atlasEndX=\"1\" atlasEndY=\"1\"" + " scaleWidthLow=\"" + scaleWidthLow + "\" scaleWidthHi=\"" + scaleWidthHi + "\" scaleHeightLow=\"" + scaleHeightLow + "\" scaleHeightHi=\"" + scaleHeightHi + "\" colorMultLow=\"" + colorMultLow + "\" colorMultHi=\"" + colorMultHi + "\" windMagnitude=\"" + windMagnitude + "\"><color r=\"" + red + "\" g=\"" + green + "\" b=\"" + blue + "\"/>" + "</PlantType>";
/*     */     }
/*     */ 
/* 919 */     xml = xml + "</boundarySemantic></boundary></boundaries>";
/* 920 */     return xml;
/*     */   }
/*     */ 
/*     */   private List<SoundData> getSoundDataList(List<Node> sounds)
/*     */   {
/* 925 */     List soundData = new LinkedList();
/* 926 */     for (Node sound : sounds) {
/* 927 */       String fileName = XMLHelper.getAttribute(sound, "Filename");
/* 928 */       String typeStr = XMLHelper.getAttribute(sound, "Type");
/* 929 */       NamedNodeMap attrMap = sound.getAttributes();
/* 930 */       Map propertyMap = new HashMap();
/* 931 */       for (int ii = 0; ii < attrMap.getLength(); ii++) {
/* 932 */         Node attr = attrMap.item(ii);
/* 933 */         String attrName = attr.getNodeName();
/* 934 */         if ((attrName.equals("Filename")) || (attrName.equals("Type")))
/*     */           continue;
/* 936 */         propertyMap.put(attrName, attr.getNodeValue());
/*     */       }
/*     */ 
/* 939 */       soundData.add(new SoundData(fileName, typeStr, propertyMap));
/*     */     }
/*     */ 
/* 942 */     return soundData;
/*     */   }
/*     */ 
/*     */   private static Road processRoad(Node roadNode)
/*     */   {
/* 948 */     String name = XMLHelper.getAttribute(roadNode, "Name");
/*     */ 
/* 950 */     Integer halfWidth = Integer.valueOf(Integer.parseInt(XMLHelper.getAttribute(roadNode, "HalfWidth")));
/* 951 */     Road road = new Road(name);
/* 952 */     road.setHalfWidth(halfWidth);
/*     */ 
/* 955 */     Node pointsNode = XMLHelper.getMatchingChild(roadNode, "PointCollection");
/*     */ 
/* 958 */     List points = XMLHelper.getMatchingChildren(pointsNode, "Point");
/* 959 */     for (Node pointNode : points) {
/* 960 */       String x = XMLHelper.getAttribute(pointNode, "x");
/* 961 */       String y = XMLHelper.getAttribute(pointNode, "y");
/* 962 */       String z = XMLHelper.getAttribute(pointNode, "z");
/*     */ 
/* 964 */       road.addPoint(new Point((int)Math.round(Double.parseDouble(x)), (int)Math.round(Double.parseDouble(y)), (int)Math.round(Double.parseDouble(z))));
/*     */     }
/*     */ 
/* 968 */     return road;
/*     */   }
/*     */ 
/*     */   static Node getFogNode(Node boundaryNode)
/*     */   {
/* 974 */     Node fogNode = XMLHelper.getMatchingChild(boundaryNode, "Fog");
/*     */ 
/* 976 */     return fogNode;
/*     */   }
/*     */ 
/*     */   static Node getWaterNode(Node boundaryNode) {
/* 980 */     return XMLHelper.getMatchingChild(boundaryNode, "Water");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  24 */     DEFAULT_SOUND_PERCEPTION_RADIUS = 25;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WorldCollectionFileLoader
 * JD-Core Version:    0.6.0
 */