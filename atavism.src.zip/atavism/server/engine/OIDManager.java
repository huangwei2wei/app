/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.util.LockFactory;
/*    */ import atavism.server.util.Log;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class OIDManager
/*    */ {
/* 85 */   private long lastOid = -2L;
/*    */ 
/* 88 */   private long freeOid = 1L;
/*    */   public static final long invalidOid = -1L;
/* 93 */   private transient Lock lock = LockFactory.makeLock("OIDManager");
/* 94 */   private Database db = null;
/* 95 */   public int defaultChunkSize = 100;
/*    */ 
/*    */   public OIDManager()
/*    */   {
/*    */   }
/*    */ 
/*    */   public OIDManager(Database db)
/*    */   {
/* 16 */     if (db == null) {
/* 17 */       throw new RuntimeException("OIDManager: db is null");
/*    */     }
/* 19 */     this.db = db;
/*    */   }
/*    */ 
/*    */   public OID getNextOid()
/*    */   {
/* 26 */     this.lock.lock();
/*    */     try {
/* 28 */       if (empty()) {
/* 29 */         getNewChunk(this.defaultChunkSize);
/*    */       }
/* 31 */       if (empty()) {
/* 32 */         throw new RuntimeException("OIDManager.getNextOid: failed");
/*    */       }
/* 34 */       OID localOID = OID.fromLong(this.freeOid++);
/*    */       return localOID; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public boolean empty()
/*    */   {
/* 45 */     this.lock.lock();
/*    */     try {
/* 47 */       int i = this.freeOid > this.lastOid ? 1 : 0;
/*    */       return i; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   protected void getNewChunk(int chunkSize)
/*    */   {
/* 59 */     this.lock.lock();
/*    */     try {
/* 61 */       if (this.db == null) { this.freeOid = 1L;
/* 64 */         this.lastOid = 1000000000L;
/*    */         return; }
/* 67 */       Database.OidChunk oidChunk = this.db.getOidChunk(chunkSize);
/*    */ 
/* 70 */       this.freeOid = oidChunk.begin;
/* 71 */       this.lastOid = oidChunk.end;
/* 72 */       if (Log.loggingDebug)
/* 73 */         Log.debug("OIDManager.getNewChunk: begin=" + oidChunk.begin + ", end=" + oidChunk.end);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 77 */       throw new RuntimeException("OIDManager.getNewChunk", e);
/*    */     }
/*    */     finally {
/* 80 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.OIDManager
 * JD-Core Version:    0.6.0
 */