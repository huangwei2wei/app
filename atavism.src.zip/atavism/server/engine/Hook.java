package atavism.server.engine;

import atavism.msgsys.Message;

public abstract interface Hook
{
  public abstract boolean processMessage(Message paramMessage, int paramInt);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Hook
 * JD-Core Version:    0.6.0
 */