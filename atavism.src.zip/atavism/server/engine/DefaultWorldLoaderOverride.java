/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.objects.LightData;
/*    */ import atavism.server.objects.Region;
/*    */ import atavism.server.objects.RegionConfig;
/*    */ import atavism.server.objects.SpawnData;
/*    */ import atavism.server.objects.Template;
/*    */ 
/*    */ public class DefaultWorldLoaderOverride
/*    */   implements WorldLoaderOverride
/*    */ {
/*    */   public boolean adjustLightData(String worldCollectionName, String objectName, LightData lightData)
/*    */   {
/* 16 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean adjustObjectTemplate(String worldCollectionName, String objectName, Template template)
/*    */   {
/* 23 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean adjustRegion(String worldCollectionName, String objectName, Region region)
/*    */   {
/* 29 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean adjustRegionConfig(String worldCollectionName, String objectName, Region region, RegionConfig regionConfig)
/*    */   {
/* 35 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean adjustSpawnData(String worldCollectionName, String objectName, SpawnData spawnData)
/*    */   {
/* 41 */     return true;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.DefaultWorldLoaderOverride
 * JD-Core Version:    0.6.0
 */