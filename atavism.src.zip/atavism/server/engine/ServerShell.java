/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.msgsys.Filter;
/*     */ import atavism.msgsys.FilterUpdate;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageCallback;
/*     */ import atavism.msgsys.MessageCatalog;
/*     */ import atavism.msgsys.MessageTrigger;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.msgsys.MessageTypeFilter;
/*     */ import atavism.msgsys.ResponseCallback;
/*     */ import atavism.msgsys.ResponseMessage;
/*     */ import atavism.msgsys.SubjectMessage;
/*     */ import atavism.msgsys.TargetMessage;
/*     */ import atavism.server.messages.PerceptionFilter;
/*     */ import atavism.server.messages.PerceptionMessage;
/*     */ import atavism.server.messages.PerceptionTrigger;
/*     */ import atavism.server.objects.ObjectTypes;
/*     */ import atavism.server.util.Log;
/*     */ import gnu.getopt.Getopt;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ServerShell
/*     */   implements MessageCallback
/*     */ {
/*  16 */   public static ServerShell shell = null;
/*     */ 
/*  21 */   public static MessageType MSG_TYPE_TEST0 = MessageType.intern("test0");
/*  22 */   public static MessageType MSG_TYPE_TEST1 = MessageType.intern("test1");
/*  23 */   public static MessageType MSG_TYPE_TEST2 = MessageType.intern("test2");
/*  24 */   public static MessageType MSG_TYPE_TEST3 = MessageType.intern("test3");
/*  25 */   public static MessageType MSG_TYPE_TEST4 = MessageType.intern("test4");
/*  26 */   public static MessageType MSG_TYPE_TEST5 = MessageType.intern("test5");
/*     */   public MessageAgent agent;
/* 511 */   public long lastMessageCount = 0L;
/* 512 */   public long startTime = 0L;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  30 */     Log.init();
/*  31 */     ServerShell shell = new ServerShell();
/*     */ 
/*  34 */     shell = shell;
/*     */ 
/*  36 */     configureMessageCatalog();
/*     */ 
/*  38 */     String agentName = "mtest" + args[0];
/*  39 */     Getopt g = new Getopt("ServerShell", args, "t:m:");
/*     */ 
/*  42 */     List tests = new LinkedList();
/*     */     int c;
/*  43 */     while ((c = g.getopt()) != -1) {
/*  44 */       switch (c) {
/*     */       case 116:
/*  46 */         String testName = g.getOptarg();
/*  47 */         tests.add(testName);
/*  48 */         break;
/*     */       case 109:
/*  51 */         break;
/*     */       case 63:
/*  53 */         Log.info("Exiting ServerShell because of unrecognized option '" + c + "'");
/*  54 */         System.exit(1);
/*     */       }
/*     */     }
/*     */ 
/*  58 */     MessageAgent agent = new MessageAgent(agentName);
/*  59 */     shell.agent = agent;
/*  60 */     shell.lastMessageCount = 0L;
/*     */     try {
/*  62 */       agent.openListener();
/*  63 */       List adverts = new LinkedList();
/*  64 */       adverts.add(MSG_TYPE_TEST0);
/*  65 */       adverts.add(MSG_TYPE_TEST1);
/*  66 */       adverts.add(MSG_TYPE_TEST2);
/*  67 */       adverts.add(MSG_TYPE_TEST3);
/*  68 */       adverts.add(MSG_TYPE_TEST4);
/*  69 */       adverts.add(MSG_TYPE_TEST5);
/*  70 */       agent.setAdvertisements(adverts);
/*     */ 
/*  74 */       agent.connectToDomain("localhost", Integer.valueOf(20374));
/*     */     }
/*     */     catch (Exception e) {
/*  77 */       System.err.println("connectToDomain: " + e);
/*  78 */       e.printStackTrace();
/*  79 */       System.exit(1);
/*     */     }
/*     */ 
/*  82 */     shell.runTests(tests);
/*     */   }
/*     */ 
/*     */   static void configureMessageCatalog()
/*     */   {
/*  87 */     MessageCatalog messageCatalog = MessageCatalog.addMsgCatalog("test", 10000, 100);
/*     */ 
/*  89 */     messageCatalog.addMsgTypeTranslation(MSG_TYPE_TEST0);
/*  90 */     messageCatalog.addMsgTypeTranslation(MSG_TYPE_TEST1);
/*  91 */     messageCatalog.addMsgTypeTranslation(MSG_TYPE_TEST2);
/*  92 */     messageCatalog.addMsgTypeTranslation(MSG_TYPE_TEST3);
/*  93 */     messageCatalog.addMsgTypeTranslation(MSG_TYPE_TEST4);
/*  94 */     messageCatalog.addMsgTypeTranslation(MSG_TYPE_TEST5);
/*     */   }
/*     */ 
/*     */   public void handleMessage(Message message, int flags)
/*     */   {
/* 100 */     System.out.println("** Got message id " + message.getMsgId());
/*     */   }
/*     */ 
/*     */   public void handleMessage2(Message message, int flags)
/*     */   {
/* 105 */     if (this.startTime == 0L)
/* 106 */       this.startTime = System.currentTimeMillis();
/* 107 */     if (System.currentTimeMillis() - this.startTime >= 1000L) {
/* 108 */       System.out.println("** Got message id " + message.getMsgId());
/* 109 */       System.out.println("Message count " + (this.agent.getAppMessageCount() - this.lastMessageCount));
/* 110 */       this.lastMessageCount = this.agent.getAppMessageCount();
/* 111 */       this.startTime = System.currentTimeMillis();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void runTests(List<String> tests)
/*     */   {
/* 117 */     for (String testName : tests)
/*     */       try {
/* 119 */         if (testName.equals("test1")) {
/* 120 */           new test1();
/*     */         }
/* 122 */         else if (testName.startsWith("pub")) {
/* 123 */           HashMap args = parseArgs(testName);
/* 124 */           new pub(args);
/*     */         }
/* 126 */         else if (testName.startsWith("respond")) {
/* 127 */           HashMap args = parseArgs(testName);
/* 128 */           new respond(args);
/*     */         }
/* 130 */         else if (testName.startsWith("rpc")) {
/* 131 */           HashMap args = parseArgs(testName);
/* 132 */           new rpc(args);
/*     */         }
/* 134 */         else if (testName.startsWith("sub")) {
/* 135 */           HashMap args = parseArgs(testName);
/* 136 */           new sub(args);
/*     */         }
/* 138 */         else if (testName.startsWith("sleep")) {
/* 139 */           HashMap args = parseArgs(testName);
/* 140 */           int seconds = 1;
/* 141 */           String str = (String)args.get("s");
/* 142 */           if (str != null) try {
/* 143 */               seconds = Integer.parseInt(str);
/*     */             }
/*     */             catch (Exception ex)
/*     */             {
/*     */             } System.out.println("Sleeping " + seconds + " seconds");
/*     */           try { Thread.sleep(seconds * 1000); } catch (Exception ex) {
/*     */           }
/*     */         }
/*     */         else {
/* 152 */           System.err.println("Unknown test " + testName);
/*     */         }
/*     */       } catch (Exception ex) {
/* 155 */         System.out.println("ERROR " + ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static HashMap<String, String> parseArgs(String arg)
/*     */   {
/* 492 */     int colon = arg.indexOf(58);
/* 493 */     HashMap args = new HashMap();
/*     */ 
/* 495 */     if (colon == -1) {
/* 496 */       return args;
/*     */     }
/* 498 */     arg = arg.substring(colon + 1);
/* 499 */     String[] strings = arg.split(",");
/* 500 */     for (int ii = 0; ii < strings.length; ii++) {
/* 501 */       String[] kv = strings[ii].split("=", 2);
/* 502 */       if (kv.length == 1)
/* 503 */         args.put(kv[0], null);
/*     */       else
/* 505 */         args.put(kv[0], kv[1]);
/*     */     }
/* 507 */     return args;
/*     */   }
/*     */ 
/*     */   public class sub
/*     */     implements Runnable, MessageCallback
/*     */   {
/*     */     ServerShell shell;
/*     */     MessageAgent agent;
/*     */     HashMap<String, String> args;
/*     */ 
/*     */     public sub()
/*     */     {
/* 403 */       this.args = args;
/* 404 */       this.shell = ServerShell.shell;
/* 405 */       this.agent = this.shell.agent;
/* 406 */       new Thread(this).start();
/*     */     }
/*     */ 
/*     */     public void run() {
/* 410 */       MessageType msgType = ServerShell.MSG_TYPE_TEST5;
/* 411 */       MessageType triggerMsgType = ServerShell.MSG_TYPE_TEST0;
/* 412 */       Filter filter = new MessageTypeFilter();
/* 413 */       MessageTrigger trigger = null;
/* 414 */       OID noid = null;
/* 415 */       short flags = 0;
/*     */       try {
/* 417 */         String arg = (String)this.args.get("t");
/* 418 */         if (arg != null) {
/* 419 */           msgType = MessageCatalog.getMessageType(arg);
/* 420 */           if (msgType == null) {
/* 421 */             throw new RuntimeException("Unknown message type " + arg);
/*     */           }
/*     */         }
/* 424 */         arg = (String)this.args.get("filter");
/* 425 */         if ((arg != null) && 
/* 426 */           (arg.equals("multi"))) {
/* 427 */           filter = new PerceptionFilter();
/*     */         }
/*     */ 
/* 430 */         arg = (String)this.args.get("trigger");
/* 431 */         if ((arg != null) && 
/* 432 */           (arg.equals("multi"))) {
/* 433 */           trigger = new PerceptionTrigger();
/*     */         }
/*     */ 
/* 436 */         arg = (String)this.args.get("trigger-type");
/* 437 */         if (arg != null) {
/* 438 */           triggerMsgType = MessageCatalog.getMessageType(arg);
/* 439 */           if (msgType == null) {
/* 440 */             throw new RuntimeException("Unknown message type " + arg);
/*     */           }
/*     */         }
/* 443 */         arg = (String)this.args.get("noid");
/* 444 */         if (arg != null) {
/* 445 */           noid = OID.parseLong(arg);
/*     */         }
/* 447 */         arg = (String)this.args.get("blocking");
/* 448 */         if (arg != null)
/* 449 */           flags = (short)(flags | 0x1);
/*     */       }
/*     */       catch (RuntimeException ex) {
/* 452 */         throw ex; } catch (Exception ex) {
/* 453 */         System.out.println("error " + ex);
/*     */       }
/* 455 */       List messageTypes = new LinkedList();
/* 456 */       System.out.println("sub msgType " + msgType);
/* 457 */       messageTypes.add(msgType);
/* 458 */       if ((filter instanceof MessageTypeFilter)) {
/* 459 */         ((MessageTypeFilter)filter).setTypes(messageTypes);
/*     */       }
/* 461 */       if ((filter instanceof PerceptionFilter)) {
/* 462 */         ((PerceptionFilter)filter).setTypes(messageTypes);
/* 463 */         if (noid != null)
/* 464 */           ((PerceptionFilter)filter).addTarget(noid);
/*     */       }
/* 466 */       if ((trigger instanceof PerceptionTrigger)) {
/* 467 */         List types = new LinkedList();
/* 468 */         types.add(triggerMsgType);
/* 469 */         ((PerceptionTrigger)trigger).setTriggeringTypes(types);
/*     */       }
/*     */ 
/* 472 */       long startTime = System.currentTimeMillis();
/* 473 */       this.agent.createSubscription(filter, this, flags, trigger);
/* 474 */       System.out.println("createSubscription " + (System.currentTimeMillis() - startTime) + " ms");
/*     */     }
/*     */ 
/*     */     public void handleMessage(Message message, int flags)
/*     */     {
/* 480 */       System.out.println("** Subscriber got message id=" + message.getMsgId() + " class=" + message.getClass().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   public class rpc
/*     */     implements Runnable, ResponseCallback
/*     */   {
/*     */     ServerShell shell;
/*     */     MessageAgent agent;
/*     */     HashMap<String, String> args;
/*     */ 
/*     */     public rpc()
/*     */     {
/* 315 */       this.args = args;
/* 316 */       this.shell = ServerShell.shell;
/* 317 */       this.agent = this.shell.agent;
/* 318 */       new Thread(this).start();
/*     */     }
/*     */ 
/*     */     public void run() {
/* 322 */       MessageType msgType = ServerShell.MSG_TYPE_TEST4;
/* 323 */       Class msgClass = Message.class;
/* 324 */       OID oid = null;
/* 325 */       OID noid = null;
/* 326 */       boolean broadcast = false;
/* 327 */       int count = 1;
/*     */       try {
/* 329 */         String arg = (String)this.args.get("t");
/* 330 */         if (arg != null)
/* 331 */           msgType = MessageCatalog.getMessageType(arg);
/* 332 */         arg = (String)this.args.get("class");
/* 333 */         if (arg != null) {
/* 334 */           if (arg.equals("subj"))
/* 335 */             msgClass = SubjectMessage.class;
/* 336 */           else if (arg.equals("targ"))
/* 337 */             msgClass = TargetMessage.class;
/*     */         }
/* 339 */         arg = (String)this.args.get("oid");
/* 340 */         if (arg != null) {
/* 341 */           oid = OID.parseLong(arg);
/*     */         }
/* 343 */         arg = (String)this.args.get("noid");
/* 344 */         if (arg != null) {
/* 345 */           noid = OID.parseLong(arg);
/*     */         }
/* 347 */         arg = (String)this.args.get("broadcast");
/* 348 */         if (arg != null) {
/* 349 */           broadcast = true;
/*     */         }
/* 351 */         arg = (String)this.args.get("count");
/* 352 */         if (arg != null)
/* 353 */           count = Integer.parseInt(arg);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */       }
/* 358 */       long startTime = System.currentTimeMillis();
/* 359 */       for (int rpcCount = count; rpcCount > 0; rpcCount--) {
/* 360 */         Message message = null;
/*     */         try {
/* 362 */           message = (Message)msgClass.newInstance();
/*     */         }
/*     */         catch (Exception ex) {
/* 365 */           System.out.println("msgClass " + ex);
/*     */         }
/* 367 */         message.setMsgType(msgType);
/* 368 */         if (msgClass == SubjectMessage.class) {
/* 369 */           ((SubjectMessage)message).setSubject(oid);
/*     */         }
/* 371 */         if (msgClass == TargetMessage.class) {
/* 372 */           ((TargetMessage)message).setTarget(noid);
/*     */         }
/*     */ 
/* 375 */         if (broadcast) {
/* 376 */           this.agent.sendBroadcastRPC(message, this);
/*     */         }
/*     */         else
/*     */         {
/* 380 */           this.agent.sendRPC(message);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 386 */       System.out.println(count + " rpc in " + (System.currentTimeMillis() - startTime) + " ms");
/*     */     }
/*     */ 
/*     */     public void handleResponse(ResponseMessage response)
/*     */     {
/* 391 */       System.out.println("** handleResponse got message id " + response.getMsgId() + " from " + response.getSenderName());
/*     */     }
/*     */   }
/*     */ 
/*     */   public class respond
/*     */     implements Runnable, MessageCallback
/*     */   {
/*     */     ServerShell shell;
/*     */     MessageAgent agent;
/*     */     HashMap<String, String> args;
/*     */ 
/*     */     public respond()
/*     */     {
/* 273 */       this.args = args;
/* 274 */       this.shell = ServerShell.shell;
/* 275 */       this.agent = this.shell.agent;
/* 276 */       new Thread(this).start();
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 282 */       MessageType requestType = ServerShell.MSG_TYPE_TEST4;
/*     */       try { String arg = (String)this.args.get("t");
/*     */ 
/* 287 */         arg = (String)this.args.get("class");
/* 288 */         if (arg == null);
/*     */       }
/*     */       catch (Exception ex) {
/*     */       }
/* 293 */       List messageTypes = new LinkedList();
/* 294 */       messageTypes.add(requestType);
/* 295 */       MessageTypeFilter filter = new MessageTypeFilter(messageTypes);
/* 296 */       this.agent.createSubscription(filter, this, 8);
/*     */     }
/*     */ 
/*     */     public void handleMessage(Message message, int flags)
/*     */     {
/* 303 */       ResponseMessage response = new ResponseMessage(message);
/* 304 */       this.agent.sendResponse(response);
/*     */     }
/*     */   }
/*     */ 
/*     */   public class pub
/*     */     implements Runnable
/*     */   {
/*     */     ServerShell shell;
/*     */     MessageAgent agent;
/*     */     HashMap<String, String> args;
/*     */ 
/*     */     public pub()
/*     */     {
/* 190 */       this.args = args;
/* 191 */       this.shell = ServerShell.shell;
/* 192 */       this.agent = this.shell.agent;
/* 193 */       new Thread(this).start();
/*     */     }
/*     */ 
/*     */     public void run() {
/* 197 */       MessageType msgType = ServerShell.MSG_TYPE_TEST0;
/* 198 */       Class msgClass = Message.class;
/* 199 */       OID oid = null;
/* 200 */       OID noid = null;
/* 201 */       int interval = 0;
/* 202 */       int count = 1;
/*     */       try {
/* 204 */         String arg = (String)this.args.get("t");
/* 205 */         if (arg != null)
/* 206 */           msgType = MessageCatalog.getMessageType(arg);
/* 207 */         arg = (String)this.args.get("class");
/* 208 */         if (arg != null) {
/* 209 */           if (arg.equals("subj"))
/* 210 */             msgClass = SubjectMessage.class;
/* 211 */           else if (arg.equals("targ"))
/* 212 */             msgClass = TargetMessage.class;
/* 213 */           else if (arg.equals("multi"))
/* 214 */             msgClass = PerceptionMessage.class;
/*     */         }
/* 216 */         arg = (String)this.args.get("oid");
/* 217 */         if (arg != null) {
/* 218 */           oid = OID.parseLong(arg);
/*     */         }
/* 220 */         arg = (String)this.args.get("noid");
/* 221 */         if (arg != null) {
/* 222 */           noid = OID.parseLong(arg);
/*     */         }
/* 224 */         arg = (String)this.args.get("interval");
/* 225 */         if (arg != null) {
/* 226 */           interval = Integer.parseInt(arg) * 1000;
/*     */         }
/* 228 */         arg = (String)this.args.get("intervalms");
/* 229 */         if (arg != null) {
/* 230 */           interval = Integer.parseInt(arg);
/*     */         }
/* 232 */         arg = (String)this.args.get("count");
/* 233 */         if (arg != null)
/* 234 */           count = Integer.parseInt(arg);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */       }
/* 239 */       for (; count > 0; count--) {
/* 240 */         Message message = null;
/*     */         try {
/* 242 */           message = (Message)msgClass.newInstance();
/*     */         }
/*     */         catch (Exception ex) {
/* 245 */           System.out.println("msgClass " + ex);
/*     */         }
/* 247 */         message.setMsgType(msgType);
/* 248 */         if (msgClass == SubjectMessage.class) {
/* 249 */           ((SubjectMessage)message).setSubject(oid);
/*     */         }
/* 251 */         if (msgClass == TargetMessage.class) {
/* 252 */           ((TargetMessage)message).setTarget(noid);
/*     */         }
/* 254 */         if (msgClass == PerceptionMessage.class) {
/* 255 */           ((PerceptionMessage)message).gainObject(noid, oid, ObjectTypes.unknown);
/*     */         }
/*     */ 
/* 258 */         this.agent.sendBroadcast(message);
/*     */         try {
/* 260 */           Thread.sleep(interval);
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public class test1
/*     */     implements Runnable
/*     */   {
/*     */     ServerShell shell;
/*     */     MessageAgent agent;
/*     */ 
/*     */     public test1()
/*     */     {
/* 163 */       this.shell = ServerShell.shell;
/* 164 */       this.agent = this.shell.agent;
/* 165 */       new Thread(this).start();
/*     */     }
/*     */ 
/*     */     public void run() {
/* 169 */       List messageTypes = new LinkedList();
/* 170 */       messageTypes.add(ServerShell.MSG_TYPE_TEST2);
/* 171 */       messageTypes.add(ServerShell.MSG_TYPE_TEST3);
/* 172 */       PerceptionFilter filter = new PerceptionFilter(messageTypes);
/* 173 */       long subId = this.agent.createSubscription(filter, this.shell);
/*     */       try { Thread.sleep(2000L); } catch (InterruptedException ex) {
/*     */       }
/* 176 */       if (filter.addTarget(OID.fromLong(1001L))) {
/* 177 */         FilterUpdate update = new FilterUpdate(1);
/* 178 */         update.addFieldValue(1, new Long(1001L));
/* 179 */         this.agent.applyFilterUpdate(subId, update);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.ServerShell
 * JD-Core Version:    0.6.0
 */