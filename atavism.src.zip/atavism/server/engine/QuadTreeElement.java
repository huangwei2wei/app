package atavism.server.engine;

import atavism.server.math.Point;
import java.io.Serializable;

public abstract interface QuadTreeElement<ElementType extends QuadTreeElement<ElementType>> extends Locatable, Serializable
{
  public abstract Object getQuadTreeObject();

  public abstract MobilePerceiver<ElementType> getPerceiver();

  public abstract void setPerceiver(MobilePerceiver<ElementType> paramMobilePerceiver);

  public abstract QuadTreeNode<ElementType> getQuadNode();

  public abstract void setQuadNode(QuadTreeNode<ElementType> paramQuadTreeNode);

  public abstract Point getCurrentLoc();

  public abstract int getPerceptionRadius();

  public abstract int getObjectRadius();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.QuadTreeElement
 * JD-Core Version:    0.6.0
 */