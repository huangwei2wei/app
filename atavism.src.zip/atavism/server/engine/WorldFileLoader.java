/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.objects.Boundary;
/*     */ import atavism.server.objects.Color;
/*     */ import atavism.server.objects.Fog;
/*     */ import atavism.server.objects.Instance;
/*     */ import atavism.server.objects.LightData;
/*     */ import atavism.server.objects.OceanData;
/*     */ import atavism.server.objects.Region;
/*     */ import atavism.server.pathing.PathArc;
/*     */ import atavism.server.pathing.PathEdge;
/*     */ import atavism.server.pathing.PathInfo;
/*     */ import atavism.server.pathing.PathObjectType;
/*     */ import atavism.server.pathing.PathPolygon;
/*     */ import atavism.server.plugins.WorldManagerClient.NewRegionMessage;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.XMLHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class WorldFileLoader
/*     */ {
/*     */   protected String worldFileName;
/*     */   protected String worldFileBasePath;
/*     */   protected WorldLoaderOverride worldLoaderOverride;
/*     */   protected Document worldDoc;
/*     */ 
/*     */   public WorldFileLoader(String worldFileName, WorldLoaderOverride override)
/*     */   {
/*  30 */     this.worldFileName = worldFileName;
/*  31 */     this.worldLoaderOverride = override;
/*     */   }
/*     */ 
/*     */   public void setWorldLoaderOverride(WorldLoaderOverride override)
/*     */   {
/*  36 */     this.worldLoaderOverride = override;
/*     */   }
/*     */ 
/*     */   public WorldLoaderOverride getWorldLoaderOverride()
/*     */   {
/*  41 */     return this.worldLoaderOverride;
/*     */   }
/*     */ 
/*     */   public boolean load(Instance instance)
/*     */   {
/*  46 */     if (!parse()) {
/*  47 */       return false;
/*     */     }
/*  49 */     return generate(instance);
/*     */   }
/*     */ 
/*     */   public boolean parse()
/*     */   {
/*     */     try {
/*  55 */       DocumentBuilder builder = XMLHelper.makeDocBuilder();
/*  56 */       File xmlFile = new File(this.worldFileName);
/*  57 */       this.worldFileBasePath = xmlFile.getParent();
/*     */ 
/*  59 */       this.worldDoc = builder.parse(xmlFile);
/*     */     }
/*     */     catch (IOException e) {
/*  62 */       Log.exception("WorldFileLoader.parse(" + this.worldFileName + ")", e);
/*  63 */       return false;
/*     */     } catch (SAXException e) {
/*  65 */       Log.exception("WorldFileLoader.parse(" + this.worldFileName + ")", e);
/*  66 */       return false;
/*     */     }
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean generate(Instance instance)
/*     */   {
/*  73 */     Node worldNode = XMLHelper.getMatchingChild(this.worldDoc, "World");
/*  74 */     if (worldNode == null) {
/*  75 */       Log.error("No <World> node in file " + this.worldFileName);
/*  76 */       return false;
/*     */     }
/*  78 */     String worldName = XMLHelper.getAttribute(worldNode, "Name");
/*  79 */     if (worldName == null) {
/*  80 */       Log.error("No world name in file " + this.worldFileName);
/*  81 */       return false;
/*     */     }
/*     */ 
/*  84 */     if (Log.loggingDebug) {
/*  85 */       Log.debug("world name=" + worldName + " (file " + this.worldFileName + ")");
/*     */     }
/*     */ 
/*  88 */     String fileVersion = XMLHelper.getAttribute(worldNode, "Version");
/*  89 */     if (fileVersion == null) {
/*  90 */       Log.error("No world file version");
/*  91 */       return false;
/*     */     }
/*  93 */     if (Log.loggingDebug) {
/*  94 */       Log.debug("world file version=" + fileVersion);
/*     */     }
/*  96 */     if ((!fileVersion.equals("2")) && (!fileVersion.equals("2.0"))) {
/*  97 */       Log.error("Unsupported world file version in file " + this.worldFileName);
/*     */ 
/*  99 */       return false;
/*     */     }
/*     */ 
/* 103 */     Node skyboxNode = XMLHelper.getMatchingChild(worldNode, "Skybox");
/* 104 */     if (skyboxNode == null) {
/* 105 */       Log.debug("No <Skybox> node in file " + this.worldFileName);
/*     */     }
/*     */     else {
/* 108 */       String skybox = XMLHelper.getAttribute(skyboxNode, "Name");
/* 109 */       if (Log.loggingDebug)
/* 110 */         Log.debug("Global skybox=" + skybox);
/* 111 */       instance.setGlobalSkybox(skybox);
/*     */     }
/*     */ 
/* 115 */     Node globalFogNode = XMLHelper.getMatchingChild(worldNode, "GlobalFog");
/*     */ 
/* 117 */     if (globalFogNode != null) {
/* 118 */       String near = XMLHelper.getAttribute(globalFogNode, "Near");
/* 119 */       String far = XMLHelper.getAttribute(globalFogNode, "Far");
/* 120 */       Color fogColor = getColor(XMLHelper.getMatchingChild(globalFogNode, "Color"));
/*     */ 
/* 122 */       Fog fog = new Fog("global fog");
/* 123 */       fog.setStart((int)Float.parseFloat(near));
/* 124 */       fog.setEnd((int)Float.parseFloat(far));
/* 125 */       fog.setColor(fogColor);
/* 126 */       instance.setGlobalFog(fog);
/* 127 */       if (Log.loggingDebug) {
/* 128 */         Log.debug("Global fog: " + fog);
/*     */       }
/*     */     }
/*     */ 
/* 132 */     Node globalAmbientLightNode = XMLHelper.getMatchingChild(worldNode, "GlobalAmbientLight");
/*     */ 
/* 134 */     if (globalAmbientLightNode != null) {
/* 135 */       Color lightColor = getColor(XMLHelper.getMatchingChild(globalAmbientLightNode, "Color"));
/*     */ 
/* 137 */       instance.setGlobalAmbientLight(lightColor);
/* 138 */       if (Log.loggingDebug) {
/* 139 */         Log.debug("Global ambient light: " + lightColor);
/*     */       }
/*     */     }
/*     */ 
/* 143 */     Node globalDirectionalLightNode = XMLHelper.getMatchingChild(worldNode, "GlobalDirectionalLight");
/* 144 */     if (globalDirectionalLightNode != null) {
/* 145 */       Color diffuseColor = getColor(XMLHelper.getMatchingChild(globalDirectionalLightNode, "Diffuse"));
/* 146 */       Color specularColor = getColor(XMLHelper.getMatchingChild(globalDirectionalLightNode, "Specular"));
/* 147 */       AOVector lightDir = getVector(XMLHelper.getMatchingChild(globalDirectionalLightNode, "Direction"));
/* 148 */       LightData lightData = new LightData();
/* 149 */       lightData.setName("globalDirLight");
/* 150 */       lightData.setDiffuse(diffuseColor);
/* 151 */       lightData.setSpecular(specularColor);
/* 152 */       lightData.setAttenuationRange(1000.0F);
/* 153 */       lightData.setAttenuationConstant(1.0F);
/* 154 */       Quaternion q = AOVector.UnitZ.getRotationTo(lightDir);
/* 155 */       if (q == null) {
/* 156 */         if (Log.loggingDebug)
/* 157 */           Log.debug("global light orient is near inverse, dir=" + lightDir);
/* 158 */         q = new Quaternion(0.0F, 1.0F, 0.0F, 0.0F);
/*     */       }
/* 160 */       lightData.setOrientation(q);
/* 161 */       instance.setGlobalDirectionalLight(lightData);
/* 162 */       if (Log.loggingDebug) {
/* 163 */         Log.debug("Global directional light: " + lightData);
/*     */       }
/*     */     }
/* 166 */     Node pathObjectTypesNode = XMLHelper.getMatchingChild(worldNode, "PathObjectTypes");
/* 167 */     if (pathObjectTypesNode != null) {
/* 168 */       List pathObjectTypeNodes = XMLHelper.getMatchingChildren(pathObjectTypesNode, "PathObjectType");
/*     */ 
/* 170 */       for (Node pathObjectTypeNode : pathObjectTypeNodes) {
/* 171 */         String potName = XMLHelper.getAttribute(pathObjectTypeNode, "name");
/* 172 */         float potHeight = Float.parseFloat(XMLHelper.getAttribute(pathObjectTypeNode, "height"));
/* 173 */         float potWidth = Float.parseFloat(XMLHelper.getAttribute(pathObjectTypeNode, "width"));
/* 174 */         float potMaxClimbSlope = Float.parseFloat(XMLHelper.getAttribute(pathObjectTypeNode, "maxClimbSlope"));
/* 175 */         instance.getPathInfo().getTypeDictionary().put(potName, new PathObjectType(potName, potHeight, potWidth, potMaxClimbSlope));
/*     */ 
/* 178 */         if (Log.loggingDebug) {
/* 179 */           Log.debug("Path object type name=" + potName);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 184 */     Node oceanNode = XMLHelper.getMatchingChild(worldNode, "Ocean");
/* 185 */     if (oceanNode != null) {
/* 186 */       OceanData oceanData = new OceanData();
/*     */ 
/* 188 */       String displayOcean = XMLHelper.getAttribute(oceanNode, "DisplayOcean");
/*     */ 
/* 190 */       oceanData.displayOcean = (displayOcean.equals("True") ? Boolean.TRUE : Boolean.FALSE);
/*     */ 
/* 193 */       String useParams = XMLHelper.getAttribute(oceanNode, "UseParams");
/* 194 */       if (useParams != null) {
/* 195 */         oceanData.useParams = (useParams.equals("True") ? Boolean.TRUE : Boolean.FALSE);
/*     */       }
/*     */ 
/* 199 */       String waveHeight = XMLHelper.getAttribute(oceanNode, "WaveHeight");
/* 200 */       if (waveHeight != null) {
/* 201 */         oceanData.waveHeight = Float.valueOf(Float.parseFloat(waveHeight));
/*     */       }
/*     */ 
/* 204 */       String seaLevel = XMLHelper.getAttribute(oceanNode, "SeaLevel");
/* 205 */       if (seaLevel != null) {
/* 206 */         oceanData.seaLevel = Float.valueOf(Float.parseFloat(seaLevel));
/*     */       }
/*     */ 
/* 209 */       String bumpScale = XMLHelper.getAttribute(oceanNode, "BumpScale");
/* 210 */       if (bumpScale != null) {
/* 211 */         oceanData.bumpScale = Float.valueOf(Float.parseFloat(bumpScale));
/*     */       }
/*     */ 
/* 214 */       String bumpSpeedX = XMLHelper.getAttribute(oceanNode, "BumpSpeedX");
/* 215 */       if (bumpSpeedX != null) {
/* 216 */         oceanData.bumpSpeedX = Float.valueOf(Float.parseFloat(bumpSpeedX));
/*     */       }
/*     */ 
/* 219 */       String bumpSpeedZ = XMLHelper.getAttribute(oceanNode, "BumpSpeedZ");
/* 220 */       if (bumpSpeedZ != null) {
/* 221 */         oceanData.bumpSpeedZ = Float.valueOf(Float.parseFloat(bumpSpeedZ));
/*     */       }
/*     */ 
/* 224 */       String textureScaleX = XMLHelper.getAttribute(oceanNode, "TextureScaleX");
/* 225 */       if (textureScaleX != null) {
/* 226 */         oceanData.textureScaleX = Float.valueOf(Float.parseFloat(textureScaleX));
/*     */       }
/*     */ 
/* 229 */       String textureScaleZ = XMLHelper.getAttribute(oceanNode, "TextureScaleZ");
/* 230 */       if (textureScaleZ != null) {
/* 231 */         oceanData.textureScaleZ = Float.valueOf(Float.parseFloat(textureScaleZ));
/*     */       }
/*     */ 
/* 234 */       Node deepColorNode = XMLHelper.getMatchingChild(oceanNode, "DeepColor");
/* 235 */       if (deepColorNode != null) {
/* 236 */         oceanData.deepColor = getColor(deepColorNode);
/*     */       }
/*     */ 
/* 239 */       Node shallowColorNode = XMLHelper.getMatchingChild(oceanNode, "ShallowColor");
/* 240 */       if (shallowColorNode != null) {
/* 241 */         oceanData.shallowColor = getColor(shallowColorNode);
/*     */       }
/*     */ 
/* 244 */       instance.setOceanData(oceanData);
/* 245 */       if (Log.loggingDebug) {
/* 246 */         Log.debug("Ocean: " + oceanData);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 252 */     TerrainConfig terrainConfig = instance.getTerrainConfig();
/* 253 */     if ((terrainConfig != null) && (Log.loggingDebug))
/* 254 */       Log.debug("Terrain: " + terrainConfig);
/* 255 */     if (terrainConfig == null) {
/* 256 */       Node terrainNode = XMLHelper.getMatchingChild(worldNode, "Terrain");
/*     */ 
/* 258 */       if (terrainNode != null) {
/* 259 */         String terrainXML = XMLHelper.toXML(terrainNode);
/* 260 */         if (Log.loggingDebug) {
/* 261 */           Log.debug("Terrain: xmlsize=" + terrainXML.length());
/*     */         }
/*     */ 
/* 264 */         Node terrainDisplay = XMLHelper.getMatchingChild(worldNode, "TerrainDisplay");
/* 265 */         if (terrainDisplay != null) {
/* 266 */           String terrainDisplayXML = XMLHelper.toXML(terrainDisplay);
/* 267 */           if (Log.loggingDebug)
/* 268 */             Log.debug("TerrainDisplay: " + terrainDisplayXML);
/* 269 */           terrainXML = terrainXML + terrainDisplayXML;
/*     */         }
/*     */ 
/* 272 */         terrainConfig = new TerrainConfig();
/* 273 */         terrainConfig.setConfigType("xmlstring");
/* 274 */         terrainConfig.setConfigData(terrainXML);
/* 275 */         instance.setTerrainConfig(terrainConfig);
/* 276 */         if (Log.loggingDebug)
/* 277 */           Log.debug("terrain has been set:" + terrainConfig);
/*     */       } else {
/* 279 */         Log.debug("No terrain in file");
/*     */       }
/*     */     }
/*     */ 
/* 283 */     setupGlobalRegion(instance);
/*     */ 
/* 286 */     if (!processWorldCollections(instance, worldNode)) {
/* 287 */       return false;
/*     */     }
/*     */ 
/* 291 */     Message msg = new WorldManagerClient.NewRegionMessage(instance.getOid(), instance.getGlobalRegion());
/*     */ 
/* 293 */     Engine.getAgent().sendBroadcast(msg);
/*     */ 
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */   protected void setupGlobalRegion(Instance instance)
/*     */   {
/* 300 */     Boundary globalBoundary = new Boundary();
/* 301 */     globalBoundary.addPoint(new Point(-2000000.0F, 0.0F, 2000000.0F));
/* 302 */     globalBoundary.addPoint(new Point(2000000.0F, 0.0F, 2000000.0F));
/* 303 */     globalBoundary.addPoint(new Point(2000000.0F, 0.0F, -2000000.0F));
/* 304 */     globalBoundary.addPoint(new Point(-2000000.0F, 0.0F, -2000000.0F));
/* 305 */     instance.getGlobalRegion().setBoundary(globalBoundary);
/*     */   }
/*     */ 
/*     */   protected boolean processWorldCollections(Instance instance, Node node)
/*     */   {
/* 310 */     List worldCollections = XMLHelper.getMatchingChildren(node, "WorldCollection");
/*     */ 
/* 312 */     for (Node worldCollectionNode : worldCollections) {
/* 313 */       String colFilename = XMLHelper.getAttribute(worldCollectionNode, "Filename");
/*     */ 
/* 315 */       if (colFilename != null) {
/* 316 */         String fullFile = this.worldFileBasePath + File.separator + colFilename;
/* 317 */         if (Log.loggingDebug)
/* 318 */           Log.debug("Loading world collection " + fullFile);
/* 319 */         WorldCollectionFileLoader collectionLoader = new WorldCollectionFileLoader(fullFile, this.worldLoaderOverride);
/*     */ 
/* 321 */         if (!collectionLoader.load(instance))
/* 322 */           return false;
/*     */       }
/*     */       else {
/* 325 */         String collectionName = XMLHelper.getAttribute(worldCollectionNode, "Name");
/*     */ 
/* 327 */         if (Log.loggingDebug)
/* 328 */           Log.debug("Loading world collection from database entry " + collectionName);
/* 329 */         WorldCollectionDatabaseLoader collectionLoader = new WorldCollectionDatabaseLoader(collectionName, this.worldLoaderOverride);
/*     */ 
/* 331 */         if (!collectionLoader.load(instance))
/* 332 */           return false;
/*     */       }
/*     */     }
/* 335 */     return true;
/*     */   }
/*     */ 
/*     */   protected static List<PathPolygon> processPathPolygons(String introducer, Node parentNode)
/*     */   {
/* 342 */     Node polyContainerNode = XMLHelper.getMatchingChild(parentNode, introducer);
/* 343 */     List polyNodes = XMLHelper.getMatchingChildren(polyContainerNode, "PathPolygon");
/* 344 */     LinkedList polys = new LinkedList();
/* 345 */     if (polyNodes == null)
/* 346 */       return polys;
/* 347 */     for (Node polyNode : polyNodes) {
/* 348 */       int index = (int)Float.parseFloat(XMLHelper.getAttribute(polyNode, "index"));
/* 349 */       String stringKind = XMLHelper.getAttribute(polyNode, "kind");
/* 350 */       byte polygonKind = PathPolygon.parsePolygonKind(stringKind);
/* 351 */       List cornerNodes = XMLHelper.getMatchingChildren(polyNode, "Corner");
/* 352 */       assert (cornerNodes.size() >= 3);
/* 353 */       LinkedList corners = new LinkedList();
/* 354 */       for (Node corner : cornerNodes)
/* 355 */         corners.add(new AOVector(getPoint(corner)));
/* 356 */       polys.add(new PathPolygon(index, polygonKind, corners));
/*     */     }
/* 358 */     return polys;
/*     */   }
/*     */ 
/*     */   protected static List<PathArc> processPathArcs(String introducer, Node parentNode)
/*     */   {
/* 365 */     Node arcContainerNode = XMLHelper.getMatchingChild(parentNode, introducer);
/* 366 */     List arcNodes = XMLHelper.getMatchingChildren(arcContainerNode, "PathArc");
/* 367 */     LinkedList arcs = new LinkedList();
/* 368 */     if (arcNodes == null)
/* 369 */       return arcs;
/* 370 */     for (Node arcNode : arcNodes) {
/* 371 */       byte arcKind = PathArc.parseArcKind(XMLHelper.getAttribute(arcNode, "kind"));
/* 372 */       int poly1Index = (int)Float.parseFloat(XMLHelper.getAttribute(arcNode, "poly1Index"));
/* 373 */       int poly2Index = (int)Float.parseFloat(XMLHelper.getAttribute(arcNode, "poly2Index"));
/* 374 */       PathEdge edge = processPathEdge(arcNode);
/* 375 */       arcs.add(new PathArc(arcKind, poly1Index, poly2Index, edge));
/*     */     }
/* 377 */     return arcs;
/*     */   }
/*     */ 
/*     */   protected static PathEdge processPathEdge(Node parentNode)
/*     */   {
/* 383 */     Node edgeNode = XMLHelper.getMatchingChild(parentNode, "PathEdge");
/* 384 */     return new PathEdge(new AOVector(getPoint(XMLHelper.getMatchingChild(edgeNode, "Start"))), new AOVector(getPoint(XMLHelper.getMatchingChild(edgeNode, "End"))));
/*     */   }
/*     */ 
/*     */   public static Color getColor(Node colorNode)
/*     */   {
/* 389 */     String redS = XMLHelper.getAttribute(colorNode, "R");
/* 390 */     String greenS = XMLHelper.getAttribute(colorNode, "G");
/* 391 */     String blueS = XMLHelper.getAttribute(colorNode, "B");
/* 392 */     Color color = new Color();
/* 393 */     color.setRed((int)(Float.parseFloat(redS) * 255.0F));
/* 394 */     color.setGreen((int)(Float.parseFloat(greenS) * 255.0F));
/* 395 */     color.setBlue((int)(Float.parseFloat(blueS) * 255.0F));
/* 396 */     return color;
/*     */   }
/*     */ 
/*     */   public static AOVector getVector(Node xyzNode) {
/* 400 */     String posX = XMLHelper.getAttribute(xyzNode, "x");
/* 401 */     String posY = XMLHelper.getAttribute(xyzNode, "y");
/* 402 */     String posZ = XMLHelper.getAttribute(xyzNode, "z");
/* 403 */     float x = Float.parseFloat(posX);
/* 404 */     float y = Float.parseFloat(posY);
/* 405 */     float z = Float.parseFloat(posZ);
/* 406 */     return new AOVector(x, y, z);
/*     */   }
/*     */ 
/*     */   public static Point getPoint(Node xyzNode)
/*     */   {
/* 411 */     String posX = XMLHelper.getAttribute(xyzNode, "x");
/* 412 */     String posY = XMLHelper.getAttribute(xyzNode, "y");
/* 413 */     String posZ = XMLHelper.getAttribute(xyzNode, "z");
/* 414 */     int x = (int)Math.round(Double.parseDouble(posX));
/* 415 */     int y = (int)Math.round(Double.parseDouble(posY));
/* 416 */     int z = (int)Math.round(Double.parseDouble(posZ));
/* 417 */     return new Point(x, y, z);
/*     */   }
/*     */ 
/*     */   public static Quaternion getQuaternion(Node quatNode) {
/* 421 */     String x = XMLHelper.getAttribute(quatNode, "x");
/* 422 */     String y = XMLHelper.getAttribute(quatNode, "y");
/* 423 */     String z = XMLHelper.getAttribute(quatNode, "z");
/* 424 */     String w = XMLHelper.getAttribute(quatNode, "w");
/* 425 */     return new Quaternion(Float.parseFloat(x), Float.parseFloat(y), Float.parseFloat(z), Float.parseFloat(w));
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WorldFileLoader
 * JD-Core Version:    0.6.0
 */