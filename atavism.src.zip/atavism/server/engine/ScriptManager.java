/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ImporterTopLevel;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.python.core.Py;
/*     */ import org.python.core.PyFile;
/*     */ import org.python.core.PyModule;
/*     */ import org.python.core.PyObject;
/*     */ import org.python.core.PyString;
/*     */ import org.python.core.PyStringMap;
/*     */ import org.python.core.PySystemState;
/*     */ import org.python.core.__builtin__;
/*     */ import org.python.core.imp;
/*     */ 
/*     */ public class ScriptManager
/*     */ {
/* 241 */   private Context cx = null;
/* 242 */   private ScriptableObject scope = null;
/* 243 */   private static PyModule aomodule = null;
/* 244 */   private static PySystemState pySystemState = null;
/*     */   private PyObject pyLocals;
/*     */ 
/*     */   public void init()
/*     */   {
/*  28 */     if (this.cx != null)
/*  29 */       return;
/*  30 */     initPythonState();
/*  31 */     this.pyLocals = null;
/*     */     try
/*     */     {
/*  34 */       this.cx = Context.enter();
/*  35 */       this.scope = new ImporterTopLevel(this.cx, true);
/*     */     }
/*     */     catch (Exception e) {
/*  38 */       throw new AORuntimeException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initLocal()
/*     */   {
/*  49 */     if (this.cx != null)
/*  50 */       return;
/*  51 */     initPythonState();
/*  52 */     this.pyLocals = new PyModule("main", new PyStringMap()).__dict__;
/*     */   }
/*     */ 
/*     */   private void initPythonState()
/*     */   {
/*  57 */     synchronized (getClass()) {
/*  58 */       if (pySystemState == null) {
/*  59 */         PySystemState.initialize();
/*     */ 
/*  61 */         pySystemState = Py.defaultSystemState;
/*  62 */         pySystemState.setClassLoader(getClass().getClassLoader());
/*  63 */         aomodule = imp.addModule("aomodule");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized Object runJSBuffer(String buf)
/*     */     throws JavaScriptException
/*     */   {
/*  75 */     Object result = this.cx.evaluateString(this.scope, buf, "ScriptManager", 1, null);
/*     */ 
/*  80 */     return result;
/*     */   }
/*     */ 
/*     */   public synchronized void runFile(String filename)
/*     */     throws JavaScriptException, FileNotFoundException, IOException, AORuntimeException
/*     */   {
/*     */     try
/*     */     {
/*  93 */       if (filename.endsWith(".py")) {
/*  94 */         runPYFile(filename);
/*     */       }
/*  96 */       else if (filename.endsWith(".js")) {
/*  97 */         runJSFile(filename);
/*     */       }
/*     */       else
/* 100 */         throw new AORuntimeException("Unknown script file type");
/*     */     }
/*     */     catch (FileNotFoundException e)
/*     */     {
/*     */     }
/*     */     catch (AORuntimeException e)
/*     */     {
/* 107 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void runFileWithThrow(String filename)
/*     */     throws JavaScriptException, FileNotFoundException, IOException, AORuntimeException
/*     */   {
/* 120 */     if (filename.endsWith(".py")) {
/* 121 */       runPYFile(filename);
/*     */     }
/* 123 */     else if (filename.endsWith(".js")) {
/* 124 */       runJSFile(filename);
/*     */     }
/*     */     else
/* 127 */       throw new AORuntimeException("Unknown script file type");
/*     */   }
/*     */ 
/*     */   public synchronized Object runJSFile(String filename)
/*     */     throws JavaScriptException, FileNotFoundException, IOException
/*     */   {
/* 139 */     Reader in = null;
/*     */     try {
/* 141 */       in = new FileReader(filename);
/*     */     } catch (FileNotFoundException e) {
/* 143 */       Log.warn("ScriptManager.runJSFile: file not found: " + filename);
/* 144 */       throw e;
/*     */     }
/* 146 */     Object result = null;
/*     */     try {
/* 148 */       result = this.cx.evaluateReader(this.scope, in, filename, 1, null);
/*     */     } catch (IOException e) {
/* 150 */       Log.exception("ScriptManager.runJSFile file=" + filename, e);
/* 151 */       throw e;
/*     */     } catch (RuntimeException e) {
/* 153 */       Log.exception("ScriptManager.runJSFile file=" + filename, e);
/* 154 */       throw e;
/*     */     }
/*     */ 
/* 157 */     return result;
/*     */   }
/*     */ 
/*     */   public synchronized boolean runPYFile(String filename)
/*     */     throws FileNotFoundException
/*     */   {
/* 167 */     if (Log.loggingDebug)
/* 168 */       Log.debug("runPYFile: file=" + filename);
/* 169 */     FileInputStream in = null;
/*     */     try {
/* 171 */       in = new FileInputStream(filename);
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 174 */       Log.warn("ScriptManager.runPYFile: file not found: " + filename);
/* 175 */       throw e;
/*     */     }
/*     */     try
/*     */     {
/* 179 */       Py.setSystemState(pySystemState);
/*     */ 
/* 181 */       Py.runCode(Py.compile_flags(in, filename, "exec", null), this.pyLocals, aomodule.__dict__);
/*     */     }
/*     */     catch (RuntimeException e) {
/* 184 */       Log.exception("ScriptManager.runPYFile: file=" + filename, e);
/* 185 */       throw e;
/*     */     }
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */   public synchronized String getResultString(Object resultObj) {
/* 191 */     return Context.toString(resultObj);
/*     */   }
/*     */ 
/*     */   public synchronized ScriptOutput runPYScript(String script)
/*     */   {
/* 205 */     ByteArrayOutputStream stdout = new ByteArrayOutputStream();
/* 206 */     ByteArrayOutputStream stderr = new ByteArrayOutputStream();
/* 207 */     PyObject saveStdout = pySystemState.stdout;
/* 208 */     PyObject saveStderr = pySystemState.stderr;
/* 209 */     pySystemState.stdout = new PyFile(stdout);
/* 210 */     pySystemState.stderr = new PyFile(stderr);
/* 211 */     Py.setSystemState(pySystemState);
/*     */ 
/* 214 */     Py.exec(Py.compile_flags(script, "<string>", "exec", null), aomodule.__dict__, this.pyLocals);
/*     */ 
/* 217 */     pySystemState.stdout = saveStdout;
/* 218 */     pySystemState.stderr = saveStderr;
/* 219 */     return new ScriptOutput(stdout.toString(), stderr.toString());
/*     */   }
/*     */ 
/*     */   public synchronized PyObject evalPYScript(String script)
/*     */   {
/* 224 */     Py.setSystemState(pySystemState);
/*     */ 
/* 226 */     return __builtin__.eval(new PyString(script), aomodule.__dict__, this.pyLocals);
/*     */   }
/*     */ 
/*     */   public synchronized String evalPYScriptAsString(String script)
/*     */   {
/* 231 */     Py.setSystemState(pySystemState);
/*     */ 
/* 233 */     PyObject result = __builtin__.eval(new PyString(script), aomodule.__dict__, this.pyLocals);
/*     */ 
/* 235 */     if (result == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static class ScriptOutput
/*     */   {
/*     */     public String stdout;
/*     */     public String stderr;
/*     */ 
/*     */     public ScriptOutput(String out, String err)
/*     */     {
/* 196 */       this.stdout = out;
/* 197 */       this.stderr = err;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.ScriptManager
 * JD-Core Version:    0.6.0
 */