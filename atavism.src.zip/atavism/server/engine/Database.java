/*      */ package atavism.server.engine;
/*      */ 
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.server.math.Geometry;
/*      */ import atavism.server.math.Point;
/*      */ import atavism.server.objects.AOObject;
/*      */ import atavism.server.objects.Entity;
/*      */ import atavism.server.objects.ObjectType;
/*      */ import atavism.server.objects.ObjectType.PersistenceDelegate;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import java.beans.ExceptionListener;
/*      */ import java.beans.XMLDecoder;
/*      */ import java.beans.XMLEncoder;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import javax.sql.rowset.serial.SerialBlob;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class Database
/*      */ {
/*   25 */   private static Logger logger = Logger.getLogger(Database.class);
/*      */ 
/* 1942 */   private Connection conn = null;
/*      */ 
/* 1944 */   transient Lock dbLock = LockFactory.makeLock("databaseLock");
/*      */ 
/* 1946 */   private static int largestNamespaceInt = 0;
/*      */ 
/*      */   public Database()
/*      */   {
/*      */     try
/*      */     {
/*   35 */       Class.forName("com.mysql.jdbc.Driver").newInstance();
/*      */     } catch (Exception e) {
/*   37 */       throw new AORuntimeException(new StringBuilder().append("could not find class: ").append(e).toString());
/*      */     }
/*      */ 
/*   41 */     Log.debug("Database: starting keepalive");
/*   42 */     Thread keepAliveThread = new Thread(new KeepAlive(), "DBKeepalive");
/*   43 */     keepAliveThread.start();
/*      */   }
/*      */ 
/*      */   public Database(String sDriver)
/*      */   {
/*   54 */     if (Log.loggingDebug) {
/*   55 */       Log.debug(new StringBuilder().append("Initializing Database with driver ").append(sDriver).toString());
/*   56 */       Log.debug(new StringBuilder().append("classpath = ").append(System.getProperty("java.class.path")).toString());
/*      */     }
/*      */     try {
/*   59 */       Class.forName(sDriver).newInstance();
/*   60 */       if (Log.loggingDebug)
/*   61 */         Log.debug(new StringBuilder().append(sDriver).append(" driver loaded").toString());
/*      */     } catch (Exception e) {
/*   63 */       throw new AORuntimeException(new StringBuilder().append("could not find class: ").append(sDriver).toString());
/*      */     }
/*      */ 
/*   67 */     Log.debug("Database: starting keepalive");
/*   68 */     Thread keepAliveThread = new Thread(new KeepAlive(), "DBKeepalive");
/*   69 */     keepAliveThread.start();
/*      */   }
/*      */ 
/*      */   public Connection getConnection()
/*      */   {
/*   77 */     return this.conn;
/*      */   }
/*      */ 
/*      */   public Lock getLock() {
/*   81 */     return this.dbLock;
/*      */   }
/*      */ 
/*      */   public void connect(String url, String username, String password)
/*      */   {
/*      */     try
/*      */     {
/*  119 */       this.dbLock.lock();
/*      */ 
/*  121 */       if (Log.loggingDebug)
/*  122 */         Log.debug(new StringBuilder().append("*** url = ").append(url).append(" username = ").append(username).append(" password = ").append(password).toString());
/*      */       try {
/*  124 */         this.conn = DriverManager.getConnection(url, username, password);
/*      */       } catch (Exception e) {
/*  126 */         throw new AORuntimeException(new StringBuilder().append("could not connect to database: ").append(e).toString());
/*      */       }
/*      */     } finally {
/*  129 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String update)
/*      */   {
/*  139 */     Statement stmt = null;
/*      */     try {
/*  141 */       this.dbLock.lock();
/*      */       try {
/*  143 */         stmt = this.conn.createStatement();
/*  144 */         int i = stmt.executeUpdate(update);
/*      */ 
/*  150 */         this.dbLock.unlock(); return i;
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  146 */         Log.exception(new StringBuilder().append("Database.executeUpdate: Running update ").append(update).toString(), e);
/*  147 */         int j = -1;
/*      */ 
/*  150 */         this.dbLock.unlock(); return j;
/*      */       } } finally { this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void executeBatch(List<String> statements)
/*      */   {
/*  159 */     Statement stmt = null;
/*      */     try {
/*  161 */       this.dbLock.lock();
/*      */       try {
/*  163 */         stmt = this.conn.createStatement();
/*  164 */         for (String statement : statements)
/*  165 */           stmt.addBatch(statement);
/*  166 */         stmt.executeBatch();
/*      */       } catch (Exception e) {
/*  168 */         Log.exception(new StringBuilder().append("Database.executeBatch: Running statements ").append(statements).toString(), e);
/*      */       }
/*      */     } finally {
/*  171 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean databaseTableContainsColumn(String dbName, String tableName, String columnName)
/*      */   {
/*  186 */     Statement stmt = null;
/*  187 */     ResultSet rs = null;
/*      */     try {
/*  189 */       this.dbLock.lock();
/*      */       try {
/*  191 */         stmt = this.conn.createStatement();
/*  192 */         String query = new StringBuilder().append("SHOW COLUMNS FROM ").append(dbName).append(".").append(tableName).append(" LIKE '").append(columnName).append("'").toString();
/*  193 */         if (Log.loggingDebug)
/*  194 */           Log.debug(new StringBuilder().append("Database.databaseTableContainsColumn query: ").append(query).toString());
/*  195 */         rs = stmt.executeQuery(query);
/*  196 */         if (!rs.next()) {
/*  197 */           i = 0;
/*      */ 
/*  206 */           this.dbLock.unlock(); return i;
/*      */         }
/*  199 */         int i = 1;
/*      */ 
/*  206 */         this.dbLock.unlock(); return i;
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  202 */         throw new AORuntimeException(new StringBuilder().append("Could not run select statement to determine the presence of the '").append(columnName).append("' in table '").append(tableName).append("': ").append(e).toString());
/*      */       }
/*      */     }
/*      */     finally {
/*  206 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean databaseContainsTable(String dbName, String tableName)
/*      */   {
/*  221 */     Statement stmt = null;
/*  222 */     ResultSet rs = null;
/*      */     try {
/*  224 */       this.dbLock.lock();
/*      */       try {
/*  226 */         stmt = this.conn.createStatement();
/*  227 */         String query = new StringBuilder().append("SELECT count(*) FROM information_schema.tables WHERE table_schema = '").append(dbName).append("' AND table_name = '").append(tableName).append("'").toString();
/*      */ 
/*  229 */         rs = stmt.executeQuery(query);
/*  230 */         if (!rs.next()) {
/*  231 */           int i = 0;
/*      */ 
/*  240 */           this.dbLock.unlock(); return i;
/*      */         }
/*  233 */         int count = rs.getInt(1);
/*  234 */         int j = count == 1 ? 1 : 0;
/*      */ 
/*  240 */         this.dbLock.unlock(); return j;
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  237 */         throw new AORuntimeException(new StringBuilder().append("Exception running select statement to find table ").append(tableName).append(": ").append(e).toString());
/*      */       }
/*      */     } finally {
/*  240 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*      */     try
/*      */     {
/*  249 */       this.dbLock.lock();
/*  250 */       if (this.conn != null) {
/*  251 */         this.conn.close();
/*  252 */         this.conn = null;
/*      */       }
/*      */     } catch (Exception e) {
/*  255 */       Log.error("Database.close: unable to close connection");
/*      */     } finally {
/*  257 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void encacheNamespaceMapping()
/*      */   {
/*  267 */     Statement stmt = null;
/*  268 */     ResultSet rs = null;
/*      */     try {
/*  270 */       this.dbLock.lock();
/*  271 */       stmt = this.conn.createStatement();
/*  272 */       String query = "SELECT namespace_string, namespace_int FROM namespaces";
/*  273 */       rs = stmt.executeQuery(query);
/*  274 */       while (rs.next()) {
/*  275 */         String nsString = rs.getString("namespace_string");
/*  276 */         Integer nsInt = Integer.valueOf(rs.getInt("namespace_int"));
/*  277 */         Namespace ns = Namespace.getNamespaceFromInt(nsInt);
/*  278 */         if (ns == null)
/*  279 */           Namespace.addDBNamespace(nsString, nsInt.intValue());
/*  280 */         else if (!ns.getName().equals(nsString)) {
/*  281 */           throw new AORuntimeException(new StringBuilder().append("Database.encacheNamespaceMapping: Encached namespace ").append(ns).append(" doesn't have the right string ").append(nsString).toString());
/*      */         }
/*  283 */         if (nsInt.intValue() > largestNamespaceInt)
/*  284 */           largestNamespaceInt = nsInt.intValue();
/*      */       }
/*      */     } catch (Exception e) {
/*  287 */       Log.exception("encacheNamespaceMapping", e);
/*  288 */       throw new AORuntimeException(new StringBuilder().append("database error: ").append(e).toString());
/*      */     } finally {
/*  290 */       if (stmt != null) {
/*      */         try {
/*  292 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  294 */           stmt = null;
/*      */         }
/*      */       }
/*  297 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Namespace findExistingNamespace(String nsString)
/*      */   {
/*  309 */     encacheNamespaceMapping();
/*  310 */     return Namespace.getNamespaceIfExists(nsString);
/*      */   }
/*      */ 
/*      */   public Namespace findExistingNamespace(Integer nsInt)
/*      */   {
/*  321 */     encacheNamespaceMapping();
/*  322 */     return Namespace.getNamespaceFromInt(nsInt);
/*      */   }
/*      */ 
/*      */   public Namespace createNamespace(String nsString)
/*      */   {
/*  333 */     Statement stmt = null;
/*  334 */     this.dbLock.lock();
/*      */     try
/*      */     {
/*  337 */       Namespace ns = findExistingNamespace(nsString);
/*  338 */       if (ns != null) {
/*  339 */         Namespace localNamespace1 = ns;
/*      */         return localNamespace1;
/*      */       }
/*  340 */       if (largestNamespaceInt >= 31) {
/*  341 */         Log.error(new StringBuilder().append("Database.createNamespace: There are ").append(largestNamespaceInt).append(" namespaces already, so you can't create another one").toString());
/*      */ 
/*  343 */         throw new AORuntimeException(new StringBuilder().append("When creating namespace ").append(nsString).append(", too many Namespaces").toString());
/*      */       }
/*      */ 
/*  346 */       stmt = this.conn.createStatement();
/*  347 */       nsInt = largestNamespaceInt + 1;
/*  348 */       String update = new StringBuilder().append("INSERT INTO namespaces (namespace_string, namespace_int) VALUES ('").append(nsString).append("'").append(", ").append(nsInt).append(")").toString();
/*      */ 
/*  350 */       int rows = 0;
/*      */       try {
/*  352 */         rows = stmt.executeUpdate(update);
/*      */       }
/*      */       catch (SQLException ex)
/*      */       {
/*  359 */         ns = findExistingNamespace(nsString);
/*  360 */         if (ns != null) {
/*  361 */           Namespace localNamespace2 = ns;
/*      */ 
/*  376 */           if (stmt != null) {
/*      */             try {
/*  378 */               stmt.close();
/*      */             } catch (SQLException sqlEx) {
/*  380 */               stmt = null;
/*      */             }
/*      */           }
/*  383 */           this.dbLock.unlock(); return localNamespace2;
/*      */         }
/*      */       }
/*  363 */       if (rows != 1) {
/*  364 */         throw new AORuntimeException(new StringBuilder().append("Could not create namespace '").append(nsString).append("'").toString());
/*      */       }
/*      */ 
/*  368 */       largestNamespaceInt = nsInt;
/*  369 */       if (Log.loggingDebug)
/*  370 */         Log.debug(new StringBuilder().append("Database.getOrCreateNamespaceInt: string ").append(nsString).append(" <=> ").append(nsInt).toString());
/*  371 */       ex = Namespace.addDBNamespace(nsString, nsInt);
/*      */       return ex;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       int nsInt;
/*  373 */       Log.exception("createNamespace", e);
/*  374 */       Object localObject1 = null;
/*      */       return localObject1;
/*      */     }
/*      */     finally
/*      */     {
/*  376 */       if (stmt != null) {
/*      */         try {
/*  378 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  380 */           stmt = null;
/*      */         }
/*      */       }
/*  383 */       this.dbLock.unlock(); } throw localObject2;
/*      */   }
/*      */ 
/*      */   public void createCharacter(String worldName, OID aoid, AOObject user, Namespace namespace)
/*      */   {
/*      */     try
/*      */     {
/*  399 */       this.dbLock.lock();
/*      */ 
/*  401 */       user.atavismID(aoid);
/*  402 */       saveObject(null, user, namespace);
/*      */ 
/*  405 */       mapAtavismID(worldName, aoid, user.getOid());
/*      */     }
/*      */     finally {
/*  408 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void mapAtavismID(String worldName, OID atavismID, OID objID)
/*      */   {
/*  419 */     Statement stmt = null;
/*  420 */     int nsInt = Namespace.WORLD_MANAGER.getNumber();
/*      */     try {
/*  422 */       this.dbLock.lock();
/*  423 */       stmt = this.conn.createStatement();
/*  424 */       String update = new StringBuilder().append("INSERT INTO player_character (account_id, obj_id, namespace_int, world_name) VALUES (").append(atavismID.toLong()).append(", ").append(objID.toLong()).append(", ").append(nsInt).append(", '").append(worldName).append("')").toString();
/*      */ 
/*  426 */       int rows = stmt.executeUpdate(update);
/*  427 */       if (rows != 1) {
/*  428 */         throw new AORuntimeException("failed to map atavismid");
/*      */       }
/*  430 */       if (Log.loggingDebug)
/*  431 */         Log.debug(new StringBuilder().append("Database.mapAtavismID: mapping aoid ").append(atavismID).append(" to objID ").append(objID).toString());
/*      */     }
/*      */     catch (Exception sqlEx) {
/*  434 */       Log.exception("mapAtavismID", e);
/*      */     } finally {
/*  436 */       if (stmt != null) {
/*      */         try {
/*  438 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  440 */           stmt = null;
/*      */         }
/*      */       }
/*  443 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Set<OID> getPersistedObjects(Namespace namespace, Geometry g)
/*      */   {
/*  459 */     Statement stmt = null;
/*  460 */     ResultSet rs = null;
/*      */     try {
/*  462 */       this.dbLock.lock();
/*  463 */       stmt = this.conn.createStatement();
/*  464 */       String query = new StringBuilder().append("SELECT obj_id FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("'").append(" AND namespace_int = ").append(namespace.getNumber()).append(" AND ((locX > ").append(g.getMinX()).append(" AND locX < ").append(g.getMaxX()).append(" AND locZ > ").append(g.getMinZ()).append(" AND locZ < ").append(g.getMaxZ()).append(") OR (locX IS NULL))").toString();
/*      */ 
/*  472 */       rs = stmt.executeQuery(query);
/*      */ 
/*  474 */       Set l = new HashSet();
/*  475 */       while (rs.next()) {
/*  476 */         oid = OID.fromLong(rs.getLong(1));
/*  477 */         l.add(oid);
/*      */       }
/*  479 */       if (Log.loggingDebug) {
/*  480 */         Log.debug(new StringBuilder().append("Database.getPersistedObjects: found ").append(l.size()).append(" persisted objects for geometry ").append(g).toString());
/*      */       }
/*  482 */       OID oid = l;
/*      */       return oid;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  484 */       Log.exception("getPersistedObjects", e);
/*  485 */       throw new AORuntimeException(new StringBuilder().append("database: ").append(e).toString());
/*      */     } finally {
/*  487 */       if (rs != null) {
/*      */         try {
/*  489 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  491 */           rs = null;
/*      */         }
/*  493 */         if (stmt != null) {
/*      */           try {
/*  495 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  497 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  501 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public Entity loadEntity(OID oid, Namespace namespace)
/*      */   {
/*      */     try
/*      */     {
/*  521 */       InputStream is = retrieveEntityDataByOidAndNamespace(oid, namespace);
/*  522 */       if (is == null) {
/*  523 */         return null;
/*      */       }
/*  525 */       XMLDecoder decoder = new XMLDecoder(is, null, new XMLExceptionListener(), getClass().getClassLoader());
/*      */ 
/*  527 */       Entity entity = (Entity)decoder.readObject();
/*  528 */       decoder.close();
/*      */ 
/*  531 */       return entity; } catch (Exception e) {
/*      */     }
/*  533 */     throw new AORuntimeException("database.loadObject", e);
/*      */   }
/*      */ 
/*      */   public Entity loadEntity(String persistenceKey)
/*      */   {
/*  557 */     InputStream is = retrieveEntityDataByPersistenceKey(persistenceKey);
/*  558 */     if (is == null) {
/*  559 */       return null;
/*      */     }
/*  561 */     XMLDecoder decoder = new XMLDecoder(is, null, new XMLExceptionListener(), getClass().getClassLoader());
/*      */ 
/*  563 */     Entity entity = (Entity)decoder.readObject();
/*  564 */     decoder.close();
/*      */ 
/*  567 */     return entity;
/*      */   }
/*      */ 
/*      */   public InputStream retrieveEntityDataByOidAndNamespace(OID oid, Namespace namespace)
/*      */   {
/*  581 */     Statement stmt = null;
/*  582 */     int nsInt = namespace.getNumber();
/*  583 */     long oidLong = oid.toLong();
/*      */     try {
/*  585 */       this.dbLock.lock();
/*  586 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  588 */       ResultSet rs = stmt.executeQuery(new StringBuilder().append("SELECT data FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("' AND obj_id = ").append(oidLong).append(" AND namespace_int=").append(nsInt).toString());
/*      */ 
/*  591 */       if (!rs.next()) {
/*  592 */         Log.error(new StringBuilder().append("retrieveEntityDataByOidAndNamespace: not found oid=").append(oid).append(" namespace=").append(namespace).toString());
/*      */ 
/*  594 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/*  596 */       Blob dataBlob = rs.getBlob("data");
/*  597 */       long blobLen = dataBlob.length();
/*  598 */       byte[] blobBytes = dataBlob.getBytes(1L, (int)blobLen);
/*      */ 
/*  600 */       ByteArrayInputStream bis = new ByteArrayInputStream(blobBytes);
/*  601 */       if (Log.loggingDebug) {
/*  602 */         Log.debug(new StringBuilder().append("retrieveEntityDataByOidAndNamespace: oid=").append(oid).append(" size=").append(blobLen).toString());
/*      */       }
/*      */ 
/*  605 */       ByteArrayInputStream localByteArrayInputStream1 = bis;
/*      */       return localByteArrayInputStream1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  607 */       Log.exception("retrieveEntityDataByOidAndNamespace", e);
/*  608 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/*  610 */       if (stmt != null) {
/*      */         try {
/*  612 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  614 */           stmt = null;
/*      */         }
/*      */       }
/*  617 */       this.dbLock.unlock(); } throw localObject2;
/*      */   }
/*      */ 
/*      */   public InputStream retrieveEntityDataByPersistenceKey(String persistenceKey)
/*      */   {
/*  634 */     Statement stmt = null;
/*      */     try {
/*  636 */       this.dbLock.lock();
/*  637 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  639 */       ResultSet rs = stmt.executeQuery(new StringBuilder().append("SELECT data FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("' AND persistence_key='").append(persistenceKey).append("'").toString());
/*      */ 
/*  642 */       if (!rs.next()) {
/*  643 */         Log.error(new StringBuilder().append("retrieveEntityDataByPersistenceKey: not found key=").append(persistenceKey).toString());
/*      */ 
/*  645 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/*  647 */       Blob dataBlob = rs.getBlob("data");
/*  648 */       long blobLen = dataBlob.length();
/*  649 */       byte[] blobBytes = dataBlob.getBytes(1L, (int)blobLen);
/*  650 */       ByteArrayInputStream bis = new ByteArrayInputStream(blobBytes);
/*  651 */       if (Log.loggingDebug) {
/*  652 */         Log.debug(new StringBuilder().append("retrieveEntityDataByPersistenceKey: key=").append(persistenceKey).append(" size=").append(blobLen).toString());
/*      */       }
/*      */ 
/*  655 */       ByteArrayInputStream localByteArrayInputStream1 = bis;
/*      */       return localByteArrayInputStream1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  657 */       Log.exception("retrieveEntityDataByPersistenceKey", e);
/*  658 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/*  660 */       if (stmt != null) {
/*      */         try {
/*  662 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  664 */           stmt = null;
/*      */         }
/*      */       }
/*  667 */       this.dbLock.unlock(); } throw localObject2;
/*      */   }
/*      */ 
/*      */   public OID getOidByName(String name, Namespace namespace)
/*      */   {
/*  673 */     return getOidByName(name, namespace, null);
/*      */   }
/*      */ 
/*      */   public OID getOidByName(String name, Namespace namespace, OID instanceOid)
/*      */   {
/*  678 */     Statement stmt = null;
/*  679 */     int nsInt = namespace.getNumber();
/*      */     try {
/*  681 */       this.dbLock.lock();
/*  682 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  684 */       String query = new StringBuilder().append("SELECT obj_id FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("'").append(" AND namespace_int=").append(nsInt).append(" AND name='").append(name).append("'").toString();
/*      */ 
/*  688 */       if (instanceOid != null)
/*  689 */         query = new StringBuilder().append(query).append(" AND instance=").append(instanceOid.toLong()).toString();
/*  690 */       ResultSet rs = stmt.executeQuery(query);
/*  691 */       if (!rs.next()) {
/*  692 */         Log.debug(new StringBuilder().append("getOidByName: unknown name=").append(name).append(" namespace=").append(namespace).append(" instanceOid=").append(instanceOid).toString());
/*      */ 
/*  695 */         localOID = null;
/*      */         return localOID;
/*      */       }
/*  697 */       OID localOID = OID.fromLong(rs.getLong(1));
/*      */       return localOID;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  699 */       Log.exception("getOidByName", e);
/*  700 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/*  702 */       if (stmt != null) {
/*      */         try {
/*  704 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  706 */           stmt = null;
/*      */         }
/*      */       }
/*  709 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public String getObjectName(OID oid, Namespace namespace)
/*      */   {
/*  718 */     Statement stmt = null;
/*  719 */     int nsInt = namespace.getNumber();
/*  720 */     long oidLong = oid.toLong();
/*      */     try {
/*  722 */       this.dbLock.lock();
/*  723 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  725 */       String query = new StringBuilder().append("SELECT name FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("'").append(" AND namespace_int=").append(nsInt).append(" AND obj_id=").append(oidLong).toString();
/*      */ 
/*  729 */       ResultSet rs = stmt.executeQuery(query);
/*  730 */       if (!rs.next()) {
/*  731 */         Log.debug(new StringBuilder().append("getObjectName: unknown oid=").append(oid).append(" namespace=").append(namespace).toString());
/*      */ 
/*  733 */         str1 = null;
/*      */         return str1;
/*      */       }
/*  735 */       String str1 = rs.getString(1);
/*      */       return str1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  737 */       Log.exception("getObjectName", e);
/*  738 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/*  740 */       if (stmt != null) {
/*      */         try {
/*  742 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  744 */           stmt = null;
/*      */         }
/*      */       }
/*  747 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public List<Object> getOidsAndNamesMatchingName(String playerName, boolean exactMatch)
/*      */   {
/*  765 */     Statement stmt = null;
/*      */     try {
/*  767 */       this.dbLock.lock();
/*  768 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  770 */       ResultSet rs = stmt.executeQuery(new StringBuilder().append("SELECT obj_id, name from objstore WHERE world_name = '").append(Engine.getWorldName()).append("'").append(" AND namespace_int = ").append(Namespace.WORLD_MANAGER.getNumber()).append(" AND name").append(exactMatch ? "=" : " LIKE ").append("'").append(playerName).append(exactMatch ? "" : "%").append("'").toString());
/*      */ 
/*  774 */       List oids = new LinkedList();
/*  775 */       List names = new LinkedList();
/*  776 */       while (rs.next()) {
/*  777 */         oids.add(OID.fromLong(rs.getLong("obj_id")));
/*  778 */         names.add(rs.getString("name"));
/*      */       }
/*  780 */       List result = new LinkedList();
/*  781 */       result.add(oids);
/*  782 */       result.add(names);
/*  783 */       if (Log.loggingDebug) {
/*  784 */         Log.debug(new StringBuilder().append("Database.getOidsAndNamesMatching: For playerName '").append(playerName).append("'").append(", found ").append(oids.size()).append(" oids: ").append(makeOidCollectionString(oids)).append(" and ").append(names.size()).append(" names: ").append(makeNameCollectionString(names)).toString());
/*      */       }
/*      */ 
/*  787 */       List localList1 = result;
/*      */       return localList1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  789 */       Log.exception("getOidsAndNamesMatchingName", e);
/*  790 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/*  792 */       if (stmt != null) {
/*      */         try {
/*  794 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  796 */           stmt = null;
/*      */         }
/*      */       }
/*  799 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public List<String> getObjectNames(List<OID> inputOids, Namespace namespace, String unknownName)
/*      */   {
/*  814 */     List names = new LinkedList();
/*  815 */     if ((inputOids == null) || (inputOids.size() == 0)) {
/*  816 */       if (Log.loggingDebug)
/*  817 */         Log.debug("Database.getObjectNames: No oids in inputOids so returning empty name list");
/*  818 */       return names;
/*      */     }
/*  820 */     String whereList = "";
/*  821 */     for (OID oid : inputOids) {
/*  822 */       long oidLong = oid.toLong();
/*  823 */       if (whereList != "")
/*  824 */         whereList = new StringBuilder().append(whereList).append(" OR ").toString();
/*  825 */       whereList = new StringBuilder().append(whereList).append("(obj_id = ").append(oidLong).append(")").toString();
/*      */     }
/*  827 */     Statement stmt = null;
/*      */     try {
/*  829 */       this.dbLock.lock();
/*  830 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  832 */       ResultSet rs = stmt.executeQuery(new StringBuilder().append("SELECT obj_id, name from objstore WHERE world_name = '").append(Engine.getWorldName()).append("'").append(" AND namespace_int = ").append(namespace.getNumber()).append(" AND (").append(whereList).append(")").toString());
/*      */ 
/*  834 */       List readOids = new LinkedList();
/*  835 */       List readNames = new LinkedList();
/*  836 */       while (rs.next()) {
/*  837 */         readOids.add(OID.fromLong(rs.getLong("obj_id")));
/*  838 */         readNames.add(rs.getString("name"));
/*      */       }
/*  840 */       List returnedNames = new LinkedList();
/*  841 */       for (OID oid : inputOids) {
/*  842 */         int index = readOids.indexOf(oid);
/*  843 */         String name = unknownName;
/*  844 */         if (index != -1)
/*  845 */           name = (String)readNames.get(index);
/*  846 */         returnedNames.add(name);
/*      */       }
/*  848 */       if (Log.loggingDebug) {
/*  849 */         Log.debug(new StringBuilder().append("Database.getObjectNames: For oids ").append(makeOidCollectionString(inputOids)).append(", returning names ").append(makeNameCollectionString(returnedNames)).toString());
/*      */       }
/*      */ 
/*  853 */       ??? = returnedNames;
/*      */       return ???;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  855 */       Log.exception("getObjectNames", e);
/*  856 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/*  858 */       if (stmt != null) {
/*      */         try {
/*  860 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  862 */           stmt = null;
/*      */         }
/*      */       }
/*  865 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean characterNameTaken(String name)
/*      */   {
/*  877 */     Statement stmt = null;
/*  878 */     ResultSet rs = null;
/*      */     try {
/*  880 */       this.dbLock.lock();
/*  881 */       stmt = this.conn.createStatement();
/*  882 */       String query = new StringBuilder().append("SELECT count(1) AS found FROM objstore WHERE type = 'PLAYER' AND LOWER(name) = lower('").append(name).append("')").toString();
/*  883 */       rs = stmt.executeQuery(query);
/*      */ 
/*  886 */       if (rs.next()) {
/*  887 */         count = rs.getInt(1);
/*  888 */         if (count > 0) {
/*  889 */           int i = 1;
/*      */           return i;
/*      */         }
/*      */       }
/*  891 */       count = 0;
/*      */       return count;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  893 */       Log.warn(new StringBuilder().append("Database.getUserName: unable to check username, this is ok if you are not on production server: ").append(e).toString());
/*  894 */       int count = 0;
/*      */       return count;
/*      */     }
/*      */     finally
/*      */     {
/*  896 */       if (rs != null) {
/*      */         try {
/*  898 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  900 */           rs = null;
/*      */         }
/*  902 */         if (stmt != null) {
/*      */           try {
/*  904 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  906 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  910 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static String makeOidCollectionString(List<OID> oids)
/*      */   {
/*  915 */     String oidString = "";
/*  916 */     for (OID oid : oids) {
/*  917 */       if (oidString == "")
/*  918 */         oidString = new StringBuilder().append(oidString).append(oid).toString();
/*      */       else
/*  920 */         oidString = new StringBuilder().append(oidString).append(",").append(oid).toString();
/*      */     }
/*  922 */     return oidString;
/*      */   }
/*      */ 
/*      */   public static String makeNameCollectionString(Collection<String> names) {
/*  926 */     String nameString = "";
/*  927 */     for (String name : names) {
/*  928 */       if (nameString != "")
/*  929 */         nameString = new StringBuilder().append(nameString).append(",").toString();
/*  930 */       nameString = new StringBuilder().append(nameString).append("'").append(name).append("'").toString();
/*      */     }
/*  932 */     return nameString;
/*      */   }
/*      */ 
/*      */   public List<Namespace> getObjectNamespaces(OID oid)
/*      */   {
/*  937 */     Statement stmt = null;
/*  938 */     long oidLong = oid.toLong();
/*      */     try {
/*  940 */       this.dbLock.lock();
/*  941 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  943 */       ResultSet rs = stmt.executeQuery(new StringBuilder().append("SELECT namespace_int FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("'").append(" AND obj_id=").append(oidLong).toString());
/*      */ 
/*  947 */       List result = new ArrayList(6);
/*  948 */       while (rs.next()) {
/*  949 */         nsInt = rs.getInt(1);
/*  950 */         Namespace namespace = Namespace.getNamespaceFromInt(Integer.valueOf(nsInt));
/*  951 */         if (namespace != null)
/*  952 */           result.add(namespace);
/*      */         else {
/*  954 */           Log.error(new StringBuilder().append("getObjectNamespaces: unknown namespace id for oid=").append(oid).append(" nsInt=").append(nsInt).toString());
/*      */         }
/*      */       }
/*  957 */       if (result.size() == 0) {
/*  958 */         nsInt = null;
/*      */         return nsInt;
/*      */       }
/*  959 */       int nsInt = result;
/*      */       return nsInt;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  961 */       Log.exception("getOidByName", e);
/*  962 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/*  964 */       if (stmt != null) {
/*      */         try {
/*  966 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  968 */           stmt = null;
/*      */         }
/*      */       }
/*  971 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public List<OID> getInstanceContent(OID instanceOid, ObjectType exclusion)
/*      */   {
/*  977 */     Statement stmt = null;
/*      */     try {
/*  979 */       this.dbLock.lock();
/*  980 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/*  982 */       String queryString = new StringBuilder().append("SELECT obj_id FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("'").append(" AND instance=").append(instanceOid).append(" AND namespace_int=").append(Namespace.WORLD_MANAGER.getNumber()).toString();
/*      */ 
/*  986 */       if (exclusion != null) {
/*  987 */         queryString = new StringBuilder().append(queryString).append(" AND type<>'").append(exclusion.getTypeName()).append("'").toString();
/*      */       }
/*  989 */       ResultSet rs = stmt.executeQuery(queryString);
/*      */ 
/*  991 */       List result = new ArrayList(100);
/*  992 */       while (rs.next()) {
/*  993 */         oid = OID.fromLong(rs.getLong(1));
/*  994 */         result.add(oid);
/*      */       }
/*  996 */       if (Log.loggingDebug) {
/*  997 */         Log.debug(new StringBuilder().append("getInstanceContent: instanceOid=").append(instanceOid).append(" returning ").append(result.size()).append(" oids").toString());
/*      */       }
/*  999 */       OID oid = result;
/*      */       return oid;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1001 */       Log.exception("getInstanceContent", e);
/* 1002 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/* 1004 */       if (stmt != null) {
/*      */         try {
/* 1006 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1008 */           stmt = null;
/*      */         }
/*      */       }
/* 1011 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void deleteObjectData(OID oid)
/*      */   {
/* 1021 */     Statement stmt = null;
/* 1022 */     long oidLong = oid.toLong();
/*      */     try {
/* 1024 */       this.dbLock.lock();
/* 1025 */       stmt = this.conn.createStatement();
/* 1026 */       stmt.execute(new StringBuilder().append("DELETE FROM objstore WHERE world_name=\"").append(Engine.getWorldName()).append("\" AND obj_id = ").append(oidLong).toString());
/*      */     }
/*      */     catch (Exception e) {
/* 1029 */       Log.exception("deleteObjectData", e);
/* 1030 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/* 1032 */       if (stmt != null) {
/*      */         try {
/* 1034 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1036 */           stmt = null;
/*      */         }
/*      */       }
/* 1039 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteObjectData(OID oid, Namespace namespace)
/*      */   {
/* 1049 */     int nsInt = namespace.getNumber();
/* 1050 */     long oidLong = oid.toLong();
/* 1051 */     Statement stmt = null;
/*      */     try {
/* 1053 */       this.dbLock.lock();
/* 1054 */       stmt = this.conn.createStatement();
/* 1055 */       stmt.execute(new StringBuilder().append("DELETE FROM objstore WHERE world_name=\"").append(Engine.getWorldName()).append("\" AND obj_id = ").append(oidLong).append(" AND namespace_int=").append(nsInt).toString());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1059 */       Log.exception("deleteObjectData", e);
/* 1060 */       throw new AORuntimeException("database error: ", e);
/*      */     } finally {
/* 1062 */       if (stmt != null) {
/*      */         try {
/* 1064 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1066 */           stmt = null;
/*      */         }
/*      */       }
/* 1069 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deletePlayerCharacter(OID oid)
/*      */   {
/* 1080 */     Statement stmt = null;
/* 1081 */     long oidLong = oid.toLong();
/*      */     try {
/* 1083 */       this.dbLock.lock();
/* 1084 */       stmt = this.conn.createStatement();
/* 1085 */       stmt.execute(new StringBuilder().append("DELETE FROM player_character WHERE obj_id = ").append(oidLong).toString());
/*      */     } catch (Exception e) {
/* 1087 */       Log.exception("deletePlayerCharacter", e);
/* 1088 */       throw new AORuntimeException("database error: ", e);
/*      */     } finally {
/* 1090 */       if (stmt != null) {
/*      */         try {
/* 1092 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1094 */           stmt = null;
/*      */         }
/*      */       }
/* 1097 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveObject(Entity entity, Namespace namespace)
/*      */   {
/* 1107 */     saveObject(null, entity, namespace);
/*      */   }
/*      */ 
/*      */   public void saveObject(String persistenceKey, byte[] data, Namespace namespace)
/*      */   {
/*      */     try
/*      */     {
/* 1122 */       ByteArrayInputStream bs = new ByteArrayInputStream(data);
/* 1123 */       ObjectInputStream ois = new ObjectInputStream(bs);
/* 1124 */       Entity entity = null;
/*      */       try {
/* 1126 */         entity = (Entity)ois.readObject();
/*      */       } catch (ClassNotFoundException e) {
/* 1128 */         throw new RuntimeException("call not found", e);
/*      */       }
/* 1130 */       saveObject(persistenceKey, entity, namespace);
/*      */     } catch (IOException e) {
/* 1132 */       throw new AORuntimeException("saveObject", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveObject(String persistenceKey, Entity entity, Namespace namespace)
/*      */   {
/* 1146 */     Lock entityLock = entity.getLock();
/*      */ 
/* 1149 */     Lock worldNodeLock = null;
/* 1150 */     AOObject obj = null;
/* 1151 */     if ((entity instanceof AOObject)) {
/* 1152 */       obj = (AOObject)entity;
/* 1153 */       WMWorldNode node = (WMWorldNode)obj.worldNode();
/* 1154 */       if ((node != null) && 
/* 1155 */         (node.getQuadNode() != null)) {
/* 1156 */         worldNodeLock = node.getQuadNode().getTree().getLock();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1162 */     byte[] data = null;
/*      */     try
/*      */     {
/* 1167 */       AOObject.transferLock.lock();
/*      */       try
/*      */       {
/* 1170 */         if (worldNodeLock != null) {
/* 1171 */           worldNodeLock.lock();
/*      */         }
/*      */         try
/*      */         {
/* 1175 */           entityLock.lock();
/*      */ 
/* 1177 */           Log.debug(new StringBuilder().append("encoding entity type=").append(entity.getType()).toString());
/*      */ 
/* 1179 */           ByteArrayOutputStream ba = new ByteArrayOutputStream();
/* 1180 */           encodeEntity(ba, entity);
/*      */ 
/* 1192 */           data = ba.toByteArray();
/* 1193 */           if (logger.isDebugEnabled()) {
/* 1194 */             logger.debug(new StringBuilder().append("Database.saveObject: persistenceKey=").append(persistenceKey).append(", ns=").append(namespace).append(" type=").append(entity.getType()).append(" xml conversion: length=").append(data.length).append(", string=").append(new String(data)).toString());
/*      */           }
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1199 */           throw new AORuntimeException(new StringBuilder().append("Database.saveObject: failed on ").append(obj.getName()).toString(), e);
/*      */         }
/*      */         finally {
/* 1202 */           entityLock.unlock();
/*      */         }
/*      */       } finally {
/* 1205 */         if (worldNodeLock != null)
/* 1206 */           worldNodeLock.unlock();
/*      */       }
/*      */     }
/*      */     finally {
/* 1210 */       AOObject.transferLock.unlock();
/*      */     }
/*      */ 
/* 1214 */     saveObjectHelper(persistenceKey, entity, namespace, data);
/*      */   }
/*      */ 
/*      */   protected void encodeEntity(ByteArrayOutputStream ba, Entity entity)
/*      */   {
/* 1225 */     Thread cur = Thread.currentThread();
/* 1226 */     ClassLoader ccl = cur.getContextClassLoader();
/* 1227 */     ClassLoader myClassLoader = getClass().getClassLoader();
/* 1228 */     cur.setContextClassLoader(myClassLoader);
/* 1229 */     XMLEncoder encoder = null;
/*      */     try {
/* 1231 */       encoder = new XMLEncoder(ba);
/* 1232 */       encoder.setExceptionListener(new ExceptionListener() {
/*      */         public void exceptionThrown(Exception exception) {
/* 1234 */           Log.exception(exception);
/*      */         }
/*      */       });
/* 1237 */       encoder.setPersistenceDelegate(ObjectType.class, new ObjectType.PersistenceDelegate());
/*      */ 
/* 1239 */       encoder.writeObject(entity);
/*      */     } finally {
/* 1241 */       if (null != encoder) {
/* 1242 */         encoder.close();
/*      */         try {
/* 1244 */           ba.flush();
/*      */         }
/*      */         catch (Exception e) {
/* 1247 */           Log.exception("Database.encodeEntity", e);
/*      */         }
/*      */       }
/*      */ 
/* 1251 */       cur.setContextClassLoader(ccl);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveObjectHelper(String persistenceKey, Entity entity, Namespace namespace, byte[] data)
/*      */   {
/* 1265 */     AOObject obj = null;
/* 1266 */     Point loc = null;
/* 1267 */     OID instanceOid = null;
/* 1268 */     int nsInt = namespace.getNumber();
/* 1269 */     if ((entity instanceof AOObject)) {
/* 1270 */       obj = (AOObject)entity;
/* 1271 */       loc = obj.getLoc();
/* 1272 */       if (obj.worldNode() != null)
/* 1273 */         instanceOid = obj.worldNode().getInstanceOid();
/*      */     }
/* 1275 */     Statement stmt = null;
/* 1276 */     long oidLong = entity.getOid().toLong();
/*      */     try {
/* 1278 */       this.dbLock.lock();
/*      */ 
/* 1280 */       stmt = this.conn.createStatement(1005, 1008);
/*      */ 
/* 1283 */       ResultSet uprs = stmt.executeQuery(new StringBuilder().append("SELECT * FROM objstore WHERE world_name='").append(Engine.getWorldName()).append("' AND obj_id=").append(oidLong).append(" AND namespace_int=").append(nsInt).toString());
/*      */ 
/* 1288 */       boolean prevSaved = uprs.first();
/*      */ 
/* 1290 */       if (!prevSaved) {
/* 1291 */         uprs.moveToInsertRow();
/* 1292 */         if (Log.loggingDebug) {
/* 1293 */           Log.debug(new StringBuilder().append("Database.saveObject: obj not in database, moved to insert row: ").append(obj).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1298 */       if (Log.loggingDebug) {
/* 1299 */         Log.debug(new StringBuilder().append("Database.saveObjectHelper: saving obj: ").append(entity.getName()).toString());
/*      */       }
/* 1301 */       updateRow(uprs, instanceOid, loc, entity.getOid(), nsInt, data, entity.getName(), entity.getType().getTypeName(), persistenceKey);
/*      */ 
/* 1306 */       if (prevSaved)
/* 1307 */         uprs.updateRow();
/*      */       else {
/* 1309 */         uprs.insertRow();
/*      */       }
/*      */ 
/* 1317 */       Log.debug("done with saving char to the database");
/*      */     } catch (Exception e) {
/* 1319 */       Log.exception("saveObjectHelper", e);
/* 1320 */       throw new AORuntimeException("database error", e);
/*      */     } finally {
/* 1322 */       if (stmt != null) {
/*      */         try {
/* 1324 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1326 */           stmt = null;
/*      */         }
/*      */       }
/* 1329 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updateRow(ResultSet uprs, OID instanceOid, Point loc, OID oid, int nsInt, byte[] data, String name, String type, String persistenceKey)
/*      */     throws SQLException, IOException
/*      */   {
/* 1357 */     if (Log.loggingDebug) {
/* 1358 */       Log.debug(new StringBuilder().append("byte array length=").append(data.length).toString());
/*      */     }
/*      */ 
/* 1361 */     Log.debug("Database.updateRow: creating blob from byte stream");
/* 1362 */     Blob blob = new SerialBlob(data);
/* 1363 */     if (Log.loggingDebug) {
/* 1364 */       Log.debug(new StringBuilder().append("Database.updateRow: created blob, datalength=").append(data.length).append(", bloblength=").append(blob.length()).toString());
/*      */     }
/*      */ 
/* 1368 */     uprs.updateLong("obj_id", oid.toLong());
/* 1369 */     uprs.updateInt("namespace_int", nsInt);
/* 1370 */     uprs.updateString("world_name", Engine.getWorldName());
/* 1371 */     if (instanceOid != null)
/* 1372 */       uprs.updateLong("instance", instanceOid.toLong());
/*      */     else
/* 1374 */       uprs.updateNull("instance");
/* 1375 */     if (loc != null) {
/* 1376 */       uprs.updateFloat("locX", loc.getX());
/* 1377 */       uprs.updateFloat("locY", loc.getY());
/* 1378 */       uprs.updateFloat("locZ", loc.getZ());
/*      */     } else {
/* 1380 */       uprs.updateNull("locX");
/* 1381 */       uprs.updateNull("locY");
/* 1382 */       uprs.updateNull("locZ");
/*      */     }
/* 1384 */     uprs.updateString("type", type);
/* 1385 */     uprs.updateString("name", name);
/* 1386 */     if (persistenceKey != null) {
/* 1387 */       uprs.updateString("persistence_key", persistenceKey);
/*      */     }
/* 1389 */     uprs.updateBlob("data", blob);
/*      */   }
/*      */ 
/*      */   public List<OID> getGameIDs(String worldName, OID atavismID)
/*      */   {
/* 1403 */     Statement stmt = null;
/* 1404 */     ResultSet rs = null;
/*      */     try {
/* 1406 */       this.dbLock.lock();
/* 1407 */       stmt = this.conn.createStatement();
/* 1408 */       String query = new StringBuilder().append("SELECT obj_id FROM player_character WHERE account_id = ").append(atavismID.toLong()).append(" AND world_name = '").append(worldName).append("'").toString();
/*      */ 
/* 1410 */       rs = stmt.executeQuery(query);
/*      */ 
/* 1412 */       LinkedList l = new LinkedList();
/* 1413 */       while (rs.next()) {
/* 1414 */         gameId = OID.fromLong(rs.getLong(1));
/* 1415 */         l.add(gameId);
/* 1416 */         if (Log.loggingDebug) {
/* 1417 */           Log.debug(new StringBuilder().append("getgameid: atavismid ").append(atavismID).append(" maps to gameID=").append(gameId).toString());
/*      */         }
/*      */       }
/* 1420 */       if ((l.isEmpty()) && 
/* 1421 */         (Log.loggingDebug)) {
/* 1422 */         Log.debug(new StringBuilder().append("getgameid: found no mapping gameids for atavismid ").append(atavismID).append(" and worldName ").append(worldName).toString());
/*      */       }
/*      */ 
/* 1425 */       OID gameId = l;
/*      */       return gameId;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1427 */       Log.exception("getGameIDs", e);
/* 1428 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/* 1430 */       if (rs != null) {
/*      */         try {
/* 1432 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/* 1434 */           rs = null;
/*      */         }
/* 1436 */         if (stmt != null) {
/*      */           try {
/* 1438 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/* 1440 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/* 1444 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public int getAccountCount(String worldName)
/*      */   {
/* 1450 */     Statement stmt = null;
/* 1451 */     ResultSet rs = null;
/* 1452 */     int count = -1;
/*      */     try {
/* 1454 */       this.dbLock.lock();
/* 1455 */       stmt = this.conn.createStatement();
/* 1456 */       String query = new StringBuilder().append("SELECT COUNT(*) FROM player_character WHERE world_name = '").append(worldName).append("'").toString();
/*      */ 
/* 1458 */       rs = stmt.executeQuery(query);
/* 1459 */       if (rs.next()) {
/* 1460 */         count = rs.getInt(1);
/*      */       }
/* 1462 */       int i = count;
/*      */       return i;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1464 */       Log.exception("getAccountCount", e);
/* 1465 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/* 1467 */       if (rs != null) {
/*      */         try {
/* 1469 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/* 1471 */           rs = null;
/*      */         }
/* 1473 */         if (stmt != null) {
/*      */           try {
/* 1475 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/* 1477 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/* 1481 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public String getUserName(OID uid)
/*      */   {
/* 1493 */     Statement stmt = null;
/* 1494 */     ResultSet rs = null;
/*      */     try {
/* 1496 */       this.dbLock.lock();
/* 1497 */       stmt = this.conn.createStatement();
/* 1498 */       String query = new StringBuilder().append("SELECT username FROM account WHERE account_id = ").append(uid.toLong()).toString();
/* 1499 */       rs = stmt.executeQuery(query);
/*      */ 
/* 1502 */       if (!rs.next()) {
/* 1503 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/* 1505 */       name = rs.getString(1);
/* 1506 */       if (Log.loggingDebug)
/* 1507 */         Log.debug(new StringBuilder().append("uid:").append(uid).append("=").append(name).toString());
/* 1508 */       sqlEx = name;
/*      */       return sqlEx;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1510 */       Log.warn(new StringBuilder().append("Database.getUserName: unable to get username, this is ok if you are not on production server: ").append(e).toString());
/* 1511 */       String name = null;
/*      */       return name;
/*      */     }
/*      */     finally
/*      */     {
/* 1513 */       if (rs != null) {
/*      */         try {
/* 1515 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/* 1517 */           rs = null;
/*      */         }
/* 1519 */         if (stmt != null) {
/*      */           try {
/* 1521 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/* 1523 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/* 1527 */       this.dbLock.unlock(); } throw localObject2;
/*      */   }
/*      */ 
/*      */   public OID getLocation(OID oid, Namespace ns, Point location)
/*      */   {
/* 1540 */     Statement stmt = null;
/* 1541 */     ResultSet rs = null;
/* 1542 */     int nsInt = ns.getNumber();
/* 1543 */     long oidLong = oid.toLong();
/*      */     try {
/* 1545 */       this.dbLock.lock();
/*      */ 
/* 1547 */       stmt = this.conn.createStatement();
/* 1548 */       rs = stmt.executeQuery(new StringBuilder().append("SELECT locX,locY,locZ,instance FROM objstore WHERE obj_id=").append(oidLong).append(" AND namespace_int=").append(nsInt).toString());
/*      */ 
/* 1554 */       if (!rs.next()) {
/* 1555 */         localOID = null;
/*      */         return localOID;
/*      */       }
/* 1558 */       location.setX(rs.getInt(1));
/* 1559 */       location.setY(rs.getInt(2));
/* 1560 */       location.setZ(rs.getInt(3));
/*      */ 
/* 1562 */       OID localOID = OID.fromLong(rs.getLong(4));
/*      */       return localOID;
/*      */     }
/*      */     catch (SQLException ex)
/*      */     {
/* 1565 */       Log.exception("Database.getLocation()", ex);
/* 1566 */       sqlEx = null;
/*      */       return sqlEx;
/*      */     }
/*      */     finally
/*      */     {
/* 1569 */       if (rs != null) {
/*      */         try {
/* 1571 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/* 1573 */           rs = null;
/*      */         }
/* 1575 */         if (stmt != null) {
/*      */           try {
/* 1577 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/* 1579 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/* 1583 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public OidChunk getOidChunk(int chunkSize)
/*      */   {
/* 1595 */     Statement stmt = null;
/*      */     try {
/* 1597 */       this.dbLock.lock();
/* 1598 */       this.conn.setAutoCommit(false);
/* 1599 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/* 1601 */       ResultSet rs = stmt.executeQuery("SELECT free_oid FROM oid_manager WHERE token = 1");
/*      */ 
/* 1603 */       if (!rs.next()) {
/* 1604 */         throw new AORuntimeException("Database.getOidChunk: no free chunks");
/*      */       }
/* 1606 */       long freeOid = rs.getLong("free_oid");
/* 1607 */       stmt.close();
/*      */ 
/* 1612 */       stmt = this.conn.createStatement();
/* 1613 */       String update = new StringBuilder().append("UPDATE oid_manager SET free_oid = ").append(freeOid + chunkSize).toString();
/*      */ 
/* 1615 */       stmt.executeUpdate(update);
/* 1616 */       this.conn.commit();
/*      */ 
/* 1618 */       OidChunk localOidChunk = new OidChunk(freeOid, freeOid + chunkSize - 1L);
/*      */       return localOidChunk;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1620 */       throw new AORuntimeException("Database.getOidChunk", e);
/*      */     } finally {
/*      */       try {
/* 1623 */         this.conn.setAutoCommit(true);
/*      */       }
/*      */       catch (SQLException sqlEx) {
/*      */       }
/* 1627 */       if (stmt != null) {
/*      */         try {
/* 1629 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1631 */           stmt = null;
/*      */         }
/*      */       }
/* 1634 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean registerStatusReportingPlugin(EnginePlugin plugin, long runId)
/*      */   {
/* 1644 */     Log.debug(new StringBuilder().append("Registering plugin: ").append(plugin.getName()).toString());
/* 1645 */     Statement stmt = null;
/* 1646 */     unregisterStatusReportingPlugin(plugin);
/*      */     try {
/* 1648 */       this.dbLock.lock();
/* 1649 */       stmt = this.conn.createStatement();
/* 1650 */       String update = new StringBuilder().append("INSERT INTO plugin_status (world_name, agent_name, plugin_name, plugin_type, host_name, pid, run_id, percent_cpu_load, last_update_time, next_update_time, status, info) VALUES ('").append(Engine.getWorldName()).append("', ").append("'").append(Engine.getAgent().getName()).append("', ").append("'").append(plugin.getName()).append("', ").append("'").append(plugin.getPluginType()).append("', ").append("'").append(Engine.getEngineHostName()).append("', ").append("0, ").append(runId).append(", ").append("'").append(plugin.getPercentCPULoad()).append("', ").append(System.currentTimeMillis()).append(", ").append("0, ").append("'").append(StringEscaper.escapeString(plugin.getPluginStatus())).append("', ").append("'").append(StringEscaper.escapeString(plugin.getPluginInfo())).append("' ").append(")").toString();
/*      */ 
/* 1666 */       rows = stmt.executeUpdate(update);
/* 1667 */       int i = rows >= 1 ? 1 : 0;
/*      */       return i;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1669 */       Log.exception("Database.registerStatusReportingPlugin", e);
/* 1670 */       int rows = 0;
/*      */       return rows;
/*      */     }
/*      */     finally
/*      */     {
/* 1672 */       if (stmt != null) {
/*      */         try {
/* 1674 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1676 */           stmt = null;
/*      */         }
/*      */       }
/* 1679 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean unregisterStatusReportingPlugin(EnginePlugin plugin)
/*      */   {
/* 1687 */     Statement stmt = null;
/*      */     try {
/* 1689 */       this.dbLock.lock();
/* 1690 */       stmt = this.conn.createStatement();
/* 1691 */       String update = new StringBuilder().append("DELETE FROM plugin_status WHERE world_name='").append(Engine.getWorldName()).append("' AND ").append("plugin_name='").append(plugin.getName()).append("'").toString();
/*      */ 
/* 1694 */       rows = stmt.executeUpdate(update);
/* 1695 */       int i = rows >= 1 ? 1 : 0;
/*      */       return i;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1697 */       Log.exception("Database.unregisterStatusReportingPlugin", e);
/* 1698 */       int rows = 0;
/*      */       return rows;
/*      */     }
/*      */     finally
/*      */     {
/* 1700 */       if (stmt != null) {
/*      */         try {
/* 1702 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1704 */           stmt = null;
/*      */         }
/*      */       }
/* 1707 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean updatePluginStatus(EnginePlugin plugin, long nextUpdateTime)
/*      */   {
/* 1715 */     Statement stmt = null;
/*      */     try {
/* 1717 */       this.dbLock.lock();
/* 1718 */       stmt = this.conn.createStatement();
/* 1719 */       long now = System.currentTimeMillis();
/* 1720 */       String update = new StringBuilder().append("UPDATE plugin_status SET last_update_time=").append(now).append(", ").append("next_update_time=").append(nextUpdateTime).append(", ").append("status='").append(StringEscaper.escapeString(plugin.getPluginStatus())).append("', ").append("percent_cpu_load='").append(plugin.getPercentCPULoad()).append("' ").append("WHERE world_name='").append(Engine.getWorldName()).append("' AND ").append("plugin_name='").append(plugin.getName()).append("'").toString();
/*      */ 
/* 1727 */       int rows = stmt.executeUpdate(update);
/* 1728 */       int j = rows >= 1 ? 1 : 0;
/*      */       return j;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1730 */       Log.exception("updatePluginStatus", e);
/* 1731 */       int i = 0;
/*      */       return i;
/*      */     }
/*      */     finally
/*      */     {
/* 1733 */       if (stmt != null) {
/*      */         try {
/* 1735 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1737 */           stmt = null;
/*      */         }
/*      */       }
/* 1740 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public List<PluginStatus> getPluginStatus(String pluginType)
/*      */   {
/* 1751 */     Statement stmt = null;
/* 1752 */     List statusList = new LinkedList();
/*      */     try {
/* 1754 */       this.dbLock.lock();
/* 1755 */       this.conn.setAutoCommit(false);
/* 1756 */       stmt = this.conn.createStatement(1004, 1007);
/*      */ 
/* 1758 */       String select = new StringBuilder().append("SELECT * FROM plugin_status WHERE world_name='").append(Engine.getWorldName()).append("'").toString();
/*      */ 
/* 1760 */       if (pluginType != null)
/* 1761 */         select = new StringBuilder().append(select).append(" AND plugin_type='").append(pluginType).append("'").toString();
/* 1762 */       rs = stmt.executeQuery(select);
/* 1763 */       while (rs.next()) {
/* 1764 */         status = new PluginStatus();
/* 1765 */         statusList.add(status);
/* 1766 */         status.world_name = rs.getString("world_name");
/* 1767 */         status.agent_name = rs.getString("agent_name");
/* 1768 */         status.plugin_name = rs.getString("plugin_name");
/* 1769 */         status.plugin_type = rs.getString("plugin_type");
/* 1770 */         status.host_name = rs.getString("host_name");
/* 1771 */         status.pid = rs.getInt("pid");
/* 1772 */         status.run_id = rs.getLong("run_id");
/* 1773 */         status.percent_cpu_load = rs.getInt("percent_cpu_load");
/* 1774 */         status.last_update_time = rs.getLong("last_update_time");
/* 1775 */         status.next_update_time = rs.getLong("next_update_time");
/*      */ 
/* 1778 */         status.status = rs.getString("status");
/* 1779 */         status.info = rs.getString("info");
/*      */       }
/* 1781 */       PluginStatus status = statusList;
/*      */       return status;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1783 */       Log.exception("Database.getPluginStatus", e);
/* 1784 */       ResultSet rs = statusList;
/*      */       return rs;
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1787 */         this.conn.setAutoCommit(true);
/*      */       }
/*      */       catch (SQLException sqlEx) {
/*      */       }
/* 1791 */       if (stmt != null) {
/*      */         try {
/* 1793 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1795 */           stmt = null;
/*      */         }
/*      */       }
/* 1798 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void ping()
/*      */   {
/* 1872 */     Log.debug("Database: ping");
/* 1873 */     Statement stmt = null;
/* 1874 */     this.dbLock.lock();
/*      */     try {
/* 1876 */       String sql = "SELECT 1 from player_character";
/* 1877 */       stmt = this.conn.createStatement();
/* 1878 */       stmt.executeQuery(sql);
/*      */     } catch (Exception sqlEx) {
/* 1880 */       reconnect();
/*      */     } finally {
/* 1882 */       if (stmt != null) {
/*      */         try {
/* 1884 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1886 */           stmt = null;
/*      */         }
/*      */       }
/* 1889 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   void reconnect()
/*      */   {
/* 1899 */     Log.error(new StringBuilder().append("Database reconnect: url=").append(Engine.getDBUrl()).toString());
/*      */ 
/* 1901 */     int failCount = 0;
/* 1902 */     this.dbLock.lock();
/*      */     try {
/* 1906 */       this.conn = DriverManager.getConnection(Engine.getDBUrl(), Engine.getDBUser(), Engine.getDBPassword());
/*      */ 
/* 1908 */       Log.info(new StringBuilder().append("Database: reconnected to ").append(Engine.getDBUrl()).toString());
/*      */       return; } catch (Exception e) {
/*      */       while (true) try {
/* 1912 */           if (failCount == 0)
/* 1913 */             Log.exception("Database reconnect failed, retrying", e);
/* 1914 */           else if (failCount % 300 == 299)
/* 1915 */             Log.error(new StringBuilder().append("Database reconnect failed, retrying: ").append(e).toString());
/* 1916 */           failCount++;
/* 1917 */           Thread.sleep(1000L);
/*      */         }
/*      */         catch (InterruptedException ie)
/*      */         {
/*      */         } 
/*      */     }
/*      */     finally
/*      */     {
/* 1924 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */   public static class OidChunk {
/*      */     public long begin;
/*      */     public long end;
/*      */ 
/*      */     public OidChunk(long begin, long end) {
/* 1933 */       this.begin = begin;
/* 1934 */       this.end = end;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class StringEscaper
/*      */   {
/* 1804 */     private static Map<Character, Character> toStringSequences = null;
/* 1805 */     private static Map<Character, Character> fromStringSequences = null;
/*      */ 
/* 1864 */     private static StringEscaper instance = null;
/*      */ 
/*      */     private StringEscaper()
/*      */     {
/* 1808 */       toStringSequences = new HashMap();
/* 1809 */       fromStringSequences = new HashMap();
/* 1810 */       add('\000', '0');
/* 1811 */       add('\'', '\'');
/* 1812 */       add('"', '"');
/* 1813 */       add('\b', 'b');
/* 1814 */       add('\r', 'r');
/* 1815 */       add('\n', 'n');
/* 1816 */       add('\t', 't');
/* 1817 */       add('\032', 'Z');
/* 1818 */       add('\\', '\\');
/* 1819 */       add('%', '%');
/*      */     }
/*      */ 
/*      */     private void add(char from, char to) {
/* 1823 */       toStringSequences.put(Character.valueOf(from), Character.valueOf(to));
/* 1824 */       fromStringSequences.put(Character.valueOf(to), Character.valueOf(from));
/*      */     }
/*      */ 
/*      */     public static String escapeString(String input) {
/* 1828 */       if (instance == null)
/* 1829 */         instance = new StringEscaper();
/* 1830 */       int length = input == null ? 0 : input.length();
/* 1831 */       StringBuilder sb = new StringBuilder(length + 10);
/* 1832 */       for (int i = 0; i < length; i++) {
/* 1833 */         char ch = input.charAt(i);
/* 1834 */         Character replacement = (Character)toStringSequences.get(Character.valueOf(ch));
/* 1835 */         if (replacement != null) {
/* 1836 */           sb.append('\\');
/* 1837 */           sb.append(replacement);
/*      */         }
/*      */         else {
/* 1840 */           sb.append(ch);
/*      */         }
/*      */       }
/* 1842 */       return sb.toString();
/*      */     }
/*      */ 
/*      */     public static String unescapeString(String input) {
/* 1846 */       if (instance == null)
/* 1847 */         instance = new StringEscaper();
/* 1848 */       StringBuilder sb = new StringBuilder(input.length() + 10);
/* 1849 */       int i = 0;
/* 1850 */       while (i < input.length()) {
/* 1851 */         char ch = input.charAt(i);
/* 1852 */         if (ch == '\\') {
/* 1853 */           i++;
/* 1854 */           ch = input.charAt(i);
/* 1855 */           char replacement = ((Character)fromStringSequences.get(Character.valueOf(ch))).charValue();
/* 1856 */           sb.append(replacement);
/*      */         }
/*      */         else {
/* 1859 */           sb.append(ch);
/*      */         }
/*      */       }
/* 1861 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XMLExceptionListener
/*      */     implements ExceptionListener
/*      */   {
/*      */     public void exceptionThrown(Exception e)
/*      */     {
/*  542 */       Log.exception("Database.loadEntity", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   class KeepAlive
/*      */     implements Runnable
/*      */   {
/*      */     KeepAlive()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */       {
/*      */         try
/*      */         {
/*   95 */           Thread.sleep(60000L);
/*      */         } catch (InterruptedException e) {
/*   97 */           Log.exception("Database.KeepAlive: interrupted", e);
/*      */         }
/*      */         try {
/*  100 */           if (Database.this.conn != null)
/*  101 */             Database.this.ping();
/*      */         }
/*      */         catch (AORuntimeException e) {
/*  104 */           Log.exception("Database.KeepAlive: ping caught exception", e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Database
 * JD-Core Version:    0.6.0
 */