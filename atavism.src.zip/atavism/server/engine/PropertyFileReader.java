/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.util.Log;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class PropertyFileReader
/*    */ {
/* 65 */   public static String propFile = null;
/* 66 */   public static boolean usePropFile = false;
/*    */ 
/*    */   public PropertyFileReader()
/*    */   {
/*    */     try
/*    */     {
/* 19 */       if (propFile == null)
/* 20 */         propFile = System.getProperty("atavism.propertyfile");
/* 21 */       if (propFile == null) {
/* 22 */         Log.debug("No property file specified.  Will use command-line properties.");
/* 23 */         usePropFile = false;
/*    */       } else {
/* 25 */         File f = new File(propFile);
/* 26 */         if (f.exists())
/*    */         {
/* 29 */           usePropFile = true;
/*    */         } else {
/* 31 */           if (Log.loggingDebug)
/* 32 */             Log.debug("Specified property file " + propFile + " does not exist! Defaulting to command-line properties.");
/* 33 */           usePropFile = false;
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 37 */       Log.exception("PropertyFileReader caught exception finding Properties file", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Properties readPropFile()
/*    */   {
/* 45 */     File f = new File(propFile);
/* 46 */     Properties properties = new Properties(System.getProperties());
/*    */ 
/* 50 */     if (f.exists()) {
/*    */       try {
/* 52 */         properties.load(new FileInputStream(propFile));
/*    */       }
/*    */       catch (IOException e) {
/* 55 */         Log.exception("PropertyFileReader.readPropFile caught exception finding Properties file", e);
/*    */       }
/*    */     }
/*    */     else {
/* 59 */       Log.error("Properties file " + propFile + " does not exist.");
/*    */     }
/*    */ 
/* 62 */     return properties;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.PropertyFileReader
 * JD-Core Version:    0.6.0
 */