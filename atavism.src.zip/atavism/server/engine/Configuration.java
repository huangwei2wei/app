/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ public class Configuration
/*     */ {
/* 160 */   static final String[] typeName = { "none", "Element", "Attr", "Text", "CDATA", "EntityRef", "Entity", "ProcInstr", "Comment", "Document", "DocType", "DocFragment", "Notation" };
/*     */   private Document document;
/*     */ 
/*     */   public Configuration(String fileName)
/*     */   {
/*  19 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */     try {
/*  21 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*  22 */       builder.setErrorHandler(new ErrorHandler()
/*     */       {
/*     */         public void fatalError(SAXParseException exception)
/*     */           throws SAXException
/*     */         {
/*     */         }
/*     */ 
/*     */         public void error(SAXParseException e)
/*     */           throws SAXParseException
/*     */         {
/*  32 */           throw e;
/*     */         }
/*     */ 
/*     */         public void warning(SAXParseException err)
/*     */           throws SAXParseException
/*     */         {
/*  38 */           System.out.println("** Warning, line " + err.getLineNumber() + ", uri " + err.getSystemId());
/*     */ 
/*  41 */           System.out.println("   " + err.getMessage());
/*     */         }
/*     */       });
/*  45 */       this.document = builder.parse(new File(fileName));
/*     */     }
/*     */     catch (SAXException sxe)
/*     */     {
/*  49 */       Exception x = sxe;
/*  50 */       if (sxe.getException() != null) {
/*  51 */         x = sxe.getException();
/*     */       }
/*  53 */       x.printStackTrace();
/*     */     }
/*     */     catch (ParserConfigurationException pce) {
/*  56 */       pce.printStackTrace();
/*     */     }
/*     */     catch (IOException ioe) {
/*  59 */       ioe.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Node getRoot() {
/*  64 */     return this.document;
/*     */   }
/*     */ 
/*     */   public static String getValueFromChild(String childName, Node node) {
/*  68 */     if (node == null) {
/*  69 */       throw new AORuntimeException("node is null");
/*     */     }
/*  71 */     Node childNode = findChild(node, childName);
/*     */ 
/*  73 */     if (childNode == null) {
/*  74 */       throw new AORuntimeException("could not find child node with name: " + childName);
/*     */     }
/*  76 */     return getNodeValue(childNode);
/*     */   }
/*     */ 
/*     */   public static String getNodeValue(Node node)
/*     */   {
/*  81 */     return node.getFirstChild().getNodeValue();
/*     */   }
/*     */ 
/*     */   public static List getMatchingChildren(Node node, String name)
/*     */   {
/*  87 */     if (node == null) {
/*  88 */       return null;
/*     */     }
/*     */ 
/*  91 */     LinkedList returnList = new LinkedList();
/*  92 */     NodeList childList = node.getChildNodes();
/*  93 */     int len = childList.getLength();
/*  94 */     for (int i = 0; i < len; i++) {
/*  95 */       Node curNode = childList.item(i);
/*  96 */       if (name.equals(curNode.getNodeName())) {
/*  97 */         returnList.add(curNode);
/*     */       }
/*     */     }
/* 100 */     return returnList;
/*     */   }
/*     */ 
/*     */   public static Node findChild(Node node, String name)
/*     */   {
/* 106 */     if (node == null) {
/* 107 */       return null;
/*     */     }
/*     */ 
/* 110 */     NodeList childList = node.getChildNodes();
/* 111 */     int len = childList.getLength();
/* 112 */     for (int i = 0; i < len; i++) {
/* 113 */       Node curNode = childList.item(i);
/* 114 */       if (name.equals(curNode.getNodeName())) {
/* 115 */         return curNode;
/*     */       }
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */   public static void printAllChildren(Node node) {
/* 122 */     if (node == null) {
/* 123 */       return;
/*     */     }
/*     */ 
/* 126 */     NodeList childList = node.getChildNodes();
/* 127 */     int len = childList.getLength();
/* 128 */     for (int i = 0; i < len; i++) {
/* 129 */       Node curNode = childList.item(i);
/* 130 */       System.out.println("node: " + toStringNode(curNode));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String toStringNode(Node domNode) {
/* 135 */     if (domNode == null) {
/* 136 */       return "";
/*     */     }
/* 138 */     String s = typeName[domNode.getNodeType()];
/* 139 */     String nodeName = domNode.getNodeName();
/* 140 */     if (!nodeName.startsWith("#")) {
/* 141 */       s = s + ": " + nodeName;
/*     */     }
/* 143 */     if (domNode.getNodeValue() != null) {
/* 144 */       if (s.startsWith("ProcInstr"))
/* 145 */         s = s + ", ";
/*     */       else {
/* 147 */         s = s + ": ";
/*     */       }
/* 149 */       String t = domNode.getNodeValue().trim();
/* 150 */       int x = t.indexOf("\n");
/* 151 */       if (x >= 0) t = t.substring(0, x);
/* 152 */       s = s + t;
/*     */     }
/* 154 */     return s;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 180 */     if (args.length != 1) {
/* 181 */       System.err.println("specify config file");
/* 182 */       System.exit(1);
/*     */     }
/* 184 */     Configuration config = new Configuration(args[0]);
/* 185 */     Node portNode = findChild(config.getRoot().getFirstChild(), "port");
/*     */ 
/* 187 */     if (portNode == null) {
/* 188 */       System.out.println("could not find port node");
/* 189 */       System.exit(1);
/*     */     }
/* 191 */     System.out.println("found port node");
/*     */ 
/* 193 */     System.out.println("printing all port node children");
/* 194 */     printAllChildren(portNode);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Configuration
 * JD-Core Version:    0.6.0
 */