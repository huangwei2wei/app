/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.objects.AOObject;
/*    */ import java.rmi.RemoteException;
/*    */ import java.rmi.server.UnicastRemoteObject;
/*    */ 
/*    */ public abstract class AbstractEventListener extends UnicastRemoteObject
/*    */   implements AOEventListener
/*    */ {
/* 19 */   protected String name = "";
/*    */ 
/*    */   public AbstractEventListener()
/*    */     throws RemoteException
/*    */   {
/*    */   }
/*    */ 
/*    */   public AbstractEventListener(String name)
/*    */     throws RemoteException
/*    */   {
/* 16 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */     throws RemoteException
/*    */   {
/* 22 */     return this.name;
/*    */   }
/*    */ 
/*    */   public abstract void handleEvent(Event paramEvent, AOObject paramAOObject)
/*    */     throws RemoteException;
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.AbstractEventListener
 * JD-Core Version:    0.6.0
 */