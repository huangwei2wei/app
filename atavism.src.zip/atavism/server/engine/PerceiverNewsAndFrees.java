/*    */ package atavism.server.engine;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class PerceiverNewsAndFrees<ElementType extends QuadTreeElement<ElementType>>
/*    */ {
/*    */   protected Set<ElementType> newElements;
/*    */   protected Set<ElementType> freedElements;
/*    */ 
/*    */   public PerceiverNewsAndFrees()
/*    */   {
/* 11 */     this.newElements = new HashSet();
/* 12 */     this.freedElements = new HashSet();
/*    */   }
/*    */ 
/*    */   public void addNewElement(ElementType element)
/*    */   {
/* 18 */     this.newElements.add(element);
/*    */   }
/*    */ 
/*    */   public void addFreedElement(ElementType element) {
/* 22 */     this.freedElements.add(element);
/*    */   }
/*    */ 
/*    */   public Set<ElementType> getFreedElements() {
/* 26 */     return this.freedElements;
/*    */   }
/*    */ 
/*    */   public Set<ElementType> getNewElements() {
/* 30 */     return this.newElements;
/*    */   }
/*    */ 
/*    */   public int newCount() {
/* 34 */     return this.newElements.size();
/*    */   }
/*    */ 
/*    */   public int freedCount() {
/* 38 */     return this.freedElements.size();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.PerceiverNewsAndFrees
 * JD-Core Version:    0.6.0
 */