/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.math.Geometry;
/*    */ 
/*    */ public class FixedPerceiver<ElementType extends QuadTreeElement<ElementType>> extends Perceiver<ElementType>
/*    */ {
/* 33 */   Geometry geometry = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public FixedPerceiver()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FixedPerceiver(Geometry g)
/*    */   {
/* 13 */     setGeometry(g);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 17 */     return "[FixedPerceiver:" + hashCode() + " " + this.geometry + "]";
/*    */   }
/*    */ 
/*    */   public boolean overlaps(Geometry g) {
/* 21 */     return this.geometry.overlaps(g);
/*    */   }
/*    */   public boolean contains(Geometry g) {
/* 24 */     return this.geometry.contains(g);
/*    */   }
/*    */ 
/*    */   public Geometry getGeometry() {
/* 28 */     return this.geometry;
/*    */   }
/*    */   public void setGeometry(Geometry g) {
/* 31 */     this.geometry = g;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.FixedPerceiver
 * JD-Core Version:    0.6.0
 */