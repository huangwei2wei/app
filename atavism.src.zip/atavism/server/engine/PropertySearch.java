/*    */ package atavism.server.engine;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PropertySearch
/*    */   implements SearchClause
/*    */ {
/*    */   private Map queryProps;
/*    */ 
/*    */   public PropertySearch()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PropertySearch(Map queryProps)
/*    */   {
/* 17 */     setProperties(queryProps);
/*    */   }
/*    */ 
/*    */   public Map getProperties()
/*    */   {
/* 24 */     return this.queryProps;
/*    */   }
/*    */ 
/*    */   public void setProperties(Map queryProps)
/*    */   {
/* 31 */     this.queryProps = queryProps;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.PropertySearch
 * JD-Core Version:    0.6.0
 */