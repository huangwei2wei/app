package atavism.server.engine;

import atavism.server.math.AOVector;
import atavism.server.math.Point;
import atavism.server.math.Quaternion;

public abstract interface IBasicWorldNode
{
  public abstract OID getInstanceOid();

  public abstract void setInstanceOid(OID paramOID);

  public abstract Point getLoc();

  public abstract void setLoc(Point paramPoint);

  public abstract Quaternion getOrientation();

  public abstract void setOrientation(Quaternion paramQuaternion);

  public abstract AOVector getDir();

  public abstract void setDir(AOVector paramAOVector);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.IBasicWorldNode
 * JD-Core Version:    0.6.0
 */