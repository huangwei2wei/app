package atavism.server.engine;

public abstract interface Interpolatable
{
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Interpolatable
 * JD-Core Version:    0.6.0
 */