/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.objects.AOObject;
/*     */ import atavism.server.objects.EntityHandle;
/*     */ import atavism.server.pathing.PathInterpolator;
/*     */ import atavism.server.pathing.PathLocAndDir;
/*     */ import atavism.server.plugins.WorldManagerClient.ObjectInfo;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class InterpolatedWorldNode
/*     */   implements WorldNode, BasicInterpolatable
/*     */ {
/* 466 */   protected EntityHandle objHandle = null;
/*     */ 
/* 468 */   protected Boolean followsTerrain = Boolean.valueOf(true);
/*     */ 
/* 470 */   protected boolean spawned = false;
/*     */   protected OID instanceOid;
/* 474 */   protected Point rawLoc = null;
/*     */ 
/* 476 */   protected Point interpLoc = null;
/*     */ 
/* 478 */   protected AOVector dir = new AOVector(0.0F, 0.0F, 0.0F);
/*     */ 
/* 480 */   protected Quaternion orient = null;
/*     */ 
/* 482 */   protected transient PathInterpolator pathInterpolator = null;
/*     */ 
/* 484 */   protected long lastUpdate = -1L;
/*     */ 
/* 486 */   protected long lastInterp = -1L;
/*     */ 
/* 488 */   protected WorldNode parent = null;
/*     */ 
/* 490 */   protected Set<WorldNode> children = null;
/*     */ 
/* 492 */   public transient Lock lock = null;
/*     */ 
/* 494 */   public transient Lock treeLock = null;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public InterpolatedWorldNode()
/*     */   {
/*  14 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public InterpolatedWorldNode(BasicWorldNode bnode) {
/*  18 */     setupTransient();
/*  19 */     this.instanceOid = bnode.getInstanceOid();
/*  20 */     this.rawLoc = bnode.getLoc();
/*  21 */     this.interpLoc = this.rawLoc;
/*  22 */     this.dir = bnode.getDir();
/*  23 */     this.orient = bnode.getOrientation();
/*  24 */     this.lastInterp = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public InterpolatedWorldNode(WorldManagerClient.ObjectInfo info) {
/*  28 */     setupTransient();
/*  29 */     this.rawLoc = info.loc;
/*  30 */     this.interpLoc = this.rawLoc;
/*  31 */     this.dir = info.dir;
/*  32 */     this.orient = info.orient;
/*  33 */     this.lastInterp = System.currentTimeMillis();
/*  34 */     this.instanceOid = info.instanceOid;
/*     */   }
/*     */ 
/*     */   void setupTransient() {
/*  38 */     this.lock = LockFactory.makeLock("InterpolatedWorldNodeLock");
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  42 */     return "[InterpolatedWorldNode: objHandle=" + this.objHandle + ", instanceOid=" + getInstanceOid() + ", rawLoc=" + getRawLoc() + ", interpLoc=" + getInterpLoc() + ", dir=" + getDir() + ", orient=" + getOrientation() + "]";
/*     */   }
/*     */ 
/*     */   public OID getInstanceOid()
/*     */   {
/*  52 */     return this.instanceOid;
/*     */   }
/*     */ 
/*     */   public void setInstanceOid(OID oid) {
/*  56 */     this.instanceOid = oid;
/*     */   }
/*     */ 
/*     */   public Point getLoc() {
/*  60 */     Lock myTreeLock = this.treeLock;
/*  61 */     if (myTreeLock != null) {
/*  62 */       myTreeLock.lock();
/*     */     }
/*  64 */     this.lock.lock();
/*     */     try {
/*  66 */       BasicInterpolator interp = (BasicInterpolator)Engine.getInterpolator();
/*     */ 
/*  68 */       if (interp != null) {
/*  69 */         interp.interpolate(this);
/*     */       }
/*  71 */       Point localPoint = this.interpLoc == null ? null : (Point)this.interpLoc.clone();
/*     */       return localPoint;
/*     */     }
/*     */     finally
/*     */     {
/*  73 */       this.lock.unlock();
/*  74 */       if (myTreeLock != null)
/*  75 */         myTreeLock.unlock(); 
/*  75 */     }throw localObject;
/*     */   }
/*     */ 
/*     */   public void setLoc(Point p)
/*     */   {
/*  81 */     Lock myTreeLock = this.treeLock;
/*  82 */     if (myTreeLock != null) {
/*  83 */       myTreeLock.lock();
/*     */     }
/*  85 */     this.lock.lock();
/*     */     try {
/*  87 */       long time = System.currentTimeMillis();
/*  88 */       setRawLoc(p);
/*  89 */       setLastUpdate(time);
/*  90 */       setInterpLoc(p);
/*  91 */       setLastInterp(time);
/*     */     } finally {
/*  93 */       this.lock.unlock();
/*  94 */       if (myTreeLock != null)
/*  95 */         myTreeLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getLastUpdate()
/*     */   {
/* 101 */     this.lock.lock();
/*     */     try {
/* 103 */       long l = this.lastUpdate;
/*     */       return l; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setLastUpdate(long time)
/*     */   {
/* 110 */     this.lock.lock();
/*     */     try {
/* 112 */       this.lastUpdate = time;
/*     */     } finally {
/* 114 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public AOObject getObject()
/*     */   {
/* 120 */     this.lock.lock();
/*     */     try {
/* 122 */       AOObject localAOObject = this.objHandle == null ? null : (AOObject)this.objHandle.getEntity(Namespace.WORLD_MANAGER);
/*     */       return localAOObject; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setObject(AOObject obj)
/*     */   {
/* 129 */     this.lock.lock();
/*     */     try {
/* 131 */       this.objHandle = (obj == null ? null : new EntityHandle(obj));
/*     */     } finally {
/* 133 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setObjectOID(OID oid) {
/* 138 */     this.objHandle = new EntityHandle(oid);
/*     */   }
/*     */   public OID getObjectOID() {
/* 141 */     if (this.objHandle == null) {
/* 142 */       return null;
/*     */     }
/* 144 */     return this.objHandle.getOid();
/*     */   }
/*     */ 
/*     */   public WorldNode getParent() {
/* 148 */     this.lock.lock();
/*     */     try {
/* 150 */       WorldNode localWorldNode = this.parent;
/*     */       return localWorldNode; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setParent(WorldNode node)
/*     */   {
/* 157 */     this.lock.lock();
/*     */     try {
/* 159 */       this.parent = node;
/*     */     } finally {
/* 161 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Quaternion getOrientation() {
/* 166 */     this.lock.lock();
/*     */     try {
/* 168 */       Quaternion localQuaternion = this.orient == null ? null : (Quaternion)this.orient.clone();
/*     */       return localQuaternion; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setOrientation(Quaternion orient)
/*     */   {
/* 175 */     this.lock.lock();
/*     */     try {
/* 177 */       this.orient = (orient == null ? null : (Quaternion)orient.clone());
/*     */     } finally {
/* 179 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDirLocOrient(BasicWorldNode bnode) {
/* 184 */     Lock myTreeLock = this.treeLock;
/* 185 */     if (myTreeLock != null) {
/* 186 */       myTreeLock.lock();
/*     */     }
/* 188 */     this.lock.lock();
/*     */     try
/*     */     {
/* 195 */       setLastInterp(System.currentTimeMillis());
/* 196 */       setRawLoc(bnode.getLoc());
/* 197 */       setDir(bnode.getDir());
/* 198 */       setInterpLoc(bnode.getLoc());
/* 199 */       setOrientation(bnode.getOrientation());
/*     */     }
/*     */     finally {
/* 202 */       this.lock.unlock();
/* 203 */       if (myTreeLock != null)
/* 204 */         myTreeLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public InterpolatedDirLocOrientTime getDirLocOrientTime()
/*     */   {
/* 222 */     InterpolatedDirLocOrientTime val = new InterpolatedDirLocOrientTime();
/* 223 */     this.lock.lock();
/*     */     try {
/* 225 */       val.interpLoc = (this.interpLoc == null ? null : (Point)this.interpLoc.clone());
/* 226 */       val.dir = (this.dir == null ? null : (AOVector)this.dir.clone());
/* 227 */       val.orient = (this.orient == null ? null : (Quaternion)this.orient.clone());
/* 228 */       val.lastInterp = this.lastInterp;
/* 229 */       InterpolatedDirLocOrientTime localInterpolatedDirLocOrientTime1 = val;
/*     */       return localInterpolatedDirLocOrientTime1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Set<WorldNode> getChildren()
/*     */   {
/* 237 */     this.lock.lock();
/*     */     try {
/* 239 */       if (this.children != null) {
/* 240 */         localHashSet = new HashSet(this.children);
/*     */         return localHashSet;
/*     */       }
/* 243 */       HashSet localHashSet = new HashSet();
/*     */       return localHashSet; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setChildren(Set<WorldNode> children)
/*     */   {
/* 251 */     this.lock.lock();
/*     */     try {
/* 253 */       this.children = new HashSet(children);
/*     */     } finally {
/* 255 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addChild(WorldNode child) {
/* 260 */     this.lock.lock();
/*     */     try {
/* 262 */       if (this.children == null) {
/* 263 */         this.children = new HashSet();
/*     */       }
/* 265 */       this.children.add(child);
/*     */     } finally {
/* 267 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeChild(WorldNode child) {
/* 272 */     this.lock.lock();
/*     */     try {
/* 274 */       this.children.remove(child);
/* 275 */       if (this.children.size() == 0)
/* 276 */         this.children = null;
/*     */     }
/*     */     finally {
/* 279 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isSpawned() {
/* 284 */     return this.spawned;
/*     */   }
/*     */ 
/*     */   public void isSpawned(boolean spawned) {
/* 288 */     this.spawned = spawned;
/* 289 */     if (!spawned) {
/* 290 */       BasicInterpolator interp = (BasicInterpolator)Engine.getInterpolator();
/*     */ 
/* 292 */       if (interp != null)
/* 293 */         interp.unregister(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public PathInterpolator getPathInterpolator()
/*     */   {
/* 299 */     return this.pathInterpolator;
/*     */   }
/*     */ 
/*     */   public void setPathInterpolator(PathInterpolator pathInterpolator) {
/* 303 */     this.lock.lock();
/*     */     try {
/* 305 */       this.pathInterpolator = pathInterpolator;
/* 306 */       if (pathInterpolator == null)
/* 307 */         changeDir(new AOVector(0.0F, 0.0F, 0.0F), false);
/*     */     } finally {
/* 309 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public PathLocAndDir interpolate(float t) {
/* 314 */     this.lock.lock();
/*     */     try {
/* 316 */       if (this.pathInterpolator == null) {
/* 317 */         Object localObject1 = null;
/*     */         return localObject1;
/*     */       }
/* 319 */       PathLocAndDir locAndDir = this.pathInterpolator.interpolate(t);
/* 320 */       if (locAndDir == null)
/* 321 */         this.pathInterpolator = null;
/* 322 */       Object localObject2 = null;
/*     */       return localObject2; } finally { this.lock.unlock(); } throw localObject3;
/*     */   }
/*     */ 
/*     */   public AOVector getDir()
/*     */   {
/* 331 */     this.lock.lock();
/*     */     try {
/* 333 */       AOVector localAOVector = this.dir == null ? null : (AOVector)this.dir.clone();
/*     */       return localAOVector; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setDir(AOVector dir)
/*     */   {
/* 340 */     Lock myTreeLock = this.treeLock;
/* 341 */     if (myTreeLock != null) {
/* 342 */       myTreeLock.lock();
/*     */     }
/* 344 */     this.lock.lock();
/*     */     try {
/* 346 */       changeDir(dir, true);
/*     */     } finally {
/* 348 */       this.lock.unlock();
/* 349 */       if (myTreeLock != null)
/* 350 */         myTreeLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void changeDir(AOVector dir, boolean performDirInterpolation)
/*     */   {
/* 358 */     BasicInterpolator interp = (BasicInterpolator)Engine.getInterpolator();
/*     */ 
/* 360 */     if ((interp != null) && 
/* 361 */       (performDirInterpolation)) {
/* 362 */       interp.interpolate(this);
/* 363 */       if ((!this.dir.isZero()) && (dir.isZero()))
/* 364 */         interp.unregister(this);
/* 365 */       else if ((this.dir.isZero()) && (!dir.isZero())) {
/* 366 */         interp.register(this);
/*     */       }
/*     */     }
/* 369 */     this.dir = (dir == null ? null : (AOVector)dir.clone());
/*     */   }
/*     */ 
/*     */   public Point getRawLoc() {
/* 373 */     this.lock.lock();
/*     */     try {
/* 375 */       Point localPoint = this.rawLoc == null ? null : (Point)this.rawLoc.clone();
/*     */       return localPoint; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setRawLoc(Point p)
/*     */   {
/* 382 */     this.lock.lock();
/*     */     try {
/* 384 */       this.rawLoc = (p == null ? null : (Point)p.clone());
/*     */     } finally {
/* 386 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getLastInterp() {
/* 391 */     this.lock.lock();
/*     */     try {
/* 393 */       long l = this.lastInterp;
/*     */       return l; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setLastInterp(long time)
/*     */   {
/* 400 */     this.lock.lock();
/*     */     try {
/* 402 */       this.lastInterp = time;
/*     */     } finally {
/* 404 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Point getInterpLoc() {
/* 409 */     this.lock.lock();
/*     */     try {
/* 411 */       Point localPoint = this.interpLoc == null ? null : (Point)this.interpLoc.clone();
/*     */       return localPoint; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Point getCurrentLoc()
/*     */   {
/* 418 */     return getInterpLoc();
/*     */   }
/*     */ 
/*     */   public void setInterpLoc(Point p) {
/* 422 */     this.lock.lock();
/*     */     try {
/* 424 */       this.interpLoc = (p == null ? null : (Point)p.clone());
/*     */     } finally {
/* 426 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setPathInterpolatorValues(long time, AOVector newDir, Point newLoc, Quaternion orientation)
/*     */   {
/* 434 */     Lock myTreeLock = this.treeLock;
/* 435 */     if (myTreeLock != null) {
/* 436 */       myTreeLock.lock();
/*     */     }
/* 438 */     this.lock.lock();
/*     */     try {
/* 440 */       this.lastInterp = time;
/* 441 */       this.dir = newDir;
/* 442 */       this.orient = (orientation == null ? null : (Quaternion)orientation.clone());
/* 443 */       setInterpLoc(newLoc);
/*     */     } finally {
/* 445 */       this.lock.unlock();
/* 446 */       if (myTreeLock != null)
/* 447 */         myTreeLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Boolean getFollowsTerrain()
/*     */   {
/* 453 */     return this.followsTerrain;
/*     */   }
/*     */ 
/*     */   public void setFollowsTerrain(Boolean flag) {
/* 457 */     this.followsTerrain = flag;
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 462 */     in.defaultReadObject();
/* 463 */     setupTransient();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 498 */       BeanInfo info = Introspector.getBeanInfo(InterpolatedWorldNode.class);
/* 499 */       PropertyDescriptor[] propertyDescriptors = info.getPropertyDescriptors();
/*     */ 
/* 501 */       for (int i = 0; i < propertyDescriptors.length; i++) {
/* 502 */         PropertyDescriptor pd = propertyDescriptors[i];
/* 503 */         if (pd.getName().equals("children")) {
/* 504 */           pd.setValue("transient", Boolean.TRUE);
/*     */         }
/* 506 */         if (pd.getName().equals("object")) {
/* 507 */           pd.setValue("transient", Boolean.TRUE);
/*     */         }
/* 509 */         if (pd.getName().equals("loc")) {
/* 510 */           pd.setValue("transient", Boolean.TRUE);
/*     */         }
/* 512 */         if (pd.getName().equals("lastUpdate")) {
/* 513 */           pd.setValue("transient", Boolean.TRUE);
/*     */         }
/* 515 */         if (pd.getName().equals("parent")) {
/* 516 */           pd.setValue("transient", Boolean.TRUE);
/*     */         }
/* 518 */         if (pd.getName().equals("dir"))
/* 519 */           pd.setValue("transient", Boolean.TRUE);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 523 */       Log.error("failed beans initalization");
/*     */     }
/*     */   }
/*     */ 
/*     */   public class InterpolatedDirLocOrientTime
/*     */   {
/*     */     public AOVector dir;
/*     */     public Point interpLoc;
/*     */     public Quaternion orient;
/*     */     public long lastInterp;
/*     */ 
/*     */     public InterpolatedDirLocOrientTime()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.InterpolatedWorldNode
 * JD-Core Version:    0.6.0
 */