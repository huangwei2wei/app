/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.network.ClientConnection.AcceptCallback;
/*     */ import atavism.server.network.ClientConnection.MessageCallback;
/*     */ import atavism.server.network.ClientTCPMessageIO;
/*     */ import atavism.server.network.rdp.RDPServer;
/*     */ import atavism.server.network.rdp.RDPServerSocket;
/*     */ import atavism.server.objects.RemoteAccountConnector;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Base64;
/*     */ import atavism.server.util.InitLogAndPid;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.SecureTokenManager;
/*     */ import atavism.server.util.SecureTokenSpec;
/*     */ import atavism.server.util.SecureTokenUtil;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Properties;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ public class MasterServer
/*     */   implements ClientConnection.AcceptCallback, ClientConnection.MessageCallback
/*     */ {
/* 154 */   int tcpPort = -1;
/* 155 */   int rdpPort = -1;
/*     */   SocketPolicyHandler policyHandler;
/* 159 */   MasterDatabase db = null;
/*     */   RemoteAccountConnector remoteConnector;
/* 169 */   private static MasterServer masterServer = null;
/*     */ 
/* 580 */   private static ExecutorService threadPool = Executors.newCachedThreadPool();
/*     */ 
/* 642 */   private static ClientTCPMessageIO clientTCPMessageIO = null;
/*     */ 
/* 644 */   public static long masterTokenValidTime = 120000L;
/*     */   private static final int CHALLENGE_LEN = 20;
/*     */   public static final int AUTH_PROTOCOL_VERSION = 1;
/*     */   public static final int defaultTcpPort = 9005;
/*     */   public static final int defaultRdpPort = 9010;
/* 657 */   public static Properties properties = new Properties();
/*     */ 
/*     */   public MasterServer()
/*     */   {
/*  25 */     String tcpPortStr = properties.getProperty("atavism.master_tcp_port");
/*  26 */     if (tcpPortStr == null) {
/*  27 */       this.tcpPort = 9005;
/*     */     }
/*     */     else {
/*  30 */       this.tcpPort = Integer.parseInt(tcpPortStr.trim());
/*     */     }
/*     */ 
/*  34 */     String rdpPortStr = properties.getProperty("atavism.master_rdp_port");
/*  35 */     if (rdpPortStr == null) {
/*  36 */       this.rdpPort = 9010;
/*     */     }
/*     */     else {
/*  39 */       this.rdpPort = Integer.parseInt(rdpPortStr.trim());
/*     */     }
/*     */ 
/*  43 */     this.policyHandler = new SocketPolicyHandler(properties);
/*     */   }
/*     */ 
/*     */   public void dbConnect() {
/*  47 */     if (this.db == null) {
/*  48 */       this.db = new MasterDatabase();
/*     */     }
/*  50 */     this.db.connect(getDBUrl(), getDBUser(), getDBPassword());
/*     */   }
/*     */ 
/*     */   public void setTCPPort(int port) {
/*  54 */     this.tcpPort = port;
/*     */   }
/*     */ 
/*     */   public int getTCPPort() {
/*  58 */     return this.tcpPort;
/*     */   }
/*     */ 
/*     */   public void setRDPPort(int port) {
/*  62 */     this.rdpPort = port;
/*     */   }
/*     */ 
/*     */   public int getRDPPort() {
/*  66 */     return this.rdpPort;
/*     */   }
/*     */ 
/*     */   public void setRemoteConnector(RemoteAccountConnector connector) {
/*  70 */     this.remoteConnector = connector;
/*     */   }
/*     */ 
/*     */   public void acceptConnection(ClientConnection con)
/*     */   {
/*  75 */     if (Log.loggingDebug)
/*  76 */       Log.debug("masterserver: new incoming connection: " + con);
/*  77 */     con.registerMessageCallback(this);
/*     */   }
/*     */ 
/*     */   public void processPacket(ClientConnection con, AOByteBuffer buf)
/*     */   {
/*     */     try {
/*  83 */       int msgType = buf.getInt();
/*  84 */       if (msgType == 0)
/*     */       {
/*  86 */         Log.debug("masterserver: got name resolution request");
/*  87 */         resolveName(con, buf);
/*  88 */         return;
/*  89 */       }if (msgType == 1)
/*     */       {
/*  91 */         Log.debug("masterserver: got chat request");
/*  92 */         chatMsg(con, buf);
/*     */       } else {
/*  94 */         Log.warn("masterserver.processPacket: ignoring unknown msg type");
/*  95 */         return;
/*     */       }
/*     */     } catch (AORuntimeException e) {
/*  98 */       Log.exception("Masterserver.processPacket got exception", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void connectionReset(ClientConnection con) {
/* 103 */     Log.debug("Masterserver: connection reset");
/*     */   }
/*     */ 
/*     */   public void resolveName(ClientConnection con, AOByteBuffer buf)
/*     */   {
/* 109 */     String worldName = buf.getString();
/* 110 */     if (Log.loggingDebug)
/* 111 */       Log.debug("masterserver.resolvename: looking up worldName " + worldName);
/* 112 */     MasterDatabase.WorldInfo worldInfo = this.db.resolveWorldID(worldName);
/* 113 */     String hostname = null;
/* 114 */     int port = -1;
/* 115 */     String patcherURL = null;
/* 116 */     String mediaURL = null;
/* 117 */     if (worldInfo == null) {
/* 118 */       Log.warn("masterserver.resolvename: failed to resolve worldName " + worldName);
/*     */     }
/*     */     else {
/* 121 */       hostname = worldInfo.svrHostName;
/* 122 */       port = worldInfo.port;
/* 123 */       patcherURL = worldInfo.patcherURL;
/* 124 */       mediaURL = worldInfo.mediaURL;
/*     */ 
/* 126 */       if (Log.loggingDebug) {
/* 127 */         Log.debug("masterverse.resolvename: resolved worldName " + worldName + " to " + hostname + ":" + port);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 132 */     AOByteBuffer returnBuf = new AOByteBuffer(hostname == null ? 200 : hostname.length() + 32);
/*     */ 
/* 134 */     returnBuf.putInt(2);
/* 135 */     returnBuf.putString(worldName);
/* 136 */     returnBuf.putInt(hostname == null ? 0 : 1);
/* 137 */     returnBuf.putString(hostname);
/* 138 */     returnBuf.putInt(port);
/* 139 */     if ((patcherURL != null) && (mediaURL != null)) {
/* 140 */       if (Log.loggingDebug) {
/* 141 */         Log.debug("masterverse.resolvename: patcher for worldName " + worldName + " at " + patcherURL + " with media at: " + mediaURL);
/*     */       }
/* 143 */       returnBuf.putString(patcherURL);
/* 144 */       returnBuf.putString(mediaURL);
/*     */     }
/* 146 */     returnBuf.flip();
/*     */ 
/* 148 */     con.send(returnBuf);
/*     */   }
/*     */ 
/*     */   public void chatMsg(ClientConnection con, AOByteBuffer buf)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static MasterServer getMasterServer()
/*     */   {
/* 164 */     if (masterServer == null) {
/* 165 */       masterServer = new MasterServer();
/*     */     }
/* 167 */     return masterServer;
/*     */   }
/*     */ 
/*     */   public static String getDBType()
/*     */   {
/* 438 */     String dbtype = properties.getProperty("atavism.db_type");
/* 439 */     if (dbtype == null) {
/* 440 */       return "mysql";
/*     */     }
/* 442 */     return dbtype;
/*     */   }
/*     */ 
/*     */   public static String getDBUrl()
/*     */   {
/* 450 */     String url = properties.getProperty("atavism.db_url");
/* 451 */     if (url == null)
/* 452 */       url = "jdbc:" + getDBType() + "://" + getDBHostname() + "/" + getDBName();
/* 453 */     return url;
/*     */   }
/*     */ 
/*     */   public static String getDBUser()
/*     */   {
/* 461 */     return properties.getProperty("atavism.db_user");
/*     */   }
/*     */ 
/*     */   public static String getDBPassword()
/*     */   {
/* 469 */     return properties.getProperty("atavism.db_password");
/*     */   }
/*     */ 
/*     */   public static String getDBHostname()
/*     */   {
/* 477 */     return properties.getProperty("atavism.db_hostname");
/*     */   }
/*     */ 
/*     */   public static String getDBName()
/*     */   {
/* 485 */     String dbname = properties.getProperty("atavism.db_name");
/* 486 */     if (dbname == null) {
/* 487 */       return "atavism";
/*     */     }
/* 489 */     return dbname;
/*     */   }
/*     */ 
/*     */   public static String getRemoteDBUrl()
/*     */   {
/* 498 */     String url = properties.getProperty("atavism.remote_db_url");
/* 499 */     if (url == null)
/* 500 */       url = "jdbc:" + getDBType() + "://" + getRemoteDBHostname() + "/" + getRemoteDBName();
/* 501 */     return url;
/*     */   }
/*     */ 
/*     */   public static String getRemoteDBUser()
/*     */   {
/* 509 */     return properties.getProperty("atavism.remote_db_user");
/*     */   }
/*     */ 
/*     */   public static String getRemoteDBPassword()
/*     */   {
/* 517 */     return properties.getProperty("atavism.remote_db_password");
/*     */   }
/*     */ 
/*     */   public static String getRemoteDBHostname()
/*     */   {
/* 525 */     return properties.getProperty("atavism.remote_db_hostname");
/*     */   }
/*     */ 
/*     */   public static String getRemoteDBName()
/*     */   {
/* 533 */     String dbname = properties.getProperty("atavism.remote_db_name");
/* 534 */     if (dbname == null) {
/* 535 */       return "master";
/*     */     }
/* 537 */     return dbname;
/*     */   }
/*     */ 
/*     */   public static String getRemoteAccountTableName()
/*     */   {
/* 546 */     String dbname = properties.getProperty("atavism.remote_db_account_table");
/* 547 */     if (dbname == null) {
/* 548 */       return "account";
/*     */     }
/* 550 */     return dbname;
/*     */   }
/*     */ 
/*     */   public static boolean remoteDatabaseEnabled()
/*     */   {
/* 559 */     String remoteDatabaseEnabled = properties.getProperty("atavism.remote_db_enabled");
/*     */ 
/* 561 */     return (remoteDatabaseEnabled != null) && (remoteDatabaseEnabled.equals("true"));
/*     */   }
/*     */ 
/*     */   public static boolean useSaltedMd5Passwords()
/*     */   {
/* 572 */     String useMd5Passwords = properties.getProperty("atavism.use_salted_passwords");
/*     */ 
/* 574 */     return (useMd5Passwords != null) && (useMd5Passwords.equals("true"));
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 583 */     if (args.length != 1) {
/* 584 */       Log.error("specify script file");
/* 585 */       System.exit(1);
/*     */     }
/*     */     try
/*     */     {
/* 589 */       properties = InitLogAndPid.initLogAndPid(args);
/*     */ 
/* 591 */       byte[] domainKey = SecureTokenUtil.encodeDomainKey(1L, SecureTokenUtil.generateDomainKey());
/* 592 */       SecureTokenManager.getInstance().initDomain(domainKey);
/*     */ 
/* 594 */       MasterServer ms = getMasterServer();
/*     */ 
/* 597 */       String scriptFilename = args[0];
/* 598 */       ScriptManager scriptManager = new ScriptManager();
/* 599 */       scriptManager.init();
/* 600 */       if (Log.loggingDebug)
/* 601 */         Log.debug("Executing script file: " + scriptFilename);
/* 602 */       scriptManager.runFile(scriptFilename);
/* 603 */       Log.debug("script completed");
/*     */ 
/* 606 */       ms.dbConnect();
/*     */ 
/* 610 */       String log_rdp_counters = properties.getProperty("atavism.log_rdp_counters");
/*     */ 
/* 612 */       if ((log_rdp_counters == null) || (log_rdp_counters.equals("false"))) {
/* 613 */         RDPServer.setCounterLogging(false);
/*     */       }
/* 615 */       RDPServerSocket serverSocket = null;
/* 616 */       serverSocket = new RDPServerSocket();
/* 617 */       RDPServer.startRDPServer();
/* 618 */       serverSocket.registerAcceptCallback(masterServer);
/* 619 */       serverSocket.bind(ms.getRDPPort());
/* 620 */       Log.info("masterserver: rdp on port " + ms.getRDPPort());
/* 621 */       clientTCPMessageIO = ClientTCPMessageIO.setup(Integer.valueOf(ms.getRDPPort()), masterServer);
/* 622 */       clientTCPMessageIO.start();
/*     */ 
/* 625 */       Log.info("masterserver: tcp on port " + ms.getTCPPort());
/* 626 */       ServerSocket socket = new ServerSocket(ms.getTCPPort());
/* 627 */       if (Log.loggingDebug)
/* 628 */         Log.debug("masterserver: tcp server listening on port " + ms.getTCPPort());
/*     */       while (true)
/*     */       {
/* 631 */         Socket clientSocket = socket.accept();
/* 632 */         threadPool.execute(new SocketHandler(clientSocket, getMasterServer().db, getMasterServer().remoteConnector));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 636 */       Log.exception("MasterServer.main caught exception", e);
/* 637 */       System.exit(1);
/*     */ 
/* 639 */       Log.info("connected to database");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class SocketHandler
/*     */     implements Runnable
/*     */   {
/* 178 */     private Socket clientSocket = null;
/* 179 */     private MasterDatabase db = null;
/* 180 */     private RemoteAccountConnector remoteConnector = null;
/* 181 */     private Random random = new Random();
/*     */ 
/*     */     public SocketHandler(Socket socket, MasterDatabase db, RemoteAccountConnector connector)
/*     */     {
/* 173 */       this.clientSocket = socket;
/* 174 */       this.db = db;
/* 175 */       this.remoteConnector = connector;
/*     */     }
/*     */ 
/*     */     private byte[] generateAuthResponse(String username, String password, byte[] challenge)
/*     */     {
/* 184 */       byte[] keyData = password.getBytes();
/*     */       try
/*     */       {
/* 187 */         SecretKeySpec key = new SecretKeySpec(keyData, "HmacSHA1");
/*     */ 
/* 189 */         Mac mac = Mac.getInstance(key.getAlgorithm());
/* 190 */         mac.init(key);
/*     */ 
/* 192 */         AOByteBuffer buf = new AOByteBuffer(256);
/* 193 */         buf.putString(username);
/* 194 */         buf.putInt(1);
/* 195 */         buf.putInt(challenge.length);
/* 196 */         buf.putBytes(challenge, 0, challenge.length);
/* 197 */         byte[] data = new byte[buf.position()];
/* 198 */         buf.rewind();
/* 199 */         buf.getBytes(data, 0, data.length);
/* 200 */         Log.debug("dataLen=" + data.length);
/* 201 */         Log.debug("data=" + Base64.encodeBytes(data));
/* 202 */         return mac.doFinal(data);
/*     */       }
/*     */       catch (NoSuchAlgorithmException e)
/*     */       {
/* 206 */         Log.exception("SecureTokenManager.generateDomainAuthenticator: bad implementation", e);
/* 207 */         return null;
/*     */       }
/*     */       catch (InvalidKeyException e)
/*     */       {
/* 211 */         Log.exception("SecureTokenManager.generateDomainAuthenticator: invalid key", e);
/* 212 */         throw new RuntimeException(e);
/*     */       }
/*     */       catch (IllegalStateException e)
/*     */       {
/* 216 */         Log.exception("SecureTokenManager.generateDomainAuthenticator: illegal state", e);
/* 217 */       }throw new RuntimeException(e);
/*     */     }
/*     */ 
/*     */     private void handleAuth(DataInputStream in, DataOutputStream out) throws IOException
/*     */     {
/* 222 */       int magicCookie = in.readInt();
/* 223 */       int version = in.readInt();
/* 224 */       Log.debug("cookie=" + magicCookie + " version=" + version);
/* 225 */       if (version != 1) {
/* 226 */         throw new RuntimeException("unsupported version=" + version);
/*     */       }
/* 228 */       int usernameLen = in.readInt();
/* 229 */       if (Log.loggingDebug)
/* 230 */         Log.debug("MasterServer.handleAuth: username len=" + usernameLen);
/* 231 */       if (usernameLen > 1000) {
/* 232 */         throw new RuntimeException("username too long, len=" + usernameLen);
/*     */       }
/* 234 */       byte[] usernameBuf = new byte[usernameLen];
/* 235 */       in.readFully(usernameBuf);
/* 236 */       String username = new String(usernameBuf);
/* 237 */       if (Log.loggingDebug) {
/* 238 */         Log.debug("MasterServer.handleAuth: login username=" + username);
/*     */       }
/* 240 */       int passwordLen = in.readInt();
/* 241 */       byte[] passwordBuf = new byte[passwordLen];
/* 242 */       in.readFully(passwordBuf);
/* 243 */       String password = new String(passwordBuf);
/*     */ 
/* 246 */       int createAccount = in.readInt();
/* 247 */       Log.debug("MasterServer.handleAuth: createaccount=" + createAccount);
/* 248 */       if (createAccount == 1) {
/* 249 */         Log.debug("MasterServer.handleAuth: creating account=" + username);
/* 250 */         int emailLen = in.readInt();
/* 251 */         byte[] emailBuf = new byte[emailLen];
/* 252 */         in.readFully(emailBuf);
/* 253 */         String email = new String(emailBuf);
/* 254 */         int status = this.db.createAccount(username, password, email);
/* 255 */         out.writeInt(status);
/* 256 */         return;
/*     */       }
/*     */ 
/* 259 */       byte[] challenge = new byte[20];
/* 260 */       this.random.nextBytes(challenge);
/*     */ 
/* 267 */       byte[] authResponse = null;
/* 268 */       if (password != null) {
/* 269 */         authResponse = generateAuthResponse(username, password, challenge);
/*     */       }
/*     */ 
/* 276 */       Log.debug("password=" + password);
/* 277 */       if (authResponse != null) {
/* 278 */         Log.debug("authResponse=" + Base64.encodeBytes(authResponse));
/*     */       }
/*     */ 
/* 284 */       OID accountOID = null;
/* 285 */       if ((this.remoteConnector != null) && (this.remoteConnector.verifyAccount(username, password))) {
/* 286 */         Log.debug("Got remote connector verfication: " + this.remoteConnector);
/* 287 */         Integer accountId = this.db.getAccountId(username);
/* 288 */         if (accountId != null) {
/* 289 */           accountOID = OID.fromLong(accountId.intValue());
/*     */         }
/* 291 */         else if (this.db.createAccount(username, password, username) == 1) {
/* 292 */           accountId = this.db.getAccountId(username);
/* 293 */           accountOID = OID.fromLong(accountId.intValue());
/*     */         }
/*     */       }
/*     */       else {
/* 297 */         accountOID = this.db.passwordCheck(username, password);
/*     */       }
/*     */ 
/* 300 */       if (accountOID != null)
/*     */       {
/* 302 */         int accountStatus = this.db.statusCheck(username);
/* 303 */         if (accountStatus > 0)
/*     */         {
/* 305 */           out.writeInt(1); } else {
/* 306 */           if (accountStatus == 0)
/*     */           {
/* 308 */             out.writeInt(4);
/*     */ 
/* 310 */             out.writeInt(0);
/*     */ 
/* 312 */             out.writeInt(0);
/* 313 */             return;
/*     */           }
/*     */ 
/* 316 */           out.writeInt(5);
/*     */ 
/* 318 */           out.writeInt(0);
/*     */ 
/* 320 */           out.writeInt(0);
/* 321 */           return;
/*     */         }
/*     */ 
/* 324 */         Integer accountId = this.db.getAccountId(username);
/* 325 */         SecureTokenSpec masterSpec = new SecureTokenSpec(1, "master", System.currentTimeMillis() + MasterServer.masterTokenValidTime);
/*     */ 
/* 329 */         masterSpec.setProperty("account_id", accountId);
/* 330 */         masterSpec.setProperty("account_name", username);
/* 331 */         byte[] masterToken = SecureTokenManager.getInstance().generateToken(masterSpec);
/* 332 */         Log.debug("tokenLen=" + masterToken.length + " token=" + Base64.encodeBytes(masterToken));
/* 333 */         AOByteBuffer tmpBuf = new AOByteBuffer(16);
/* 334 */         tmpBuf.putInt(accountId.intValue() ^ 0xFFFFFFFF);
/* 335 */         tmpBuf.flip();
/* 336 */         byte[] oldToken = new byte[4];
/* 337 */         tmpBuf.getBytes(oldToken, 0, oldToken.length);
/*     */ 
/* 340 */         if (masterToken == null) {
/* 341 */           Log.debug("null token");
/*     */         }
/*     */         else {
/* 344 */           Log.debug("tokenLen=" + masterToken.length + " token=" + Base64.encodeBytes(masterToken));
/*     */         }
/* 346 */         out.writeInt(masterToken.length);
/* 347 */         out.write(masterToken);
/* 348 */         out.writeInt(oldToken.length);
/* 349 */         out.write(oldToken);
/*     */       }
/*     */       else
/*     */       {
/* 353 */         out.writeInt(0);
/*     */ 
/* 355 */         out.writeInt(0);
/*     */ 
/* 357 */         out.writeInt(0);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void handleOldStyleAuth(DataInputStream in, DataOutputStream out) throws IOException {
/* 362 */       int usernameLen = in.readInt();
/* 363 */       if (Log.loggingDebug)
/* 364 */         Log.debug("masterserver: username len=" + usernameLen);
/* 365 */       if (usernameLen > 1000) {
/* 366 */         throw new RuntimeException("username too long, len=" + usernameLen);
/*     */       }
/* 368 */       byte[] nameBuf = new byte[usernameLen];
/* 369 */       in.readFully(nameBuf);
/* 370 */       String username = new String(nameBuf);
/* 371 */       if (Log.loggingDebug) {
/* 372 */         Log.debug("masterserver: login username=" + username);
/*     */       }
/*     */ 
/* 375 */       int passwordLen = in.readInt();
/* 376 */       byte[] passwordBuf = new byte[passwordLen];
/* 377 */       in.readFully(passwordBuf);
/* 378 */       String password = new String(passwordBuf);
/* 379 */       if (Log.loggingDebug) {
/* 380 */         Log.debug("login info: password=" + password);
/*     */       }
/*     */ 
/* 383 */       int uid = this.db.AOAcctPasswdCheck(username, password);
/* 384 */       if (uid == -1) {
/* 385 */         Log.warn("MasterServer: password check failed for username " + username);
/*     */       }
/* 387 */       else if (Log.loggingDebug) {
/* 388 */         Log.debug("MasterServer: password verified, uid=" + uid + ", token=" + (uid ^ 0xFFFFFFFF));
/*     */       }
/*     */ 
/* 392 */       out.writeInt(uid == -1 ? 0 : 1);
/*     */ 
/* 395 */       out.writeInt(4);
/* 396 */       out.writeInt(uid ^ 0xFFFFFFFF);
/*     */     }
/*     */ 
/*     */     public void run() {
/*     */       try {
/* 401 */         BufferedInputStream bufferedIn = new BufferedInputStream(this.clientSocket.getInputStream());
/* 402 */         DataInputStream in = new DataInputStream(bufferedIn);
/* 403 */         DataOutputStream out = new DataOutputStream(this.clientSocket.getOutputStream());
/*     */ 
/* 405 */         if (!in.markSupported()) {
/* 406 */           throw new RuntimeException("MasterServer.run: cannot use mark/reset on input stream");
/*     */         }
/*     */ 
/* 409 */         in.mark(4);
/* 410 */         int magicCookie = in.readInt();
/* 411 */         Log.debug("Magic cookie: " + magicCookie);
/*     */ 
/* 413 */         in.reset();
/* 414 */         if (magicCookie == -1) {
/* 415 */           handleAuth(in, out);
/*     */         }
/*     */         else
/* 418 */           handleOldStyleAuth(in, out);
/*     */       }
/*     */       catch (Exception e) {
/* 421 */         Log.exception("MasterServer.run caught exception", e);
/*     */       } finally {
/*     */         try {
/* 424 */           this.clientSocket.close();
/* 425 */           if (Log.loggingDebug)
/* 426 */             Log.debug("SocketHandler: closed socket: " + this.clientSocket);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.MasterServer
 * JD-Core Version:    0.6.0
 */