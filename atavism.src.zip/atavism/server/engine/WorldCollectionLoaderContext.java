/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.objects.Instance;
/*    */ import java.io.Serializable;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WorldCollectionLoaderContext
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 14 */   private LinkedList<String> worldCollectionFiles = new LinkedList();
/* 15 */   private LinkedList<String> worldCollectionDatabaseKeys = new LinkedList();
/*    */ 
/*    */   public boolean load(Instance instance)
/*    */   {
/* 25 */     return load(instance, instance.getWorldLoaderOverride());
/*    */   }
/*    */ 
/*    */   public boolean load(Instance instance, WorldLoaderOverride worldLoaderOverride)
/*    */   {
/* 37 */     boolean rv = true;
/* 38 */     for (WorldCollectionLoader loader : getWorldCollectionLoaders(instance, worldLoaderOverride))
/*    */     {
/* 40 */       rv &= loader.load(instance);
/*    */     }
/* 42 */     return rv;
/*    */   }
/*    */ 
/*    */   public List<WorldCollectionLoader> getWorldCollectionLoaders(Instance instance, WorldLoaderOverride worldLoaderOverride)
/*    */   {
/* 55 */     List worldCollections = new LinkedList();
/* 56 */     for (String fileName : getWorldCollectionFiles())
/*    */     {
/* 58 */       worldCollections.add(new WorldCollectionFileLoader(fileName, worldLoaderOverride));
/*    */     }
/* 60 */     for (String persistenceKey : getWorldCollectionDatabaseKeys())
/*    */     {
/* 62 */       worldCollections.add(new WorldCollectionDatabaseLoader(persistenceKey, worldLoaderOverride));
/*    */     }
/* 64 */     return worldCollections;
/*    */   }
/*    */ 
/*    */   public synchronized void setWorldCollectionFiles(List<String> fileNames) {
/* 68 */     this.worldCollectionFiles.clear();
/* 69 */     this.worldCollectionFiles.addAll(fileNames);
/*    */   }
/*    */ 
/*    */   public synchronized void addWorldCollectionFile(String fileName) {
/* 73 */     this.worldCollectionFiles.add(fileName);
/*    */   }
/*    */ 
/*    */   public synchronized List<String> getWorldCollectionFiles() {
/* 77 */     return new LinkedList(this.worldCollectionFiles);
/*    */   }
/*    */ 
/*    */   public synchronized void setWorldCollectionDatabaseKeys(List<String> persistenceKeys) {
/* 81 */     this.worldCollectionDatabaseKeys.clear();
/* 82 */     this.worldCollectionDatabaseKeys.addAll(persistenceKeys);
/*    */   }
/*    */ 
/*    */   public synchronized void addWorldCollectionDatabaseKey(String persistenceKey) {
/* 86 */     this.worldCollectionDatabaseKeys.add(persistenceKey);
/*    */   }
/*    */ 
/*    */   public synchronized List<String> getWorldCollectionDatabaseKeys() {
/* 90 */     return new LinkedList(this.worldCollectionDatabaseKeys);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.WorldCollectionLoaderContext
 * JD-Core Version:    0.6.0
 */