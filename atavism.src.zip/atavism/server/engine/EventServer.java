/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class EventServer
/*     */ {
/* 140 */   private Map<Integer, Class> eventIdMapping = new HashMap();
/*     */ 
/* 145 */   private Map<Class, Integer> eventClassMapping = new HashMap();
/*     */ 
/* 148 */   transient Lock lock = LockFactory.makeLock("EventServerLock");
/*     */ 
/*     */   public Event parseBytes(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  16 */     Object obj = parseAnyBytes(buf);
/*  17 */     if (!(obj instanceof Event))
/*  18 */       throw new AORuntimeException("EventServer: new instance is not an Event");
/*  19 */     Event event = (Event)obj;
/*  20 */     event.setConnection(con);
/*  21 */     event.setBuffer(buf);
/*  22 */     return event;
/*     */   }
/*     */ 
/*     */   public Object parseAnyBytes(AOByteBuffer buf)
/*     */   {
/*  31 */     OID playerId = buf.getOID();
/*  32 */     int eventID = buf.getInt();
/*  33 */     long test = buf.getLong();
/*  34 */     Log.debug(new StringBuilder().append("ParseAnyBytes - long: ").append(test).toString());
/*  35 */     buf.rewind();
/*     */ 
/*  37 */     Class eventClass = null;
/*     */ 
/*  39 */     this.lock.lock();
/*     */     try {
/*  41 */       eventClass = (Class)this.eventIdMapping.get(Integer.valueOf(eventID));
/*  42 */       if (Log.loggingDebug) {
/*  43 */         Log.debug(new StringBuilder().append("EventServer.parsebytes: id=").append(eventID).append(eventClass != null ? new StringBuilder().append(", found event class: ").append(eventClass.getName()).toString() : "").toString());
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*  48 */       this.lock.unlock();
/*     */     }
/*     */ 
/*  51 */     if (eventClass == null) {
/*  52 */       Log.error(new StringBuilder().append("found no event class for oid ").append(playerId).append(", id ").append(eventID).toString());
/*  53 */       Log.dumpStack("Event.parseBytes");
/*  54 */       return null;
/*     */     }
/*     */     try
/*     */     {
/*  58 */       Object obj = eventClass.newInstance();
/*  59 */       if (obj == null) {
/*  60 */         throw new AORuntimeException(new StringBuilder().append("EventServer: newInstance failed on ").append(eventClass).toString());
/*     */       }
/*     */ 
/*  63 */       if (!(obj instanceof EventParser)) {
/*  64 */         throw new AORuntimeException("EventServer: new instance is not an EventParser");
/*     */       }
/*  66 */       EventParser event = (EventParser)obj;
/*  67 */       event.parseBytes(buf);
/*  68 */       return event;
/*     */     } catch (Exception e) {
/*     */     }
/*  71 */     throw new AORuntimeException("EventServer.parseBytes", e);
/*     */   }
/*     */ 
/*     */   public void registerEventId(int id, String className)
/*     */   {
/*  82 */     this.lock.lock();
/*     */     try {
/*  84 */       Class eventClass = Class.forName(className);
/*  85 */       if (Log.loggingDebug) {
/*  86 */         Log.debug(new StringBuilder().append("loaded event, event id#").append(id).append(" maps to '").append(className).append("'").toString());
/*     */       }
/*     */ 
/*  89 */       this.eventIdMapping.put(Integer.valueOf(id), eventClass);
/*  90 */       this.eventClassMapping.put(eventClass, Integer.valueOf(id));
/*     */     }
/*     */     catch (Exception e) {
/*  93 */       throw new AORuntimeException(new StringBuilder().append("EventServer: could not find/instantiate class '").append(className).append("': ").append(e).toString());
/*     */     }
/*     */     finally {
/*  96 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getEventClass(int id) {
/* 101 */     this.lock.lock();
/*     */     try {
/* 103 */       Class localClass = (Class)this.eventIdMapping.get(Integer.valueOf(id));
/*     */       return localClass; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public int getEventID(Class eventClass)
/*     */   {
/* 114 */     this.lock.lock();
/*     */     try {
/* 116 */       Integer id = (Integer)this.eventClassMapping.get(eventClass);
/* 117 */       if (id == null) {
/* 118 */         throw new AORuntimeException("EventServer.getEventId: id is null");
/*     */       }
/* 120 */       int i = id.intValue();
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public int getEventID(String className)
/*     */   {
/*     */     try {
/* 129 */       Class eventClass = Class.forName(className);
/* 130 */       return getEventID(eventClass);
/*     */     } catch (Exception e) {
/*     */     }
/* 133 */     throw new AORuntimeException("EventServer.getEventID", e);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.EventServer
 * JD-Core Version:    0.6.0
 */