/*    */ package atavism.server.engine;
/*    */ 
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.objects.Entity;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ import atavism.server.util.Log;
/*    */ 
/*    */ public abstract class Event
/*    */   implements EventParser
/*    */ {
/* 94 */   private OID eventObjOid = null;
/* 95 */   private ClientConnection con = null;
/* 96 */   private AOByteBuffer buffer = null;
/* 97 */   private long enqueueTime = 0L;
/*    */ 
/*    */   public Event()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Event(AOByteBuffer buf, ClientConnection con)
/*    */   {
/*    */     try
/*    */     {
/* 17 */       parseBytes(buf);
/* 18 */       this.con = con;
/* 19 */       this.buffer = buf;
/*    */     }
/*    */     catch (AORuntimeException e) {
/* 22 */       Log.error("Event constructor: failed to parse bytes");
/*    */     }
/*    */   }
/*    */ 
/*    */   public Event(Entity obj) {
/* 27 */     setEntity(obj);
/*    */   }
/*    */ 
/*    */   public Event(OID oid) {
/* 31 */     this.eventObjOid = oid;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 35 */     return "[Event: " + getName() + "]";
/*    */   }
/*    */ 
/*    */   public abstract String getName();
/*    */ 
/*    */   public abstract AOByteBuffer toBytes();
/*    */ 
/*    */   public abstract void parseBytes(AOByteBuffer paramAOByteBuffer);
/*    */ 
/*    */   public void setEntity(Entity obj)
/*    */   {
/* 52 */     if (obj != null)
/* 53 */       this.eventObjOid = obj.getOid();
/*    */   }
/*    */ 
/*    */   public void setObject(AOObject obj) {
/* 57 */     if (obj != null)
/* 58 */       this.eventObjOid = obj.getOid();
/*    */   }
/*    */ 
/*    */   public void setObjectOid(OID objOid) {
/* 62 */     this.eventObjOid = objOid;
/*    */   }
/*    */ 
/*    */   public OID getObjectOid() {
/* 66 */     return this.eventObjOid;
/*    */   }
/*    */ 
/*    */   public void setConnection(ClientConnection con) {
/* 70 */     this.con = con;
/*    */   }
/*    */ 
/*    */   public ClientConnection getConnection() {
/* 74 */     return this.con;
/*    */   }
/*    */ 
/*    */   public void setBuffer(AOByteBuffer buf) {
/* 78 */     this.buffer = buf;
/*    */   }
/*    */ 
/*    */   public void setEnqueueTime(long time) {
/* 82 */     this.enqueueTime = time;
/*    */   }
/*    */   public long getEnqueueTime() {
/* 85 */     return this.enqueueTime;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer getBuffer()
/*    */   {
/* 92 */     return this.buffer;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Event
 * JD-Core Version:    0.6.0
 */