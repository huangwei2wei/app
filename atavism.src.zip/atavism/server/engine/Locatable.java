package atavism.server.engine;

import atavism.server.math.Point;

public abstract interface Locatable
{
  public abstract Point getLoc();

  public abstract void setLoc(Point paramPoint);

  public abstract Point getCurrentLoc();

  public abstract OID getInstanceOid();

  public abstract long getLastUpdate();

  public abstract void setLastUpdate(long paramLong);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Locatable
 * JD-Core Version:    0.6.0
 */