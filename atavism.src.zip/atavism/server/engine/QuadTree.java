/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.objects.Region;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class QuadTree<ElementType extends QuadTreeElement<ElementType>>
/*     */ {
/* 187 */   public QuadTree<ElementType>.NewsAndFrees spawningNewsAndFrees = null;
/*     */ 
/* 723 */   protected Set<FixedPerceiver<ElementType>> fixedPerceivers = new HashSet();
/*     */ 
/* 759 */   private Geometry localGeometry = null;
/*     */ 
/* 761 */   private int hysteresis = 0;
/*     */ 
/* 763 */   private int maxObjects = 30;
/*     */ 
/* 765 */   private int maxDepth = 20;
/*     */ 
/* 767 */   private QuadTreeNode<ElementType> rootNode = null;
/*     */ 
/* 769 */   private Lock lock = LockFactory.makeLock("QuadTreeLock");
/*     */   boolean supportsExtentBasedPerceiver;
/* 873 */   protected static final Logger log = new Logger("QuadTree");
/*     */ 
/*     */   public QuadTree(Geometry g)
/*     */   {
/*  27 */     createQuadTree(g, 0);
/*     */   }
/*     */ 
/*     */   public QuadTree(Geometry g, int hysteresis) {
/*  31 */     createQuadTree(g, hysteresis);
/*     */   }
/*     */ 
/*     */   protected void createQuadTree(Geometry g, int hysteresis) {
/*  35 */     this.supportsExtentBasedPerceiver = true;
/*  36 */     this.hysteresis = hysteresis;
/*  37 */     this.rootNode = new QuadTreeNode(this, null, g, QuadTreeNode.NodeType.REMOTE);
/*     */   }
/*     */ 
/*     */   public QuadTree(Geometry g, boolean supportsExtentBasedPerceiver)
/*     */   {
/*  44 */     this.supportsExtentBasedPerceiver = supportsExtentBasedPerceiver;
/*  45 */     this.rootNode = new QuadTreeNode(this, null, g, QuadTreeNode.NodeType.REMOTE);
/*     */   }
/*     */ 
/*     */   QuadTreeNode<ElementType> getRoot()
/*     */   {
/*  50 */     return this.rootNode;
/*     */   }
/*     */ 
/*     */   public void printTree() {
/*  54 */     this.rootNode.recurseToString();
/*     */   }
/*     */ 
/*     */   public Set<ElementType> getElements(Point loc, int radius)
/*     */   {
/*  60 */     return this.rootNode.getElements(loc, radius);
/*     */   }
/*     */ 
/*     */   public Set<ElementType> getElementsBetween(Point loc1, Point loc2)
/*     */   {
/*  69 */     return this.rootNode.getElementsBetween(loc1, loc2);
/*     */   }
/*     */ 
/*     */   public Set<ElementType> getElements(ElementType elem, int radius)
/*     */   {
/*  76 */     return getElements(elem.getLoc(), radius);
/*     */   }
/*     */ 
/*     */   public Geometry getLocalGeometry() {
/*  80 */     return this.localGeometry;
/*     */   }
/*     */ 
/*     */   public void addRegion(Region region) {
/*  84 */     this.rootNode.addRegion(region);
/*     */   }
/*     */ 
/*     */   public List<Region> getRegionsContainingPoint(Point loc)
/*     */   {
/*  92 */     this.lock.lock();
/*     */     try {
/*  94 */       QuadTreeNode newNode = findLeafNode(loc);
/*  95 */       List localList = newNode.getRegionByLoc(loc);
/*     */       return localList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setMaxObjects(int max)
/*     */   {
/* 104 */     if ((max > 0) && (max != this.maxObjects)) {
/* 105 */       Log.info("QuadTree maximum-objects-per-node changed from " + this.maxObjects + " to " + max);
/*     */ 
/* 107 */       this.maxObjects = max;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMaxObjects() {
/* 112 */     return this.maxObjects;
/*     */   }
/*     */ 
/*     */   public void setMaxDepth(int max) {
/* 116 */     if ((max > 0) && (max != this.maxDepth)) {
/* 117 */       Log.info("QuadTree maximum-depth changed from " + this.maxDepth + " to " + max);
/*     */ 
/* 119 */       this.maxDepth = max;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMaxDepth() {
/* 124 */     return this.maxDepth;
/*     */   }
/*     */ 
/*     */   public boolean getSupportsExtentBasedPerceiver() {
/* 128 */     return this.supportsExtentBasedPerceiver;
/*     */   }
/*     */ 
/*     */   public Lock getLock() {
/* 132 */     return this.lock;
/*     */   }
/*     */ 
/*     */   public int getHysteresis() {
/* 136 */     return this.hysteresis;
/*     */   }
/*     */ 
/*     */   public void setHysteresis(int hysteresis) {
/* 140 */     this.hysteresis = hysteresis;
/*     */   }
/*     */ 
/*     */   public QuadTreeNode<ElementType> addElement(ElementType elem)
/*     */   {
/* 155 */     NewsAndFrees newsAndFrees = new NewsAndFrees();
/* 156 */     this.lock.lock();
/*     */     try {
/* 158 */       QuadTreeNode node = addElementInternal(elem, newsAndFrees);
/* 159 */       newsAndFrees.processNewsAndFrees();
/* 160 */       QuadTreeNode localQuadTreeNode1 = node;
/*     */       return localQuadTreeNode1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Integer addElementReturnCountForPerceiver(ElementType elem, OID mobilePerceiverOid)
/*     */   {
/* 175 */     NewsAndFrees newsAndFrees = new NewsAndFrees();
/* 176 */     this.lock.lock();
/*     */     try
/*     */     {
/* 179 */       addElementInternal(elem, newsAndFrees);
/* 180 */       Integer count = newsAndFrees.processNewsAndFrees(mobilePerceiverOid);
/*     */ 
/* 182 */       Integer localInteger1 = Integer.valueOf(count == null ? 0 : count.intValue());
/*     */       return localInteger1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean removeElement(ElementType elem)
/*     */   {
/* 191 */     NewsAndFrees newsAndFrees = new NewsAndFrees();
/* 192 */     this.lock.lock();
/*     */     try {
/* 194 */       boolean rv = removeElementInternal(elem, newsAndFrees);
/* 195 */       newsAndFrees.processNewsAndFrees();
/* 196 */       boolean bool1 = rv;
/*     */       return bool1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Integer removeElementReturnCountForPerceiver(ElementType elem, OID mobilePerceiverOid)
/*     */   {
/* 210 */     NewsAndFrees newsAndFrees = new NewsAndFrees();
/* 211 */     this.lock.lock();
/*     */     try
/*     */     {
/* 214 */       removeElementInternal(elem, newsAndFrees);
/* 215 */       Integer count = newsAndFrees.processNewsAndFrees(mobilePerceiverOid);
/*     */ 
/* 217 */       Integer localInteger1 = Integer.valueOf(count == null ? 0 : count.intValue());
/*     */       return localInteger1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void updateElement(ElementType elem, Point loc)
/*     */   {
/* 229 */     NewsAndFrees newsAndFrees = new NewsAndFrees();
/* 230 */     this.lock.lock();
/*     */     try {
/* 232 */       updateElementInternal(elem, loc, newsAndFrees);
/* 233 */       newsAndFrees.processNewsAndFrees();
/*     */     } finally {
/* 235 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updatePerceiver(Perceiver<ElementType> perceiver) {
/* 240 */     NewsAndFrees newsAndFrees = new NewsAndFrees();
/* 241 */     this.lock.lock();
/*     */     try {
/* 243 */       updatePerceiverInternal(perceiver, newsAndFrees);
/* 244 */       newsAndFrees.processNewsAndFrees();
/*     */     } finally {
/* 246 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addFixedPerceiver(FixedPerceiver<ElementType> perceiver) {
/* 251 */     if (Log.loggingDebug)
/* 252 */       log.debug("QuadTree.addFixedPerceiver p=" + perceiver);
/* 253 */     this.fixedPerceivers.add(perceiver);
/* 254 */     updatePerceiver(perceiver);
/*     */   }
/*     */ 
/*     */   public void removeFixedPerceiver(FixedPerceiver<ElementType> perceiver) {
/* 258 */     this.fixedPerceivers.remove(perceiver);
/* 259 */     updatePerceiver(perceiver);
/*     */   }
/*     */ 
/*     */   public void setLocalGeometry(Geometry g) {
/* 263 */     NewsAndFrees newsAndFrees = new NewsAndFrees();
/* 264 */     this.lock.lock();
/*     */     try {
/* 266 */       this.localGeometry = g;
/* 267 */       setLocalGeometryHelper(this.rootNode, g, newsAndFrees);
/* 268 */       newsAndFrees.processNewsAndFrees();
/*     */     } finally {
/* 270 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection<ElementType> getElementPerceivables(ElementType elem)
/*     */   {
/* 276 */     Set result = new HashSet();
/* 277 */     this.lock.lock();
/*     */     try {
/* 279 */       Perceiver perceiver = elem.getPerceiver();
/* 280 */       if (perceiver == null) {
/* 281 */         Set localSet1 = result;
/*     */         return localSet1;
/*     */       }
/* 283 */       Set nodes = perceiver.getQuadTreeNodes();
/*     */ 
/* 285 */       for (QuadTreeNode node : nodes) {
/* 286 */         result.addAll(node.getNodeElements());
/*     */ 
/* 288 */         Set perceiverExtentObjects = node.getPerceiverExtentObjects();
/*     */ 
/* 290 */         if (perceiverExtentObjects != null) {
/* 291 */           result.addAll(perceiverExtentObjects);
/*     */         }
/*     */       }
/* 294 */       ??? = result;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   protected QuadTreeNode<ElementType> addElementInternal(ElementType elem, QuadTree<ElementType>.NewsAndFrees newsAndFrees)
/*     */   {
/* 307 */     Point loc = elem.getLoc();
/* 308 */     this.lock.lock();
/*     */     try {
/* 310 */       if (this.supportsExtentBasedPerceiver) {
/* 311 */         radius = elem.getPerceptionRadius();
/* 312 */         if (Log.loggingDebug)
/* 313 */           Log.debug("QuadTree.addElementInternal: elem " + elem + ", percept radius " + radius);
/* 314 */         if (radius > 0) {
/* 315 */           this.rootNode.addPerceiverExtentObject(elem, loc, radius);
/*     */         }
/*     */       }
/* 318 */       int radius = addHelper(this.rootNode, elem, loc, newsAndFrees);
/*     */       return radius; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   protected QuadTreeNode<ElementType> addHelper(QuadTreeNode<ElementType> node, ElementType elem, Point loc, QuadTree<ElementType>.NewsAndFrees newsAndFrees)
/*     */   {
/* 328 */     if (loc == null) {
/* 329 */       throw new AORuntimeException("QuadTree.addHelper: obj has null location");
/*     */     }
/* 331 */     if (!node.getGeometry().contains(loc)) {
/* 332 */       Log.warn("QuadTree.addHelper: element not within node, element=" + elem + ", quadtreenode=" + node);
/*     */ 
/* 334 */       return null;
/*     */     }
/*     */ 
/* 337 */     if (node.isLeaf()) {
/* 338 */       if (Log.loggingDebug) {
/* 339 */         log.debug("QuadTree.addHelper: node is leaf: " + node + ", rootNode is leaf? " + this.rootNode.isLeaf() + ", qtree=" + hashCode());
/*     */       }
/*     */ 
/* 344 */       int curSize = node.numElements();
/* 345 */       int maxSize = getMaxObjects();
/* 346 */       if ((curSize >= maxSize) && (node.getDepth() < getMaxDepth()))
/*     */       {
/* 348 */         if (Log.loggingDebug) {
/* 349 */           log.debug("QuadTree.addHelper: maxObj=" + maxSize + ", cursize=" + curSize + ".. dividing");
/*     */         }
/* 351 */         node.divide(newsAndFrees);
/* 352 */         return addHelper(node, elem, loc, newsAndFrees);
/*     */       }
/*     */ 
/* 356 */       if (Log.loggingDebug) {
/* 357 */         log.debug("QuadTree.addHelper: adding element " + elem + " to quadnode " + node + " -- maxObjects=" + getMaxObjects());
/*     */       }
/*     */ 
/* 361 */       updateElementInternal(elem, loc, newsAndFrees);
/* 362 */       if (!node.containsElement(elem)) {
/* 363 */         throw new AORuntimeException("QuadTree.addHelper: Failed check");
/*     */       }
/* 365 */       return node;
/*     */     }
/*     */ 
/* 369 */     QuadTreeNode childNode = node.whichChild(loc);
/* 370 */     return addHelper(childNode, elem, loc, newsAndFrees);
/*     */   }
/*     */ 
/*     */   protected boolean removeElementInternal(ElementType elem, QuadTree<ElementType>.NewsAndFrees newsAndFrees) {
/* 374 */     this.lock.lock();
/* 375 */     QuadTreeNode node = elem.getQuadNode();
/*     */     try {
/* 377 */       boolean rv = node.removeElement(elem);
/* 378 */       elem.setQuadNode(null);
/* 379 */       for (Iterator i$ = node.getPerceivers().iterator(); i$.hasNext(); ) { p = (Perceiver)i$.next();
/* 380 */         newsAndFrees.noteFreedElement(p, elem);
/*     */       }
/* 382 */       Perceiver p = elem.getPerceiver();
/* 383 */       if (p != null) {
/* 384 */         updatePerceiverInternal(p, newsAndFrees);
/* 385 */         p = null;
/*     */       }
/* 387 */       this.rootNode.removePerceiverExtentObject(elem);
/* 388 */       Perceiver p = rv;
/*     */       return p; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   protected void updateElementInternal(ElementType elem, Point loc, QuadTree<ElementType>.NewsAndFrees newsAndFrees)
/*     */   {
/* 395 */     this.lock.lock();
/*     */     try {
/* 397 */       if (Log.loggingDebug)
/* 398 */         log.debug("updateElement: elem=" + elem);
/* 399 */       QuadTreeNode node = elem.getQuadNode();
/* 400 */       if ((node != null) && (node.getGeometry().contains(loc))) {
/* 401 */         Perceiver perceiver = elem.getPerceiver();
/* 402 */         if (perceiver != null)
/*     */         {
/* 407 */           if (perceiver.shouldUpdateBasedOnLoc(loc))
/* 408 */             updatePerceiverInternal(perceiver, newsAndFrees);
/*     */         }
/* 410 */         else log.debug("updateElementInternal: has no perceiver");
/*     */         return;
/*     */       }
/*     */ 
/* 415 */       QuadTreeNode newNode = findLeafNode(loc);
/* 416 */       if (node != null)
/*     */       {
/* 420 */         if (!node.removeElement(elem)) {
/* 421 */           throw new RuntimeException("updateElementInternal: could not remove from node");
/*     */         }
/* 423 */         if (Log.loggingDebug) {
/* 424 */           log.debug("QuadTree.updateElementInternal: element moved out of node obj=" + elem.getQuadTreeObject() + " oldNode=" + node + " newNode=" + newNode + ", loc=" + loc);
/*     */         }
/*     */       }
/*     */ 
/* 428 */       newNode.addElement(elem);
/* 429 */       elem.setQuadNode(newNode);
/*     */ 
/* 431 */       updateElementPerceiversInternal(elem, node, newNode, newsAndFrees);
/*     */ 
/* 433 */       Perceiver perceiver = elem.getPerceiver();
/* 434 */       if (perceiver != null)
/*     */       {
/* 436 */         updatePerceiverInternal(perceiver, newsAndFrees);
/*     */       }
/*     */     } finally {
/* 439 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updateElementPerceiversInternal(ElementType elem, QuadTreeNode<ElementType> oldNode, QuadTreeNode<ElementType> newNode, QuadTree<ElementType>.NewsAndFrees newsAndFrees)
/*     */   {
/* 452 */     Set removePerceivers = new HashSet();
/*     */ 
/* 455 */     this.rootNode.removePerceiverExtentObject(elem);
/* 456 */     this.rootNode.addPerceiverExtentObject(elem, elem.getLoc(), elem.getPerceptionRadius());
/*     */ 
/* 458 */     if (Log.loggingDebug) {
/* 459 */       log.debug("updateElementPerceivers: elem=" + elem + " oldNode=" + oldNode + " newNode=" + newNode);
/*     */     }
/*     */ 
/* 462 */     if (oldNode != null) {
/* 463 */       removePerceivers = oldNode.getPerceivers();
/*     */     }
/*     */ 
/* 466 */     Set addPerceivers = newNode.getPerceivers();
/*     */ 
/* 476 */     removePerceivers.removeAll(newNode.getPerceivers());
/* 477 */     if (oldNode != null) {
/* 478 */       addPerceivers.removeAll(oldNode.getPerceivers());
/*     */     }
/* 480 */     if (Log.loggingDebug) {
/* 481 */       log.debug("updateElementPerceivers: remove perceivers size=" + removePerceivers.size() + "add perceivers size=" + addPerceivers.size());
/*     */     }
/*     */ 
/* 486 */     HashSet freed = new HashSet();
/* 487 */     for (Perceiver p : removePerceivers)
/*     */     {
/* 491 */       newsAndFrees.noteFreedElement(p, elem);
/*     */     }
/*     */ 
/* 494 */     HashSet news = new HashSet();
/* 495 */     for (Perceiver p : addPerceivers)
/*     */     {
/* 499 */       newsAndFrees.noteNewElement(p, elem);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updatePerceiverInternal(Perceiver<ElementType> perceiver, QuadTree<ElementType>.NewsAndFrees newsAndFrees)
/*     */   {
/* 512 */     this.lock.lock();
/*     */     try {
/* 514 */       if ((perceiver instanceof MobilePerceiver)) {
/* 515 */         MobilePerceiver p = (MobilePerceiver)perceiver;
/* 516 */         if (Log.loggingDebug)
/* 517 */           log.debug("QuadTree.updatePerceiver: mobile perceiver radius=" + p.getRadius() + " owner=" + p.getElement().getQuadTreeObject());
/*     */       }
/*     */       else
/*     */       {
/* 521 */         FixedPerceiver p = (FixedPerceiver)perceiver;
/* 522 */         if (Log.loggingDebug) {
/* 523 */           log.debug("QuadTree.updatePerceiver: fixed perceiver geom=" + p.getGeometry());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 528 */       Set oldNodes = perceiver.getQuadTreeNodes();
/*     */ 
/* 530 */       Set removeNodes = new HashSet(oldNodes);
/*     */ 
/* 534 */       Set newNodes = new HashSet();
/* 535 */       updatePerceiverHelper(newNodes, this.rootNode, perceiver);
/* 536 */       Set addNodes = new HashSet(newNodes);
/*     */ 
/* 540 */       Set bothPerceiverExtentElements = new HashSet();
/*     */ 
/* 543 */       Set oldPerceiverExtentElements = new HashSet();
/* 544 */       for (QuadTreeNode node : oldNodes) {
/* 545 */         Set perceiverExtentObjects = node.getNodeElements();
/* 546 */         if (perceiverExtentObjects != null)
/*     */         {
/* 548 */           for (QuadTreeElement elem : perceiverExtentObjects)
/*     */           {
/* 550 */             oldPerceiverExtentElements.add(elem);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 557 */       Set newPerceiverExtentElements = new HashSet();
/* 558 */       for (QuadTreeNode node : addNodes) {
/* 559 */         Set perceiverExtentObjects = node.getNodeElements();
/* 560 */         if (perceiverExtentObjects != null) {
/* 561 */           for (QuadTreeElement elem : perceiverExtentObjects)
/*     */           {
/* 563 */             newPerceiverExtentElements.add(elem);
/* 564 */             if (oldPerceiverExtentElements.contains(elem)) {
/* 565 */               bothPerceiverExtentElements.add(elem);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 572 */       removeNodes.removeAll(newNodes);
/*     */ 
/* 576 */       addNodes.removeAll(oldNodes);
/*     */ 
/* 578 */       if (Log.loggingDebug) {
/* 579 */         log.debug("Before removing, newPerceiverExtentElements.size(): " + newPerceiverExtentElements.size() + " oldPerceiverExtentElements.size(): " + oldPerceiverExtentElements.size() + " bothPerceiverExtentElements.size(): " + bothPerceiverExtentElements.size() + " num remove nodes=" + removeNodes.size());
/*     */       }
/*     */ 
/* 588 */       for (QuadTreeNode node : removeNodes) {
/* 589 */         if (Log.loggingDebug)
/* 590 */           log.debug("updatePerceiver: removing from node " + node);
/* 591 */         perceiver.removeQuadTreeNode(node);
/* 592 */         node.removePerceiver(perceiver);
/* 593 */         for (QuadTreeElement elem : node.getNodeElements())
/*     */         {
/* 596 */           if ((!newPerceiverExtentElements.contains(elem)) && (!oldPerceiverExtentElements.contains(elem)))
/*     */           {
/* 598 */             newsAndFrees.noteFreedElement(perceiver, elem);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 605 */       oldPerceiverExtentElements.removeAll(bothPerceiverExtentElements);
/* 606 */       newPerceiverExtentElements.removeAll(bothPerceiverExtentElements);
/* 607 */       if (Log.loggingDebug) {
/* 608 */         log.debug("After removing, newPerceiverExtentElements.size(): " + newPerceiverExtentElements.size() + " oldPerceiverExtentElements.size(): " + oldPerceiverExtentElements.size());
/*     */       }
/*     */ 
/* 613 */       for (QuadTreeElement elem : oldPerceiverExtentElements)
/*     */       {
/* 616 */         newsAndFrees.noteFreedElement(perceiver, elem);
/*     */       }
/* 618 */       if (Log.loggingDebug) {
/* 619 */         log.debug("updatePerceiver: num addnodes=" + addNodes.size());
/*     */       }
/*     */ 
/* 622 */       for (QuadTreeNode node : addNodes) {
/* 623 */         if (Log.loggingDebug)
/* 624 */           log.debug("updatePerceiver: adding to node " + node);
/* 625 */         perceiver.addQuadTreeNode(node);
/* 626 */         node.addPerceiver(perceiver);
/* 627 */         for (QuadTreeElement elem : node.getNodeElements())
/*     */         {
/* 630 */           if ((!newPerceiverExtentElements.contains(elem)) && (!bothPerceiverExtentElements.contains(elem)))
/*     */           {
/* 632 */             newsAndFrees.noteNewElement(perceiver, elem);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 638 */       for (QuadTreeElement elem : newPerceiverExtentElements)
/*     */       {
/* 641 */         newsAndFrees.noteNewElement(perceiver, elem);
/*     */       }
/*     */ 
/* 644 */       log.debug("updatedPerceiver: done updating, printing out list of all nodes");
/* 645 */       if (Log.loggingDebug)
/*     */       {
/* 647 */         for (QuadTreeNode node : perceiver.getQuadTreeNodes()) {
/* 648 */           log.debug("updatePerceiver: IS IN NODE " + node);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 659 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updatePerceiverHelper(Set<QuadTreeNode<ElementType>> nodeSet, QuadTreeNode<ElementType> node, Perceiver<ElementType> perceiver)
/*     */   {
/* 676 */     if (perceiver.overlaps(node.getGeometry()))
/* 677 */       if (!node.isLeaf())
/*     */       {
/* 682 */         for (QuadTreeNode child : node.getChildren()) {
/* 683 */           updatePerceiverHelper(nodeSet, child, perceiver);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 693 */         nodeSet.add(node);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void setLocalGeometryHelper(QuadTreeNode<ElementType> node, Geometry g, QuadTree<ElementType>.NewsAndFrees newsAndFrees)
/*     */   {
/* 701 */     if (!g.overlaps(node.getGeometry())) {
/* 702 */       return;
/*     */     }
/*     */ 
/* 705 */     if (g.contains(node.getGeometry())) {
/* 706 */       node.setNodeType(QuadTreeNode.NodeType.LOCAL);
/*     */     }
/*     */     else {
/* 709 */       if (node.isLeaf()) {
/* 710 */         log.debug("setLocalGeometryHelper: divide");
/* 711 */         node.divide(newsAndFrees);
/*     */       }
/* 713 */       node.setNodeType(QuadTreeNode.NodeType.MIXED);
/*     */     }
/*     */ 
/* 716 */     if (!node.isLeaf())
/* 717 */       for (QuadTreeNode child : node.getChildren())
/* 718 */         setLocalGeometryHelper(child, g, newsAndFrees);
/*     */   }
/*     */ 
/*     */   QuadTreeNode<ElementType> findLeafNode(Point loc)
/*     */   {
/* 731 */     return findLeafNodeHelper(this.rootNode, loc);
/*     */   }
/*     */ 
/*     */   QuadTreeNode<ElementType> findLeafNodeHelper(QuadTreeNode<ElementType> node, Point loc)
/*     */   {
/* 742 */     if (node.isLeaf()) {
/* 743 */       if (node.getGeometry().contains(loc)) {
/* 744 */         return node;
/*     */       }
/* 746 */       return null;
/*     */     }
/*     */ 
/* 749 */     Log.trace("QUAD: checking node: " + node.toString() + " against loc: " + loc + ". is node leaf? " + node.isLeaf());
/*     */ 
/* 751 */     QuadTreeNode childNode = node.getChild(loc);
/* 752 */     if (childNode == null) {
/* 753 */       Log.error("QUAD: got null child for loc: " + loc + "with node: " + node.toString() + " with children: " + node.getChildren());
/* 754 */       return node;
/*     */     }
/* 756 */     return findLeafNodeHelper(childNode, loc);
/*     */   }
/*     */ 
/*     */   public class NewsAndFrees
/*     */   {
/*     */     protected Map<Perceiver<ElementType>, PerceiverNewsAndFrees<ElementType>> perceiverMap;
/*     */ 
/*     */     public NewsAndFrees()
/*     */     {
/* 784 */       this.perceiverMap = new HashMap();
/*     */     }
/*     */ 
/*     */     public Map<Perceiver<ElementType>, PerceiverNewsAndFrees<ElementType>> getMap()
/*     */     {
/* 790 */       return this.perceiverMap;
/*     */     }
/*     */ 
/*     */     public void noteNewElement(Perceiver<ElementType> perceiver, ElementType element)
/*     */     {
/* 798 */       if (perceiver.shouldNotifyNewElement(element)) {
/* 799 */         PerceiverNewsAndFrees newsAndFrees = (PerceiverNewsAndFrees)this.perceiverMap.get(perceiver);
/* 800 */         if (newsAndFrees == null) {
/* 801 */           newsAndFrees = new PerceiverNewsAndFrees();
/* 802 */           this.perceiverMap.put(perceiver, newsAndFrees);
/*     */         }
/* 804 */         newsAndFrees.addNewElement(element);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void noteFreedElement(Perceiver<ElementType> perceiver, ElementType element)
/*     */     {
/* 813 */       if (perceiver.shouldFreeElement(element)) {
/* 814 */         PerceiverNewsAndFrees newsAndFrees = (PerceiverNewsAndFrees)this.perceiverMap.get(perceiver);
/* 815 */         if (newsAndFrees == null) {
/* 816 */           newsAndFrees = new PerceiverNewsAndFrees();
/* 817 */           this.perceiverMap.put(perceiver, newsAndFrees);
/*     */         }
/* 819 */         newsAndFrees.addFreedElement(element);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Integer processNewsAndFrees() {
/* 824 */       processNewsAndFrees(null);
/* 825 */       return null;
/*     */     }
/*     */ 
/*     */     public Integer processNewsAndFrees(OID mobilePerceiverOid)
/*     */     {
/* 833 */       return processBatchedNewsAndFrees(mobilePerceiverOid);
/*     */     }
/*     */ 
/*     */     protected Integer processBatchedNewsAndFrees(OID mobilePerceiverOid)
/*     */     {
/* 842 */       int news = 0;
/* 843 */       int frees = 0;
/* 844 */       Integer perceiverOidCount = null;
/* 845 */       for (PerceiverNewsAndFrees newsAndFrees : this.perceiverMap.values()) {
/* 846 */         news += newsAndFrees.newCount();
/* 847 */         frees += newsAndFrees.freedCount();
/*     */       }
/* 849 */       boolean workToDo = (news > 0) || (frees > 0);
/* 850 */       if ((Log.loggingDebug) && (workToDo)) {
/* 851 */         Log.debug("QuadTree.NewsAndFrees.processBatchedNewsAndFrees: starting to process " + frees + " frees, " + news + " news");
/*     */       }
/*     */ 
/* 854 */       if (workToDo) {
/* 855 */         for (Map.Entry entry : this.perceiverMap.entrySet()) {
/* 856 */           Perceiver perceiver = (Perceiver)entry.getKey();
/* 857 */           PerceiverNewsAndFrees newsAndFrees = (PerceiverNewsAndFrees)entry.getValue();
/* 858 */           Integer count = perceiver.processNewsAndFrees(newsAndFrees, mobilePerceiverOid);
/* 859 */           if (count != null) {
/* 860 */             perceiverOidCount = count;
/*     */           }
/*     */         }
/*     */       }
/* 864 */       if ((Log.loggingDebug) && (
/* 865 */         (frees > 0) || (news > 0))) {
/* 866 */         Log.debug("QuadTree.NewsAndFrees.processBatchedNewsAndFrees: finished processing " + frees + " frees, " + news + " news");
/*     */       }
/*     */ 
/* 869 */       return perceiverOidCount;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.QuadTree
 * JD-Core Version:    0.6.0
 */