/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.msgsys.GenericResponseMessage;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageCallback;
/*     */ import atavism.msgsys.ResponseCallback;
/*     */ import atavism.msgsys.ResponseMessage;
/*     */ import atavism.server.messages.SearchMessage;
/*     */ import atavism.server.messages.SearchMessageFilter;
/*     */ import atavism.server.objects.ObjectType;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class SearchManager
/*     */ {
/* 189 */   static Map<MatcherKey, MatcherFactory> matchers = new HashMap();
/*     */ 
/*     */   public static Collection searchObjects(ObjectType objectType, SearchClause searchClause, SearchSelection selection)
/*     */   {
/*  51 */     SearchMessage message = new SearchMessage(objectType, searchClause, selection);
/*     */ 
/*  54 */     Collector collector = new Collector(message);
/*  55 */     return collector.getResults();
/*     */   }
/*     */ 
/*     */   public static void registerSearchable(ObjectType objectType, Searchable searchable)
/*     */   {
/* 106 */     SearchMessageFilter filter = new SearchMessageFilter(objectType);
/* 107 */     Engine.getAgent().createSubscription(filter, new SearchMessageCallback(searchable), 8);
/*     */   }
/*     */ 
/*     */   public static void registerMatcher(Class searchClauseClass, Class instanceClass, MatcherFactory matcherFactory)
/*     */   {
/* 122 */     matchers.put(new MatcherKey(searchClauseClass, instanceClass), matcherFactory);
/*     */   }
/*     */ 
/*     */   public static Matcher getMatcher(SearchClause searchClause, Class instanceClass)
/*     */   {
/* 135 */     MatcherFactory matcherFactory = (MatcherFactory)matchers.get(new MatcherKey(searchClause.getClass(), instanceClass));
/*     */ 
/* 137 */     if (matcherFactory == null) {
/* 138 */       Log.error("runSearch: No matcher for " + searchClause.getClass() + " " + instanceClass);
/* 139 */       return null;
/*     */     }
/* 141 */     return matcherFactory.createMatcher(searchClause);
/*     */   }
/*     */ 
/*     */   static class SearchMessageCallback
/*     */     implements MessageCallback
/*     */   {
/*     */     Searchable searchable;
/*     */ 
/*     */     public SearchMessageCallback(Searchable searchable)
/*     */     {
/* 167 */       this.searchable = searchable;
/*     */     }
/*     */ 
/*     */     public void handleMessage(Message msg, int flags)
/*     */     {
/* 172 */       SearchMessage message = (SearchMessage)msg;
/*     */ 
/* 174 */       Collection result = null;
/*     */       try {
/* 176 */         result = this.searchable.runSearch(message.getSearchClause(), message.getSearchSelection());
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 180 */         Log.exception("runSearch failed", e);
/*     */       }
/*     */ 
/* 183 */       Engine.getAgent().sendObjectResponse(message, result);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class MatcherKey
/*     */   {
/*     */     public Class queryType;
/*     */     public Class instanceType;
/*     */ 
/*     */     public MatcherKey(Class qt, Class it)
/*     */     {
/* 147 */       this.queryType = qt;
/* 148 */       this.instanceType = it;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object key)
/*     */     {
/* 154 */       return (((MatcherKey)key).queryType == this.queryType) && (((MatcherKey)key).instanceType == this.instanceType);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 159 */       return this.queryType.hashCode() + this.instanceType.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class Collector
/*     */     implements ResponseCallback
/*     */   {
/*  94 */     Collection results = new LinkedList();
/*     */     SearchMessage searchMessage;
/*  96 */     int responders = 0;
/*     */ 
/*     */     public Collector(SearchMessage message)
/*     */     {
/*  62 */       this.searchMessage = message;
/*     */     }
/*     */ 
/*     */     public Collection getResults()
/*     */     {
/*  67 */       int expectedResponses = Engine.getAgent().sendBroadcastRPC(this.searchMessage, this);
/*  68 */       synchronized (this) {
/*  69 */         this.responders += expectedResponses;
/*  70 */         while (this.responders != 0)
/*     */           try {
/*  72 */             wait();
/*     */           }
/*     */           catch (InterruptedException e) {
/*     */           }
/*     */       }
/*  77 */       return this.results;
/*     */     }
/*     */ 
/*     */     public synchronized void handleResponse(ResponseMessage rr)
/*     */     {
/*  82 */       this.responders -= 1;
/*     */ 
/*  84 */       GenericResponseMessage response = (GenericResponseMessage)rr;
/*     */ 
/*  86 */       Collection list = (Collection)response.getData();
/*  87 */       if (list != null) {
/*  88 */         this.results.addAll(list);
/*     */       }
/*  90 */       if (this.responders == 0)
/*  91 */         notify();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.SearchManager
 * JD-Core Version:    0.6.0
 */