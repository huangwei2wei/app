/*      */ package atavism.server.engine;
/*      */ 
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import java.io.PrintStream;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.SecureRandom;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ public class MasterDatabase
/*      */ {
/* 1055 */   private Connection conn = null;
/* 1056 */   private final String localAccountTable = "account";
/* 1057 */   private final String remoteAccountTable = "jos_users";
/* 1058 */   private final String idField = "id";
/*      */ 
/* 1060 */   transient Lock dbLock = LockFactory.makeLock("masterDBLock");
/*      */ 
/*      */   public MasterDatabase()
/*      */   {
/*      */     try
/*      */     {
/*   27 */       Class.forName("com.mysql.jdbc.Driver").newInstance();
/*      */     } catch (Exception e) {
/*   29 */       throw new AORuntimeException("could not find class: " + e);
/*      */     }
/*      */ 
/*   33 */     Log.debug("Database: starting keepalive");
/*   34 */     Thread keepAliveThread = new Thread(new KeepAlive(), "DBKeepalive");
/*   35 */     keepAliveThread.start();
/*      */   }
/*      */ 
/*      */   public MasterDatabase(String sDriver)
/*      */   {
/*   46 */     if (Log.loggingDebug) {
/*   47 */       Log.debug("Initializing Database with driver " + sDriver);
/*   48 */       Log.debug("classpath = " + System.getProperty("java.class.path"));
/*      */     }
/*      */     try {
/*   51 */       Class.forName(sDriver).newInstance();
/*   52 */       if (Log.loggingDebug)
/*   53 */         Log.debug(sDriver + " driver loaded");
/*      */     } catch (Exception e) {
/*   55 */       throw new AORuntimeException("could not find class: " + sDriver);
/*      */     }
/*      */ 
/*   59 */     Log.debug("Database: starting keepalive");
/*   60 */     Thread keepAliveThread = new Thread(new KeepAlive(), "DBKeepalive");
/*   61 */     keepAliveThread.start();
/*      */   }
/*      */ 
/*      */   public void connect(String url, String username, String password)
/*      */   {
/*      */     try
/*      */     {
/*   99 */       this.dbLock.lock();
/*      */ 
/*  101 */       if (Log.loggingDebug)
/*  102 */         Log.debug("*** url = " + url + " username = " + username + " password = " + password);
/*      */       try {
/*  104 */         this.conn = DriverManager.getConnection(url, username, password);
/*      */       } catch (Exception e) {
/*  106 */         throw new AORuntimeException("could not connect to database: " + e);
/*      */       }
/*      */     } finally {
/*  109 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void executeUpdate(String update)
/*      */   {
/*  119 */     Statement stmt = null;
/*      */     try {
/*  121 */       this.dbLock.lock();
/*      */       try {
/*  123 */         stmt = this.conn.createStatement();
/*  124 */         stmt.executeUpdate(update);
/*      */       } catch (Exception e) {
/*  126 */         Log.exception("Database.executeUpdate: Running update " + update, e);
/*      */       }
/*      */     } finally {
/*  129 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void executeBatch(List<String> statements)
/*      */   {
/*  138 */     Statement stmt = null;
/*      */     try {
/*  140 */       this.dbLock.lock();
/*      */       try {
/*  142 */         stmt = this.conn.createStatement();
/*  143 */         for (String statement : statements)
/*  144 */           stmt.addBatch(statement);
/*  145 */         stmt.executeBatch();
/*      */       } catch (Exception e) {
/*  147 */         Log.exception("Database.executeBatch: Running statements " + statements, e);
/*      */       }
/*      */     } finally {
/*  150 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean databaseTableContainsColumn(String dbName, String tableName, String columnName)
/*      */   {
/*  165 */     Statement stmt = null;
/*  166 */     ResultSet rs = null;
/*      */     try {
/*  168 */       this.dbLock.lock();
/*      */       try {
/*  170 */         stmt = this.conn.createStatement();
/*  171 */         String query = "SHOW COLUMNS FROM " + dbName + "." + tableName + " LIKE '" + columnName + "'";
/*  172 */         if (Log.loggingDebug)
/*  173 */           Log.debug("Database.databaseTableContainsColumn query: " + query);
/*  174 */         rs = stmt.executeQuery(query);
/*  175 */         if (!rs.next()) {
/*  176 */           i = 0;
/*      */ 
/*  185 */           this.dbLock.unlock(); return i;
/*      */         }
/*  178 */         int i = 1;
/*      */ 
/*  185 */         this.dbLock.unlock(); return i;
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  181 */         throw new AORuntimeException("Could not run select statement to determine the presence of the '" + columnName + "' in table '" + tableName + "': " + e);
/*      */       }
/*      */     }
/*      */     finally {
/*  185 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean databaseContainsTable(String dbName, String tableName)
/*      */   {
/*  200 */     Statement stmt = null;
/*  201 */     ResultSet rs = null;
/*      */     try {
/*  203 */       this.dbLock.lock();
/*      */       try {
/*  205 */         stmt = this.conn.createStatement();
/*  206 */         String query = "SELECT count(*) FROM information_schema.tables WHERE table_schema = '" + dbName + "' AND table_name = '" + tableName + "'";
/*      */ 
/*  208 */         rs = stmt.executeQuery(query);
/*  209 */         if (!rs.next()) {
/*  210 */           int i = 0;
/*      */ 
/*  219 */           this.dbLock.unlock(); return i;
/*      */         }
/*  212 */         int count = rs.getInt(1);
/*  213 */         int j = count == 1 ? 1 : 0;
/*      */ 
/*  219 */         this.dbLock.unlock(); return j;
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  216 */         throw new AORuntimeException("Exception running select statement to find table " + tableName + ": " + e);
/*      */       }
/*      */     } finally {
/*  219 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*      */     try
/*      */     {
/*  228 */       this.dbLock.lock();
/*  229 */       if (this.conn != null) {
/*  230 */         this.conn.close();
/*  231 */         this.conn = null;
/*      */       }
/*      */     } catch (Exception e) {
/*  234 */       Log.error("MasterDatabase.close: unable to close connection");
/*      */     } finally {
/*  236 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void printDevelopers()
/*      */   {
/*  246 */     Statement stmt = null;
/*  247 */     ResultSet rs = null;
/*      */     try {
/*  249 */       this.dbLock.lock();
/*  250 */       stmt = this.conn.createStatement();
/*  251 */       String query = "SELECT * FROM developer";
/*  252 */       rs = stmt.executeQuery(query);
/*      */ 
/*  255 */       while (rs.next()) {
/*  256 */         int devId = rs.getInt("dev_id");
/*  257 */         String email = rs.getString("email");
/*  258 */         String company = rs.getString("company");
/*  259 */         String skill = rs.getString("skill");
/*  260 */         String prior = rs.getString("prior");
/*  261 */         String genre = rs.getString("genre");
/*  262 */         String idea = rs.getString("idea");
/*  263 */         System.out.println("devId=" + devId + "\nemail=" + email + "\ncompany=" + company + "\nskill=" + skill + "\nprior=" + prior + "\ngenre=" + genre + "\nidea=" + idea);
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  269 */       Log.exception("printDevelopers", e);
/*  270 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  272 */       if (rs != null) {
/*      */         try {
/*  274 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  276 */           rs = null;
/*      */         }
/*  278 */         if (stmt != null) {
/*      */           try {
/*  280 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  282 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  286 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int AOAcctPasswdCheck(String username, String password)
/*      */   {
/*  298 */     Statement stmt = null;
/*  299 */     ResultSet rs = null;
/*      */     try {
/*  301 */       this.dbLock.lock();
/*  302 */       stmt = this.conn.createStatement();
/*      */ 
/*  305 */       String query = "SELECT id, password FROM account WHERE username = '" + username + "'";
/*      */ 
/*  307 */       rs = stmt.executeQuery(query);
/*      */ 
/*  310 */       if (!rs.next()) {
/*  311 */         int i = -1;
/*      */         return i;
/*      */       }
/*  313 */       String realPassword = rs.getString(2);
/*  314 */       if (!realPassword.equals(password)) {
/*  315 */         sqlEx = -1;
/*      */         return sqlEx;
/*      */       }
/*  317 */       int uid = rs.getInt(1);
/*  318 */       if (Log.loggingDebug)
/*  319 */         Log.debug("username=" + username + ", uid=" + uid);
/*  320 */       sqlEx = uid;
/*      */       return sqlEx;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  322 */       Log.exception("AOAcctPasswdCheck", e);
/*  323 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  325 */       if (rs != null) {
/*      */         try {
/*  327 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  329 */           rs = null;
/*      */         }
/*  331 */         if (stmt != null) {
/*      */           try {
/*  333 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  335 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  339 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public WorldInfo resolveWorldID(String worldName)
/*      */   {
/*  376 */     Statement stmt = null;
/*  377 */     ResultSet rs = null;
/*      */     try {
/*  379 */       this.dbLock.lock();
/*  380 */       stmt = this.conn.createStatement();
/*  381 */       String query = "SELECT server_name, server_port, patcher_URL, media_URL FROM world WHERE world_name = '" + worldName + "'";
/*      */ 
/*  383 */       rs = stmt.executeQuery(query);
/*      */ 
/*  386 */       if (!rs.next()) {
/*  387 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/*  390 */       String hostname = rs.getString(1);
/*  391 */       int port = rs.getInt(2);
/*  392 */       String patcherURL = rs.getString(3);
/*  393 */       String mediaURL = rs.getString(4);
/*      */ 
/*  395 */       WorldInfo worldInfo = new WorldInfo(worldName, hostname, port, patcherURL, mediaURL);
/*  396 */       WorldInfo localWorldInfo1 = worldInfo;
/*      */       return localWorldInfo1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  398 */       Log.exception("resolveWorldID", e);
/*  399 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  401 */       if (rs != null) {
/*      */         try {
/*  403 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  405 */           rs = null;
/*      */         }
/*  407 */         if (stmt != null) {
/*      */           try {
/*  409 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  411 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  415 */       this.dbLock.unlock(); } throw localObject2;
/*      */   }
/*      */ 
/*      */   public String getPassword(String username)
/*      */   {
/*  420 */     Statement stmt = null;
/*  421 */     ResultSet rs = null;
/*      */     try {
/*  423 */       this.dbLock.lock();
/*  424 */       stmt = this.conn.createStatement();
/*  425 */       String query = "SELECT id, password FROM account WHERE username = '" + username + "'";
/*      */ 
/*  427 */       rs = stmt.executeQuery(query);
/*      */ 
/*  430 */       if (!rs.next()) {
/*  431 */         str1 = null;
/*      */         return str1;
/*      */       }
/*  433 */       String str1 = rs.getString(2);
/*      */       return str1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  435 */       Log.exception("getPassword", e);
/*  436 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  438 */       if (rs != null) {
/*      */         try {
/*  440 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  442 */           rs = null;
/*      */         }
/*  444 */         if (stmt != null) {
/*      */           try {
/*  446 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  448 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  452 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public Integer getAccountId(String username)
/*      */   {
/*  457 */     Statement stmt = null;
/*  458 */     ResultSet rs = null;
/*      */     try {
/*  460 */       this.dbLock.lock();
/*  461 */       stmt = this.conn.createStatement();
/*  462 */       String query = "SELECT id FROM account WHERE username = '" + username + "'";
/*      */ 
/*  464 */       rs = stmt.executeQuery(query);
/*      */ 
/*  467 */       if (!rs.next()) {
/*  468 */         localInteger = null;
/*      */         return localInteger;
/*      */       }
/*  470 */       Integer localInteger = Integer.valueOf(rs.getInt(1));
/*      */       return localInteger;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  472 */       Log.exception("getAccountId", e);
/*  473 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  475 */       if (rs != null) {
/*      */         try {
/*  477 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  479 */           rs = null;
/*      */         }
/*  481 */         if (stmt != null) {
/*      */           try {
/*  483 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  485 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  489 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public OID passwordCheck(String username, String password)
/*      */   {
/*  501 */     Statement stmt = null;
/*  502 */     ResultSet rs = null;
/*      */     try {
/*  504 */       this.dbLock.lock();
/*  505 */       stmt = this.conn.createStatement();
/*  506 */       String query = "SELECT id, password FROM account WHERE username = '" + username + "' OR email = '" + "'";
/*      */ 
/*  508 */       rs = stmt.executeQuery(query);
/*      */ 
/*  511 */       if (!rs.next()) {
/*  512 */         Log.debug("AUTH: no account found, check remote server? " + MasterServer.remoteDatabaseEnabled());
/*  513 */         if (MasterServer.remoteDatabaseEnabled())
/*  514 */           rs = checkRemoteServer(username, true);
/*  515 */         if (rs == null) {
/*  516 */           Object localObject1 = null;
/*      */           return localObject1;
/*      */         }
/*      */       }
/*  518 */       String realPassword = rs.getString(2);
/*  519 */       Log.debug("COMPARE: comparing local password: " + realPassword + " with password: " + password);
/*  520 */       boolean passwordsMatch = comparePasswords(password, realPassword);
/*      */       Object localObject2;
/*  521 */       if ((!passwordsMatch) && (MasterServer.remoteDatabaseEnabled())) {
/*  522 */         checkRemoteServer(username, false);
/*  523 */         rs = stmt.executeQuery(query);
/*  524 */         if (!rs.next()) {
/*  525 */           localObject2 = null;
/*      */           return localObject2;
/*      */         }
/*  527 */         realPassword = rs.getString("password");
/*  528 */         Log.debug("COMPARE: comparing remote password: " + realPassword + " with password: " + password);
/*  529 */         passwordsMatch = comparePasswords(password, realPassword);
/*  530 */         if (!passwordsMatch) {
/*  531 */           localObject2 = null;
/*      */           return localObject2;
/*      */         }
/*      */       }
/*  532 */       else if (!passwordsMatch) {
/*  533 */         Log.debug("COMPARE: passwords do not match");
/*  534 */         localObject2 = null;
/*      */         return localObject2;
/*      */       }
/*  536 */       long uidLong = rs.getInt(1);
/*  537 */       if (Log.loggingDebug)
/*  538 */         Log.debug("username=" + username + ", uid=" + uidLong);
/*  539 */       OID localOID = OID.fromLong(uidLong);
/*      */       return localOID;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  541 */       Log.exception("passwordCheck", e);
/*  542 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  544 */       if (rs != null) {
/*      */         try {
/*  546 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  548 */           rs = null;
/*      */         }
/*  550 */         if (stmt != null) {
/*      */           try {
/*  552 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  554 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  558 */       this.dbLock.unlock(); } throw localObject3;
/*      */   }
/*      */ 
/*      */   private boolean comparePasswords(String password, String realPassword)
/*      */   {
/*      */     try {
/*  564 */       boolean saltedPassword = MasterServer.useSaltedMd5Passwords();
/*  565 */       if (saltedPassword) {
/*  566 */         if (!realPassword.contains(":"))
/*      */         {
/*  568 */           MessageDigest md = MessageDigest.getInstance("MD5");
/*  569 */           byte[] array = md.digest(password.getBytes());
/*  570 */           StringBuffer sb = new StringBuffer();
/*  571 */           for (int i = 0; i < array.length; i++) {
/*  572 */             sb.append(Integer.toHexString(array[i] & 0xFF | 0x100).substring(1, 3));
/*      */           }
/*      */ 
/*  575 */           return sb.toString().equals(realPassword);
/*      */         }
/*      */ 
/*  580 */         Log.debug("AUTH: using salted passwords");
/*  581 */         String[] passwordPieces = realPassword.split(":");
/*  582 */         MessageDigest md = MessageDigest.getInstance("MD5");
/*  583 */         String salted = password + passwordPieces[1];
/*  584 */         md.reset();
/*  585 */         md.update(salted.getBytes());
/*  586 */         byte[] digest = md.digest();
/*      */ 
/*  588 */         StringBuffer hexString = new StringBuffer();
/*  589 */         for (int i = 0; i < digest.length; i++) {
/*  590 */           String hex = Integer.toHexString(0xFF & digest[i]);
/*  591 */           if (hex.length() == 1)
/*  592 */             hexString.append('0');
/*  593 */           hexString.append(hex);
/*      */         }
/*  595 */         String hash = hexString.toString();
/*  596 */         String md5 = passwordPieces[0];
/*  597 */         Log.debug("Password Check: " + password + " against real password: " + realPassword);
/*  598 */         Log.debug("Password Check: " + password + " has hash: [" + hash + "] and md5: [" + md5 + "]");
/*  599 */         if (!hash.equals(md5)) {
/*  600 */           Log.debug("hash does not equal md5");
/*  601 */           return false;
/*      */         }
/*      */       } else {
/*  604 */         Log.debug("COMPARE: checking not salted password");
/*  605 */         if (!password.equals(realPassword))
/*  606 */           return false;
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  610 */       Log.exception("comparePasswords", e);
/*  611 */       throw new AORuntimeException("database: ", e);
/*      */     }
/*  613 */     return true;
/*      */   }
/*      */ 
/*      */   public int createAccount(String username, String password, String emailAddress)
/*      */   {
/*  624 */     Statement stmt = null;
/*  625 */     ResultSet rs = null;
/*      */     try {
/*  627 */       this.dbLock.lock();
/*  628 */       stmt = this.conn.createStatement();
/*  629 */       String query = "SELECT id, password FROM account WHERE username = '" + username + "'";
/*      */ 
/*  631 */       rs = stmt.executeQuery(query);
/*      */       int i;
/*  634 */       if (rs.next()) {
/*  635 */         Log.debug("Create Account Failed: username already used");
/*  636 */         i = 6;
/*      */         return i;
/*      */       }
/*  639 */       query = "SELECT id, password FROM account WHERE email = '" + emailAddress + "'";
/*      */ 
/*  641 */       rs = stmt.executeQuery(query);
/*      */ 
/*  644 */       if (rs.next()) {
/*  645 */         Log.debug("Create Account Failed: email address already used");
/*  646 */         i = 7;
/*      */         return i;
/*      */       }
/*  650 */       if (MasterServer.useSaltedMd5Passwords()) {
/*  651 */         password = generateSaltedPassword(password);
/*  652 */         Log.debug("AUTH: created salted password: " + password);
/*      */       }
/*      */ 
/*  655 */       stmt = this.conn.createStatement();
/*  656 */       String update = "INSERT INTO account (username, password, email, status, created_at) VALUES ( \"" + username + "\", \"" + password + "\", \"" + emailAddress + "\", " + 1 + ", NOW())";
/*      */ 
/*  658 */       int rows = stmt.executeUpdate(update);
/*  659 */       if (rows >= 1) {
/*  660 */         j = 1;
/*      */         return j;
/*      */       }
/*  661 */       Log.debug("Unknown error when creating account");
/*  662 */       int j = 8;
/*      */       return j;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  664 */       Log.exception("createAccount", e);
/*  665 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  667 */       if (rs != null) {
/*      */         try {
/*  669 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  671 */           rs = null;
/*      */         }
/*  673 */         if (stmt != null) {
/*      */           try {
/*  675 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  677 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  681 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static String generateSaltedPassword(String passwd)
/*      */   {
/*  686 */     StringBuffer saltBuf = new StringBuffer();
/*  687 */     SecureRandom rnd = new SecureRandom();
/*      */ 
/*  689 */     for (int i = 0; i < 32; i++) {
/*  690 */       saltBuf.append(Integer.toString(rnd.nextInt(36), 36));
/*      */     }
/*  692 */     String salt = saltBuf.toString();
/*  693 */     Log.debug("AUTH: generated salt: " + salt);
/*  694 */     return md5(new StringBuilder().append(passwd).append(salt).toString()) + ":" + salt;
/*      */   }
/*      */ 
/*      */   private static String md5(String data)
/*      */   {
/*  708 */     byte[] bdata = new byte[data.length()];
/*      */ 
/*  710 */     for (int i = 0; i < data.length(); i++) bdata[i] = (byte)(data.charAt(i) & 0xFF); byte[] hash;
/*      */     try {
/*  713 */       MessageDigest md5er = MessageDigest.getInstance("MD5");
/*  714 */       hash = md5er.digest(bdata); } catch (GeneralSecurityException e) {
/*  715 */       throw new RuntimeException(e);
/*      */     }
/*  717 */     StringBuffer r = new StringBuffer(32);
/*  718 */     for (i = 0; i < hash.length; i++) {
/*  719 */       String x = Integer.toHexString(hash[i] & 0xFF);
/*  720 */       if (x.length() < 2) r.append("0");
/*  721 */       r.append(x);
/*      */     }
/*  723 */     return r.toString();
/*      */   }
/*      */ 
/*      */   private ResultSet checkRemoteServer(String username, boolean createUser)
/*      */   {
/*  734 */     Log.debug("Checking remote server for account details.");
/*  735 */     Statement stmt = null;
/*  736 */     ResultSet rs = null;
/*      */     try {
/*  738 */       this.dbLock.lock();
/*  739 */       Connection tempConn = DriverManager.getConnection(MasterServer.getRemoteDBUrl(), MasterServer.getRemoteDBUser(), MasterServer.getRemoteDBPassword());
/*      */ 
/*  741 */       stmt = tempConn.createStatement();
/*  742 */       String query = "SELECT * FROM jos_users WHERE username = '" + username + "' OR email = '" + username + "'";
/*      */ 
/*  744 */       rs = stmt.executeQuery(query);
/*      */ 
/*  747 */       if (!rs.next()) {
/*  748 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/*  750 */       String realPassword = rs.getString("password");
/*  751 */       String email = rs.getString("email");
/*      */ 
/*  753 */       int status = 1;
/*      */       boolean userCreated;
/*  754 */       if (createUser) {
/*  755 */         userCreated = createUser(username, realPassword, email, status);
/*  756 */         if (userCreated) {
/*  757 */           ResultSet localResultSet1 = rs;
/*      */           return localResultSet1;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  760 */         updateUser(username, realPassword, status);
/*  761 */         userCreated = null;
/*      */         return userCreated;
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  764 */       Log.exception("checkRemoteServer", e);
/*  765 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  767 */       if (rs != null) {
/*      */         try {
/*  769 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  771 */           rs = null;
/*      */         }
/*  773 */         if (stmt != null) {
/*      */           try {
/*  775 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  777 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  781 */       this.dbLock.unlock();
/*      */     }
/*  783 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean createUser(String username, String password, String email, int status)
/*      */   {
/*  795 */     Statement stmt = null;
/*      */     try {
/*  797 */       this.dbLock.lock();
/*  798 */       stmt = this.conn.createStatement();
/*  799 */       String update = "INSERT INTO account (username, password, email, status, created_at) VALUES ( \"" + username + "\", \"" + password + "\", \"" + email + "\", " + status + ", NOW())";
/*      */ 
/*  801 */       rows = stmt.executeUpdate(update);
/*  802 */       int i = rows >= 1 ? 1 : 0;
/*      */       return i;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  804 */       Log.exception("createUser", e);
/*  805 */       Log.error("database error: " + e);
/*  806 */       int rows = 0;
/*      */       return rows;
/*      */     }
/*      */     finally
/*      */     {
/*  808 */       if (stmt != null) {
/*      */         try {
/*  810 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  812 */           stmt = null;
/*      */         }
/*      */       }
/*  815 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void updateUser(String username, String password, int status)
/*      */   {
/*  828 */     Statement stmt = null;
/*      */     try {
/*  830 */       this.dbLock.lock();
/*  831 */       stmt = this.conn.createStatement();
/*  832 */       String update = "UPDATE account set password = \"" + password + "\", status = " + status + " where username = \"" + username + "\"";
/*      */ 
/*  834 */       rows = stmt.executeUpdate(update); } catch (Exception e) { int rows;
/*  836 */       Log.exception("createUser", e);
/*  837 */       Log.error("database error: " + e);
/*      */       return; } finally { if (stmt != null) {
/*      */         try {
/*  842 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  844 */           stmt = null;
/*      */         }
/*      */       }
/*  847 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int statusCheck(String username)
/*      */   {
/*  859 */     Statement stmt = null;
/*  860 */     ResultSet rs = null;
/*      */     try {
/*  862 */       this.dbLock.lock();
/*  863 */       stmt = this.conn.createStatement();
/*  864 */       String query = "SELECT status FROM account WHERE username = '" + username + "'";
/*      */ 
/*  866 */       rs = stmt.executeQuery(query);
/*      */ 
/*  869 */       if (!rs.next()) {
/*  870 */         int i = 0;
/*      */         return i;
/*      */       }
/*  872 */       int status = rs.getInt("status");
/*      */ 
/*  878 */       sqlEx = status;
/*      */       return sqlEx;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  880 */       Log.exception("statusCheck", e);
/*  881 */       throw new AORuntimeException("database: ", e);
/*      */     } finally {
/*  883 */       if (rs != null) {
/*      */         try {
/*  885 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  887 */           rs = null;
/*      */         }
/*  889 */         if (stmt != null) {
/*      */           try {
/*  891 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  893 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  897 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public String getUserName(long uid)
/*      */   {
/*  909 */     Statement stmt = null;
/*  910 */     ResultSet rs = null;
/*      */     try {
/*  912 */       this.dbLock.lock();
/*  913 */       stmt = this.conn.createStatement();
/*  914 */       String query = "SELECT username FROM account WHERE id = " + uid;
/*  915 */       rs = stmt.executeQuery(query);
/*      */ 
/*  918 */       if (!rs.next()) {
/*  919 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/*  921 */       name = rs.getString(1);
/*  922 */       if (Log.loggingDebug)
/*  923 */         Log.debug("uid:" + uid + "=" + name);
/*  924 */       sqlEx = name;
/*      */       return sqlEx;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  926 */       Log.warn("Database.getUserName: unable to get username, this is ok if you are not on production server: " + e);
/*  927 */       String name = null;
/*      */       return name;
/*      */     }
/*      */     finally
/*      */     {
/*  929 */       if (rs != null) {
/*      */         try {
/*  931 */           rs.close();
/*      */         } catch (SQLException sqlEx) {
/*  933 */           rs = null;
/*      */         }
/*  935 */         if (stmt != null) {
/*      */           try {
/*  937 */             stmt.close();
/*      */           } catch (SQLException sqlEx) {
/*  939 */             stmt = null;
/*      */           }
/*      */         }
/*      */       }
/*  943 */       this.dbLock.unlock(); } throw localObject2;
/*      */   }
/*      */ 
/*      */   public void ping()
/*      */   {
/*  952 */     Log.debug("Database: ping");
/*  953 */     Statement stmt = null;
/*  954 */     this.dbLock.lock();
/*      */     try {
/*  956 */       String sql = "SELECT 1 from player_character";
/*  957 */       stmt = this.conn.createStatement();
/*  958 */       stmt.executeQuery(sql);
/*      */     } catch (Exception sqlEx) {
/*  960 */       reconnect();
/*      */     } finally {
/*  962 */       if (stmt != null) {
/*      */         try {
/*  964 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/*  966 */           stmt = null;
/*      */         }
/*      */       }
/*  969 */       this.dbLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   void reconnect()
/*      */   {
/*  979 */     Log.error("Database reconnect: url=" + MasterServer.getDBUrl());
/*  980 */     close();
/*      */ 
/*  982 */     int failCount = 0;
/*  983 */     this.dbLock.lock();
/*      */     try {
/*  987 */       this.conn = DriverManager.getConnection(MasterServer.getDBUrl(), MasterServer.getDBUser(), MasterServer.getDBPassword());
/*      */ 
/*  989 */       Log.info("Database: reconnected to " + MasterServer.getDBUrl());
/*      */       return; } catch (Exception e) {
/*      */       while (true) try {
/*  993 */           if (failCount == 0)
/*  994 */             Log.exception("Database reconnect failed, retrying", e);
/*  995 */           else if (failCount % 300 == 299)
/*  996 */             Log.error("Database reconnect failed, retrying: " + e);
/*  997 */           failCount++;
/*  998 */           Thread.sleep(1000L);
/*      */         }
/*      */         catch (InterruptedException ie)
/*      */         {
/*      */         } 
/*      */     }
/*      */     finally
/*      */     {
/* 1005 */       this.dbLock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/*      */     try
/*      */     {
/* 1016 */       if (args.length != 3) {
/* 1017 */         System.err.println("creates <count> users named <username>0 <username>1 ... <username><count-1> all with same password");
/*      */ 
/* 1019 */         System.err.println("java Database <username> <password> <count> <namespace>");
/*      */ 
/* 1021 */         System.exit(1);
/*      */       }
/* 1023 */       String username = args[0];
/* 1024 */       String password = args[1];
/*      */ 
/* 1026 */       int count = Integer.valueOf(args[2]).intValue();
/*      */ 
/* 1030 */       MasterDatabase db = new MasterDatabase(Engine.getDBDriver());
/* 1031 */       db.connect(Engine.getDBUrl(), Engine.getDBUser(), Engine.getDBPassword());
/*      */ 
/* 1034 */       for (int i = 0; i < count; i++) {
/* 1035 */         String uname = username + i;
/*      */ 
/* 1042 */         OID oid = db.passwordCheck(uname, password);
/* 1043 */         if (oid == null)
/* 1044 */           System.out.println("password check failed in database");
/*      */         else
/* 1046 */           System.out.println("password check passed, oid=" + oid);
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1051 */       Log.error("Database: " + e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class WorldInfo
/*      */   {
/*  356 */     public String worldName = null;
/*      */ 
/*  358 */     public String svrHostName = null;
/*      */ 
/*  360 */     public int port = -1;
/*      */ 
/*  362 */     public String patcherURL = null;
/*      */ 
/*  364 */     public String mediaURL = null;
/*      */ 
/*      */     WorldInfo(String worldName, String svrHostName, int port, String patcherURL, String mediaURL)
/*      */     {
/*  349 */       this.worldName = worldName;
/*  350 */       this.svrHostName = svrHostName;
/*  351 */       this.port = port;
/*  352 */       this.patcherURL = patcherURL;
/*  353 */       this.mediaURL = mediaURL;
/*      */     }
/*      */   }
/*      */ 
/*      */   class KeepAlive
/*      */     implements Runnable
/*      */   {
/*      */     KeepAlive()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */       {
/*      */         try
/*      */         {
/*   75 */           Thread.sleep(60000L);
/*      */         } catch (InterruptedException e) {
/*   77 */           Log.exception("Database.KeepAlive: interrupted", e);
/*      */         }
/*      */         try {
/*   80 */           if (MasterDatabase.this.conn != null)
/*   81 */             MasterDatabase.this.ping();
/*      */         }
/*      */         catch (AORuntimeException e) {
/*   84 */           Log.exception("Database.KeepAlive: ping caught exception", e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.MasterDatabase
 * JD-Core Version:    0.6.0
 */