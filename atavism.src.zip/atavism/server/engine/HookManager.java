/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class HookManager
/*     */ {
/*  99 */   private LinkedList<Hook> nullList = new LinkedList();
/* 100 */   private Lock lock = LockFactory.makeLock("HookManager");
/* 101 */   private Map<MessageType, List<Hook>> hooks = new HashMap();
/*     */ 
/*     */   public void addHook(MessageType msgType, Hook hook)
/*     */   {
/*  43 */     this.lock.lock();
/*     */     try {
/*  45 */       List hookList = (List)this.hooks.get(msgType);
/*  46 */       if (hookList == null) {
/*  47 */         hookList = new LinkedList();
/*  48 */         hookList.add(hook);
/*  49 */         this.hooks.put(msgType, hookList);
/*     */       }
/*     */       else {
/*  52 */         hookList = new LinkedList(hookList);
/*  53 */         hookList.add(hook);
/*  54 */         this.hooks.put(msgType, hookList);
/*     */       }
/*     */     }
/*     */     finally {
/*  58 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeHook(MessageType msgType, Hook hook)
/*     */   {
/*  66 */     this.lock.lock();
/*     */     try {
/*  68 */       List hookList = (List)this.hooks.get(msgType);
/*  69 */       if (hookList != null) {
/*  70 */         hookList = new LinkedList(hookList);
/*  71 */         hookList.remove(hook);
/*  72 */         if (hookList.size() == 0)
/*  73 */           this.hooks.remove(msgType);
/*     */         else
/*  75 */           this.hooks.put(msgType, hookList);
/*     */       }
/*     */     }
/*     */     finally {
/*  79 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Hook> getHooks(MessageType msgType)
/*     */   {
/*  92 */     List hookList = (List)this.hooks.get(msgType);
/*  93 */     if (hookList == null) {
/*  94 */       return this.nullList;
/*     */     }
/*  96 */     return hookList;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.HookManager
 * JD-Core Version:    0.6.0
 */