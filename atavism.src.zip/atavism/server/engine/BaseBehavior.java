/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.SubjectFilter;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.objects.EntityHandle;
/*     */ import atavism.server.objects.ObjectStub;
/*     */ import atavism.server.objects.ObjectTracker;
/*     */ import atavism.server.objects.SpawnData;
/*     */ import atavism.server.pathing.PathLocAndDir;
/*     */ import atavism.server.pathing.PathState;
/*     */ import atavism.server.plugins.MobManagerPlugin;
/*     */ import atavism.server.plugins.WorldManagerClient;
/*     */ import atavism.server.plugins.WorldManagerClient.MobPathReqMessage;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class BaseBehavior extends Behavior
/*     */   implements Runnable
/*     */ {
/* 409 */   String pathObjectTypeName = "Generic";
/*     */ 
/* 411 */   Long commandSub = null;
/*     */ 
/* 413 */   Point destLoc = null;
/* 414 */   long arriveTime = 0L;
/*     */ 
/* 417 */   PathState pathState = null;
/*     */ 
/* 419 */   EntityHandle followTarget = null;
/* 420 */   float distanceToFollowAt = 0.0F;
/* 421 */   float mobSpeed = 0.0F;
/* 422 */   boolean interpolatingPath = false;
/*     */ 
/* 424 */   protected transient Lock lock = null;
/*     */ 
/* 426 */   protected String mode = "stop";
/* 427 */   protected boolean roamingBehavior = false;
/* 428 */   protected boolean activated = false;
/*     */   public static final String MSG_CMD_TYPE_GOTO = "goto";
/*     */   public static final String MSG_CMD_TYPE_FOLLOW = "follow";
/*     */   public static final String MSG_CMD_TYPE_STOP = "stop";
/*     */   public static final String MSG_CMD_TYPE_DISABLE = "disable";
/*     */   public static final String MSG_EVENT_TYPE_ARRIVED = "arrived";
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public BaseBehavior()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BaseBehavior(SpawnData data)
/*     */   {
/*  19 */     super(data);
/*     */   }
/*     */ 
/*     */   public void initialize() {
/*  23 */     this.lock = LockFactory.makeLock("BaseBehaviorLock");
/*  24 */     OID oid = this.obj.getOid();
/*  25 */     SubjectFilter filter = new SubjectFilter(oid);
/*  26 */     filter.addType(Behavior.MSG_TYPE_COMMAND);
/*  27 */     filter.addType(WorldManagerClient.MSG_TYPE_MOB_PATH_CORRECTION);
/*  28 */     this.pathState = new PathState(oid, this.pathObjectTypeName, true);
/*  29 */     this.commandSub = Long.valueOf(Engine.getAgent().createSubscription(filter, this));
/*     */   }
/*     */   public void activate() {
/*  32 */     this.activated = true;
/*     */   }
/*     */ 
/*     */   public void deactivate() {
/*  36 */     this.lock.lock();
/*     */     try {
/*  38 */       this.activated = false;
/*  39 */       if (this.commandSub != null) {
/*  40 */         Engine.getExecutor().remove(this);
/*  41 */         Engine.getAgent().removeSubscription(this.commandSub.longValue());
/*  42 */         this.commandSub = null;
/*     */       }
/*     */     }
/*     */     finally {
/*  46 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void handleMessage(Message msg, int flags) {
/*     */     try {
/*  52 */       this.lock.lock();
/*  53 */       if (!this.activated) return;
/*  55 */       if (msg.getMsgType() == Behavior.MSG_TYPE_COMMAND) {
/*  56 */         Behavior.CommandMessage cmdMsg = (Behavior.CommandMessage)msg;
/*  57 */         String command = cmdMsg.getCmd();
/*     */ 
/*  60 */         Engine.getExecutor().remove(this);
/*  61 */         if (Log.loggingDebug)
/*  62 */           Log.debug("BaseBehavior.onMessage: command = " + command + "; oid = " + this.obj.getOid() + "; name " + this.obj.getName());
/*  63 */         if (command.equals("goto")) {
/*  64 */           GotoCommandMessage gotoMsg = (GotoCommandMessage)msg;
/*  65 */           Point destination = gotoMsg.getDestination();
/*  66 */           this.mode = "goto";
/*  67 */           this.roamingBehavior = true;
/*  68 */           gotoSetup(destination, gotoMsg.getSpeed());
/*     */         }
/*  70 */         else if (command.equals("stop")) {
/*  71 */           this.followTarget = null;
/*  72 */           this.pathState.clear();
/*  73 */           this.obj.getWorldNode().setDir(new AOVector(0.0F, 0.0F, 0.0F));
/*  74 */           this.obj.updateWorldNode();
/*  75 */           this.mode = "stop";
/*     */ 
/*  80 */           if (this.roamingBehavior) {
/*     */             try {
/*  82 */               Engine.getAgent().sendBroadcast(new ArrivedEventMessage(this.obj));
/*     */             }
/*     */             catch (Exception e) {
/*  85 */               Log.error("BaseBehavior.onMessage: Error sending ArrivedEventMessage, error was '" + e.getMessage() + "'");
/*  86 */               throw new RuntimeException(e);
/*     */             }
/*     */           }
/*     */         }
/*  90 */         else if (command.equals("follow")) {
/*  91 */           FollowCommandMessage followMsg = (FollowCommandMessage)msg;
/*  92 */           this.mode = "follow";
/*  93 */           followSetup(followMsg.getTarget(), followMsg.getSpeed().intValue(), followMsg.getDistanceToFollowAt().floatValue());
/*     */         }
/*  95 */         else if (command.equals("disable")) {
/*  96 */           deactivate();
/*     */         }
/*     */       }
/*  99 */       else if (msg.getMsgType() == WorldManagerClient.MSG_TYPE_MOB_PATH_CORRECTION) {
/* 100 */         Engine.getExecutor().remove(this);
/* 101 */         interpolatePath();
/* 102 */         this.interpolatingPath = false;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 107 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void gotoSetup(Point dest, float speed)
/*     */   {
/* 113 */     this.destLoc = dest;
/* 114 */     this.mobSpeed = speed;
/* 115 */     Point myLoc = this.obj.getWorldNode().getLoc();
/* 116 */     OID oid = this.obj.getOid();
/* 117 */     if (Log.loggingDebug)
/* 118 */       Log.debug("BaseBehavior.gotoSetup: oid = " + oid + "; myLoc = " + myLoc + "; dest = " + dest);
/* 119 */     scheduleMe(setupPathInterpolator(oid, myLoc, dest, false, 0.0F, this.obj.getWorldNode().getFollowsTerrain().booleanValue()));
/*     */   }
/*     */ 
/*     */   public void gotoUpdate() {
/* 123 */     Point myLoc = this.obj.getWorldNode().getLoc();
/* 124 */     OID oid = this.obj.getOid();
/* 125 */     if (this.interpolatingPath) {
/* 126 */       interpolatePath();
/* 127 */       if (!this.interpolatingPath) {
/* 128 */         Engine.getAgent().sendBroadcast(new ArrivedEventMessage(this.obj));
/* 129 */         if (Log.loggingDebug)
/* 130 */           Log.debug("BaseBehavior.gotoUpdate sending ArrivedEventMessage: oid = " + oid + "; myLoc = " + myLoc + "; destLoc = " + this.destLoc);
/* 131 */         this.mode = "stop";
/*     */       }
/*     */     }
/* 134 */     if (this.interpolatingPath)
/* 135 */       scheduleMe(this.pathState.pathTimeRemaining());
/*     */   }
/*     */ 
/*     */   public void followSetup(EntityHandle target, int speed, float distance) {
/* 139 */     this.followTarget = target;
/* 140 */     this.distanceToFollowAt = distance;
/* 141 */     this.mobSpeed = speed;
/* 142 */     InterpolatedWorldNode node = this.obj.getWorldNode();
/* 143 */     Point myLoc = node.getLoc();
/* 144 */     OID oid = this.obj.getOid();
/* 145 */     ObjectStub followObj = (ObjectStub)this.followTarget.getEntity(Namespace.MOB);
/* 146 */     Point followLoc = followObj.getWorldNode().getLoc();
/* 147 */     this.destLoc = followLoc;
/* 148 */     scheduleMe(setupPathInterpolator(oid, myLoc, followLoc, true, this.distanceToFollowAt, node.getFollowsTerrain().booleanValue()));
/*     */   }
/*     */ 
/*     */   protected void scheduleMe(long timeToDest) {
/* 152 */     long ms = Math.min(500L, timeToDest);
/*     */ 
/* 155 */     Engine.getExecutor().schedule(this, ms, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   public void followUpdate() {
/* 159 */     ObjectStub followObj = (ObjectStub)this.followTarget.getEntity(Namespace.MOB);
/* 160 */     Point followLoc = followObj.getWorldNode().getLoc();
/* 161 */     InterpolatedWorldNode node = this.obj.getWorldNode();
/* 162 */     Point myLoc = node.getLoc();
/* 163 */     OID oid = this.obj.getOid();
/* 164 */     float fdist = Point.distanceTo(followLoc, this.destLoc);
/* 165 */     float dist = Point.distanceTo(followLoc, myLoc);
/* 166 */     if (Log.loggingDebug) {
/* 167 */       Log.debug("BaseBehavior.followUpdate: oid = " + oid + "; myLoc = " + myLoc + "; followLoc = " + followLoc + "; fdist = " + fdist + "; dist = " + dist);
/*     */     }
/* 169 */     long msToSleep = 500L;
/*     */ 
/* 172 */     if (fdist > 1.0F) {
/* 173 */       long msToDest = setupPathInterpolator(oid, myLoc, followLoc, true, this.distanceToFollowAt, node.getFollowsTerrain().booleanValue());
/* 174 */       this.destLoc = followLoc;
/* 175 */       msToSleep = msToDest == 0L ? 500L : Math.min(500L, msToDest);
/*     */     }
/* 178 */     else if (this.interpolatingPath) {
/* 179 */       interpolatePath();
/* 180 */       if (Log.loggingDebug)
/* 181 */         Log.debug("baseBehavior.followUpdate: oid = " + oid + "; interpolated myLoc = " + this.obj.getWorldNode().getLoc());
/*     */     }
/* 183 */     scheduleMe(this.interpolatingPath ? msToSleep : this.pathState.pathTimeRemaining());
/*     */   }
/*     */ 
/*     */   protected long setupPathInterpolator(OID oid, Point myLoc, Point dest, boolean follow, float distanceToFollowAt, boolean followsTerrain) {
/* 187 */     long timeNow = System.currentTimeMillis();
/* 188 */     WorldManagerClient.MobPathReqMessage reqMsg = this.pathState.setupPathInterpolator(timeNow, myLoc, dest, this.mobSpeed, follow, distanceToFollowAt, followsTerrain);
/* 189 */     if (reqMsg != null) {
/*     */       try {
/* 191 */         Engine.getAgent().sendBroadcast(reqMsg);
/* 192 */         if (Log.loggingDebug)
/* 193 */           Log.debug("BaseBehavior.setupPathInterpolator: send MobPathReqMessage " + reqMsg);
/*     */       }
/*     */       catch (Exception e) {
/* 196 */         throw new RuntimeException(e);
/*     */       }
/* 198 */       this.interpolatingPath = true;
/* 199 */       return this.pathState.pathTimeRemaining();
/*     */     }
/*     */ 
/* 202 */     this.interpolatingPath = false;
/* 203 */     return 0L;
/*     */   }
/*     */ 
/*     */   protected void cancelPathInterpolator(OID oid)
/*     */   {
/* 208 */     WorldManagerClient.MobPathReqMessage cancelMsg = new WorldManagerClient.MobPathReqMessage(oid);
/*     */     try {
/* 210 */       Engine.getAgent().sendBroadcast(cancelMsg);
/*     */     }
/*     */     catch (Exception e) {
/* 213 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean interpolatePath() {
/* 218 */     long timeNow = System.currentTimeMillis();
/* 219 */     PathLocAndDir locAndDir = this.pathState.interpolatePath(timeNow);
/* 220 */     OID oid = this.obj.getOid();
/*     */ 
/* 230 */     if (locAndDir == null)
/*     */     {
/* 232 */       if (this.interpolatingPath) {
/* 233 */         if (Log.loggingDebug)
/* 234 */           Log.debug("BaseBehavior.interpolatePath: cancelling path: oid = " + oid + "; myLoc = " + this.obj.getWorldNode().getLoc());
/* 235 */         cancelPathInterpolator(oid);
/* 236 */         this.interpolatingPath = false;
/*     */       }
/* 238 */       this.obj.getWorldNode().setDir(new AOVector(0.0F, 0.0F, 0.0F));
/*     */     } else {
/* 240 */       this.obj.getWorldNode().setPathInterpolatorValues(timeNow, locAndDir.getDir(), locAndDir.getLoc(), locAndDir.getOrientation());
/*     */ 
/* 242 */       MobManagerPlugin.getTracker(this.obj.getInstanceOid()).updateEntity(this.obj);
/*     */     }
/* 244 */     return this.interpolatingPath;
/*     */   }
/*     */ 
/*     */   public void run() {
/*     */     try {
/* 249 */       this.lock.lock();
/* 250 */       if (!this.activated)
/*     */         return;
/*     */       try {
/* 254 */         if (this.mode == "goto") {
/* 255 */           gotoUpdate();
/*     */         }
/* 257 */         else if (this.mode == "follow") {
/* 258 */           followUpdate();
/*     */         }
/* 260 */         else if (this.mode != "stop")
/*     */         {
/* 263 */           Log.error("BaseBehavior.run: invalid mode");
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 267 */         Log.exception("BaseBehavior.run caught exception raised during run for mode = " + this.mode, e);
/* 268 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */     finally {
/* 272 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getPathObjectTypeName()
/*     */   {
/* 404 */     return this.pathObjectTypeName;
/*     */   }
/*     */ 
/*     */   public static class ArrivedEventMessage extends Behavior.EventMessage
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public ArrivedEventMessage()
/*     */     {
/* 387 */       setEvent("arrived");
/*     */     }
/*     */ 
/*     */     public ArrivedEventMessage(OID objOid) {
/* 391 */       super();
/* 392 */       setEvent("arrived");
/*     */     }
/*     */ 
/*     */     public ArrivedEventMessage(ObjectStub obj) {
/* 396 */       super();
/* 397 */       setEvent("arrived");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class DisableCommandMessage extends Behavior.CommandMessage
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public DisableCommandMessage()
/*     */     {
/* 369 */       super();
/*     */     }
/*     */ 
/*     */     public DisableCommandMessage(OID objOid) {
/* 373 */       super("disable");
/*     */     }
/*     */ 
/*     */     public DisableCommandMessage(ObjectStub obj) {
/* 377 */       super("disable");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class StopCommandMessage extends Behavior.CommandMessage
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public StopCommandMessage()
/*     */     {
/* 352 */       super();
/*     */     }
/*     */ 
/*     */     public StopCommandMessage(OID objOid) {
/* 356 */       super("stop");
/*     */     }
/*     */ 
/*     */     public StopCommandMessage(ObjectStub obj) {
/* 360 */       super("stop");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class FollowCommandMessage extends Behavior.CommandMessage
/*     */   {
/*     */     private EntityHandle target;
/*     */     private Integer speed;
/*     */     private Float distanceToFollowAt;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public FollowCommandMessage()
/*     */     {
/* 311 */       super();
/*     */     }
/*     */ 
/*     */     public FollowCommandMessage(ObjectStub obj, EntityHandle target, Integer speed, Float distanceToFollowAt) {
/* 315 */       super();
/* 316 */       setTarget(target);
/* 317 */       setSpeed(speed);
/* 318 */       setDistanceToFollowAt(distanceToFollowAt);
/*     */     }
/*     */ 
/*     */     public EntityHandle getTarget() {
/* 322 */       return this.target;
/*     */     }
/*     */     public void setTarget(EntityHandle target) {
/* 325 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public Integer getSpeed() {
/* 329 */       return this.speed;
/*     */     }
/*     */     public void setSpeed(Integer speed) {
/* 332 */       this.speed = speed;
/*     */     }
/*     */ 
/*     */     public Float getDistanceToFollowAt() {
/* 336 */       return this.distanceToFollowAt;
/*     */     }
/*     */     public void setDistanceToFollowAt(Float distanceToFollowAt) {
/* 339 */       this.distanceToFollowAt = distanceToFollowAt;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class GotoCommandMessage extends Behavior.CommandMessage
/*     */   {
/*     */     private Point dest;
/*     */     private float speed;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public GotoCommandMessage()
/*     */     {
/* 279 */       super();
/*     */     }
/*     */ 
/*     */     public GotoCommandMessage(ObjectStub obj, Point dest, float speed) {
/* 283 */       super("goto");
/* 284 */       setDestination(dest);
/* 285 */       setSpeed(speed);
/*     */     }
/*     */ 
/*     */     public Point getDestination() {
/* 289 */       return this.dest;
/*     */     }
/*     */     public void setDestination(Point dest) {
/* 292 */       this.dest = dest;
/*     */     }
/*     */ 
/*     */     public float getSpeed() {
/* 296 */       return this.speed;
/*     */     }
/*     */     public void setSpeed(float speed) {
/* 299 */       this.speed = speed;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.BaseBehavior
 * JD-Core Version:    0.6.0
 */