/*     */ package atavism.server.engine;
/*     */ 
/*     */ import atavism.server.plugins.JukeboxWebPlugin;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class JukeboxWebEngine extends HttpServlet
/*     */ {
/*     */   private ArrayList<String> nameList;
/*     */   private ArrayList<String> typeList;
/*     */   private ArrayList<String> urlList;
/*     */   private ArrayList<String> costList;
/*     */   private ArrayList<String> descriptionList;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public void init(ServletConfig config)
/*     */     throws ServletException
/*     */   {
/*  26 */     this.nameList = new ArrayList();
/*  27 */     this.typeList = new ArrayList();
/*  28 */     this.urlList = new ArrayList();
/*  29 */     this.costList = new ArrayList();
/*  30 */     this.descriptionList = new ArrayList();
/*  31 */     JukeboxWebEngineThread jukeboxWebEngineThread = new JukeboxWebEngineThread();
/*  32 */     new Thread(jukeboxWebEngineThread).start();
/*     */   }
/*     */ 
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse res)
/*     */     throws ServletException, IOException
/*     */   {
/*  38 */     res.setContentType("text/html");
/*  39 */     res.setHeader("pragma", "no-cache");
/*  40 */     String playerOid = req.getParameter("poid");
/*  41 */     PrintWriter out = res.getWriter();
/*  42 */     if ((playerOid == null) || (playerOid.length() == 0)) {
/*  43 */       out.print("<HTML><HEAD><TITLE>Jukebox Media Manager</TITLE></HEAD>");
/*  44 */       out.print("<BODY><H3>Jukebox Media Control:</H3><TABLE border=\"1\">");
/*  45 */       out.print("<TR><TH>NAME</TH><TH>TYPE</TH><TH>URL</TH><TH>COST</TH><TH>DESCRIPTION</TH></TR>");
/*  46 */       for (int i = 0; i < this.nameList.size(); i++) {
/*  47 */         out.print("<TR>");
/*  48 */         out.print("<TD>" + (String)this.nameList.get(i) + "</TD>");
/*  49 */         out.print("<TD>" + (String)this.typeList.get(i) + "</TD>");
/*  50 */         out.print("<TD>" + (String)this.urlList.get(i) + "</TD>");
/*  51 */         out.print("<TD>" + (String)this.costList.get(i) + "</TD>");
/*  52 */         out.print("<TD>" + (String)this.descriptionList.get(i) + "</TD>");
/*  53 */         out.print("</TR>");
/*     */       }
/*  55 */       out.print("</TABLE><HR><FORM METHOD=POST>");
/*  56 */       out.print("<TABLE>");
/*  57 */       out.print("<TR><TD>name:</TD><TD><INPUT TYPE=TEXT NAME=name></TD></TR>");
/*  58 */       out.print("<TR><TD>type:</TD><TD><INPUT TYPE=TEXT NAME=type></TD></TR>");
/*  59 */       out.print("<TR><TD>url:</TD><TD><INPUT TYPE=TEXT NAME=url></TD></TR>");
/*  60 */       out.print("<TR><TD>cost:</TD><TD><INPUT TYPE=TEXT NAME=cost></TD></TR>");
/*  61 */       out.print("<TR><TD>description:</TD><TD><INPUT TYPE=TEXT NAME=description></TD></TR>");
/*  62 */       out.print("<TR><TD></TD></TR>");
/*  63 */       out.print("<TR><TD align=\"center\" colspan=\"2\">");
/*  64 */       out.print("<INPUT TYPE=SUBMIT NAME=action VALUE=add>");
/*  65 */       out.print("<INPUT TYPE=SUBMIT NAME=action VALUE=delete>");
/*  66 */       out.print("<INPUT TYPE=SUBMIT NAME=action VALUE=get>");
/*  67 */       out.print("</TD></TR>");
/*  68 */       out.print("</TABLE>");
/*  69 */       out.print("</FORM></BODY></HTML>");
/*  70 */       out.close();
/*     */     } else {
/*  72 */       int funds = getMoney(playerOid);
/*  73 */       out.print("<HTML><HEAD><TITLE>Jukebox Funds Manager</TITLE></HEAD>");
/*  74 */       out.print("<BODY><H3>Jukebox Funds Control:</H3>");
/*  75 */       out.print("Player OID: " + playerOid + "<BR>");
/*  76 */       out.print("Current Funds: $" + funds / 100);
/*  77 */       if (funds % 100 < 10)
/*  78 */         out.print(".0" + funds % 100 + "<BR>");
/*     */       else {
/*  80 */         out.print("." + funds % 100 + "<BR>");
/*     */       }
/*  82 */       out.print("<FORM METHOD=POST>");
/*  83 */       out.print("<INPUT TYPE=TEXT NAME=money><BR>");
/*  84 */       out.print("<INPUT TYPE=SUBMIT NAME=action VALUE=deposit><BR>");
/*  85 */       out.print("<INPUT TYPE=HIDDEN NAME=poid VALUE=" + playerOid + "><BR>");
/*  86 */       out.print("</FORM>");
/*  87 */       out.print("</BODY></HTML>");
/*  88 */       out.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse res)
/*     */     throws ServletException, IOException
/*     */   {
/*  95 */     String name = req.getParameter("name");
/*  96 */     String type = req.getParameter("type");
/*  97 */     String url = req.getParameter("url");
/*  98 */     String cost = req.getParameter("cost");
/*  99 */     String description = req.getParameter("description");
/* 100 */     String poid = req.getParameter("poid");
/* 101 */     String money = req.getParameter("money");
/* 102 */     String msg = "";
/* 103 */     if ((poid == null) || (poid.length() == 0)) {
/* 104 */       if ((name.length() == 0) && (!req.getParameter("action").equals("get"))) {
/* 105 */         res.sendError(400, "No name specified.");
/* 106 */         return;
/*     */       }
/* 108 */       if (req.getParameter("action").equals("add")) {
/* 109 */         if (type.length() == 0) {
/* 110 */           res.sendError(400, "Type must be stream or audio.");
/* 111 */           return;
/*     */         }
/* 113 */         if (url.length() == 0) {
/* 114 */           res.sendError(400, "No url specified.");
/* 115 */           return;
/*     */         }
/* 117 */         if (cost.length() == 0) {
/* 118 */           res.sendError(400, "No cost specified.");
/* 119 */           return;
/*     */         }
/* 121 */         if (description.length() == 0) {
/* 122 */           description = "n/a";
/*     */         }
/* 124 */         if (addTrack(name, type, url, cost, description)) {
/* 125 */           msg = "" + name + " has been added.";
/*     */         } else {
/* 127 */           res.sendError(400, "" + name + " is already in the list.");
/* 128 */           return;
/*     */         }
/* 130 */       } else if (req.getParameter("action").equals("delete")) {
/* 131 */         if (deleteTrack(name)) {
/* 132 */           msg = "" + name + " has been deleted.";
/*     */         } else {
/* 134 */           res.sendError(400, "" + name + " is not in the list.");
/* 135 */           return;
/*     */         }
/* 137 */       } else if (req.getParameter("action").equals("get")) {
/* 138 */         if (getTracks()) {
/* 139 */           msg = "Got tracks.";
/*     */         } else {
/* 141 */           res.sendError(400, "Cannot get tracks.");
/* 142 */           return;
/*     */         }
/*     */       }
/*     */     }
/* 146 */     else if (req.getParameter("action").equals("deposit")) {
/* 147 */       if (addMoney(poid, money)) {
/* 148 */         msg = "Added money.";
/*     */       } else {
/* 150 */         res.sendError(400, "Cannot add money.");
/* 151 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 156 */     res.setContentType("text/html");
/* 157 */     res.setHeader("pragma", "no-cache");
/* 158 */     PrintWriter out = res.getWriter();
/* 159 */     out.print("<HTML><HEAD><TITLE>Jukebox Manager</TITLE></HEAD><BODY>");
/* 160 */     out.print(msg);
/* 161 */     out.print("<HR><A HREF=\"");
/* 162 */     out.print(req.getRequestURL());
/* 163 */     if ((poid != null) && (poid.length() != 0)) {
/* 164 */       out.print("?poid=" + poid);
/*     */     }
/* 166 */     out.print("\">Return</A></BODY></HTML>");
/* 167 */     out.close();
/*     */   }
/*     */ 
/*     */   public String getServletInfo() {
/* 171 */     return "JukeboxWebEngine";
/*     */   }
/*     */ 
/*     */   private synchronized boolean addTrack(String name, String type, String url, String cost, String description)
/*     */     throws IOException
/*     */   {
/* 177 */     JukeboxWebPlugin jukeboxWebPlugin = (JukeboxWebPlugin)Engine.getPlugin("JukeboxWebPlugin");
/* 178 */     if (jukeboxWebPlugin == null) return false;
/* 179 */     if (this.nameList.contains(name)) return false;
/* 180 */     this.nameList.add(name);
/* 181 */     this.typeList.add(type);
/* 182 */     this.urlList.add(url);
/* 183 */     this.costList.add(cost);
/* 184 */     this.descriptionList.add(description);
/* 185 */     jukeboxWebPlugin.addTrack(name, type, url, cost, description);
/* 186 */     return true;
/*     */   }
/*     */ 
/*     */   private synchronized boolean deleteTrack(String name) throws IOException {
/* 190 */     JukeboxWebPlugin jukeboxWebPlugin = (JukeboxWebPlugin)Engine.getPlugin("JukeboxWebPlugin");
/* 191 */     if (jukeboxWebPlugin == null) return false;
/* 192 */     int index = this.nameList.indexOf(name);
/* 193 */     if (index == -1) return false;
/* 194 */     this.nameList.remove(index);
/* 195 */     this.typeList.remove(index);
/* 196 */     this.urlList.remove(index);
/* 197 */     this.costList.remove(index);
/* 198 */     this.descriptionList.remove(index);
/* 199 */     jukeboxWebPlugin.deleteTrack(name);
/* 200 */     return true;
/*     */   }
/*     */ 
/*     */   private synchronized boolean getTracks() {
/* 204 */     JukeboxWebPlugin jukeboxWebPlugin = (JukeboxWebPlugin)Engine.getPlugin("JukeboxWebPlugin");
/* 205 */     if (jukeboxWebPlugin == null) return false;
/* 206 */     ArrayList trackData = jukeboxWebPlugin.getTracks();
/* 207 */     if (trackData == null) return false;
/* 208 */     this.nameList.clear();
/* 209 */     this.typeList.clear();
/* 210 */     this.urlList.clear();
/* 211 */     this.costList.clear();
/* 212 */     this.descriptionList.clear();
/* 213 */     for (int i = trackData.size(); i-- > 0; ) {
/* 214 */       HashMap trackInfo = (HashMap)trackData.get(i);
/* 215 */       this.nameList.add((String)trackInfo.get("name"));
/* 216 */       this.typeList.add((String)trackInfo.get("type"));
/* 217 */       this.urlList.add((String)trackInfo.get("url"));
/* 218 */       this.costList.add((String)trackInfo.get("cost"));
/* 219 */       this.descriptionList.add((String)trackInfo.get("description"));
/*     */     }
/* 221 */     return true;
/*     */   }
/*     */ 
/*     */   private synchronized int getMoney(String poid) {
/* 225 */     JukeboxWebPlugin jukeboxWebPlugin = (JukeboxWebPlugin)Engine.getPlugin("JukeboxWebPlugin");
/* 226 */     if (jukeboxWebPlugin == null) return 0;
/* 227 */     int money = jukeboxWebPlugin.getMoney(poid);
/* 228 */     return money;
/*     */   }
/*     */ 
/*     */   private synchronized boolean addMoney(String poid, String money) {
/* 232 */     JukeboxWebPlugin jukeboxWebPlugin = (JukeboxWebPlugin)Engine.getPlugin("JukeboxWebPlugin");
/* 233 */     Double dDollars = new Double(money);
/* 234 */     dDollars = Double.valueOf(dDollars.doubleValue() * 100.0D);
/* 235 */     Integer iDollars = new Integer(dDollars.intValue());
/* 236 */     if (jukeboxWebPlugin == null) return false;
/* 237 */     jukeboxWebPlugin.addMoney(poid, iDollars.toString());
/* 238 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.JukeboxWebEngine
 * JD-Core Version:    0.6.0
 */