package atavism.server.engine;

public abstract interface PerceiverCallback<ElementType extends QuadTreeElement<ElementType>>
{
  public abstract Integer processNewsAndFrees(Perceiver<ElementType> paramPerceiver, PerceiverNewsAndFrees<ElementType> paramPerceiverNewsAndFrees, OID paramOID);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.PerceiverCallback
 * JD-Core Version:    0.6.0
 */