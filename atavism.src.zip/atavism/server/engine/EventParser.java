package atavism.server.engine;

import atavism.server.network.AOByteBuffer;

public abstract interface EventParser
{
  public abstract void parseBytes(AOByteBuffer paramAOByteBuffer);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.EventParser
 * JD-Core Version:    0.6.0
 */