/*     */ package atavism.server.engine;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SearchSelection
/*     */ {
/*     */   public static final int RESULT_KEYED = 1;
/*     */   public static final int RESULT_KEY_ONLY = 2;
/*     */   private int resultOption;
/*     */   private boolean selectAllProperties;
/*     */   private long propFlags;
/*     */   private List<String> properties;
/*     */ 
/*     */   public SearchSelection()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SearchSelection(long propFlags)
/*     */   {
/*  31 */     setPropFlags(propFlags);
/*     */   }
/*     */ 
/*     */   public SearchSelection(long propFlags, int resultOption)
/*     */   {
/*  39 */     setPropFlags(propFlags);
/*  40 */     setResultOption(resultOption);
/*     */   }
/*     */ 
/*     */   public SearchSelection(List<String> properties)
/*     */   {
/*  47 */     setProperties(properties);
/*     */   }
/*     */ 
/*     */   public SearchSelection(List<String> properties, int resultOption)
/*     */   {
/*  55 */     setProperties(properties);
/*  56 */     setResultOption(resultOption);
/*     */   }
/*     */ 
/*     */   public int getResultOption()
/*     */   {
/*  70 */     return this.resultOption;
/*     */   }
/*     */ 
/*     */   public void setResultOption(int option)
/*     */   {
/*  78 */     this.resultOption = option;
/*     */   }
/*     */ 
/*     */   public List<String> getProperties()
/*     */   {
/*  85 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public void setProperties(List<String> props)
/*     */   {
/*  92 */     this.properties = props;
/*     */   }
/*     */ 
/*     */   public void addProperty(String property)
/*     */   {
/*  99 */     if (this.properties == null)
/* 100 */       this.properties = new LinkedList();
/* 101 */     this.properties.add(property);
/*     */   }
/*     */ 
/*     */   public void removeProperty(String property)
/*     */   {
/* 108 */     if (this.properties != null)
/* 109 */       this.properties.remove(property);
/*     */   }
/*     */ 
/*     */   public boolean getAllProperties()
/*     */   {
/* 116 */     return this.selectAllProperties;
/*     */   }
/*     */ 
/*     */   public void setAllProperties(boolean selectAllProperties)
/*     */   {
/* 123 */     this.selectAllProperties = selectAllProperties;
/*     */   }
/*     */ 
/*     */   public long getPropFlags()
/*     */   {
/* 130 */     return this.propFlags;
/*     */   }
/*     */ 
/*     */   public void setPropFlags(long flags)
/*     */   {
/* 137 */     this.propFlags = flags;
/*     */   }
/*     */ 
/*     */   public void addPropFlag(long flag)
/*     */   {
/* 144 */     this.propFlags |= flag;
/*     */   }
/*     */ 
/*     */   public void removePropFlag(long flag)
/*     */   {
/* 151 */     this.propFlags &= (flag ^ 0xFFFFFFFF);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.SearchSelection
 * JD-Core Version:    0.6.0
 */