package atavism.server.engine;

public abstract interface Matcher
{
  public abstract boolean match(Object paramObject);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.engine.Matcher
 * JD-Core Version:    0.6.0
 */