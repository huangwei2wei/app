/*     */ package atavism.server.math;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ 
/*     */ public class Point
/*     */   implements Cloneable, Externalizable
/*     */ {
/* 167 */   private float _x = 0.0F;
/* 168 */   private float _y = 0.0F;
/* 169 */   private float _z = 0.0F;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Point()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Point(float x, float y, float z)
/*     */   {
/*  13 */     this._x = x;
/*  14 */     this._y = y;
/*  15 */     this._z = z;
/*     */   }
/*     */ 
/*     */   public Point(AOVector v) {
/*  19 */     this._x = v.getX();
/*  20 */     this._y = v.getY();
/*  21 */     this._z = v.getZ();
/*     */   }
/*     */ 
/*     */   public Point(Point p) {
/*  25 */     this._x = p.getX();
/*  26 */     this._y = p.getY();
/*  27 */     this._z = p.getZ();
/*     */   }
/*     */ 
/*     */   public Object clone() {
/*  31 */     Point o = new Point(this._x, this._y, this._z);
/*  32 */     return o;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  37 */     Point other = (Point)obj;
/*  38 */     return (this._x == other._x) && (this._y == other._y) && (this._z == other._z);
/*     */   }
/*     */ 
/*     */   public void add(int x, int y, int z) {
/*  42 */     this._x += x;
/*  43 */     this._y += y;
/*  44 */     this._z += z;
/*     */   }
/*     */ 
/*     */   public void add(float x, float y, float z) {
/*  48 */     this._x += x;
/*  49 */     this._y += y;
/*  50 */     this._z += z;
/*     */   }
/*     */ 
/*     */   public void add(Point other) {
/*  54 */     this._x += other.getX();
/*  55 */     this._y += other.getY();
/*  56 */     this._z += other.getZ();
/*     */   }
/*     */ 
/*     */   public void sub(Point other) {
/*  60 */     this._x -= other.getX();
/*  61 */     this._y -= other.getY();
/*  62 */     this._z -= other.getZ();
/*     */   }
/*     */ 
/*     */   public void add(AOVector other) {
/*  66 */     this._x += other.getX();
/*  67 */     this._y += other.getY();
/*  68 */     this._z += other.getZ();
/*     */   }
/*     */ 
/*     */   public void sub(AOVector other) {
/*  72 */     this._x -= other.getX();
/*  73 */     this._y -= other.getY();
/*  74 */     this._z -= other.getZ();
/*     */   }
/*     */ 
/*     */   public void negate() {
/*  78 */     this._x = (-this._x);
/*  79 */     this._y = (-this._y);
/*  80 */     this._z = (-this._z);
/*     */   }
/*     */ 
/*     */   public void multiply(float factor) {
/*  84 */     this._x = (int)(this._x * factor);
/*  85 */     this._y = (int)(this._y * factor);
/*  86 */     this._z = (int)(this._z * factor);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  90 */     return "(" + getX() + "," + getY() + "," + getZ() + ")";
/*     */   }
/*     */ 
/*     */   public static Point parsePoint(String s) {
/*  94 */     String v = s.trim();
/*  95 */     Point p = new Point();
/*  96 */     if ((v.startsWith("(")) && (v.endsWith(")"))) {
/*  97 */       String[] parts = v.substring(1, v.length() - 1).split(",");
/*  98 */       int n = parts.length;
/*  99 */       if (n >= 1)
/* 100 */         p.setX((int)Float.parseFloat(parts[0]));
/* 101 */       if (n >= 2)
/* 102 */         p.setY((int)Float.parseFloat(parts[1]));
/* 103 */       if (n >= 3)
/* 104 */         p.setZ((int)Float.parseFloat(parts[2]));
/*     */     }
/* 106 */     return p;
/*     */   }
/*     */   public float getX() {
/* 109 */     return this._x; } 
/* 110 */   public float getY() { return this._y; } 
/* 111 */   public float getZ() { return this._z; } 
/*     */   public void setX(float x) {
/* 113 */     this._x = x; } 
/* 114 */   public void setY(float y) { this._y = y; } 
/* 115 */   public void setZ(float z) { this._z = z;
/*     */   }
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 129 */     Log.debug("Writing point: " + toString());
/* 130 */     out.writeFloat(this._x);
/* 131 */     out.writeFloat(this._y);
/* 132 */     out.writeFloat(this._z);
/*     */   }
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 143 */     this._x = in.readFloat();
/* 144 */     this._y = in.readFloat();
/* 145 */     this._z = in.readFloat();
/* 146 */     Log.debug("Reading point: " + toString());
/*     */   }
/*     */ 
/*     */   public static float distanceTo(Point p1, Point p2)
/*     */   {
/* 153 */     float dist = (float)Math.sqrt(Math.pow(p2.getX() - p1.getX(), 2.0D) + Math.pow(p2.getZ() - p1.getZ(), 2.0D));
/*     */ 
/* 155 */     return dist;
/*     */   }
/*     */ 
/*     */   public static float distanceToSquared(Point p1, Point p2)
/*     */   {
/* 163 */     float distSquared = (float)(Math.pow(p2.getX() - p1.getX(), 2.0D) + Math.pow(p2.getZ() - p1.getZ(), 2.0D));
/* 164 */     return distSquared;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.Point
 * JD-Core Version:    0.6.0
 */