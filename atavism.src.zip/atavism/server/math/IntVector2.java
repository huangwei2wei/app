/*    */ package atavism.server.math;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class IntVector2
/*    */   implements Cloneable, Serializable
/*    */ {
/* 26 */   public int x = -1;
/* 27 */   public int y = -1;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public IntVector2()
/*    */   {
/*    */   }
/*    */ 
/*    */   public IntVector2(int x, int y)
/*    */   {
/* 14 */     this.x = x;
/* 15 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public Object clone() {
/* 19 */     return new IntVector2(this.x, this.y);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return "[IntVector2 x=" + this.x + " y=" + this.y + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.IntVector2
 * JD-Core Version:    0.6.0
 */