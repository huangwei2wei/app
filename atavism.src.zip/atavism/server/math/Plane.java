/*    */ package atavism.server.math;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Plane
/*    */   implements Cloneable, Serializable
/*    */ {
/*    */   protected AOVector normal;
/*    */   protected float d;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Plane()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Plane(AOVector normal, AOVector point)
/*    */   {
/* 28 */     this.normal = normal;
/* 29 */     this.d = (-normal.dotProduct(point));
/*    */   }
/*    */ 
/*    */   public Plane(AOVector normal, float dist)
/*    */   {
/* 34 */     this.normal = normal;
/* 35 */     this.d = dist;
/*    */   }
/*    */ 
/*    */   public Plane(Point intPoint0, Point intPoint1, Point intPoint2)
/*    */   {
/* 40 */     AOVector point0 = new AOVector(intPoint0);
/* 41 */     AOVector point1 = new AOVector(intPoint1);
/* 42 */     AOVector point2 = new AOVector(intPoint2);
/* 43 */     AOVector edge1 = AOVector.sub(point1, point0);
/* 44 */     AOVector edge2 = AOVector.sub(point2, point0);
/* 45 */     this.normal = AOVector.cross(edge1, edge2);
/* 46 */     this.normal.normalize();
/* 47 */     this.d = (-this.normal.dotProduct(point0));
/*    */   }
/*    */ 
/*    */   public Plane(AOVector point0, AOVector point1, AOVector point2)
/*    */   {
/* 52 */     AOVector edge1 = AOVector.sub(point1, point0);
/* 53 */     AOVector edge2 = AOVector.sub(point2, point0);
/* 54 */     this.normal = AOVector.cross(edge1, edge2);
/* 55 */     this.normal.normalize();
/* 56 */     this.d = (-this.normal.dotProduct(point0));
/*    */   }
/*    */ 
/*    */   public PlaneSide getSide(AOVector point) {
/* 60 */     float distance = getDistance(point);
/* 61 */     if (distance < 0.0F) {
/* 62 */       return PlaneSide.Negative;
/*    */     }
/* 64 */     if (distance > 0.0F) {
/* 65 */       return PlaneSide.Positive;
/*    */     }
/* 67 */     return PlaneSide.None;
/*    */   }
/*    */ 
/*    */   public float getDistance(AOVector point)
/*    */   {
/* 77 */     return this.normal.dotProduct(point) + this.d;
/*    */   }
/*    */ 
/*    */   public AOVector getNormal() {
/* 81 */     return this.normal;
/*    */   }
/*    */ 
/*    */   public float getD() {
/* 85 */     return this.d;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 89 */     return "[Plane: normal=" + this.normal.toString() + "; d=" + this.d + "]";
/*    */   }
/*    */ 
/*    */   public static enum PlaneSide
/*    */   {
/* 14 */     None(0), 
/* 15 */     Positive(1), 
/* 16 */     Negative(2);
/*    */ 
/* 20 */     byte val = -1;
/*    */ 
/*    */     private PlaneSide(byte val)
/*    */     {
/* 18 */       this.val = val;
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.Plane
 * JD-Core Version:    0.6.0
 */