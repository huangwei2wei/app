/*     */ package atavism.server.math;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ public class Geometry
/*     */   implements Serializable, Cloneable
/*     */ {
/* 181 */   float minX = 0.0F;
/* 182 */   float maxX = 0.0F;
/* 183 */   float minZ = 0.0F;
/* 184 */   float maxZ = 0.0F;
/*     */ 
/* 186 */   public static float GEO_MIN_X = -499999.0F;
/* 187 */   public static float GEO_MAX_X = 500000.0F;
/* 188 */   public static float GEO_MIN_Z = -499999.0F;
/* 189 */   public static float GEO_MAX_Z = 500000.0F;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Geometry()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Geometry(float minX, float maxX, float minZ, float maxZ)
/*     */   {
/*  18 */     this.minX = minX;
/*  19 */     this.maxX = maxX;
/*  20 */     this.minZ = minZ;
/*  21 */     this.maxZ = maxZ;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  25 */     return "[Geometry X=" + getMinX() + "," + getMaxX() + " Z=" + getMinZ() + "," + getMaxZ() + "]";
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  33 */     return new Geometry(this.minX, this.maxX, this.minZ, this.maxZ);
/*     */   }
/*     */ 
/*     */   public boolean equals(Geometry other) {
/*  37 */     return (this.minX == other.minX) && (this.maxX == other.maxX) && (this.minZ == other.minZ) && (this.maxZ == other.maxZ);
/*     */   }
/*     */ 
/*     */   public float getMinX()
/*     */   {
/*  44 */     return this.minX;
/*     */   }
/*     */   public float getMaxX() {
/*  47 */     return this.maxX;
/*     */   }
/*     */   public float getMinZ() {
/*  50 */     return this.minZ;
/*     */   }
/*     */   public float getMaxZ() {
/*  53 */     return this.maxZ;
/*     */   }
/*     */ 
/*     */   public void setMinX(int x) {
/*  57 */     this.minX = x;
/*     */   }
/*     */   public void setMaxX(int x) {
/*  60 */     this.maxX = x;
/*     */   }
/*     */   public void getMinZ(int z) {
/*  63 */     this.minZ = z;
/*     */   }
/*     */   public void getMaxZ(int z) {
/*  66 */     this.maxZ = z;
/*     */   }
/*     */ 
/*     */   Point getCenter()
/*     */   {
/*  74 */     int halfX = (int)((()this.maxX - ()this.minX) / 2L - 1L);
/*  75 */     int halfZ = (int)((()this.maxZ - ()this.minZ) / 2L - 1L);
/*  76 */     return new Point(halfX, 0.0F, halfZ);
/*     */   }
/*     */ 
/*     */   public boolean contains(Point pt)
/*     */   {
/*  83 */     if (pt == null) {
/*  84 */       return false;
/*     */     }
/*  86 */     return (pt.getX() >= getMinX()) && (pt.getX() <= getMaxX()) && (pt.getZ() >= getMinZ()) && (pt.getZ() <= getMaxZ());
/*     */   }
/*     */ 
/*     */   public boolean contains(Geometry g)
/*     */   {
/*  96 */     if (g == null) {
/*  97 */       return false;
/*     */     }
/*  99 */     return (g.getMinX() >= getMinX()) && (g.getMaxX() <= getMaxX()) && (g.getMinZ() >= getMinZ()) && (g.getMaxZ() <= getMaxZ());
/*     */   }
/*     */ 
/*     */   public boolean overlaps(Geometry g)
/*     */   {
/* 109 */     if (g == null) {
/* 110 */       return false;
/*     */     }
/* 112 */     return (g.getMaxX() >= getMinX()) && (g.getMinX() <= getMaxX()) && (g.getMaxZ() >= getMinZ()) && (g.getMinZ() <= getMaxZ());
/*     */   }
/*     */ 
/*     */   public Collection<Point> getCorners()
/*     */   {
/* 122 */     Collection corners = new LinkedList();
/* 123 */     corners.add(new Point(this.minX, 0.0F, this.minZ));
/* 124 */     corners.add(new Point(this.minX, 0.0F, this.maxZ));
/* 125 */     corners.add(new Point(this.maxX, 0.0F, this.minZ));
/* 126 */     corners.add(new Point(this.maxX, 0.0F, this.maxZ));
/* 127 */     return corners;
/*     */   }
/*     */ 
/*     */   public Geometry[] divide()
/*     */   {
/* 137 */     long ldiffX = ()this.maxX - ()this.minX;
/* 138 */     long lhalfX = ldiffX / 2L - 1L;
/* 139 */     Log.debug("DIVIDE: maxX=" + this.maxX + " minX=" + this.minX + " ldiffX=" + ldiffX + " lhalfX=" + lhalfX);
/*     */ 
/* 141 */     long ldiffZ = ()this.maxZ - ()this.minZ;
/* 142 */     long lhalfZ = ldiffZ / 2L - 1L;
/*     */ 
/* 144 */     Geometry[] ga = new Geometry[4];
/* 145 */     ga[0] = new Geometry(this.minX, this.minX + (float)lhalfX + 1.0F, this.minZ, this.minZ + (float)lhalfZ + 1.0F);
/*     */ 
/* 147 */     ga[1] = new Geometry(this.minX + (float)lhalfX + 1.0F, this.maxX, this.minZ, this.minZ + (float)lhalfZ + 1.0F);
/*     */ 
/* 149 */     ga[2] = new Geometry(this.minX, this.minX + (float)lhalfX + 1.0F, this.minZ + (float)lhalfZ + 1.0F, this.maxZ);
/*     */ 
/* 151 */     ga[3] = new Geometry(this.minX + (float)lhalfX + 1.0F, this.maxX, this.minZ + (float)lhalfZ + 1.0F, this.maxZ);
/*     */ 
/* 153 */     return ga;
/*     */   }
/*     */ 
/*     */   public boolean isAdjacent(Geometry gOther) {
/* 157 */     return (gOther.getMinX() == getMaxX() + 1.0F) || (gOther.getMaxX() == getMinX() - 1.0F) || (gOther.getMaxZ() == getMinZ() - 1.0F) || (gOther.getMinZ() == getMaxZ() + 1.0F);
/*     */   }
/*     */ 
/*     */   public static Geometry maxGeometry()
/*     */   {
/* 168 */     return new Geometry(GEO_MIN_X, GEO_MAX_X, GEO_MIN_Z, GEO_MAX_Z);
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 173 */     in.defaultReadObject();
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException
/*     */   {
/* 178 */     out.defaultWriteObject();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.Geometry
 * JD-Core Version:    0.6.0
 */