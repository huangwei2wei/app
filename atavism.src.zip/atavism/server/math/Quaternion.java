/*     */ package atavism.server.math;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ 
/*     */ public class Quaternion
/*     */   implements Externalizable, Cloneable
/*     */ {
/*  98 */   private float _x = 0.0F;
/*     */ 
/* 100 */   private float _y = 0.0F;
/*     */ 
/* 102 */   private float _z = 0.0F;
/*     */ 
/* 104 */   private float _w = 0.0F;
/*     */ 
/* 152 */   public static final Quaternion Identity = new Quaternion();
/*     */ 
/* 182 */   public static float epsilon = 0.001F;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Quaternion()
/*     */   {
/*  14 */     this._w = 1.0F;
/*     */   }
/*     */ 
/*     */   public Quaternion(float x, float y, float z, float w) {
/*  18 */     this._x = x;
/*  19 */     this._y = y;
/*  20 */     this._z = z;
/*  21 */     this._w = w;
/*     */   }
/*     */ 
/*     */   public Quaternion(Quaternion other) {
/*  25 */     this._x = other._x;
/*  26 */     this._y = other._y;
/*  27 */     this._z = other._z;
/*  28 */     this._w = other._w;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  32 */     return "(" + getX() + "," + getY() + "," + getZ() + "," + getW() + ")";
/*     */   }
/*     */ 
/*     */   public static Quaternion parseQuaternion(String s) {
/*  36 */     String v = s.trim();
/*  37 */     Quaternion q = new Quaternion();
/*  38 */     if ((v.startsWith("(")) && (v.endsWith(")"))) {
/*  39 */       String[] parts = v.substring(1, v.length() - 2).split(",");
/*  40 */       int n = parts.length;
/*  41 */       if (n >= 1)
/*  42 */         q.setX((int)Float.parseFloat(parts[0]));
/*  43 */       if (n >= 2)
/*  44 */         q.setY((int)Float.parseFloat(parts[1]));
/*  45 */       if (n >= 3)
/*  46 */         q.setZ((int)Float.parseFloat(parts[2]));
/*  47 */       if (n >= 4)
/*  48 */         q.setW((int)Float.parseFloat(parts[3]));
/*     */     }
/*  50 */     return q;
/*     */   }
/*     */ 
/*     */   public Object clone() {
/*  54 */     return new Quaternion(this._x, this._y, this._z, this._w);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  59 */     return equals((Quaternion)obj);
/*     */   }
/*     */ 
/*     */   public boolean equals(Quaternion q) {
/*  63 */     return (this._x == q._x) && (this._y == q._y) && (this._z == q._z) && (this._w == q._w);
/*     */   }
/*     */ 
/*     */   public float getX() {
/*  67 */     return this._x;
/*     */   }
/*     */ 
/*     */   public float getY() {
/*  71 */     return this._y;
/*     */   }
/*     */ 
/*     */   public float getZ() {
/*  75 */     return this._z;
/*     */   }
/*     */ 
/*     */   public float getW() {
/*  79 */     return this._w;
/*     */   }
/*     */ 
/*     */   public void setX(float x) {
/*  83 */     this._x = x;
/*     */   }
/*     */ 
/*     */   public void setY(float y) {
/*  87 */     this._y = y;
/*     */   }
/*     */ 
/*     */   public void setZ(float z) {
/*  91 */     this._z = z;
/*     */   }
/*     */ 
/*     */   public void setW(float w) {
/*  95 */     this._w = w;
/*     */   }
/*     */ 
/*     */   public static Quaternion fromAngleAxis(double angle, AOVector axis)
/*     */   {
/* 115 */     Quaternion quat = new Quaternion();
/* 116 */     double halfAngle = 0.5D * angle;
/* 117 */     float cos = (float)Math.cos(halfAngle);
/* 118 */     float sin = (float)Math.sin(halfAngle);
/* 119 */     AOVector normAxis = new AOVector(axis).normalize();
/* 120 */     quat._w = cos;
/* 121 */     quat._x = (sin * normAxis.getX());
/* 122 */     quat._y = (sin * normAxis.getY());
/* 123 */     quat._z = (sin * normAxis.getZ());
/* 124 */     return quat;
/*     */   }
/*     */ 
/*     */   public static Quaternion fromAngleAxisDegrees(double angle, AOVector axis)
/*     */   {
/* 136 */     return fromAngleAxis(Math.toRadians(angle), axis);
/*     */   }
/*     */ 
/*     */   public double getAngleAxisDegrees(AOVector axis)
/*     */   {
/* 148 */     double angle = getAngleAxis(axis);
/* 149 */     return Math.toDegrees(angle);
/*     */   }
/*     */ 
/*     */   public double getAngleAxis(AOVector axis)
/*     */   {
/* 165 */     float len = (float)Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z);
/*     */     double angle;
/* 167 */     if (len > 0.0F) {
/* 168 */       double angle = 2.0D * Math.acos(this._w);
/* 169 */       axis.setX(this._x / len);
/* 170 */       axis.setY(this._y / len);
/* 171 */       axis.setZ(this._z / len);
/*     */     }
/*     */     else {
/* 174 */       angle = 0.0D;
/* 175 */       axis.setX(1.0F);
/* 176 */       axis.setY(0.0F);
/* 177 */       axis.setZ(0.0F);
/*     */     }
/* 179 */     return angle;
/*     */   }
/*     */ 
/*     */   public static Quaternion fromVectorRotation(AOVector a, AOVector b)
/*     */   {
/* 194 */     AOVector aDir = new AOVector(a).normalize();
/* 195 */     AOVector bDir = new AOVector(b).normalize();
/* 196 */     AOVector cross = AOVector.cross(aDir, bDir);
/* 197 */     float crossLen = cross.length();
/*     */ 
/* 199 */     double theta = Math.asin(crossLen);
/*     */ 
/* 201 */     float dot = aDir.dotProduct(bDir);
/* 202 */     if (dot < 0.0F) {
/* 203 */       theta = 3.141592653589793D - theta;
/*     */     }
/* 205 */     if (crossLen < epsilon) {
/* 206 */       return Identity;
/*     */     }
/* 208 */     return fromAngleAxis(theta, cross.scale(1.0F / crossLen));
/*     */   }
/*     */ 
/*     */   public static Quaternion fromTwoVectors(AOVector u, AOVector v)
/*     */   {
/* 213 */     AOVector w = AOVector.cross(u, v);
/* 214 */     Quaternion q = new Quaternion(u.dotProduct(v), w.getX(), w.getY(), w.getZ());
/* 215 */     q._w += q.len();
/* 216 */     return q.normalize();
/*     */   }
/*     */ 
/*     */   public static Quaternion multiply(Quaternion left, Quaternion right)
/*     */   {
/* 229 */     Quaternion q = new Quaternion();
/*     */ 
/* 231 */     q._w = (left._w * right._w - left._x * right._x - left._y * right._y - left._z * right._z);
/*     */ 
/* 233 */     q._x = (left._w * right._x + left._x * right._w + left._y * right._z - left._z * right._y);
/*     */ 
/* 235 */     q._y = (left._w * right._y + left._y * right._w + left._z * right._x - left._x * right._z);
/*     */ 
/* 237 */     q._z = (left._w * right._z + left._z * right._w + left._x * right._y - left._y * right._x);
/*     */ 
/* 239 */     return q;
/*     */   }
/*     */ 
/*     */   public static AOVector multiply(Quaternion quat, AOVector vector)
/*     */   {
/* 247 */     AOVector qvec = new AOVector(quat._x, quat._y, quat._z);
/* 248 */     AOVector uv = AOVector.cross(qvec, vector);
/* 249 */     AOVector uuv = AOVector.cross(qvec, uv);
/* 250 */     uv.multiply(2.0F * quat._w);
/* 251 */     uuv.multiply(2.0F);
/* 252 */     return AOVector.add(vector, AOVector.add(uv, uuv));
/*     */   }
/*     */ 
/*     */   public Quaternion setEulerAngles(float pitch, float yaw, float roll)
/*     */   {
/* 262 */     return setEulerAnglesRad((float)Math.toRadians(pitch), (float)Math.toRadians(yaw), (float)Math.toRadians(roll));
/*     */   }
/*     */ 
/*     */   public Quaternion setEulerAnglesRad(float pitch, float yaw, float roll)
/*     */   {
/* 272 */     float hr = roll * 0.5F;
/* 273 */     float shr = (float)Math.sin(hr);
/* 274 */     float chr = (float)Math.cos(hr);
/* 275 */     float hp = pitch * 0.5F;
/* 276 */     float shp = (float)Math.sin(hp);
/* 277 */     float chp = (float)Math.cos(hp);
/* 278 */     float hy = yaw * 0.5F;
/* 279 */     float shy = (float)Math.sin(hy);
/* 280 */     float chy = (float)Math.cos(hy);
/* 281 */     float chy_shp = chy * shp;
/* 282 */     float shy_chp = shy * chp;
/* 283 */     float chy_chp = chy * chp;
/* 284 */     float shy_shp = shy * shp;
/*     */ 
/* 286 */     this._x = (chy_shp * chr + shy_chp * shr);
/* 287 */     this._y = (shy_chp * chr - chy_shp * shr);
/* 288 */     this._z = (chy_chp * shr - shy_shp * chr);
/* 289 */     this._w = (chy_chp * chr + shy_shp * shr);
/* 290 */     return this;
/*     */   }
/*     */ 
/*     */   public int getGimbalPole()
/*     */   {
/* 296 */     float t = this._y * this._x + this._z * this._w;
/* 297 */     return t < -0.499F ? -1 : t > 0.499F ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public float getRollRad()
/*     */   {
/* 303 */     int pole = getGimbalPole();
/* 304 */     return (float)(pole == 0 ? Math.atan2(2.0F * (this._w * this._z + this._y * this._x), 1.0F - 2.0F * (this._x * this._x + this._z * this._z)) : pole * 2.0F * Math.atan2(this._y, this._w));
/*     */   }
/*     */ 
/*     */   public float getRoll()
/*     */   {
/* 310 */     return (float)Math.toDegrees(getRollRad());
/*     */   }
/*     */ 
/*     */   public float getPitchRad()
/*     */   {
/* 316 */     int pole = getGimbalPole();
/* 317 */     return (float)(pole == 0 ? (float)Math.asin(clamp(2.0F * (this._w * this._x - this._z * this._y), -1.0F, 1.0F)) : pole * 3.141592653589793D * 0.5D);
/*     */   }
/*     */ 
/*     */   public float getPitch()
/*     */   {
/* 323 */     return (float)Math.toDegrees(getPitchRad());
/*     */   }
/*     */ 
/*     */   public float getYawRad()
/*     */   {
/* 329 */     return (float)(getGimbalPole() == 0 ? Math.atan2(2.0F * (this._y * this._w + this._x * this._z), 1.0F - 2.0F * (this._y * this._y + this._x * this._x)) : 0.0D);
/*     */   }
/*     */ 
/*     */   public float getYaw()
/*     */   {
/* 335 */     return (float)Math.toDegrees(getYawRad());
/*     */   }
/*     */ 
/*     */   public static float clamp(float value, float min, float max) {
/* 339 */     if (value < min) return min;
/* 340 */     if (value > max) return max;
/* 341 */     return value;
/*     */   }
/*     */ 
/*     */   public float len()
/*     */   {
/* 348 */     return (float)Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
/*     */   }
/*     */ 
/*     */   public float len2()
/*     */   {
/* 355 */     return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
/*     */   }
/*     */ 
/*     */   public Quaternion normalize()
/*     */   {
/* 363 */     float len = len2();
/* 364 */     if ((len != 0.0F) && (len != 1.0F)) {
/* 365 */       len = (float)Math.sqrt(len);
/* 366 */       this._w /= len;
/* 367 */       this._x /= len;
/* 368 */       this._y /= len;
/* 369 */       this._z /= len;
/*     */     }
/* 371 */     return this;
/*     */   }
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 382 */     out.writeFloat(this._x);
/* 383 */     out.writeFloat(this._y);
/* 384 */     out.writeFloat(this._z);
/* 385 */     out.writeFloat(this._w);
/*     */   }
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 396 */     this._x = in.readFloat();
/* 397 */     this._y = in.readFloat();
/* 398 */     this._z = in.readFloat();
/* 399 */     this._w = in.readFloat();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.Quaternion
 * JD-Core Version:    0.6.0
 */