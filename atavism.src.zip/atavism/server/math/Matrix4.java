/*     */ package atavism.server.math;
/*     */ 
/*     */ public class Matrix4
/*     */   implements Comparable<Matrix4>, Cloneable
/*     */ {
/*   6 */   private float[][] _data = new float[4][4];
/*     */ 
/*     */   public Matrix4() {
/*   9 */     this._data[0][0] = 1.0F;
/*  10 */     this._data[1][1] = 1.0F;
/*  11 */     this._data[2][2] = 1.0F;
/*  12 */     this._data[3][3] = 1.0F;
/*     */   }
/*     */ 
/*     */   public Matrix4(float m00, float m01, float m02, float m03, float m10, float m11, float m12, float m13, float m20, float m21, float m22, float m23, float m30, float m31, float m32, float m33)
/*     */   {
/*  19 */     this._data[0][0] = m00;
/*  20 */     this._data[0][1] = m01;
/*  21 */     this._data[0][2] = m02;
/*  22 */     this._data[0][3] = m03;
/*     */ 
/*  24 */     this._data[1][0] = m10;
/*  25 */     this._data[1][1] = m11;
/*  26 */     this._data[1][2] = m12;
/*  27 */     this._data[1][3] = m13;
/*     */ 
/*  29 */     this._data[2][0] = m20;
/*  30 */     this._data[2][1] = m21;
/*  31 */     this._data[2][2] = m22;
/*  32 */     this._data[2][3] = m23;
/*     */ 
/*  34 */     this._data[3][0] = m30;
/*  35 */     this._data[3][1] = m31;
/*  36 */     this._data[3][2] = m32;
/*  37 */     this._data[3][3] = m33;
/*     */   }
/*     */ 
/*     */   public Object clone() {
/*  41 */     Matrix4 rv = new Matrix4();
/*  42 */     rv.assign(this);
/*  43 */     return rv;
/*     */   }
/*     */ 
/*     */   public float get(int row, int column) {
/*  47 */     return this._data[row][column];
/*     */   }
/*     */ 
/*     */   public void set(int row, int column, float val) {
/*  51 */     this._data[row][column] = val;
/*     */   }
/*     */ 
/*     */   public Matrix4 translate(AOVector vec) {
/*  55 */     this._data[0][3] += vec.getX();
/*  56 */     this._data[1][3] += vec.getY();
/*  57 */     this._data[2][3] += vec.getZ();
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   public Matrix4 rotate(Quaternion rot) {
/*  62 */     Matrix4 rotMatrix = fromRotation(rot);
/*  63 */     assign(rotMatrix.multiply(this));
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */   private static Matrix4 multiplyRef(Matrix4 result, Matrix4 left, Matrix4 right)
/*     */   {
/*  76 */     result._data[0][0] = (left._data[0][0] * right._data[0][0] + left._data[0][1] * right._data[1][0] + left._data[0][2] * right._data[2][0] + left._data[0][3] * right._data[3][0]);
/*  77 */     result._data[0][1] = (left._data[0][0] * right._data[0][1] + left._data[0][1] * right._data[1][1] + left._data[0][2] * right._data[2][1] + left._data[0][3] * right._data[3][1]);
/*  78 */     result._data[0][2] = (left._data[0][0] * right._data[0][2] + left._data[0][1] * right._data[1][2] + left._data[0][2] * right._data[2][2] + left._data[0][3] * right._data[3][2]);
/*  79 */     result._data[0][3] = (left._data[0][0] * right._data[0][3] + left._data[0][1] * right._data[1][3] + left._data[0][2] * right._data[2][3] + left._data[0][3] * right._data[3][3]);
/*     */ 
/*  81 */     result._data[1][0] = (left._data[1][0] * right._data[0][0] + left._data[1][1] * right._data[1][0] + left._data[1][2] * right._data[2][0] + left._data[1][3] * right._data[3][0]);
/*  82 */     result._data[1][1] = (left._data[1][0] * right._data[0][1] + left._data[1][1] * right._data[1][1] + left._data[1][2] * right._data[2][1] + left._data[1][3] * right._data[3][1]);
/*  83 */     result._data[1][2] = (left._data[1][0] * right._data[0][2] + left._data[1][1] * right._data[1][2] + left._data[1][2] * right._data[2][2] + left._data[1][3] * right._data[3][2]);
/*  84 */     result._data[1][3] = (left._data[1][0] * right._data[0][3] + left._data[1][1] * right._data[1][3] + left._data[1][2] * right._data[2][3] + left._data[1][3] * right._data[3][3]);
/*     */ 
/*  86 */     result._data[2][0] = (left._data[2][0] * right._data[0][0] + left._data[2][1] * right._data[1][0] + left._data[2][2] * right._data[2][0] + left._data[2][3] * right._data[3][0]);
/*  87 */     result._data[2][1] = (left._data[2][0] * right._data[0][1] + left._data[2][1] * right._data[1][1] + left._data[2][2] * right._data[2][1] + left._data[2][3] * right._data[3][1]);
/*  88 */     result._data[2][2] = (left._data[2][0] * right._data[0][2] + left._data[2][1] * right._data[1][2] + left._data[2][2] * right._data[2][2] + left._data[2][3] * right._data[3][2]);
/*  89 */     result._data[2][3] = (left._data[2][0] * right._data[0][3] + left._data[2][1] * right._data[1][3] + left._data[2][2] * right._data[2][3] + left._data[2][3] * right._data[3][3]);
/*     */ 
/*  91 */     result._data[3][0] = (left._data[3][0] * right._data[0][0] + left._data[3][1] * right._data[1][0] + left._data[3][2] * right._data[2][0] + left._data[3][3] * right._data[3][0]);
/*  92 */     result._data[3][1] = (left._data[3][0] * right._data[0][1] + left._data[3][1] * right._data[1][1] + left._data[3][2] * right._data[2][1] + left._data[3][3] * right._data[3][1]);
/*  93 */     result._data[3][2] = (left._data[3][0] * right._data[0][2] + left._data[3][1] * right._data[1][2] + left._data[3][2] * right._data[2][2] + left._data[3][3] * right._data[3][2]);
/*  94 */     result._data[3][3] = (left._data[3][0] * right._data[0][3] + left._data[3][1] * right._data[1][3] + left._data[3][2] * right._data[2][3] + left._data[3][3] * right._data[3][3]);
/*     */ 
/*  96 */     return result;
/*     */   }
/*     */ 
/*     */   private static Matrix4 multiplyRef(Matrix4 result, float scalar, Matrix4 transform)
/*     */   {
/* 108 */     result._data[0][0] = (scalar * transform._data[0][0]);
/* 109 */     result._data[0][1] = (scalar * transform._data[0][1]);
/* 110 */     result._data[0][2] = (scalar * transform._data[0][2]);
/* 111 */     result._data[0][3] = (scalar * transform._data[0][3]);
/*     */ 
/* 113 */     result._data[1][0] = (scalar * transform._data[1][0]);
/* 114 */     result._data[1][1] = (scalar * transform._data[1][1]);
/* 115 */     result._data[1][2] = (scalar * transform._data[1][2]);
/* 116 */     result._data[1][3] = (scalar * transform._data[1][3]);
/*     */ 
/* 118 */     result._data[2][0] = (scalar * transform._data[2][0]);
/* 119 */     result._data[2][1] = (scalar * transform._data[2][1]);
/* 120 */     result._data[2][2] = (scalar * transform._data[2][2]);
/* 121 */     result._data[2][3] = (scalar * transform._data[2][3]);
/*     */ 
/* 123 */     result._data[3][0] = (scalar * transform._data[3][0]);
/* 124 */     result._data[3][1] = (scalar * transform._data[3][1]);
/* 125 */     result._data[3][2] = (scalar * transform._data[3][2]);
/* 126 */     result._data[3][3] = (scalar * transform._data[3][3]);
/*     */ 
/* 128 */     return result;
/*     */   }
/*     */ 
/*     */   public static Matrix4 multiply(Matrix4 left, Matrix4 right) {
/* 132 */     Matrix4 result = new Matrix4();
/* 133 */     return multiplyRef(result, left, right);
/*     */   }
/*     */ 
/*     */   public Matrix4 multiply(Matrix4 other) {
/* 137 */     assign(multiply(this, other));
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */   public static Matrix4 multiply(float scalar, Matrix4 transform) {
/* 142 */     return multiplyRef(transform, scalar, transform);
/*     */   }
/*     */ 
/*     */   public Matrix4 multiply(float scalar) {
/* 146 */     return multiplyRef(this, scalar, this);
/*     */   }
/*     */ 
/*     */   public static AOVector multiply(Matrix4 matrix, AOVector vector) {
/* 150 */     float inverseW = 1.0F / (matrix._data[3][0] + matrix._data[3][1] + matrix._data[3][2] + matrix._data[3][3]);
/* 151 */     float x = (matrix._data[0][0] * vector.getX() + matrix._data[0][1] * vector.getY() + matrix._data[0][2] * vector.getZ() + matrix._data[0][3]) * inverseW;
/* 152 */     float y = (matrix._data[1][0] * vector.getX() + matrix._data[1][1] * vector.getY() + matrix._data[1][2] * vector.getZ() + matrix._data[1][3]) * inverseW;
/* 153 */     float z = (matrix._data[2][0] * vector.getX() + matrix._data[2][1] * vector.getY() + matrix._data[2][2] * vector.getZ() + matrix._data[2][3]) * inverseW;
/*     */ 
/* 155 */     return new AOVector(x, y, z);
/*     */   }
/*     */ 
/*     */   public static Plane multiply(Matrix4 transform, Plane plane) {
/* 159 */     AOVector planeNormal = plane.getNormal();
/* 160 */     AOVector planePoint = (AOVector)(AOVector)planeNormal.clone();
/* 161 */     planePoint.scale(-1.0F * plane.getD());
/* 162 */     AOVector newPoint = multiply(transform, planePoint);
/* 163 */     AOVector newPointPlusNormal = multiply(transform, AOVector.add(planePoint, planeNormal));
/* 164 */     AOVector newNormal = AOVector.sub(newPointPlusNormal, newPoint).normalize();
/*     */ 
/* 166 */     return new Plane(newNormal, newPoint);
/*     */   }
/*     */ 
/*     */   public boolean equals(Matrix4 other) {
/* 170 */     return compareTo(other) == 0;
/*     */   }
/*     */ 
/*     */   public int compareTo(Matrix4 other) {
/* 174 */     if (this == other) {
/* 175 */       return 0;
/*     */     }
/* 177 */     for (int i = 0; i < 4; i++) {
/* 178 */       for (int j = 0; j < 4; j++) {
/* 179 */         if (this._data[i][j] != other._data[i][j]) {
/* 180 */           return this._data[i][j] < other._data[i][j] ? -1 : 1;
/*     */         }
/*     */       }
/*     */     }
/* 184 */     return 0;
/*     */   }
/*     */ 
/*     */   public static Matrix4 fromRotation(Quaternion rot) {
/* 188 */     Matrix4 rv = new Matrix4();
/* 189 */     rv.setRotation(rot);
/* 190 */     return rv;
/*     */   }
/*     */ 
/*     */   public static Matrix4 fromTranslation(AOVector vec) {
/* 194 */     Matrix4 rv = new Matrix4();
/* 195 */     rv.setTranslation(vec);
/* 196 */     return rv;
/*     */   }
/*     */ 
/*     */   public AOVector getTranslation() {
/* 200 */     return new AOVector(this._data[0][3], this._data[1][3], this._data[2][3]);
/*     */   }
/*     */ 
/*     */   public void setTranslation(AOVector vec) {
/* 204 */     this._data[0][3] = vec.getX();
/* 205 */     this._data[1][3] = vec.getY();
/* 206 */     this._data[2][3] = vec.getZ();
/*     */   }
/*     */ 
/*     */   public void setRotation(Quaternion rot)
/*     */   {
/* 215 */     float tx = 2.0F * rot.getX();
/* 216 */     float ty = 2.0F * rot.getY();
/* 217 */     float tz = 2.0F * rot.getZ();
/* 218 */     float twx = tx * rot.getW();
/* 219 */     float twy = ty * rot.getW();
/* 220 */     float twz = tz * rot.getW();
/* 221 */     float txx = tx * rot.getX();
/* 222 */     float txy = ty * rot.getX();
/* 223 */     float txz = tz * rot.getX();
/* 224 */     float tyy = ty * rot.getY();
/* 225 */     float tyz = tz * rot.getY();
/* 226 */     float tzz = tz * rot.getZ();
/*     */ 
/* 228 */     this._data[0][0] = (1.0F - (tyy + tzz));
/* 229 */     this._data[0][1] = (txy - twz);
/* 230 */     this._data[0][2] = (txz + twy);
/* 231 */     this._data[1][0] = (txy + twz);
/* 232 */     this._data[1][1] = (1.0F - (txx + tzz));
/* 233 */     this._data[1][2] = (tyz - twx);
/* 234 */     this._data[2][0] = (txz - twy);
/* 235 */     this._data[2][1] = (tyz + twx);
/* 236 */     this._data[2][2] = (1.0F - (txx + tyy));
/*     */   }
/*     */ 
/*     */   private Matrix4 getAdjoint() {
/* 240 */     float val0 = this._data[1][1] * (this._data[2][2] * this._data[3][3] - this._data[3][2] * this._data[2][3]) - this._data[1][2] * (this._data[2][1] * this._data[3][3] - this._data[3][1] * this._data[2][3]) + this._data[1][3] * (this._data[2][1] * this._data[3][2] - this._data[3][1] * this._data[2][2]);
/* 241 */     float val1 = -(this._data[0][1] * (this._data[2][2] * this._data[3][3] - this._data[3][2] * this._data[2][3]) - this._data[0][2] * (this._data[2][1] * this._data[3][3] - this._data[3][1] * this._data[2][3]) + this._data[0][3] * (this._data[2][1] * this._data[3][2] - this._data[3][1] * this._data[2][2]));
/* 242 */     float val2 = this._data[0][1] * (this._data[1][2] * this._data[3][3] - this._data[3][2] * this._data[1][3]) - this._data[0][2] * (this._data[1][1] * this._data[3][3] - this._data[3][1] * this._data[1][3]) + this._data[0][3] * (this._data[1][1] * this._data[3][2] - this._data[3][1] * this._data[1][2]);
/* 243 */     float val3 = -(this._data[0][1] * (this._data[1][2] * this._data[2][3] - this._data[2][2] * this._data[1][3]) - this._data[0][2] * (this._data[1][1] * this._data[2][3] - this._data[2][1] * this._data[1][3]) + this._data[0][3] * (this._data[1][1] * this._data[2][2] - this._data[2][1] * this._data[1][2]));
/* 244 */     float val4 = -(this._data[1][0] * (this._data[2][2] * this._data[3][3] - this._data[3][2] * this._data[2][3]) - this._data[1][2] * (this._data[2][0] * this._data[3][3] - this._data[3][0] * this._data[2][3]) + this._data[1][3] * (this._data[2][0] * this._data[3][2] - this._data[3][0] * this._data[2][2]));
/* 245 */     float val5 = this._data[0][0] * (this._data[2][2] * this._data[3][3] - this._data[3][2] * this._data[2][3]) - this._data[0][2] * (this._data[2][0] * this._data[3][3] - this._data[3][0] * this._data[2][3]) + this._data[0][3] * (this._data[2][0] * this._data[3][2] - this._data[3][0] * this._data[2][2]);
/* 246 */     float val6 = -(this._data[0][0] * (this._data[1][2] * this._data[3][3] - this._data[3][2] * this._data[1][3]) - this._data[0][2] * (this._data[1][0] * this._data[3][3] - this._data[3][0] * this._data[1][3]) + this._data[0][3] * (this._data[1][0] * this._data[3][2] - this._data[3][0] * this._data[1][2]));
/* 247 */     float val7 = this._data[0][0] * (this._data[1][2] * this._data[2][3] - this._data[2][2] * this._data[1][3]) - this._data[0][2] * (this._data[1][0] * this._data[2][3] - this._data[2][0] * this._data[1][3]) + this._data[0][3] * (this._data[1][0] * this._data[2][2] - this._data[2][0] * this._data[1][2]);
/* 248 */     float val8 = this._data[1][0] * (this._data[2][1] * this._data[3][3] - this._data[3][1] * this._data[2][3]) - this._data[1][1] * (this._data[2][0] * this._data[3][3] - this._data[3][0] * this._data[2][3]) + this._data[1][3] * (this._data[2][0] * this._data[3][1] - this._data[3][0] * this._data[2][1]);
/* 249 */     float val9 = -(this._data[0][0] * (this._data[2][1] * this._data[3][3] - this._data[3][1] * this._data[2][3]) - this._data[0][1] * (this._data[2][0] * this._data[3][3] - this._data[3][0] * this._data[2][3]) + this._data[0][3] * (this._data[2][0] * this._data[3][1] - this._data[3][0] * this._data[2][1]));
/* 250 */     float val10 = this._data[0][0] * (this._data[1][1] * this._data[3][3] - this._data[3][1] * this._data[1][3]) - this._data[0][1] * (this._data[1][0] * this._data[3][3] - this._data[3][0] * this._data[1][3]) + this._data[0][3] * (this._data[1][0] * this._data[3][1] - this._data[3][0] * this._data[1][1]);
/* 251 */     float val11 = -(this._data[0][0] * (this._data[1][1] * this._data[2][3] - this._data[2][1] * this._data[1][3]) - this._data[0][1] * (this._data[1][0] * this._data[2][3] - this._data[2][0] * this._data[1][3]) + this._data[0][3] * (this._data[1][0] * this._data[2][1] - this._data[2][0] * this._data[1][1]));
/* 252 */     float val12 = -(this._data[1][0] * (this._data[2][1] * this._data[3][2] - this._data[3][1] * this._data[2][2]) - this._data[1][1] * (this._data[2][0] * this._data[3][2] - this._data[3][0] * this._data[2][2]) + this._data[1][2] * (this._data[2][0] * this._data[3][1] - this._data[3][0] * this._data[2][1]));
/* 253 */     float val13 = this._data[0][0] * (this._data[2][1] * this._data[3][2] - this._data[3][1] * this._data[2][2]) - this._data[0][1] * (this._data[2][0] * this._data[3][2] - this._data[3][0] * this._data[2][2]) + this._data[0][2] * (this._data[2][0] * this._data[3][1] - this._data[3][0] * this._data[2][1]);
/* 254 */     float val14 = -(this._data[0][0] * (this._data[1][1] * this._data[3][2] - this._data[3][1] * this._data[1][2]) - this._data[0][1] * (this._data[1][0] * this._data[3][2] - this._data[3][0] * this._data[1][2]) + this._data[0][2] * (this._data[1][0] * this._data[3][1] - this._data[3][0] * this._data[1][1]));
/* 255 */     float val15 = this._data[0][0] * (this._data[1][1] * this._data[2][2] - this._data[2][1] * this._data[1][2]) - this._data[0][1] * (this._data[1][0] * this._data[2][2] - this._data[2][0] * this._data[1][2]) + this._data[0][2] * (this._data[1][0] * this._data[2][1] - this._data[2][0] * this._data[1][1]);
/* 256 */     return new Matrix4(val0, val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11, val12, val13, val14, val15);
/*     */   }
/*     */ 
/*     */   public Matrix4 getInverse() {
/* 260 */     Matrix4 adjoint = getAdjoint();
/* 261 */     return multiply(1.0F / getDeterminant(), adjoint);
/*     */   }
/*     */ 
/*     */   public float getDeterminant() {
/* 265 */     float result = this._data[0][0] * (this._data[1][1] * (this._data[2][2] * this._data[3][3] - this._data[3][2] * this._data[2][3]) - this._data[1][2] * (this._data[2][1] * this._data[3][3] - this._data[3][1] * this._data[2][3]) + this._data[1][3] * (this._data[2][1] * this._data[3][2] - this._data[3][1] * this._data[2][2])) - this._data[0][1] * (this._data[1][0] * (this._data[2][2] * this._data[3][3] - this._data[3][2] * this._data[2][3]) - this._data[1][2] * (this._data[2][0] * this._data[3][3] - this._data[3][0] * this._data[2][3]) + this._data[1][3] * (this._data[2][0] * this._data[3][2] - this._data[3][0] * this._data[2][2])) + this._data[0][2] * (this._data[1][0] * (this._data[2][1] * this._data[3][3] - this._data[3][1] * this._data[2][3]) - this._data[1][1] * (this._data[2][0] * this._data[3][3] - this._data[3][0] * this._data[2][3]) + this._data[1][3] * (this._data[2][0] * this._data[3][1] - this._data[3][0] * this._data[2][1])) - this._data[0][3] * (this._data[1][0] * (this._data[2][1] * this._data[3][2] - this._data[3][1] * this._data[2][2]) - this._data[1][1] * (this._data[2][0] * this._data[3][2] - this._data[3][0] * this._data[2][2]) + this._data[1][2] * (this._data[2][0] * this._data[3][1] - this._data[3][0] * this._data[2][1]));
/*     */ 
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */   private void assign(Matrix4 other) {
/* 273 */     if (this == other) {
/* 274 */       return;
/*     */     }
/* 276 */     for (int i = 0; i < 4; i++)
/* 277 */       for (int j = 0; j < 4; j++)
/* 278 */         this._data[i][j] = other._data[i][j];
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 284 */     StringBuilder sb = new StringBuilder();
/* 285 */     sb.append("[");
/* 286 */     for (int i = 0; i < 4; i++) {
/* 287 */       if (i == 0)
/* 288 */         sb.append("\n[");
/*     */       else
/* 290 */         sb.append(" ");
/* 291 */       for (int j = 0; j < 4; j++) {
/* 292 */         if (j != 0) {
/* 293 */           sb.append(" ");
/*     */         }
/* 295 */         sb.append(this._data[i][j]);
/*     */       }
/* 297 */       if (i == 3)
/* 298 */         sb.append("]\n");
/*     */       else {
/* 300 */         sb.append("\n");
/*     */       }
/*     */     }
/* 303 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.Matrix4
 * JD-Core Version:    0.6.0
 */