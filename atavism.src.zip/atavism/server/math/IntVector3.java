/*     */ package atavism.server.math;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class IntVector3
/*     */   implements Externalizable
/*     */ {
/*  77 */   public static final IntVector3 UnitZ = new IntVector3(0, 0, 1);
/*  78 */   public static final IntVector3 Zero = new IntVector3(0, 0, 0);
/*     */ 
/* 277 */   private int _x = 0;
/* 278 */   private int _y = 0;
/* 279 */   private int _z = 0;
/*     */ 
/* 281 */   public static float epsilon = 0.001F;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public IntVector3()
/*     */   {
/*     */   }
/*     */ 
/*     */   public IntVector3(int x, int y, int z)
/*     */   {
/*  13 */     this._x = x;
/*  14 */     this._y = y;
/*  15 */     this._z = z;
/*     */   }
/*     */ 
/*     */   public Object clone() {
/*  19 */     IntVector3 o = new IntVector3(getX(), getY(), getZ());
/*  20 */     return o;
/*     */   }
/*     */ 
/*     */   public IntVector3 cloneAOVector() {
/*  24 */     IntVector3 o = new IntVector3(getX(), getY(), getZ());
/*  25 */     return o;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  30 */     IntVector3 other = (IntVector3)obj;
/*  31 */     return (this._x == other._x) && (this._y == other._y) && (this._z == other._z);
/*     */   }
/*     */ 
/*     */   public void assign(IntVector3 source) {
/*  35 */     this._x = source.getX();
/*  36 */     this._y = source.getY();
/*  37 */     this._z = source.getZ();
/*     */   }
/*     */ 
/*     */   public static int distanceTo(IntVector3 p1, IntVector3 p2)
/*     */   {
/*  44 */     int dx = p2.getX() - p1.getX();
/*  45 */     int dz = p2.getZ() - p1.getZ();
/*  46 */     return (int)Math.sqrt(dx * dx + dz * dz);
/*     */   }
/*     */ 
/*     */   public static int distanceToSquared(IntVector3 p1, IntVector3 p2)
/*     */   {
/*  53 */     int dx = p2.getX() - p1.getX();
/*  54 */     int dz = p2.getZ() - p1.getZ();
/*  55 */     return dx * dx + dz * dz;
/*     */   }
/*     */ 
/*     */   public static IntVector3 add(IntVector3 p1, IntVector3 p2) {
/*  59 */     return new IntVector3(p1._x + p2._x, p1._y + p2._y, p1._z + p2._z);
/*     */   }
/*     */ 
/*     */   public boolean isZero()
/*     */   {
/*  64 */     return (this._x == 0) && (this._y == 0) && (this._z == 0);
/*     */   }
/*     */ 
/*     */   public IntVector3 normalize()
/*     */   {
/*  70 */     int len = length();
/*     */ 
/*  72 */     if (len > epsilon)
/*  73 */       scale(1 / len);
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 add(IntVector3 other)
/*     */   {
/*  81 */     this._x += other.getX();
/*  82 */     this._y += other.getY();
/*  83 */     this._z += other.getZ();
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 add(Point other) {
/*  88 */     this._x = (int)(this._x + other.getX());
/*  89 */     this._y = (int)(this._y + other.getY());
/*  90 */     this._z = (int)(this._z + other.getZ());
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 add(int x, int y, int z) {
/*  95 */     this._x += x;
/*  96 */     this._y += y;
/*  97 */     this._z += z;
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 sub(IntVector3 other) {
/* 102 */     this._x -= other.getX();
/* 103 */     this._y -= other.getY();
/* 104 */     this._z -= other.getZ();
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 sub(Point other) {
/* 109 */     this._x = (int)(this._x - other.getX());
/* 110 */     this._y = (int)(this._y - other.getY());
/* 111 */     this._z = (int)(this._z - other.getZ());
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 sub(int x, int y, int z) {
/* 116 */     this._x -= x;
/* 117 */     this._y -= y;
/* 118 */     this._z -= z;
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 multiply(int factor) {
/* 123 */     this._x *= factor;
/* 124 */     this._y *= factor;
/* 125 */     this._z *= factor;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   public IntVector3 plus(IntVector3 other)
/*     */   {
/* 136 */     IntVector3 p = (IntVector3)clone();
/* 137 */     p.add(other);
/* 138 */     return p;
/*     */   }
/*     */ 
/*     */   public IntVector3 minus(IntVector3 other)
/*     */   {
/* 148 */     IntVector3 p = (IntVector3)clone();
/* 149 */     p.sub(other);
/* 150 */     return p;
/*     */   }
/*     */ 
/*     */   public IntVector3 times(int factor) {
/* 154 */     IntVector3 p = (IntVector3)clone();
/* 155 */     p.multiply(factor);
/* 156 */     return p;
/*     */   }
/*     */ 
/*     */   public IntVector3 negate() {
/* 160 */     return new IntVector3(-this._x, -this._y, -this._z);
/*     */   }
/*     */ 
/*     */   public int length()
/*     */   {
/* 166 */     return (int)Math.sqrt(getX() * getX() + getY() * getY() + getZ() * getZ());
/*     */   }
/*     */ 
/*     */   public int lengthXZ()
/*     */   {
/* 173 */     return (int)Math.sqrt(getX() * getX() + getZ() * getZ());
/*     */   }
/*     */ 
/*     */   public int dotProduct(IntVector3 v)
/*     */   {
/* 179 */     return getX() * v.getX() + getY() * v.getY() + getZ() * v.getZ();
/*     */   }
/*     */ 
/*     */   public IntVector3 scale(int s)
/*     */   {
/* 184 */     this._x *= s;
/* 185 */     this._y *= s;
/* 186 */     this._z *= s;
/* 187 */     return this;
/*     */   }
/*     */ 
/*     */   public Quaternion getRotationTo(IntVector3 destination)
/*     */   {
/* 199 */     Quaternion q = new Quaternion();
/*     */ 
/* 201 */     IntVector3 v0 = new IntVector3(this._x, this._y, this._z);
/* 202 */     IntVector3 v1 = destination;
/*     */ 
/* 205 */     v0.normalize();
/* 206 */     v1.normalize();
/*     */ 
/* 209 */     IntVector3 c = cross(v0, v1);
/*     */ 
/* 214 */     int d = v0.dotProduct(v1);
/*     */ 
/* 217 */     if (d >= 1.0F)
/*     */     {
/* 219 */       return Quaternion.Identity;
/*     */     }
/* 221 */     if (Log.loggingDebug)
/* 222 */       Log.debug("IntVector3.getRotationTo: d=" + d);
/* 223 */     if (d < -0.99F)
/*     */     {
/* 225 */       return null;
/*     */     }
/* 227 */     int s = (int)Math.sqrt((1 + d) * 2);
/* 228 */     int inverse = 1 / s;
/*     */ 
/* 230 */     q.setX(c.getX() * inverse);
/* 231 */     q.setY(c.getY() * inverse);
/* 232 */     q.setZ(c.getZ() * inverse);
/* 233 */     q.setW(s * 0.5F);
/*     */ 
/* 235 */     return q;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 239 */     return "[x=" + getX() + ",y=" + getY() + ",z=" + getZ() + "]";
/*     */   }
/*     */   public int getX() {
/* 242 */     return this._x; } 
/* 243 */   public int getY() { return this._y; } 
/* 244 */   public int getZ() { return this._z; } 
/*     */   public void setX(int x) {
/* 246 */     this._x = x; } 
/* 247 */   public void setY(int y) { this._y = y; } 
/* 248 */   public void setZ(int z) { this._z = z;
/*     */   }
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 259 */     out.writeInt(this._x);
/* 260 */     out.writeInt(this._y);
/* 261 */     out.writeInt(this._z);
/*     */   }
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 272 */     this._x = in.readInt();
/* 273 */     this._y = in.readInt();
/* 274 */     this._z = in.readInt();
/*     */   }
/*     */ 
/*     */   public IntVector3(IntVector3 other)
/*     */   {
/* 286 */     this._x = other._x;
/* 287 */     this._y = other._y;
/* 288 */     this._z = other._z;
/*     */   }
/*     */ 
/*     */   public static IntVector3 cross(IntVector3 u, IntVector3 v)
/*     */   {
/* 293 */     int x = u._y * v._z - u._z * v._y;
/* 294 */     int y = u._z * v._x - u._x * v._z;
/* 295 */     int z = u._x * v._y - u._y * v._x;
/* 296 */     return new IntVector3(x, y, z);
/*     */   }
/*     */ 
/*     */   public static boolean counterClockwisePoints(IntVector3 v0, IntVector3 v1, IntVector3 v2) {
/* 300 */     return (v1._x - v0._x) * (v2._z - v0._z) - (v2._x - v0._x) * (v1._z - v0._z) > 0;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 306 */     IntVector3 v = new IntVector3(4, 3, 0);
/* 307 */     int len = v.length();
/* 308 */     System.out.println("length of " + v + " should be 5.. result=" + len);
/*     */ 
/* 310 */     v.normalize();
/* 311 */     System.out.println("normal should be 0.8 0.6 0 - result is " + v);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.IntVector3
 * JD-Core Version:    0.6.0
 */