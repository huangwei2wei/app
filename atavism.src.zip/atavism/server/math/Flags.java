/*   */ package atavism.server.math;
/*   */ 
/*   */ public class Flags
/*   */ {
/* 4 */   public static short SHORT_FLAG = -1;
/* 5 */   public static int INT_FLAG = -1;
/* 6 */   public static long LONG_FLAG = -1L;
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.Flags
 * JD-Core Version:    0.6.0
 */