/*     */ package atavism.server.math;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class AOVector
/*     */   implements Externalizable
/*     */ {
/*  79 */   public static final AOVector UnitZ = new AOVector(0.0F, 0.0F, 1.0F);
/*  80 */   public static final AOVector Zero = new AOVector(0.0F, 0.0F, 0.0F);
/*     */ 
/* 286 */   private float _x = 0.0F;
/* 287 */   private float _y = 0.0F;
/* 288 */   private float _z = 0.0F;
/*     */ 
/* 290 */   public static float epsilon = 0.001F;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public AOVector()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AOVector(float x, float y, float z)
/*     */   {
/*  13 */     this._x = x;
/*  14 */     this._y = y;
/*  15 */     this._z = z;
/*     */   }
/*     */ 
/*     */   public AOVector(Point other) {
/*  19 */     this._x = other.getX();
/*  20 */     this._y = other.getY();
/*  21 */     this._z = other.getZ();
/*     */   }
/*     */ 
/*     */   public Object clone() {
/*  25 */     AOVector o = new AOVector(getX(), getY(), getZ());
/*  26 */     return o;
/*     */   }
/*     */ 
/*     */   public AOVector cloneAOVector() {
/*  30 */     AOVector o = new AOVector(getX(), getY(), getZ());
/*  31 */     return o;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  36 */     AOVector other = (AOVector)obj;
/*  37 */     return (this._x == other._x) && (this._y == other._y) && (this._z == other._z);
/*     */   }
/*     */ 
/*     */   public void assign(AOVector source) {
/*  41 */     this._x = source.getX();
/*  42 */     this._y = source.getY();
/*  43 */     this._z = source.getZ();
/*     */   }
/*     */ 
/*     */   public static float distanceTo(AOVector p1, AOVector p2)
/*     */   {
/*  50 */     float dx = p2.getX() - p1.getX();
/*  51 */     float dz = p2.getZ() - p1.getZ();
/*  52 */     return (float)Math.sqrt(dx * dx + dz * dz);
/*     */   }
/*     */ 
/*     */   public static float distanceToSquared(AOVector p1, AOVector p2)
/*     */   {
/*  59 */     float dx = p2.getX() - p1.getX();
/*  60 */     float dz = p2.getZ() - p1.getZ();
/*  61 */     return dx * dx + dz * dz;
/*     */   }
/*     */ 
/*     */   public boolean isZero()
/*     */   {
/*  66 */     return (this._x == 0.0F) && (this._y == 0.0F) && (this._z == 0.0F);
/*     */   }
/*     */ 
/*     */   public AOVector normalize()
/*     */   {
/*  72 */     float len = length();
/*     */ 
/*  74 */     if (len > epsilon)
/*  75 */       scale(1.0F / len);
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector add(AOVector other)
/*     */   {
/*  83 */     this._x += other.getX();
/*  84 */     this._y += other.getY();
/*  85 */     this._z += other.getZ();
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector add(Point other) {
/*  90 */     this._x += other.getX();
/*  91 */     this._y += other.getY();
/*  92 */     this._z += other.getZ();
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector add(float x, float y, float z) {
/*  97 */     this._x += x;
/*  98 */     this._y += y;
/*  99 */     this._z += z;
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector sub(AOVector other) {
/* 104 */     this._x -= other.getX();
/* 105 */     this._y -= other.getY();
/* 106 */     this._z -= other.getZ();
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector sub(Point other) {
/* 111 */     this._x -= other.getX();
/* 112 */     this._y -= other.getY();
/* 113 */     this._z -= other.getZ();
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector sub(float x, float y, float z) {
/* 118 */     this._x -= x;
/* 119 */     this._y -= y;
/* 120 */     this._z -= z;
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector multiply(float factor) {
/* 125 */     this._x *= factor;
/* 126 */     this._y *= factor;
/* 127 */     this._z *= factor;
/* 128 */     return this;
/*     */   }
/*     */ 
/*     */   public AOVector negate() {
/* 132 */     return new AOVector(-this._x, -this._y, -this._z);
/*     */   }
/*     */ 
/*     */   public float length()
/*     */   {
/* 138 */     return (float)Math.sqrt(getX() * getX() + getY() * getY() + getZ() * getZ());
/*     */   }
/*     */ 
/*     */   public float lengthXZ()
/*     */   {
/* 145 */     return (float)Math.sqrt(getX() * getX() + getZ() * getZ());
/*     */   }
/*     */ 
/*     */   public float dotProduct(AOVector v)
/*     */   {
/* 151 */     return getX() * v.getX() + getY() * v.getY() + getZ() * v.getZ();
/*     */   }
/*     */ 
/*     */   public AOVector scale(float s)
/*     */   {
/* 156 */     this._x *= s;
/* 157 */     this._y *= s;
/* 158 */     this._z *= s;
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */   public Quaternion getRotationTo(AOVector destination)
/*     */   {
/* 171 */     Quaternion q = new Quaternion();
/*     */ 
/* 173 */     AOVector v0 = new AOVector(this._x, this._y, this._z);
/* 174 */     AOVector v1 = destination;
/*     */ 
/* 177 */     v0.normalize();
/* 178 */     v1.normalize();
/*     */ 
/* 181 */     AOVector c = cross(v0, v1);
/*     */ 
/* 186 */     float d = v0.dotProduct(v1);
/*     */ 
/* 189 */     if (d >= 1.0F)
/*     */     {
/* 191 */       return Quaternion.Identity;
/*     */     }
/* 193 */     if (Log.loggingDebug)
/* 194 */       Log.debug("AOVector.getRotationTo: d=" + d);
/* 195 */     if (d < -0.99F)
/*     */     {
/* 197 */       return null;
/*     */     }
/* 199 */     float s = (float)Math.sqrt((1.0F + d) * 2.0F);
/* 200 */     float inverse = 1.0F / s;
/*     */ 
/* 202 */     q.setX(c.getX() * inverse);
/* 203 */     q.setY(c.getY() * inverse);
/* 204 */     q.setZ(c.getZ() * inverse);
/* 205 */     q.setW(s * 0.5F);
/*     */ 
/* 207 */     return q;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 211 */     return "[x=" + getX() + ",y=" + getY() + ",z=" + getZ() + "]";
/*     */   }
/*     */   public float getX() {
/* 214 */     return this._x; } 
/* 215 */   public float getY() { return this._y; } 
/* 216 */   public float getZ() { return this._z; } 
/*     */   public void setX(float x) {
/* 218 */     this._x = x; } 
/* 219 */   public void setY(float y) { this._y = y; } 
/* 220 */   public void setZ(float z) { this._z = z; }
/*     */ 
/*     */   public static AOVector add(AOVector p1, AOVector p2) {
/* 223 */     return new AOVector(p1._x + p2._x, p1._y + p2._y, p1._z + p2._z);
/*     */   }
/*     */ 
/*     */   public static AOVector multiply(AOVector src, float factor) {
/* 227 */     return new AOVector(src.getX() * factor, src.getY() * factor, src.getZ() * factor);
/*     */   }
/*     */ 
/*     */   public static AOVector sub(AOVector dest, AOVector cur)
/*     */   {
/* 232 */     return new AOVector(dest.getX() - cur.getX(), dest.getY() - cur.getY(), dest.getZ() - cur.getZ());
/*     */   }
/*     */ 
/*     */   public static AOVector sub(Point dest, Point cur)
/*     */   {
/* 239 */     return new AOVector(dest.getX() - cur.getX(), dest.getY() - cur.getY(), dest.getZ() - cur.getZ());
/*     */   }
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 252 */     out.writeFloat(this._x);
/* 253 */     out.writeFloat(this._y);
/* 254 */     out.writeFloat(this._z);
/*     */   }
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 265 */     this._x = in.readFloat();
/* 266 */     this._y = in.readFloat();
/* 267 */     this._z = in.readFloat();
/*     */   }
/*     */ 
/*     */   public static AOVector parsePoint(String s) {
/* 271 */     String v = s.trim();
/* 272 */     AOVector p = new AOVector();
/* 273 */     if ((v.startsWith("(")) && (v.endsWith(")"))) {
/* 274 */       String[] parts = v.substring(1, v.length() - 1).split(",");
/* 275 */       int n = parts.length;
/* 276 */       if (n >= 1)
/* 277 */         p.setX(Float.parseFloat(parts[0]));
/* 278 */       if (n >= 2)
/* 279 */         p.setY(Float.parseFloat(parts[1]));
/* 280 */       if (n >= 3)
/* 281 */         p.setZ(Float.parseFloat(parts[2]));
/*     */     }
/* 283 */     return p;
/*     */   }
/*     */ 
/*     */   public AOVector(AOVector other)
/*     */   {
/* 295 */     this._x = other._x;
/* 296 */     this._y = other._y;
/* 297 */     this._z = other._z;
/*     */   }
/*     */ 
/*     */   public static AOVector cross(AOVector u, AOVector v)
/*     */   {
/* 302 */     float x = u._y * v._z - u._z * v._y;
/* 303 */     float y = u._z * v._x - u._x * v._z;
/* 304 */     float z = u._x * v._y - u._y * v._x;
/* 305 */     return new AOVector(x, y, z);
/*     */   }
/*     */ 
/*     */   public static boolean counterClockwisePoints(AOVector v0, AOVector v1, AOVector v2) {
/* 309 */     return (v1._x - v0._x) * (v2._z - v0._z) - (v2._x - v0._x) * (v1._z - v0._z) > 0.0F;
/*     */   }
/*     */ 
/*     */   public static float getLookAtYaw(AOVector motion) {
/* 313 */     return (float)Math.toDegrees(Math.atan2(motion.getX(), motion.getZ()));
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 319 */     AOVector v = new AOVector(4.0F, 3.0F, 0.0F);
/* 320 */     float len = v.length();
/* 321 */     System.out.println("length of " + v + " should be 5.. result=" + len);
/*     */ 
/* 323 */     v.normalize();
/* 324 */     System.out.println("normal should be 0.8 0.6 0 - result is " + v);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.math.AOVector
 * JD-Core Version:    0.6.0
 */