/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class PathPortal
/*    */   implements Serializable, Cloneable
/*    */ {
/*    */   int cvPolyIndex;
/*    */   int terrainPolyIndex;
/*    */   PathEdge edge;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PathPortal()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PathPortal(int cvPolyIndex, int terrainPolyIndex, PathEdge edge)
/*    */   {
/* 15 */     this.cvPolyIndex = cvPolyIndex;
/* 16 */     this.terrainPolyIndex = terrainPolyIndex;
/* 17 */     this.edge = edge;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 21 */     return "[PathPortal cvPolyIndex=" + getCVPolyIndex() + ", terrainPolyIndex=" + getTerrainPolyIndex() + ",edge=" + getEdge() + "]";
/*    */   }
/*    */ 
/*    */   public Object clone()
/*    */   {
/* 27 */     return new PathPortal(getCVPolyIndex(), getTerrainPolyIndex(), getEdge());
/*    */   }
/*    */ 
/*    */   public int getCVPolyIndex() {
/* 31 */     return this.cvPolyIndex;
/*    */   }
/*    */ 
/*    */   public int getTerrainPolyIndex() {
/* 35 */     return this.terrainPolyIndex;
/*    */   }
/*    */ 
/*    */   public PathEdge getEdge() {
/* 39 */     return this.edge;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathPortal
 * JD-Core Version:    0.6.0
 */