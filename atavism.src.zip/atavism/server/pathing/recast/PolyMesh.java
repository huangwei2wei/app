/*      */ package atavism.server.pathing.recast;
/*      */ 
/*      */ import atavism.server.math.IntVector3;
/*      */ 
/*      */ public class PolyMesh
/*      */ {
/*      */   public int[] Verts;
/*      */   public int[] Polys;
/*      */   public int[] Regs;
/*      */   public int[] Flags;
/*      */   public short[] Areas;
/*      */   public int NVerts;
/*      */   public int NPolys;
/*      */   public int MaxPolys;
/*      */   public int Nvp;
/*   16 */   public float[] BMin = new float[3];
/*   17 */   public float[] BMax = new float[3];
/*      */   public float Cs;
/*      */   public float Ch;
/*      */   public int BorderSize;
/*   22 */   public static int VertexBucketCount = 4096;
/*   23 */   public static int MeshNullIdx = 65535;
/*      */ 
/*      */   public PolyMesh(ContourSet cset, int nvp)
/*      */   {
/*   27 */     System.arraycopy(cset.BMin, 0, this.BMin, 0, 3);
/*   28 */     System.arraycopy(cset.BMax, 0, this.BMax, 0, 3);
/*   29 */     this.Cs = cset.Cs;
/*   30 */     this.Ch = cset.Ch;
/*   31 */     this.BorderSize = cset.BorderSize;
/*      */ 
/*   33 */     int maxVertices = 0;
/*   34 */     int maxTris = 0;
/*   35 */     int maxVertsPerCont = 0;
/*   36 */     for (int i = 0; i < cset.NConts; i++)
/*      */     {
/*   38 */       if (cset.Conts[i].NVerts >= 3) {
/*   39 */         maxVertices += cset.Conts[i].NVerts;
/*   40 */         maxTris += cset.Conts[i].NVerts - 2;
/*   41 */         maxVertsPerCont = Math.max(maxVertsPerCont, cset.Conts[i].NVerts);
/*      */       }
/*      */     }
/*   44 */     short[] vflags = new short[maxVertices];
/*      */ 
/*   46 */     this.Verts = new int[maxVertices * 3];
/*   47 */     this.Polys = new int[maxTris * nvp * 2];
/*   48 */     this.Regs = new int[maxTris];
/*   49 */     this.Areas = new short[maxTris];
/*      */ 
/*   51 */     this.NVerts = 0;
/*   52 */     this.NPolys = 0;
/*   53 */     this.Nvp = nvp;
/*   54 */     this.MaxPolys = maxTris;
/*      */ 
/*   56 */     for (int i = 0; i < maxTris * nvp * 2; i++)
/*      */     {
/*   58 */       this.Polys[i] = 65535;
/*      */     }
/*      */ 
/*   61 */     int[] nextVert = new int[maxVertices];
/*      */ 
/*   63 */     int[] firstVert = new int[VertexBucketCount];
/*   64 */     for (int i = 0; i < firstVert.length; i++)
/*      */     {
/*   66 */       firstVert[i] = -1;
/*      */     }
/*      */ 
/*   69 */     int[] indices = new int[maxVertsPerCont];
/*   70 */     int[] tris = new int[maxVertsPerCont * 3];
/*   71 */     int[] polys = new int[(maxVertsPerCont + 1) * nvp];
/*   72 */     int[] tmpPoly = new int[nvp];
/*      */ 
/*   74 */     for (int i = 0; i < cset.NConts; i++)
/*      */     {
/*   76 */       Contour cont = cset.Conts[i];
/*      */ 
/*   78 */       if (cont.NVerts < 3)
/*      */         continue;
/*   80 */       for (int j = 0; j < cont.NVerts; j++)
/*      */       {
/*   82 */         indices[j] = j;
/*      */       }
/*      */ 
/*   85 */       int ntris = Triangulate(cont.NVerts, cont.Verts, indices, tris);
/*   86 */       if (ntris <= 0)
/*      */       {
/*   89 */         ntris = -ntris;
/*      */       }
/*      */ 
/*   92 */       for (int j = 0; j < cont.NVerts; j++)
/*      */       {
/*   94 */         int v = j * 4;
/*   95 */         indices[j] = AddVertex(cont.Verts[(v + 0)], cont.Verts[(v + 1)], cont.Verts[(v + 2)], firstVert, nextVert);
/*   96 */         if ((cont.Verts[(v + 3)] & ContourSet.BorderVertex) == 0)
/*      */           continue;
/*   98 */         vflags[indices[j]] = 1;
/*      */       }
/*      */ 
/*  103 */       int npolys = 0;
/*  104 */       for (int j = 0; j < polys.length; j++)
/*      */       {
/*  106 */         polys[j] = 65535;
/*      */       }
/*  108 */       for (int j = 0; j < ntris; j++)
/*      */       {
/*  110 */         int t = j * 3;
/*  111 */         if ((tris[(t + 0)] == tris[(t + 1)]) || (tris[(t + 0)] == tris[(t + 2)]) || (tris[(t + 1)] == tris[(t + 2)]))
/*      */           continue;
/*  113 */         polys[(npolys * nvp + 0)] = indices[tris[(t + 0)]];
/*  114 */         polys[(npolys * nvp + 1)] = indices[tris[(t + 1)]];
/*  115 */         polys[(npolys * nvp + 2)] = indices[tris[(t + 2)]];
/*  116 */         npolys++;
/*      */       }
/*      */ 
/*  119 */       if (npolys == 0) {
/*      */         continue;
/*      */       }
/*  122 */       if (nvp > 3)
/*      */       {
/*      */         while (true)
/*      */         {
/*  126 */           int bestMergeVal = 0;
/*  127 */           int bestPa = 0; int bestPb = 0; int bestEa = 0; int bestEb = 0;
/*      */ 
/*  129 */           for (int j = 0; j < npolys - 1; j++)
/*      */           {
/*  131 */             int pj = j * nvp;
/*  132 */             for (int k = j + 1; k < npolys; k++)
/*      */             {
/*  134 */               int pk = k * nvp;
/*  135 */               int ea = 0; int eb = 0;
/*      */ 
/*  137 */               IntVector3 returnVec = GetPolyMergeValue(polys, pj, pk, this.Verts, ea, eb, nvp);
/*  138 */               int v = returnVec.getX();
/*  139 */               ea = returnVec.getY();
/*  140 */               eb = returnVec.getZ();
/*  141 */               if (v <= bestMergeVal)
/*      */                 continue;
/*  143 */               bestMergeVal = v;
/*  144 */               bestPa = j;
/*  145 */               bestPb = k;
/*  146 */               bestEa = ea;
/*  147 */               bestEb = eb;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  152 */           if (bestMergeVal <= 0)
/*      */             break;
/*  154 */           int pa = bestPa * nvp;
/*  155 */           int pb = bestPb * nvp;
/*  156 */           MergePolys(polys, pa, pb, bestEa, bestEb, tmpPoly, nvp);
/*      */ 
/*  158 */           System.arraycopy(polys, (npolys - 1) * nvp, polys, pb, nvp);
/*  159 */           npolys--;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  168 */       for (int j = 0; j < npolys; j++)
/*      */       {
/*  170 */         int p = this.NPolys * nvp * 2;
/*  171 */         int q = j * nvp;
/*  172 */         for (int k = 0; k < nvp; k++)
/*      */         {
/*  174 */           this.Polys[(p + k)] = polys[(q + k)];
/*      */         }
/*  176 */         this.Regs[this.NPolys] = cont.Reg;
/*  177 */         this.Areas[this.NPolys] = cont.Area;
/*  178 */         this.NPolys += 1;
/*      */       }
/*      */     }
/*      */ 
/*  182 */     for (int i = 0; i < this.NVerts; i++);
/*  200 */     if ((BuildMeshAdjacency(nvp).booleanValue()) || 
/*  206 */       (this.BorderSize > 0))
/*      */     {
/*  208 */       int w = cset.Width;
/*  209 */       int h = cset.Height;
/*  210 */       for (int i = 0; i < this.NPolys; i++)
/*      */       {
/*  212 */         int p = i * 2 * nvp;
/*  213 */         for (int j = 0; j < nvp; j++)
/*      */         {
/*  215 */           if (this.Polys[(p + j)] == MeshNullIdx) break;
/*  216 */           if (this.Polys[(p + nvp + j)] == MeshNullIdx) {
/*  217 */             int nj = j + 1;
/*  218 */             if ((nj >= nvp) || (this.Polys[(p + nj)] == MeshNullIdx)) nj = 0;
/*  219 */             int va = this.Polys[(p + j)] * 3;
/*  220 */             int vb = this.Polys[(p + nj)] * 3;
/*      */ 
/*  222 */             if ((this.Verts[(va + 0)] == 0) && (this.Verts[(vb + 0)] == 0))
/*  223 */               this.Polys[(p + nvp + j)] = 32768;
/*  224 */             else if ((this.Verts[(va + 2)] == h) && (this.Verts[(vb + 2)] == h))
/*  225 */               this.Polys[(p + nvp + j)] = 32769;
/*  226 */             else if ((this.Verts[(va + 0)] == w) && (this.Verts[(vb + 0)] == w))
/*  227 */               this.Polys[(p + nvp + j)] = 32770;
/*  228 */             else if ((this.Verts[(va + 2)] == 0) && (this.Verts[(vb + 2)] == 0)) {
/*  229 */               this.Polys[(p + nvp + j)] = 32771;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  235 */     this.Flags = new int[this.NPolys];
/*      */   }
/*      */ 
/*      */   private int Triangulate(int n, int[] verts, int[] indices, int[] tris)
/*      */   {
/*  240 */     int ntris = 0;
/*  241 */     int trisIndex = 0;
/*      */ 
/*  243 */     for (int i = 0; i < n; i++)
/*      */     {
/*  245 */       int i1 = Next(i, n);
/*  246 */       int i2 = Next(i1, n);
/*  247 */       if (Diagonal(i, i2, n, verts, indices).booleanValue()) {
/*  248 */         indices[i1] |= -2147483648;
/*      */       }
/*      */     }
/*  251 */     while (n > 3)
/*      */     {
/*  253 */       int minLen = -1;
/*  254 */       int mini = -1;
/*  255 */       for (int i = 0; i < n; i++)
/*      */       {
/*  257 */         int i1 = Next(i, n);
/*  258 */         if ((indices[i1] & 0x80000000) == 0)
/*      */           continue;
/*  260 */         int p0 = (indices[i] & 0xFFFFFFF) * 4;
/*  261 */         int p2 = indices[(Next(i1, n) & 0xFFFFFFF)] * 4;
/*      */ 
/*  263 */         int dx = verts[(p2 + 0)] - verts[(p0 + 0)];
/*  264 */         int dy = verts[(p2 + 2)] - verts[(p0 + 2)];
/*  265 */         int len = dx * dx + dy * dy;
/*      */ 
/*  267 */         if ((minLen >= 0) && (len >= minLen))
/*      */           continue;
/*  269 */         minLen = len;
/*  270 */         mini = i;
/*      */       }
/*      */ 
/*  275 */       if (mini == -1) {
/*  276 */         return -ntris;
/*      */       }
/*  278 */       int j = mini;
/*  279 */       int j1 = Next(j, n);
/*  280 */       int j2 = Next(j1, n);
/*      */ 
/*  282 */       tris[(trisIndex++)] = (indices[j] & 0xFFFFFFF);
/*  283 */       tris[(trisIndex++)] = (indices[j1] & 0xFFFFFFF);
/*  284 */       tris[(trisIndex++)] = (indices[j2] & 0xFFFFFFF);
/*  285 */       ntris++;
/*      */ 
/*  287 */       n--;
/*  288 */       for (int k = j1; k < n; k++)
/*      */       {
/*  290 */         indices[k] = indices[(k + 1)];
/*      */       }
/*      */ 
/*  293 */       if (j1 >= n) j1 = 0;
/*  294 */       j = Prev(j1, n);
/*      */ 
/*  296 */       if (Diagonal(Prev(j, n), j1, n, verts, indices).booleanValue()) {
/*  297 */         indices[j] |= -2147483648;
/*      */       }
/*      */       else {
/*  300 */         indices[j] &= 268435455;
/*      */       }
/*      */ 
/*  303 */       if (Diagonal(j, Next(j1, n), n, verts, indices).booleanValue()) {
/*  304 */         indices[j1] |= -2147483648;
/*      */       }
/*      */       else {
/*  307 */         indices[j1] &= 268435455;
/*      */       }
/*      */     }
/*      */ 
/*  311 */     tris[(trisIndex++)] = (indices[0] & 0xFFFFFFF);
/*  312 */     tris[(trisIndex++)] = (indices[1] & 0xFFFFFFF);
/*  313 */     tris[(trisIndex++)] = (indices[2] & 0xFFFFFFF);
/*  314 */     ntris++;
/*      */ 
/*  316 */     return ntris;
/*      */   }
/*      */ 
/*      */   private Boolean Diagonal(int i, int j, int n, int[] verts, int[] indices)
/*      */   {
/*  321 */     return Boolean.valueOf((InCone(i, j, n, verts, indices).booleanValue()) && (Diagonalie(i, j, n, verts, indices).booleanValue()));
/*      */   }
/*      */ 
/*      */   private Boolean Diagonalie(int i, int j, int n, int[] verts, int[] indices)
/*      */   {
/*  326 */     int d0 = (indices[i] & 0xFFFFFFF) * 4;
/*  327 */     int d1 = (indices[j] & 0xFFFFFFF) * 4;
/*      */ 
/*  329 */     for (int k = 0; k < n; k++)
/*      */     {
/*  331 */       int k1 = Next(k, n);
/*      */ 
/*  333 */       if ((k == i) || (k1 == i) || (k == j) || (k1 == j))
/*      */         continue;
/*  335 */       int p0 = (indices[k] & 0xFFFFFFF) * 4;
/*  336 */       int p1 = (indices[k1] & 0xFFFFFFF) * 4;
/*      */ 
/*  338 */       if ((VEqual(verts[(d0 + 0)], verts[(d0 + 2)], verts[(p0 + 0)], verts[(p0 + 2)]).booleanValue()) || (VEqual(verts[(d1 + 0)], verts[(d1 + 2)], verts[(p0 + 0)], verts[(p0 + 2)]).booleanValue()) || (VEqual(verts[(d0 + 0)], verts[(d0 + 2)], verts[(p1 + 0)], verts[(p1 + 2)]).booleanValue()) || (VEqual(verts[(d1 + 0)], verts[(d1 + 2)], verts[(p1 + 0)], verts[(p1 + 2)]).booleanValue())) {
/*      */         continue;
/*      */       }
/*  341 */       if (Intersect(verts[(d0 + 0)], verts[(d0 + 2)], verts[(d1 + 0)], verts[(d1 + 2)], verts[(p0 + 0)], verts[(p0 + 2)], verts[(p1 + 0)], verts[(p1 + 2)]).booleanValue())
/*      */       {
/*  343 */         return Boolean.valueOf(false);
/*      */       }
/*      */     }
/*  346 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private Boolean Intersect(int ax, int az, int bx, int bz, int cx, int cz, int dx, int dz)
/*      */   {
/*  351 */     if (IntersectProp(ax, az, bx, bz, cx, cz, dx, dz).booleanValue())
/*  352 */       return Boolean.valueOf(true);
/*  353 */     if ((Between(ax, az, bx, bz, cx, cz).booleanValue()) || (Between(ax, az, bx, bz, dx, dz).booleanValue()) || (Between(cx, cz, dx, dz, ax, az).booleanValue()) || (Between(cx, cz, dx, dz, bx, bz).booleanValue()))
/*      */     {
/*  355 */       return Boolean.valueOf(true);
/*      */     }
/*  357 */     return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   private Boolean IntersectProp(int ax, int az, int bx, int bz, int cx, int cz, int dx, int dz)
/*      */   {
/*  362 */     if ((Collinear(ax, az, bx, bz, cx, cz).booleanValue()) || (Collinear(ax, az, bx, bz, dx, dz).booleanValue()) || (Collinear(cx, cz, dx, dz, ax, az).booleanValue()) || (Collinear(cx, cz, dx, dz, bx, bz).booleanValue()))
/*      */     {
/*  364 */       return Boolean.valueOf(false);
/*      */     }
/*  366 */     return Boolean.valueOf((Xorb(Left(ax, az, bx, bz, cx, cz), Left(ax, az, bx, bz, dx, dz)).booleanValue()) && (Xorb(Left(cx, cz, dx, dz, ax, az), Left(cx, cz, dx, dz, bx, bz)).booleanValue()));
/*      */   }
/*      */ 
/*      */   private Boolean Xorb(Boolean x, Boolean y)
/*      */   {
/*  372 */     return Boolean.valueOf((!x.booleanValue() ? 1 : 0) ^ (!y.booleanValue() ? 1 : 0));
/*      */   }
/*      */ 
/*      */   private Boolean Between(int ax, int az, int bx, int bz, int cx, int cz)
/*      */   {
/*  377 */     if (!Collinear(ax, az, bx, bz, cx, cz).booleanValue())
/*  378 */       return Boolean.valueOf(false);
/*  379 */     if (ax != bx) {
/*  380 */       return Boolean.valueOf(((ax <= cx) && (cx <= bx)) || ((ax >= cx) && (cx >= bx)));
/*      */     }
/*  382 */     return Boolean.valueOf(((az <= cz) && (cz <= bz)) || ((az >= cz) && (cz >= bz)));
/*      */   }
/*      */ 
/*      */   private Boolean VEqual(int ax, int az, int bx, int bz)
/*      */   {
/*  387 */     return Boolean.valueOf((ax == bx) && (az == bz));
/*      */   }
/*      */ 
/*      */   private Boolean InCone(int i, int j, int n, int[] verts, int[] indices)
/*      */   {
/*  392 */     int pi = (indices[i] & 0xFFFFFFF) * 4;
/*  393 */     int pj = (indices[j] & 0xFFFFFFF) * 4;
/*  394 */     int pi1 = (indices[Next(i, n)] & 0xFFFFFFF) * 4;
/*  395 */     int pin1 = (indices[Prev(i, n)] & 0xFFFFFFF) * 4;
/*      */ 
/*  397 */     if (LeftOn(verts[(pin1 + 0)], verts[(pin1 + 2)], verts[(pi + 0)], verts[(pi + 2)], verts[(pi1 + 0)], verts[(pi1 + 2)]).booleanValue())
/*  398 */       return Boolean.valueOf((Left(verts[(pi + 0)], verts[(pi + 2)], verts[(pj + 0)], verts[(pj + 2)], verts[(pin1 + 0)], verts[(pin1 + 2)]).booleanValue()) && (Left(verts[(pj + 0)], verts[(pj + 2)], verts[(pi + 0)], verts[(pi + 2)], verts[(pi1 + 0)], verts[(pi1 + 2)]).booleanValue()));
/*  399 */     return Boolean.valueOf((!LeftOn(verts[(pi + 0)], verts[(pi + 2)], verts[(pj + 0)], verts[(pj + 2)], verts[(pi1 + 0)], verts[(pi1 + 2)]).booleanValue()) || (!LeftOn(verts[(pj + 0)], verts[(pj + 2)], verts[(pi + 0)], verts[(pi + 2)], verts[(pin1 + 0)], verts[(pin1 + 2)]).booleanValue()));
/*      */   }
/*      */ 
/*      */   private Boolean LeftOn(int ax, int az, int bx, int bz, int cx, int cz)
/*      */   {
/*  404 */     return Boolean.valueOf(Area2(ax, az, bx, bz, cx, cz) <= 0);
/*      */   }
/*      */ 
/*      */   private Boolean Left(int ax, int az, int bx, int bz, int cx, int cz)
/*      */   {
/*  409 */     return Boolean.valueOf(Area2(ax, az, bx, bz, cx, cz) < 0);
/*      */   }
/*      */ 
/*      */   private Boolean Collinear(int ax, int az, int bx, int bz, int cx, int cz)
/*      */   {
/*  414 */     return Boolean.valueOf(Area2(ax, az, bx, bz, cx, cz) == 0);
/*      */   }
/*      */ 
/*      */   private int Area2(int ax, int az, int bx, int bz, int cx, int cz)
/*      */   {
/*  419 */     return (bx - ax) * (cz - az) - (cx - ax) * (bz - az);
/*      */   }
/*      */ 
/*      */   private int Next(int i, int n)
/*      */   {
/*  424 */     return i + 1 < n ? i + 1 : 0;
/*      */   }
/*      */ 
/*      */   private int Prev(int i, int n)
/*      */   {
/*  429 */     return i - 1 >= 0 ? i - 1 : n - 1;
/*      */   }
/*      */ 
/*      */   private int AddVertex(int x, int y, int z, int[] firstVert, int[] nextVert)
/*      */   {
/*  434 */     int bucket = ComputeVertexHash(x, 0, z);
/*  435 */     int i = firstVert[bucket];
/*      */ 
/*  437 */     while (i != -1)
/*      */     {
/*  439 */       int v = i * 3;
/*  440 */       if ((this.Verts[(v + 0)] == x) && (Math.abs(this.Verts[(v + 1)] - y) <= 2) && (this.Verts[(v + 2)] == z))
/*  441 */         return i;
/*  442 */       i = nextVert[i];
/*      */     }
/*      */ 
/*  445 */     i = this.NVerts;
/*  446 */     this.NVerts += 1;
/*  447 */     int v1 = i * 3;
/*  448 */     this.Verts[(v1 + 0)] = x;
/*  449 */     this.Verts[(v1 + 1)] = y;
/*  450 */     this.Verts[(v1 + 2)] = z;
/*  451 */     nextVert[i] = firstVert[bucket];
/*  452 */     firstVert[bucket] = i;
/*      */ 
/*  454 */     return i;
/*      */   }
/*      */ 
/*      */   private int ComputeVertexHash(int x, int y, int z)
/*      */   {
/*  459 */     long h1 = -1918454973L;
/*  460 */     long h2 = -669632447L;
/*  461 */     long h3 = -887442657L;
/*  462 */     long n = h1 * x + h2 * y + h3 * z;
/*  463 */     return (int)(n & VertexBucketCount - 1);
/*      */   }
/*      */ 
/*      */   private IntVector3 GetPolyMergeValue(int[] polys, int pa, int pb, int[] verts, int ea, int eb, int nvp)
/*      */   {
/*  468 */     IntVector3 returnVec = new IntVector3();
/*  469 */     int na = CountPolyVerts(polys, pa, nvp);
/*  470 */     int nb = CountPolyVerts(polys, pb, nvp);
/*      */ 
/*  472 */     if (na + nb - 2 > nvp) {
/*  473 */       returnVec.setX(-1);
/*  474 */       return returnVec;
/*      */     }
/*      */ 
/*  477 */     ea = -1;
/*  478 */     eb = -1;
/*      */ 
/*  480 */     for (int i = 0; i < na; i++)
/*      */     {
/*  482 */       int va0 = polys[(pa + i)];
/*  483 */       int va1 = polys[(pa + (i + 1) % na)];
/*  484 */       if (va0 > va1)
/*      */       {
/*  486 */         int temp = va0;
/*  487 */         va0 = va1;
/*  488 */         va1 = temp;
/*      */       }
/*  490 */       for (int j = 0; j < nb; j++)
/*      */       {
/*  492 */         int vb0 = polys[(pb + j)];
/*  493 */         int vb1 = polys[(pb + (j + 1) % nb)];
/*  494 */         if (vb0 > vb1)
/*      */         {
/*  496 */           int temp = vb0;
/*  497 */           vb0 = vb1;
/*  498 */           vb1 = temp;
/*      */         }
/*  500 */         if ((va0 != vb0) || (va1 != vb1))
/*      */           continue;
/*  502 */         ea = i;
/*  503 */         eb = j;
/*  504 */         break;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  509 */     if ((ea == -1) || (eb == -1)) {
/*  510 */       returnVec.setX(-1);
/*  511 */       return returnVec;
/*      */     }
/*      */ 
/*  515 */     int va = polys[(pa + (ea + na - 1) % na)];
/*  516 */     int vb = polys[(pa + ea)];
/*  517 */     int vc = polys[(pb + (eb + 2) % nb)];
/*  518 */     if (!ULeft(verts[(va * 3 + 0)], verts[(va * 3 + 2)], verts[(vb * 3 + 0)], verts[(vb * 3 + 2)], verts[(vc * 3 + 0)], verts[(vc * 3 + 2)]).booleanValue()) {
/*  519 */       returnVec.setX(-1);
/*  520 */       return returnVec;
/*      */     }
/*      */ 
/*  523 */     va = polys[(pb + (eb + nb - 1) % nb)];
/*  524 */     vb = polys[(pb + eb)];
/*  525 */     vc = polys[(pa + (ea + 2) % na)];
/*  526 */     if (!ULeft(verts[(va * 3 + 0)], verts[(va * 3 + 2)], verts[(vb * 3 + 0)], verts[(vb * 3 + 2)], this.Verts[(vc * 3 + 0)], verts[(vc * 3 + 2)]).booleanValue()) {
/*  527 */       returnVec.setX(-1);
/*  528 */       return returnVec;
/*      */     }
/*      */ 
/*  531 */     va = polys[(pa + ea)];
/*  532 */     vb = polys[(pa + (ea + 1) % na)];
/*      */ 
/*  534 */     int dx = verts[(va * 3 + 0)] - verts[(vb * 3 + 0)];
/*  535 */     int dz = verts[(va * 3 + 2)] - verts[(vb * 3 + 2)];
/*      */ 
/*  537 */     returnVec.setX(dx * dx + dz * dz);
/*  538 */     returnVec.setY(ea);
/*  539 */     returnVec.setZ(eb);
/*  540 */     return returnVec;
/*      */   }
/*      */ 
/*      */   private Boolean ULeft(int ax, int az, int bx, int bz, int cx, int cz)
/*      */   {
/*  545 */     return Boolean.valueOf((bx - ax) * (cz - az) - (cx - ax) * (bz - az) < 0);
/*      */   }
/*      */ 
/*      */   private void MergePolys(int[] polys, int pa, int pb, int ea, int eb, int[] tmpPoly, int nvp)
/*      */   {
/*  550 */     int na = CountPolyVerts(polys, pa, nvp);
/*  551 */     int nb = CountPolyVerts(polys, pb, nvp);
/*      */ 
/*  553 */     for (int i = 0; i < nvp; i++)
/*      */     {
/*  555 */       tmpPoly[i] = 65535;
/*      */     }
/*  557 */     int n = 0;
/*  558 */     for (int i = 0; i < na - 1; i++)
/*      */     {
/*  560 */       tmpPoly[(n++)] = polys[(pa + (ea + 1 + i) % na)];
/*      */     }
/*  562 */     for (int i = 0; i < nb - 1; i++)
/*      */     {
/*  564 */       tmpPoly[(n++)] = polys[(pb + (eb + 1 + i) % nb)];
/*      */     }
/*      */ 
/*  567 */     System.arraycopy(tmpPoly, 0, polys, pa, nvp);
/*      */   }
/*      */ 
/*      */   private Boolean CanRemoveVertex(int rem)
/*      */   {
/*  572 */     int nvp = this.Nvp;
/*      */ 
/*  574 */     int numRemovedVerts = 0;
/*  575 */     int numTouchedVerts = 0;
/*  576 */     int numRemainingEdges = 0;
/*      */ 
/*  578 */     for (int i = 0; i < this.NPolys; i++)
/*      */     {
/*  580 */       int p = i * nvp * 2;
/*  581 */       int nv = CountPolyVerts(this.Polys, p, nvp);
/*  582 */       int numRemoved = 0;
/*  583 */       int numVerts = 0;
/*  584 */       for (int j = 0; j < nv; j++)
/*      */       {
/*  586 */         if (this.Polys[(p + j)] == rem)
/*      */         {
/*  588 */           numTouchedVerts++;
/*  589 */           numRemoved++;
/*      */         }
/*  591 */         numVerts++;
/*      */       }
/*  593 */       if (numRemoved <= 0)
/*      */         continue;
/*  595 */       numRemovedVerts += numRemoved;
/*  596 */       numRemainingEdges += numVerts - (numRemoved + 1);
/*      */     }
/*      */ 
/*  600 */     if (numRemainingEdges <= 2) {
/*  601 */       return Boolean.valueOf(false);
/*      */     }
/*  603 */     int maxEdges = numTouchedVerts * 2;
/*  604 */     int nedges = 0;
/*  605 */     int[] edges = new int[maxEdges * 3];
/*      */ 
/*  607 */     for (int i = 0; i < this.NPolys; i++)
/*      */     {
/*  609 */       int p = i * nvp * 2;
/*  610 */       int nv = CountPolyVerts(this.Polys, p, nvp);
/*      */ 
/*  612 */       int j = 0; for (int k = nv - 1; j < nv; k = j++)
/*      */       {
/*  614 */         if ((this.Polys[(p + j)] != rem) && (this.Polys[(p + k)] != rem))
/*      */           continue;
/*  616 */         int a = this.Polys[(p + j)]; int b = this.Polys[(p + k)];
/*  617 */         if (b == rem)
/*      */         {
/*  619 */           int temp = a;
/*  620 */           a = b;
/*  621 */           b = temp;
/*      */         }
/*      */ 
/*  624 */         Boolean exists = Boolean.valueOf(false);
/*  625 */         for (int m = 0; m < nedges; m++)
/*      */         {
/*  627 */           int e = m * 3;
/*  628 */           if (edges[(e + 1)] != b)
/*      */             continue;
/*  630 */           edges[(e + 2)] += 1;
/*  631 */           exists = Boolean.valueOf(true);
/*      */         }
/*      */ 
/*  634 */         if (exists.booleanValue())
/*      */           continue;
/*  636 */         int e = nedges * 3;
/*  637 */         edges[(e + 0)] = a;
/*  638 */         edges[(e + 1)] = b;
/*  639 */         edges[(e + 2)] = 1;
/*  640 */         nedges++;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  646 */     int numOpenEdges = 0;
/*  647 */     for (int i = 0; i < nedges; i++)
/*      */     {
/*  649 */       if (edges[(i * 3 + 2)] < 2)
/*  650 */         numOpenEdges++;
/*      */     }
/*  652 */     if (numOpenEdges > 2) {
/*  653 */       return Boolean.valueOf(false);
/*      */     }
/*  655 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private Boolean RemoveVertex(int rem, int maxTris)
/*      */   {
/*  660 */     int nvp = this.Nvp;
/*      */ 
/*  662 */     int numRemovedVerts = 0;
/*  663 */     for (int i = 0; i < this.NPolys; i++)
/*      */     {
/*  665 */       int p = i * nvp * 2;
/*  666 */       int nv = CountPolyVerts(this.Polys, p, nvp);
/*  667 */       for (int j = 0; j < nv; j++)
/*      */       {
/*  669 */         if (this.Polys[(p + j)] != rem)
/*      */           continue;
/*  671 */         numRemovedVerts++;
/*      */       }
/*      */     }
/*      */ 
/*  675 */     int nedges = 0;
/*  676 */     int[] edges = new int[numRemovedVerts * nvp * 4];
/*      */ 
/*  678 */     int nhole = 0;
/*  679 */     int[] hole = new int[numRemovedVerts * nvp];
/*      */ 
/*  681 */     int nhreg = 0;
/*  682 */     int[] hreg = new int[numRemovedVerts * nvp];
/*      */ 
/*  684 */     int nharea = 0;
/*  685 */     int[] harea = new int[numRemovedVerts * nvp];
/*      */ 
/*  687 */     for (int i = 0; i < this.NPolys; i++)
/*      */     {
/*  689 */       int p = i * nvp * 2;
/*  690 */       int nv = CountPolyVerts(this.Polys, p, nvp);
/*  691 */       Boolean hasRem = Boolean.valueOf(false);
/*  692 */       for (int j = 0; j < nv; j++)
/*      */       {
/*  694 */         if (this.Polys[(p + j)] != rem) continue; hasRem = Boolean.valueOf(true);
/*      */       }
/*  696 */       if (!hasRem.booleanValue())
/*      */         continue;
/*  698 */       int j = 0; for (int k = nv - 1; j < nv; k = j++)
/*      */       {
/*  700 */         if ((this.Polys[(p + j)] == rem) || (this.Polys[(p + k)] == rem))
/*      */           continue;
/*  702 */         int e = nedges * 4;
/*  703 */         edges[(e + 0)] = this.Polys[(p + k)];
/*  704 */         edges[(e + 1)] = this.Polys[(p + j)];
/*  705 */         edges[(e + 2)] = this.Regs[i];
/*  706 */         edges[(e + 3)] = this.Areas[i];
/*  707 */         nedges++;
/*      */       }
/*      */ 
/*  711 */       int p2 = (this.NPolys - 1) * nvp * 2;
/*  712 */       System.arraycopy(this.Polys, p2, this.Polys, p, nvp);
/*  713 */       for (int j = p + nvp; j < p + nvp + nvp; j++)
/*      */       {
/*  715 */         this.Polys[j] = 65535;
/*      */       }
/*  717 */       this.Regs[i] = this.Regs[(this.NPolys - 1)];
/*  718 */       this.Areas[i] = this.Areas[(this.NPolys - 1)];
/*  719 */       this.NPolys -= 1;
/*  720 */       i--;
/*      */     }
/*      */ 
/*  724 */     for (int i = rem; i < this.NVerts - 1; i++)
/*      */     {
/*  726 */       this.Verts[(i * 3 + 0)] = this.Verts[((i + 1) * 3 + 0)];
/*  727 */       this.Verts[(i * 3 + 1)] = this.Verts[((i + 1) * 3 + 1)];
/*  728 */       this.Verts[(i * 3 + 2)] = this.Verts[((i + 1) * 3 + 2)];
/*      */     }
/*  730 */     this.NVerts -= 1;
/*      */ 
/*  732 */     for (int i = 0; i < this.NPolys; i++)
/*      */     {
/*  734 */       int p = i * nvp * 2;
/*  735 */       int nv = CountPolyVerts(this.Polys, p, nvp);
/*  736 */       for (int j = 0; j < nv; j++)
/*      */       {
/*  738 */         if (this.Polys[(p + j)] <= rem) continue; this.Polys[(p + j)] -= 1;
/*      */       }
/*      */     }
/*  741 */     for (int i = 0; i < nedges; i++)
/*      */     {
/*  743 */       if (edges[(i * 4 + 0)] > rem) edges[(i * 4 + 0)] -= 1;
/*  744 */       if (edges[(i * 4 + 1)] <= rem) continue; edges[(i * 4 + 1)] -= 1;
/*      */     }
/*      */ 
/*  747 */     nhole = PushBack(edges[0], hole, nhole);
/*  748 */     nhreg = PushBack(edges[2], hreg, nhreg);
/*  749 */     nharea = PushBack(edges[3], harea, nharea);
/*      */ 
/*  751 */     while (nedges > 0)
/*      */     {
/*  753 */       Boolean match = Boolean.valueOf(false);
/*  754 */       for (int i = 0; i < nedges; i++)
/*      */       {
/*  756 */         int ea = edges[(i * 4 + 0)];
/*  757 */         int eb = edges[(i * 4 + 1)];
/*  758 */         int r = edges[(i * 4 + 2)];
/*  759 */         int a = edges[(i * 4 + 3)];
/*  760 */         Boolean add = Boolean.valueOf(false);
/*  761 */         if (hole[0] == eb)
/*      */         {
/*  763 */           nhole = PushFront(ea, hole, nhole);
/*  764 */           nhreg = PushFront(r, hreg, nhreg);
/*  765 */           nharea = PushFront(a, harea, nharea);
/*  766 */           add = Boolean.valueOf(true);
/*      */         }
/*  768 */         else if (hole[(nhole - 1)] == ea)
/*      */         {
/*  770 */           nhole = PushBack(eb, hole, nhole);
/*  771 */           nhreg = PushBack(r, hreg, nhreg);
/*  772 */           nharea = PushBack(a, harea, nharea);
/*  773 */           add = Boolean.valueOf(true);
/*      */         }
/*  775 */         if (!add.booleanValue())
/*      */           continue;
/*  777 */         edges[(i * 4 + 0)] = edges[((nedges - 1) * 4 + 0)];
/*  778 */         edges[(i * 4 + 1)] = edges[((nedges - 1) * 4 + 1)];
/*  779 */         edges[(i * 4 + 2)] = edges[((nedges - 1) * 4 + 2)];
/*  780 */         edges[(i * 4 + 3)] = edges[((nedges - 1) * 4 + 3)];
/*  781 */         nedges--;
/*  782 */         match = Boolean.valueOf(true);
/*  783 */         i--;
/*      */       }
/*      */ 
/*  786 */       if (!match.booleanValue()) {
/*      */         break;
/*      */       }
/*      */     }
/*  790 */     int[] tris = new int[nhole * 3];
/*  791 */     int[] tverts = new int[nhole * 4];
/*  792 */     int[] thole = new int[nhole];
/*      */ 
/*  794 */     for (int i = 0; i < nhole; i++)
/*      */     {
/*  796 */       int pi = hole[i];
/*  797 */       tverts[(i * 4 + 0)] = this.Verts[(pi * 3 + 0)];
/*  798 */       tverts[(i * 4 + 1)] = this.Verts[(pi * 3 + 1)];
/*  799 */       tverts[(i * 4 + 2)] = this.Verts[(pi * 3 + 2)];
/*  800 */       tverts[(i * 4 + 3)] = 0;
/*  801 */       thole[i] = i;
/*      */     }
/*      */ 
/*  804 */     int ntris = Triangulate(nhole, tverts, thole, tris);
/*  805 */     if (ntris < 0)
/*      */     {
/*  807 */       ntris = -ntris;
/*      */     }
/*      */ 
/*  810 */     int[] polys = new int[ntris * nvp];
/*  811 */     int[] pregs = new int[ntris];
/*  812 */     int[] pareas = new int[ntris];
/*      */ 
/*  814 */     int[] tmpPoly = new int[nvp];
/*      */ 
/*  816 */     int npolys = 0;
/*  817 */     for (int i = 0; i < ntris * nvp; i++)
/*      */     {
/*  819 */       polys[i] = 65535;
/*      */     }
/*  821 */     for (int j = 0; j < ntris; j++)
/*      */     {
/*  823 */       int t = j * 3;
/*  824 */       if ((tris[(t + 0)] == tris[(t + 1)]) || (tris[(t + 0)] == tris[(t + 2)]) || (tris[(t + 1)] == tris[(t + 2)]))
/*      */         continue;
/*  826 */       polys[(npolys * nvp + 0)] = hole[tris[(t + 0)]];
/*  827 */       polys[(npolys * nvp + 1)] = hole[tris[(t + 1)]];
/*  828 */       polys[(npolys * nvp + 2)] = hole[tris[(t + 2)]];
/*  829 */       pregs[npolys] = hreg[tris[(t + 0)]];
/*  830 */       pareas[npolys] = harea[tris[(t + 0)]];
/*  831 */       npolys++;
/*      */     }
/*      */ 
/*  834 */     if (npolys == 0) {
/*  835 */       return Boolean.valueOf(true);
/*      */     }
/*  837 */     if (nvp > 3)
/*      */     {
/*      */       while (true)
/*      */       {
/*  841 */         int bestMergeVal = 0;
/*  842 */         int bestPa = 0; int bestPb = 0; int bestEa = 0; int bestEb = 0;
/*      */ 
/*  844 */         for (int j = 0; j < npolys - 1; j++)
/*      */         {
/*  846 */           int pj = j * nvp;
/*  847 */           for (int k = j + 1; k < npolys; k++)
/*      */           {
/*  849 */             int pk = k * nvp;
/*  850 */             int ea = 0; int eb = 0;
/*  851 */             IntVector3 returnVec = GetPolyMergeValue(polys, pj, pk, this.Verts, ea, eb, nvp);
/*  852 */             int v = returnVec.getX();
/*  853 */             ea = returnVec.getY();
/*  854 */             eb = returnVec.getZ();
/*  855 */             if (v <= bestMergeVal)
/*      */               continue;
/*  857 */             bestMergeVal = v;
/*  858 */             bestPa = j;
/*  859 */             bestPb = k;
/*  860 */             bestEa = ea;
/*  861 */             bestEb = eb;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  866 */         if (bestMergeVal <= 0)
/*      */           break;
/*  868 */         int pa = bestPa * nvp;
/*  869 */         int pb = bestPb * nvp;
/*  870 */         MergePolys(polys, pa, pb, bestEa, bestEb, tmpPoly, nvp);
/*  871 */         System.arraycopy(polys, pb, polys, (npolys - 1) * nvp, nvp);
/*  872 */         pregs[bestPb] = pregs[(npolys - 1)];
/*  873 */         pareas[bestPb] = pareas[(npolys - 1)];
/*  874 */         npolys--;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  883 */     for (int i = 0; i < npolys; i++)
/*      */     {
/*  885 */       if (this.NPolys >= maxTris) break;
/*  886 */       int p = this.NPolys * nvp * 2;
/*  887 */       for (int j = p; j < p + nvp * 2; j++)
/*      */       {
/*  889 */         this.Polys[j] = 65535;
/*      */       }
/*  891 */       for (int j = 0; j < nvp; j++)
/*      */       {
/*  893 */         this.Polys[(p + j)] = polys[(i * nvp + j)];
/*      */       }
/*  895 */       this.Regs[this.NPolys] = pregs[i];
/*  896 */       this.Areas[this.NPolys] = (short)pareas[i];
/*  897 */       this.NPolys += 1;
/*      */     }
/*  899 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private int PushFront(int v, int[] arr, int an)
/*      */   {
/*  904 */     an++;
/*  905 */     for (int i = an - 1; i > 0; i--)
/*      */     {
/*  907 */       arr[i] = arr[(i - 1)];
/*      */     }
/*  909 */     arr[0] = v;
/*  910 */     return an;
/*      */   }
/*      */ 
/*      */   private int PushBack(int v, int[] arr, int an)
/*      */   {
/*  915 */     arr[an] = v;
/*  916 */     an++;
/*  917 */     return an;
/*      */   }
/*      */ 
/*      */   private int CountPolyVerts(int[] polys, int p, int nvp)
/*      */   {
/*  922 */     for (int i = 0; i < nvp; i++)
/*      */     {
/*  924 */       if (polys[(p + i)] == MeshNullIdx)
/*  925 */         return i;
/*      */     }
/*  927 */     return nvp;
/*      */   }
/*      */ 
/*      */   private Boolean BuildMeshAdjacency(int vertsPerPoly)
/*      */   {
/*  932 */     int maxEdgeCount = this.NPolys * vertsPerPoly;
/*  933 */     int[] firstEdge = new int[this.NVerts];
/*  934 */     int[] nextEdge = new int[maxEdgeCount];
/*      */ 
/*  936 */     int edgeCount = 0;
/*      */ 
/*  938 */     Edge[] edges = new Edge[maxEdgeCount];
/*  939 */     for (int i = 0; i < maxEdgeCount; i++)
/*      */     {
/*  941 */       edges[i] = new Edge();
/*      */     }
/*      */ 
/*  944 */     for (int i = 0; i < this.NVerts; i++)
/*      */     {
/*  946 */       firstEdge[i] = MeshNullIdx;
/*      */     }
/*      */ 
/*  949 */     for (int i = 0; i < this.NPolys; i++)
/*      */     {
/*  951 */       int t = i * vertsPerPoly * 2;
/*  952 */       for (int j = 0; j < vertsPerPoly; j++)
/*      */       {
/*  954 */         if (this.Polys[(t + j)] == MeshNullIdx) break;
/*  955 */         int v0 = this.Polys[(t + j)];
/*  956 */         int v1 = (j + 1 >= vertsPerPoly) || (this.Polys[(t + j + 1)] == MeshNullIdx) ? this.Polys[(t + 0)] : this.Polys[(t + j + 1)];
/*  957 */         if (v0 >= v1)
/*      */           continue;
/*  959 */         Edge edge = edges[edgeCount];
/*  960 */         edge.Vert[0] = v0;
/*  961 */         edge.Vert[1] = v1;
/*  962 */         edge.Poly[0] = i;
/*  963 */         edge.PolyEdge[0] = j;
/*  964 */         edge.Poly[1] = i;
/*  965 */         edge.PolyEdge[1] = 0;
/*      */ 
/*  967 */         nextEdge[edgeCount] = firstEdge[v0];
/*  968 */         firstEdge[v0] = edgeCount;
/*  969 */         edgeCount++;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  974 */     for (int i = 0; i < this.NPolys; i++)
/*      */     {
/*  976 */       int t = i * vertsPerPoly * 2;
/*  977 */       for (int j = 0; j < vertsPerPoly; j++)
/*      */       {
/*  979 */         if (this.Polys[(t + j)] == MeshNullIdx) break;
/*  980 */         int v0 = this.Polys[(t + j)];
/*  981 */         int v1 = (j + 1 >= vertsPerPoly) || (this.Polys[(t + j + 1)] == MeshNullIdx) ? this.Polys[(t + 0)] : this.Polys[(t + j + 1)];
/*  982 */         if (v0 <= v1)
/*      */           continue;
/*  984 */         for (int e = firstEdge[v1]; e < MeshNullIdx; e = nextEdge[e])
/*      */         {
/*  986 */           Edge edge = edges[e];
/*  987 */           if ((edge.Vert[1] != v0) || (edge.Poly[0] != edge.Poly[1]))
/*      */             continue;
/*  989 */           edge.Poly[1] = i;
/*  990 */           edge.PolyEdge[1] = j;
/*  991 */           break;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  998 */     for (int i = 0; i < edgeCount; i++)
/*      */     {
/* 1000 */       Edge e = edges[i];
/* 1001 */       if (e.Poly[0] == e.Poly[1])
/*      */         continue;
/* 1003 */       int p0 = e.Poly[0] * vertsPerPoly * 2;
/* 1004 */       int p1 = e.Poly[1] * vertsPerPoly * 2;
/*      */ 
/* 1006 */       this.Polys[(p0 + vertsPerPoly + e.PolyEdge[0])] = e.Poly[1];
/* 1007 */       this.Polys[(p1 + vertsPerPoly + e.PolyEdge[1])] = e.Poly[0];
/*      */     }
/*      */ 
/* 1011 */     return Boolean.valueOf(true);
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.PolyMesh
 * JD-Core Version:    0.6.0
 */