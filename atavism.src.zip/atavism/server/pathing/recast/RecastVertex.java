/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ public class RecastVertex
/*     */ {
/*     */   protected float[] Verts;
/*     */   public float X;
/*     */   public float Y;
/*     */   public float Z;
/*     */ 
/*     */   public float getX()
/*     */   {
/*  11 */     return this.Verts[0];
/*     */   }
/*     */   public void setX(float value) {
/*  14 */     this.Verts[0] = value;
/*     */   }
/*     */ 
/*     */   public float getY() {
/*  18 */     return this.Verts[1];
/*     */   }
/*     */   public void setY(float value) {
/*  21 */     this.Verts[1] = value;
/*     */   }
/*     */ 
/*     */   public float getZ() {
/*  25 */     return this.Verts[2];
/*     */   }
/*     */   public void setZ(float value) {
/*  28 */     this.Verts[2] = value;
/*     */   }
/*     */ 
/*     */   public RecastVertex()
/*     */   {
/*  33 */     this.Verts = new float[3];
/*     */   }
/*     */ 
/*     */   public RecastVertex(RecastVertex copy)
/*     */   {
/*  38 */     this.X = copy.X;
/*  39 */     this.Y = copy.Y;
/*  40 */     this.Z = copy.Z;
/*     */   }
/*     */ 
/*     */   public RecastVertex(float x, float y, float z)
/*     */   {
/*  45 */     this.X = x;
/*  46 */     this.Y = y;
/*  47 */     this.Z = z;
/*     */   }
/*     */ 
/*     */   public RecastVertex(float[] inArray)
/*     */   {
/*     */     try
/*     */     {
/*  54 */       if (inArray.length < 3)
/*  55 */         throw new Exception();
/*     */     }
/*     */     catch (Exception e) {
/*  58 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  61 */     this.X = inArray[0];
/*  62 */     this.Y = inArray[1];
/*  63 */     this.Z = inArray[2];
/*     */   }
/*     */ 
/*     */   public float[] ToArray()
/*     */   {
/*  68 */     return this.Verts;
/*     */   }
/*     */ 
/*     */   public Boolean Equals(RecastVertex other)
/*     */   {
/*  74 */     if (other == null) return Boolean.valueOf(false);
/*  75 */     if (other == this) return Boolean.valueOf(true);
/*  76 */     return Boolean.valueOf((other.X == this.X) && (other.Y == this.Y) && (other.Z == this.Z));
/*     */   }
/*     */ 
/*     */   public Boolean Equals(Object obj)
/*     */   {
/*  81 */     if (obj == null) return Boolean.valueOf(false);
/*  82 */     if (obj == this) return Boolean.valueOf(true);
/*  83 */     if (obj.getClass().isInstance(RecastVertex.class)) return Boolean.valueOf(false);
/*  84 */     return Equals((RecastVertex)obj);
/*     */   }
/*     */ 
/*     */   public static RecastVertex Add(RecastVertex left, RecastVertex right)
/*     */   {
/*  91 */     return new RecastVertex(left.X + right.X, left.Y + right.Y, left.Z + right.Z);
/*     */   }
/*     */ 
/*     */   public static RecastVertex Sub(RecastVertex left, RecastVertex right)
/*     */   {
/* 101 */     return new RecastVertex(left.X - right.X, left.Y - right.Y, left.Z - right.Z);
/*     */   }
/*     */ 
/*     */   public static RecastVertex Mult(RecastVertex left, int scale)
/*     */   {
/* 111 */     return new RecastVertex(left.X * scale, left.Y * scale, left.Z * scale);
/*     */   }
/*     */ 
/*     */   public static RecastVertex Mult(RecastVertex left, RecastVertex right, int scale)
/*     */   {
/* 121 */     return new RecastVertex(left.X + right.X * scale, left.Y + right.Y * scale, left.Z + right.Z * scale);
/*     */   }
/*     */ 
/*     */   public static RecastVertex Cross(RecastVertex left, RecastVertex right)
/*     */   {
/* 131 */     return new RecastVertex(left.Y * right.Z - left.Z * right.Y, left.Z * right.X - left.X * right.Z, left.X * right.Y - left.Y * right.X);
/*     */   }
/*     */ 
/*     */   public static float Dot(RecastVertex left, RecastVertex right)
/*     */   {
/* 141 */     return left.X * right.X + left.Y * right.Y + left.Z * right.Z;
/*     */   }
/*     */ 
/*     */   public static RecastVertex Min(RecastVertex left, RecastVertex right)
/*     */   {
/* 146 */     return new RecastVertex(Math.min(left.X, right.X), Math.min(left.Y, right.Y), Math.min(left.Z, right.Z));
/*     */   }
/*     */ 
/*     */   public static RecastVertex Max(RecastVertex left, RecastVertex right)
/*     */   {
/* 156 */     return new RecastVertex(Math.max(left.X, right.X), Math.max(left.Y, right.Y), Math.max(left.Z, right.Z));
/*     */   }
/*     */ 
/*     */   public static float Distance(RecastVertex left, RecastVertex right)
/*     */   {
/* 165 */     float dx = right.X - left.X;
/* 166 */     float dy = right.Y - left.Y;
/* 167 */     float dz = right.Z - left.Z;
/* 168 */     return (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
/*     */   }
/*     */ 
/*     */   public static float SquareDistance(RecastVertex left, RecastVertex right)
/*     */   {
/* 173 */     float dx = right.X - left.X;
/* 174 */     float dy = right.Y - left.Y;
/* 175 */     float dz = right.Z - left.Z;
/* 176 */     return dx * dx + dy * dy + dz * dz;
/*     */   }
/*     */ 
/*     */   public void Normalize()
/*     */   {
/* 181 */     float d = (float)(1.0D / Math.sqrt(this.X * this.X + this.Y * this.Y + this.Z * this.Z));
/* 182 */     this.X *= d;
/* 183 */     this.Y *= d;
/* 184 */     this.Z *= d;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.RecastVertex
 * JD-Core Version:    0.6.0
 */