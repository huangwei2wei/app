package atavism.server.pathing.recast;

public class Contour
{
  public int[] Verts;
  public int NVerts;
  public int[] RVerts;
  public int NRVerts;
  public int Reg;
  public short Area;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.Contour
 * JD-Core Version:    0.6.0
 */