/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Geometry
/*     */ {
/*  12 */   public static short WalkableArea = 63;
/*     */   public ArrayList<RecastVertex> Vertexes;
/*     */   public int NumVertexes;
/*     */   public ArrayList<Integer> Triangles;
/*     */   public int NumTriangles;
/*     */   public RecastVertex MaxBounds;
/*     */   public RecastVertex MinBounds;
/*     */   private int _walkableAreas;
/*     */   public ChunkyTriMesh ChunkyTriMesh;
/*     */   public ArrayList<Float> OffMeshConnectionVerts;
/*     */   public ArrayList<Float> OffMeshConnectionRadii;
/*     */   public ArrayList<Integer> OffMeshConnectionDirections;
/*     */   public ArrayList<Integer> OffMeshConnectionAreas;
/*     */   public ArrayList<Integer> OffMeshConnectionFlags;
/*     */   public ArrayList<Long> OffMeshConnectionIds;
/*     */   public long OffMeshConnectionCount;
/*     */ 
/*     */   public int WalkableAreas()
/*     */   {
/*  34 */     return this._walkableAreas;
/*     */   }
/*     */ 
/*     */   public Geometry()
/*     */   {
/*  39 */     this.Vertexes = new ArrayList();
/*  40 */     this.Triangles = new ArrayList();
/*  41 */     this.OffMeshConnectionVerts = new ArrayList();
/*  42 */     this.OffMeshConnectionRadii = new ArrayList();
/*  43 */     this.OffMeshConnectionDirections = new ArrayList();
/*  44 */     this.OffMeshConnectionAreas = new ArrayList();
/*  45 */     this.OffMeshConnectionFlags = new ArrayList();
/*  46 */     this.OffMeshConnectionIds = new ArrayList();
/*     */   }
/*     */ 
/*     */   public Geometry(String filename)
/*     */   {
/*  51 */     this.Vertexes = new ArrayList();
/*  52 */     this.Triangles = new ArrayList();
/*     */     try
/*     */     {
/*  56 */       BufferedReader br = new BufferedReader(new FileReader(filename));
/*     */       String line;
/*  58 */       while ((line = br.readLine()) != null)
/*     */       {
/*  60 */         if ((line.charAt(0) == '#') || (
/*  61 */           ((line.charAt(0) == 'v') && (line.charAt(1) != 'n') && (line.charAt(1) != 't')) && 
/*  69 */           (line.charAt(0) != 'f')))
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  85 */       e.printStackTrace();
/*     */     }
/*  87 */     CalculateBounds();
/*     */   }
/*     */ 
/*     */   public void CalculateBounds()
/*     */   {
/*  92 */     if (this.Vertexes.size() != 0)
/*     */     {
/*  94 */       this.MinBounds = ((RecastVertex)this.Vertexes.get(0));
/*  95 */       this.MaxBounds = ((RecastVertex)this.Vertexes.get(0));
/*  96 */       for (RecastVertex recastVertex : this.Vertexes)
/*     */       {
/*  98 */         this.MinBounds = RecastVertex.Min(this.MinBounds, recastVertex);
/*  99 */         this.MaxBounds = RecastVertex.Max(this.MaxBounds, recastVertex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void MarkWalkableTriangles(float walkableSlopeAngle, short[] areas)
/*     */   {
/* 106 */     MarkWalkableTriangles(walkableSlopeAngle, this.Triangles, this.NumTriangles, areas);
/*     */   }
/*     */ 
/*     */   public void MarkWalkableTriangles(float walkableSlopeAngle, List<Integer> triangles, int numTriangles, short[] areas)
/*     */   {
/* 112 */     float walkableThr = (float)Math.cos(walkableSlopeAngle / 180.0F * 3.141592653589793D);
/* 113 */     float[] norm = new float[3];
/* 114 */     this._walkableAreas = 0;
/* 115 */     for (int i = 0; i < numTriangles; i++)
/*     */     {
/* 117 */       int tri = i * 3;
/* 118 */       CalcTriNormal((RecastVertex)this.Vertexes.get(((Integer)triangles.get(tri + 0)).intValue()), (RecastVertex)this.Vertexes.get(((Integer)triangles.get(tri + 1)).intValue()), (RecastVertex)this.Vertexes.get(((Integer)triangles.get(tri + 2)).intValue()), norm);
/*     */ 
/* 121 */       if (norm[1] - walkableThr > 0.0F)
/* 122 */         areas[i] = WalkableArea;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void CalcTriNormal(RecastVertex v0, RecastVertex v1, RecastVertex v2, float[] norm)
/*     */   {
/* 133 */     RecastVertex e0 = RecastVertex.Sub(v1, v0);
/* 134 */     RecastVertex e1 = RecastVertex.Sub(v2, v0);
/* 135 */     RecastVertex n = RecastVertex.Cross(e0, e1);
/* 136 */     n.Normalize();
/* 137 */     norm = n.ToArray();
/*     */   }
/*     */ 
/*     */   public void CreateChunkyTriMesh()
/*     */   {
/* 142 */     this.ChunkyTriMesh = new ChunkyTriMesh((RecastVertex[])(RecastVertex[])this.Vertexes.toArray(), (Integer[])(Integer[])this.Triangles.toArray(), this.NumTriangles, 256);
/*     */   }
/*     */ 
/*     */   public void AddOffMeshConnection(RecastVertex start, RecastVertex end, float radius, Boolean biDirectional, short area, int flags)
/*     */   {
/* 148 */     this.OffMeshConnectionVerts.add(Float.valueOf(start.X));
/* 149 */     this.OffMeshConnectionVerts.add(Float.valueOf(start.Y));
/* 150 */     this.OffMeshConnectionVerts.add(Float.valueOf(start.Z));
/* 151 */     this.OffMeshConnectionVerts.add(Float.valueOf(end.X));
/* 152 */     this.OffMeshConnectionVerts.add(Float.valueOf(end.Y));
/* 153 */     this.OffMeshConnectionVerts.add(Float.valueOf(end.Z));
/* 154 */     this.OffMeshConnectionRadii.add(Float.valueOf(radius));
/* 155 */     this.OffMeshConnectionDirections.add(Integer.valueOf(biDirectional.booleanValue() ? 1 : 0));
/* 156 */     this.OffMeshConnectionAreas.add(Integer.valueOf(area));
/* 157 */     this.OffMeshConnectionFlags.add(Integer.valueOf(flags));
/* 158 */     this.OffMeshConnectionIds.add(Long.valueOf(1000L + this.OffMeshConnectionCount++));
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.Geometry
 * JD-Core Version:    0.6.0
 */