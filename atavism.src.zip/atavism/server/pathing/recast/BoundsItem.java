/*    */ package atavism.server.pathing.recast;
/*    */ 
/*    */ public class BoundsItem
/*    */ {
/*    */   public float[] bmin;
/*    */   public float[] bmax;
/*    */   public int i;
/*    */ 
/*    */   public BoundsItem()
/*    */   {
/* 11 */     this.bmin = new float[2];
/* 12 */     this.bmax = new float[2];
/* 13 */     this.i = 0;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.BoundsItem
 * JD-Core Version:    0.6.0
 */