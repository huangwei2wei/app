/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ import atavism.server.math.IntVector2;
/*     */ import atavism.server.objects.Vector2;
/*     */ import atavism.server.pathing.detour.DetourNumericReturn;
/*     */ 
/*     */ public class Helper
/*     */ {
/*   9 */   public static int NavMeshMagic = 1;
/*  10 */   public static int NavMeshVersion = 1;
/*  11 */   public static int StatusDetailMast = 268435455;
/*  12 */   protected static int[] offsetX = { -1, 0, 1, 0 };
/*  13 */   protected static int[] offsetY = { 0, 1, 0, -1 };
/*     */ 
/*     */   public static int GetDirOffsetX(int dir)
/*     */   {
/*  21 */     return offsetX[(dir & 0x3)];
/*     */   }
/*     */ 
/*     */   public static int GetDirOffsetY(int dir)
/*     */   {
/*  26 */     return offsetY[(dir & 0x3)];
/*     */   }
/*     */ 
/*     */   public static long NextPow2(long v)
/*     */   {
/*  31 */     v -= 1L;
/*  32 */     v |= v >> 1;
/*  33 */     v |= v >> 2;
/*  34 */     v |= v >> 4;
/*  35 */     v |= v >> 8;
/*  36 */     v |= v >> 16;
/*  37 */     v += 1L;
/*  38 */     return v;
/*     */   }
/*     */ 
/*     */   public static long Ilog2(long v)
/*     */   {
/*  45 */     long r = v > 65535L ? 16L : 0L;
/*  46 */     v >>= (int)r;
/*  47 */     long shift = v > 255L ? 8L : 0L; v >>= (int)shift; r |= shift;
/*  48 */     shift = v > 15L ? 4L : 0L; v >>= (int)shift; r |= shift;
/*  49 */     shift = v > 3L ? 2L : 0L; v >>= (int)shift; r |= shift;
/*  50 */     r |= v >> 1;
/*  51 */     return r;
/*     */   }
/*     */ 
/*     */   public static float GetSlabCoord(float vax, float vay, float vaz, int side)
/*     */   {
/*  56 */     if ((side == 0) || (side == 4))
/*  57 */       return vax;
/*  58 */     if ((side == 2) || (side == 6))
/*  59 */       return vaz;
/*  60 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public static void CalcSlabEndPoints(float vax, float vay, float vaz, float vbx, float vby, float vbz, float[] bmin, float[] bmax, int side)
/*     */   {
/*  65 */     if ((side == 0) || (side == 4))
/*     */     {
/*  67 */       if (vaz < vbz)
/*     */       {
/*  69 */         bmin[0] = vaz;
/*  70 */         bmin[1] = vay;
/*  71 */         bmax[0] = vbz;
/*  72 */         bmax[1] = vby;
/*     */       }
/*     */       else
/*     */       {
/*  76 */         bmin[0] = vbz;
/*  77 */         bmin[1] = vby;
/*  78 */         bmax[0] = vaz;
/*  79 */         bmax[1] = vay;
/*     */       }
/*     */     }
/*  82 */     else if ((side == 2) || (side == 6))
/*     */     {
/*  84 */       if (vax < vbx)
/*     */       {
/*  86 */         bmin[0] = vax;
/*  87 */         bmin[1] = vay;
/*  88 */         bmax[0] = vbx;
/*  89 */         bmax[1] = vby;
/*     */       }
/*     */       else
/*     */       {
/*  93 */         bmin[0] = vbx;
/*  94 */         bmin[1] = vby;
/*  95 */         bmax[0] = vax;
/*  96 */         bmax[1] = vay;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Boolean OverlapSlabs(float[] amin, float[] amax, float[] bmin, float[] bmax, float px, float py)
/*     */   {
/* 103 */     float minx = Math.max(amin[0] + px, bmin[0] + px);
/* 104 */     float maxx = Math.min(amax[0] - px, bmax[0] - px);
/* 105 */     if (minx > maxx) {
/* 106 */       return Boolean.valueOf(false);
/*     */     }
/* 108 */     float ad = (amax[1] - amin[1]) / (amax[0] - amin[0]);
/* 109 */     float ak = amin[1] - ad * amin[0];
/* 110 */     float bd = (bmax[1] - bmin[1]) / (bmax[0] - bmin[0]);
/* 111 */     float bk = bmin[1] - bd * bmin[0];
/* 112 */     float aminy = ad * minx + ak;
/* 113 */     float amaxy = ad * maxx + ak;
/* 114 */     float bminy = bd * minx + bk;
/* 115 */     float bmaxy = bd * maxx + bk;
/* 116 */     float dmin = bminy - aminy;
/* 117 */     float dmax = bmaxy - amaxy;
/*     */ 
/* 119 */     if (dmin * dmax < 0.0F) {
/* 120 */       return Boolean.valueOf(true);
/*     */     }
/* 122 */     float thr = py * 2.0F * (py * 2.0F);
/* 123 */     if ((dmin * dmin <= thr) || (dmax * dmax <= thr)) {
/* 124 */       return Boolean.valueOf(true);
/*     */     }
/* 126 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */   public static int OppositeTile(int side)
/*     */   {
/* 131 */     return side + 4 & 0x7;
/*     */   }
/*     */ 
/*     */   public static float VDist(float v1x, float v1y, float v1z, float v2x, float v2y, float v2z)
/*     */   {
/* 136 */     float dx = v2x - v1x;
/* 137 */     float dy = v2y - v1y;
/* 138 */     float dz = v2z - v1z;
/* 139 */     return (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
/*     */   }
/*     */ 
/*     */   public static float[] VLerp(float[] dest, float v1x, float v1y, float v1z, float v2x, float v2y, float v2z, float t)
/*     */   {
/* 144 */     dest[0] = (v1x + (v2x - v1x) * t);
/* 145 */     dest[1] = (v1y + (v2y - v1y) * t);
/* 146 */     dest[2] = (v1z + (v2z - v1z) * t);
/* 147 */     return dest;
/*     */   }
/*     */ 
/*     */   public static Boolean DistancePtPolyEdgesSqr(float ptx, float pty, float ptz, float[] verts, int nverts, float[] ed, float[] et)
/*     */   {
/* 153 */     Boolean c = Boolean.valueOf(false);
/* 154 */     int i = 0; for (int j = nverts - 1; i < nverts; j = i++)
/*     */     {
/* 156 */       int vi = i * 3;
/* 157 */       int vj = j * 3;
/* 158 */       if ((verts[(vi + 2)] > ptz ? 1 : 0) != (verts[(vj + 2)] > ptz ? 1 : 0)) if (ptx < (verts[(vj + 0)] - verts[(vi + 0)]) * (ptz - verts[(vi + 2)]) / (verts[(vj + 2)] - verts[(vi + 2)]) + verts[(vi + 0)])
/*     */         {
/* 160 */           c = Boolean.valueOf(!c.booleanValue());
/*     */         } ed[j] = DistancePtSegSqr2D(ptx, pty, ptz, verts[(vj + 0)], verts[(vj + 1)], verts[(vj + 2)], verts[(vi + 0)], verts[(vi + 1)], verts[(vi + 2)], et, j);
/*     */     }
/*     */ 
/* 165 */     return c;
/*     */   }
/*     */ 
/*     */   public static float DistancePtSegSqr2D(float ptx, float pty, float ptz, float px, float py, float pz, float qx, float qy, float qz, float[] et, int t)
/*     */   {
/* 170 */     float pqx = qx - px;
/* 171 */     float pqz = qz - pz;
/* 172 */     float dx = ptx - px;
/* 173 */     float dz = ptz - pz;
/* 174 */     float d = pqx * pqx + pqz * pqz;
/* 175 */     et[t] = (pqx * dx + pqz * dz);
/* 176 */     if (d > 0.0F) et[t] /= d;
/* 177 */     if (et[t] < 0.0F) et[t] = 0.0F;
/* 178 */     else if (et[t] > 1.0F) et[t] = 1.0F;
/* 179 */     dx = px + et[t] * pqx - ptx;
/* 180 */     dz = pz + et[t] * pqz - ptz;
/* 181 */     return dx * dx + dz * dz;
/*     */   }
/*     */ 
/*     */   public static Vector2 DistancePtSegSqr2D(float ptx, float pty, float ptz, float px, float py, float pz, float qx, float qy, float qz)
/*     */   {
/* 186 */     Vector2 numericReturn = new Vector2();
/* 187 */     float pqx = qx - px;
/* 188 */     float pqz = qz - pz;
/* 189 */     float dx = ptx - px;
/* 190 */     float dz = ptz - pz;
/* 191 */     float d = pqx * pqx + pqz * pqz;
/* 192 */     float t = pqx * dx + pqz * dz;
/* 193 */     if (d > 0.0F) t /= d;
/* 194 */     if (t < 0.0F) t = 0.0F;
/* 195 */     else if (t > 1.0F) t = 1.0F;
/* 196 */     dx = px + t * pqx - ptx;
/* 197 */     dz = pz + t * pqz - ptz;
/* 198 */     numericReturn.x = (dx * dx + dz * dz);
/* 199 */     numericReturn.y = t;
/* 200 */     return numericReturn;
/*     */   }
/*     */ 
/*     */   public static DetourNumericReturn ClosestHeightPointTriangle(float px, float py, float pz, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz)
/*     */   {
/* 205 */     DetourNumericReturn numericReturn = new DetourNumericReturn();
/* 206 */     float[] v0 = VSub(cx, cy, cz, ax, ay, az);
/* 207 */     float[] v1 = VSub(bx, by, bz, ax, ay, az);
/* 208 */     float[] v2 = VSub(px, py, pz, ax, ay, az);
/*     */ 
/* 210 */     float dot00 = VDot2D(v0, v0);
/* 211 */     float dot01 = VDot2D(v0, v1);
/* 212 */     float dot02 = VDot2D(v0, v2);
/* 213 */     float dot11 = VDot2D(v1, v1);
/* 214 */     float dot12 = VDot2D(v1, v2);
/*     */ 
/* 216 */     float invDenom = 1.0F / (dot00 * dot11 - dot01 * dot01);
/* 217 */     float u = (dot11 * dot02 - dot01 * dot12) * invDenom;
/* 218 */     float v = (dot00 * dot12 - dot01 * dot02) * invDenom;
/*     */ 
/* 220 */     float EPS = 1.0E-004F;
/* 221 */     if ((u >= -EPS) && (v >= -EPS) && (u + v <= 1.0F + EPS))
/*     */     {
/* 223 */       numericReturn.floatValue = (ay + v0[1] * u + v1[1] * v);
/* 224 */       numericReturn.boolValue = Boolean.valueOf(true);
/* 225 */       return numericReturn;
/*     */     }
/* 227 */     numericReturn.boolValue = Boolean.valueOf(false);
/* 228 */     return numericReturn;
/*     */   }
/*     */ 
/*     */   public static float VDot2D(float[] u, float[] v)
/*     */   {
/* 233 */     return u[0] * v[0] + u[2] * v[2];
/*     */   }
/*     */ 
/*     */   public static float VDot(float[] u, float[] v)
/*     */   {
/* 238 */     return u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
/*     */   }
/*     */ 
/*     */   public static float[] VMad(float[] dest, float[] v1, float[] v2, float s)
/*     */   {
/* 243 */     v1[0] += v2[0] * s;
/* 244 */     v1[1] += v2[1] * s;
/* 245 */     v1[2] += v2[2] * s;
/* 246 */     return dest;
/*     */   }
/*     */ 
/*     */   public static float[] VSub(float v1x, float v1y, float v1z, float v2x, float v2y, float v2z)
/*     */   {
/* 251 */     float[] dest = new float[3];
/* 252 */     dest[0] = (v1x - v2x);
/* 253 */     dest[1] = (v1y - v2y);
/* 254 */     dest[2] = (v1z - v2z);
/*     */ 
/* 256 */     return dest;
/*     */   }
/*     */ 
/*     */   public static float[] VAdd(float v1x, float v1y, float v1z, float v2x, float v2y, float v2z)
/*     */   {
/* 261 */     float[] dest = new float[3];
/* 262 */     dest[0] = (v1x + v2x);
/* 263 */     dest[1] = (v1y + v2y);
/* 264 */     dest[2] = (v1z + v2z);
/* 265 */     return dest;
/*     */   }
/*     */ 
/*     */   public static float VDistSqr(float v1x, float v1y, float v1z, float v2x, float v2y, float v2z)
/*     */   {
/* 270 */     float dx = v2x - v1x;
/* 271 */     float dy = v2y - v1y;
/* 272 */     float dz = v2z - v1z;
/* 273 */     return dx * dx + dy * dy + dz * dz;
/*     */   }
/*     */ 
/*     */   public static Boolean OverlapQuantBounds(int[] amin, int[] amax, int[] bmin, int[] bmax)
/*     */   {
/* 278 */     Boolean overlap = Boolean.valueOf(true);
/* 279 */     overlap = Boolean.valueOf((amin[0] > bmax[0]) || (amax[0] < bmin[0]) ? false : overlap.booleanValue());
/* 280 */     overlap = Boolean.valueOf((amin[1] > bmax[1]) || (amax[1] < bmin[1]) ? false : overlap.booleanValue());
/* 281 */     overlap = Boolean.valueOf((amin[2] > bmax[2]) || (amax[2] < bmin[2]) ? false : overlap.booleanValue());
/* 282 */     return overlap;
/*     */   }
/*     */ 
/*     */   public static float[] VMin(float[] mn, float vx, float vy, float vz)
/*     */   {
/* 287 */     mn[0] = Math.min(mn[0], vx);
/* 288 */     mn[1] = Math.min(mn[1], vx);
/* 289 */     mn[2] = Math.min(mn[2], vx);
/* 290 */     return mn;
/*     */   }
/*     */ 
/*     */   public static float[] VMax(float[] mn, float vx, float vy, float vz)
/*     */   {
/* 295 */     mn[0] = Math.max(mn[0], vx);
/* 296 */     mn[1] = Math.max(mn[1], vx);
/* 297 */     mn[2] = Math.max(mn[2], vx);
/* 298 */     return mn;
/*     */   }
/*     */ 
/*     */   public static Boolean OverlapBounds(float aminx, float aminy, float aminz, float amaxx, float amaxy, float amaxz, float bminx, float bminy, float bminz, float bmaxx, float bmaxy, float bmaxz)
/*     */   {
/* 303 */     Boolean overlap = Boolean.valueOf(true);
/* 304 */     overlap = Boolean.valueOf((aminx > bmaxx) || (amaxx < bminx) ? false : overlap.booleanValue());
/* 305 */     overlap = Boolean.valueOf((aminy > bmaxy) || (amaxy < bminy) ? false : overlap.booleanValue());
/* 306 */     overlap = Boolean.valueOf((aminz > bmaxz) || (amaxz < bminz) ? false : overlap.booleanValue());
/* 307 */     return overlap;
/*     */   }
/*     */ 
/*     */   public static long HashRef(long a)
/*     */   {
/* 313 */     a += (a << 15 ^ 0xFFFFFFFF);
/* 314 */     a ^= a >> 10;
/* 315 */     a += (a << 3);
/* 316 */     a ^= a >> 6;
/* 317 */     a += (a << 11 ^ 0xFFFFFFFF);
/* 318 */     a ^= a >> 16;
/* 319 */     return a;
/*     */   }
/*     */ 
/*     */   public static float TriArea2D(float[] a, float[] b, float[] c)
/*     */   {
/* 324 */     float abx = b[0] - a[0];
/* 325 */     float abz = b[2] - a[2];
/* 326 */     float acx = c[0] - a[0];
/* 327 */     float acz = c[2] - a[2];
/* 328 */     return acx * abz - abx * acz;
/*     */   }
/*     */ 
/*     */   public static void RandomPointInConvexPoly(float[] pts, int npts, float[] areas, float s, float t, float[] outPt)
/*     */   {
/* 333 */     float areasum = 0.0F;
/* 334 */     float[] va = new float[3]; float[] vb = new float[3]; float[] vc = new float[3];
/* 335 */     for (int i = 2; i < npts; i++)
/*     */     {
/* 337 */       System.arraycopy(pts, 0, va, 0, 3);
/* 338 */       System.arraycopy(pts, (i - 1) * 3, vb, 0, 3);
/* 339 */       System.arraycopy(pts, i * 3, vc, 0, 3);
/* 340 */       areas[i] = TriArea2D(va, vb, vc);
/* 341 */       areasum += Math.max(0.001F, areas[i]);
/*     */     }
/*     */ 
/* 344 */     float thr = s * areasum;
/* 345 */     float acc = 0.0F;
/* 346 */     float u = 0.0F;
/* 347 */     int tri = 0;
/* 348 */     for (int i = 2; i < npts; i++)
/*     */     {
/* 350 */       float dacc = areas[i];
/* 351 */       if ((thr >= acc) && (thr < acc + dacc))
/*     */       {
/* 353 */         u = (thr - acc) / dacc;
/* 354 */         tri = i;
/* 355 */         break;
/*     */       }
/* 357 */       acc += dacc;
/*     */     }
/*     */ 
/* 360 */     float v = (float)Math.sqrt(t);
/*     */ 
/* 362 */     float a = 1.0F - v;
/* 363 */     float b = (1.0F - u) * v;
/* 364 */     float c = u * v;
/* 365 */     int pa = 0;
/* 366 */     int pb = (tri - 1) * 3;
/* 367 */     int pc = tri * 3;
/*     */ 
/* 369 */     outPt[0] = (a * pts[(pa + 0)] + b * pts[(pb + 0)] + c * pts[(pc + 0)]);
/* 370 */     outPt[1] = (a * pts[(pa + 1)] + b * pts[(pb + 1)] + c * pts[(pc + 1)]);
/* 371 */     outPt[2] = (a * pts[(pa + 2)] + b * pts[(pb + 2)] + c * pts[(pc + 2)]);
/*     */   }
/*     */ 
/*     */   public static Boolean VEqual(float p0x, float p0y, float p0z, float p1x, float p1y, float p1z)
/*     */   {
/* 376 */     float thr = 3.72529E-009F;
/* 377 */     float d = VDistSqr(p0x, p0y, p0z, p1x, p1y, p1z);
/* 378 */     return Boolean.valueOf(d < thr);
/*     */   }
/*     */ 
/*     */   public static DetourNumericReturn IntersectSegSeg2D(float apx, float apy, float apz, float aqx, float aqy, float aqz, float[] bp, float[] bq)
/*     */   {
/* 383 */     DetourNumericReturn numericReturn = new DetourNumericReturn();
/* 384 */     float[] u = VSub(aqx, aqy, aqz, apx, apy, apz);
/* 385 */     float[] v = VSub(bq[0], bq[1], bq[2], bp[0], bp[1], bp[2]);
/* 386 */     float[] w = VSub(apx, apy, apz, bp[0], bp[1], bp[2]);
/* 387 */     float d = VPerpXZ(u, v);
/* 388 */     if (Math.abs(d) < 1.0E-006F) {
/* 389 */       numericReturn.boolValue = Boolean.valueOf(false);
/* 390 */       return numericReturn;
/*     */     }
/* 392 */     Vector2 vectorVal = new Vector2();
/* 393 */     vectorVal.x = (VPerpXZ(v, w) / d);
/* 394 */     vectorVal.y = (VPerpXZ(u, w) / d);
/* 395 */     numericReturn.vector2Value = vectorVal;
/* 396 */     numericReturn.boolValue = Boolean.valueOf(true);
/* 397 */     return numericReturn;
/*     */   }
/*     */ 
/*     */   private static float VPerpXZ(float[] a, float[] b)
/*     */   {
/* 402 */     return a[0] * b[2] - a[2] * b[0];
/*     */   }
/*     */ 
/*     */   public static Boolean PointInPolygon(float ptx, float pty, float ptz, float[] verts, int nverts)
/*     */   {
/* 408 */     Boolean c = Boolean.valueOf(false);
/* 409 */     int i = 0; for (int j = nverts - 1; i < nverts; j = i++)
/*     */     {
/* 411 */       int vi = i * 3;
/* 412 */       int vj = j * 3;
/* 413 */       if ((verts[(vi + 2)] > ptz ? 1 : 0) == (verts[(vj + 2)] > ptz ? 1 : 0)) continue; if (ptx >= (verts[(vj + 0)] - verts[(vi + 0)]) * (ptz - verts[(vi + 2)]) / (verts[(vj + 2)] - verts[(vi + 2)]) + verts[(vi + 0)])
/*     */         continue;
/* 415 */       c = Boolean.valueOf(!c.booleanValue());
/*     */     }
/* 417 */     return c;
/*     */   }
/*     */ 
/*     */   public static Boolean IntersectSegmentPoly2D(float[] p0, float[] p1, float[] verts, int nverts, Vector2 tMinMax, IntVector2 segMinMax)
/*     */   {
/* 422 */     float EPS = 1.0E-008F;
/*     */ 
/* 424 */     tMinMax.x = 0.0D;
/* 425 */     tMinMax.y = 1.0D;
/* 426 */     segMinMax.x = -1;
/* 427 */     segMinMax.y = -1;
/*     */ 
/* 429 */     float[] dir = VSub(p1[0], p1[1], p1[2], p0[0], p0[1], p0[2]);
/*     */ 
/* 431 */     int i = 0; for (int j = nverts - 1; i < nverts; j = i++)
/*     */     {
/* 433 */       float[] edge = VSub(verts[(i * 3 + 0)], verts[(i * 3 + 1)], verts[(i * 3 + 2)], verts[(j * 3 + 0)], verts[(j * 3 + 1)], verts[(j * 3 + 2)]);
/* 434 */       float[] diff = VSub(p0[0], p0[1], p0[2], verts[(j * 3 + 0)], verts[(j * 3 + 1)], verts[(j * 3 + 2)]);
/* 435 */       float n = VPerp2D(edge, diff);
/* 436 */       float d = VPerp2D(dir, edge);
/* 437 */       if (Math.abs(d) < EPS)
/*     */       {
/* 439 */         if (n < 0.0F) {
/* 440 */           return Boolean.valueOf(false);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 446 */         float t = n / d;
/* 447 */         if (d < 0.0F)
/*     */         {
/* 449 */           if (t <= tMinMax.x)
/*     */             continue;
/* 451 */           tMinMax.x = t;
/* 452 */           segMinMax.x = j;
/* 453 */           if (tMinMax.x > tMinMax.y) {
/* 454 */             return Boolean.valueOf(false);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 459 */           if (t >= tMinMax.y)
/*     */             continue;
/* 461 */           tMinMax.y = t;
/* 462 */           segMinMax.y = j;
/* 463 */           if (tMinMax.y < tMinMax.x)
/* 464 */             return Boolean.valueOf(false);
/*     */         }
/*     */       }
/*     */     }
/* 468 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public static float VPerp2D(float[] u, float[] v)
/*     */   {
/* 473 */     return u[2] * v[0] - u[0] * v[2];
/*     */   }
/*     */ 
/*     */   public static float[] VNormalize(float[] v)
/*     */   {
/* 478 */     float d = 1.0F / (float)Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
/* 479 */     v[0] *= d;
/* 480 */     v[1] *= d;
/* 481 */     v[2] *= d;
/* 482 */     return v;
/*     */   }
/*     */ 
/*     */   public static float[] VScale(float vx, float vy, float vz, float t)
/*     */   {
/* 487 */     float[] dest = { vx * t, vy * t, vz * t };
/* 488 */     return dest;
/*     */   }
/*     */ 
/*     */   public static Boolean OverlapPolyPoly2D(float[] polya, int npolya, float[] polyb, int npolyb)
/*     */   {
/* 493 */     float eps = 1.0E-004F;
/*     */ 
/* 495 */     int i = 0; for (int j = npolya - 1; i < npolya; j = i++)
/*     */     {
/* 497 */       int va = j * 3;
/* 498 */       int vb = i * 3;
/* 499 */       float[] n = { polya[(vb + 2)] - polya[(va + 2)], 0.0F, -(polya[(vb + 0)] - polya[(va + 0)]) };
/* 500 */       Vector2 minMaxA = ProjectPoly(n, polya, npolya);
/* 501 */       Vector2 minMaxB = ProjectPoly(n, polyb, npolyb);
/* 502 */       float amin = (float)minMaxA.x;
/* 503 */       float amax = (float)minMaxA.y;
/* 504 */       float bmin = (float)minMaxB.x;
/* 505 */       float bmax = (float)minMaxB.y;
/* 506 */       if (!OverlapRange(amin, amax, bmin, bmax, eps).booleanValue())
/* 507 */         return Boolean.valueOf(false);
/*     */     }
/* 509 */     int i = 0; for (int j = npolya - 1; i < npolyb; j = i++)
/*     */     {
/* 511 */       int va = j * 3;
/* 512 */       int vb = i * 3;
/* 513 */       float[] n = { polyb[(vb + 2)] - polyb[(va + 2)], 0.0F, -(polyb[(vb + 0)] - polyb[(va + 0)]) };
/* 514 */       Vector2 minMaxA = ProjectPoly(n, polya, npolya);
/* 515 */       Vector2 minMaxB = ProjectPoly(n, polyb, npolyb);
/* 516 */       float amin = (float)minMaxA.x;
/* 517 */       float amax = (float)minMaxA.y;
/* 518 */       float bmin = (float)minMaxB.x;
/* 519 */       float bmax = (float)minMaxB.y;
/* 520 */       if (!OverlapRange(amin, amax, bmin, bmax, eps).booleanValue())
/* 521 */         return Boolean.valueOf(false);
/*     */     }
/* 523 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   private static Boolean OverlapRange(float amin, float amax, float bmin, float bmax, float eps)
/*     */   {
/* 528 */     return Boolean.valueOf((amin + eps <= bmax) && (amax - eps >= bmin));
/*     */   }
/*     */ 
/*     */   private static Vector2 ProjectPoly(float[] axis, float[] poly, int npoly)
/*     */   {
/* 533 */     Vector2 minMax = new Vector2();
/* 534 */     float[] temp = new float[3];
/* 535 */     System.arraycopy(poly, 0, temp, 0, 3);
/* 536 */     (minMax.y = VDot2D(axis, temp)).x = minMax;
/* 537 */     int i = 1;
/*     */ 
/* 539 */     System.arraycopy(poly, i * 3, temp, 0, 3);
/* 540 */     float d = VDot2D(axis, temp);
/* 541 */     minMax.x = Math.min(minMax.x, d);
/* 542 */     minMax.y = Math.max(minMax.y, d);
/*     */ 
/* 537 */     i++;
/*     */ 
/* 544 */     return minMax;
/*     */   }
/*     */ 
/*     */   public static void VSet(float[] dest, float x, float y, float z)
/*     */   {
/* 549 */     dest[0] = x;
/* 550 */     dest[1] = y;
/* 551 */     dest[2] = z;
/*     */   }
/*     */ 
/*     */   public static void VCopy(float[] dest, float[] source)
/*     */   {
/* 556 */     dest[0] = source[0];
/* 557 */     dest[1] = source[1];
/* 558 */     dest[2] = source[2];
/*     */   }
/*     */ 
/*     */   public static float VDist2D(float[] v1, float[] v2)
/*     */   {
/* 563 */     float dx = v2[0] - v1[0];
/* 564 */     float dz = v2[2] - v1[2];
/* 565 */     return (float)Math.sqrt(dx * dx + dz * dz);
/*     */   }
/*     */ 
/*     */   public static float VDist2DSqr(float v1x, float v1y, float v1z, float v2x, float v2y, float v2z)
/*     */   {
/* 570 */     float dx = v2x - v1x;
/* 571 */     float dz = v2z - v1z;
/* 572 */     return dx * dx + dz * dz;
/*     */   }
/*     */ 
/*     */   public static float VLen(float[] v)
/*     */   {
/* 577 */     return (float)Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
/*     */   }
/*     */ 
/*     */   public static float VLenSqr(float[] v)
/*     */   {
/* 582 */     return v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
/*     */   }
/*     */ 
/*     */   public static float Clamp(float v, float min, float max)
/*     */   {
/* 587 */     return v > max ? max : v < min ? min : v;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.Helper
 * JD-Core Version:    0.6.0
 */