/*   */ package atavism.server.pathing.recast;
/*   */ 
/*   */ public class Edge
/*   */ {
/* 5 */   public int[] Vert = new int[2];
/* 6 */   public int[] PolyEdge = new int[2];
/* 7 */   public int[] Poly = new int[2];
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.Edge
 * JD-Core Version:    0.6.0
 */