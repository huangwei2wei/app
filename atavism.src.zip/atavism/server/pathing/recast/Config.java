/*    */ package atavism.server.pathing.recast;
/*    */ 
/*    */ public class Config
/*    */ {
/*    */   public float CellSize;
/*    */   public float CellHeight;
/*    */   public float WalkableSlopeAngle;
/*    */   public int WalkableHeight;
/*    */   public int WalkableClimb;
/*    */   public int WalkableRadius;
/*    */   public int MaxEdgeLength;
/*    */   public float MaxSimplificationError;
/*    */   public int MinRegionArea;
/*    */   public int MergeRegionArea;
/*    */   public int MaxVertexesPerPoly;
/*    */   public float DetailSampleDistance;
/*    */   public float DetailSampleMaxError;
/*    */   public RecastVertex MinBounds;
/*    */   public RecastVertex MaxBounds;
/*    */   public int Width;
/*    */   public int Height;
/*    */   public int BorderSize;
/*    */   public int TileSize;
/*    */ 
/*    */   public void CalculateGridSize(Geometry geom)
/*    */   {
/* 31 */     this.Width = (int)((geom.MaxBounds.X - geom.MinBounds.X) / this.CellSize + 0.5F);
/* 32 */     this.Height = (int)((geom.MaxBounds.Z - geom.MinBounds.Z) / this.CellSize + 0.5F);
/* 33 */     this.MaxBounds = geom.MaxBounds;
/* 34 */     this.MinBounds = geom.MinBounds;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.Config
 * JD-Core Version:    0.6.0
 */