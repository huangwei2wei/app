/*    */ package atavism.server.pathing.recast;
/*    */ 
/*    */ public class SpanPool
/*    */ {
/*  5 */   public static int SpansPerPool = 2048;
/*    */   public SpanPool Next;
/*    */   public Span[] Items;
/*    */ 
/*    */   public SpanPool()
/*    */   {
/* 12 */     this.Items = new Span[SpansPerPool];
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.SpanPool
 * JD-Core Version:    0.6.0
 */