/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ import atavism.server.math.IntVector2;
/*     */ import atavism.server.pathing.detour.DetourNumericReturn;
/*     */ 
/*     */ public class ContourSet
/*     */ {
/*     */   public Contour[] Conts;
/*     */   public int NConts;
/*     */   public float[] BMin;
/*     */   public float[] BMax;
/*     */   public float Cs;
/*     */   public float Ch;
/*     */   public int Width;
/*     */   public int Height;
/*     */   public int BorderSize;
/*  17 */   public static int ContourRegMask = 65535;
/*  18 */   public static int BorderVertex = 65536;
/*  19 */   public static int AreaBorder = 131072;
/*     */ 
/*     */   public ContourSet(CompactHeightfield cfh, float maxError, int maxEdgeLen) {
/*  22 */     this(cfh, maxError, maxEdgeLen, 1);
/*     */   }
/*     */ 
/*     */   public ContourSet(CompactHeightfield cfh, float maxError, int maxEdgeLen, int buildFlags)
/*     */   {
/*  27 */     int w = cfh.Width;
/*  28 */     int h = cfh.Height;
/*  29 */     int borderSize = cfh.BorderSize;
/*     */ 
/*  31 */     this.BMin = new float[3];
/*  32 */     this.BMax = new float[3];
/*  33 */     System.arraycopy(cfh.BMin, 0, this.BMin, 0, 3);
/*  34 */     System.arraycopy(cfh.BMax, 0, this.BMax, 0, 3);
/*     */ 
/*  36 */     if (borderSize > 0)
/*     */     {
/*  38 */       float pad = borderSize * cfh.Cs;
/*  39 */       this.BMin[0] += pad;
/*  40 */       this.BMin[2] += pad;
/*  41 */       this.BMax[0] -= pad;
/*  42 */       this.BMax[2] -= pad;
/*     */     }
/*     */ 
/*  45 */     this.Cs = cfh.Cs;
/*  46 */     this.Ch = cfh.Ch;
/*  47 */     this.Width = (cfh.Width - cfh.BorderSize * 2);
/*  48 */     this.Height = (cfh.Height - cfh.BorderSize * 2);
/*  49 */     this.BorderSize = cfh.BorderSize;
/*  50 */     int maxContours = Math.max(cfh.MaxRegions, 8);
/*  51 */     this.Conts = new Contour[maxContours];
/*  52 */     for (int i = 0; i < maxContours; i++)
/*     */     {
/*  54 */       this.Conts[i] = new Contour();
/*     */     }
/*  56 */     this.NConts = 0;
/*     */ 
/*  58 */     char[] flags = new char[cfh.SpanCount];
/*     */ 
/*  60 */     for (int y = 0; y < h; y++)
/*     */     {
/*  62 */       for (int x = 0; x < w; x++)
/*     */       {
/*  64 */         CompactCell c = cfh.Cells[(x + y * w)];
/*  65 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*     */         {
/*     */           int z;
/*  67 */           if (i == 4782)
/*     */           {
/*  69 */             z = 0;
/*     */           }
/*  71 */           int res = 0;
/*  72 */           CompactSpan s = cfh.Spans[i];
/*  73 */           if ((s.Reg == 0) || ((s.Reg & CompactHeightfield.BorderReg) != 0))
/*     */           {
/*  75 */             flags[i] = '\000';
/*     */           }
/*     */           else {
/*  78 */             for (int dir = 0; dir < 4; dir++)
/*     */             {
/*  80 */               int r = 0;
/*  81 */               if (s.GetCon(dir) != CompactHeightfield.NotConnected)
/*     */               {
/*  83 */                 int ax = x + Helper.GetDirOffsetX(dir);
/*  84 */                 int ay = y + Helper.GetDirOffsetY(dir);
/*  85 */                 int ai = (int)cfh.Cells[(ax + ay * w)].Index + s.GetCon(dir);
/*  86 */                 r = cfh.Spans[ai].Reg;
/*     */               }
/*  88 */               if (r != cfh.Spans[i].Reg)
/*     */                 continue;
/*  90 */               res |= 1 << dir;
/*     */             }
/*     */ 
/*  93 */             flags[i] = (char)(res ^ 0xF);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  98 */     IntArray verts = new IntArray(256);
/*  99 */     IntArray simplified = new IntArray(64);
/*     */ 
/* 101 */     for (int y = 0; y < h; y++)
/*     */     {
/* 103 */       for (int x = 0; x < w; x++)
/*     */       {
/* 105 */         CompactCell c = cfh.Cells[(x + y * w)];
/* 106 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*     */         {
/* 108 */           if ((flags[i] == 0) || (flags[i] == '\017'))
/*     */           {
/* 110 */             flags[i] = '\000';
/*     */           }
/*     */           else
/*     */           {
/* 114 */             int reg = cfh.Spans[i].Reg;
/* 115 */             if ((reg != 0) && ((reg & CompactHeightfield.BorderReg) == 0)) {
/* 116 */               long area = cfh.Areas[i];
/*     */ 
/* 118 */               verts.Resize(0);
/* 119 */               simplified.Resize(0);
/*     */ 
/* 121 */               WalkContour(x, y, i, cfh, flags, verts);
/*     */ 
/* 123 */               SimplifyContour(verts, simplified, maxError, maxEdgeLen, buildFlags);
/* 124 */               RemoveDegenerateSegments(simplified);
/*     */ 
/* 126 */               if (simplified.Size / 4 < 3) {
/*     */                 continue;
/*     */               }
/* 129 */               if (this.NConts >= maxContours)
/*     */               {
/* 131 */                 int oldMax = maxContours;
/* 132 */                 maxContours *= 2;
/* 133 */                 Contour[] newConts = new Contour[maxContours];
/* 134 */                 for (int j = 0; j < maxContours; j++)
/*     */                 {
/* 136 */                   newConts[j] = new Contour();
/*     */                 }
/* 138 */                 for (int j = 0; j < this.NConts; j++)
/*     */                 {
/* 140 */                   newConts[j] = this.Conts[j];
/*     */                 }
/* 142 */                 this.Conts = newConts;
/*     */               }
/* 144 */               Contour cont = this.Conts[(this.NConts++)];
/* 145 */               cont.NVerts = (simplified.Size / 4);
/* 146 */               cont.Verts = new int[cont.NVerts * 4];
/* 147 */               System.arraycopy(simplified.ToArray(), 0, cont.Verts, 0, cont.NVerts * 4);
/* 148 */               if (borderSize > 0)
/*     */               {
/* 150 */                 for (int j = 0; j < cont.NVerts; j++)
/*     */                 {
/* 152 */                   int v = j * 4;
/* 153 */                   cont.Verts[(v + 0)] -= borderSize;
/* 154 */                   cont.Verts[(v + 2)] -= borderSize;
/*     */                 }
/*     */               }
/*     */ 
/* 158 */               cont.NRVerts = (verts.Size / 4);
/* 159 */               cont.RVerts = new int[cont.NRVerts * 4];
/* 160 */               System.arraycopy(verts.ToArray(), 0, cont.RVerts, 0, cont.NRVerts * 4);
/* 161 */               if (borderSize > 0)
/*     */               {
/* 163 */                 for (int j = 0; j < cont.NRVerts; j++)
/*     */                 {
/* 165 */                   int v = j * 4;
/* 166 */                   cont.RVerts[(v + 0)] -= borderSize;
/* 167 */                   cont.RVerts[(v + 2)] -= borderSize;
/*     */                 }
/*     */               }
/*     */ 
/* 171 */               cont.Reg = reg;
/* 172 */               cont.Area = (short)(int)area;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 179 */     for (int i = 0; i < this.NConts; i++)
/*     */     {
/* 181 */       Contour cont = this.Conts[i];
/* 182 */       if (CalcAreaOfPolygon2D(cont.Verts, cont.NVerts) >= 0)
/*     */         continue;
/* 184 */       int mergeIdx = -1;
/* 185 */       for (int j = 0; j < this.NConts; j++)
/*     */       {
/* 187 */         if ((i == j) || 
/* 188 */           (this.Conts[j].NVerts <= 0) || (this.Conts[j].Reg != cont.Reg))
/*     */           continue;
/* 190 */         if (CalcAreaOfPolygon2D(this.Conts[j].Verts, this.Conts[j].NVerts) <= 0)
/*     */           continue;
/* 192 */         mergeIdx = j;
/* 193 */         break;
/*     */       }
/*     */ 
/* 197 */       if (mergeIdx == -1)
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 203 */       Contour mcont = this.Conts[mergeIdx];
/* 204 */       IntVector2 iaib = GetClosestIndices(mcont.Verts, mcont.NVerts, cont.Verts, cont.NVerts);
/* 205 */       if ((iaib.x == -1) || (iaib.y == -1))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 210 */       if (!MergeContours(mcont, cont, iaib.x, iaib.y).booleanValue())
/*     */         continue;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void WalkContour(int x, int y, int i, CompactHeightfield cfh, char[] flags, IntArray points)
/*     */   {
/* 222 */     char dir = '\000';
/* 223 */     while ((flags[i] & '\001' << dir) == 0) {
/* 224 */       dir = (char)(dir + '\001');
/*     */     }
/* 226 */     char startDir = dir;
/* 227 */     char tempDir = dir;
/* 228 */     int starti = i;
/*     */ 
/* 230 */     long area = cfh.Areas[i];
/* 231 */     int iter = 0;
/*     */     while (true) { iter++; if (iter >= 40000)
/*     */         break;
/* 234 */       if ((flags[i] & '\001' << dir) > 0)
/*     */       {
/* 236 */         Boolean isAreaBorder = Boolean.valueOf(false);
/* 237 */         int px = x;
/* 238 */         DetourNumericReturn cornerHeight = GetCornerHeight(x, y, i, tempDir, cfh);
/* 239 */         Boolean isBorderVertex = cornerHeight.boolValue;
/* 240 */         int py = cornerHeight.intValue;
/*     */ 
/* 242 */         int pz = y;
/*     */ 
/* 244 */         if (dir == 0)
/*     */         {
/* 246 */           pz++;
/*     */         }
/* 248 */         else if (dir == '\001')
/*     */         {
/* 250 */           px++;
/* 251 */           pz++;
/*     */         }
/* 253 */         else if (dir == '\002')
/*     */         {
/* 255 */           px++;
/*     */         }
/*     */ 
/* 258 */         int r = 0;
/* 259 */         CompactSpan s = cfh.Spans[i];
/* 260 */         if (s.GetCon(dir) != CompactHeightfield.NotConnected)
/*     */         {
/* 262 */           int ax = x + Helper.GetDirOffsetX(dir);
/* 263 */           int ay = y + Helper.GetDirOffsetY(dir);
/* 264 */           int ai = (int)cfh.Cells[(ax + ay * cfh.Width)].Index + s.GetCon(dir);
/* 265 */           r = cfh.Spans[ai].Reg;
/* 266 */           if (area != cfh.Areas[ai])
/*     */           {
/* 268 */             isAreaBorder = Boolean.valueOf(true);
/*     */           }
/*     */         }
/* 271 */         if (isBorderVertex.booleanValue())
/* 272 */           r |= BorderVertex;
/* 273 */         if (isAreaBorder.booleanValue()) {
/* 274 */           r |= AreaBorder;
/*     */         }
/* 276 */         points.Push(px);
/* 277 */         points.Push(py);
/* 278 */         points.Push(pz);
/* 279 */         points.Push(r);
/*     */         int tmp314_313 = i;
/*     */         char[] tmp314_311 = flags; tmp314_311[tmp314_313] = (char)(tmp314_311[tmp314_313] & (char)('\001' << dir ^ 0xFFFFFFFF));
/* 282 */         dir = (char)(dir + '\001' & 0x3);
/*     */       }
/*     */       else
/*     */       {
/* 286 */         int ni = -1;
/* 287 */         int nx = x + Helper.GetDirOffsetX(dir);
/* 288 */         int ny = y + Helper.GetDirOffsetY(dir);
/* 289 */         CompactSpan s = cfh.Spans[i];
/* 290 */         if (s.GetCon(dir) != CompactHeightfield.NotConnected)
/*     */         {
/* 292 */           CompactCell nc = cfh.Cells[(nx + ny * cfh.Width)];
/* 293 */           ni = (int)nc.Index + s.GetCon(dir);
/*     */         }
/* 295 */         if (ni == -1)
/*     */         {
/* 298 */           return;
/*     */         }
/* 300 */         x = nx;
/* 301 */         y = ny;
/* 302 */         i = ni;
/* 303 */         dir = (char)(dir + '\003' & 0x3);
/*     */       }
/* 305 */       if ((starti != i) || (startDir != dir))
/*     */         continue;
/*     */     }
/*     */   }
/*     */ 
/*     */   private DetourNumericReturn GetCornerHeight(int x, int y, int i, int dir, CompactHeightfield cfh)
/*     */   {
/* 314 */     DetourNumericReturn numericReturn = new DetourNumericReturn();
/* 315 */     numericReturn.boolValue = Boolean.valueOf(false);
/* 316 */     CompactSpan s = cfh.Spans[i];
/* 317 */     int ch = s.Y;
/* 318 */     int dirp = dir + 1 & 0x3;
/*     */ 
/* 320 */     long[] regs = { 0L, 0L, 0L, 0L };
/*     */ 
/* 322 */     regs[0] = (cfh.Spans[i].Reg | cfh.Areas[i] << 16);
/*     */ 
/* 324 */     if (s.GetCon(dir) != CompactHeightfield.NotConnected)
/*     */     {
/* 326 */       int ax = x + Helper.GetDirOffsetX(dir);
/* 327 */       int ay = y + Helper.GetDirOffsetY(dir);
/* 328 */       int ai = (int)cfh.Cells[(ax + ay * cfh.Width)].Index + s.GetCon(dir);
/* 329 */       CompactSpan aspan = cfh.Spans[ai];
/* 330 */       ch = Math.max(ch, aspan.Y);
/* 331 */       regs[1] = (cfh.Spans[ai].Reg | cfh.Areas[ai] << 16);
/* 332 */       if (aspan.GetCon(dirp) != CompactHeightfield.NotConnected)
/*     */       {
/* 334 */         int ax2 = ax + Helper.GetDirOffsetX(dirp);
/* 335 */         int ay2 = ay + Helper.GetDirOffsetY(dirp);
/* 336 */         int ai2 = (int)cfh.Cells[(ax2 + ay2 * cfh.Width)].Index + aspan.GetCon(dirp);
/* 337 */         CompactSpan as2 = cfh.Spans[ai2];
/* 338 */         ch = Math.max(ch, as2.Y);
/* 339 */         regs[2] = (cfh.Spans[ai2].Reg | cfh.Areas[ai2] << 16);
/*     */       }
/*     */     }
/* 342 */     if (s.GetCon(dirp) != CompactHeightfield.NotConnected)
/*     */     {
/* 344 */       int ax = x + Helper.GetDirOffsetX(dirp);
/* 345 */       int ay = y + Helper.GetDirOffsetY(dirp);
/* 346 */       int ai = (int)cfh.Cells[(ax + ay * cfh.Width)].Index + s.GetCon(dirp);
/* 347 */       CompactSpan aspan = cfh.Spans[ai];
/* 348 */       ch = Math.max(ch, aspan.Y);
/* 349 */       regs[3] = (cfh.Spans[ai].Reg | cfh.Areas[ai] << 16);
/* 350 */       if (aspan.GetCon(dir) != CompactHeightfield.NotConnected)
/*     */       {
/* 352 */         int ax2 = ax + Helper.GetDirOffsetX(dir);
/* 353 */         int ay2 = ay + Helper.GetDirOffsetY(dir);
/* 354 */         int ai2 = (int)cfh.Cells[(ax2 + ay2 * cfh.Width)].Index + aspan.GetCon(dir);
/* 355 */         CompactSpan as2 = cfh.Spans[ai2];
/* 356 */         ch = Math.max(ch, as2.Y);
/* 357 */         regs[2] = (cfh.Spans[ai2].Reg | cfh.Areas[ai2] << 16);
/*     */       }
/*     */     }
/*     */ 
/* 361 */     for (int j = 0; j < 4; j++)
/*     */     {
/* 363 */       int a = j;
/* 364 */       int b = j + 1 & 0x3;
/* 365 */       int c = j + 2 & 0x3;
/* 366 */       int d = j + 3 & 0x3;
/*     */ 
/* 368 */       Boolean twoSameExts = Boolean.valueOf(((regs[a] & regs[b] & CompactHeightfield.BorderReg) != 0L) && (regs[a] == regs[b]));
/* 369 */       Boolean twoInts = Boolean.valueOf(((regs[c] | regs[d]) & CompactHeightfield.BorderReg) == 0L);
/* 370 */       Boolean intsSameArea = Boolean.valueOf(regs[c] >> 16 == regs[d] >> 16);
/* 371 */       Boolean noZeros = Boolean.valueOf((regs[a] != 0L) && (regs[b] != 0L) && (regs[c] != 0L) && (regs[d] != 0L));
/* 372 */       if ((!twoSameExts.booleanValue()) || (!twoInts.booleanValue()) || (!intsSameArea.booleanValue()) || (!noZeros.booleanValue()))
/*     */         continue;
/* 374 */       numericReturn.boolValue = Boolean.valueOf(true);
/* 375 */       break;
/*     */     }
/*     */ 
/* 379 */     numericReturn.intValue = ch;
/* 380 */     return numericReturn;
/*     */   }
/*     */ 
/*     */   private void SimplifyContour(IntArray points, IntArray simplified, float maxError, int maxEdgeLen, int buildFlags)
/*     */   {
/* 385 */     Boolean hasConnections = Boolean.valueOf(false);
/* 386 */     for (int i = 0; i < points.Size; i += 4)
/*     */     {
/* 388 */       if ((points.get(i + 3) & ContourRegMask) == 0)
/*     */         continue;
/* 390 */       hasConnections = Boolean.valueOf(true);
/* 391 */       break;
/*     */     }
/*     */ 
/* 394 */     if (hasConnections.booleanValue())
/*     */     {
/* 396 */       int i = 0; for (int ni = points.Size / 4; i < ni; i++)
/*     */       {
/* 398 */         int ii = (i + 1) % ni;
/* 399 */         Boolean differentRegs = Boolean.valueOf((points.get(i * 4 + 3) & ContourRegMask) != (points.get(ii * 4 + 3) & ContourRegMask));
/* 400 */         Boolean areaBorders = Boolean.valueOf((points.get(i * 4 + 3) & AreaBorder) != (points.get(ii * 4 + 3) & AreaBorder));
/* 401 */         if ((!differentRegs.booleanValue()) && (!areaBorders.booleanValue()))
/*     */           continue;
/* 403 */         simplified.Push(points.get(i * 4 + 0));
/* 404 */         simplified.Push(points.get(i * 4 + 1));
/* 405 */         simplified.Push(points.get(i * 4 + 2));
/* 406 */         simplified.Push(i);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 411 */     if (simplified.Size == 0)
/*     */     {
/* 413 */       int llx = points.get(0);
/* 414 */       int lly = points.get(1);
/* 415 */       int llz = points.get(2);
/* 416 */       int lli = 0;
/* 417 */       int urx = points.get(0);
/* 418 */       int ury = points.get(1);
/* 419 */       int urz = points.get(2);
/* 420 */       int uri = 0;
/* 421 */       for (int i = 0; i < points.Size; i += 4)
/*     */       {
/* 423 */         int x = points.get(i + 0);
/* 424 */         int y = points.get(i + 1);
/* 425 */         int z = points.get(i + 2);
/* 426 */         if ((x < llx) || ((x == llx) && (z < llz)))
/*     */         {
/* 428 */           llx = x;
/* 429 */           lly = y;
/* 430 */           llz = z;
/* 431 */           lli = i / 4;
/*     */         }
/* 433 */         if ((x <= urx) && ((x != urx) || (z <= urz)))
/*     */           continue;
/* 435 */         urx = x;
/* 436 */         ury = y;
/* 437 */         urz = z;
/* 438 */         uri = i / 4;
/*     */       }
/*     */ 
/* 441 */       simplified.Push(llx);
/* 442 */       simplified.Push(lly);
/* 443 */       simplified.Push(llz);
/* 444 */       simplified.Push(lli);
/*     */ 
/* 446 */       simplified.Push(urx);
/* 447 */       simplified.Push(ury);
/* 448 */       simplified.Push(urz);
/* 449 */       simplified.Push(uri);
/*     */     }
/*     */ 
/* 452 */     int pn = points.Size / 4;
/*     */ 
/* 454 */     for (int i = 0; i < simplified.Size / 4; )
/*     */     {
/* 456 */       int ii = (i + 1) % (simplified.Size / 4);
/*     */ 
/* 458 */       int ax = simplified.get(i * 4 + 0);
/* 459 */       int az = simplified.get(i * 4 + 2);
/* 460 */       int ai = simplified.get(i * 4 + 3);
/*     */ 
/* 462 */       int bx = simplified.get(ii * 4 + 0);
/* 463 */       int bz = simplified.get(ii * 4 + 2);
/* 464 */       int bi = simplified.get(ii * 4 + 3);
/*     */ 
/* 466 */       float maxd = 0.0F;
/* 467 */       int maxi = -1;
/*     */       int endi;
/*     */       int cinc;
/*     */       int ci;
/*     */       int endi;
/* 470 */       if ((bx > ax) || ((bx == ax) && (bz > az)))
/*     */       {
/* 472 */         int cinc = 1;
/* 473 */         int ci = (ai + cinc) % pn;
/* 474 */         endi = bi;
/*     */       }
/*     */       else
/*     */       {
/* 478 */         cinc = pn - 1;
/* 479 */         ci = (bi + cinc) % pn;
/* 480 */         endi = ai;
/*     */       }
/*     */ 
/* 483 */       if (((points.get(ci * 4 + 3) & ContourRegMask) == 0) || ((points.get(ci * 4 + 3) & AreaBorder) != 0))
/*     */       {
/* 485 */         while (ci != endi)
/*     */         {
/* 487 */           float d = DistancePtSeg(points.get(ci * 4 + 0), points.get(ci * 4 + 2), ax, az, bx, bz);
/* 488 */           if (d > maxd)
/*     */           {
/* 490 */             maxd = d;
/* 491 */             maxi = ci;
/*     */           }
/* 493 */           ci = (ci + cinc) % pn;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 498 */       float errorSqrd = maxError * maxError;
/* 499 */       if ((maxi != -1) && (maxd > maxError * maxError))
/*     */       {
/* 501 */         simplified.Resize(simplified.Size + 4);
/* 502 */         int n = simplified.Size / 4;
/* 503 */         for (int j = n - 1; j > i; j--)
/*     */         {
/* 505 */           simplified.set(j * 4 + 0, simplified.get((j - 1) * 4 + 0));
/* 506 */           simplified.set(j * 4 + 1, simplified.get((j - 1) * 4 + 1));
/* 507 */           simplified.set(j * 4 + 2, simplified.get((j - 1) * 4 + 2));
/* 508 */           simplified.set(j * 4 + 3, simplified.get((j - 1) * 4 + 3));
/*     */         }
/*     */ 
/* 511 */         simplified.set((i + 1) * 4 + 0, points.get(maxi * 4 + 0));
/* 512 */         simplified.set((i + 1) * 4 + 1, points.get(maxi * 4 + 1));
/* 513 */         simplified.set((i + 1) * 4 + 2, points.get(maxi * 4 + 2));
/* 514 */         simplified.set((i + 1) * 4 + 3, maxi);
/*     */       }
/*     */       else
/*     */       {
/* 518 */         i++;
/*     */       }
/*     */     }
/*     */     int i;
/* 523 */     if ((maxEdgeLen > 0) && ((buildFlags & 0x3) != 0))
/*     */     {
/* 526 */       for (i = 0; i < simplified.Size / 4; )
/*     */       {
/* 528 */         int ii = (i + 1) % (simplified.Size / 4);
/*     */ 
/* 530 */         int ax = simplified.get(i * 4 + 0);
/* 531 */         int az = simplified.get(i * 4 + 2);
/* 532 */         int ai = simplified.get(i * 4 + 3);
/*     */ 
/* 534 */         int bx = simplified.get(ii * 4 + 0);
/* 535 */         int bz = simplified.get(ii * 4 + 2);
/* 536 */         int bi = simplified.get(ii * 4 + 3);
/*     */ 
/* 538 */         int maxi = -1;
/* 539 */         int ci = (ai + 1) % pn;
/*     */ 
/* 541 */         Boolean tess = Boolean.valueOf(false);
/*     */ 
/* 543 */         if (((buildFlags & 0x1) != 0) && ((points.get(ci * 4 + 3) & ContourRegMask) == 0))
/*     */         {
/* 545 */           tess = Boolean.valueOf(true);
/* 546 */         }if (((buildFlags & 0x2) != 0) && ((points.get(ci * 4 + 3) & AreaBorder) != 0))
/*     */         {
/* 548 */           tess = Boolean.valueOf(true);
/*     */         }
/* 550 */         if (tess.booleanValue())
/*     */         {
/* 552 */           int dx = bx - ax;
/* 553 */           int dz = bz - az;
/* 554 */           if (dx * dx + dz * dz > maxEdgeLen * maxEdgeLen)
/*     */           {
/* 556 */             int n = bi < ai ? bi + pn - ai : bi - ai;
/* 557 */             if (n > 1)
/*     */             {
/* 559 */               if ((bx > ax) || ((bx == ax) && (bz > az))) {
/* 560 */                 maxi = (int)(ai + n / 2.0F) % pn;
/*     */               }
/*     */               else {
/* 563 */                 maxi = (int)(ai + (n + 1) / 2.0F) % pn;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 569 */         if (maxi != -1)
/*     */         {
/* 571 */           simplified.Resize(simplified.Size + 4);
/* 572 */           int n = simplified.Size / 4;
/* 573 */           for (int j = n - 1; j > i; j--)
/*     */           {
/* 575 */             simplified.set(j * 4 + 0, simplified.get((j - 1) * 4 + 0));
/* 576 */             simplified.set(j * 4 + 1, simplified.get((j - 1) * 4 + 1));
/* 577 */             simplified.set(j * 4 + 2, simplified.get((j - 1) * 4 + 2));
/* 578 */             simplified.set(j * 4 + 3, simplified.get((j - 1) * 4 + 3));
/*     */           }
/* 580 */           simplified.set((i + 1) * 4 + 0, points.get(maxi * 4 + 0));
/* 581 */           simplified.set((i + 1) * 4 + 1, points.get(maxi * 4 + 1));
/* 582 */           simplified.set((i + 1) * 4 + 2, points.get(maxi * 4 + 2));
/* 583 */           simplified.set((i + 1) * 4 + 3, maxi);
/*     */         }
/*     */         else
/*     */         {
/* 587 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 592 */     for (int i = 0; i < simplified.Size / 4; i++)
/*     */     {
/* 594 */       int ai = (simplified.get(i * 4 + 3) + 1) % pn;
/* 595 */       int bi = simplified.get(i * 4 + 3);
/* 596 */       simplified.set(i * 4 + 3, points.get(ai * 4 + 3) & (ContourRegMask | AreaBorder) | points.get(bi * 4 + 3) & BorderVertex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private float DistancePtSeg(int x, int z, int px, int pz, int qx, int qz)
/*     */   {
/* 603 */     float pqx = qx - px;
/* 604 */     float pqz = qz - pz;
/* 605 */     float dx = x - px;
/* 606 */     float dz = z - pz;
/* 607 */     float d = pqx * pqx + pqz * pqz;
/* 608 */     float t = pqx * dx + pqz * dz;
/* 609 */     if (d > 0.0F)
/* 610 */       t /= d;
/* 611 */     if (t < 0.0F)
/* 612 */       t = 0.0F;
/* 613 */     else if (t > 1.0F) {
/* 614 */       t = 1.0F;
/*     */     }
/* 616 */     dx = px + t * pqx - x;
/* 617 */     dz = pz + t * pqz - z;
/*     */ 
/* 619 */     return dx * dx + dz * dz;
/*     */   }
/*     */ 
/*     */   private void RemoveDegenerateSegments(IntArray simplified)
/*     */   {
/* 624 */     for (int i = 0; i < simplified.Size / 4; i++)
/*     */     {
/* 626 */       int ni = i + 1;
/* 627 */       if (ni >= simplified.Size / 4) {
/* 628 */         ni = 0;
/*     */       }
/* 630 */       if ((simplified.get(i * 4 + 0) != simplified.get(ni * 4 + 0)) || (simplified.get(i * 4 + 2) != simplified.get(ni * 4 + 2)))
/*     */         continue;
/* 632 */       for (int j = i; j < simplified.Size / 4 - 1; j++)
/*     */       {
/* 634 */         simplified.set(j * 4 + 0, simplified.get((j + 1) * 4 + 0));
/* 635 */         simplified.set(j * 4 + 1, simplified.get((j + 1) * 4 + 1));
/* 636 */         simplified.set(j * 4 + 2, simplified.get((j + 1) * 4 + 2));
/* 637 */         simplified.set(j * 4 + 3, simplified.get((j + 1) * 4 + 3));
/*     */       }
/* 639 */       simplified.Resize(simplified.Size - 4);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int CalcAreaOfPolygon2D(int[] verts, int nVerts)
/*     */   {
/* 646 */     int area = 0;
/* 647 */     int i = 0; for (int j = nVerts - 1; i < nVerts; j = i++)
/*     */     {
/* 649 */       int vi = i * 4;
/* 650 */       int vj = j * 4;
/* 651 */       area += verts[(vi + 0)] * verts[(vj + 2)] - verts[(vj + 0)] * verts[(vi + 2)];
/*     */     }
/* 653 */     return (area + 1) / 2;
/*     */   }
/*     */ 
/*     */   private IntVector2 GetClosestIndices(int[] vertsa, int nvertsa, int[] vertsb, int nvertsb)
/*     */   {
/* 658 */     IntVector2 iaib = new IntVector2(-1, -1);
/* 659 */     int closestDist = 2147483647;
/* 660 */     for (int i = 0; i < nvertsa; i++)
/*     */     {
/* 662 */       int iNext = (i + 1) % nvertsa;
/* 663 */       int iPrev = (i + nvertsa - 1) % nvertsa;
/* 664 */       int va = i * 4;
/* 665 */       int van = iNext * 4;
/* 666 */       int vap = iPrev * 4;
/*     */ 
/* 668 */       for (int j = 0; j < nvertsb; j++)
/*     */       {
/* 670 */         int vb = j * 4;
/*     */ 
/* 672 */         if ((!ILeft(vertsa, vap, vertsa, va, vertsb, vb).booleanValue()) || (!ILeft(vertsa, va, vertsa, van, vertsb, vb).booleanValue()))
/*     */           continue;
/* 674 */         int dx = vertsb[(vb + 0)] - vertsa[(va + 0)];
/* 675 */         int dz = vertsb[(vb + 2)] - vertsa[(va + 2)];
/* 676 */         int d = dx * dx + dz * dz;
/* 677 */         if (d >= closestDist)
/*     */           continue;
/* 679 */         iaib.x = i;
/* 680 */         iaib.y = j;
/* 681 */         closestDist = d;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 686 */     return iaib;
/*     */   }
/*     */ 
/*     */   private Boolean ILeft(int[] a, int ia, int[] b, int ib, int[] c, int ic)
/*     */   {
/* 691 */     return Boolean.valueOf((b[(ib + 0)] - a[(ia + 0)]) * (c[(ic + 2)] - a[(ia + 2)]) - (c[(ic + 0)] - a[(ia + 0)]) * (b[(ib + 2)] - a[(ia + 2)]) <= 0);
/*     */   }
/*     */ 
/*     */   private Boolean MergeContours(Contour ca, Contour cb, int ia, int ib)
/*     */   {
/* 696 */     int maxVerts = ca.NVerts + cb.NVerts + 2;
/* 697 */     int[] verts = new int[maxVerts * 4];
/* 698 */     int nv = 0;
/*     */ 
/* 700 */     for (int i = 0; i < ca.NVerts; i++)
/*     */     {
/* 702 */       int dst = nv * 4;
/* 703 */       int src = (ia + i) % ca.NVerts * 4;
/* 704 */       verts[(dst + 0)] = ca.Verts[(src + 0)];
/* 705 */       verts[(dst + 1)] = ca.Verts[(src + 1)];
/* 706 */       verts[(dst + 2)] = ca.Verts[(src + 2)];
/* 707 */       verts[(dst + 3)] = ca.Verts[(src + 3)];
/* 708 */       nv++;
/*     */     }
/*     */ 
/* 711 */     for (int i = 0; i < cb.NVerts; i++)
/*     */     {
/* 713 */       int dst = nv * 4;
/* 714 */       int src = (ib + i) % cb.NVerts * 4;
/* 715 */       verts[(dst + 0)] = cb.Verts[(src + 0)];
/* 716 */       verts[(dst + 1)] = cb.Verts[(src + 1)];
/* 717 */       verts[(dst + 2)] = cb.Verts[(src + 2)];
/* 718 */       verts[(dst + 3)] = cb.Verts[(src + 3)];
/* 719 */       nv++;
/*     */     }
/*     */ 
/* 722 */     ca.Verts = verts;
/* 723 */     ca.NVerts = nv;
/* 724 */     cb.Verts = null;
/* 725 */     cb.NVerts = 0;
/*     */ 
/* 727 */     return Boolean.valueOf(true);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.ContourSet
 * JD-Core Version:    0.6.0
 */