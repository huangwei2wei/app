package atavism.server.pathing.recast;

public class Span
{
  public long SMin;
  public long SMax;
  public long Area;
  public Span Next;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.Span
 * JD-Core Version:    0.6.0
 */