/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ import atavism.server.pathing.detour.BVNode;
/*     */ import atavism.server.pathing.detour.DetourNumericReturn;
/*     */ import atavism.server.pathing.detour.Link;
/*     */ import atavism.server.pathing.detour.MeshHeader;
/*     */ import atavism.server.pathing.detour.NavMesh;
/*     */ import atavism.server.pathing.detour.NavMeshBuilder;
/*     */ import atavism.server.pathing.detour.OffMeshConnection;
/*     */ import atavism.server.pathing.detour.Poly;
/*     */ import atavism.server.pathing.detour.PolyDetail;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.XMLHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class NavMeshXmlLoader
/*     */ {
/*     */   protected String navMeshBuilderFileName;
/*     */   protected Document navMeshBuilderDoc;
/*     */ 
/*     */   public NavMeshXmlLoader(String fileName)
/*     */   {
/*  35 */     this.navMeshBuilderFileName = fileName;
/*     */   }
/*     */ 
/*     */   public NavMeshXmlLoader()
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean load(NavMesh navMesh)
/*     */   {
/*  44 */     if (!parse()) {
/*  45 */       return false;
/*     */     }
/*  47 */     Element builderNode = (Element)XMLHelper.getMatchingChild(this.navMeshBuilderDoc, "AtavismNavTile");
/*  48 */     return generate(navMesh, builderNode);
/*     */   }
/*     */ 
/*     */   public boolean parse()
/*     */   {
/*     */     try {
/*  54 */       DocumentBuilder builder = XMLHelper.makeDocBuilder();
/*  55 */       File xmlFile = new File(this.navMeshBuilderFileName);
/*     */ 
/*  57 */       this.navMeshBuilderDoc = builder.parse(xmlFile);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  61 */       Log.error("NavMesh WorldFile not found: " + this.navMeshBuilderFileName + ". Reverting to old pathing system");
/*  62 */       return false;
/*     */     } catch (SAXException e) {
/*  64 */       Log.exception("WorldFileLoader.parse(" + this.navMeshBuilderFileName + ")", e);
/*  65 */       return false;
/*     */     }
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean generate(NavMesh navMesh, Element builderNode)
/*     */   {
/*  72 */     NavMeshBuilder navMeshBuilder = new NavMeshBuilder();
/*  73 */     if (builderNode == null) {
/*  74 */       Log.error("No <NavMeshBuilder> node in file " + this.navMeshBuilderFileName);
/*  75 */       return false;
/*     */     }
/*     */ 
/*  78 */     NodeList nodeList = builderNode.getChildNodes();
/*  79 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  80 */       if (nodeList.item(i).getNodeType() == 1) {
/*  81 */         if (nodeList.item(i).getNodeName().equals("Header"))
/*     */         {
/*  83 */           navMeshBuilder.Header = processHeader(nodeList.item(i));
/*     */         }
/*  85 */         else if (nodeList.item(i).getNodeName().equals("NavVerts")) {
/*  86 */           List navVertsNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "float");
/*  87 */           float[] navVerts = new float[navVertsNodes.size()];
/*  88 */           for (int j = 0; j < navVertsNodes.size(); j++) {
/*  89 */             Element eElement = (Element)navVertsNodes.get(j);
/*  90 */             navVerts[j] = Float.parseFloat(eElement.getTextContent());
/*     */           }
/*  92 */           navMeshBuilder.NavVerts = navVerts;
/*     */         }
/*  94 */         else if (nodeList.item(i).getNodeName().equals("NavPolys")) {
/*  95 */           List navPolysNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "Poly");
/*  96 */           Poly[] navPolys = new Poly[navPolysNodes.size()];
/*  97 */           for (int j = 0; j < navPolysNodes.size(); j++) {
/*  98 */             navPolys[j] = processNavPoly((Node)navPolysNodes.get(j));
/*     */           }
/* 100 */           navMeshBuilder.NavPolys = navPolys;
/*     */         }
/* 102 */         else if (nodeList.item(i).getNodeName().equals("NavLinks")) {
/* 103 */           List navLinkNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "Link");
/* 104 */           Link[] navLinks = new Link[navLinkNodes.size()];
/* 105 */           for (int j = 0; j < navLinkNodes.size(); j++) {
/* 106 */             navLinks[j] = processLink((Node)navLinkNodes.get(j));
/*     */           }
/* 108 */           navMeshBuilder.NavLinks = navLinks;
/*     */         }
/* 110 */         else if (nodeList.item(i).getNodeName().equals("NavDMeshes")) {
/* 111 */           List navPolyDetailNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "PolyDetail");
/* 112 */           PolyDetail[] navPolyDetails = new PolyDetail[navPolyDetailNodes.size()];
/* 113 */           for (int j = 0; j < navPolyDetailNodes.size(); j++) {
/* 114 */             navPolyDetails[j] = processPolyDetail((Node)navPolyDetailNodes.get(j));
/*     */           }
/* 116 */           navMeshBuilder.NavDMeshes = navPolyDetails;
/*     */         }
/* 118 */         else if (nodeList.item(i).getNodeName().equals("NavDVerts")) {
/* 119 */           List navDVertsNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "float");
/* 120 */           float[] navDVerts = new float[navDVertsNodes.size()];
/* 121 */           for (int j = 0; j < navDVertsNodes.size(); j++) {
/* 122 */             Element eElement = (Element)navDVertsNodes.get(j);
/* 123 */             navDVerts[j] = Float.parseFloat(eElement.getTextContent());
/*     */           }
/* 125 */           navMeshBuilder.NavDVerts = navDVerts;
/*     */         }
/* 127 */         else if (nodeList.item(i).getNodeName().equals("NavDTris")) {
/* 128 */           List navDTrisNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "short");
/* 129 */           short[] navDTris = new short[navDTrisNodes.size()];
/* 130 */           for (int j = 0; j < navDTrisNodes.size(); j++) {
/* 131 */             Element eElement = (Element)navDTrisNodes.get(j);
/* 132 */             navDTris[j] = Short.parseShort(eElement.getTextContent());
/*     */           }
/* 134 */           navMeshBuilder.NavDTris = navDTris;
/*     */         }
/* 136 */         else if (nodeList.item(i).getNodeName().equals("NavBvTree")) {
/* 137 */           List navBVNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "BVNode");
/* 138 */           BVNode[] navBvTree = new BVNode[navBVNodes.size()];
/* 139 */           for (int j = 0; j < navBVNodes.size(); j++) {
/* 140 */             navBvTree[j] = processBVNode((Node)navBVNodes.get(j));
/*     */           }
/* 142 */           navMeshBuilder.NavBvTree = navBvTree;
/*     */         }
/* 144 */         else if (nodeList.item(i).getNodeName().equals("NavBvTree")) {
/* 145 */           List navOffMeshConnectionNodes = XMLHelper.getMatchingChildren(nodeList.item(i), "OffMeshConnection");
/* 146 */           OffMeshConnection[] offMeshCons = new OffMeshConnection[navOffMeshConnectionNodes.size()];
/* 147 */           for (int j = 0; j < navOffMeshConnectionNodes.size(); j++) {
/* 148 */             offMeshCons[j] = processOffMeshConnection((Node)navOffMeshConnectionNodes.get(j));
/*     */           }
/* 150 */           navMeshBuilder.OffMeshCons = offMeshCons;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 271 */     long tempRef = 0L;
/* 272 */     long temp = 0L;
/*     */ 
/* 274 */     if (navMeshBuilder.Header != null) {
/* 275 */       temp = navMesh.AddTile(navMeshBuilder, NavMesh.TileFreeData, tempRef).longValue;
/* 276 */       Log.debug("NAVMESH: added tile");
/*     */     }
/*     */ 
/* 279 */     return true;
/*     */   }
/*     */ 
/*     */   protected MeshHeader processHeader(Node node)
/*     */   {
/* 284 */     MeshHeader header = new MeshHeader();
/* 285 */     Element eElement = (Element)XMLHelper.getMatchingChild(node, "Magic");
/* 286 */     Log.debug("NAVMESH: magic=" + eElement.getTextContent());
/* 287 */     header.Magic = Integer.parseInt(eElement.getTextContent());
/* 288 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Version");
/* 289 */     header.Version = Integer.parseInt(eElement.getTextContent());
/* 290 */     eElement = (Element)XMLHelper.getMatchingChild(node, "X");
/* 291 */     header.X = Integer.parseInt(eElement.getTextContent());
/* 292 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Y");
/* 293 */     header.Y = Integer.parseInt(eElement.getTextContent());
/* 294 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Layer");
/* 295 */     header.Layer = Integer.parseInt(eElement.getTextContent());
/* 296 */     eElement = (Element)XMLHelper.getMatchingChild(node, "UserId");
/* 297 */     header.UserId = Long.parseLong(eElement.getTextContent());
/* 298 */     eElement = (Element)XMLHelper.getMatchingChild(node, "PolyCount");
/* 299 */     header.PolyCount = Integer.parseInt(eElement.getTextContent());
/* 300 */     eElement = (Element)XMLHelper.getMatchingChild(node, "VertCount");
/* 301 */     header.VertCount = Integer.parseInt(eElement.getTextContent());
/* 302 */     eElement = (Element)XMLHelper.getMatchingChild(node, "MaxLinkCount");
/* 303 */     header.MaxLinkCount = Integer.parseInt(eElement.getTextContent());
/* 304 */     eElement = (Element)XMLHelper.getMatchingChild(node, "DetailMeshCount");
/* 305 */     header.DetailMeshCount = Integer.parseInt(eElement.getTextContent());
/* 306 */     eElement = (Element)XMLHelper.getMatchingChild(node, "DetailVertCount");
/* 307 */     header.DetailVertCount = Integer.parseInt(eElement.getTextContent());
/* 308 */     eElement = (Element)XMLHelper.getMatchingChild(node, "DetailTriCount");
/* 309 */     header.DetailTriCount = Integer.parseInt(eElement.getTextContent());
/* 310 */     eElement = (Element)XMLHelper.getMatchingChild(node, "BVNodeCount");
/* 311 */     header.BVNodeCount = Integer.parseInt(eElement.getTextContent());
/* 312 */     eElement = (Element)XMLHelper.getMatchingChild(node, "OffMeshConCount");
/* 313 */     header.OffMeshConCount = Integer.parseInt(eElement.getTextContent());
/* 314 */     eElement = (Element)XMLHelper.getMatchingChild(node, "OffMeshBase");
/* 315 */     header.OffMeshBase = Integer.parseInt(eElement.getTextContent());
/* 316 */     eElement = (Element)XMLHelper.getMatchingChild(node, "WalkableHeight");
/* 317 */     header.WalkableHeight = Float.parseFloat(eElement.getTextContent());
/* 318 */     eElement = (Element)XMLHelper.getMatchingChild(node, "WalkableRadius");
/* 319 */     header.WalkableRadius = Float.parseFloat(eElement.getTextContent());
/* 320 */     eElement = (Element)XMLHelper.getMatchingChild(node, "WalkableClimb");
/* 321 */     header.WalkableClimb = Float.parseFloat(eElement.getTextContent());
/*     */ 
/* 324 */     Node bminNode = XMLHelper.getMatchingChild(node, "BMin");
/* 325 */     if (bminNode == null) {
/* 326 */       Log.debug("No <BMin> node in BVNode");
/*     */     } else {
/* 328 */       List bminNodes = XMLHelper.getMatchingChildren(bminNode, "float");
/* 329 */       float[] bmin = new float[bminNodes.size()];
/* 330 */       for (int i = 0; i < bminNodes.size(); i++) {
/* 331 */         eElement = (Element)bminNodes.get(i);
/* 332 */         bmin[i] = Float.parseFloat(eElement.getTextContent());
/*     */       }
/* 334 */       header.BMin = bmin;
/*     */     }
/*     */ 
/* 338 */     Node bmaxNode = XMLHelper.getMatchingChild(node, "BMax");
/* 339 */     if (bmaxNode == null) {
/* 340 */       Log.debug("No <BMax> node in BVNode");
/*     */     } else {
/* 342 */       List bmaxNodes = XMLHelper.getMatchingChildren(bmaxNode, "float");
/* 343 */       float[] bmax = new float[bmaxNodes.size()];
/* 344 */       for (int i = 0; i < bmaxNodes.size(); i++) {
/* 345 */         eElement = (Element)bmaxNodes.get(i);
/* 346 */         bmax[i] = Float.parseFloat(eElement.getTextContent());
/*     */       }
/* 348 */       header.BMax = bmax;
/*     */     }
/*     */ 
/* 351 */     eElement = (Element)XMLHelper.getMatchingChild(node, "TileRef");
/* 352 */     header.TileRef = Long.parseLong(eElement.getTextContent());
/* 353 */     eElement = (Element)XMLHelper.getMatchingChild(node, "BVQuantFactor");
/* 354 */     header.BVQuantFactor = Float.parseFloat(eElement.getTextContent());
/*     */ 
/* 356 */     return header;
/*     */   }
/*     */ 
/*     */   protected Poly processNavPoly(Node node)
/*     */   {
/* 361 */     Poly poly = new Poly();
/* 362 */     Element eElement = (Element)XMLHelper.getMatchingChild(node, "_areaAndType");
/* 363 */     poly._areaAndType = Short.parseShort(eElement.getTextContent());
/* 364 */     eElement = (Element)XMLHelper.getMatchingChild(node, "FirstLink");
/* 365 */     poly.FirstLink = Long.parseLong(eElement.getTextContent());
/*     */ 
/* 368 */     Node vertsNode = XMLHelper.getMatchingChild(node, "Verts");
/* 369 */     if (vertsNode == null) {
/* 370 */       Log.debug("No <NavVerts> node in Poly");
/*     */     } else {
/* 372 */       List vertsNodes = XMLHelper.getMatchingChildren(vertsNode, "int");
/* 373 */       int[] verts = new int[vertsNodes.size()];
/* 374 */       for (int i = 0; i < vertsNodes.size(); i++) {
/* 375 */         eElement = (Element)vertsNodes.get(i);
/* 376 */         verts[i] = Integer.parseInt(eElement.getTextContent());
/*     */       }
/* 378 */       poly.Verts = verts;
/*     */     }
/*     */ 
/* 382 */     Node neisNode = XMLHelper.getMatchingChild(node, "Neis");
/* 383 */     if (neisNode == null) {
/* 384 */       Log.debug("No <NavVerts> node in Poly");
/*     */     } else {
/* 386 */       List neisNodes = XMLHelper.getMatchingChildren(neisNode, "int");
/* 387 */       int[] neis = new int[neisNodes.size()];
/* 388 */       for (int i = 0; i < neisNodes.size(); i++) {
/* 389 */         eElement = (Element)neisNodes.get(i);
/* 390 */         neis[i] = Integer.parseInt(eElement.getTextContent());
/*     */       }
/* 392 */       poly.Neis = neis;
/*     */     }
/*     */ 
/* 395 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Flags");
/* 396 */     poly.Flags = Integer.parseInt(eElement.getTextContent());
/* 397 */     eElement = (Element)XMLHelper.getMatchingChild(node, "VertCount");
/* 398 */     poly.VertCount = Short.parseShort(eElement.getTextContent());
/* 399 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Area");
/* 400 */     poly.setArea(Short.parseShort(eElement.getTextContent()));
/* 401 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Type");
/* 402 */     poly.setType(Short.parseShort(eElement.getTextContent()));
/* 403 */     return poly;
/*     */   }
/*     */ 
/*     */   protected Link processLink(Node node)
/*     */   {
/* 408 */     Link link = new Link();
/* 409 */     Element eElement = (Element)XMLHelper.getMatchingChild(node, "Ref");
/* 410 */     link.Ref = Long.parseLong(eElement.getTextContent());
/* 411 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Next");
/* 412 */     link.Next = Long.parseLong(eElement.getTextContent());
/* 413 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Edge");
/* 414 */     link.Edge = Short.parseShort(eElement.getTextContent());
/* 415 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Side");
/* 416 */     link.Side = Short.parseShort(eElement.getTextContent());
/* 417 */     eElement = (Element)XMLHelper.getMatchingChild(node, "BMin");
/* 418 */     link.BMin = Short.parseShort(eElement.getTextContent());
/* 419 */     eElement = (Element)XMLHelper.getMatchingChild(node, "BMax");
/* 420 */     link.BMax = Short.parseShort(eElement.getTextContent());
/* 421 */     return link;
/*     */   }
/*     */ 
/*     */   protected PolyDetail processPolyDetail(Node node)
/*     */   {
/* 426 */     PolyDetail detail = new PolyDetail();
/* 427 */     Element eElement = (Element)XMLHelper.getMatchingChild(node, "VertBase");
/* 428 */     detail.VertBase = Long.parseLong(eElement.getTextContent());
/* 429 */     eElement = (Element)XMLHelper.getMatchingChild(node, "TriBase");
/* 430 */     detail.TriBase = Long.parseLong(eElement.getTextContent());
/* 431 */     eElement = (Element)XMLHelper.getMatchingChild(node, "VertCount");
/* 432 */     detail.VertCount = Short.parseShort(eElement.getTextContent());
/* 433 */     eElement = (Element)XMLHelper.getMatchingChild(node, "TriCount");
/* 434 */     detail.TriCount = Short.parseShort(eElement.getTextContent());
/* 435 */     return detail;
/*     */   }
/*     */ 
/*     */   protected BVNode processBVNode(Node node)
/*     */   {
/* 440 */     BVNode bvNode = new BVNode();
/* 441 */     Element eElement = (Element)XMLHelper.getMatchingChild(node, "I");
/* 442 */     bvNode.I = Integer.parseInt(eElement.getTextContent());
/*     */ 
/* 445 */     Node bminNode = XMLHelper.getMatchingChild(node, "BMin");
/* 446 */     if (bminNode == null) {
/* 447 */       Log.debug("No <BMin> node in BVNode");
/*     */     } else {
/* 449 */       List bminNodes = XMLHelper.getMatchingChildren(bminNode, "int");
/* 450 */       int[] bmin = new int[bminNodes.size()];
/* 451 */       for (int i = 0; i < bminNodes.size(); i++) {
/* 452 */         eElement = (Element)bminNodes.get(i);
/* 453 */         bmin[i] = Integer.parseInt(eElement.getTextContent());
/*     */       }
/* 455 */       bvNode.BMin = bmin;
/*     */     }
/*     */ 
/* 459 */     Node bmaxNode = XMLHelper.getMatchingChild(node, "BMax");
/* 460 */     if (bmaxNode == null) {
/* 461 */       Log.debug("No <BMax> node in BVNode");
/*     */     } else {
/* 463 */       List bmaxNodes = XMLHelper.getMatchingChildren(bmaxNode, "int");
/* 464 */       int[] bmax = new int[bmaxNodes.size()];
/* 465 */       for (int i = 0; i < bmaxNodes.size(); i++) {
/* 466 */         eElement = (Element)bmaxNodes.get(i);
/* 467 */         bmax[i] = Integer.parseInt(eElement.getTextContent());
/*     */       }
/* 469 */       bvNode.BMax = bmax;
/*     */     }
/*     */ 
/* 472 */     return bvNode;
/*     */   }
/*     */ 
/*     */   protected OffMeshConnection processOffMeshConnection(Node node)
/*     */   {
/* 477 */     OffMeshConnection omc = new OffMeshConnection();
/*     */ 
/* 480 */     Node vertsNode = XMLHelper.getMatchingChild(node, "Pos");
/* 481 */     if (vertsNode == null) {
/* 482 */       Log.debug("No <Pos> node in OffMeshConnection ");
/*     */     } else {
/* 484 */       List posNodes = XMLHelper.getMatchingChildren(vertsNode, "float");
/* 485 */       float[] pos = new float[posNodes.size()];
/* 486 */       for (int i = 0; i < posNodes.size(); i++) {
/* 487 */         Element eElement = (Element)posNodes.get(i);
/* 488 */         pos[i] = Float.parseFloat(eElement.getTextContent());
/*     */       }
/* 490 */       omc.Pos = pos;
/*     */     }
/*     */ 
/* 493 */     Element eElement = (Element)XMLHelper.getMatchingChild(node, "Rad");
/* 494 */     omc.Rad = Float.parseFloat(eElement.getTextContent());
/* 495 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Poly");
/* 496 */     omc.Poly = Integer.parseInt(eElement.getTextContent());
/* 497 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Flags");
/* 498 */     omc.Flags = Short.parseShort(eElement.getTextContent());
/* 499 */     eElement = (Element)XMLHelper.getMatchingChild(node, "Side");
/* 500 */     omc.Side = Short.parseShort(eElement.getTextContent());
/* 501 */     eElement = (Element)XMLHelper.getMatchingChild(node, "UserId");
/* 502 */     omc.UserId = Long.parseLong(eElement.getTextContent());
/*     */ 
/* 504 */     return omc;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.NavMeshXmlLoader
 * JD-Core Version:    0.6.0
 */