/*    */ package atavism.server.pathing.recast;
/*    */ 
/*    */ public class ChunkyTriMeshNode
/*    */ {
/*    */   public float[] bmin;
/*    */   public float[] bmax;
/*    */   public int i;
/*    */   public int n;
/*    */ 
/*    */   public ChunkyTriMeshNode()
/*    */   {
/* 12 */     this.bmin = new float[2];
/* 13 */     this.bmax = new float[2];
/* 14 */     this.i = 0;
/* 15 */     this.n = 0;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.ChunkyTriMeshNode
 * JD-Core Version:    0.6.0
 */