/*      */ package atavism.server.pathing.recast;
/*      */ 
/*      */ public class CompactHeightfield
/*      */ {
/*      */   public int Width;
/*      */   public int Height;
/*      */   public int SpanCount;
/*      */   public int WalkableHeight;
/*      */   public int WalkableClimb;
/*      */   public int BorderSize;
/*      */   public int MaxDistance;
/*      */   public int MaxRegions;
/*      */   public float[] BMin;
/*      */   public float[] BMax;
/*      */   public float Cs;
/*      */   public float Ch;
/*      */   public CompactCell[] Cells;
/*      */   public CompactSpan[] Spans;
/*      */   public int[] Dist;
/*      */   public long[] Areas;
/*   24 */   public static int NotConnected = 63;
/*   25 */   public static int BorderReg = 32768;
/*      */ 
/*      */   public CompactHeightfield(int walkableHeight, int walkableClimb, HeightField hf)
/*      */   {
/*   29 */     int w = hf.Width;
/*   30 */     int h = hf.Height;
/*   31 */     int spanCount = hf.GetHeightFieldSpanCount();
/*      */ 
/*   33 */     this.Width = w;
/*   34 */     this.Height = h;
/*   35 */     this.SpanCount = spanCount;
/*   36 */     this.WalkableHeight = walkableHeight;
/*   37 */     this.WalkableClimb = walkableClimb;
/*   38 */     this.MaxRegions = 0;
/*   39 */     this.BMin = new float[3];
/*   40 */     this.BMax = new float[3];
/*   41 */     System.arraycopy(hf.Bmin, 0, this.BMin, 0, 3);
/*   42 */     System.arraycopy(hf.Bmax, 0, this.BMax, 0, 3);
/*   43 */     this.BMax[1] += walkableHeight * hf.Ch;
/*   44 */     this.Cs = hf.Cs;
/*   45 */     this.Ch = hf.Ch;
/*   46 */     this.Cells = new CompactCell[w * h];
/*   47 */     this.Spans = new CompactSpan[spanCount];
/*   48 */     this.Areas = new long[spanCount];
/*   49 */     int MaxHeight = 65535;
/*      */ 
/*   51 */     int idx = 0;
/*   52 */     for (int y = 0; y < h; y++)
/*      */     {
/*   54 */       for (int x = 0; x < w; x++)
/*      */       {
/*   56 */         Span s = hf.Spans[(x + y * w)];
/*   57 */         if (s == null)
/*      */           continue;
/*   59 */         this.Cells[(x + y * w)].Index = idx;
/*   60 */         this.Cells[(x + y * w)].Count = 0L;
/*      */ 
/*   62 */         while (s != null)
/*      */         {
/*   64 */           if (s.Area != HeightField.NullArea)
/*      */           {
/*   66 */             int bot = (int)s.SMax;
/*   67 */             int top = s.Next != null ? (int)s.Next.SMin : MaxHeight;
/*   68 */             this.Spans[idx].Y = Math.max(0, Math.min(bot, MaxHeight));
/*   69 */             this.Spans[idx].H = Math.max(0, Math.min(top - bot, 255));
/*   70 */             this.Areas[idx] = s.Area;
/*   71 */             idx++;
/*   72 */             this.Cells[(x + y * w)].Count += 1L;
/*      */           }
/*   74 */           s = s.Next;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*   79 */     int MaxLayers = NotConnected - 1;
/*   80 */     int tooHighNeighbor = 0;
/*   81 */     for (int y = 0; y < h; y++)
/*      */     {
/*   83 */       for (int x = 0; x < w; x++)
/*      */       {
/*   85 */         CompactCell c = this.Cells[(x + y * w)];
/*   86 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*   88 */           for (int dir = 0; dir < 4; dir++)
/*      */           {
/*   90 */             this.Spans[i].SetCon(dir, NotConnected);
/*   91 */             int nx = x + Helper.GetDirOffsetX(dir);
/*   92 */             int ny = y + Helper.GetDirOffsetY(dir);
/*      */ 
/*   94 */             if ((nx < 0) || (ny < 0) || (nx >= w) || (ny >= h)) {
/*      */               continue;
/*      */             }
/*   97 */             CompactCell nc = this.Cells[(nx + ny * w)];
/*   98 */             int k = (int)nc.Index; for (int nk = (int)(nc.Index + nc.Count); k < nk; k++)
/*      */             {
/*  100 */               CompactSpan ns = this.Spans[k];
/*  101 */               int bot = Math.max(this.Spans[i].Y, ns.Y);
/*  102 */               int top = Math.min(this.Spans[i].Y + this.Spans[i].H, ns.Y + ns.H);
/*      */ 
/*  104 */               if ((top - bot < walkableHeight) || (Math.abs(ns.Y - this.Spans[i].Y) > walkableClimb))
/*      */                 continue;
/*  106 */               int lidx = k - (int)nc.Index;
/*  107 */               if ((lidx < 0) || (lidx > MaxLayers))
/*      */               {
/*  109 */                 tooHighNeighbor = Math.max(tooHighNeighbor, lidx);
/*      */               }
/*      */               else {
/*  112 */                 this.Spans[i].SetCon(dir, lidx);
/*  113 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Boolean ErodeWalkableArea(int radius)
/*      */   {
/*  124 */     int w = this.Width;
/*  125 */     int h = this.Height;
/*      */ 
/*  127 */     short[] dist = new short[this.SpanCount];
/*  128 */     for (int i = 0; i < this.SpanCount; i++)
/*      */     {
/*  130 */       dist[i] = 255;
/*      */     }
/*      */ 
/*  133 */     for (int y = 0; y < h; y++)
/*      */     {
/*  135 */       for (int x = 0; x < w; x++)
/*      */       {
/*  137 */         CompactCell c = this.Cells[(x + y * w)];
/*      */ 
/*  139 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  141 */           if (this.Areas[i] == HeightField.NullArea)
/*      */           {
/*  143 */             dist[i] = 0;
/*      */           }
/*      */           else
/*      */           {
/*  147 */             CompactSpan s = this.Spans[i];
/*  148 */             int nc = 0;
/*  149 */             for (int dir = 0; dir < 4; dir++)
/*      */             {
/*  151 */               if (s.GetCon(dir) == NotConnected)
/*      */                 continue;
/*  153 */               int nx = x + Helper.GetDirOffsetX(dir);
/*  154 */               int ny = y + Helper.GetDirOffsetY(dir);
/*  155 */               int nidx = (int)this.Cells[(nx + ny * w)].Index + s.GetCon(dir);
/*  156 */               if (this.Areas[nidx] == HeightField.NullArea)
/*      */                 continue;
/*  158 */               nc++;
/*      */             }
/*      */ 
/*  162 */             if (nc != 4) {
/*  163 */               dist[i] = 0;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  169 */     for (int y = 0; y < h; y++)
/*      */     {
/*  171 */       for (int x = 0; x < w; x++)
/*      */       {
/*  173 */         CompactCell c = this.Cells[(x + y * w)];
/*  174 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  176 */           CompactSpan s = this.Spans[i];
/*      */ 
/*  178 */           if (s.GetCon(0) != NotConnected)
/*      */           {
/*  180 */             int ax = x + Helper.GetDirOffsetX(0);
/*  181 */             int ay = y + Helper.GetDirOffsetY(0);
/*  182 */             int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(0);
/*  183 */             CompactSpan aspan = this.Spans[ai];
/*  184 */             short nd = (short)Math.min(dist[ai] + 2, 255);
/*  185 */             if (nd < dist[i]) {
/*  186 */               dist[i] = nd;
/*      */             }
/*  188 */             if (aspan.GetCon(3) != NotConnected)
/*      */             {
/*  190 */               int aax = ax + Helper.GetDirOffsetX(3);
/*  191 */               int aay = ay + Helper.GetDirOffsetY(3);
/*  192 */               int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(3);
/*  193 */               nd = (short)Math.min(dist[aai] + 3, 255);
/*  194 */               if (nd < dist[i])
/*  195 */                 dist[i] = nd;
/*      */             }
/*      */           }
/*  198 */           if (s.GetCon(3) == NotConnected)
/*      */             continue;
/*  200 */           int ax = x + Helper.GetDirOffsetX(3);
/*  201 */           int ay = y + Helper.GetDirOffsetY(3);
/*  202 */           int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(3);
/*  203 */           CompactSpan aspan = this.Spans[ai];
/*  204 */           short nd = (short)Math.min(dist[ai] + 2, 255);
/*  205 */           if (nd < dist[i]) {
/*  206 */             dist[i] = nd;
/*      */           }
/*  208 */           if (aspan.GetCon(2) == NotConnected)
/*      */             continue;
/*  210 */           int aax = ax + Helper.GetDirOffsetX(2);
/*  211 */           int aay = ay + Helper.GetDirOffsetY(2);
/*  212 */           int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(2);
/*  213 */           nd = (short)Math.min(dist[aai] + 3, 255);
/*  214 */           if (nd < dist[i]) {
/*  215 */             dist[i] = nd;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  222 */     for (int y = h - 1; y >= 0; y--)
/*      */     {
/*  224 */       for (int x = w - 1; x >= 0; x--)
/*      */       {
/*  226 */         CompactCell c = this.Cells[(x + y * w)];
/*  227 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  229 */           CompactSpan s = this.Spans[i];
/*  230 */           if (s.GetCon(2) != NotConnected)
/*      */           {
/*  232 */             int ax = x + Helper.GetDirOffsetX(2);
/*  233 */             int ay = y + Helper.GetDirOffsetY(2);
/*  234 */             int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(2);
/*  235 */             CompactSpan aspan = this.Spans[ai];
/*  236 */             short nd = (short)Math.min(dist[ai] + 2, 255);
/*  237 */             if (nd < dist[i]) {
/*  238 */               dist[i] = nd;
/*      */             }
/*  240 */             if (aspan.GetCon(1) != NotConnected)
/*      */             {
/*  242 */               int aax = ax + Helper.GetDirOffsetX(1);
/*  243 */               int aay = ay + Helper.GetDirOffsetY(1);
/*  244 */               int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(1);
/*  245 */               nd = (short)Math.min(dist[aai] + 3, 255);
/*  246 */               if (nd < dist[i])
/*  247 */                 dist[i] = nd;
/*      */             }
/*      */           }
/*  250 */           if (s.GetCon(1) == NotConnected)
/*      */             continue;
/*  252 */           int ax = x + Helper.GetDirOffsetX(1);
/*  253 */           int ay = y + Helper.GetDirOffsetY(1);
/*  254 */           int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(1);
/*  255 */           CompactSpan aspan = this.Spans[ai];
/*  256 */           short nd = (short)Math.min(dist[ai] + 2, 255);
/*  257 */           if (nd < dist[i]) {
/*  258 */             dist[i] = nd;
/*      */           }
/*  260 */           if (aspan.GetCon(0) == NotConnected)
/*      */             continue;
/*  262 */           int aax = ax + Helper.GetDirOffsetX(0);
/*  263 */           int aay = ay + Helper.GetDirOffsetY(0);
/*  264 */           int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(0);
/*  265 */           nd = (short)Math.min(dist[aai] + 3, 255);
/*  266 */           if (nd < dist[i]) {
/*  267 */             dist[i] = nd;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  274 */     short thr = (short)(radius * 2);
/*  275 */     for (int i = 0; i < this.SpanCount; i++)
/*      */     {
/*  277 */       if (dist[i] >= thr)
/*      */         continue;
/*  279 */       this.Areas[i] = HeightField.NullArea;
/*      */     }
/*      */ 
/*  283 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   public Boolean BuildDistanceField()
/*      */   {
/*  288 */     int[] src = new int[this.SpanCount];
/*  289 */     int[] dst = new int[this.SpanCount];
/*      */ 
/*  291 */     int maxDist = CalculateDistanceField(src, 0);
/*  292 */     this.MaxDistance = maxDist;
/*      */ 
/*  294 */     this.Dist = BoxBlur(1, src, dst);
/*      */ 
/*  296 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private int[] BoxBlur(int thr, int[] src, int[] dst)
/*      */   {
/*  301 */     int w = this.Width;
/*  302 */     int h = this.Height;
/*      */ 
/*  304 */     thr *= 2;
/*  305 */     for (int y = 0; y < h; y++)
/*      */     {
/*  307 */       for (int x = 0; x < w; x++)
/*      */       {
/*  309 */         CompactCell c = this.Cells[(x + y * w)];
/*  310 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  312 */           CompactSpan s = this.Spans[i];
/*  313 */           int cd = src[i];
/*  314 */           if (cd <= thr)
/*      */           {
/*  316 */             dst[i] = cd;
/*      */           }
/*      */           else
/*      */           {
/*  320 */             int d = cd;
/*  321 */             for (int dir = 0; dir < 4; dir++)
/*      */             {
/*  323 */               if (s.GetCon(dir) != NotConnected)
/*      */               {
/*  325 */                 int ax = x + Helper.GetDirOffsetX(dir);
/*  326 */                 int ay = y + Helper.GetDirOffsetY(dir);
/*  327 */                 int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(dir);
/*  328 */                 d += src[ai];
/*      */ 
/*  330 */                 CompactSpan aspan = this.Spans[ai];
/*  331 */                 int dir2 = dir + 1 & 0x3;
/*  332 */                 if (aspan.GetCon(dir2) != NotConnected)
/*      */                 {
/*  334 */                   int ax2 = ax + Helper.GetDirOffsetX(dir2);
/*  335 */                   int ay2 = ay + Helper.GetDirOffsetY(dir2);
/*  336 */                   int ai2 = (int)this.Cells[(ax2 + ay2 * w)].Index + aspan.GetCon(dir2);
/*  337 */                   d += src[ai2];
/*      */                 }
/*      */                 else
/*      */                 {
/*  341 */                   d += cd;
/*      */                 }
/*      */               }
/*      */               else
/*      */               {
/*  346 */                 d += cd * 2;
/*      */               }
/*      */             }
/*  349 */             dst[i] = ((d + 5) / 9);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  353 */     return dst;
/*      */   }
/*      */ 
/*      */   private int CalculateDistanceField(int[] src, int maxDist)
/*      */   {
/*  358 */     int w = this.Width;
/*  359 */     int h = this.Height;
/*  360 */     for (int i = 0; i < this.SpanCount; i++) {
/*  361 */       src[i] = 65535;
/*      */     }
/*  363 */     for (int y = 0; y < h; y++)
/*      */     {
/*  365 */       for (int x = 0; x < w; x++)
/*      */       {
/*  367 */         CompactCell c = this.Cells[(x + y * w)];
/*  368 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  370 */           CompactSpan s = this.Spans[i];
/*  371 */           long area = this.Areas[i];
/*      */ 
/*  373 */           int nc = 0;
/*  374 */           for (int dir = 0; dir < 4; dir++)
/*      */           {
/*  376 */             if (s.GetCon(dir) == NotConnected)
/*      */               continue;
/*  378 */             int ax = x + Helper.GetDirOffsetX(dir);
/*  379 */             int ay = y + Helper.GetDirOffsetY(dir);
/*  380 */             int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(dir);
/*  381 */             if (area == this.Areas[ai]) {
/*  382 */               nc++;
/*      */             }
/*      */           }
/*  385 */           if (nc != 4) {
/*  386 */             src[i] = 0;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  391 */     for (int y = 0; y < h; y++)
/*      */     {
/*  393 */       for (int x = 0; x < w; x++)
/*      */       {
/*  395 */         CompactCell c = this.Cells[(x + y * w)];
/*  396 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  398 */           CompactSpan s = this.Spans[i];
/*  399 */           if (s.GetCon(0) != NotConnected)
/*      */           {
/*  401 */             int ax = x + Helper.GetDirOffsetX(0);
/*  402 */             int ay = y + Helper.GetDirOffsetY(0);
/*  403 */             int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(0);
/*  404 */             CompactSpan aspan = this.Spans[ai];
/*  405 */             if (src[ai] + 2 < src[i]) {
/*  406 */               src[ai] += 2;
/*      */             }
/*  408 */             if (aspan.GetCon(3) != NotConnected)
/*      */             {
/*  410 */               int aax = ax + Helper.GetDirOffsetX(3);
/*  411 */               int aay = ay + Helper.GetDirOffsetY(3);
/*  412 */               int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(3);
/*  413 */               if (src[aai] + 3 < src[i])
/*  414 */                 src[aai] += 3;
/*      */             }
/*      */           }
/*  417 */           if (s.GetCon(3) == NotConnected)
/*      */             continue;
/*  419 */           int ax = x + Helper.GetDirOffsetX(3);
/*  420 */           int ay = y + Helper.GetDirOffsetY(3);
/*  421 */           int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(3);
/*  422 */           CompactSpan aspan = this.Spans[ai];
/*  423 */           if (src[ai] + 2 < src[i]) {
/*  424 */             src[ai] += 2;
/*      */           }
/*  426 */           if (aspan.GetCon(2) == NotConnected)
/*      */             continue;
/*  428 */           int aax = ax + Helper.GetDirOffsetX(2);
/*  429 */           int aay = ay + Helper.GetDirOffsetY(2);
/*  430 */           int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(2);
/*  431 */           if (src[aai] + 3 < src[i]) {
/*  432 */             src[aai] += 3;
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  440 */     for (int y = h - 1; y >= 0; y--)
/*      */     {
/*  442 */       for (int x = w - 1; x >= 0; x--)
/*      */       {
/*  444 */         CompactCell c = this.Cells[(x + y * w)];
/*  445 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  447 */           CompactSpan s = this.Spans[i];
/*  448 */           if (s.GetCon(2) != NotConnected)
/*      */           {
/*  450 */             int ax = x + Helper.GetDirOffsetX(2);
/*  451 */             int ay = y + Helper.GetDirOffsetY(2);
/*  452 */             int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(2);
/*  453 */             CompactSpan aspan = this.Spans[ai];
/*  454 */             if (src[ai] + 2 < src[i]) {
/*  455 */               src[ai] += 2;
/*      */             }
/*  457 */             if (aspan.GetCon(1) != NotConnected)
/*      */             {
/*  459 */               int aax = ax + Helper.GetDirOffsetX(1);
/*  460 */               int aay = ay + Helper.GetDirOffsetY(1);
/*  461 */               int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(1);
/*  462 */               if (src[aai] + 3 < src[i])
/*  463 */                 src[aai] += 3;
/*      */             }
/*      */           }
/*  466 */           if (s.GetCon(1) == NotConnected)
/*      */             continue;
/*  468 */           int ax = x + Helper.GetDirOffsetX(1);
/*  469 */           int ay = y + Helper.GetDirOffsetY(1);
/*  470 */           int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(1);
/*  471 */           CompactSpan aspan = this.Spans[ai];
/*  472 */           if (src[ai] + 2 < src[i]) {
/*  473 */             src[ai] += 2;
/*      */           }
/*  475 */           if (aspan.GetCon(0) == NotConnected)
/*      */             continue;
/*  477 */           int aax = ax + Helper.GetDirOffsetX(0);
/*  478 */           int aay = ay + Helper.GetDirOffsetY(0);
/*  479 */           int aai = (int)this.Cells[(aax + aay * w)].Index + aspan.GetCon(0);
/*  480 */           if (src[aai] + 3 < src[i]) {
/*  481 */             src[aai] += 3;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  488 */     maxDist = 0;
/*  489 */     for (int i = 0; i < this.SpanCount; i++)
/*      */     {
/*  491 */       maxDist = Math.max(src[i], maxDist);
/*      */     }
/*      */ 
/*  494 */     return maxDist;
/*      */   }
/*      */ 
/*      */   public Boolean BuildRegions(int borderSize, int minRegionArea, int mergeRegionArea)
/*      */   {
/*  499 */     int w = this.Width;
/*  500 */     int h = this.Height;
/*      */ 
/*  504 */     IntArray stack = new IntArray(1024);
/*  505 */     IntArray visited = new IntArray(1024);
/*      */ 
/*  507 */     int[] srcReg = new int[this.SpanCount];
/*  508 */     int[] srcDist = new int[this.SpanCount];
/*  509 */     int[] dstReg = new int[this.SpanCount];
/*  510 */     int[] dstDist = new int[this.SpanCount];
/*      */ 
/*  512 */     int regionId = 1;
/*  513 */     int level = this.MaxDistance + 1 & 0xFFFFFFFE;
/*      */ 
/*  515 */     int expandIters = 8;
/*      */ 
/*  517 */     if (borderSize > 0)
/*      */     {
/*  519 */       int bw = Math.min(w, borderSize);
/*  520 */       int bh = Math.min(h, borderSize);
/*      */ 
/*  522 */       PaintRectRegion(0, bw, 0, h, regionId | BorderReg, srcReg); regionId++;
/*  523 */       PaintRectRegion(w - bw, w, 0, h, regionId | BorderReg, srcReg); regionId++;
/*  524 */       PaintRectRegion(0, w, 0, bh, regionId | BorderReg, srcReg); regionId++;
/*  525 */       PaintRectRegion(0, w, h - bh, h, regionId | BorderReg, srcReg); regionId++;
/*      */ 
/*  527 */       this.BorderSize = borderSize;
/*      */     }
/*      */ 
/*  530 */     while (level > 0)
/*      */     {
/*  532 */       level = level >= 2 ? level - 2 : 0;
/*      */ 
/*  534 */       if (ExpandRegions(expandIters, level, srcReg, srcDist, dstReg, dstDist, stack) != srcReg)
/*      */       {
/*  536 */         int[] at = srcReg;
/*  537 */         srcReg = dstReg;
/*  538 */         dstReg = at;
/*  539 */         at = srcDist;
/*  540 */         srcDist = dstDist;
/*  541 */         dstDist = at;
/*      */       }
/*      */ 
/*  544 */       for (int y = 0; y < h; y++)
/*      */       {
/*  546 */         for (int x = 0; x < w; x++)
/*      */         {
/*  548 */           CompactCell c = this.Cells[(x + y * w)];
/*  549 */           int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */           {
/*  551 */             if ((this.Dist[i] < level) || (srcReg[i] != 0) || (this.Areas[i] == HeightField.NullArea) || 
/*  552 */               (!FloodRegion(x, y, i, level, regionId, srcReg, srcDist, stack).booleanValue())) continue;
/*  553 */             regionId++;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  559 */     if (ExpandRegions(expandIters * 8, 0, srcReg, srcDist, dstReg, dstDist, stack) != srcReg)
/*      */     {
/*  561 */       int[] t = srcReg;
/*  562 */       srcReg = dstReg;
/*  563 */       dstReg = t;
/*  564 */       t = srcDist;
/*  565 */       srcDist = dstDist;
/*  566 */       dstDist = t;
/*      */     }
/*      */ 
/*  569 */     this.MaxRegions = regionId;
/*  570 */     if (!FilterSmallRegions(minRegionArea, mergeRegionArea, srcReg).booleanValue()) {
/*  571 */       return Boolean.valueOf(false);
/*      */     }
/*  573 */     for (int i = 0; i < this.SpanCount; i++)
/*      */     {
/*  575 */       this.Spans[i].Reg = srcReg[i];
/*      */     }
/*  577 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private Boolean FilterSmallRegions(int minRegionArea, int mergeRegionArea, int[] srcReg)
/*      */   {
/*  582 */     int w = this.Width;
/*  583 */     int h = this.Height;
/*      */ 
/*  585 */     int nreg = this.MaxRegions + 1;
/*  586 */     Region[] regions = new Region[nreg];
/*      */ 
/*  588 */     for (int i = 0; i < nreg; i++)
/*      */     {
/*  590 */       regions[i] = new Region(i);
/*      */     }
/*      */ 
/*  593 */     for (int y = 0; y < h; y++)
/*      */     {
/*  595 */       for (int x = 0; x < w; x++)
/*      */       {
/*  597 */         CompactCell c = this.Cells[(x + y * w)];
/*  598 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  600 */           int r = srcReg[i];
/*  601 */           if ((r <= 0) || (r >= nreg))
/*      */             continue;
/*  603 */           Region reg = regions[r];
/*  604 */           reg.SpanCount += 1;
/*      */ 
/*  606 */           for (int j = (int)c.Index; j < ni; j++)
/*      */           {
/*  608 */             if (i != j) {
/*  609 */               int floorId = srcReg[j];
/*  610 */               if ((floorId > 0) && (floorId < nreg))
/*  611 */                 AddUniqueFloorRegion(reg, floorId);
/*      */             }
/*      */           }
/*  614 */           if (reg.Connections.Size > 0) {
/*      */             continue;
/*      */           }
/*  617 */           reg.AreaType = (short)(int)this.Areas[i];
/*      */ 
/*  619 */           int ndir = -1;
/*  620 */           for (int dir = 0; dir < 4; dir++)
/*      */           {
/*  622 */             if (!IsSolidEdge(srcReg, x, y, i, dir).booleanValue())
/*      */               continue;
/*  624 */             ndir = dir;
/*  625 */             break;
/*      */           }
/*      */ 
/*  629 */           if (ndir == -1)
/*      */             continue;
/*  631 */           WalkContour(x, y, i, ndir, srcReg, reg);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  638 */     IntArray stack = new IntArray(32);
/*  639 */     IntArray trace = new IntArray(32);
/*  640 */     for (int i = 0; i < nreg; i++)
/*      */     {
/*  642 */       Region reg = regions[i];
/*  643 */       if ((reg.Id <= 0) || ((reg.Id & BorderReg) != 0) || 
/*  644 */         (reg.SpanCount == 0) || 
/*  645 */         (reg.Visited.booleanValue()))
/*      */         continue;
/*  647 */       Boolean connectsToBorder = Boolean.valueOf(false);
/*  648 */       int spanCount = 0;
/*  649 */       stack.Resize(0);
/*  650 */       trace.Resize(0);
/*      */ 
/*  652 */       reg.Visited = Boolean.valueOf(true);
/*  653 */       stack.Push(i);
/*      */ 
/*  655 */       while (stack.Size > 0)
/*      */       {
/*  657 */         int ri = stack.Pop();
/*      */ 
/*  659 */         Region creg = regions[ri];
/*  660 */         spanCount += creg.SpanCount;
/*  661 */         trace.Push(ri);
/*      */ 
/*  663 */         for (int j = 0; j < creg.Connections.Size; j++)
/*      */         {
/*  665 */           if ((creg.Connections.get(j) & BorderReg) != 0)
/*      */           {
/*  667 */             connectsToBorder = Boolean.valueOf(true);
/*      */           }
/*      */           else {
/*  670 */             Region neireg = regions[creg.Connections.get(j)];
/*  671 */             if ((neireg.Visited.booleanValue()) || 
/*  672 */               (neireg.Id <= 0) || ((neireg.Id & BorderReg) != 0)) continue;
/*  673 */             stack.Push(neireg.Id);
/*  674 */             neireg.Visited = Boolean.valueOf(true);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  679 */       if ((spanCount >= minRegionArea) || (connectsToBorder.booleanValue()))
/*      */         continue;
/*  681 */       for (int j = 0; j < trace.Size; j++)
/*      */       {
/*  683 */         regions[trace.get(j)].SpanCount = 0;
/*  684 */         regions[trace.get(j)].Id = 0;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  689 */     int mergeCount = 0;
/*      */     do
/*      */     {
/*  692 */       mergeCount = 0;
/*  693 */       for (int i = 0; i < nreg; i++)
/*      */       {
/*  695 */         Region reg = regions[i];
/*  696 */         if ((reg.Id <= 0) || ((reg.Id & BorderReg) != 0) || 
/*  697 */           (reg.SpanCount == 0))
/*      */           continue;
/*  699 */         if ((reg.SpanCount > mergeRegionArea) && (IsRegionConnectedToBorder(reg).booleanValue()))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/*  704 */         int smallest = 2147483647;
/*  705 */         int mergeId = reg.Id;
/*  706 */         for (int j = 0; j < reg.Connections.Size; j++)
/*      */         {
/*  708 */           if ((reg.Connections.get(j) & BorderReg) == 0) {
/*  709 */             Region mreg = regions[reg.Connections.get(j)];
/*  710 */             if ((mreg.Id <= 0) || ((mreg.Id & BorderReg) != 0) || 
/*  711 */               (mreg.SpanCount >= smallest) || (!CanMergeWithRegion(reg, mreg).booleanValue()) || (!CanMergeWithRegion(mreg, reg).booleanValue()))
/*      */               continue;
/*  713 */             smallest = mreg.SpanCount;
/*  714 */             mergeId = mreg.Id;
/*      */           }
/*      */         }
/*  717 */         if (mergeId == reg.Id)
/*      */           continue;
/*  719 */         int oldId = reg.Id;
/*  720 */         Region target = regions[mergeId];
/*      */ 
/*  722 */         if (!MergeRegions(target, reg).booleanValue())
/*      */           continue;
/*  724 */         for (int j = 0; j < nreg; j++)
/*      */         {
/*  726 */           if ((regions[j].Id != 0) && ((regions[j].Id & BorderReg) == 0)) {
/*  727 */             if (regions[j].Id == oldId)
/*      */             {
/*  729 */               regions[j].Id = mergeId;
/*      */             }
/*  731 */             Region reg2 = regions[j];
/*  732 */             ReplaceNeighbor(reg2, oldId, mergeId);
/*      */           }
/*      */         }
/*  734 */         mergeCount++;
/*      */       }
/*      */     }
/*      */ 
/*  738 */     while (mergeCount > 0);
/*      */ 
/*  741 */     for (int i = 0; i < nreg; i++)
/*      */     {
/*  743 */       regions[i].Remap = Boolean.valueOf(false);
/*  744 */       if ((regions[i].Id != 0) && ((regions[i].Id & BorderReg) == 0)) {
/*  745 */         regions[i].Remap = Boolean.valueOf(true);
/*      */       }
/*      */     }
/*  748 */     int regIdGen = 0;
/*  749 */     for (int i = 0; i < nreg; i++)
/*      */     {
/*  751 */       if (!regions[i].Remap.booleanValue())
/*      */         continue;
/*  753 */       int oldId = regions[i].Id;
/*  754 */       regIdGen++; int newId = regIdGen;
/*  755 */       for (int j = i; j < nreg; j++)
/*      */       {
/*  757 */         if (regions[j].Id != oldId)
/*      */           continue;
/*  759 */         regions[j].Id = newId;
/*  760 */         regions[j].Remap = Boolean.valueOf(false);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  765 */     this.MaxRegions = regIdGen;
/*      */ 
/*  768 */     for (int i = 0; i < this.SpanCount; i++)
/*      */     {
/*  770 */       if ((srcReg[i] & BorderReg) == 0) {
/*  771 */         srcReg[i] = regions[srcReg[i]].Id;
/*      */       }
/*      */     }
/*  774 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private Boolean MergeRegions(Region rega, Region regb)
/*      */   {
/*  779 */     int aid = rega.Id;
/*  780 */     int bid = regb.Id;
/*      */ 
/*  782 */     IntArray acon = new IntArray(rega.Connections.Size);
/*  783 */     for (int i = 0; i < rega.Connections.Size; i++)
/*      */     {
/*  785 */       acon.set(i, rega.Connections.get(i));
/*      */     }
/*  787 */     IntArray bcon = regb.Connections;
/*      */ 
/*  789 */     int insa = -1;
/*  790 */     for (int i = 0; i < acon.Size; i++)
/*      */     {
/*  792 */       if (acon.get(i) != bid)
/*      */         continue;
/*  794 */       insa = i;
/*  795 */       break;
/*      */     }
/*      */ 
/*  798 */     if (insa == -1) {
/*  799 */       return Boolean.valueOf(false);
/*      */     }
/*  801 */     int insb = -1;
/*  802 */     for (int i = 0; i < bcon.Size; i++)
/*      */     {
/*  804 */       if (bcon.get(i) != aid)
/*      */         continue;
/*  806 */       insb = i;
/*  807 */       break;
/*      */     }
/*      */ 
/*  810 */     if (insb == -1) {
/*  811 */       return Boolean.valueOf(false);
/*      */     }
/*  813 */     rega.Connections.Resize(0);
/*  814 */     int i = 0; for (int ni = acon.Size; i < ni - 1; i++)
/*      */     {
/*  816 */       rega.Connections.Push(acon.get((insa + 1 + i) % ni));
/*      */     }
/*  818 */     int i = 0; for (int ni = bcon.Size; i < ni - 1; i++)
/*      */     {
/*  820 */       rega.Connections.Push(bcon.get((insb + 1 + i) % ni));
/*      */     }
/*  822 */     RemoveAdjacentNeighbors(rega);
/*      */ 
/*  824 */     for (int j = 0; j < regb.Floors.Size; j++)
/*      */     {
/*  826 */       AddUniqueFloorRegion(rega, regb.Floors.get(j));
/*      */     }
/*  828 */     rega.SpanCount += regb.SpanCount;
/*  829 */     regb.SpanCount = 0;
/*  830 */     regb.Connections.Resize(0);
/*      */ 
/*  832 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private void ReplaceNeighbor(Region reg, int oldId, int newId)
/*      */   {
/*  837 */     Boolean neiChanged = Boolean.valueOf(false);
/*  838 */     for (int i = 0; i < reg.Connections.Size; i++)
/*      */     {
/*  840 */       if (reg.Connections.get(i) != oldId)
/*      */         continue;
/*  842 */       reg.Connections.set(i, newId);
/*  843 */       neiChanged = Boolean.valueOf(true);
/*      */     }
/*      */ 
/*  846 */     for (int i = 0; i < reg.Floors.Size; i++)
/*      */     {
/*  848 */       if (reg.Floors.get(i) == oldId)
/*  849 */         reg.Floors.set(i, newId);
/*      */     }
/*  851 */     if (neiChanged.booleanValue())
/*  852 */       RemoveAdjacentNeighbors(reg);
/*      */   }
/*      */ 
/*      */   private void RemoveAdjacentNeighbors(Region reg)
/*      */   {
/*  857 */     for (int i = 0; (i < reg.Connections.Size) && (reg.Connections.Size > 1); )
/*      */     {
/*  859 */       int ni = (i + 1) % reg.Connections.Size;
/*  860 */       if (reg.Connections.get(i) == reg.Connections.get(ni))
/*      */       {
/*  862 */         for (int j = 0; j < reg.Connections.Size - 1; j++)
/*      */         {
/*  864 */           reg.Connections.set(j, reg.Connections.get(j + 1));
/*      */         }
/*  866 */         reg.Connections.Pop();
/*      */       }
/*      */       else
/*      */       {
/*  870 */         i++;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private Boolean CanMergeWithRegion(Region rega, Region regb)
/*      */   {
/*  877 */     if (rega.AreaType != regb.AreaType)
/*  878 */       return Boolean.valueOf(false);
/*  879 */     int n = 0;
/*  880 */     for (int i = 0; i < rega.Connections.Size; i++)
/*      */     {
/*  882 */       if (rega.Connections.get(i) == regb.Id)
/*  883 */         n++;
/*      */     }
/*  885 */     if (n > 1)
/*  886 */       return Boolean.valueOf(false);
/*  887 */     for (int i = 0; i < rega.Floors.Size; i++)
/*      */     {
/*  889 */       if (rega.Floors.get(i) == regb.Id)
/*  890 */         return Boolean.valueOf(false);
/*      */     }
/*  892 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private Boolean IsRegionConnectedToBorder(Region reg)
/*      */   {
/*  897 */     for (int i = 0; i < reg.Connections.Size; i++)
/*      */     {
/*  899 */       if (reg.Connections.get(i) == 0)
/*  900 */         return Boolean.valueOf(true);
/*      */     }
/*  902 */     return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   private void WalkContour(int x, int y, int i, int dir, int[] srcReg, Region cont)
/*      */   {
/*  907 */     int startDir = dir;
/*  908 */     int starti = i;
/*      */ 
/*  910 */     CompactSpan ss = this.Spans[i];
/*  911 */     int curReg = 0;
/*  912 */     if (ss.GetCon(dir) != NotConnected)
/*      */     {
/*  914 */       int ax = x + Helper.GetDirOffsetX(dir);
/*  915 */       int ay = y + Helper.GetDirOffsetY(dir);
/*  916 */       int ai = (int)this.Cells[(ax + ay * this.Width)].Index + ss.GetCon(dir);
/*  917 */       curReg = srcReg[ai];
/*      */     }
/*  919 */     cont.Connections.Push(curReg);
/*      */ 
/*  921 */     int iter = 0;
/*      */     while (true) { iter++; if (iter >= 40000)
/*      */         break;
/*  924 */       CompactSpan s = this.Spans[i];
/*  925 */       if (IsSolidEdge(srcReg, x, y, i, dir).booleanValue())
/*      */       {
/*  927 */         int r = 0;
/*  928 */         if (s.GetCon(dir) != NotConnected)
/*      */         {
/*  930 */           int ax = x + Helper.GetDirOffsetX(dir);
/*  931 */           int ay = y + Helper.GetDirOffsetY(dir);
/*  932 */           int ai = (int)this.Cells[(ax + ay * this.Width)].Index + s.GetCon(dir);
/*  933 */           r = srcReg[ai];
/*      */         }
/*  935 */         if (r != curReg)
/*      */         {
/*  937 */           curReg = r;
/*  938 */           cont.Connections.Push(curReg);
/*      */         }
/*      */ 
/*  941 */         dir = dir + 1 & 0x3;
/*      */       }
/*      */       else
/*      */       {
/*  945 */         int ni = -1;
/*  946 */         int nx = x + Helper.GetDirOffsetX(dir);
/*  947 */         int ny = y + Helper.GetDirOffsetY(dir);
/*  948 */         if (s.GetCon(dir) != NotConnected)
/*      */         {
/*  950 */           CompactCell nc = this.Cells[(nx + ny * this.Width)];
/*  951 */           ni = (int)nc.Index + s.GetCon(dir);
/*      */         }
/*  953 */         if (ni == -1)
/*      */         {
/*  956 */           return;
/*      */         }
/*  958 */         x = nx;
/*  959 */         y = ny;
/*  960 */         i = ni;
/*  961 */         dir = dir + 3 & 0x3;
/*      */       }
/*      */ 
/*  964 */       if ((starti == i) && (startDir == dir))
/*      */         break;
/*      */     }
/*      */     int j;
/*  971 */     if (cont.Connections.Size > 1)
/*      */     {
/*  973 */       for (j = 0; j < cont.Connections.Size; )
/*      */       {
/*  975 */         int nj = (j + 1) % cont.Connections.Size;
/*  976 */         if (cont.Connections.get(j) == cont.Connections.get(nj))
/*      */         {
/*  978 */           for (int k = j; k < cont.Connections.Size - 1; k++)
/*      */           {
/*  980 */             cont.Connections.set(k, cont.Connections.get(k + 1));
/*      */           }
/*  982 */           cont.Connections.Pop();
/*      */         }
/*      */         else
/*      */         {
/*  986 */           j++;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private Boolean IsSolidEdge(int[] srcReg, int x, int y, int i, int dir)
/*      */   {
/*  994 */     CompactSpan s = this.Spans[i];
/*  995 */     int r = 0;
/*  996 */     if (s.GetCon(dir) != NotConnected)
/*      */     {
/*  998 */       int ax = x + Helper.GetDirOffsetX(dir);
/*  999 */       int ay = y + Helper.GetDirOffsetY(dir);
/* 1000 */       int ai = (int)this.Cells[(ax + ay * this.Width)].Index + s.GetCon(dir);
/* 1001 */       r = srcReg[ai];
/*      */     }
/* 1003 */     if (r == srcReg[i])
/* 1004 */       return Boolean.valueOf(false);
/* 1005 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private void AddUniqueFloorRegion(Region reg, int n)
/*      */   {
/* 1011 */     for (int i = 0; i < reg.Floors.Size; i++)
/*      */     {
/* 1013 */       if (reg.Floors.get(i) == n)
/* 1014 */         return;
/*      */     }
/* 1016 */     reg.Floors.Push(n);
/*      */   }
/*      */ 
/*      */   private Boolean FloodRegion(int x, int y, int i, int level, int r, int[] srcReg, int[] srcDist, IntArray stack)
/*      */   {
/* 1021 */     int w = this.Width;
/* 1022 */     long area = this.Areas[i];
/*      */ 
/* 1024 */     stack.Resize(0);
/* 1025 */     stack.Push(x);
/* 1026 */     stack.Push(y);
/* 1027 */     stack.Push(i);
/* 1028 */     srcReg[i] = r;
/* 1029 */     srcDist[i] = 0;
/*      */ 
/* 1031 */     int lev = level >= 2 ? level - 2 : 0;
/* 1032 */     int count = 0;
/*      */ 
/* 1034 */     while (stack.Size > 0)
/*      */     {
/* 1036 */       int ci = stack.Pop();
/* 1037 */       int cy = stack.Pop();
/* 1038 */       int cx = stack.Pop();
/*      */ 
/* 1040 */       CompactSpan cs = this.Spans[ci];
/*      */ 
/* 1042 */       int ar = 0;
/* 1043 */       for (int dir = 0; dir < 4; dir++)
/*      */       {
/* 1045 */         if (cs.GetCon(dir) == NotConnected)
/*      */           continue;
/* 1047 */         int ax = cx + Helper.GetDirOffsetX(dir);
/* 1048 */         int ay = cy + Helper.GetDirOffsetY(dir);
/* 1049 */         int ai = (int)this.Cells[(ax + ay * w)].Index + cs.GetCon(dir);
/* 1050 */         if (this.Areas[ai] == area) {
/* 1051 */           int nr = srcReg[ai];
/* 1052 */           if ((nr & BorderReg) == 0) {
/* 1053 */             if ((nr != 0) && (nr != r))
/* 1054 */               ar = nr;
/* 1055 */             CompactSpan aspan = this.Spans[ai];
/*      */ 
/* 1057 */             int dir2 = dir + 1 & 0x3;
/* 1058 */             if (aspan.GetCon(dir2) == NotConnected)
/*      */               continue;
/* 1060 */             int ax2 = ax + Helper.GetDirOffsetX(dir2);
/* 1061 */             int ay2 = ay + Helper.GetDirOffsetY(dir2);
/* 1062 */             int ai2 = (int)this.Cells[(ax2 + ay2 * w)].Index + aspan.GetCon(dir2);
/* 1063 */             if (this.Areas[ai2] == area) {
/* 1064 */               int nr2 = srcReg[ai2];
/* 1065 */               if ((nr2 != 0) && (nr2 != r))
/* 1066 */                 ar = nr2; 
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1070 */       if (ar != 0)
/*      */       {
/* 1072 */         srcReg[ci] = 0;
/* 1073 */         continue;
/*      */       }
/* 1075 */       count++;
/*      */ 
/* 1077 */       for (int dir = 0; dir < 4; dir++)
/*      */       {
/* 1079 */         if (cs.GetCon(dir) == NotConnected)
/*      */           continue;
/* 1081 */         int ax = cx + Helper.GetDirOffsetX(dir);
/* 1082 */         int ay = cy + Helper.GetDirOffsetY(dir);
/* 1083 */         int ai = (int)this.Cells[(ax + ay * w)].Index + cs.GetCon(dir);
/* 1084 */         if ((this.Areas[ai] != area) || 
/* 1085 */           (this.Dist[ai] < lev) || (srcReg[ai] != 0))
/*      */           continue;
/* 1087 */         srcReg[ai] = r;
/* 1088 */         srcDist[ai] = 0;
/* 1089 */         stack.Push(ax);
/* 1090 */         stack.Push(ay);
/* 1091 */         stack.Push(ai);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1097 */     return Boolean.valueOf(count > 0);
/*      */   }
/*      */ 
/*      */   private int[] ExpandRegions(int maxIter, int level, int[] srcReg, int[] srcDist, int[] dstReg, int[] dstDist, IntArray stack)
/*      */   {
/* 1102 */     int w = this.Width;
/* 1103 */     int h = this.Height;
/*      */ 
/* 1105 */     stack.Resize(0);
/* 1106 */     for (int y = 0; y < h; y++)
/*      */     {
/* 1108 */       for (int x = 0; x < w; x++)
/*      */       {
/* 1110 */         CompactCell c = this.Cells[(x + y * w)];
/* 1111 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/* 1113 */           if ((this.Dist[i] < level) || (srcReg[i] != 0) || (this.Areas[i] == HeightField.NullArea))
/*      */             continue;
/* 1115 */           stack.Push(x);
/* 1116 */           stack.Push(y);
/* 1117 */           stack.Push(i);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1123 */     int iter = 0;
/* 1124 */     while (stack.Size > 0)
/*      */     {
/* 1126 */       int failed = 0;
/*      */ 
/* 1128 */       System.arraycopy(srcReg, 0, dstReg, 0, 4 * this.SpanCount);
/* 1129 */       System.arraycopy(srcDist, 0, dstDist, 0, 4 * this.SpanCount);
/*      */ 
/* 1133 */       for (int j = 0; j < stack.Size; j += 3)
/*      */       {
/* 1135 */         int x = stack.get(j + 0);
/* 1136 */         int y = stack.get(j + 1);
/* 1137 */         int i = stack.get(j + 2);
/* 1138 */         if (i < 0)
/*      */         {
/* 1140 */           failed++;
/*      */         }
/*      */         else
/*      */         {
/* 1144 */           int r = srcReg[i];
/* 1145 */           int d2 = 32767;
/* 1146 */           long area = this.Areas[i];
/* 1147 */           CompactSpan s = this.Spans[i];
/* 1148 */           for (int dir = 0; dir < 4; dir++)
/*      */           {
/* 1150 */             if (s.GetCon(dir) != NotConnected) {
/* 1151 */               int ax = x + Helper.GetDirOffsetX(dir);
/* 1152 */               int ay = y + Helper.GetDirOffsetY(dir);
/* 1153 */               int ai = (int)this.Cells[(ax + ay * w)].Index + s.GetCon(dir);
/* 1154 */               if ((this.Areas[ai] != area) || 
/* 1155 */                 (srcReg[ai] <= 0) || ((srcReg[ai] & BorderReg) != 0))
/*      */                 continue;
/* 1157 */               if (srcDist[ai] + 2 >= d2)
/*      */                 continue;
/* 1159 */               r = srcReg[ai];
/* 1160 */               d2 = srcDist[ai] + 2;
/*      */             }
/*      */           }
/*      */ 
/* 1164 */           if (r != 0)
/*      */           {
/* 1166 */             stack.set(j + 2, -1);
/* 1167 */             dstReg[i] = r;
/* 1168 */             dstDist[i] = d2;
/*      */           }
/*      */           else
/*      */           {
/* 1172 */             failed++;
/*      */           }
/*      */         }
/*      */       }
/* 1175 */       int[] temp = srcReg;
/* 1176 */       srcReg = dstReg;
/* 1177 */       dstReg = temp;
/* 1178 */       temp = srcDist;
/* 1179 */       srcDist = dstDist;
/* 1180 */       dstDist = temp;
/*      */ 
/* 1182 */       if (failed * 3 == stack.Size) {
/*      */         break;
/*      */       }
/* 1185 */       if (level > 0)
/*      */       {
/* 1187 */         iter++;
/* 1188 */         if (iter >= maxIter)
/*      */           break;
/*      */       }
/*      */     }
/* 1192 */     return srcReg;
/*      */   }
/*      */ 
/*      */   private void PaintRectRegion(int minx, int maxx, int miny, int maxy, int regId, int[] srcReg)
/*      */   {
/* 1197 */     int w = this.Width;
/* 1198 */     for (int y = miny; y < maxy; y++)
/*      */     {
/* 1200 */       for (int x = minx; x < maxx; x++)
/*      */       {
/* 1202 */         CompactCell c = this.Cells[(x + y * w)];
/* 1203 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/* 1205 */           if (this.Areas[i] != HeightField.NullArea)
/* 1206 */             srcReg[i] = regId;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.CompactHeightfield
 * JD-Core Version:    0.6.0
 */