package atavism.server.pathing.recast;

public class CompactCell
{
  public long Index;
  public long Count;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.CompactCell
 * JD-Core Version:    0.6.0
 */