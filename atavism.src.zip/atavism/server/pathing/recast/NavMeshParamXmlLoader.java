/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ import atavism.server.pathing.detour.NavMesh;
/*     */ import atavism.server.pathing.detour.NavMeshParams;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.XMLHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class NavMeshParamXmlLoader
/*     */ {
/*     */   protected String worldFileName;
/*     */   protected Document worldDoc;
/*     */ 
/*     */   public NavMeshParamXmlLoader(String worldFileName)
/*     */   {
/*  21 */     this.worldFileName = worldFileName;
/*     */   }
/*     */ 
/*     */   public boolean load(NavMesh navMesh)
/*     */   {
/*  26 */     if (!parse()) {
/*  27 */       return false;
/*     */     }
/*  29 */     return generate(navMesh);
/*     */   }
/*     */ 
/*     */   public boolean parse()
/*     */   {
/*     */     try {
/*  35 */       DocumentBuilder builder = XMLHelper.makeDocBuilder();
/*  36 */       Log.debug("NAVMESH: loading in file: " + this.worldFileName);
/*  37 */       File xmlFile = new File(this.worldFileName);
/*     */ 
/*  39 */       this.worldDoc = builder.parse(xmlFile);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  43 */       Log.error("NavMesh WorldFile not found: " + this.worldFileName + ". Reverting to old pathing system");
/*  44 */       return false;
/*     */     } catch (SAXException e) {
/*  46 */       Log.exception("NavMeshParamXmlLoader.parse(" + this.worldFileName + ")", e);
/*  47 */       return false;
/*     */     }
/*  49 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean generate(NavMesh navMesh)
/*     */   {
/*  54 */     Node paramNode = XMLHelper.getMatchingChild(this.worldDoc, "NavMeshParams");
/*     */ 
/*  56 */     if (paramNode == null) {
/*  57 */       Log.error("No <Param> node in file " + this.worldFileName);
/*  58 */       return false;
/*     */     }
/*     */ 
/*  61 */     NavMeshParams param = new NavMeshParams();
/*     */ 
/*  63 */     Node origNode = XMLHelper.getMatchingChild(paramNode, "Orig");
/*  64 */     if (origNode == null) {
/*  65 */       Log.debug("No <Orig> node in BVNode");
/*     */     } else {
/*  67 */       List origNodes = XMLHelper.getMatchingChildren(origNode, "float");
/*  68 */       float[] orig = new float[origNodes.size()];
/*  69 */       for (int i = 0; i < origNodes.size(); i++) {
/*  70 */         Element eElement = (Element)origNodes.get(i);
/*  71 */         orig[i] = Float.parseFloat(eElement.getTextContent());
/*     */       }
/*  73 */       param.Orig = orig;
/*     */     }
/*     */ 
/*  76 */     Element eElement = (Element)XMLHelper.getMatchingChild(paramNode, "TileWidth");
/*  77 */     param.TileWidth = Float.parseFloat(eElement.getTextContent());
/*  78 */     eElement = (Element)XMLHelper.getMatchingChild(paramNode, "TileHeight");
/*  79 */     param.TileHeight = Float.parseFloat(eElement.getTextContent());
/*  80 */     eElement = (Element)XMLHelper.getMatchingChild(paramNode, "MaxTiles");
/*  81 */     param.MaxTiles = Integer.parseInt(eElement.getTextContent());
/*  82 */     eElement = (Element)XMLHelper.getMatchingChild(paramNode, "MaxPolys");
/*  83 */     param.MaxPolys = Integer.parseInt(eElement.getTextContent());
/*     */ 
/*  85 */     navMesh.Init(param);
/*     */ 
/*  87 */     int maxX = (int)Math.sqrt(param.MaxTiles);
/*  88 */     String fileName = this.worldFileName.substring(0, this.worldFileName.length() - 4);
/*  89 */     for (int x = 0; x < maxX; x++) {
/*  90 */       for (int y = 0; y < maxX; y++) {
/*  91 */         Log.debug("NAVMESH: loading file: " + fileName + "_tile" + x + "_" + y + ".xml");
/*  92 */         NavMeshXmlLoader navMeshLoader = new NavMeshXmlLoader(fileName + "_tile" + x + "_" + y + ".xml");
/*  93 */         navMeshLoader.load(navMesh);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 106 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.NavMeshParamXmlLoader
 * JD-Core Version:    0.6.0
 */