/*    */ package atavism.server.pathing.recast;
/*    */ 
/*    */ public class IntArray
/*    */ {
/*    */   public int[] Data;
/*    */   public int Size;
/*    */   public int Capacity;
/*    */ 
/*    */   public IntArray()
/*    */   {
/* 11 */     this.Data = null;
/* 12 */     this.Size = 0;
/* 13 */     this.Capacity = 0;
/*    */   }
/*    */ 
/*    */   public IntArray(int n)
/*    */   {
/* 18 */     Resize(n);
/*    */   }
/*    */ 
/*    */   public void Resize(int n)
/*    */   {
/* 23 */     if (n > this.Capacity)
/*    */     {
/* 25 */       if (this.Capacity == 0) this.Capacity = 10;
/* 26 */       while (this.Capacity < n) this.Capacity *= 2;
/* 27 */       int[] newData = new int[this.Capacity];
/* 28 */       if (this.Size > 0) System.arraycopy(this.Data, 0, newData, 0, this.Size);
/* 29 */       this.Data = newData;
/*    */     }
/* 31 */     this.Size = n;
/*    */   }
/*    */ 
/*    */   public void Push(int item)
/*    */   {
/* 36 */     Resize(this.Size + 1);
/* 37 */     this.Data[(this.Size - 1)] = item;
/*    */   }
/*    */ 
/*    */   public int Pop()
/*    */   {
/* 42 */     if (this.Size > 0)
/* 43 */       this.Size -= 1;
/* 44 */     return this.Data[this.Size];
/*    */   }
/*    */ 
/*    */   public int get(int i)
/*    */   {
/* 49 */     return this.Data[i];
/*    */   }
/*    */ 
/*    */   public void set(int i, int value) {
/* 53 */     this.Data[i] = value;
/*    */   }
/*    */ 
/*    */   public int[] ToArray()
/*    */   {
/* 58 */     return this.Data;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.IntArray
 * JD-Core Version:    0.6.0
 */