/*    */ package atavism.server.pathing.recast;
/*    */ 
/*    */ public class Region
/*    */ {
/*    */   public int SpanCount;
/*    */   public int Id;
/*    */   public short AreaType;
/*    */   public Boolean Remap;
/*    */   public Boolean Visited;
/*    */   public IntArray Connections;
/*    */   public IntArray Floors;
/*    */ 
/*    */   public Region(int i)
/*    */   {
/* 15 */     this.SpanCount = 0;
/* 16 */     this.Id = i;
/* 17 */     this.AreaType = 0;
/* 18 */     this.Remap = Boolean.valueOf(false);
/* 19 */     this.Visited = Boolean.valueOf(false);
/* 20 */     this.Connections = new IntArray();
/* 21 */     this.Floors = new IntArray();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.Region
 * JD-Core Version:    0.6.0
 */