/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ import atavism.server.math.IntVector2;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ public class ChunkyTriMesh
/*     */ {
/*     */   public ChunkyTriMeshNode[] Nodes;
/*     */   public int NNodes;
/*     */   public int[] Tris;
/*     */   public int NTris;
/*     */   public int MaxTrisPerChunk;
/*     */ 
/*     */   public ChunkyTriMesh(RecastVertex[] verts, Integer[] tris, int ntris, int trisPerChunk)
/*     */   {
/*  19 */     int nchunks = (ntris + trisPerChunk - 1) / trisPerChunk;
/*  20 */     this.Nodes = new ChunkyTriMeshNode[nchunks * 4];
/*  21 */     this.Tris = new int[ntris * 3];
/*     */ 
/*  23 */     this.NTris = ntris;
/*     */ 
/*  25 */     BoundsItem[] items = new BoundsItem[ntris];
/*     */ 
/*  27 */     for (int i = 0; i < ntris; i++)
/*     */     {
/*  29 */       int t = i * 3;
/*  30 */       items[i] = new BoundsItem();
/*  31 */       BoundsItem it = items[i];
/*  32 */       it.i = i;
/*     */       float tmp111_108 = verts[tris[t].intValue()].X; it.bmax[0] = tmp111_108; it.bmin[0] = tmp111_108;
/*     */       float tmp138_135 = verts[tris[t].intValue()].Z; it.bmax[1] = tmp138_135; it.bmin[1] = tmp138_135;
/*  35 */       for (int j = 1; j < 3; j++)
/*     */       {
/*  37 */         int v = tris[(t + j)].intValue();
/*  38 */         if (verts[v].X < it.bmin[0]) it.bmin[0] = verts[v].X;
/*  39 */         if (verts[v].Z < it.bmin[1]) it.bmin[1] = verts[v].Z;
/*     */ 
/*  41 */         if (verts[v].X > it.bmax[0]) it.bmax[0] = verts[v].X;
/*  42 */         if (verts[v].Z <= it.bmax[1]) continue; it.bmax[1] = verts[v].Z;
/*     */       }
/*     */     }
/*     */ 
/*  46 */     IntVector2 curTriNode = new IntVector2(0, 0);
/*  47 */     Subdivide(items, ntris, 0, ntris, trisPerChunk, curTriNode, nchunks * 4, tris);
/*     */ 
/*  49 */     this.NNodes = curTriNode.x;
/*     */ 
/*  51 */     this.MaxTrisPerChunk = 0;
/*  52 */     for (int i = 0; i < this.NNodes; i++)
/*     */     {
/*  54 */       Boolean isLeaf = Boolean.valueOf(this.Nodes[i].i >= 0);
/*  55 */       if ((!isLeaf.booleanValue()) || 
/*  56 */         (this.Nodes[i].n <= this.MaxTrisPerChunk)) continue;
/*  57 */       this.MaxTrisPerChunk = this.Nodes[i].n;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int GetChunksOverlappingRect(float[] bmin, float[] bmax, int[] ids, int maxIds)
/*     */   {
/*  63 */     int i = 0;
/*  64 */     int n = 0;
/*  65 */     while (i < this.NNodes)
/*     */     {
/*  67 */       ChunkyTriMeshNode node = this.Nodes[i];
/*  68 */       Boolean overlap = CheckOverlapRect(bmin, bmax, node.bmin, node.bmax);
/*  69 */       Boolean isLeafNode = Boolean.valueOf(node.i >= 0);
/*     */ 
/*  71 */       if ((isLeafNode.booleanValue()) && (overlap.booleanValue()))
/*     */       {
/*  73 */         if (n < maxIds)
/*     */         {
/*  75 */           ids[n] = i;
/*  76 */           n++;
/*     */         }
/*     */       }
/*     */ 
/*  80 */       if ((overlap.booleanValue()) || (isLeafNode.booleanValue()))
/*     */       {
/*  82 */         i++;
/*     */       }
/*     */       else
/*     */       {
/*  86 */         int escapeIndex = -node.i;
/*  87 */         i += escapeIndex;
/*     */       }
/*     */     }
/*  90 */     return n;
/*     */   }
/*     */ 
/*     */   private Boolean CheckOverlapRect(float[] amin, float[] amax, float[] bmin, float[] bmax)
/*     */   {
/*  95 */     Boolean overlap = Boolean.valueOf(true);
/*  96 */     overlap = Boolean.valueOf((amin[0] > bmax[0]) || (amax[0] < bmin[0]) ? false : overlap.booleanValue());
/*  97 */     overlap = Boolean.valueOf((amin[1] > bmax[1]) || (amax[1] < bmin[1]) ? false : overlap.booleanValue());
/*  98 */     return overlap;
/*     */   }
/*     */ 
/*     */   private void Subdivide(BoundsItem[] items, int nitems, int imin, int imax, int trisPerChunk, IntVector2 curNodeTri, int maxNodes, Integer[] tris)
/*     */   {
/* 103 */     int inum = imax - imin;
/* 104 */     int icur = curNodeTri.x;
/*     */ 
/* 106 */     if (curNodeTri.x > maxNodes) {
/* 107 */       return;
/*     */     }
/*     */ 
/* 110 */     ChunkyTriMeshNode node = this.Nodes[curNodeTri.x];
/* 111 */     if (this.Nodes[curNodeTri.x] == null)
/*     */     {
/* 113 */       node = new ChunkyTriMeshNode();
/* 114 */       this.Nodes[curNodeTri.x] = node;
/*     */     }
/* 116 */     curNodeTri.x += 1;
/*     */ 
/* 118 */     if (inum <= trisPerChunk)
/*     */     {
/* 120 */       CalcExtends(items, nitems, imin, imax, node);
/*     */ 
/* 122 */       node.i = curNodeTri.y;
/* 123 */       node.n = inum;
/*     */ 
/* 125 */       for (int i = imin; i < imax; i++)
/*     */       {
/* 127 */         int src = items[i].i * 3;
/* 128 */         int dst = curNodeTri.y * 3;
/* 129 */         curNodeTri.y += 1;
/* 130 */         this.Tris[(dst + 0)] = tris[(src + 0)].intValue();
/* 131 */         this.Tris[(dst + 1)] = tris[(src + 1)].intValue();
/* 132 */         this.Tris[(dst + 2)] = tris[(src + 2)].intValue();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 137 */       CalcExtends(items, nitems, imin, imax, node);
/*     */ 
/* 139 */       int axis = LongestAxis(node.bmax[0] - node.bmin[0], node.bmax[1] - node.bmin[1]);
/*     */ 
/* 141 */       if (axis == 0)
/*     */       {
/* 144 */         Arrays.sort(items, imin, inum, new CompareItemX());
/*     */       }
/* 146 */       else if (axis == 1)
/*     */       {
/* 149 */         Arrays.sort(items, imin, inum, new CompareItemY());
/*     */       }
/*     */ 
/* 152 */       int isplit = imin + inum / 2;
/*     */ 
/* 154 */       Subdivide(items, nitems, imin, isplit, trisPerChunk, curNodeTri, maxNodes, tris);
/* 155 */       Subdivide(items, nitems, isplit, imax, trisPerChunk, curNodeTri, maxNodes, tris);
/*     */ 
/* 157 */       int iescape = curNodeTri.x - icur;
/* 158 */       node.i = (-iescape);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void CalcExtends(BoundsItem[] items, int nitems, int imin, int imax, ChunkyTriMeshNode node)
/*     */   {
/* 166 */     node.bmin[0] = items[imin].bmin[0];
/* 167 */     node.bmin[1] = items[imin].bmin[1];
/*     */ 
/* 169 */     node.bmax[0] = items[imin].bmax[0];
/* 170 */     node.bmax[1] = items[imin].bmax[1];
/*     */ 
/* 172 */     for (int i = imin + 1; i < imax; i++)
/*     */     {
/* 174 */       BoundsItem it = items[i];
/* 175 */       if (it.bmin[0] < node.bmin[0]) node.bmin[0] = it.bmin[0];
/* 176 */       if (it.bmin[1] < node.bmin[1]) node.bmin[1] = it.bmin[1];
/*     */ 
/* 178 */       if (it.bmax[0] > node.bmax[0]) node.bmax[0] = it.bmax[0];
/* 179 */       if (it.bmax[1] <= node.bmax[1]) continue; node.bmax[1] = it.bmax[1];
/*     */     }
/*     */   }
/*     */ 
/*     */   private int LongestAxis(float x, float y)
/*     */   {
/* 185 */     return y > x ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public class CompareItemY
/*     */     implements Comparator<Object>
/*     */   {
/*     */     public CompareItemY()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int compare(Object va, Object vb)
/*     */     {
/* 210 */       BoundsItem a = (BoundsItem)va;
/* 211 */       BoundsItem b = (BoundsItem)vb;
/* 212 */       if ((a != null) && (b != null))
/*     */       {
/* 214 */         if (a.bmin[1] < b.bmin[1])
/* 215 */           return -1;
/* 216 */         if (a.bmin[1] > b.bmin[1])
/* 217 */           return 1;
/*     */       }
/* 219 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class CompareItemX
/*     */     implements Comparator<Object>
/*     */   {
/*     */     public CompareItemX()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int compare(Object va, Object vb)
/*     */     {
/* 192 */       BoundsItem a = (BoundsItem)va;
/* 193 */       BoundsItem b = (BoundsItem)vb;
/* 194 */       if ((a != null) && (b != null))
/*     */       {
/* 197 */         if (a.bmin[0] < b.bmin[0])
/* 198 */           return -1;
/* 199 */         if (a.bmin[0] > b.bmin[0])
/* 200 */           return 1;
/*     */       }
/* 202 */       return 0;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.ChunkyTriMesh
 * JD-Core Version:    0.6.0
 */