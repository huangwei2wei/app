/*      */ package atavism.server.pathing.recast;
/*      */ 
/*      */ import atavism.server.math.IntVector2;
/*      */ import atavism.server.pathing.detour.DetourNumericReturn;
/*      */ 
/*      */ public class DetailPolyMesh
/*      */ {
/*      */   public long[] Meshes;
/*      */   public float[] Verts;
/*      */   public short[] Tris;
/*      */   public int NMeshes;
/*      */   public int NVerts;
/*      */   public int NTris;
/*   15 */   public static int UnsetHeight = 65535;
/*      */ 
/*   17 */   public static int Undef = -1;
/*   18 */   public static int Hull = -2;
/*      */ 
/*   20 */   protected float[] DistPtTriV0 = new float[3]; protected float[] DistPtTriV1 = new float[3]; protected float[] DistPtTriV2 = new float[3];
/*      */ 
/*      */   public DetailPolyMesh(PolyMesh mesh, CompactHeightfield chf, float sampleDist, float sampleMaxError)
/*      */   {
/*   24 */     if ((mesh.NVerts == 0) || (mesh.NPolys == 0)) {
/*   25 */       return;
/*      */     }
/*   27 */     int nvp = mesh.Nvp;
/*   28 */     float cs = mesh.Cs;
/*   29 */     float ch = mesh.Ch;
/*   30 */     float[] orig = mesh.BMin;
/*   31 */     int borderSize = mesh.BorderSize;
/*      */ 
/*   33 */     IntArray edges = new IntArray(64);
/*   34 */     IntArray tris = new IntArray(512);
/*   35 */     IntArray stack = new IntArray(512);
/*   36 */     IntArray samples = new IntArray(512);
/*   37 */     float[] verts = new float[768];
/*   38 */     HeightPatch hp = new HeightPatch();
/*   39 */     int nPolyVerts = 0;
/*   40 */     int maxhw = 0; int maxhh = 0;
/*      */ 
/*   42 */     int[] bounds = new int[mesh.NPolys * 4];
/*   43 */     float[] poly = new float[nvp * 3];
/*      */ 
/*   45 */     for (int i = 0; i < mesh.NPolys; i++)
/*      */     {
/*   47 */       int p = i * nvp * 2;
/*   48 */       int xmin = i * 4 + 0;
/*   49 */       int xmax = i * 4 + 1;
/*   50 */       int ymin = i * 4 + 2;
/*   51 */       int ymax = i * 4 + 3;
/*      */ 
/*   53 */       bounds[xmin] = chf.Width;
/*   54 */       bounds[xmax] = 0;
/*   55 */       bounds[ymin] = chf.Height;
/*   56 */       bounds[ymax] = 0;
/*      */ 
/*   58 */       for (int j = 0; j < nvp; j++)
/*      */       {
/*   60 */         if (mesh.Polys[(p + j)] == PolyMesh.MeshNullIdx) break;
/*   61 */         int v = mesh.Polys[(p + j)] * 3;
/*   62 */         bounds[xmin] = Math.min(bounds[xmin], mesh.Verts[(v + 0)]);
/*   63 */         bounds[xmax] = Math.max(bounds[xmax], mesh.Verts[(v + 0)]);
/*   64 */         bounds[ymin] = Math.min(bounds[ymin], mesh.Verts[(v + 2)]);
/*   65 */         bounds[ymax] = Math.max(bounds[ymax], mesh.Verts[(v + 2)]);
/*   66 */         nPolyVerts++;
/*      */       }
/*   68 */       bounds[xmin] = Math.max(0, bounds[xmin] - 1);
/*   69 */       bounds[xmax] = Math.min(chf.Width, bounds[xmax] + 1);
/*   70 */       bounds[ymin] = Math.max(0, bounds[ymin] - 1);
/*   71 */       bounds[ymax] = Math.min(chf.Height, bounds[ymax] + 1);
/*   72 */       if ((bounds[xmin] < bounds[xmax]) && (bounds[ymin] < bounds[ymax])) {
/*   73 */         maxhw = Math.max(maxhw, bounds[xmax] - bounds[xmin]);
/*   74 */         maxhh = Math.max(maxhh, bounds[ymax] - bounds[ymin]);
/*      */       }
/*      */     }
/*   77 */     hp.Data = new int[maxhw * maxhh];
/*      */ 
/*   79 */     this.NMeshes = mesh.NPolys;
/*      */ 
/*   82 */     this.Meshes = new long[this.NMeshes * 4];
/*      */ 
/*   84 */     int vcap = nPolyVerts + nPolyVerts / 2;
/*   85 */     int tcap = vcap * 2;
/*      */ 
/*   87 */     this.NVerts = 0;
/*   88 */     this.Verts = new float[vcap * 3];
/*   89 */     this.NTris = 0;
/*   90 */     this.Tris = new short[tcap * 4];
/*      */ 
/*   92 */     for (int i = 0; i < mesh.NPolys; i++)
/*      */     {
/*   94 */       int p = i * nvp * 2;
/*   95 */       int npoly = 0;
/*   96 */       for (int j = 0; j < nvp; j++)
/*      */       {
/*   98 */         if (mesh.Polys[(p + j)] == PolyMesh.MeshNullIdx) break;
/*   99 */         int v = mesh.Polys[(p + j)] * 3;
/*  100 */         poly[(j * 3 + 0)] = (mesh.Verts[(v + 0)] * cs);
/*  101 */         poly[(j * 3 + 1)] = (mesh.Verts[(v + 1)] * ch);
/*  102 */         poly[(j * 3 + 2)] = (mesh.Verts[(v + 2)] * cs);
/*  103 */         npoly++;
/*      */       }
/*      */ 
/*  106 */       hp.XMin = bounds[(i * 4 + 0)];
/*  107 */       hp.YMin = bounds[(i * 4 + 2)];
/*  108 */       hp.Width = (bounds[(i * 4 + 1)] - bounds[(i * 4 + 0)]);
/*  109 */       hp.Height = (bounds[(i * 4 + 3)] - bounds[(i * 4 + 2)]);
/*      */ 
/*  111 */       int[] tempPoly = new int[nvp];
/*  112 */       System.arraycopy(mesh.Polys, p, tempPoly, 0, nvp);
/*      */ 
/*  114 */       GetHeightData(chf, tempPoly, npoly, mesh.Verts, borderSize, hp, stack);
/*      */ 
/*  116 */       DetourNumericReturn polyDetail = BuildPolyDetail(poly, npoly, sampleDist, sampleMaxError, chf, hp, verts, tris, edges, samples);
/*  117 */       if (!polyDetail.boolValue.booleanValue())
/*      */       {
/*  119 */         return;
/*      */       }
/*  121 */       int nverts = polyDetail.intValue;
/*      */ 
/*  123 */       for (int j = 0; j < nverts; j++)
/*      */       {
/*  125 */         verts[(j * 3 + 0)] += orig[0];
/*  126 */         verts[(j * 3 + 1)] += orig[1] + chf.Ch;
/*  127 */         verts[(j * 3 + 2)] += orig[2];
/*      */       }
/*  129 */       for (int j = 0; j < npoly; j++)
/*      */       {
/*  131 */         poly[(j * 3 + 0)] += orig[0];
/*  132 */         poly[(j * 3 + 1)] += orig[1];
/*  133 */         poly[(j * 3 + 2)] += orig[2];
/*      */       }
/*      */ 
/*  136 */       int ntris = tris.Size / 4;
/*      */ 
/*  138 */       this.Meshes[(i * 4 + 0)] = this.NVerts;
/*  139 */       this.Meshes[(i * 4 + 1)] = nverts;
/*  140 */       this.Meshes[(i * 4 + 2)] = this.NTris;
/*  141 */       this.Meshes[(i * 4 + 3)] = ntris;
/*      */ 
/*  143 */       if (this.NVerts + nverts > vcap)
/*      */       {
/*  145 */         while (this.NVerts + nverts > vcap) {
/*  146 */           vcap += 256;
/*      */         }
/*  148 */         float[] newv = new float[vcap * 3];
/*  149 */         if (this.NVerts > 0) {
/*  150 */           System.arraycopy(this.Verts, 0, newv, 0, 3 * this.NVerts);
/*      */         }
/*  152 */         this.Verts = newv;
/*      */       }
/*      */ 
/*  155 */       for (int j = 0; j < nverts; j++)
/*      */       {
/*  157 */         this.Verts[(this.NVerts * 3 + 0)] = verts[(j * 3 + 0)];
/*  158 */         this.Verts[(this.NVerts * 3 + 1)] = verts[(j * 3 + 1)];
/*  159 */         this.Verts[(this.NVerts * 3 + 2)] = verts[(j * 3 + 2)];
/*  160 */         this.NVerts += 1;
/*      */       }
/*      */ 
/*  163 */       if (this.NTris + ntris > tcap)
/*      */       {
/*  165 */         while (this.NTris + ntris > tcap)
/*  166 */           tcap += 256;
/*  167 */         short[] newt = new short[tcap * 4];
/*  168 */         if (this.NTris > 0) {
/*  169 */           System.arraycopy(this.Tris, 0, newt, 0, 4 * this.NTris);
/*      */         }
/*  171 */         this.Tris = newt;
/*      */       }
/*  173 */       for (int j = 0; j < ntris; j++)
/*      */       {
/*  175 */         int t = j * 4;
/*  176 */         this.Tris[(this.NTris * 4 + 0)] = (short)tris.get(t + 0);
/*  177 */         this.Tris[(this.NTris * 4 + 1)] = (short)tris.get(t + 1);
/*  178 */         this.Tris[(this.NTris * 4 + 2)] = (short)tris.get(t + 2);
/*  179 */         this.Tris[(this.NTris * 4 + 3)] = GetTriFlags(verts, tris.get(t + 0) * 3, verts, tris.get(t + 1) * 3, verts, tris.get(t + 2) * 3, poly, npoly);
/*  180 */         this.NTris += 1;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void GetHeightData(CompactHeightfield chf, int[] p, int npoly, int[] verts, int bs, HeightPatch hp, IntArray stack)
/*      */   {
/*  187 */     for (int i = 0; i < hp.Width * hp.Height; i++)
/*      */     {
/*  189 */       hp.Data[i] = 0;
/*      */     }
/*      */ 
/*  192 */     stack.Resize(0);
/*      */ 
/*  194 */     int[] offset = { 0, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1, 0, 1, -1, 1, -1, 0 };
/*      */ 
/*  196 */     for (int j = 0; j < npoly; j++)
/*      */     {
/*  198 */       int cx = 0; int cz = 0; int ci = -1;
/*      */ 
/*  200 */       int dmin = UnsetHeight;
/*  201 */       for (int k = 0; k < 9; k++)
/*      */       {
/*  203 */         int ax = verts[(p[j] * 3 + 0)] + offset[(k * 2 + 0)];
/*  204 */         int ay = verts[(p[j] * 3 + 1)];
/*  205 */         int az = verts[(p[j] * 3 + 2)] + offset[(k * 2 + 1)];
/*  206 */         if ((ax < hp.XMin) || (ax >= hp.XMin + hp.Width) || (az < hp.YMin) || (az >= hp.YMin + hp.Height)) {
/*      */           continue;
/*      */         }
/*  209 */         CompactCell c = chf.Cells[(ax + bs + (az + bs) * chf.Width)];
/*  210 */         int i = (int)c.Index; for (int ni = (int)(c.Index + c.Count); i < ni; i++)
/*      */         {
/*  212 */           CompactSpan s = chf.Spans[i];
/*  213 */           int d = Math.abs(ay - s.Y);
/*  214 */           if (d >= dmin)
/*      */             continue;
/*  216 */           cx = ax;
/*  217 */           cz = az;
/*  218 */           ci = i;
/*  219 */           dmin = d;
/*      */         }
/*      */       }
/*      */ 
/*  223 */       if (ci == -1)
/*      */         continue;
/*  225 */       stack.Push(cx);
/*  226 */       stack.Push(cz);
/*  227 */       stack.Push(ci);
/*      */     }
/*      */ 
/*  231 */     int pcx = 0; int pcz = 0;
/*  232 */     for (int j = 0; j < npoly; j++)
/*      */     {
/*  234 */       pcx += verts[(p[j] * 3 + 0)];
/*  235 */       pcz += verts[(p[j] * 3 + 2)];
/*      */     }
/*  237 */     pcx /= npoly;
/*  238 */     pcz /= npoly;
/*      */ 
/*  240 */     for (int i = 0; i < stack.Size; i += 3)
/*      */     {
/*  242 */       int cx = stack.get(i + 0);
/*  243 */       int cy = stack.get(i + 1);
/*  244 */       int idx = cx - hp.XMin + (cy - hp.YMin) * hp.Width;
/*  245 */       hp.Data[idx] = 1;
/*      */     }
/*      */ 
/*  248 */     while (stack.Size > 0)
/*      */     {
/*  250 */       int ci = stack.Pop();
/*  251 */       int cy = stack.Pop();
/*  252 */       int cx = stack.Pop();
/*      */ 
/*  254 */       if ((Math.abs(cx - pcx) <= 1) && (Math.abs(cy - pcz) <= 1))
/*      */       {
/*  256 */         stack.Resize(0);
/*  257 */         stack.Push(cx);
/*  258 */         stack.Push(cy);
/*  259 */         stack.Push(ci);
/*  260 */         break;
/*      */       }
/*      */ 
/*  263 */       CompactSpan cs = chf.Spans[ci];
/*      */ 
/*  265 */       for (int dir = 0; dir < 4; dir++)
/*      */       {
/*  267 */         if (cs.GetCon(dir) == CompactHeightfield.NotConnected)
/*      */           continue;
/*  269 */         int ax = cx + Helper.GetDirOffsetX(dir);
/*  270 */         int ay = cy + Helper.GetDirOffsetY(dir);
/*      */ 
/*  272 */         if ((ax < hp.XMin) || (ax >= hp.XMin + hp.Width) || (ay < hp.YMin) || (ay >= hp.YMin + hp.Height))
/*      */         {
/*      */           continue;
/*      */         }
/*  276 */         if (hp.Data[(ax - hp.XMin + (ay - hp.YMin) * hp.Width)] != 0) {
/*      */           continue;
/*      */         }
/*  279 */         int ai = (int)chf.Cells[(ax + bs + (ay + bs) * chf.Width)].Index + cs.GetCon(dir);
/*      */ 
/*  281 */         int idx = ax - hp.XMin + (ay - hp.YMin) * hp.Width;
/*  282 */         hp.Data[idx] = 1;
/*      */ 
/*  284 */         stack.Push(ax);
/*  285 */         stack.Push(ay);
/*  286 */         stack.Push(ai);
/*      */       }
/*      */     }
/*      */ 
/*  290 */     for (int i = 0; i < hp.Data.length; i++)
/*      */     {
/*  292 */       hp.Data[i] = UnsetHeight;
/*      */     }
/*      */ 
/*  295 */     for (int i = 0; i < stack.Size; i += 3)
/*      */     {
/*  297 */       int cx = stack.get(i + 0);
/*  298 */       int cy = stack.get(i + 1);
/*  299 */       int ci = stack.get(i + 2);
/*  300 */       int idx = cx - hp.XMin + (cy - hp.YMin) * hp.Width;
/*  301 */       CompactSpan cs = chf.Spans[ci];
/*  302 */       hp.Data[idx] = cs.Y;
/*      */     }
/*      */ 
/*  305 */     int RetractSize = 256;
/*  306 */     int head = 0;
/*      */ 
/*  308 */     while (head * 3 < stack.Size)
/*      */     {
/*  310 */       int cx = stack.get(head * 3 + 0);
/*  311 */       int cy = stack.get(head * 3 + 1);
/*  312 */       int ci = stack.get(head * 3 + 2);
/*  313 */       head++;
/*  314 */       if (head >= RetractSize)
/*      */       {
/*  316 */         head = 0;
/*  317 */         if (stack.Size > RetractSize * 3)
/*      */         {
/*  319 */           System.arraycopy(stack.Data, RetractSize * 3, stack.Data, 0, stack.Size - RetractSize * 3);
/*      */         }
/*  321 */         stack.Resize(stack.Size - RetractSize * 3);
/*      */       }
/*      */ 
/*  324 */       CompactSpan cs = chf.Spans[ci];
/*  325 */       for (int dir = 0; dir < 4; dir++)
/*      */       {
/*  327 */         if (cs.GetCon(dir) == CompactHeightfield.NotConnected)
/*      */           continue;
/*  329 */         int ax = cx + Helper.GetDirOffsetX(dir);
/*  330 */         int ay = cy + Helper.GetDirOffsetY(dir);
/*      */ 
/*  332 */         if ((ax < hp.XMin) || (ax >= hp.XMin + hp.Width) || (ay < hp.YMin) || (ay >= hp.YMin + hp.Height))
/*      */         {
/*      */           continue;
/*      */         }
/*  336 */         if (hp.Data[(ax - hp.XMin + (ay - hp.YMin) * hp.Width)] != UnsetHeight) {
/*      */           continue;
/*      */         }
/*  339 */         int ai = (int)chf.Cells[(ax + bs + (ay + bs) * chf.Width)].Index + cs.GetCon(dir);
/*      */ 
/*  341 */         CompactSpan aspan = chf.Spans[ai];
/*  342 */         int idx = ax - hp.XMin + (ay - hp.YMin) * hp.Width;
/*  343 */         hp.Data[idx] = aspan.Y;
/*      */ 
/*  345 */         stack.Push(ax);
/*  346 */         stack.Push(ay);
/*  347 */         stack.Push(ai);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private DetourNumericReturn BuildPolyDetail(float[] inArray, int nin, float sampleDist, float sampleMaxError, CompactHeightfield chf, HeightPatch hp, float[] verts, IntArray tris, IntArray edges, IntArray samples)
/*      */   {
/*  354 */     DetourNumericReturn numericReturn = new DetourNumericReturn();
/*      */ 
/*  356 */     int MaxVerts = 127;
/*  357 */     int MaxTris = 255;
/*  358 */     int MaxVertsPerEdge = 32;
/*  359 */     float[] edge = new float[(MaxVertsPerEdge + 1) * 3];
/*  360 */     int[] hull = new int[MaxVerts];
/*  361 */     int nhull = 0;
/*      */ 
/*  363 */     for (int i = 0; i < nin; i++)
/*      */     {
/*  365 */       System.arraycopy(inArray, i * 3, verts, i * 3, 3);
/*      */     }
/*      */ 
/*  368 */     numericReturn.intValue = nin;
/*      */ 
/*  370 */     float cs = chf.Cs;
/*  371 */     float ics = 1.0F / cs;
/*      */ 
/*  373 */     if (sampleDist > 0.0F)
/*      */     {
/*  375 */       int i = 0; for (int j = nin - 1; i < nin; j = i++)
/*      */       {
/*  377 */         int vj = j * 3;
/*  378 */         int vi = i * 3;
/*      */ 
/*  380 */         Boolean swapped = Boolean.valueOf(false);
/*  381 */         if (Math.abs(inArray[(vj + 0)] - inArray[(vi + 0)]) < 1.0E-006F)
/*      */         {
/*  383 */           if (inArray[(vj + 2)] > inArray[(vi + 2)])
/*      */           {
/*  385 */             int temp = vj;
/*  386 */             vj = vi;
/*  387 */             vi = temp;
/*  388 */             swapped = Boolean.valueOf(true);
/*      */           }
/*      */ 
/*      */         }
/*  393 */         else if (inArray[(vj + 0)] > inArray[(vi + 0)])
/*      */         {
/*  395 */           int temp = vj;
/*  396 */           vj = vi;
/*  397 */           vi = temp;
/*  398 */           swapped = Boolean.valueOf(true);
/*      */         }
/*      */ 
/*  402 */         float dx = inArray[(vi + 0)] - inArray[(vj + 0)];
/*  403 */         float dy = inArray[(vi + 1)] - inArray[(vj + 1)];
/*  404 */         float dz = inArray[(vi + 2)] - inArray[(vj + 2)];
/*  405 */         float d = (float)Math.sqrt(dx * dx + dz * dz);
/*  406 */         int nn = 1 + (int)Math.floor(d / sampleDist);
/*  407 */         if (nn >= MaxVertsPerEdge) nn = MaxVertsPerEdge - 1;
/*  408 */         if (numericReturn.intValue + nn >= MaxVerts) {
/*  409 */           nn = MaxVerts - 1 - numericReturn.intValue;
/*      */         }
/*  411 */         for (int k = 0; k <= nn; k++)
/*      */         {
/*  413 */           float u = k / nn;
/*  414 */           int pos = k * 3;
/*  415 */           inArray[(vj + 0)] += dx * u;
/*  416 */           inArray[(vj + 1)] += dy * u;
/*  417 */           inArray[(vj + 2)] += dz * u;
/*  418 */           edge[(pos + 1)] = (GetHeight(edge[(pos + 0)], edge[(pos + 1)], edge[(pos + 2)], cs, ics, chf.Ch, hp) * chf.Ch);
/*      */         }
/*      */ 
/*  421 */         int[] idx = new int[MaxVertsPerEdge];
/*  422 */         idx[0] = 0; idx[1] = nn;
/*  423 */         int nidx = 2;
/*  424 */         for (int k = 0; k < nidx - 1; )
/*      */         {
/*  426 */           int a = idx[k];
/*  427 */           int b = idx[(k + 1)];
/*  428 */           int va = a * 3;
/*  429 */           int vb = b * 3;
/*      */ 
/*  431 */           float maxd = 0.0F;
/*  432 */           int maxi = -1;
/*  433 */           for (int m = a + 1; m < b; m++)
/*      */           {
/*  435 */             float dev = DistancePtSeg(edge[(m * 3 + 0)], edge[(m * 3 + 1)], edge[(m * 3 + 2)], edge[(va + 0)], edge[(va + 1)], edge[(va + 2)], edge[(vb + 0)], edge[(vb + 1)], edge[(vb + 2)]);
/*  436 */             if (dev <= maxd)
/*      */               continue;
/*  438 */             maxd = dev;
/*  439 */             maxi = m;
/*      */           }
/*      */ 
/*  443 */           if ((maxi != -1) && (maxd > sampleMaxError * sampleMaxError))
/*      */           {
/*  445 */             for (int m = nidx; m > k; m--)
/*      */             {
/*  447 */               idx[m] = idx[(m - 1)];
/*      */             }
/*  449 */             idx[(k + 1)] = maxi;
/*  450 */             nidx++;
/*      */           }
/*      */           else
/*      */           {
/*  454 */             k++;
/*      */           }
/*      */         }
/*      */ 
/*  458 */         hull[(nhull++)] = j;
/*  459 */         if (swapped.booleanValue())
/*      */         {
/*  461 */           for (int k = nidx - 2; k > 0; k--)
/*      */           {
/*  463 */             System.arraycopy(edge, idx[k] * 3, verts, numericReturn.intValue * 3, 3);
/*  464 */             hull[(nhull++)] = numericReturn.intValue;
/*  465 */             numericReturn.intValue += 1;
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  470 */           for (int k = 1; k < nidx - 1; k++)
/*      */           {
/*  472 */             System.arraycopy(edge, idx[k] * 3, verts, numericReturn.intValue * 3, 3);
/*  473 */             hull[(nhull++)] = numericReturn.intValue;
/*  474 */             numericReturn.intValue += 1;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  480 */     edges.Resize(0);
/*  481 */     tris.Resize(0);
/*      */ 
/*  483 */     DelaunayHull(numericReturn.intValue, verts, nhull, hull, tris, edges);
/*      */ 
/*  485 */     if (tris.Size == 0)
/*      */     {
/*  488 */       for (int i = 2; i < numericReturn.intValue; i++)
/*      */       {
/*  490 */         tris.Push(0);
/*  491 */         tris.Push(i - 1);
/*  492 */         tris.Push(i);
/*  493 */         tris.Push(0);
/*      */       }
/*  495 */       numericReturn.boolValue = Boolean.valueOf(true);
/*  496 */       return numericReturn;
/*      */     }
/*      */ 
/*  499 */     if (sampleDist > 0.0F)
/*      */     {
/*  501 */       float[] bmin = new float[3]; float[] bmax = new float[3];
/*  502 */       System.arraycopy(inArray, 0, bmin, 0, 3);
/*  503 */       System.arraycopy(inArray, 0, bmax, 0, 3);
/*      */ 
/*  505 */       for (int i = 1; i < nin; i++)
/*      */       {
/*  507 */         bmin[0] = Math.min(bmin[0], inArray[(i * 3 + 0)]);
/*  508 */         bmin[1] = Math.min(bmin[1], inArray[(i * 3 + 1)]);
/*  509 */         bmin[2] = Math.min(bmin[2], inArray[(i * 3 + 2)]);
/*  510 */         bmax[0] = Math.max(bmax[0], inArray[(i * 3 + 0)]);
/*  511 */         bmax[1] = Math.max(bmax[1], inArray[(i * 3 + 1)]);
/*  512 */         bmax[2] = Math.max(bmax[2], inArray[(i * 3 + 2)]);
/*      */       }
/*      */ 
/*  515 */       int x0 = (int)Math.floor(bmin[0] / sampleDist);
/*  516 */       int x1 = (int)Math.ceil(bmax[0] / sampleDist);
/*  517 */       int z0 = (int)Math.floor(bmin[2] / sampleDist);
/*  518 */       int z1 = (int)Math.ceil(bmax[2] / sampleDist);
/*  519 */       samples.Resize(0);
/*  520 */       for (int z = z0; z < z1; z++)
/*      */       {
/*  522 */         for (int x = x0; x < x1; x++)
/*      */         {
/*  524 */           float[] pt = new float[3];
/*  525 */           pt[0] = (x * sampleDist);
/*  526 */           pt[1] = ((bmax[1] + bmin[1]) * 0.5F);
/*  527 */           pt[2] = (z * sampleDist);
/*      */ 
/*  529 */           if (DistToPoly(nin, inArray, pt[0], pt[1], pt[2]) <= -sampleDist / 2.0F) {
/*  530 */             samples.Push(x);
/*  531 */             samples.Push(GetHeight(pt[0], pt[1], pt[2], cs, ics, chf.Ch, hp));
/*  532 */             samples.Push(z);
/*  533 */             samples.Push(0);
/*      */           }
/*      */         }
/*      */       }
/*  537 */       int nsamples = samples.Size / 4;
/*  538 */       for (int iter = 0; iter < nsamples; iter++)
/*      */       {
/*  540 */         if (numericReturn.intValue >= MaxVerts) {
/*      */           break;
/*      */         }
/*  543 */         float[] bestpt = { 0.0F, 0.0F, 0.0F };
/*  544 */         float bestd = 0.0F;
/*  545 */         int besti = -1;
/*  546 */         for (int i = 0; i < nsamples; i++)
/*      */         {
/*  548 */           int s = i * 4;
/*  549 */           if (samples.get(s + 3) == 0) {
/*  550 */             float[] pt = new float[3];
/*      */ 
/*  552 */             pt[0] = (samples.get(s + 0) * sampleDist + GetJitterX(i) * cs * 0.1F);
/*  553 */             pt[1] = (samples.get(s + 1) * chf.Ch);
/*  554 */             pt[2] = (samples.get(s + 2) * sampleDist + GetJitterY(i) * cs * 0.1F);
/*  555 */             float d = DistToTriMesh(pt[0], pt[1], pt[2], verts, numericReturn.intValue, tris, tris.Size / 4);
/*  556 */             if ((d < 0.0F) || 
/*  557 */               (d <= bestd))
/*      */               continue;
/*  559 */             bestd = d;
/*  560 */             besti = i;
/*  561 */             System.arraycopy(pt, 0, bestpt, 0, 3);
/*      */           }
/*      */         }
/*  564 */         if ((bestd <= sampleMaxError) || (besti == -1))
/*      */           break;
/*  566 */         samples.set(besti * 4 + 3, 1);
/*  567 */         System.arraycopy(bestpt, 0, verts, numericReturn.intValue * 3, 3);
/*  568 */         numericReturn.intValue += 1;
/*      */ 
/*  570 */         edges.Resize(0);
/*  571 */         tris.Resize(0);
/*  572 */         DelaunayHull(numericReturn.intValue, verts, nhull, hull, tris, edges);
/*      */       }
/*      */     }
/*      */ 
/*  576 */     int ntris = tris.Size / 4;
/*  577 */     if (ntris > MaxTris)
/*      */     {
/*  580 */       tris.Resize(MaxTris * 4);
/*      */     }
/*  582 */     numericReturn.boolValue = Boolean.valueOf(true);
/*  583 */     return numericReturn;
/*      */   }
/*      */ 
/*      */   private void DelaunayHull(int npts, float[] pts, int nhull, int[] hull, IntArray tris, IntArray edges)
/*      */   {
/*  588 */     int maxEdges = npts * 10;
/*  589 */     edges.Resize(maxEdges * 4);
/*      */ 
/*  591 */     IntVector2 nEdgesFaces = new IntVector2(0, 0);
/*      */ 
/*  593 */     int i = 0; for (int j = nhull - 1; i < nhull; j = i++)
/*      */     {
/*  595 */       AddEdge(edges, nEdgesFaces, maxEdges, hull[j], hull[i], Hull, Undef);
/*      */     }
/*      */ 
/*  598 */     int currentEdge = 0;
/*  599 */     while (currentEdge < nEdgesFaces.x)
/*      */     {
/*  601 */       if (edges.get(currentEdge * 4 + 2) == Undef)
/*  602 */         CompleteFacet(pts, npts, edges, nEdgesFaces, maxEdges, currentEdge);
/*  603 */       if (edges.get(currentEdge * 4 + 3) == Undef)
/*  604 */         CompleteFacet(pts, npts, edges, nEdgesFaces, maxEdges, currentEdge);
/*  605 */       currentEdge++;
/*      */     }
/*      */ 
/*  608 */     tris.Resize(nEdgesFaces.y * 4);
/*  609 */     for (int i = 0; i < nEdgesFaces.y * 4; i++)
/*      */     {
/*  611 */       tris.set(i, -1);
/*      */     }
/*      */ 
/*  614 */     for (int i = 0; i < nEdgesFaces.x; i++)
/*      */     {
/*  616 */       int e = i * 4;
/*  617 */       if (edges.get(e + 3) >= 0)
/*      */       {
/*  619 */         int t = edges.get(e + 3) * 4;
/*  620 */         if (tris.get(t + 0) == -1)
/*      */         {
/*  622 */           tris.set(t + 0, edges.get(e + 0));
/*  623 */           tris.set(t + 1, edges.get(e + 1));
/*      */         }
/*  625 */         else if (tris.get(t + 0) == edges.get(e + 1))
/*      */         {
/*  627 */           tris.set(t + 2, edges.get(e + 0));
/*      */         }
/*  629 */         else if (tris.get(t + 1) == edges.get(e + 0))
/*      */         {
/*  631 */           tris.set(t + 2, edges.get(e + 1));
/*      */         }
/*      */       }
/*  634 */       if (edges.get(e + 2) < 0)
/*      */         continue;
/*  636 */       int t = edges.get(e + 2) * 4;
/*  637 */       if (tris.get(t + 0) == -1)
/*      */       {
/*  639 */         tris.set(t + 0, edges.get(e + 1));
/*  640 */         tris.set(t + 1, edges.get(e + 0));
/*      */       }
/*  642 */       else if (tris.get(t + 0) == edges.get(e + 0))
/*      */       {
/*  644 */         tris.set(t + 2, edges.get(e + 1));
/*      */       } else {
/*  646 */         if (tris.get(t + 1) != edges.get(e + 1))
/*      */           continue;
/*  648 */         tris.set(t + 2, edges.get(e + 0));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  653 */     for (int i = 0; i < tris.Size / 4; i++)
/*      */     {
/*  655 */       int t = i * 4;
/*  656 */       if ((tris.get(t + 0) != -1) && (tris.get(t + 1) != -1) && (tris.get(t + 2) != -1)) {
/*      */         continue;
/*      */       }
/*  659 */       tris.set(t + 0, tris.get(tris.Size - 4));
/*  660 */       tris.set(t + 1, tris.get(tris.Size - 3));
/*  661 */       tris.set(t + 2, tris.get(tris.Size - 2));
/*  662 */       tris.set(t + 3, tris.get(tris.Size - 1));
/*  663 */       tris.Resize(tris.Size - 4);
/*  664 */       i--;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void CompleteFacet(float[] pts, int npts, IntArray edges, IntVector2 nEdgesFaces, int maxEdges, int e)
/*      */   {
/*  671 */     float EPS = 1.0E-005F;
/*      */ 
/*  673 */     int edge = e * 4;
/*      */ 
/*  675 */     int s = 0; int t = 0;
/*  676 */     if (edges.get(edge + 2) == Undef)
/*      */     {
/*  678 */       s = edges.get(edge + 0);
/*  679 */       t = edges.get(edge + 1);
/*      */     }
/*  681 */     else if (edges.get(edge + 3) == Undef)
/*      */     {
/*  683 */       s = edges.get(edge + 1);
/*  684 */       t = edges.get(edge + 0);
/*      */     }
/*      */     else
/*      */     {
/*  688 */       return;
/*      */     }
/*      */ 
/*  691 */     int pt = npts;
/*  692 */     float[] c = { 0.0F, 0.0F, 0.0F };
/*  693 */     float r = -1.0F;
/*  694 */     for (int u = 0; u < npts; u++)
/*      */     {
/*  696 */       if ((u == s) || (u == t))
/*      */         continue;
/*  698 */       if (VCross2(pts[(s * 3 + 0)], pts[(s * 3 + 1)], pts[(s * 3 + 2)], pts[(t * 3 + 0)], pts[(t * 3 + 1)], pts[(t * 3 + 2)], pts[(u * 3 + 0)], pts[(u * 3 + 1)], pts[(u * 3 + 2)]) <= EPS)
/*      */         continue;
/*  700 */       if (r < 0.0F)
/*      */       {
/*  702 */         pt = u;
/*  703 */         r = CircumCircle(pts[(s * 3 + 0)], pts[(s * 3 + 1)], pts[(s * 3 + 2)], pts[(t * 3 + 0)], pts[(t * 3 + 1)], pts[(t * 3 + 2)], pts[(u * 3 + 0)], pts[(u * 3 + 1)], pts[(u * 3 + 2)], c, r).floatValue;
/*      */       }
/*      */       else
/*      */       {
/*  707 */         float d = VDist2(c[0], c[1], c[2], pts[(u * 3 + 0)], pts[(u * 3 + 1)], pts[(u * 3 + 2)]);
/*  708 */         float tol = 0.001F;
/*  709 */         if (d > r * (1.0F + tol))
/*      */         {
/*      */           continue;
/*      */         }
/*  713 */         if (d < r * (1.0F - tol))
/*      */         {
/*  715 */           pt = u;
/*  716 */           r = CircumCircle(pts[(s * 3 + 0)], pts[(s * 3 + 1)], pts[(s * 3 + 2)], pts[(t * 3 + 0)], pts[(t * 3 + 1)], pts[(t * 3 + 2)], pts[(u * 3 + 0)], pts[(u * 3 + 1)], pts[(u * 3 + 2)], c, r).floatValue;
/*      */         }
/*      */         else
/*      */         {
/*  721 */           if (OverlapEdges(pts, edges, nEdgesFaces.x, s, u).booleanValue())
/*      */             continue;
/*  723 */           if (OverlapEdges(pts, edges, nEdgesFaces.x, t, u).booleanValue()) {
/*      */             continue;
/*      */           }
/*  726 */           pt = u;
/*  727 */           r = CircumCircle(pts[(s * 3 + 0)], pts[(s * 3 + 1)], pts[(s * 3 + 2)], pts[(t * 3 + 0)], pts[(t * 3 + 1)], pts[(t * 3 + 2)], pts[(u * 3 + 0)], pts[(u * 3 + 1)], pts[(u * 3 + 2)], c, r).floatValue;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  733 */     if (pt < npts)
/*      */     {
/*  735 */       UpdateLeftFace(edges, e * 4, s, t, nEdgesFaces.y);
/*      */ 
/*  737 */       e = FindEdge(edges, nEdgesFaces.x, pt, s);
/*  738 */       if (e == Undef)
/*      */       {
/*  740 */         AddEdge(edges, nEdgesFaces, maxEdges, pt, s, nEdgesFaces.y, Undef);
/*      */       }
/*      */       else
/*      */       {
/*  744 */         UpdateLeftFace(edges, e * 4, pt, s, nEdgesFaces.y);
/*      */       }
/*      */ 
/*  747 */       e = FindEdge(edges, nEdgesFaces.x, t, pt);
/*  748 */       if (e == Undef)
/*      */       {
/*  750 */         AddEdge(edges, nEdgesFaces, maxEdges, t, pt, nEdgesFaces.y, Undef);
/*      */       }
/*      */       else
/*      */       {
/*  754 */         UpdateLeftFace(edges, e * 4, t, pt, nEdgesFaces.y);
/*      */       }
/*      */ 
/*  757 */       nEdgesFaces.y += 1;
/*      */     }
/*      */     else
/*      */     {
/*  761 */       UpdateLeftFace(edges, e * 4, s, t, Hull);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Boolean OverlapEdges(float[] pts, IntArray edges, int nedges, int s1, int t1)
/*      */   {
/*  767 */     for (int i = 0; i < nedges; i++)
/*      */     {
/*  769 */       int s0 = i * 4 + 0;
/*  770 */       int t0 = i * 4 + 1;
/*      */ 
/*  772 */       if ((edges.get(s0) == s1) || (edges.get(s0) == t1) || (edges.get(t0) == s1) || (edges.get(t0) == t1))
/*      */         continue;
/*  774 */       if (OverlapSegSeg2d(pts[(edges.get(s0) * 3 + 0)], pts[(edges.get(s0) * 3 + 1)], pts[(edges.get(s0) * 3 + 2)], pts[(edges.get(t0) * 3 + 0)], pts[(edges.get(t0) * 3 + 1)], pts[(edges.get(t0) * 3 + 2)], pts[(s1 * 3 + 0)], pts[(s1 * 3 + 1)], pts[(s1 * 3 + 1)], pts[(t1 * 3 + 0)], pts[(t1 * 3 + 1)], pts[(t1 * 3 + 1)]).booleanValue())
/*      */       {
/*  778 */         return Boolean.valueOf(true);
/*      */       }
/*      */     }
/*  780 */     return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   private Boolean OverlapSegSeg2d(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float dx, float dy, float dz)
/*      */   {
/*  785 */     float a1 = VCross2(ax, ay, az, bx, by, bz, dx, dy, dz);
/*  786 */     float a2 = VCross2(ax, ay, az, bx, by, bz, cx, cy, cz);
/*  787 */     if (a1 * a2 < 0.0F)
/*      */     {
/*  789 */       float a3 = VCross2(cx, cy, cz, dx, dy, dz, ax, ay, az);
/*  790 */       float a4 = a3 + a2 - a1;
/*  791 */       if (a3 * a4 < 0.0F)
/*  792 */         return Boolean.valueOf(true);
/*      */     }
/*  794 */     return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   private DetourNumericReturn CircumCircle(float p1x, float p1y, float p1z, float p2x, float p2y, float p2z, float p3x, float p3y, float p3z, float[] c, float r)
/*      */   {
/*  799 */     DetourNumericReturn numericReturn = new DetourNumericReturn();
/*  800 */     float EPS = 1.0E-006F;
/*      */ 
/*  802 */     float cp = VCross2(p1x, p1y, p1z, p2x, p2y, p2z, p3x, p3y, p3z);
/*  803 */     if (Math.abs(cp) > EPS)
/*      */     {
/*  805 */       float p1Sq = Dot(p1x, p1y, p1z, p1x, p1y, p1z);
/*  806 */       float p2Sq = Dot(p2x, p2y, p2z, p2x, p2y, p2z);
/*  807 */       float p3Sq = Dot(p3x, p3y, p3z, p3x, p3y, p3z);
/*  808 */       c[0] = ((p1Sq * (p2z - p3z) + p2Sq * (p3z - p1z) + p3Sq * (p1z - p2z)) / (2.0F * cp));
/*  809 */       c[2] = ((p1Sq * (p3x - p2x) + p2Sq * (p1x - p3x) + p3Sq * (p2x - p1x)) / (2.0F * cp));
/*  810 */       numericReturn.floatValue = VDist2(c[0], c[1], c[2], p1x, p1y, p1z);
/*  811 */       numericReturn.boolValue = Boolean.valueOf(true);
/*  812 */       return numericReturn;
/*      */     }
/*      */ 
/*  815 */     c[0] = p1x;
/*  816 */     c[2] = p1z;
/*  817 */     numericReturn.floatValue = 0.0F;
/*  818 */     numericReturn.boolValue = Boolean.valueOf(false);
/*  819 */     return numericReturn;
/*      */   }
/*      */ 
/*      */   private float VDist2(float px, float py, float pz, float qx, float qy, float qz)
/*      */   {
/*  824 */     return (float)Math.sqrt(VDistSq2(px, py, pz, qx, qy, qz));
/*      */   }
/*      */ 
/*      */   private float VDistSq2(float px, float py, float pz, float qx, float qy, float qz)
/*      */   {
/*  829 */     float dx = qx - px;
/*  830 */     float dy = qz - pz;
/*  831 */     return dx * dx + dy * dy;
/*      */   }
/*      */ 
/*      */   private float VCross2(float p1X, float p1Y, float p1Z, float p2X, float p2Y, float p2Z, float p3X, float p3Y, float p3Z)
/*      */   {
/*  836 */     float u1 = p2X - p1X;
/*  837 */     float v1 = p2Z - p1Z;
/*  838 */     float u2 = p3X - p1X;
/*  839 */     float v2 = p3Z - p1Z;
/*  840 */     return u1 * v2 - v1 * u2;
/*      */   }
/*      */ 
/*      */   private void UpdateLeftFace(IntArray edges, int e, int s, int t, int f)
/*      */   {
/*  845 */     if ((edges.get(e + 0) == s) && (edges.get(e + 1) == t) && (edges.get(e + 2) == Undef))
/*  846 */       edges.set(e + 2, f);
/*  847 */     else if ((edges.get(e + 1) == s) && (edges.get(e + 0) == t) && (edges.get(e + 3) == Undef))
/*  848 */       edges.set(e + 3, f);
/*      */   }
/*      */ 
/*      */   private int AddEdge(IntArray edges, IntVector2 nEdgesFaces, int maxEdges, int s, int t, int l, int r)
/*      */   {
/*  853 */     if (nEdgesFaces.x >= maxEdges)
/*      */     {
/*  856 */       return Undef;
/*      */     }
/*      */ 
/*  859 */     int e = FindEdge(edges, nEdgesFaces.x, s, t);
/*  860 */     if (e == Undef)
/*      */     {
/*  862 */       int edge = nEdgesFaces.x * 4;
/*  863 */       edges.set(edge + 0, s);
/*  864 */       edges.set(edge + 1, t);
/*  865 */       edges.set(edge + 2, l);
/*  866 */       edges.set(edge + 3, r);
/*  867 */       return nEdgesFaces.x++;
/*      */     }
/*  869 */     return Undef;
/*      */   }
/*      */ 
/*      */   private int FindEdge(IntArray edges, int nedges, int s, int t)
/*      */   {
/*  874 */     for (int i = 0; i < nedges; i++)
/*      */     {
/*  876 */       int e = i * 4;
/*  877 */       if (((edges.get(e + 0) == s) && (edges.get(e + 1) == t)) || ((edges.get(e + 0) == t) && (edges.get(e + 1) == s)))
/*  878 */         return i;
/*      */     }
/*  880 */     return Undef;
/*      */   }
/*      */ 
/*      */   private float DistancePtSeg(float ptx, float pty, float ptz, float px, float py, float pz, float qx, float qy, float qz)
/*      */   {
/*  885 */     float pqx = qx - px;
/*  886 */     float pqy = qy - py;
/*  887 */     float pqz = qz - pz;
/*  888 */     float dx = ptx - px;
/*  889 */     float dy = pty - py;
/*  890 */     float dz = ptz - pz;
/*  891 */     float d = pqx * pqx + pqy * pqy + pqz * pqz;
/*  892 */     float t = pqx * dx + pqy * dy + pqz * dz;
/*  893 */     if (d > 0.0F)
/*  894 */       t /= d;
/*  895 */     if (t < 0.0F)
/*  896 */       t = 0.0F;
/*  897 */     else if (t > 1.0F) {
/*  898 */       t = 1.0F;
/*      */     }
/*  900 */     dx = px + t * pqx - ptx;
/*  901 */     dy = py + t * pqy - pty;
/*  902 */     dz = pz + t * pqz - ptz;
/*      */ 
/*  904 */     return dx * dx + dy * dy + dz * dz;
/*      */   }
/*      */ 
/*      */   private float DistToPoly(int nvert, float[] verts, float px, float py, float pz)
/*      */   {
/*  909 */     float dmin = 3.4028235E+38F;
/*  910 */     int i = 0; int j = 0;
/*  911 */     Boolean c = Boolean.valueOf(false);
/*  912 */     i = 0; for (j = nvert - 1; i < nvert; j = i++)
/*      */     {
/*  914 */       int vi = i * 3;
/*  915 */       int vj = j * 3;
/*  916 */       if ((verts[(vi + 2)] > pz ? 1 : 0) != (verts[(vj + 2)] > pz ? 1 : 0)) if (px < (verts[(vj + 0)] - verts[(vi + 0)]) * (pz - verts[(vi + 2)]) / (verts[(vj + 2)] - verts[(vi + 2)]) + verts[(vi + 0)])
/*      */         {
/*  918 */           c = Boolean.valueOf(!c.booleanValue());
/*      */         } float[] pxpypz = { px, py, pz };
/*  920 */       dmin = Math.min(dmin, DistancePtSeg2d(pxpypz, 0, verts, vj, verts, vi));
/*      */     }
/*  922 */     return c.booleanValue() ? -dmin : dmin;
/*      */   }
/*      */ 
/*      */   private int GetHeight(float fx, float fy, float fz, float cs, float ics, float ch, HeightPatch hp)
/*      */   {
/*  927 */     int ix = (int)Math.floor(fx * ics + 0.01F);
/*  928 */     int iz = (int)Math.floor(fz * ics + 0.01F);
/*  929 */     ix = Math.max(0, Math.min(hp.Width, ix - hp.XMin));
/*  930 */     iz = Math.max(0, Math.min(hp.Height, iz - hp.YMin));
/*  931 */     int h = hp.Data[(ix + iz * hp.Width)];
/*  932 */     if (h == UnsetHeight)
/*      */     {
/*  934 */       int[] offset = { -1, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1, 0, 1, -1, 1 };
/*  935 */       float dmin = 3.4028235E+38F;
/*  936 */       for (int i = 0; i < 8; i++)
/*      */       {
/*  938 */         int nx = ix + offset[(i * 2 + 0)];
/*  939 */         int nz = iz + offset[(i * 2 + 1)];
/*  940 */         if ((nx >= 0) && (nz >= 0) && (nx < hp.Width) && (nz < hp.Height)) {
/*  941 */           int nh = hp.Data[(nx + nz * hp.Width)];
/*  942 */           if (nh == UnsetHeight)
/*      */             continue;
/*  944 */           float d = Math.abs(nh * ch - fy);
/*  945 */           if (d >= dmin)
/*      */             continue;
/*  947 */           h = nh;
/*  948 */           dmin = d;
/*      */         }
/*      */       }
/*      */     }
/*  952 */     return h;
/*      */   }
/*      */ 
/*      */   private float GetJitterX(int i)
/*      */   {
/*  957 */     return (i * -1918454973 & 0xFFFF) / 65535.0F * 2.0F - 1.0F;
/*      */   }
/*      */ 
/*      */   private float GetJitterY(int i)
/*      */   {
/*  962 */     return (i * -669632447 & 0xFFFF) / 65535.0F * 2.0F - 1.0F;
/*      */   }
/*      */ 
/*      */   private float DistToTriMesh(float px, float py, float pz, float[] verts, int nverts, IntArray tris, int ntris)
/*      */   {
/*  967 */     float dmin = 3.4028235E+38F;
/*  968 */     for (int i = 0; i < ntris; i++)
/*      */     {
/*  970 */       int va = tris.get(i * 4 + 0) * 3;
/*  971 */       int vb = tris.get(i * 4 + 1) * 3;
/*  972 */       int vc = tris.get(i * 4 + 2) * 3;
/*  973 */       float d = DistPtTri(px, py, pz, verts[(va + 0)], verts[(va + 1)], verts[(va + 2)], verts[(vb + 0)], verts[(vb + 1)], verts[(vb + 2)], verts[(vc + 0)], verts[(vc + 1)], verts[(vc + 2)]);
/*      */ 
/*  975 */       if (d < dmin)
/*  976 */         dmin = d;
/*      */     }
/*  978 */     if (dmin == 3.4028235E+38F) return -1.0F;
/*  979 */     return dmin;
/*      */   }
/*      */ 
/*      */   private float DistPtTri(float px, float py, float pz, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz)
/*      */   {
/*  984 */     Sub(this.DistPtTriV0, cx, cy, cz, ax, ay, az);
/*  985 */     Sub(this.DistPtTriV1, bx, by, bz, ax, ay, az);
/*  986 */     Sub(this.DistPtTriV2, px, py, pz, ax, ay, az);
/*      */ 
/*  988 */     float dot00 = Dot(this.DistPtTriV0, this.DistPtTriV0);
/*  989 */     float dot01 = Dot(this.DistPtTriV0, this.DistPtTriV1);
/*  990 */     float dot02 = Dot(this.DistPtTriV0, this.DistPtTriV2);
/*  991 */     float dot11 = Dot(this.DistPtTriV1, this.DistPtTriV1);
/*  992 */     float dot12 = Dot(this.DistPtTriV1, this.DistPtTriV2);
/*      */ 
/*  994 */     float invDenom = 1.0F / (dot00 * dot11 - dot01 * dot01);
/*  995 */     float u = (dot11 * dot02 - dot01 * dot12) * invDenom;
/*  996 */     float v = (dot00 * dot12 - dot01 * dot02) * invDenom;
/*      */ 
/*  998 */     float EPS = 1.0E-004F;
/*  999 */     if ((u >= -EPS) && (v >= -EPS) && (u + v <= 1.0F + EPS))
/*      */     {
/* 1001 */       float y = ay + this.DistPtTriV0[1] * u + this.DistPtTriV1[1] * v;
/* 1002 */       return Math.abs(y - py);
/*      */     }
/* 1004 */     return 3.4028235E+38F;
/*      */   }
/*      */ 
/*      */   private float Dot(float[] a, float[] b)
/*      */   {
/* 1009 */     return a[0] * b[0] + a[2] * b[2];
/*      */   }
/*      */ 
/*      */   private float Dot(float ax, float ay, float az, float bx, float by, float bz)
/*      */   {
/* 1014 */     return ax * bx + az * bz;
/*      */   }
/*      */ 
/*      */   private void Sub(float[] dest, float v1x, float v1y, float v1z, float v2x, float v2y, float v2z)
/*      */   {
/* 1019 */     dest[0] = (v1x - v2x);
/* 1020 */     dest[1] = (v1y - v2y);
/* 1021 */     dest[2] = (v1z - v2z);
/*      */   }
/*      */ 
/*      */   private short GetTriFlags(float[] vertsa, int va, float[] vertsb, int vb, float[] vertsc, int vc, float[] vpoly, int npoly)
/*      */   {
/* 1026 */     short flags = 0;
/* 1027 */     flags = (short)(flags | (short)(GetEdgeFlags(vertsa, va, vertsb, vb, vpoly, npoly) << 0));
/* 1028 */     flags = (short)(flags | (short)(GetEdgeFlags(vertsb, vb, vertsc, vc, vpoly, npoly) << 2));
/* 1029 */     flags = (short)(flags | (short)(GetEdgeFlags(vertsc, vc, vertsa, va, vpoly, npoly) << 4));
/* 1030 */     return flags;
/*      */   }
/*      */ 
/*      */   private short GetEdgeFlags(float[] vertsa, int va, float[] vertsb, int vb, float[] vpoly, int npoly)
/*      */   {
/* 1035 */     float thrSqr = 1.E-006F;
/* 1036 */     int i = 0; for (int j = npoly - 1; i < npoly; j = i++)
/*      */     {
/* 1038 */       if ((DistancePtSeg2d(vertsa, va, vpoly, j * 3, vpoly, i * 3) < thrSqr) && (DistancePtSeg2d(vertsb, vb, vpoly, j * 3, vpoly, i * 3) < thrSqr))
/*      */       {
/* 1040 */         return 1;
/*      */       }
/*      */     }
/* 1042 */     return 0;
/*      */   }
/*      */ 
/*      */   private float DistancePtSeg2d(float[] vpt, int pt, float[] vp, int p, float[] vq, int q)
/*      */   {
/* 1047 */     float pqx = vq[(q + 0)] - vp[(p + 0)];
/* 1048 */     float pqz = vq[(q + 2)] - vp[(p + 2)];
/* 1049 */     float dx = vpt[(pt + 0)] - vp[(p + 0)];
/* 1050 */     float dz = vpt[(pt + 2)] - vp[(p + 2)];
/* 1051 */     float d = pqx * pqx + pqz * pqz;
/* 1052 */     float t = pqx * dx + pqz * dz;
/* 1053 */     if (d > 0.0F)
/* 1054 */       t /= d;
/* 1055 */     if (t < 0.0F)
/* 1056 */       t = 0.0F;
/* 1057 */     else if (t > 1.0F) {
/* 1058 */       t = 1.0F;
/*      */     }
/* 1060 */     dx = vp[(p + 0)] + t * pqx - vpt[(pt + 0)];
/* 1061 */     dz = vp[(p + 2)] + t * pqz - vpt[(pt + 2)];
/*      */ 
/* 1063 */     return dx * dx + dz * dz;
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.DetailPolyMesh
 * JD-Core Version:    0.6.0
 */