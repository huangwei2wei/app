/*    */ package atavism.server.pathing.recast;
/*    */ 
/*    */ public class CompactSpan
/*    */ {
/*    */   public int Y;
/*    */   public int Reg;
/*    */   public long Con;
/*    */   public int H;
/*    */ 
/*    */   public void SetCon(int dir, int i)
/*    */   {
/* 18 */     int shift = dir * 6;
/* 19 */     long con = this.Con;
/* 20 */     this.Con = (con & (63 << shift ^ 0xFFFFFFFF) | (i & 0x3F) << shift);
/*    */   }
/*    */ 
/*    */   public int GetCon(int dir)
/*    */   {
/* 30 */     int shift = dir * 6;
/* 31 */     return (int)(this.Con >> shift & 0x3F);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.CompactSpan
 * JD-Core Version:    0.6.0
 */