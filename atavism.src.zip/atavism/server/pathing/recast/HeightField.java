/*     */ package atavism.server.pathing.recast;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ public class HeightField
/*     */ {
/*     */   public int Width;
/*     */   public int Height;
/*  12 */   public float[] Bmin = new float[3];
/*     */ 
/*  14 */   public float[] Bmax = new float[3];
/*     */   public float Cs;
/*     */   public float Ch;
/*     */   public Span[] Spans;
/*     */   public SpanPool Pools;
/*     */   public Span Freelist;
/*  25 */   protected float[] d = new float[12];
/*     */ 
/*  27 */   public static long NullArea = 0L;
/*     */ 
/*     */   public HeightField(int width, int height, float[] bmin, float[] bmax, float cs, float ch)
/*     */   {
/*  31 */     this.Width = width;
/*  32 */     this.Height = height;
/*  33 */     System.arraycopy(bmin, 0, this.Bmin, 0, 3);
/*  34 */     System.arraycopy(bmax, 0, this.Bmax, 0, 3);
/*  35 */     this.Cs = cs;
/*  36 */     this.Ch = ch;
/*  37 */     this.Spans = new Span[width * height];
/*     */   }
/*     */ 
/*     */   public void RasterizeTriangles(Geometry geom, short[] areas, int flagMergeThr)
/*     */   {
/*  42 */     RasterizeTriangles(geom, geom.Triangles, geom.NumTriangles, areas, flagMergeThr);
/*     */   }
/*     */ 
/*     */   public void RasterizeTriangles(Geometry geom, List<Integer> triangles, int numTriangles, short[] areas, int flagMergeThr)
/*     */   {
/*  48 */     float ics = 1.0F / this.Cs;
/*  49 */     float ich = 1.0F / this.Ch;
/*     */ 
/*  51 */     for (int i = 0; i < numTriangles; i++)
/*     */     {
/*  53 */       int v0 = ((Integer)triangles.get(i * 3 + 0)).intValue();
/*  54 */       int v1 = ((Integer)triangles.get(i * 3 + 1)).intValue();
/*  55 */       int v2 = ((Integer)triangles.get(i * 3 + 2)).intValue();
/*     */ 
/*  57 */       RasterizeTriangle(geom.Vertexes, v0, v1, v2, areas[i], ics, ich, flagMergeThr);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void RasterizeTriangle(List<RecastVertex> vertexes, int v0, int v1, int v2, short area, float ics, float ich, int flagMergeThr)
/*     */   {
/*  63 */     int w = this.Width;
/*  64 */     int h = this.Height;
/*     */ 
/*  67 */     float by = this.Bmax[1] - this.Bmin[1];
/*  68 */     RecastVertex tempMin = new RecastVertex((RecastVertex)vertexes.get(v0));
/*  69 */     RecastVertex tempMax = new RecastVertex((RecastVertex)vertexes.get(v0));
/*  70 */     tempMin = RecastVertex.Min(tempMin, (RecastVertex)vertexes.get(v1));
/*  71 */     tempMin = RecastVertex.Min(tempMin, (RecastVertex)vertexes.get(v2));
/*  72 */     tempMax = RecastVertex.Max(tempMax, (RecastVertex)vertexes.get(v1));
/*  73 */     tempMax = RecastVertex.Max(tempMax, (RecastVertex)vertexes.get(v2));
/*     */ 
/*  75 */     if (!OverlapBounds(this.Bmin, this.Bmax, tempMin.ToArray(), tempMax.ToArray()).booleanValue()) {
/*  76 */       return;
/*     */     }
/*  78 */     int x0 = (int)((tempMin.getX() - this.Bmin[0]) * ics);
/*  79 */     int y0 = (int)((tempMin.getZ() - this.Bmin[2]) * ics);
/*  80 */     int x1 = (int)((tempMin.getX() - this.Bmin[0]) * ics);
/*  81 */     int y1 = (int)((tempMin.getZ() - this.Bmin[2]) * ics);
/*     */ 
/*  83 */     x0 = Math.max(0, Math.min(x0, w - 1));
/*  84 */     y0 = Math.max(0, Math.min(y0, h - 1));
/*  85 */     x1 = Math.max(0, Math.min(x1, w - 1));
/*  86 */     y1 = Math.max(0, Math.min(y1, h - 1));
/*     */ 
/*  88 */     float[] inArray = new float[21]; float[] outArray = new float[21]; float[] inrowArray = new float[21];
/*     */ 
/*  90 */     for (int y = y0; y <= y1; y++)
/*     */     {
/*  92 */       System.arraycopy(((RecastVertex)vertexes.get(v0)).ToArray(), 0, inArray, 0, 3);
/*  93 */       System.arraycopy(((RecastVertex)vertexes.get(v1)).ToArray(), 0, inArray, 3, 3);
/*  94 */       System.arraycopy(((RecastVertex)vertexes.get(v2)).ToArray(), 0, inArray, 6, 3);
/*  95 */       int nvrow = 3;
/*  96 */       float cz = this.Bmin[2] + y * this.Cs;
/*  97 */       nvrow = ClipPoly(inArray, nvrow, outArray, 0, 1, -cz);
/*  98 */       if (nvrow >= 3) {
/*  99 */         nvrow = ClipPoly(outArray, nvrow, inrowArray, 0, -1, cz + this.Cs);
/* 100 */         if (nvrow < 3)
/*     */           continue;
/* 102 */         for (int x = x0; x <= x1; x++)
/*     */         {
/* 104 */           int nv = nvrow;
/* 105 */           float cx = this.Bmin[0] + x * this.Cs;
/* 106 */           nv = ClipPoly(inrowArray, nv, outArray, 1, 0, -cx);
/* 107 */           if (nv >= 3) {
/* 108 */             nv = ClipPoly(outArray, nv, inArray, -1, 0, cx + this.Cs);
/* 109 */             if (nv < 3)
/*     */               continue;
/* 111 */             float smin = inArray[1]; float smax = inArray[1];
/* 112 */             for (int i = 1; i < nv; i++)
/*     */             {
/* 114 */               smin = Math.min(smin, inArray[(i * 3 + 1)]);
/* 115 */               smax = Math.max(smax, inArray[(i * 3 + 1)]);
/*     */             }
/* 117 */             smin -= this.Bmin[1];
/* 118 */             smax -= this.Bmin[1];
/*     */ 
/* 121 */             if ((smax >= 0.0F) && (smin <= by)) {
/* 122 */               if (smin < 0.0F) smin = 0.0F;
/* 123 */               if (smax > by) smax = by;
/*     */ 
/* 125 */               int ismin = Math.max(0, Math.min((int)Math.floor(smin * ich), 32767));
/* 126 */               int ismax = Math.max(ismin + 1, Math.min((int)Math.floor(smax * ich), 32767));
/*     */ 
/* 128 */               AddSpan(x, y, ismin, ismax, area, flagMergeThr);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void AddSpan(int x, int y, int smin, int smax, short area, int flagMergeThr) {
/* 135 */     int idx = x + y * this.Width;
/* 136 */     Span s = AllocSpan();
/* 137 */     s.SMin = smin;
/* 138 */     s.SMax = smax;
/* 139 */     s.Area = area;
/* 140 */     s.Next = null;
/*     */ 
/* 142 */     if (this.Spans[idx] == null)
/*     */     {
/* 144 */       this.Spans[idx] = s;
/* 145 */       return;
/*     */     }
/*     */ 
/* 148 */     Span prev = null;
/* 149 */     Span cur = this.Spans[idx];
/*     */ 
/* 151 */     while (cur != null)
/*     */     {
/* 153 */       if (cur.SMin > s.SMax)
/*     */       {
/*     */         break;
/*     */       }
/* 157 */       if (cur.SMax < s.SMin)
/*     */       {
/* 159 */         prev = cur;
/* 160 */         cur = cur.Next; continue;
/*     */       }
/*     */ 
/* 164 */       if (cur.SMin < s.SMin)
/*     */       {
/* 166 */         s.SMin = cur.SMin;
/*     */       }
/* 168 */       if (cur.SMax > s.SMax)
/*     */       {
/* 170 */         s.SMax = cur.SMax;
/*     */       }
/*     */ 
/* 173 */       if (Math.abs((int)s.SMax - (int)cur.SMax) <= flagMergeThr)
/*     */       {
/* 175 */         s.Area = Math.max(s.Area, cur.Area);
/*     */       }
/*     */ 
/* 178 */       Span next = cur.Next;
/* 179 */       FreeSpan(cur);
/* 180 */       if (prev != null)
/*     */       {
/* 182 */         prev.Next = next;
/*     */       }
/*     */       else
/*     */       {
/* 186 */         this.Spans[idx] = next;
/*     */       }
/* 188 */       cur = next;
/*     */     }
/*     */ 
/* 192 */     if (prev != null)
/*     */     {
/* 194 */       s.Next = prev.Next;
/* 195 */       prev.Next = s;
/*     */     }
/*     */     else
/*     */     {
/* 199 */       s.Next = this.Spans[idx];
/* 200 */       this.Spans[idx] = s;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void FreeSpan(Span ptr)
/*     */   {
/* 206 */     if (ptr == null) return;
/* 207 */     ptr.Next = this.Freelist;
/* 208 */     this.Freelist = ptr;
/*     */   }
/*     */ 
/*     */   private Span AllocSpan()
/*     */   {
/* 213 */     if (this.Freelist == null)
/*     */     {
/* 215 */       this.Freelist = new Span();
/*     */     }
/*     */ 
/* 218 */     Span it = this.Freelist;
/* 219 */     this.Freelist = this.Freelist.Next;
/* 220 */     return it;
/*     */   }
/*     */ 
/*     */   private int ClipPoly(float[] inArray, int n, float[] outArray, int pnx, int pnz, float pd)
/*     */   {
/* 225 */     for (int i = 0; i < n; i++)
/*     */     {
/* 227 */       this.d[i] = (pnx * inArray[(i * 3 + 0)] + pnz * inArray[(i * 3 + 2)] + pd);
/*     */     }
/*     */ 
/* 230 */     int m = 0;
/* 231 */     int i = 0; for (int j = n - 1; i < n; i++)
/*     */     {
/* 233 */       Boolean ina = Boolean.valueOf(this.d[j] >= 0.0F);
/* 234 */       Boolean inb = Boolean.valueOf(this.d[i] >= 0.0F);
/* 235 */       if (ina != inb)
/*     */       {
/* 237 */         float s = this.d[j] / (this.d[j] - this.d[i]);
/* 238 */         inArray[(j * 3 + 0)] += (inArray[(i * 3 + 0)] - inArray[(j * 3 + 0)]) * s;
/* 239 */         inArray[(j * 3 + 1)] += (inArray[(i * 3 + 1)] - inArray[(j * 3 + 1)]) * s;
/* 240 */         inArray[(j * 3 + 2)] += (inArray[(i * 3 + 2)] - inArray[(j * 3 + 2)]) * s;
/* 241 */         m++;
/*     */       }
/* 243 */       if (inb.booleanValue())
/*     */       {
/* 245 */         outArray[(m * 3 + 0)] = inArray[(i * 3 + 0)];
/* 246 */         outArray[(m * 3 + 1)] = inArray[(i * 3 + 1)];
/* 247 */         outArray[(m * 3 + 2)] = inArray[(i * 3 + 2)];
/* 248 */         m++;
/*     */       }
/* 231 */       j = i;
/*     */     }
/*     */ 
/* 251 */     return m;
/*     */   }
/*     */ 
/*     */   private Boolean OverlapBounds(float[] amin, float[] amax, float[] bmin, float[] bmax)
/*     */   {
/* 256 */     Boolean overlap = Boolean.valueOf(true);
/* 257 */     overlap = Boolean.valueOf((amin[0] > bmax[0]) || (amax[0] < bmin[0]) ? false : overlap.booleanValue());
/* 258 */     overlap = Boolean.valueOf((amin[1] > bmax[1]) || (amax[1] < bmin[1]) ? false : overlap.booleanValue());
/* 259 */     overlap = Boolean.valueOf((amin[2] > bmax[2]) || (amax[2] < bmin[2]) ? false : overlap.booleanValue());
/* 260 */     return overlap;
/*     */   }
/*     */ 
/*     */   public void FilterLowHangingWalkableObstacles(int walkableClimb)
/*     */   {
/* 265 */     int w = this.Width;
/* 266 */     int h = this.Height;
/*     */ 
/* 268 */     for (int y = 0; y < h; y++)
/*     */     {
/* 270 */       for (int x = 0; x < w; x++)
/*     */       {
/* 272 */         Span ps = null;
/* 273 */         Boolean previousWalkable = Boolean.valueOf(false);
/* 274 */         long previousArea = NullArea;
/*     */ 
/* 276 */         for (Span s = this.Spans[(x + y * w)]; s != null; s = s.Next)
/*     */         {
/* 278 */           Boolean walkable = Boolean.valueOf(s.Area != NullArea);
/*     */ 
/* 280 */           if ((!walkable.booleanValue()) && (previousWalkable.booleanValue()))
/*     */           {
/* 282 */             if (Math.abs((int)s.SMax - (int)ps.SMax) <= walkableClimb)
/* 283 */               s.Area = previousArea;
/*     */           }
/* 285 */           previousWalkable = walkable;
/* 286 */           previousArea = s.Area;
/*     */ 
/* 276 */           ps = s;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void FilterLedgeSpans(int walkableHeight, int walkableClimb)
/*     */   {
/* 294 */     int w = this.Width;
/* 295 */     int h = this.Height;
/* 296 */     int MaxHeight = 65535;
/*     */ 
/* 298 */     for (int y = 0; y < h; y++)
/*     */     {
/* 300 */       for (int x = 0; x < w; x++)
/*     */       {
/* 302 */         for (Span s = this.Spans[(x + y * w)]; s != null; s = s.Next)
/*     */         {
/* 304 */           if (s.Area == NullArea) {
/*     */             continue;
/*     */           }
/* 307 */           int bot = (int)s.SMax;
/* 308 */           int top = s.Next != null ? (int)s.Next.SMin : MaxHeight;
/*     */ 
/* 310 */           int minh = MaxHeight;
/*     */ 
/* 312 */           int asmin = (int)s.SMax;
/* 313 */           int asmax = (int)s.SMax;
/*     */ 
/* 315 */           for (int dir = 0; dir < 4; dir++)
/*     */           {
/* 317 */             int dx = x + Helper.GetDirOffsetX(dir);
/* 318 */             int dy = y + Helper.GetDirOffsetY(dir);
/* 319 */             if ((dx < 0) || (dy < 0) || (dx >= w) || (dy >= h))
/*     */             {
/* 321 */               minh = Math.min(minh, -walkableClimb - bot);
/*     */             }
/*     */             else {
/* 324 */               Span ns = this.Spans[(dx + dy * w)];
/* 325 */               int nbot = -walkableClimb;
/* 326 */               int ntop = ns != null ? (int)ns.SMin : MaxHeight;
/*     */ 
/* 328 */               if (Math.min(top, ntop) - Math.max(bot, nbot) > walkableHeight) {
/* 329 */                 minh = Math.min(minh, nbot - bot);
/*     */               }
/* 331 */               for (ns = this.Spans[(dx + dy * w)]; ns != null; ns = ns.Next)
/*     */               {
/* 333 */                 nbot = (int)ns.SMax;
/* 334 */                 ntop = ns.Next != null ? (int)ns.Next.SMin : MaxHeight;
/* 335 */                 if (Math.min(top, ntop) - Math.max(bot, nbot) <= walkableHeight)
/*     */                   continue;
/* 337 */                 minh = Math.min(minh, nbot - bot);
/* 338 */                 if (Math.abs(nbot - bot) > walkableClimb)
/*     */                   continue;
/* 340 */                 if (nbot < asmin) asmin = nbot;
/* 341 */                 if (nbot <= asmax) continue; asmax = nbot;
/*     */               }
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 347 */           if (minh < -walkableClimb) {
/* 348 */             s.Area = NullArea;
/*     */           }
/* 350 */           if (asmax - asmin <= walkableClimb)
/*     */             continue;
/* 352 */           s.Area = NullArea;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void FilterWalkableLowHeightSpans(int walkableHeight)
/*     */   {
/* 361 */     int w = this.Width;
/* 362 */     int h = this.Height;
/* 363 */     int MaxHeight = 65535;
/*     */ 
/* 365 */     for (int y = 0; y < h; y++)
/*     */     {
/* 367 */       for (int x = 0; x < w; x++)
/*     */       {
/* 369 */         for (Span s = this.Spans[(x + y * w)]; s != null; s = s.Next)
/*     */         {
/* 371 */           int bot = (int)s.SMax;
/* 372 */           int top = s.Next != null ? (int)s.Next.SMin : MaxHeight;
/* 373 */           if (top - bot <= walkableHeight)
/* 374 */             s.Area = NullArea;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int GetHeightFieldSpanCount()
/*     */   {
/* 382 */     int w = this.Width;
/* 383 */     int h = this.Height;
/* 384 */     int spanCount = 0;
/* 385 */     for (int y = 0; y < h; y++)
/*     */     {
/* 387 */       for (int x = 0; x < w; x++)
/*     */       {
/* 389 */         for (Span s = this.Spans[(x + y * w)]; s != null; s = s.Next)
/*     */         {
/* 391 */           if (s.Area != NullArea)
/* 392 */             spanCount++;
/*     */         }
/*     */       }
/*     */     }
/* 396 */     return spanCount;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.recast.HeightField
 * JD-Core Version:    0.6.0
 */