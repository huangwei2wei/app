/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class PathSynth
/*     */ {
/*     */   String modelName;
/*     */   String type;
/*     */   int firstTerrainIndex;
/*     */   PathPolygon boundingPolygon;
/*     */   List<PathPolygon> polygons;
/*     */   List<PathArc> portals;
/*     */   List<PathArc> arcs;
/* 669 */   Map<Integer, List<PathArc>> polygonArcs = null;
/* 670 */   Map<Integer, PathPolygon> polygonMap = null;
/* 671 */   LinkedList<PathPolygon> terrainPolygonAtCorner = null;
/*     */   public static final float epsilon = 1.0F;
/* 682 */   protected static float insideDistance = 100.0F;
/*     */ 
/* 684 */   protected static final Logger log = new Logger("PathSynth");
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public PathSynth(PathPolygon boundary, List<PathPolygon> obstacles)
/*     */   {
/*  16 */     this.modelName = "Dynamic";
/*  17 */     this.type = "Dynamic";
/*  18 */     this.boundingPolygon = boundary;
/*  19 */     this.arcs = new LinkedList();
/*  20 */     this.polygons = new LinkedList();
/*  21 */     boundary.setIndex(1);
/*  22 */     boundary.setKind(1);
/*  23 */     combineBoundaryAndObstacles(boundary, obstacles);
/*  24 */     List polygonsCopy = new LinkedList(this.polygons);
/*  25 */     for (PathPolygon poly : polygonsCopy)
/*  26 */       generateConvexPolygons(poly);
/*  27 */     this.arcs = PathObject.discoverArcs(this.polygons);
/*     */     int i;
/*  28 */     if (Log.loggingDebug) {
/*  29 */       log.debug("PathSynth constructor: After combining boundary and obstacles:");
/*  30 */       i = 0;
/*  31 */       for (PathPolygon polygon : this.polygons)
/*  32 */         log.debug(new StringBuilder().append("      Poly ").append(i++).append(": ").append(polygon).toString());
/*  33 */       i = 0;
/*  34 */       for (PathArc arc : this.arcs)
/*  35 */         log.debug(new StringBuilder().append("      Arc  ").append(i++).append(": ").append(arc).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void combineBoundaryAndObstacles(PathPolygon boundaryPoly, List<PathPolygon> obstacles)
/*     */   {
/*  79 */     int obstacleCount = obstacles.size();
/*  80 */     if (obstacleCount == 0)
/*     */     {
/*  82 */       this.polygons.add(boundaryPoly);
/*  83 */       return;
/*     */     }
/*  85 */     if (obstacleCount == 1)
/*     */     {
/*  88 */       PathPolygon obstacle = (PathPolygon)obstacles.get(0);
/*  89 */       PathPolygon newPoly = breakBoundaryAroundObstacle(boundaryPoly, obstacle);
/*  90 */       this.polygons.add(boundaryPoly);
/*  91 */       this.polygons.add(newPoly);
/*  92 */       return;
/*     */     }
/*     */ 
/*  95 */     List hullLines = computeConvexHull(obstacles);
/*  96 */     HullPoint[] hullPoints = sortHullPoints(hullLines);
/*     */ 
/* 103 */     int hullSize = hullPoints.length;
/* 104 */     List corners = new LinkedList();
/* 105 */     List usedObstacles = new LinkedList();
/* 106 */     int hullPointNumber = 0;
/*     */     while (true)
/*     */     {
/* 110 */       HullPoint hullPoint = hullPoints[hullPointNumber];
/* 111 */       List obstacleCorners = hullPoint.polygon.getCorners();
/* 112 */       int obstacleSize = obstacleCorners.size();
/* 113 */       if (usedObstacles.contains(hullPoint.polygon))
/*     */         break;
/* 115 */       boolean previousSamePoly = hullPoint.polygon != hullPoints[wrap(hullPointNumber - 1, hullSize)].polygon;
/* 116 */       boolean nextSamePoly = hullPoint.polygon == hullPoints[wrap(hullPointNumber + 1, hullSize)].polygon;
/*     */ 
/* 120 */       if ((previousSamePoly) && (nextSamePoly)) {
/* 121 */         hullPointNumber = wrap(hullPointNumber - 1, hullSize);
/* 122 */         continue;
/*     */       }
/*     */ 
/* 125 */       int cornerDirection = -1;
/*     */       int lastObstacleHullPointNumber;
/* 126 */       if (nextSamePoly)
/*     */       {
/* 130 */         int lastObstacleHullPointNumber = hullPointNumber;
/* 131 */         int j = lastObstacleHullPointNumber;
/* 132 */         while (hullPoints[j].polygon == hullPoint.polygon) {
/* 133 */           lastObstacleHullPointNumber = j;
/* 134 */           j = wrap(j + 1, hullSize);
/*     */         }
/*     */ 
/* 140 */         if (wrap(hullPoint.cornerNumber + 1, obstacleSize) == hullPoints[wrap(hullPointNumber + 1, hullSize)].cornerNumber) {
/* 141 */           cornerDirection = 1;
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 148 */         int cornerNumber = hullPoint.cornerNumber;
/* 149 */         lastObstacleHullPointNumber = cornerNumber;
/*     */ 
/* 154 */         HullPoint previousHullPoint = hullPoints[wrap(hullPointNumber - 1, hullSize)];
/* 155 */         AOVector v = AOVector.sub(hullPoint.point, previousHullPoint.point);
/* 156 */         v.normalize();
/* 157 */         AOVector cPlus = AOVector.sub((AOVector)obstacleCorners.get(wrap(hullPoint.cornerNumber + 1, obstacleSize)), hullPoint.point);
/* 158 */         cPlus.normalize();
/* 159 */         AOVector cMinus = AOVector.sub((AOVector)obstacleCorners.get(wrap(hullPoint.cornerNumber - 1, obstacleSize)), hullPoint.point);
/* 160 */         cMinus.normalize();
/* 161 */         if (v.dotProduct(cPlus) > v.dotProduct(cMinus))
/* 162 */           cornerDirection = -1;
/*     */       }
/* 164 */       int cornerNumber = hullPoint.cornerNumber;
/* 165 */       corners.add(obstacleCorners.get(cornerNumber));
/*     */       do {
/* 167 */         cornerNumber = wrap(cornerNumber + cornerDirection, obstacleSize);
/* 168 */         corners.add(obstacleCorners.get(cornerNumber));
/*     */       }
/* 170 */       while (cornerNumber != hullPoints[lastObstacleHullPointNumber].cornerNumber);
/* 171 */       usedObstacles.add(hullPoint.polygon);
/*     */     }
/* 173 */     PathPolygon newPoly = breakBoundaryAroundObstacle(boundaryPoly, new PathPolygon(0, 1, corners));
/* 174 */     this.polygons.add(boundaryPoly);
/* 175 */     this.polygons.add(newPoly);
/*     */   }
/*     */ 
/*     */   protected void combineBoundaryAndObstacles_old(PathPolygon boundaryPoly, List<PathPolygon> obstacles)
/*     */   {
/* 188 */     List holeyObstacles = spliceOutIntersections(boundaryPoly, obstacles);
/* 189 */     List boundaryPolys = new LinkedList();
/* 190 */     boundaryPolys.add(boundaryPoly);
/* 191 */     PathPolygon newPoly = null;
/* 192 */     for (PathPolygon obstacle : holeyObstacles) {
/* 193 */       newPoly = breakBoundaryAroundObstacle(boundaryPoly, obstacle);
/* 194 */       if (newPoly == null) {
/* 195 */         log.error(new StringBuilder().append("PathSynth.combineBoundaryAndObstacles: obstacle ").append(obstacle).append(" is not wholly contained in any boundary polygon!").toString());
/*     */       }
/*     */       else
/* 198 */         boundaryPolys.add(newPoly);
/*     */     }
/* 200 */     this.polygons.addAll(boundaryPolys);
/*     */   }
/*     */ 
/*     */   protected PathPolygon breakBoundaryAroundObstacle(PathPolygon boundaryPoly, PathPolygon obstacle)
/*     */   {
/* 209 */     List obstacleCorners = obstacle.getCorners();
/* 210 */     boolean obstacleccw = AOVector.counterClockwisePoints((AOVector)obstacleCorners.get(0), (AOVector)obstacleCorners.get(1), (AOVector)obstacleCorners.get(2));
/* 211 */     int firstCornerNumber = 0;
/* 212 */     int middleCornerNumber = obstacleCorners.size() / 2;
/* 213 */     AOVector obstacleCorner1 = (AOVector)obstacleCorners.get(firstCornerNumber);
/* 214 */     AOVector obstacleCorner2 = (AOVector)obstacleCorners.get(middleCornerNumber);
/* 215 */     int boundaryCorner1Number = boundaryPoly.getClosestCornerToPoint(obstacleCorner1);
/* 216 */     int boundaryCorner2Number = boundaryPoly.getClosestCornerToPoint(obstacleCorner2);
/*     */ 
/* 218 */     List boundaryCorners = boundaryPoly.getCorners();
/* 219 */     boolean boundaryccw = AOVector.counterClockwisePoints((AOVector)boundaryCorners.get(0), (AOVector)boundaryCorners.get(1), (AOVector)boundaryCorners.get(2));
/*     */ 
/* 221 */     PathPolygon newPoly = new PathPolygon();
/* 222 */     newPoly.setKind(1);
/* 223 */     newPoly.setIndex(this.polygons.size() + 1);
/*     */ 
/* 225 */     List newPolyCorners = new LinkedList();
/* 226 */     List originalPolyCorners = new LinkedList();
/* 227 */     addCornersInRange(newPolyCorners, boundaryCorners, boundaryCorner2Number, boundaryCorner1Number, 1);
/* 228 */     addCornersInRange(originalPolyCorners, boundaryCorners, boundaryCorner1Number, boundaryCorner2Number, 1);
/* 229 */     int incr = boundaryccw == obstacleccw ? -1 : 1;
/* 230 */     addCornersInRange(newPolyCorners, obstacleCorners, firstCornerNumber, middleCornerNumber, incr);
/* 231 */     addCornersInRange(originalPolyCorners, obstacleCorners, middleCornerNumber, firstCornerNumber, incr);
/*     */ 
/* 233 */     boundaryPoly.setCorners(originalPolyCorners);
/* 234 */     newPoly.setCorners(newPolyCorners);
/* 235 */     return newPoly;
/*     */   }
/*     */ 
/*     */   protected void addCornersInRange(List<AOVector> newCorners, List<AOVector> oldCorners, int firstOldCorner, int lastOldCorner, int incr)
/*     */   {
/* 244 */     int oldCount = oldCorners.size();
/* 245 */     int cornerNumber = firstOldCorner;
/*     */     while (true) {
/* 247 */       newCorners.add(oldCorners.get(cornerNumber));
/* 248 */       if (cornerNumber == lastOldCorner)
/*     */         break;
/* 250 */       if (incr > 0) {
/* 251 */         cornerNumber = cornerNumber == oldCount - 1 ? 0 : cornerNumber + 1; continue;
/*     */       }
/* 253 */       cornerNumber = cornerNumber == 0 ? oldCount - 1 : cornerNumber - 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int wrap(int index, int size)
/*     */   {
/* 259 */     int i = index % size;
/* 260 */     if (i >= 0) {
/* 261 */       return i;
/*     */     }
/* 263 */     return (index + size) % size;
/*     */   }
/*     */ 
/*     */   protected static Float computeSlope(AOVector point1, AOVector point2)
/*     */   {
/* 315 */     if (point1.getX() == point2.getX()) {
/* 316 */       return null;
/*     */     }
/* 318 */     if (point2.getZ() == point1.getZ()) {
/* 319 */       return Float.valueOf(0.0F);
/*     */     }
/* 321 */     return Float.valueOf((point2.getZ() - point1.getZ()) / (point2.getX() - point1.getX()));
/*     */   }
/*     */ 
/*     */   protected static boolean onLeft(AOVector point1, AOVector point2, Float slope, AOVector p)
/*     */   {
/* 331 */     if (slope == null) {
/* 332 */       if (p.getX() < point1.getX()) return true;
/*     */ 
/* 334 */       if (p.getX() == point1.getX())
/*     */       {
/* 337 */         return ((p.getZ() > point1.getZ()) && (p.getZ() < point2.getZ())) || ((p.getZ() > point2.getZ()) && (p.getZ() < point1.getZ()));
/*     */       }
/*     */ 
/* 341 */       return false;
/*     */     }
/*     */ 
/* 345 */     float x3 = (p.getX() + slope.floatValue() * (slope.floatValue() * point1.getX() - point1.getZ() + p.getZ())) / (1.0F + slope.floatValue() * slope.floatValue());
/* 346 */     float z3 = slope.floatValue() * (x3 - point1.getX()) + point1.getZ();
/*     */ 
/* 348 */     if (slope.floatValue() == 0.0F)
/* 349 */       return p.getZ() > z3;
/* 350 */     if (slope.floatValue() > 0.0F) {
/* 351 */       return x3 > p.getX();
/*     */     }
/* 353 */     return p.getX() > x3;
/*     */   }
/*     */ 
/*     */   protected static HullPoint hullVertex(HullPoint[] points, AOVector p)
/*     */   {
/* 362 */     for (HullPoint hullPoint : points) {
/* 363 */       if (AOVector.distanceToSquared(hullPoint.point, p) < 1.0F)
/* 364 */         return hullPoint;
/*     */     }
/* 366 */     return null;
/*     */   }
/*     */ 
/*     */   protected static HullPoint[] sortHullPoints(List<HullLine> lines)
/*     */   {
/* 374 */     HullPoint[] sortedPoints = new HullPoint[lines.size()];
/* 375 */     HullLine currentLine = null;
/* 376 */     int count = 0;
/* 377 */     for (HullLine line : lines) {
/* 378 */       if (currentLine == null) {
/* 379 */         currentLine = line;
/*     */       }
/*     */       else
/*     */       {
/* 383 */         AOVector p = currentLine.point2();
/* 384 */         HullLine nextLine = null;
/* 385 */         for (HullLine otherLine : lines) {
/* 386 */           if (line == currentLine)
/*     */             continue;
/* 388 */           if (AOVector.distanceToSquared(p, otherLine.point1()) < 1.0F) {
/* 389 */             nextLine = line;
/* 390 */             break;
/*     */           }
/* 392 */           if (AOVector.distanceToSquared(p, otherLine.point2()) < 1.0F)
/*     */           {
/* 394 */             nextLine = new HullLine(line.hullPoint2, line.hullPoint1);
/* 395 */             break;
/*     */           }
/*     */         }
/* 398 */         if (nextLine != null) {
/* 399 */           currentLine = nextLine;
/*     */         } else {
/* 401 */           log.error(new StringBuilder().append("PathSynth.sortHullLines: Could not find the HullLine starting with point ").append(p).toString());
/* 402 */           return sortedPoints;
/*     */         }
/* 404 */         sortedPoints[(count++)] = currentLine.hullPoint1;
/*     */       }
/*     */     }
/* 407 */     return sortedPoints;
/*     */   }
/*     */ 
/*     */   public List<HullLine> computeConvexHull(List<PathPolygon> obstacles)
/*     */   {
/* 417 */     int pointCount = 0;
/* 418 */     for (PathPolygon polygon : obstacles)
/* 419 */       pointCount += polygon.getCorners().size();
/* 420 */     HullPoint[] points = new HullPoint[pointCount];
/* 421 */     int hullPointCount = 0;
/* 422 */     for (Iterator i$ = obstacles.iterator(); i$.hasNext(); ) { polygon = (PathPolygon)i$.next();
/* 423 */       List corners = polygon.getCorners();
/* 424 */       i = 0;
/* 425 */       for (AOVector corner : corners)
/* 426 */         points[(hullPointCount++)] = new HullPoint(i++, corner, polygon);
/*     */     }
/*     */     PathPolygon polygon;
/*     */     int i;
/* 428 */     List hull = new LinkedList();
/* 429 */     for (int c1 = 0; c1 < pointCount; c1++) {
/* 430 */       for (int c2 = c1 + 1; c2 < pointCount; c2++) {
/* 431 */         boolean leftMost = true;
/* 432 */         boolean rightMost = true;
/* 433 */         HullPoint p1 = points[c1];
/* 434 */         AOVector point1 = p1.point;
/* 435 */         HullPoint p2 = points[c2];
/* 436 */         AOVector point2 = p2.point;
/* 437 */         Float slope = computeSlope(point1, point2);
/* 438 */         for (int c3 = 0; c3 < pointCount; c3++) {
/* 439 */           if ((c3 != c1) && (c3 != c2)) {
/* 440 */             if (onLeft(point1, point2, slope, points[c3].point))
/* 441 */               leftMost = false;
/*     */             else {
/* 443 */               rightMost = false;
/*     */             }
/*     */           }
/*     */         }
/* 447 */         if ((leftMost) || (rightMost))
/* 448 */           hull.add(new HullLine(p1, p2));
/*     */       }
/*     */     }
/* 451 */     return hull;
/*     */   }
/*     */ 
/*     */   protected List<PathPolygon> spliceOutIntersections(PathPolygon boundary, List<PathPolygon> obstacles)
/*     */   {
/* 460 */     List holeyObstacles = new LinkedList();
/* 461 */     for (PathPolygon obstacle : obstacles) {
/* 462 */       List intersections = PathPolygon.findPolyIntersections(boundary, obstacle);
/* 463 */       if (intersections != null) {
/* 464 */         if (Log.loggingDebug)
/* 465 */           log.debug(new StringBuilder().append("PathSynth.spliceOutIntersections: ").append(intersections.size()).append(" intersections").toString());
/* 466 */         if (intersections.size() == 2)
/* 467 */           mergeDoublyIntersectingObstacle(boundary, obstacle, intersections);
/*     */         else {
/* 469 */           log.warn(new StringBuilder().append("PathSynth.spliceOutIntersections: Can't handle ").append(intersections.size()).append(" intersections").toString());
/*     */         }
/*     */       }
/* 472 */       else if (!whollyContained(boundary, obstacle)) {
/* 473 */         log.warn("PathSynth.spliceOutIntersections: Obstacle is not wholly contained in the the boundary, but does not intersect it.");
/*     */       }
/*     */       else
/*     */       {
/* 477 */         holeyObstacles.add(obstacle);
/* 478 */         if (Log.loggingDebug) {
/* 479 */           log.debug(new StringBuilder().append("PathSynth.spliceOutIntersections: new holeyObstacle ").append(obstacle).toString());
/*     */         }
/*     */       }
/*     */     }
/* 483 */     return holeyObstacles;
/*     */   }
/*     */ 
/*     */   protected boolean whollyContained(PathPolygon boundary, PathPolygon obstacle)
/*     */   {
/* 493 */     boolean contained = true;
/* 494 */     for (AOVector p : obstacle.getCorners()) {
/* 495 */       if (!boundary.pointInside2D(p)) {
/* 496 */         contained = false;
/* 497 */         break;
/*     */       }
/*     */     }
/* 500 */     if (Log.loggingDebug) {
/* 501 */       log.debug(new StringBuilder().append("PathSynth.whollyContained: obstacle ").append(obstacle).append(contained ? "is" : "is not").append(" wholly contained in ").append(boundary).toString());
/*     */     }
/* 503 */     return contained;
/*     */   }
/*     */ 
/*     */   protected void mergeDoublyIntersectingObstacle(PathPolygon boundary, PathPolygon obstacle, List<PolyIntersection> intersections)
/*     */   {
/* 514 */     PolyIntersection intr1 = (PolyIntersection)intersections.get(0);
/* 515 */     PolyIntersection intr2 = (PolyIntersection)intersections.get(1);
/*     */ 
/* 517 */     int bc1Index = intr1.poly1Corner;
/* 518 */     int bc2Index = intr2.poly1Corner;
/* 519 */     List boundaryCorners = boundary.getCorners();
/* 520 */     int size = boundaryCorners.size();
/* 521 */     List obstaclePoints = pointsInside(boundary, obstacle);
/*     */ 
/* 523 */     if (bc1Index != bc2Index) {
/* 524 */       int count = bc2Index - bc1Index;
/* 525 */       if (count < 0)
/* 526 */         count += size;
/* 527 */       for (int i = 0; i < count; i++) {
/* 528 */         int index = wrap(bc1Index + 1, size);
/* 529 */         boundaryCorners.remove(index);
/* 530 */         size = boundaryCorners.size();
/*     */       }
/*     */     }
/* 533 */     PathIntersection pintr1 = intr1.intr;
/* 534 */     AOVector corner1 = (AOVector)boundaryCorners.get(bc1Index);
/* 535 */     bc2Index = wrap(bc1Index + 1, size);
/* 536 */     AOVector corner2 = (AOVector)boundaryCorners.get(bc2Index);
/* 537 */     AOVector newPoint1 = AOVector.sub(corner2, corner1).multiply(pintr1.getWhere1());
/* 538 */     boundaryCorners.add(bc2Index, newPoint1);
/* 539 */     AOVector newPoint2 = AOVector.sub(corner2, corner1).multiply(pintr1.getWhere2());
/* 540 */     bc2Index = wrap(bc2Index + 1, size);
/* 541 */     boundaryCorners.add(bc2Index, newPoint2);
/* 542 */     boundaryCorners.addAll(bc2Index, obstaclePoints);
/*     */   }
/*     */ 
/*     */   protected List<AOVector> pointsInside(PathPolygon boundary, PathPolygon obstacle)
/*     */   {
/* 550 */     List points = new LinkedList();
/* 551 */     for (AOVector p : obstacle.getCorners()) {
/* 552 */       if (boundary.pointInside2D(p))
/* 553 */         points.add(p);
/*     */     }
/* 555 */     return points;
/*     */   }
/*     */ 
/*     */   protected void generateConvexPolygons(PathPolygon poly)
/*     */   {
/* 566 */     List originalCorners = poly.getCorners();
/* 567 */     int size = originalCorners.size();
/* 568 */     AOVector[] points = new AOVector[size];
/* 569 */     int c = 0;
/* 570 */     for (AOVector corner : originalCorners)
/* 571 */       points[(c++)] = new AOVector(corner);
/* 572 */     List concaveCorners = new LinkedList();
/* 573 */     for (int i = 0; i < size; i++) {
/* 574 */       if (AOVector.counterClockwisePoints(points[wrap(i - 1, size)], points[i], points[wrap(i + 1, size)]))
/*     */       {
/*     */         continue;
/*     */       }
/* 578 */       concaveCorners.add(Integer.valueOf(i));
/*     */     }
/*     */ 
/* 581 */     if (concaveCorners.size() == 0) {
/* 582 */       if (Log.loggingDebug)
/* 583 */         log.debug(new StringBuilder().append("PathSynth.generateConvexPolygons: Poly is convex ").append(poly).toString());
/* 584 */       return;
/*     */     }
/* 586 */     for (int origCornerNumber = 0; origCornerNumber < size; origCornerNumber++) {
/* 587 */       if (!concaveCorners.contains(Integer.valueOf(origCornerNumber)))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 592 */       int lastNewPolyCorner = origCornerNumber;
/* 593 */       int newPolyCornerCount = 3;
/* 594 */       if (Log.loggingDebug)
/* 595 */         log.debug(new StringBuilder().append("PathSynth.generateConvexPolygons: size ").append(size).append(", lastNewPolyCorner ").append(lastNewPolyCorner).toString());
/* 596 */       int firstNewPolyCorner = wrap(lastNewPolyCorner - 2, size);
/*     */       while (true)
/*     */       {
/* 600 */         if (!AOVector.counterClockwisePoints(points[wrap(lastNewPolyCorner - 1, size)], points[lastNewPolyCorner], points[firstNewPolyCorner]))
/*     */         {
/* 604 */           firstNewPolyCorner = wrap(firstNewPolyCorner + 1, size);
/* 605 */           newPolyCornerCount--;
/* 606 */           break;
/*     */         }
/*     */ 
/* 609 */         firstNewPolyCorner = wrap(firstNewPolyCorner - 1, size);
/* 610 */         newPolyCornerCount++;
/*     */       }
/*     */ 
/* 617 */       LinkedList newPolyCorners = new LinkedList();
/* 618 */       for (int i = 0; i < newPolyCornerCount; i++) {
/* 619 */         int n = wrap(firstNewPolyCorner + i, size);
/* 620 */         newPolyCorners.add(originalCorners.get(n));
/*     */       }
/*     */ 
/* 623 */       int newPolyIndex = this.polygons.size() + 1;
/* 624 */       PathPolygon newPoly = new PathPolygon(newPolyIndex, 1, newPolyCorners);
/* 625 */       if (Log.loggingDebug) {
/* 626 */         log.debug(new StringBuilder().append("PathSynth.generateConvexPolygons: new poly corner count ").append(newPolyCorners.size()).append(", first corner ").append(firstNewPolyCorner).append(", last corner ").append(lastNewPolyCorner).append(",  ").append(newPoly).toString());
/*     */       }
/* 628 */       if (newPolyCorners.size() < 3) {
/* 629 */         log.error(new StringBuilder().append("PathSynth.generateConvexPolygons: newPoly has just ").append(newPolyCorners.size()).append(" corners.").toString());
/* 630 */         return;
/*     */       }
/* 632 */       this.polygons.add(newPoly);
/*     */ 
/* 635 */       int i = wrap(firstNewPolyCorner + 1, size);
/* 636 */       int count = newPolyCorners.size() - 2;
/* 637 */       for (int j = 0; j < count; j++) {
/* 638 */         originalCorners.remove(i);
/* 639 */         i = wrap(i, originalCorners.size());
/*     */       }
/* 641 */       if (Log.loggingDebug)
/* 642 */         log.debug(new StringBuilder().append("PathSynth.generateConvexPolygons: original Poly ").append(poly).toString());
/* 643 */       if (originalCorners.size() < 3) {
/* 644 */         log.error(new StringBuilder().append("PathSynth.generateConvexPolygons: original Poly has just ").append(originalCorners.size()).append(" corners.").toString());
/* 645 */         return;
/*     */       }
/*     */ 
/* 648 */       generateConvexPolygons(poly);
/* 649 */       break;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void dumpPolygonsAndArcs(String description)
/*     */   {
/* 655 */     log.info(new StringBuilder().append(description).append(": ").append(this.polygons.size()).append(" polygons, ").append(this.arcs.size()).append(" arcs.").toString());
/* 656 */     for (PathPolygon poly : this.polygons)
/* 657 */       log.info(new StringBuilder().append(description).append(": Polygon ").append(poly).toString());
/* 658 */     for (PathArc arc : this.arcs)
/* 659 */       log.info(new StringBuilder().append(description).append(": Arc ").append(arc).toString());
/*     */   }
/*     */ 
/*     */   private static void test1()
/*     */   {
/* 688 */     log.info("PathSynth.main: Starting test1");
/*     */ 
/* 690 */     List corners = new LinkedList();
/* 691 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 692 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 693 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 694 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 695 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*     */ 
/* 697 */     List obstacles = new LinkedList();
/* 698 */     corners = new LinkedList();
/* 699 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 700 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 701 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 702 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 703 */     obstacles.add(new PathPolygon(0, 1, corners));
/*     */ 
/* 705 */     PathSynth obj = new PathSynth(boundary, obstacles);
/* 706 */     obj.dumpPolygonsAndArcs("test1");
/* 707 */     log.info("");
/*     */   }
/*     */ 
/*     */   private static void test2() {
/* 711 */     log.info("PathSynth.main: Starting test2");
/*     */ 
/* 713 */     List corners = new LinkedList();
/* 714 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 715 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 716 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 717 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 718 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*     */ 
/* 720 */     List obstacles = new LinkedList();
/* 721 */     corners = new LinkedList();
/* 722 */     corners.add(new AOVector(500.0F, 0.0F, 250.0F));
/* 723 */     corners.add(new AOVector(750.0F, 0.0F, 500.0F));
/* 724 */     corners.add(new AOVector(500.0F, 0.0F, 750.0F));
/* 725 */     corners.add(new AOVector(250.0F, 0.0F, 500.0F));
/* 726 */     obstacles.add(new PathPolygon(0, 1, corners));
/*     */ 
/* 728 */     PathSynth obj = new PathSynth(boundary, obstacles);
/* 729 */     obj.dumpPolygonsAndArcs("test2");
/* 730 */     log.info("");
/*     */   }
/*     */ 
/*     */   private static void test3() {
/* 734 */     log.info("PathSynth.main: Starting test3");
/*     */ 
/* 736 */     List corners = new LinkedList();
/* 737 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 738 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 739 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 740 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 741 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*     */ 
/* 743 */     List obstacles = new LinkedList();
/* 744 */     corners = new LinkedList();
/* 745 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 746 */     corners.add(new AOVector(400.0F, 0.0F, 200.0F));
/* 747 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 748 */     corners.add(new AOVector(800.0F, 0.0F, 500.0F));
/* 749 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 750 */     corners.add(new AOVector(500.0F, 0.0F, 800.0F));
/* 751 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 752 */     corners.add(new AOVector(200.0F, 0.0F, 400.0F));
/* 753 */     obstacles.add(new PathPolygon(0, 1, corners));
/*     */ 
/* 755 */     PathSynth obj = new PathSynth(boundary, obstacles);
/* 756 */     obj.dumpPolygonsAndArcs("test3");
/* 757 */     log.info("");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 765 */     Properties props = new Properties();
/* 766 */     props.put("log4j.appender.FILE", "org.apache.log4j.RollingFileAppender");
/* 767 */     props.put("log4j.appender.FILE.File", "${atavism.logs}/pathing.out");
/* 768 */     props.put("log4j.appender.FILE.MaxFileSize", "50MB");
/* 769 */     props.put("log4j.appender.FILE.layout", "org.apache.log4j.PatternLayout");
/* 770 */     props.put("log4j.appender.FILE.layout.ConversionPattern", "%-5p %m%n");
/* 771 */     props.put("atavism.log_level", "0");
/* 772 */     props.put("log4j.rootLogger", "DEBUG, FILE");
/* 773 */     Log.init(props);
/*     */ 
/* 775 */     test1();
/* 776 */     test2();
/* 777 */     test3();
/*     */   }
/*     */ 
/*     */   public static class HullLine
/*     */   {
/*     */     public PathSynth.HullPoint hullPoint1;
/*     */     public PathSynth.HullPoint hullPoint2;
/*     */ 
/*     */     public HullLine(PathSynth.HullPoint hullPoint1, PathSynth.HullPoint hullPoint2)
/*     */     {
/* 297 */       this.hullPoint1 = hullPoint1;
/* 298 */       this.hullPoint2 = hullPoint2;
/*     */     }
/*     */ 
/*     */     public AOVector point1() {
/* 302 */       return this.hullPoint1.point;
/*     */     }
/*     */ 
/*     */     public AOVector point2() {
/* 306 */       return this.hullPoint2.point;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class HullPoint
/*     */   {
/*     */     public int cornerNumber;
/*     */     public AOVector point;
/*     */     public PathPolygon polygon;
/*     */ 
/*     */     public HullPoint(int cornerNumber, AOVector point, PathPolygon polygon)
/*     */     {
/* 277 */       this.cornerNumber = cornerNumber;
/* 278 */       this.point = point;
/* 279 */       this.polygon = polygon;
/* 280 */       if (cornerNumber >= polygon.getCorners().size())
/* 281 */         PathSynth.log.error("HullLine constructor: cornerNumber1 " + cornerNumber + " is beyond poly1.corners.size() " + polygon.getCorners().size());
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathSynth
 * JD-Core Version:    0.6.0
 */