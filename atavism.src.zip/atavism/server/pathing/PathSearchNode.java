/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PathSearchNode
/*     */ {
/*  10 */   protected static int closeEnough = 100;
/*     */   protected PathArc arc;
/*     */   protected int polyIndex;
/*     */   protected PathSearchNode predecessor;
/*     */   protected AOVector loc;
/*     */   protected int costSoFar;
/*     */   protected int costToGoal;
/* 158 */   protected static final Logger log = new Logger("PathSearchNode");
/* 159 */   protected static boolean logAll = false;
/*     */ 
/*     */   public PathSearchNode(int polyIndex, AOVector loc)
/*     */   {
/*  15 */     this.polyIndex = polyIndex;
/*  16 */     this.loc = loc;
/*     */   }
/*     */ 
/*     */   public PathSearchNode(AOVector loc, PathSearchNode predecessor)
/*     */   {
/*  22 */     this.loc = loc;
/*  23 */     this.predecessor = predecessor;
/*     */   }
/*     */ 
/*     */   public PathSearchNode(PathArc arc, int polyIndex, PathSearchNode predecessor)
/*     */   {
/*  29 */     this.polyIndex = polyIndex;
/*  30 */     this.arc = arc;
/*  31 */     this.predecessor = predecessor;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/*  35 */     return this.costSoFar == ((PathSearchNode)obj).costSoFar;
/*     */   }
/*     */ 
/*     */   public AOVector getLoc() {
/*  39 */     return this.loc;
/*     */   }
/*     */ 
/*     */   public void setLoc(AOVector value) {
/*  43 */     this.loc = value;
/*     */   }
/*     */ 
/*     */   public int getPolyIndex() {
/*  47 */     return this.polyIndex;
/*     */   }
/*     */ 
/*     */   public int distanceEstimate(PathSearchNode goal) {
/*  51 */     return (int)AOVector.distanceTo(this.loc, goal.getLoc());
/*     */   }
/*     */ 
/*     */   public boolean atGoal(PathSearchNode goal) {
/*  55 */     return this.polyIndex == goal.getPolyIndex();
/*     */   }
/*     */ 
/*     */   protected List<PathSearchNode> getSuccessors(PathAStarSearcher searcher)
/*     */   {
/*  61 */     List nodes = new LinkedList();
/*  62 */     for (PathArc arc : searcher.getPolygonArcs(this.polyIndex)) {
/*  63 */       int poly1Index = arc.getPoly1Index();
/*  64 */       int poly2Index = arc.getPoly2Index();
/*     */       int otherPolyIndex;
/*     */       int otherPolyIndex;
/*  66 */       if (this.polyIndex == poly2Index)
/*  67 */         otherPolyIndex = poly1Index;
/*     */       else
/*  69 */         otherPolyIndex = arc.getPoly2Index();
/*  70 */       if ((this.predecessor == null) || (otherPolyIndex != this.predecessor.getPolyIndex())) {
/*  71 */         PathSearchNode successor = new PathSearchNode(arc, otherPolyIndex, this);
/*  72 */         nodes.add(successor);
/*  73 */         if (logAll)
/*  74 */           log.debug(new StringBuilder().append("getSuccessors: arc = ").append(arc.shortString()).append("; successor = ").append(successor).toString());
/*     */       }
/*     */     }
/*  77 */     if (logAll)
/*  78 */       log.debug(new StringBuilder().append("getSuccessors: returning ").append(nodes.size()).append(" successors").toString());
/*  79 */     return nodes;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  83 */     return new StringBuilder().append("[PathSearchNode  polyIndex = ").append(this.polyIndex).append("; loc = ").append(this.loc).append("; arc = ").append(this.arc).append("; costSoFar = ").append(this.costSoFar).append("; costToGoal = ").append(this.costToGoal).append("]").toString();
/*     */   }
/*     */ 
/*     */   public String shortString()
/*     */   {
/*  88 */     return new StringBuilder().append("[PathSearchNode  polyIndex = ").append(this.polyIndex).append("; loc = ").append(this.loc).append("; arc = ").append(this.arc == null ? "null" : this.arc.shortString()).append("; costSoFar = ").append(this.costSoFar).append("; costToGoal = ").append(this.costToGoal).append("]").toString();
/*     */   }
/*     */ 
/*     */   protected boolean isSameState(PathSearchNode node)
/*     */   {
/*  94 */     return node.getPolyIndex() == this.polyIndex;
/*     */   }
/*     */ 
/*     */   protected int getCostBetween(PathSearchNode successor)
/*     */   {
/* 103 */     AOVector startLoc = this.arc == null ? this.loc : this.arc.getEdge().getMidpoint();
/* 104 */     PathArc sarc = successor.getArc();
/* 105 */     AOVector endLoc = sarc == null ? successor.getLoc() : sarc.getEdge().getMidpoint();
/* 106 */     return (int)AOVector.distanceTo(startLoc, endLoc);
/*     */   }
/*     */ 
/*     */   public PathArc getArc() {
/* 110 */     return this.arc;
/*     */   }
/*     */ 
/*     */   public void setArc(PathArc arc) {
/* 114 */     this.arc = arc;
/*     */   }
/*     */ 
/*     */   public void setPredecessor(PathSearchNode node) {
/* 118 */     this.predecessor = node;
/*     */   }
/*     */ 
/*     */   public PathSearchNode getPredecessor() {
/* 122 */     return this.predecessor;
/*     */   }
/*     */ 
/*     */   public void setCostSoFar(int cost) {
/* 126 */     this.costSoFar = cost;
/*     */   }
/*     */ 
/*     */   public int getCostSoFar() {
/* 130 */     return this.costSoFar;
/*     */   }
/*     */ 
/*     */   public void setCostToGoal(int cost) {
/* 134 */     this.costToGoal = cost;
/*     */   }
/*     */ 
/*     */   public int getCostToGoal() {
/* 138 */     return this.costToGoal;
/*     */   }
/*     */ 
/*     */   public int getCostToEnd() {
/* 142 */     return this.costSoFar + this.costToGoal;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathSearchNode
 * JD-Core Version:    0.6.0
 */