/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import atavism.server.engine.Locatable;
/*    */ import atavism.server.engine.MobilePerceiver;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.engine.QuadTreeElement;
/*    */ import atavism.server.engine.QuadTreeNode;
/*    */ import atavism.server.math.Point;
/*    */ 
/*    */ public class PathModelElement
/*    */   implements QuadTreeElement<PathModelElement>, Locatable
/*    */ {
/*    */   protected PathObject pathObject;
/* 70 */   private transient QuadTreeNode<PathModelElement> node = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PathModelElement(PathObject pathObject)
/*    */   {
/*  9 */     this.pathObject = pathObject;
/*    */   }
/*    */ 
/*    */   public Object getQuadTreeObject()
/*    */   {
/* 14 */     return this.pathObject;
/*    */   }
/*    */ 
/*    */   public QuadTreeNode<PathModelElement> getQuadNode() {
/* 18 */     return this.node;
/*    */   }
/*    */ 
/*    */   public void setQuadNode(QuadTreeNode<PathModelElement> node) {
/* 22 */     this.node = node;
/*    */   }
/*    */ 
/*    */   public int getPerceptionRadius() {
/* 26 */     return this.pathObject.getRadius();
/*    */   }
/*    */ 
/*    */   public int getObjectRadius() {
/* 30 */     return this.pathObject.getRadius();
/*    */   }
/*    */ 
/*    */   public MobilePerceiver<PathModelElement> getPerceiver()
/*    */   {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   public void setPerceiver(MobilePerceiver<PathModelElement> p)
/*    */   {
/*    */   }
/*    */ 
/*    */   public OID getInstanceOid() {
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */   public Point getLoc()
/*    */   {
/* 49 */     return new Point(this.pathObject.getCenter());
/*    */   }
/*    */ 
/*    */   public Point getCurrentLoc() {
/* 53 */     return new Point(this.pathObject.getCenter());
/*    */   }
/*    */ 
/*    */   public void setLoc(Point p)
/*    */   {
/*    */   }
/*    */ 
/*    */   public long getLastUpdate()
/*    */   {
/* 62 */     return 0L;
/*    */   }
/*    */ 
/*    */   public void setLastUpdate(long value)
/*    */   {
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathModelElement
 * JD-Core Version:    0.6.0
 */