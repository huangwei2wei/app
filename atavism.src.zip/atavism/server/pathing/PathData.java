/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PathData
/*    */   implements Serializable, Cloneable
/*    */ {
/*    */   int version;
/*    */   List<PathObject> pathObjects;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PathData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PathData(int version, List<PathObject> pathObjects)
/*    */   {
/* 16 */     this.version = version;
/* 17 */     this.pathObjects = pathObjects;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 21 */     return "[PathData " + this.pathObjects.size() + " path objects]";
/*    */   }
/*    */ 
/*    */   public Object clone() {
/* 25 */     return new PathData(this.version, getPathObjects());
/*    */   }
/*    */ 
/*    */   public int getVersion() {
/* 29 */     return this.version;
/*    */   }
/*    */ 
/*    */   public List<PathObject> getPathObjects() {
/* 33 */     return this.pathObjects;
/*    */   }
/*    */ 
/*    */   public PathObject getPathObjectForType(String type) {
/* 37 */     for (PathObject pathObject : this.pathObjects) {
/* 38 */       if (pathObject.getType().equals(type))
/* 39 */         return pathObject;
/*    */     }
/* 41 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathData
 * JD-Core Version:    0.6.0
 */