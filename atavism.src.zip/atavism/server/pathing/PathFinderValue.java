/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import atavism.server.math.AOVector;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PathFinderValue
/*    */ {
/*    */   protected PathSearcher.PathResult result;
/*    */   protected List<AOVector> path;
/*    */   protected String terrainString;
/*    */ 
/*    */   public PathFinderValue(PathSearcher.PathResult result, List<AOVector> path, String terrainString)
/*    */   {
/* 12 */     this.result = result;
/* 13 */     this.path = path;
/* 14 */     this.terrainString = terrainString;
/*    */   }
/*    */ 
/*    */   public PathSearcher.PathResult getResult() {
/* 18 */     return this.result;
/*    */   }
/*    */ 
/*    */   public void setResult(PathSearcher.PathResult result) {
/* 22 */     this.result = result;
/*    */   }
/*    */ 
/*    */   public List<AOVector> getPath() {
/* 26 */     return this.path;
/*    */   }
/*    */ 
/*    */   public String getTerrainString() {
/* 30 */     return this.terrainString;
/*    */   }
/*    */ 
/*    */   public void setTerrainString(String terrainString) {
/* 34 */     this.terrainString = terrainString;
/*    */   }
/*    */ 
/*    */   public void addTerrainChar(char ch) {
/*    */   }
/*    */ 
/*    */   public void addPathElement(AOVector loc) {
/* 41 */     assert (this.path.size() == 0);
/* 42 */     this.path.add(loc);
/*    */   }
/*    */ 
/*    */   public int pathElementCount() {
/* 46 */     return this.path.size();
/*    */   }
/*    */ 
/*    */   public void addPathElement(AOVector loc, boolean overTerrain) {
/* 50 */     assert (this.path.size() == this.terrainString.length());
/* 51 */     this.path.add(loc);
/* 52 */     this.terrainString = new StringBuilder().append(this.terrainString).append(overTerrain ? 'T' : 'C').toString();
/*    */   }
/*    */ 
/*    */   public void removePathElementsAfter(int pathSize) {
/* 56 */     for (int i = this.path.size() - 1; i >= pathSize; i--)
/* 57 */       this.path.remove(i);
/* 58 */     this.terrainString = this.terrainString.substring(0, pathSize);
/*    */   }
/*    */ 
/*    */   String stringPath(int firstElt) {
/* 62 */     String s = "";
/* 63 */     for (int i = firstElt; i < this.path.size(); i++) {
/* 64 */       AOVector p = (AOVector)this.path.get(i);
/* 65 */       if (s.length() > 0)
/* 66 */         s = new StringBuilder().append(s).append(", ").toString();
/* 67 */       s = new StringBuilder().append(s).append("#").append(i).append(": ").append(this.terrainString.charAt(i)).append(p).toString();
/*    */     }
/* 69 */     return s;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathFinderValue
 * JD-Core Version:    0.6.0
 */