/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class PathAStarSearcher
/*     */ {
/*     */   protected TreeSet<PathSearchNode> openPrioritySet;
/*     */   protected Map<Integer, PathSearchNode> openStates;
/*     */   protected Map<Integer, PathSearchNode> closedStates;
/*     */   protected int iterations;
/*     */   protected PathSearchNode start;
/*     */   protected PathSearchNode goal;
/*     */   protected PathObject pathObject;
/* 292 */   protected static final Logger log = new Logger("PathAStarSearcher");
/* 293 */   protected static boolean logAll = false;
/*     */ 
/*     */   public PathAStarSearcher(PathObject pathObject)
/*     */   {
/*  26 */     this.pathObject = pathObject;
/*     */   }
/*     */ 
/*     */   public static boolean findPathInModel(PathFinderValue value, PathObjectLocation poLoc1, PathObjectLocation poLoc2, float halfWidth)
/*     */   {
/*  43 */     PathAStarSearcher astar = new PathAStarSearcher(poLoc1.getPathObject());
/*  44 */     AOVector loc1 = poLoc1.getLoc();
/*  45 */     AOVector loc2 = poLoc2.getLoc();
/*     */ 
/*  47 */     int index = poLoc1.getPolyIndex();
/*  48 */     boolean terrainPoint = poLoc1.getPathObject().isTerrainPolygon(index);
/*  49 */     if (index == poLoc2.getPolyIndex()) {
/*  50 */       if (Log.loggingDebug)
/*  51 */         log.debug("findPathInModel: start and end polygon index are the same, so success!");
/*  52 */       value.addPathElement(loc1, terrainPoint);
/*  53 */       value.addPathElement(loc2, terrainPoint);
/*  54 */       return true;
/*     */     }
/*  56 */     log.debug("findPathInModel: about to call aStarSearch");
/*  57 */     PathSearchNode node = astar.aStarSearch(poLoc1.getPolyIndex(), loc1, poLoc2.getPolyIndex(), loc2);
/*     */ 
/*  59 */     int i = value.pathElementCount();
/*  60 */     boolean result = astar.createPath(value, poLoc1.getPathObject(), loc2, halfWidth, node);
/*  61 */     if (Log.loggingDebug)
/*  62 */       log.debug("findPathInModel from " + loc1 + " to " + loc2 + ": " + value.stringPath(i));
/*  63 */     return result;
/*     */   }
/*     */ 
/*     */   protected boolean createPath(PathFinderValue value, PathObject po, AOVector loc2, float halfWidth, PathSearchNode goal) {
/*  67 */     if (goal == null)
/*  68 */       return false;
/*  69 */     List reversePath = new LinkedList();
/*  70 */     List reversePolygonIndexes = new LinkedList();
/*     */ 
/*  72 */     reversePath.add(goal.getLoc());
/*  73 */     reversePolygonIndexes.add(Integer.valueOf(goal.getPolyIndex()));
/*  74 */     PathSearchNode node = goal;
/*  75 */     while (node != null) {
/*  76 */       int nodePolygonIndex = node.getPolyIndex();
/*  77 */       if (logAll)
/*  78 */         log.debug("createPath: node = " + node.shortString());
/*  79 */       PathSearchNode next = node.getPredecessor();
/*     */ 
/*  81 */       if (next == null) {
/*  82 */         reversePath.add(node.getLoc());
/*  83 */         reversePolygonIndexes.add(Integer.valueOf(nodePolygonIndex));
/*  84 */         break;
/*     */       }
/*  86 */       PathArc arc = node.getArc();
/*  87 */       AOVector lastPoint = (AOVector)reversePath.get(reversePath.size() - 1);
/*  88 */       AOVector nextPoint = next.getArc() != null ? next.getArc().getEdge().getMidpoint() : loc2;
/*  89 */       if (arc != null)
/*     */       {
/*  99 */         AOVector p = arc.getEdge().bestPoint(lastPoint, nextPoint, halfWidth);
/* 100 */         if (logAll) {
/* 101 */           log.debug("createPath: bestPoint = " + p + "; lastPoint = " + lastPoint + "; nextPoint = " + nextPoint + "; arc = " + arc);
/*     */         }
/* 103 */         reversePath.add(p);
/* 104 */         reversePolygonIndexes.add(Integer.valueOf(nodePolygonIndex));
/*     */       }
/*     */       else {
/* 107 */         log.error("For intermediate node " + node + ", no arc was found!");
/* 108 */         return false;
/*     */       }
/* 110 */       node = next;
/*     */     }
/* 112 */     for (int i = reversePath.size() - 1; i >= 0; i--) {
/* 113 */       AOVector p = (AOVector)reversePath.get(i);
/* 114 */       int nodePolyIndex = ((Integer)reversePolygonIndexes.get(i)).intValue();
/* 115 */       boolean terrainPolygon = po.isTerrainPolygon(nodePolyIndex);
/* 116 */       if (logAll)
/* 117 */         log.debug("createPath: adding point = " + p + "; over terrain = " + Boolean.toString(terrainPolygon));
/* 118 */       value.addPathElement(p, terrainPolygon);
/*     */     }
/* 120 */     return true;
/*     */   }
/*     */ 
/*     */   protected PathSearchNode aStarSearch(int poly1, AOVector loc1, int poly2, AOVector loc2)
/*     */   {
/* 141 */     if (Log.loggingDebug)
/* 142 */       log.debug("aStarSearch poly1 = " + poly1 + "; loc1 = " + loc1 + "; poly2 = " + poly2 + "; loc2 = " + loc2);
/* 143 */     this.goal = new PathSearchNode(poly2, loc2);
/*     */ 
/* 146 */     if (poly1 == poly2)
/* 147 */       return this.goal;
/* 148 */     this.openPrioritySet = new TreeSet(new PathSearchNodeCostComparator());
/* 149 */     this.openStates = new HashMap();
/* 150 */     this.closedStates = new HashMap();
/* 151 */     this.start = new PathSearchNode(poly1, loc1);
/* 152 */     this.start.setCostToGoal(this.start.distanceEstimate(this.goal));
/* 153 */     this.openStates.put(Integer.valueOf(this.start.getPolyIndex()), this.start);
/* 154 */     this.openPrioritySet.add(this.start);
/* 155 */     if (logAll)
/* 156 */       log.debug("aStarSearch start = " + this.start.shortString() + "; goal = " + this.goal.shortString());
/* 157 */     SearchState state = SearchState.Running;
/*     */     do
/*     */     {
/* 160 */       state = iterate();
/* 161 */       this.iterations += 1;
/*     */     }
/* 163 */     while (state == SearchState.Running);
/* 164 */     return state == SearchState.Succeeded ? this.goal : null;
/*     */   }
/*     */ 
/*     */   protected SearchState iterate() {
/* 168 */     if (logAll)
/* 169 */       log.debug("iterate: openStates.size() = " + this.openStates.size() + "; openPrioritySet.size() = " + this.openPrioritySet.size());
/* 170 */     if (this.openStates.size() == 0) {
/* 171 */       return SearchState.Failed;
/*     */     }
/*     */ 
/* 174 */     PathSearchNode current = (PathSearchNode)this.openPrioritySet.first();
/* 175 */     if (logAll)
/* 176 */       log.debug("iterate: current = " + current.shortString() + "; iterations = " + this.iterations);
/* 177 */     this.openPrioritySet.remove(current);
/* 178 */     this.openStates.remove(Integer.valueOf(current.getPolyIndex()));
/* 179 */     if (current.isSameState(this.goal)) {
/* 180 */       if (Log.loggingDebug) {
/* 181 */         log.debug("iterate: Succeeded, because current = " + current.shortString() + " same as goal = " + this.goal.shortString());
/*     */       }
/* 183 */       current.setLoc(this.goal.getLoc());
/* 184 */       this.goal = current;
/* 185 */       dumpStateSet("openStates successor loop", this.openStates);
/* 186 */       dumpStateSet("closedStates successor loop", this.closedStates);
/* 187 */       return SearchState.Succeeded;
/*     */     }
/* 189 */     List successors = current.getSuccessors(this);
/* 190 */     for (PathSearchNode successor : successors) {
/* 191 */       if (logAll) {
/* 192 */         dumpStateSet("openStates successor loop", this.openStates);
/* 193 */         dumpStateSet("closedStates successor loop", this.closedStates);
/*     */       }
/* 195 */       int cost = current.getCostSoFar() + current.getCostBetween(successor);
/* 196 */       int index = successor.getPolyIndex();
/* 197 */       if (logAll)
/* 198 */         log.debug("iterate: successor = " + successor.shortString() + "; cost = " + cost);
/* 199 */       PathSearchNode openElement = null;
/* 200 */       PathSearchNode closedElement = null;
/* 201 */       if (this.openStates.containsKey(Integer.valueOf(index))) {
/* 202 */         openElement = (PathSearchNode)this.openStates.get(Integer.valueOf(index));
/* 203 */         if (openElement.getCostSoFar() <= cost) {
/* 204 */           if (logAll) {
/* 205 */             log.debug("iterate: Ignoring successor, because openElement = " + openElement.shortString() + " cost < " + cost); continue;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 210 */       if (this.closedStates.containsKey(Integer.valueOf(index))) {
/* 211 */         closedElement = (PathSearchNode)this.closedStates.get(Integer.valueOf(index));
/* 212 */         if (closedElement.getCostSoFar() < cost) {
/* 213 */           if (logAll) {
/* 214 */             log.debug("iterate: Ignoring successor, because closedElement = " + closedElement.shortString() + " cost < " + cost); continue;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 219 */         this.closedStates.remove(closedElement);
/*     */       }
/* 221 */       if (openElement != null)
/*     */       {
/* 225 */         if (logAll) {
/* 226 */           log.debug("iterate: Successor index = " + index + " found in openStates, so replacing openElement cost = " + openElement.getCostSoFar() + " with current cost = " + cost);
/*     */         }
/*     */ 
/* 229 */         this.openPrioritySet.remove(openElement);
/* 230 */         openElement.setCostSoFar(cost);
/* 231 */         openElement.setPredecessor(current);
/* 232 */         this.openPrioritySet.add(openElement);
/*     */       }
/*     */       else {
/* 235 */         successor.setCostSoFar(cost);
/* 236 */         if (logAll) {
/* 237 */           log.debug("iterate: About to add successor current = " + current.getPolyIndex() + "; openStates.size() = " + this.openStates.size() + "; openPrioritySet.size() = " + this.openPrioritySet.size());
/*     */         }
/*     */ 
/* 240 */         this.openStates.put(Integer.valueOf(successor.getPolyIndex()), successor);
/* 241 */         this.openPrioritySet.add(successor);
/* 242 */         if (logAll) {
/* 243 */           log.debug("iterate: Added successor current = " + current.getPolyIndex() + "; openStates.size() = " + this.openStates.size() + "; openPrioritySet.size() = " + this.openPrioritySet.size());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 249 */     this.closedStates.put(Integer.valueOf(current.getPolyIndex()), current);
/* 250 */     if (logAll) {
/* 251 */       log.debug("iterate: Added current = " + current.shortString() + " to closedStates, whose size is " + this.closedStates.size());
/*     */     }
/* 253 */     return SearchState.Running;
/*     */   }
/*     */ 
/*     */   void dumpStateSet(String which, Map<Integer, PathSearchNode> states) {
/* 257 */     String s = "dumpStateSet: set " + which + "; ";
/* 258 */     Iterator iter = states.entrySet().iterator();
/*     */ 
/* 260 */     while (iter.hasNext()) {
/* 261 */       Map.Entry entry = (Map.Entry)iter.next();
/* 262 */       s = s + "[" + entry.getKey() + ": ";
/* 263 */       String e = "";
/* 264 */       PathSearchNode n = (PathSearchNode)entry.getValue();
/*     */       do {
/* 266 */         if (e.length() > 0)
/* 267 */           e = e + ">";
/* 268 */         e = e + n.getPolyIndex();
/* 269 */         n = n.getPredecessor();
/* 270 */       }while (n != null);
/* 271 */       s = s + e + "] ";
/*     */     }
/* 273 */     log.debug(s);
/*     */   }
/*     */ 
/*     */   List<PathArc> getPolygonArcs(int polyIndex) {
/* 277 */     return this.pathObject.getPolygonArcs(polyIndex);
/*     */   }
/*     */ 
/*     */   protected class PathSearchNodeCostComparator
/*     */     implements Comparator
/*     */   {
/*     */     public PathSearchNodeCostComparator()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int compare(Object n1, Object n2)
/*     */     {
/* 128 */       PathSearchNode s1 = (PathSearchNode)n1;
/* 129 */       PathSearchNode s2 = (PathSearchNode)n2;
/* 130 */       int cost1 = s1.costSoFar;
/* 131 */       int cost2 = s2.costSoFar;
/* 132 */       return s1.getPolyIndex() == s2.getPolyIndex() ? 0 : s1.getPolyIndex() < s2.getPolyIndex() ? -1 : cost1 > cost2 ? 1 : cost1 < cost2 ? -1 : 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum SearchState
/*     */   {
/*  30 */     Running(0), 
/*  31 */     Succeeded(1), 
/*  32 */     Failed(2);
/*     */ 
/*  36 */     byte val = -1;
/*     */ 
/*     */     private SearchState(byte val)
/*     */     {
/*  34 */       this.val = val;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathAStarSearcher
 * JD-Core Version:    0.6.0
 */