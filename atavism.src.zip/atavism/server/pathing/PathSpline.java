/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PathSpline extends PathInterpolator
/*     */ {
/* 129 */   protected final float directionTimeOffset = 0.1F;
/*     */   protected float[] timeVector;
/*     */   protected float totalTime;
/* 144 */   protected static Logger log = new Logger("PathSpline");
/* 145 */   protected static boolean logAll = false;
/*     */ 
/*     */   public PathSpline(OID oid, long startTime, float speed, String terrainString, List<Point> path)
/*     */   {
/*  16 */     super(oid, startTime, speed, terrainString, path);
/*     */ 
/*  19 */     path.add(0, path.get(0));
/*  20 */     path.add(path.get(path.size() - 1));
/*  21 */     path.add(path.get(path.size() - 1));
/*  22 */     int count = path.size();
/*  23 */     this.timeVector = new float[count];
/*  24 */     this.timeVector[0] = 0.0F;
/*  25 */     float t = 0.0F;
/*  26 */     AOVector curr = new AOVector((Point)path.get(0));
/*  27 */     for (int i = 1; i < count; i++) {
/*  28 */       AOVector next = new AOVector((Point)path.get(i));
/*  29 */       float diff = AOVector.distanceTo(curr, next);
/*  30 */       t += diff / speed;
/*  31 */       this.timeVector[i] = t;
/*  32 */       curr = next;
/*     */     }
/*  34 */     this.totalTime = t;
/*  35 */     if (Log.loggingDebug)
/*  36 */       log.debug("PathSpline constructor: oid = " + oid + "; timeVector = " + this.timeVector + "; timeVector.length = " + this.timeVector.length + "; path = " + path + "; speed = " + speed);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  41 */     return "[PathSpline oid = " + this.oid + "; speed = " + this.speed + "; timeVector = " + this.timeVector + "; path = " + this.path + "]";
/*     */   }
/*     */ 
/*     */   public PathLocAndDir interpolate(float t)
/*     */   {
/*  47 */     if (t < 0.0F)
/*  48 */       t = 0.0F;
/*  49 */     else if (t >= this.totalTime) {
/*  50 */       return null;
/*     */     }
/*  52 */     int count = this.path.size();
/*     */ 
/*  56 */     int pointNumber = -2;
/*  57 */     for (int i = 0; i < count; i++) {
/*  58 */       if (this.timeVector[i] > t) {
/*  59 */         pointNumber = i - 1;
/*  60 */         break;
/*     */       }
/*     */     }
/*  63 */     if (pointNumber == -1) {
/*  64 */       log.error("interpolateSpline: Time t " + t + " passed to interpolateSpline < 0; oid = " + this.oid);
/*  65 */       pointNumber = 1;
/*     */     }
/*     */     AOVector dir;
/*     */     AOVector loc;
/*     */     AOVector dir;
/*  71 */     if (pointNumber == -2) {
/*  72 */       AOVector loc = new AOVector((Point)this.path.get(count - 1));
/*  73 */       dir = new AOVector(0.0F, 0.0F, 0.0F);
/*     */     }
/*     */     else {
/*  76 */       float timeAtPoint = this.timeVector[pointNumber];
/*  77 */       float timeSincePoint = t - timeAtPoint;
/*  78 */       float timeFraction = timeSincePoint / (this.timeVector[(pointNumber + 1)] - timeAtPoint);
/*  79 */       loc = evalPoint(pointNumber, timeFraction);
/*  80 */       dir = AOVector.multiply(evalDirection(loc, pointNumber, timeFraction), this.speed);
/*     */     }
/*     */ 
/*  86 */     int pathNumber = pointNumber == -2 ? count - 4 : pointNumber - 1;
/*  87 */     if ((this.terrainString.charAt(pathNumber) == 'T') || (this.terrainString.charAt(pathNumber + 1) == 'T')) {
/*  88 */       loc.setY(0.0F);
/*  89 */       dir.setY(0.0F);
/*     */     }
/*  91 */     if (logAll)
/*  92 */       log.debug("interpolateSpline: oid = " + this.oid + "; t = " + t + "; loc = " + loc + "; dir = " + dir);
/*  93 */     return new PathLocAndDir(new Point(loc), dir, this.speed * Math.max(0.0F, this.totalTime - t));
/*     */   }
/*     */ 
/*     */   protected float basisFactor(int degree, float t)
/*     */   {
/*  98 */     switch (degree) {
/*     */     case -1:
/* 100 */       return ((-t + 2.0F) * t - 1.0F) * t / 2.0F;
/*     */     case 0:
/* 102 */       return ((3.0F * t - 5.0F) * t * t + 2.0F) / 2.0F;
/*     */     case 1:
/* 104 */       return ((-3.0F * t + 4.0F) * t + 1.0F) * t / 2.0F;
/*     */     case 2:
/* 106 */       return (t - 1.0F) * t * t / 2.0F;
/*     */     }
/* 108 */     log.error("interpolateSpline: Invalid basis index " + degree + " specified! - oid = " + this.oid);
/* 109 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   protected AOVector evalPoint(int pointNumber, float t)
/*     */   {
/* 115 */     float px = 0.0F;
/* 116 */     float py = 0.0F;
/* 117 */     float pz = 0.0F;
/* 118 */     for (int degree = -1; degree <= 2; degree++) {
/* 119 */       float basis = basisFactor(degree, t);
/* 120 */       Point pathPoint = (Point)this.path.get(pointNumber + degree);
/* 121 */       px += basis * pathPoint.getX();
/* 122 */       py += basis * pathPoint.getY();
/* 123 */       pz += basis * pathPoint.getZ();
/*     */     }
/* 125 */     return new AOVector(px, py, pz);
/*     */   }
/*     */ 
/*     */   protected AOVector evalDirection(AOVector p, int pointNumber, float t)
/*     */   {
/* 134 */     AOVector next = evalPoint(pointNumber, t + 0.1F);
/* 135 */     next.sub(p);
/* 136 */     next.setY(0.0F);
/* 137 */     next.normalize();
/* 138 */     return next;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathSpline
 * JD-Core Version:    0.6.0
 */