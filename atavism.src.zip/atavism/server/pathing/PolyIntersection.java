/*    */ package atavism.server.pathing;
/*    */ 
/*    */ public class PolyIntersection
/*    */ {
/*    */   public int poly1Corner;
/*    */   public int poly2Corner;
/*    */   public PathIntersection intr;
/*    */ 
/*    */   public PolyIntersection(int poly1Corner, int poly2Corner, PathIntersection intr)
/*    */   {
/*  8 */     this.poly1Corner = poly1Corner;
/*  9 */     this.poly2Corner = poly2Corner;
/* 10 */     this.intr = intr;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PolyIntersection
 * JD-Core Version:    0.6.0
 */