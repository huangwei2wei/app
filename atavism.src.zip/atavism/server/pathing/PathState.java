/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.plugins.WorldManagerClient.MobPathReqMessage;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PathState
/*     */ {
/*     */   protected OID oid;
/*     */   protected String type;
/*     */   protected boolean linear;
/*     */   protected Point startLoc;
/*     */   protected Point endLoc;
/*     */   protected float speed;
/*     */   protected List<Point> path;
/*     */   protected PathInterpolator pathInterpolator;
/*     */   protected long startTime;
/* 176 */   protected static final Logger log = new Logger("PathState");
/* 177 */   protected static boolean logAll = false;
/*     */ 
/*     */   public PathState(OID oid, String type, boolean linear)
/*     */   {
/*  17 */     this.oid = oid;
/*  18 */     this.type = type;
/*  19 */     this.linear = linear;
/*  20 */     clear();
/*     */   }
/*     */ 
/*     */   public PathState(OID oid, long startTime, String type, Point startLoc, Point endLoc, float speed) {
/*  24 */     this.oid = oid;
/*  25 */     this.startTime = startTime;
/*  26 */     this.type = type;
/*  27 */     this.startLoc = startLoc;
/*  28 */     this.endLoc = endLoc;
/*  29 */     this.speed = speed;
/*  30 */     this.path = null;
/*  31 */     this.pathInterpolator = null;
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  35 */     if (Log.loggingDebug)
/*  36 */       log.debug("clear: oid = " + this.oid);
/*  37 */     this.startTime = 0L;
/*  38 */     this.startLoc = null;
/*  39 */     this.endLoc = null;
/*  40 */     this.speed = 0.0F;
/*  41 */     this.path = null;
/*  42 */     this.pathInterpolator = null;
/*     */   }
/*     */ 
/*     */   public WorldManagerClient.MobPathReqMessage setupPathInterpolator(long timeNow, Point newStartLoc, Point newEndLoc, float newSpeed, boolean following, float followDistance, boolean followsTerrain)
/*     */   {
/*  49 */     this.startTime = timeNow;
/*  50 */     this.startLoc = newStartLoc;
/*  51 */     this.endLoc = newEndLoc;
/*  52 */     this.speed = newSpeed;
/*  53 */     PathFinderValue value = PathSearcher.findPath(this.type, new AOVector(this.startLoc), new AOVector(this.endLoc), followsTerrain);
/*  54 */     PathSearcher.PathResult result = value.getResult();
/*  55 */     List floatingPath = value.getPath();
/*     */ 
/*  57 */     this.path = new LinkedList();
/*  58 */     for (AOVector pathPoint : floatingPath)
/*  59 */       this.path.add(new Point(pathPoint));
/*  60 */     int count = this.path.size();
/*     */ 
/*  63 */     if ((following) && (count >= 2)) {
/*  64 */       Point p1 = (Point)this.path.get(count - 2);
/*  65 */       Point p2 = (Point)this.path.get(count - 1);
/*  66 */       float len = Point.distanceTo(p1, p2);
/*  67 */       float newLen = Math.max(followDistance, len - followDistance);
/*  68 */       if (newLen > len)
/*     */       {
/*  70 */         this.path.set(count - 1, new Point(p1));
/*     */       } else {
/*  72 */         AOVector newp2 = new AOVector(p2);
/*  73 */         newp2.sub(p1);
/*  74 */         newp2.setY(0.0F);
/*  75 */         newp2.normalize();
/*  76 */         newp2.multiply(newLen);
/*  77 */         newp2.add(p1);
/*  78 */         this.path.set(count - 1, new Point(newp2));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  83 */     String terrainString = value.getTerrainString();
/*  84 */     if (Log.loggingDebug) {
/*  85 */       log.debug("setupPathInterpolator: findPath result = " + result.toString() + "; path.size() = " + this.path.size() + "; terrainString = " + terrainString);
/*     */     }
/*  87 */     if ((result == PathSearcher.PathResult.OK) && (this.path.size() >= 2)) {
/*  88 */       if (this.linear)
/*  89 */         this.pathInterpolator = new PathLinear(this.oid, timeNow, this.speed, terrainString, this.path);
/*     */       else {
/*  91 */         this.pathInterpolator = new PathSpline(this.oid, timeNow, this.speed, terrainString, this.path);
/*     */       }
/*  93 */       WorldManagerClient.MobPathReqMessage reqMsg = new WorldManagerClient.MobPathReqMessage(this.oid, this.startTime, this.linear ? "linear" : "spline", this.speed, terrainString, this.path);
/*     */ 
/*  95 */       if (Log.loggingDebug)
/*  96 */         log.debug("setupPathInterpolator: pathInterpolator = " + this.pathInterpolator);
/*  97 */       return reqMsg;
/*     */     }
/*     */ 
/* 100 */     this.path = null;
/* 101 */     this.pathInterpolator = null;
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */   public PathLocAndDir interpolatePath(long timeNow)
/*     */   {
/* 107 */     if (this.path == null) {
/* 108 */       return null;
/*     */     }
/* 110 */     float currentTime = (float)(timeNow - this.startTime) / 1000.0F;
/* 111 */     float t = currentTime == 0.0F ? 0.1F : currentTime;
/* 112 */     PathLocAndDir v = this.pathInterpolator.interpolate(t);
/* 113 */     if (logAll) {
/* 114 */       if (v != null) {
/* 115 */         if (Log.loggingDebug)
/* 116 */           log.debug("interpolatePath: t = " + t + "; loc = " + v.getLoc() + "; dir = " + v.getDir());
/*     */       }
/* 118 */       else if (Log.loggingDebug)
/* 119 */         log.debug("interpolatePath: t = " + t + "; PathLocAndDir is null");
/*     */     }
/* 121 */     return v;
/*     */   }
/*     */ 
/*     */   public long pathTimeRemaining()
/*     */   {
/* 126 */     if (this.pathInterpolator != null) {
/* 127 */       long timeSinceStart = System.currentTimeMillis() - this.startTime;
/* 128 */       return ()(this.pathInterpolator.getTotalTime() * 1000.0F) + timeSinceStart;
/*     */     }
/*     */ 
/* 131 */     return 0L;
/*     */   }
/*     */ 
/*     */   public OID getOid() {
/* 135 */     return this.oid;
/*     */   }
/*     */ 
/*     */   public String getType() {
/* 139 */     return this.type;
/*     */   }
/*     */ 
/*     */   public Point getStartLoc() {
/* 143 */     return this.startLoc;
/*     */   }
/*     */ 
/*     */   public Point getEndLoc() {
/* 147 */     return this.endLoc;
/*     */   }
/*     */ 
/*     */   public float getSpeed() {
/* 151 */     return this.speed;
/*     */   }
/*     */ 
/*     */   public List<Point> getPath() {
/* 155 */     return this.path;
/*     */   }
/*     */ 
/*     */   public PathInterpolator getPathInterpolator() {
/* 159 */     return this.pathInterpolator;
/*     */   }
/*     */ 
/*     */   public long getStartTime() {
/* 163 */     return this.startTime;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathState
 * JD-Core Version:    0.6.0
 */