/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class PathObjectType
/*    */   implements Serializable, Cloneable
/*    */ {
/*    */   private String name;
/*    */   private float height;
/*    */   private float width;
/*    */   private float maxClimbSlope;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PathObjectType()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PathObjectType(String name, float height, float width, float maxClimbSlope)
/*    */   {
/* 15 */     this.name = name;
/* 16 */     this.height = height;
/* 17 */     this.width = width;
/* 18 */     this.maxClimbSlope = maxClimbSlope;
/*    */   }
/*    */ 
/*    */   public Object clone() {
/* 22 */     return new PathObjectType(this.name, this.height, this.width, this.maxClimbSlope);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 26 */     return this.name;
/*    */   }
/*    */ 
/*    */   public float getHeight() {
/* 30 */     return this.height;
/*    */   }
/*    */ 
/*    */   public float getWidth() {
/* 34 */     return this.width;
/*    */   }
/*    */ 
/*    */   public float getMaxClimbSlope() {
/* 38 */     return this.maxClimbSlope;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathObjectType
 * JD-Core Version:    0.6.0
 */