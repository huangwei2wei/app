/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class PathObject
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   String modelName;
/*     */   String type;
/*     */   int firstTerrainIndex;
/*     */   PathPolygon boundingPolygon;
/*     */   List<PathPolygon> polygons;
/*     */   List<PathArc> portals;
/*     */   List<PathArc> arcs;
/* 373 */   Map<Integer, List<PathArc>> polygonArcs = null;
/* 374 */   Map<Integer, PathPolygon> polygonMap = null;
/* 375 */   LinkedList<PathPolygon> terrainPolygonAtCorner = null;
/*     */   protected static float insideDistance;
/*     */   protected static final Logger log;
/*     */   protected static boolean logAll;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public PathObject()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PathObject(String modelName, String type, int firstTerrainIndex, PathPolygon boundingPolygon, List<PathPolygon> polygons, List<PathArc> portals, List<PathArc> arcs)
/*     */   {
/*  24 */     this.modelName = modelName;
/*  25 */     this.type = type;
/*  26 */     this.firstTerrainIndex = firstTerrainIndex;
/*  27 */     this.boundingPolygon = boundingPolygon;
/*  28 */     this.polygons = polygons;
/*  29 */     this.portals = portals;
/*  30 */     this.arcs = arcs;
/*     */ 
/*  32 */     for (PathArc arc : this.portals)
/*  33 */       this.arcs.add(arc);
/*  34 */     findTerrainPolygonsAtCorners();
/*     */   }
/*     */ 
/*     */   public PathObject(String description, float avatarWidth, List<AOVector> boundaryCorners, List<List<AOVector>> obstacleCorners)
/*     */   {
/*  42 */     PathPolygon boundary = new PathPolygon(0, 1, boundaryCorners).ensureWindingOrder(true);
/*  43 */     List obstacles = new LinkedList();
/*  44 */     for (List corners : obstacleCorners) {
/*  45 */       obstacles.add(new PathPolygon(0, 1, corners).ensureWindingOrder(false));
/*     */     }
/*     */ 
/*  53 */     Triangulate triangulator = new Triangulate();
/*  54 */     List triangles = triangulator.computeTriangulation(description, boundary, obstacles);
/*     */ 
/*  57 */     this.polygons = aggregateTriangles(triangles);
/*     */ 
/*  60 */     this.arcs = discoverArcs(this.polygons);
/*     */   }
/*     */ 
/*     */   protected static List<PathPolygon> aggregateTriangles(List<PathPolygon> triangles)
/*     */   {
/*  67 */     List polys = new LinkedList();
/*  68 */     while (triangles.size() > 0) { PathPolygon poly = (PathPolygon)triangles.remove(0);
/*  70 */       polys.add(poly);
/*  71 */       List polyCorners = poly.getCorners();
/*  72 */       boolean foundOne = false;
/*     */       label297: 
/*     */       do { foundOne = false;
/*  75 */         int polySize = polyCorners.size();
/*     */         AOVector pcCorner1;
/*     */         int pcPlus;
/*     */         AOVector pcCorner2;
/*  77 */         for (int pc = 0; pc < polySize; pc++) {
/*  78 */           pcCorner1 = (AOVector)polyCorners.get(pc);
/*  79 */           pcPlus = PathSynth.wrap(pc + 1, polySize);
/*  80 */           pcCorner2 = (AOVector)polyCorners.get(pcPlus);
/*  81 */           for (PathPolygon triangle : triangles) {
/*  82 */             List triCorners = triangle.getCorners();
/*  83 */             for (int tc = 0; tc < 3; tc++) {
/*  84 */               AOVector triCorner1 = (AOVector)triCorners.get(tc);
/*  85 */               int tcPlus = PathSynth.wrap(tc + 1, 3);
/*  86 */               AOVector triCorner2 = (AOVector)triCorners.get(tcPlus);
/*  87 */               AOVector triCorner3 = (AOVector)triCorners.get(PathSynth.wrap(tc + 2, 3));
/*  88 */               if (((AOVector.distanceToSquared(pcCorner1, triCorner1) >= 1.0F) || (AOVector.distanceToSquared(pcCorner2, triCorner2) >= 1.0F)) && ((AOVector.distanceToSquared(pcCorner2, triCorner1) >= 1.0F) || (AOVector.distanceToSquared(pcCorner1, triCorner2) >= 1.0F) || (!AOVector.counterClockwisePoints(pcCorner1, triCorner3, pcCorner2))))
/*     */               {
/*     */                 continue;
/*     */               }
/*     */ 
/*  94 */               foundOne = true;
/*  95 */               polyCorners.add(pcPlus, triCorner3);
/*  96 */               break label297;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 102 */       while (foundOne);
/*     */     }
/*     */ 
/* 105 */     int i = 1;
/* 106 */     for (PathPolygon poly : polys)
/* 107 */       poly.setIndex(i++);
/* 108 */     return polys;
/*     */   }
/*     */ 
/*     */   protected static List<PathArc> discoverArcs(List<PathPolygon> polygons)
/*     */   {
/* 116 */     int s = polygons.size();
/* 117 */     List arcs = new LinkedList();
/* 118 */     for (int p1 = 0; p1 < s; p1++) {
/* 119 */       PathPolygon poly1 = (PathPolygon)polygons.get(p1);
/* 120 */       List corners1 = poly1.getCorners();
/* 121 */       int size1 = corners1.size();
/* 122 */       for (int pc1 = 0; pc1 < size1; pc1++) {
/* 123 */         AOVector corner11 = (AOVector)corners1.get(pc1);
/* 124 */         int pc1Plus = PathSynth.wrap(pc1 + 1, size1);
/* 125 */         AOVector corner12 = (AOVector)corners1.get(pc1Plus);
/* 126 */         for (int p2 = p1 + 1; p2 < s; p2++) {
/* 127 */           PathPolygon poly2 = (PathPolygon)polygons.get(p2);
/* 128 */           List corners2 = poly2.getCorners();
/* 129 */           int size2 = corners2.size();
/* 130 */           for (int pc2 = 0; pc2 < size2; pc2++) {
/* 131 */             AOVector corner21 = (AOVector)corners2.get(pc2);
/* 132 */             int pc2Plus = PathSynth.wrap(pc2 + 1, size2);
/* 133 */             AOVector corner22 = (AOVector)corners2.get(pc2Plus);
/* 134 */             if (((AOVector.distanceToSquared(corner11, corner21) >= 1.0F) || (AOVector.distanceToSquared(corner12, corner22) >= 1.0F)) && ((AOVector.distanceToSquared(corner12, corner21) >= 1.0F) || (AOVector.distanceToSquared(corner11, corner22) >= 1.0F)))
/*     */             {
/*     */               continue;
/*     */             }
/*     */ 
/* 143 */             PathEdge edge = new PathEdge(corner11, corner12);
/* 144 */             PathArc arc1 = new PathArc(1, poly1.getIndex(), poly2.getIndex(), edge);
/* 145 */             PathArc arc2 = new PathArc(1, poly2.getIndex(), poly1.getIndex(), edge);
/* 146 */             arcs.add(arc1);
/* 147 */             arcs.add(arc2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 153 */     return arcs;
/*     */   }
/*     */ 
/*     */   protected void findTerrainPolygonsAtCorners() {
/* 157 */     List corners = this.boundingPolygon.getCorners();
/* 158 */     int count = corners.size();
/* 159 */     this.terrainPolygonAtCorner = new LinkedList();
/* 160 */     for (int i = 0; i < count; i++) {
/* 161 */       AOVector corner = (AOVector)corners.get(i);
/* 162 */       for (PathPolygon polygon : this.polygons) {
/* 163 */         if (polygon.getKind() != 2)
/*     */           continue;
/* 165 */         List pcorners = polygon.getCorners();
/* 166 */         int pcount = pcorners.size();
/* 167 */         for (int j = 0; j < pcount; j++) {
/* 168 */           AOVector c = (AOVector)pcorners.get(j);
/* 169 */           float dx = corner.getX() - c.getX();
/* 170 */           float dz = corner.getZ() - c.getZ();
/*     */ 
/* 174 */           if (dx * dx + dz * dz < 50.0F) {
/* 175 */             this.terrainPolygonAtCorner.add(polygon);
/*     */ 
/* 178 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 182 */       if (this.terrainPolygonAtCorner.get(i) == null)
/* 183 */         log.error("findTerrainPolygonsAtCorners: could not find terrain polygon for corner " + i);
/*     */     }
/*     */   }
/*     */ 
/*     */   public PathPolygon getCVPolygon(int polyIndex) {
/* 188 */     PathPolygon polygon = getPolygon(polyIndex);
/* 189 */     if ((polygon != null) && 
/* 190 */       (!$assertionsDisabled) && (polygon.getKind() != 1)) throw new AssertionError();
/* 191 */     return polygon;
/*     */   }
/*     */ 
/*     */   public PathPolygon getTerrainPolygon(int polyIndex) {
/* 195 */     PathPolygon polygon = getPolygon(polyIndex);
/* 196 */     if ((polygon != null) && 
/* 197 */       (!$assertionsDisabled) && (polygon.getKind() != 2)) throw new AssertionError();
/* 198 */     return polygon;
/*     */   }
/*     */ 
/*     */   public boolean isTerrainPolygon(int polyIndex) {
/* 202 */     PathPolygon polygon = getPolygon(polyIndex);
/* 203 */     if (polygon == null) {
/* 204 */       log.error("polygonTerrainStringChar: no polygon at index " + polyIndex);
/* 205 */       return true;
/*     */     }
/*     */ 
/* 208 */     return polygon.getKind() == 2;
/*     */   }
/*     */ 
/*     */   public PathPolygon getTerrainPolygonAtCorner(int cornerNumber) {
/* 212 */     return (PathPolygon)this.terrainPolygonAtCorner.get(cornerNumber);
/*     */   }
/*     */ 
/*     */   public int getClosestCornerToPoint(AOVector loc)
/*     */   {
/* 217 */     return this.boundingPolygon.getClosestCornerToPoint(loc);
/*     */   }
/*     */ 
/*     */   public PathPolygon getPolygon(int polyIndex)
/*     */   {
/* 222 */     if (this.polygonMap == null)
/* 223 */       createPolygonMap();
/* 224 */     if (this.polygonMap.containsKey(Integer.valueOf(polyIndex))) {
/* 225 */       return (PathPolygon)this.polygonMap.get(Integer.valueOf(polyIndex));
/*     */     }
/* 227 */     return null;
/*     */   }
/*     */ 
/*     */   protected void createPolygonMap() {
/* 231 */     this.polygonMap = new HashMap();
/* 232 */     for (PathPolygon polygon : this.polygons)
/* 233 */       this.polygonMap.put(Integer.valueOf(polygon.getIndex()), polygon);
/*     */   }
/*     */ 
/*     */   public int findCVPolygonAtLocation(AOVector loc)
/*     */   {
/* 239 */     AOVector floc = new AOVector(loc);
/* 240 */     for (PathPolygon polygon : this.polygons) {
/* 241 */       if ((polygon.getKind() == 1) && (polygon.pointInside(floc, insideDistance)))
/* 242 */         return polygon.getIndex();
/*     */     }
/* 244 */     return -1;
/*     */   }
/*     */ 
/*     */   public int findTerrainPolygonAtLocation(AOVector loc)
/*     */   {
/* 250 */     AOVector floc = new AOVector(loc);
/* 251 */     for (PathPolygon polygon : this.polygons) {
/* 252 */       if ((polygon.getKind() == 2) && (polygon.pointInside(floc, insideDistance)))
/* 253 */         return polygon.getIndex();
/*     */     }
/* 255 */     return -1;
/*     */   }
/*     */ 
/*     */   public PathIntersection closestIntersection(AOVector loc1, AOVector loc2)
/*     */   {
/* 261 */     PathIntersection closest = null;
/* 262 */     for (PathPolygon cvPoly : this.polygons) {
/* 263 */       if (cvPoly.getKind() != 1)
/*     */         continue;
/* 265 */       PathIntersection intersection = cvPoly.closestIntersection(this, loc1, loc2);
/* 266 */       if (intersection == null)
/*     */         continue;
/* 268 */       if ((closest == null) || (intersection.getWhere1() < closest.getWhere1()))
/* 269 */         closest = intersection;
/*     */     }
/* 271 */     return closest;
/*     */   }
/*     */ 
/*     */   public List<PathArc> getPolygonArcs(int polyIndex) {
/* 275 */     if (logAll) {
/* 276 */       log.debug("getPolygonArcs: Entering");
/*     */     }
/* 278 */     if (this.polygonArcs == null) {
/* 279 */       this.polygonArcs = new HashMap();
/* 280 */       for (PathArc arc : this.arcs) {
/* 281 */         addToArcMap(this.polygonArcs, arc, arc.getPoly1Index());
/* 282 */         addToArcMap(this.polygonArcs, arc, arc.getPoly2Index());
/*     */       }
/*     */     }
/* 285 */     if (this.polygonArcs.containsKey(Integer.valueOf(polyIndex))) {
/* 286 */       List parcs = (List)this.polygonArcs.get(Integer.valueOf(polyIndex));
/* 287 */       if (logAll)
/* 288 */         log.debug("getPolygonArcs: returning parcs.size() = " + parcs.size());
/* 289 */       return parcs;
/*     */     }
/*     */ 
/* 292 */     return null;
/*     */   }
/*     */ 
/*     */   private void addToArcMap(Map<Integer, List<PathArc>> polygonArcs, PathArc arc, int polyIndex) {
/* 296 */     List parcs = null;
/* 297 */     if (!polygonArcs.containsKey(Integer.valueOf(polyIndex))) {
/* 298 */       parcs = new LinkedList();
/* 299 */       polygonArcs.put(Integer.valueOf(polyIndex), parcs);
/*     */     }
/*     */     else {
/* 302 */       parcs = (List)polygonArcs.get(Integer.valueOf(polyIndex));
/* 303 */     }parcs.add(arc);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 307 */     return "[PathObject modelName=" + getModelName() + "; type=" + this.type + "; boundingPolygon = " + this.boundingPolygon + "]";
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 312 */     return new PathObject(getModelName(), getType(), getFirstTerrainIndex(), this.boundingPolygon, getPolygons(), getPortals(), getArcs());
/*     */   }
/*     */ 
/*     */   public String getModelName()
/*     */   {
/* 317 */     return this.modelName;
/*     */   }
/*     */ 
/*     */   public String getType() {
/* 321 */     return this.type;
/*     */   }
/*     */ 
/*     */   public int getFirstTerrainIndex() {
/* 325 */     return this.firstTerrainIndex;
/*     */   }
/*     */ 
/*     */   public AOVector getCenter() {
/* 329 */     List corners = this.boundingPolygon.getCorners();
/* 330 */     AOVector ll = (AOVector)corners.get(0);
/* 331 */     AOVector ur = (AOVector)corners.get(2);
/* 332 */     AOVector center = new AOVector((ll.getX() + ur.getX()) * 0.5F, (ll.getY() + ur.getY()) * 0.5F, (ll.getZ() + ur.getZ()) * 0.5F);
/*     */ 
/* 335 */     if (logAll)
/* 336 */       log.debug("getCenter: center = " + center);
/* 337 */     return center;
/*     */   }
/*     */ 
/*     */   public int getRadius() {
/* 341 */     List corners = this.boundingPolygon.getCorners();
/* 342 */     AOVector ll = (AOVector)corners.get(0);
/* 343 */     AOVector ur = (AOVector)corners.get(2);
/* 344 */     int radius = (int)(AOVector.distanceTo(ll, ur) / 2.0F);
/* 345 */     if (logAll)
/* 346 */       log.debug("getRadius: pathObject = " + this + "; radius = " + radius);
/* 347 */     return radius;
/*     */   }
/*     */ 
/*     */   public PathPolygon getBoundingPolygon() {
/* 351 */     return this.boundingPolygon;
/*     */   }
/*     */ 
/*     */   public List<PathPolygon> getPolygons() {
/* 355 */     return this.polygons;
/*     */   }
/*     */ 
/*     */   public List<PathArc> getPortals() {
/* 359 */     return this.portals;
/*     */   }
/*     */ 
/*     */   public List<PathArc> getArcs() {
/* 363 */     return this.arcs;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 380 */     insideDistance = 100.0F;
/*     */ 
/* 382 */     log = new Logger("PathObject");
/* 383 */     logAll = false;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathObject
 * JD-Core Version:    0.6.0
 */