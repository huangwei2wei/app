/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import atavism.server.math.AOVector;
/*    */ 
/*    */ public class PathObjectLocation
/*    */ {
/*    */   protected PathObject pathObject;
/*    */   protected AOVector loc;
/*    */   protected byte kind;
/*    */   protected int polyIndex;
/*    */ 
/*    */   public PathObjectLocation(PathObject pathObject, AOVector loc, byte kind, int polyIndex)
/*    */   {
/*  9 */     this.pathObject = pathObject;
/* 10 */     this.loc = loc;
/* 11 */     this.kind = kind;
/* 12 */     this.polyIndex = polyIndex;
/*    */   }
/*    */ 
/*    */   public PathObject getPathObject() {
/* 16 */     return this.pathObject;
/*    */   }
/*    */ 
/*    */   public AOVector getLoc() {
/* 20 */     return this.loc;
/*    */   }
/*    */ 
/*    */   public byte getKind() {
/* 24 */     return this.kind;
/*    */   }
/*    */ 
/*    */   public int getPolyIndex() {
/* 28 */     return this.polyIndex;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 32 */     return "[PathObjectLocation loc = " + this.loc + "; kind = " + this.kind + "; polyIndex = " + this.polyIndex + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathObjectLocation
 * JD-Core Version:    0.6.0
 */