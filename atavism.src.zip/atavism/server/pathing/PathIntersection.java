/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ 
/*     */ public class PathIntersection
/*     */ {
/*     */   protected PathObject pathObject;
/* 130 */   protected PathPolygon cvPoly = null;
/*     */   protected float where1;
/*     */   protected float where2;
/*     */   protected AOVector line1;
/*     */   protected AOVector line2;
/*     */ 
/*     */   public PathIntersection(PathObject pathObject, float where1, float where2, AOVector line1, AOVector line2)
/*     */   {
/*  13 */     this.pathObject = pathObject;
/*  14 */     this.where1 = where1;
/*  15 */     this.where2 = where2;
/*  16 */     this.line1 = line1;
/*  17 */     this.line2 = line2;
/*     */   }
/*     */ 
/*     */   public PathIntersection(PathObject pathObject, PathPolygon cvPoly, float where1, float where2, AOVector line1, AOVector line2)
/*     */   {
/*  22 */     this.pathObject = pathObject;
/*  23 */     this.cvPoly = cvPoly;
/*  24 */     this.where1 = where1;
/*  25 */     this.where2 = where2;
/*  26 */     this.line1 = line1;
/*  27 */     this.line2 = line2;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  31 */     return "[PathIntersecton line1 = " + this.line1 + " line2 = " + this.line2 + " where1 = " + this.where1 + " where2 = " + this.where2 + "; cvPoly = " + this.cvPoly + " pathObject = " + this.pathObject;
/*     */   }
/*     */ 
/*     */   public static PathIntersection findIntersection(AOVector s1, AOVector e1, AOVector s2, AOVector e2)
/*     */   {
/*  37 */     return findIntersection(null, s1.getX(), s1.getZ(), e1.getX() - s1.getX(), e1.getZ() - s1.getZ(), s2.getX(), s2.getZ(), e2.getX() - s2.getX(), e2.getZ() - s2.getZ());
/*     */   }
/*     */ 
/*     */   public static PathIntersection findIntersection(PathObject pathObject, float start1x, float start1z, float disp1x, float disp1z, float start2x, float start2z, float disp2x, float disp2z)
/*     */   {
/*  54 */     float det = disp2x * disp1z - disp2z * disp1x;
/*  55 */     float diffx = start2x - start1x;
/*  56 */     float diffz = start2z - start1z;
/*  57 */     if (det * det > 1.0F) {
/*  58 */       float invDet = 1.0F / det;
/*  59 */       float where1 = (disp2x * diffz - disp2z * diffx) * invDet;
/*  60 */       float where2 = (disp1x * diffz - disp1z * diffx) * invDet;
/*  61 */       if ((where1 >= 0.0F) && (where1 <= 1.0F) && (where2 >= 0.0F) && (where2 <= 1.0F))
/*     */       {
/*  63 */         return new PathIntersection(pathObject, where1, where2, new AOVector(start2x, 0.0F, start2z), new AOVector(start2x + disp2x, 0.0F, start2z + disp2z));
/*     */       }
/*     */     }
/*     */ 
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   public static PathIntersection findIntersection(PathObject pathObject, PathPolygon cvPoly, float start1x, float start1z, float disp1x, float disp1z, float start2x, float start2z, float disp2x, float disp2z)
/*     */   {
/*  75 */     PathIntersection i = findIntersection(pathObject, start1x, start1z, disp1x, disp1z, start2x, start2z, disp2x, disp2z);
/*     */ 
/*  77 */     if (i != null)
/*  78 */       i.setCVPoly(cvPoly);
/*  79 */     return i;
/*     */   }
/*     */ 
/*     */   public static float distancePointLine(AOVector p, AOVector line1, AOVector line2) {
/*  83 */     float line1x = line1.getX();
/*  84 */     float line1z = line1.getZ();
/*  85 */     float line2x = line2.getX();
/*  86 */     float line2z = line2.getZ();
/*  87 */     float linedx = line2x - line1x;
/*  88 */     float linedz = line2z - line1z;
/*  89 */     float numer = Math.abs(linedx * (line1z - p.getZ()) - (line1x - p.getX()) * linedz);
/*  90 */     float denom = (float)Math.sqrt(linedx * linedx + linedz * linedz);
/*  91 */     return numer / denom;
/*     */   }
/*     */ 
/*     */   public PathObject getPathObject()
/*     */   {
/*  96 */     return this.pathObject;
/*     */   }
/*     */ 
/*     */   public PathPolygon getCVPoly() {
/* 100 */     return this.cvPoly;
/*     */   }
/*     */ 
/*     */   public void setCVPoly(PathPolygon cvPoly) {
/* 104 */     this.cvPoly = cvPoly;
/*     */   }
/*     */ 
/*     */   public float getWhere1() {
/* 108 */     return this.where1;
/*     */   }
/*     */ 
/*     */   public float getWhere2() {
/* 112 */     return this.where2;
/*     */   }
/*     */ 
/*     */   public static AOVector getLinePoint(float where, AOVector loc1, AOVector loc2) {
/* 116 */     AOVector diff = AOVector.sub(loc2, loc1);
/* 117 */     return AOVector.add(loc1, diff.multiply(where));
/*     */   }
/*     */ 
/*     */   public AOVector getIntersectorPoint(float where) {
/* 121 */     AOVector diff = AOVector.sub(this.line2, this.line1);
/* 122 */     return AOVector.add(this.line2, diff.multiply(where));
/*     */   }
/*     */ 
/*     */   public float getIntersectorLength() {
/* 126 */     return AOVector.distanceTo(this.line1, this.line2);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathIntersection
 * JD-Core Version:    0.6.0
 */