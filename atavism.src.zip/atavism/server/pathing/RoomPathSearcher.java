/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RoomPathSearcher
/*     */ {
/* 109 */   static boolean logAll = true;
/* 110 */   protected static final Logger log = new Logger("RoomPathSearcher");
/*     */ 
/*     */   public static List<AOVector> findPathInRoom(AOVector loc1, AOVector loc2, Quaternion endOrientation, PathPolygon room, List<PathPolygon> obstacles, float playerWidth)
/*     */   {
/*  25 */     float halfWidth = playerWidth * 0.5F;
/*  26 */     List path = new LinkedList();
/*  27 */     path.add(loc1);
/*  28 */     AOVector next = loc1;
/*     */ 
/*  33 */     int limit = 100;
/*  34 */     for (int i = 0; i < limit; i++) {
/*  35 */       PathIntersection intersection = findFirstObstacle(next, loc2, room, obstacles);
/*  36 */       if (intersection == null)
/*     */         break;
/*  38 */       next = findPathAroundObstacle(intersection, next, loc2, room, halfWidth);
/*  39 */       if (next == null)
/*  40 */         return path;
/*  41 */       path.add(next);
/*     */     }
/*  43 */     return path;
/*     */   }
/*     */ 
/*     */   protected static PathIntersection findFirstObstacle(AOVector loc1, AOVector loc2, PathPolygon room, List<PathPolygon> obstacles)
/*     */   {
/*  50 */     if (logAll)
/*  51 */       log.debug(new StringBuilder().append("findFirstObstacle: loc1 = ").append(loc1).append("; loc2 = ").append(loc2).toString());
/*  52 */     List elems = getElementsBetween(loc1, loc2, obstacles);
/*  53 */     if (logAll)
/*  54 */       log.debug(new StringBuilder().append("findFirstObstacle: elems = ").append(elems == null ? elems : Integer.valueOf(elems.size())).toString());
/*  55 */     if ((elems == null) || (elems.size() == 0))
/*  56 */       return null;
/*     */     while (true) {
/*  58 */       PathIntersection closest = null;
/*  59 */       PathPolygon closestElem = null;
/*  60 */       for (PathPolygon elem : elems) {
/*  61 */         if (logAll)
/*  62 */           log.debug(new StringBuilder().append("findFirstObstacle elem = ").append(elem).toString());
/*  63 */         PathIntersection intersection = elem.closestIntersection(null, loc1, loc2);
/*     */ 
/*  65 */         if ((intersection != null) && ((closest == null) || (intersection.getWhere1() < closest.getWhere1())))
/*     */         {
/*  67 */           closest = intersection;
/*  68 */           closestElem = elem;
/*     */         }
/*     */       }
/*  71 */       if (closest == null)
/*  72 */         return null;
/*  73 */       PathIntersection pathObjectClosest = closestElem.closestIntersection(null, loc1, loc2);
/*  74 */       if (pathObjectClosest != null) {
/*  75 */         if (logAll)
/*  76 */           log.debug(new StringBuilder().append("findFirstObstacle: pathObjectClosest = ").append(pathObjectClosest).toString());
/*  77 */         return pathObjectClosest;
/*     */       }
/*     */ 
/*  80 */       elems.remove(closestElem);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static AOVector findPathAroundObstacle(PathIntersection intersection, AOVector loc1, AOVector loc2, PathPolygon room, float halfWidth)
/*     */   {
/*  87 */     PathPolygon poly = intersection.getCVPoly();
/*  88 */     int corner1 = poly.getClosestCornerToPoint(loc1);
/*  89 */     AOVector cornerPoint1 = (AOVector)poly.getCorners().get(corner1);
/*  90 */     int corner2 = poly.getClosestCornerToPoint(loc2);
/*  91 */     AOVector endPoint = (AOVector)poly.getCorners().get(corner2);
/*  92 */     if (logAll) {
/*  93 */       log.debug(new StringBuilder().append("findPathAroundObstacle: loc1 = ").append(loc1).append("; corner1 = ").append(corner1).append("; cornerPoint1 = ").append(cornerPoint1).append("; loc2 = ").append(loc2).append("; endPoint = ").append(endPoint).append("; endPoint = ").append(endPoint).toString());
/*     */     }
/*     */ 
/*  97 */     return endPoint;
/*     */   }
/*     */ 
/*     */   protected static List<PathPolygon> getElementsBetween(AOVector loc1, AOVector loc2, List<PathPolygon> obstacles) {
/* 101 */     List intersectors = new LinkedList();
/* 102 */     for (PathPolygon poly : obstacles) {
/* 103 */       if (poly.closestIntersection(null, loc1, loc2) != null)
/* 104 */         intersectors.add(poly);
/*     */     }
/* 106 */     return intersectors;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.RoomPathSearcher
 * JD-Core Version:    0.6.0
 */