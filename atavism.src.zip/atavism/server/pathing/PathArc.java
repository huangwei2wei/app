/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class PathArc
/*    */   implements Serializable, Cloneable
/*    */ {
/*    */   public static final byte Illegal = 0;
/*    */   public static final byte CVToCV = 1;
/*    */   public static final byte TerrainToTerrain = 2;
/*    */   public static final byte CVToTerrain = 3;
/*    */   int poly1Index;
/*    */   int poly2Index;
/*    */   byte arcKind;
/*    */   PathEdge edge;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PathArc()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PathArc(byte arcKind, int poly1Index, int poly2Index, PathEdge edge)
/*    */   {
/* 15 */     this.arcKind = arcKind;
/* 16 */     this.poly1Index = poly1Index;
/* 17 */     this.poly2Index = poly2Index;
/* 18 */     this.edge = edge;
/*    */   }
/*    */ 
/*    */   public String formatArcKind(byte val)
/*    */   {
/* 27 */     switch (val) {
/*    */     case 0:
/* 29 */       return "Illegal";
/*    */     case 1:
/* 31 */       return "CVToCV";
/*    */     case 2:
/* 33 */       return "TerrainToTerrain";
/*    */     case 3:
/* 35 */       return "CVToTerrain";
/*    */     }
/* 37 */     return "Unknown ArcKind " + val;
/*    */   }
/*    */ 
/*    */   public static byte parseArcKind(String s)
/*    */   {
/* 42 */     if (s.equals("Illegal"))
/* 43 */       return 0;
/* 44 */     if (s.equals("CVToCV"))
/* 45 */       return 1;
/* 46 */     if (s.equals("TerrainToTerrain"))
/* 47 */       return 2;
/* 48 */     if (s.equals("CVToTerrain")) {
/* 49 */       return 3;
/*    */     }
/* 51 */     return 0;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 55 */     return "[PathArc kind=" + formatArcKind(this.arcKind) + ",poly1Index=" + getPoly1Index() + ",poly2Index=" + getPoly2Index() + ",edge=" + getEdge() + "]";
/*    */   }
/*    */ 
/*    */   public String shortString()
/*    */   {
/* 60 */     return getPoly1Index() + ":" + getPoly2Index();
/*    */   }
/*    */ 
/*    */   public Object clone() {
/* 64 */     return new PathArc(getKind(), getPoly1Index(), getPoly2Index(), getEdge());
/*    */   }
/*    */ 
/*    */   public byte getKind() {
/* 68 */     return this.arcKind;
/*    */   }
/*    */ 
/*    */   public int getPoly1Index() {
/* 72 */     return this.poly1Index;
/*    */   }
/*    */ 
/*    */   public void setPoly1Index(int poly1Index) {
/* 76 */     this.poly1Index = poly1Index;
/*    */   }
/*    */ 
/*    */   public int getPoly2Index() {
/* 80 */     return this.poly2Index;
/*    */   }
/*    */ 
/*    */   public void setPoly2Index(int poly2Index) {
/* 84 */     this.poly2Index = poly2Index;
/*    */   }
/*    */ 
/*    */   public PathEdge getEdge() {
/* 88 */     return this.edge;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathArc
 * JD-Core Version:    0.6.0
 */