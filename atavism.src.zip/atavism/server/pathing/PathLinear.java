/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.math.Point;
/*    */ import atavism.server.util.Logger;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PathLinear extends PathInterpolator
/*    */ {
/*    */   protected float totalTime;
/* 66 */   protected static final Logger log = new Logger("PathLinear");
/* 67 */   protected static boolean logAll = false;
/*    */ 
/*    */   public PathLinear(OID oid, long startTime, float speed, String terrainString, List<Point> path)
/*    */   {
/* 13 */     super(oid, startTime, speed, terrainString, path);
/* 14 */     float cumm = 0.0F;
/* 15 */     Point curr = (Point)path.get(0);
/* 16 */     for (int i = 1; i < path.size(); i++) {
/* 17 */       Point next = (Point)path.get(i);
/* 18 */       float dist = Point.distanceTo(curr, next);
/* 19 */       float diffTime = dist / speed;
/* 20 */       cumm += diffTime;
/* 21 */       curr = next;
/*    */     }
/* 23 */     this.totalTime = cumm;
/*    */   }
/*    */ 
/*    */   public PathLocAndDir interpolate(float t)
/*    */   {
/* 29 */     if (logAll)
/* 30 */       log.debug("interpolate: t = " + t + "; totalTime = " + this.totalTime);
/* 31 */     if (t < 0.0F)
/* 32 */       t = 0.0F;
/* 33 */     else if (t >= this.totalTime)
/* 34 */       return null;
/* 35 */     float cumm = 0.0F;
/* 36 */     Point curr = (Point)this.path.get(0);
/* 37 */     for (int i = 1; i < this.path.size(); i++) {
/* 38 */       Point next = (Point)this.path.get(i);
/* 39 */       AOVector diff = new AOVector(zeroYIfOnTerrain(new AOVector(next).sub(curr), i - 1));
/* 40 */       float dist = diff.lengthXZ();
/* 41 */       float diffTime = dist / this.speed;
/* 42 */       if (t <= cumm + diffTime) {
/* 43 */         float frac = (t - cumm) / diffTime;
/* 44 */         AOVector loc = new AOVector(curr);
/* 45 */         loc.add(AOVector.multiply(diff, frac));
/* 46 */         Point iloc = new Point(loc);
/* 47 */         AOVector dir = diff;
/* 48 */         dir.normalize();
/* 49 */         dir.multiply(this.speed);
/* 50 */         return new PathLocAndDir(iloc, dir, this.speed * (this.totalTime - t));
/*    */       }
/* 52 */       cumm += diffTime;
/* 53 */       curr = next;
/*    */     }
/*    */ 
/* 57 */     return new PathLocAndDir((Point)this.path.get(this.path.size() - 1), new AOVector(0.0F, 0.0F, 0.0F), 0.0F);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 61 */     return "[PathLinear oid = " + this.oid + "; speed = " + this.speed + "; path = " + this.path + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathLinear
 * JD-Core Version:    0.6.0
 */