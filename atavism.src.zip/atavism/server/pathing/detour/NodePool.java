/*     */ package atavism.server.pathing.detour;
/*     */ 
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ 
/*     */ public class NodePool
/*     */ {
/*     */   public int MaxNodes;
/*     */   public int HashSize;
/*     */   private Node[] _nodes;
/*     */   private int[] _first;
/*     */   private int[] _next;
/*     */   private int _nodeCount;
/*     */ 
/*     */   public NodePool(int maxNodes, int hashSize)
/*     */   {
/*     */     try
/*     */     {
/*  18 */       if (hashSize != Helper.NextPow2(hashSize))
/*  19 */         throw new Exception("Hash size must be a power of 2");
/*  20 */       if (maxNodes <= 0)
/*  21 */         throw new Exception("Max nodes must be greater than 0");
/*     */     }
/*     */     catch (Exception e) {
/*  24 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  27 */     this.MaxNodes = maxNodes;
/*  28 */     this.HashSize = hashSize;
/*  29 */     this._nodes = new Node[maxNodes];
/*  30 */     for (int i = 0; i < maxNodes; i++)
/*     */     {
/*  32 */       this._nodes[i] = new Node();
/*     */     }
/*  34 */     this._next = new int[maxNodes];
/*  35 */     this._first = new int[hashSize];
/*     */ 
/*  37 */     for (int i = 0; i < hashSize; i++)
/*     */     {
/*  39 */       this._first[i] = Node.NullIdx;
/*     */     }
/*  41 */     for (int i = 0; i < maxNodes; i++)
/*     */     {
/*  43 */       this._next[i] = Node.NullIdx;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void Clear()
/*     */   {
/*  49 */     this._nodeCount = 0;
/*  50 */     for (int i = 0; i < this.HashSize; i++)
/*     */     {
/*  52 */       this._first[i] = Node.NullIdx;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Node GetNode(long id)
/*     */   {
/*  59 */     int bucket = (int)(Helper.HashRef(id) & this.HashSize - 1);
/*  60 */     int i = this._first[bucket];
/*  61 */     Node node = null;
/*  62 */     while (i != Node.NullIdx)
/*     */     {
/*  64 */       if (this._nodes[i].Id == id)
/*  65 */         return this._nodes[i];
/*  66 */       i = this._next[i];
/*     */     }
/*     */ 
/*  69 */     if (this._nodeCount >= this.MaxNodes) {
/*  70 */       return null;
/*     */     }
/*  72 */     i = this._nodeCount;
/*  73 */     this._nodeCount += 1;
/*     */ 
/*  75 */     node = this._nodes[i];
/*  76 */     node.PIdx = 0L;
/*  77 */     node.Cost = 0.0F;
/*  78 */     node.Total = 0.0F;
/*  79 */     node.Id = id;
/*  80 */     node.Flags = 0L;
/*     */ 
/*  82 */     this._next[i] = this._first[bucket];
/*  83 */     this._first[bucket] = i;
/*     */ 
/*  85 */     return node;
/*     */   }
/*     */ 
/*     */   public Node FindNode(long id)
/*     */   {
/*  91 */     int bucket = (int)(Helper.HashRef(id) & this.HashSize - 1);
/*  92 */     int i = this._first[bucket];
/*  93 */     while (i != Node.NullIdx)
/*     */     {
/*  95 */       if (this._nodes[i].Id == id)
/*  96 */         return this._nodes[i];
/*  97 */       i = this._next[i];
/*     */     }
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   public long GetNodeIdx(Node node)
/*     */   {
/* 104 */     if (node == null) return 0L;
/* 105 */     for (int i = 0; i < this._nodes.length; i++)
/*     */     {
/* 107 */       if (node == this._nodes[i])
/* 108 */         return i + 1;
/*     */     }
/* 110 */     return 0L;
/*     */   }
/*     */ 
/*     */   public Node GetNodeAtIdx(long idx)
/*     */   {
/* 115 */     if (idx <= 0L) return null;
/*     */ 
/* 117 */     return this._nodes[((int)idx - 1)];
/*     */   }
/*     */ 
/*     */   public int GetFirst(int bucket)
/*     */   {
/* 122 */     return this._first[bucket];
/*     */   }
/*     */ 
/*     */   public int GetNext(int i) {
/* 126 */     return this._next[i];
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.NodePool
 * JD-Core Version:    0.6.0
 */