/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class NavMeshParams
/*    */ {
/*    */   public float[] Orig;
/*    */   public float TileWidth;
/*    */   public float TileHeight;
/*    */   public int MaxTiles;
/*    */   public int MaxPolys;
/*    */ 
/*    */   public NavMeshParams()
/*    */   {
/* 21 */     this.Orig = new float[3];
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.NavMeshParams
 * JD-Core Version:    0.6.0
 */