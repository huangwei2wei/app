/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ import atavism.server.objects.Vector2;
/*    */ import java.util.EnumSet;
/*    */ 
/*    */ public class DetourNumericReturn
/*    */ {
/*    */   public int intValue;
/*    */   public float floatValue;
/*    */   public long longValue;
/*    */   public Boolean boolValue;
/*    */   public Vector2 vector2Value;
/* 13 */   public EnumSet<Status> status = EnumSet.noneOf(Status.class);
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.DetourNumericReturn
 * JD-Core Version:    0.6.0
 */