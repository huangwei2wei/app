/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class Node
/*    */ {
/*    */   public float[] Pos;
/*    */   public float Cost;
/*    */   public float Total;
/*    */   public long PIdx;
/*    */   public long Flags;
/*    */   public long Id;
/* 12 */   public static int NullIdx = -1;
/* 13 */   public static int NodeOpen = 1;
/* 14 */   public static int NodeClosed = 2;
/*    */ 
/*    */   public Node()
/*    */   {
/* 18 */     this.Pos = new float[3];
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.Node
 * JD-Core Version:    0.6.0
 */