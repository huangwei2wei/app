/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ 
/*    */ public class QueryData
/*    */ {
/*  7 */   public EnumSet<Status> Status = EnumSet.noneOf(Status.class);
/*    */   public Node LastBestNode;
/*    */   public float LastBestNodeCost;
/*    */   public long StartRef;
/*    */   public long EndRef;
/*    */   public float[] StartPos;
/*    */   public float[] EndPos;
/*    */   public QueryFilter Filter;
/*    */ 
/*    */   public QueryData()
/*    */   {
/* 18 */     this.StartPos = new float[3];
/* 19 */     this.EndPos = new float[3];
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.QueryData
 * JD-Core Version:    0.6.0
 */