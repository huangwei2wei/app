package atavism.server.pathing.detour;

public class SegInterval
{
  public long RefId;
  public short TMin;
  public short TMax;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.SegInterval
 * JD-Core Version:    0.6.0
 */