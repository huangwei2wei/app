/*      */ package atavism.server.pathing.detour;
/*      */ 
/*      */ import atavism.server.math.IntVector2;
/*      */ import atavism.server.objects.Vector2;
/*      */ import atavism.server.pathing.recast.Helper;
/*      */ import atavism.server.util.Log;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Random;
/*      */ 
/*      */ public class NavMeshQuery
/*      */ {
/*      */   public NodePool NodePool;
/*      */   public NavMesh NavMesh;
/*      */   public NodePool _tinyNodePool;
/*      */   public NodeQueue _openList;
/*      */   public QueryData _query;
/*   35 */   public static float HScale = 0.999F;
/*      */ 
/*   37 */   public static short StraightPathStart = 1;
/*   38 */   public static short StraightPathEnd = 2;
/*   39 */   public static short StraightPathOffMeshConnection = 4;
/*      */ 
/*   41 */   public static short StraightPathAreaCrossings = 1;
/*   42 */   public static short StraightPathAllCrossings = 2;
/*      */ 
/*      */   public Status Init(NavMesh navMesh, int maxNodes)
/*      */   {
/*   50 */     this.NavMesh = navMesh;
/*   51 */     if ((this.NodePool == null) || (this.NodePool.MaxNodes < maxNodes))
/*      */     {
/*   53 */       this.NodePool = new NodePool(maxNodes, (int)Helper.NextPow2(maxNodes / 4));
/*      */     }
/*      */     else
/*      */     {
/*   57 */       this.NodePool.Clear();
/*      */     }
/*      */ 
/*   60 */     if (this._tinyNodePool == null)
/*      */     {
/*   62 */       this._tinyNodePool = new NodePool(64, 32);
/*      */     }
/*      */     else
/*      */     {
/*   66 */       this._tinyNodePool.Clear();
/*      */     }
/*      */ 
/*   69 */     if ((this._openList == null) || (this._openList.Capacity < maxNodes))
/*      */     {
/*   71 */       this._openList = new NodeQueue(maxNodes);
/*      */     }
/*      */     else
/*      */     {
/*   75 */       this._openList.Clear();
/*      */     }
/*      */ 
/*   78 */     return Status.Success;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FindPath(long startRef, long endRef, float[] startPos, float[] endPos, QueryFilter filter, long[] path, int pathCount, int maxPath)
/*      */   {
/*      */     try
/*      */     {
/*   85 */       if (this.NavMesh == null)
/*   86 */         throw new Exception("NavMesh is not initialized");
/*   87 */       if (this.NodePool == null)
/*   88 */         throw new Exception("NodePool is not initialized");
/*   89 */       if (this._openList == null)
/*   90 */         throw new Exception("OpenList is not initialized");
/*      */     } catch (Exception e) {
/*   92 */       e.printStackTrace();
/*      */     }
/*      */ 
/*   95 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */ 
/*   98 */     if ((startRef <= 0L) || (endRef <= 0L) || (maxPath <= 0))
/*      */     {
/*  100 */       statusReturn.status.add(Status.Failure);
/*  101 */       statusReturn.status.add(Status.InvalidParam);
/*  102 */       return statusReturn;
/*      */     }
/*      */ 
/*  105 */     if ((!this.NavMesh.IsValidPolyRef(startRef).booleanValue()) || (!this.NavMesh.IsValidPolyRef(endRef).booleanValue())) {
/*  106 */       statusReturn.status.add(Status.Failure);
/*  107 */       statusReturn.status.add(Status.InvalidParam);
/*  108 */       return statusReturn;
/*      */     }
/*      */ 
/*  111 */     if (startRef == endRef)
/*      */     {
/*  113 */       path[0] = startRef;
/*  114 */       statusReturn.intValue = 1;
/*  115 */       statusReturn.status.add(Status.Success);
/*  116 */       return statusReturn;
/*      */     }
/*      */ 
/*  119 */     this.NodePool.Clear();
/*  120 */     this._openList.Clear();
/*      */ 
/*  122 */     Node startNode = this.NodePool.GetNode(startRef);
/*  123 */     System.arraycopy(startPos, 0, startNode.Pos, 0, 3);
/*  124 */     startNode.PIdx = 0L;
/*  125 */     startNode.Cost = 0.0F;
/*  126 */     startNode.Total = (Helper.VDist(startPos[0], startPos[1], startPos[2], endPos[0], endPos[1], endPos[2]) * HScale);
/*  127 */     startNode.Id = startRef;
/*  128 */     startNode.Flags = Node.NodeOpen;
/*  129 */     this._openList.Push(startNode);
/*      */ 
/*  131 */     Node lastBestNode = startNode;
/*  132 */     float lastBestNodeCost = startNode.Total;
/*      */ 
/*  134 */     statusReturn.status.add(Status.Success);
/*      */ 
/*  136 */     while (!this._openList.Empty().booleanValue())
/*      */     {
/*  138 */       Node bestNode = this._openList.Pop();
/*  139 */       bestNode.Flags &= (Node.NodeOpen ^ 0xFFFFFFFF);
/*  140 */       bestNode.Flags |= Node.NodeClosed;
/*      */ 
/*  142 */       if (bestNode.Id == endRef)
/*      */       {
/*  144 */         lastBestNode = bestNode;
/*  145 */         break;
/*      */       }
/*      */ 
/*  148 */       long bestRef = bestNode.Id;
/*  149 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(bestRef);
/*  150 */       MeshTile bestTile = tileAndPoly.tile;
/*  151 */       Poly bestPoly = tileAndPoly.poly;
/*      */ 
/*  153 */       long parentRef = 0L;
/*  154 */       MeshTile parentTile = null;
/*  155 */       Poly parentPoly = null;
/*      */ 
/*  157 */       if (bestNode.PIdx > 0L)
/*  158 */         parentRef = this.NodePool.GetNodeAtIdx(bestNode.PIdx).Id;
/*  159 */       if (parentRef > 0L) {
/*  160 */         DetourMeshTileAndPoly parentTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(parentRef);
/*  161 */         parentTile = parentTileAndPoly.tile;
/*  162 */         parentPoly = parentTileAndPoly.poly;
/*      */       }
/*      */ 
/*  165 */       for (long i = bestPoly.FirstLink; i != NavMesh.NullLink; i = bestTile.Links[(int)i].Next)
/*      */       {
/*  167 */         long neighborRef = bestTile.Links[(int)i].Ref;
/*      */ 
/*  169 */         if ((neighborRef <= 0L) || (neighborRef == parentRef)) {
/*      */           continue;
/*      */         }
/*  172 */         DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(neighborRef);
/*  173 */         MeshTile neighbourTile = neiTileAndPoly.tile;
/*  174 */         Poly neighbourPoly = neiTileAndPoly.poly;
/*      */ 
/*  176 */         if (!filter.PassFilter(neighborRef, neighbourTile, neighbourPoly).booleanValue()) {
/*      */           continue;
/*      */         }
/*  179 */         Node neighbourNode = this.NodePool.GetNode(neighborRef);
/*  180 */         if (neighbourNode == null)
/*      */         {
/*  182 */           statusReturn.status.add(Status.OutOfNodes);
/*      */         }
/*      */         else
/*      */         {
/*  186 */           if (neighbourNode.Flags == 0L)
/*      */           {
/*  188 */             float[] pos = new float[3];
/*  189 */             GetEdgeMidPoint(bestRef, bestPoly, bestTile, neighborRef, neighbourPoly, neighbourTile, pos);
/*  190 */             System.arraycopy(pos, 0, neighbourNode.Pos, 0, 3);
/*      */           }
/*      */ 
/*  193 */           float cost = 0.0F;
/*  194 */           float heuristic = 0.0F;
/*      */ 
/*  196 */           if (neighborRef == endRef)
/*      */           {
/*  198 */             float curCost = filter.GetCost(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighbourNode.Pos[0], neighbourNode.Pos[1], neighbourNode.Pos[2], parentRef, parentTile, parentPoly, bestRef, bestTile, bestPoly, neighborRef, neighbourTile, neighbourPoly);
/*      */ 
/*  202 */             float endCost = filter.GetCost(neighbourNode.Pos[0], neighbourNode.Pos[1], neighbourNode.Pos[2], endPos[0], endPos[1], endPos[2], bestRef, bestTile, bestPoly, neighborRef, neighbourTile, neighbourPoly, 0L, null, null);
/*      */ 
/*  205 */             cost = bestNode.Cost + curCost + endCost;
/*  206 */             heuristic = 0.0F;
/*      */           }
/*      */           else
/*      */           {
/*  210 */             float curCost = filter.GetCost(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighbourNode.Pos[0], neighbourNode.Pos[1], neighbourNode.Pos[2], parentRef, parentTile, parentPoly, bestRef, bestTile, bestPoly, neighborRef, neighbourTile, neighbourPoly);
/*      */ 
/*  214 */             cost = bestNode.Cost + curCost;
/*  215 */             heuristic = Helper.VDist(neighbourNode.Pos[0], neighbourNode.Pos[1], neighbourNode.Pos[2], endPos[0], endPos[1], endPos[2]) * HScale;
/*      */           }
/*      */ 
/*  219 */           float total = cost + heuristic;
/*      */ 
/*  221 */           if (((neighbourNode.Flags & Node.NodeOpen) != 0L) && (total >= neighbourNode.Total))
/*      */             continue;
/*  223 */           if (((neighbourNode.Flags & Node.NodeClosed) != 0L) && (total >= neighbourNode.Total)) {
/*      */             continue;
/*      */           }
/*  226 */           neighbourNode.PIdx = this.NodePool.GetNodeIdx(bestNode);
/*  227 */           neighbourNode.Id = neighborRef;
/*  228 */           neighbourNode.Flags &= (Node.NodeClosed ^ 0xFFFFFFFF);
/*  229 */           neighbourNode.Cost = cost;
/*  230 */           neighbourNode.Total = total;
/*      */ 
/*  232 */           if ((neighbourNode.Flags & Node.NodeOpen) != 0L)
/*      */           {
/*  234 */             this._openList.Modify(neighbourNode);
/*      */           }
/*      */           else
/*      */           {
/*  238 */             neighbourNode.Flags |= Node.NodeOpen;
/*  239 */             this._openList.Push(neighbourNode);
/*      */           }
/*      */ 
/*  242 */           if (heuristic >= lastBestNodeCost)
/*      */             continue;
/*  244 */           lastBestNodeCost = heuristic;
/*  245 */           lastBestNode = neighbourNode;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  250 */     if (lastBestNode.Id != endRef)
/*      */     {
/*  252 */       statusReturn.status.add(Status.PartialResult);
/*      */     }
/*      */ 
/*  255 */     Node prev = null;
/*  256 */     Node node = lastBestNode;
/*      */     do
/*      */     {
/*  259 */       Node next = this.NodePool.GetNodeAtIdx(node.PIdx);
/*  260 */       node.PIdx = this.NodePool.GetNodeIdx(prev);
/*  261 */       prev = node;
/*  262 */       node = next;
/*  263 */     }while (node != null);
/*      */ 
/*  265 */     node = prev;
/*  266 */     int n = 0;
/*      */     do
/*      */     {
/*  269 */       path[(n++)] = node.Id;
/*  270 */       if (n >= maxPath)
/*      */       {
/*  272 */         statusReturn.status.add(Status.BufferTooSmall);
/*  273 */         break;
/*      */       }
/*  275 */       node = this.NodePool.GetNodeAtIdx(node.PIdx);
/*  276 */     }while (node != null);
/*      */ 
/*  278 */     statusReturn.intValue = n;
/*  279 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FindStraightPath(float[] startPos, float[] endPos, long[] path, int pathSize, float[] straightPath, short[] straightPathFlags, long[] straightPathRefs, int maxStraightPath)
/*      */   {
/*  286 */     return FindStraightPath(startPos, endPos, path, pathSize, straightPath, straightPathFlags, straightPathRefs, maxStraightPath, 0);
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FindStraightPath(float[] startPos, float[] endPos, long[] path, int pathSize, float[] straightPath, short[] straightPathFlags, long[] straightPathRefs, int maxStraightPath, int options)
/*      */   {
/*      */     try
/*      */     {
/*  295 */       if (this.NavMesh == null)
/*  296 */         throw new Exception("NavMesh is not initialized");
/*      */     } catch (Exception e) {
/*  298 */       e.printStackTrace();
/*      */     }
/*      */ 
/*  303 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*  304 */     statusReturn.intValue = 0;
/*      */ 
/*  306 */     if (maxStraightPath <= 0) {
/*  307 */       statusReturn.status.add(Status.Failure);
/*  308 */       statusReturn.status.add(Status.InvalidParam);
/*  309 */       return statusReturn;
/*      */     }
/*  311 */     if (path[0] <= 0L) {
/*  312 */       statusReturn.status.add(Status.Failure);
/*  313 */       statusReturn.status.add(Status.InvalidParam);
/*  314 */       return statusReturn;
/*      */     }
/*      */ 
/*  317 */     float[] closestStartPos = new float[3];
/*  318 */     if (ClosestPointOnPolyBoundary(path[0], startPos, closestStartPos).contains(Status.Failure)) {
/*  319 */       statusReturn.status.add(Status.Failure);
/*  320 */       statusReturn.status.add(Status.InvalidParam);
/*  321 */       return statusReturn;
/*      */     }
/*      */ 
/*  324 */     float[] closestEndPos = new float[3];
/*  325 */     if (ClosestPointOnPolyBoundary(path[(pathSize - 1)], endPos, closestEndPos).contains(Status.Failure)) {
/*  326 */       statusReturn.status.add(Status.Failure);
/*  327 */       statusReturn.status.add(Status.InvalidParam);
/*  328 */       return statusReturn;
/*      */     }
/*      */ 
/*  342 */     DetourStatusReturn sr = AppendVertex(closestStartPos, StraightPathStart, path[0], straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath);
/*      */ 
/*  352 */     if (!sr.status.contains(Status.InProgress)) {
/*  353 */       return sr;
/*      */     }
/*  355 */     statusReturn.intValue = sr.intValue;
/*      */ 
/*  357 */     if (pathSize > 1)
/*      */     {
/*  360 */       float[] portalApex = new float[3]; float[] portalLeft = new float[3]; float[] portalRight = new float[3];
/*  361 */       System.arraycopy(closestStartPos, 0, portalApex, 0, 3);
/*  362 */       System.arraycopy(portalApex, 0, portalLeft, 0, 3);
/*  363 */       System.arraycopy(portalApex, 0, portalRight, 0, 3);
/*  364 */       Log.debug("CORRIDOR: portalRight 1: " + portalRight[0] + "," + portalRight[1] + "," + portalRight[2]);
/*      */ 
/*  366 */       int apexIndex = 0;
/*  367 */       int leftIndex = 0;
/*  368 */       int rightIndex = 0;
/*      */ 
/*  370 */       short leftPolyType = 0;
/*  371 */       short rightPolyType = 0;
/*      */ 
/*  373 */       long leftPolyRef = path[0];
/*  374 */       long rightPolyRef = path[0];
/*      */ 
/*  376 */       for (int i = 0; i < pathSize; i++)
/*      */       {
/*  378 */         float[] left = new float[3]; float[] right = new float[3];
/*  379 */         short fromType = 0; short toType = 0;
/*      */ 
/*  381 */         if (i + 1 < pathSize)
/*      */         {
/*  384 */           DetourNumericReturn ppReturn = GetPortalPoints(path[i], path[(i + 1)], left, right);
/*  385 */           Log.debug("CORRIDOR: gotPortalPoints right 1: " + right[0] + "," + right[1] + "," + right[2] + " left 1: " + left[0] + "," + left[1] + "," + left[2]);
/*      */ 
/*  387 */           fromType = (short)ppReturn.intValue;
/*  388 */           toType = (short)(int)ppReturn.longValue;
/*      */ 
/*  390 */           if (sr.status.contains(Status.Failure))
/*      */           {
/*  392 */             if (ClosestPointOnPolyBoundary(path[i], endPos, closestEndPos).contains(Status.Failure))
/*      */             {
/*  394 */               statusReturn.status.add(Status.Failure);
/*  395 */               statusReturn.status.add(Status.InvalidParam);
/*  396 */               return statusReturn;
/*      */             }
/*      */ 
/*  399 */             if ((options & (StraightPathAreaCrossings | StraightPathAllCrossings)) != 0)
/*      */             {
/*  401 */               sr = AppendPortals(apexIndex, i, closestEndPos, path, straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath, options);
/*      */             }
/*      */ 
/*  412 */             sr = AppendVertex(closestEndPos, 0, path[i], straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath);
/*      */ 
/*  421 */             statusReturn.intValue = sr.intValue;
/*  422 */             statusReturn.status.add(Status.Success);
/*  423 */             statusReturn.status.add(Status.PartialResult);
/*  424 */             if (statusReturn.intValue >= maxStraightPath)
/*  425 */               statusReturn.status.add(Status.BufferTooSmall);
/*  426 */             return statusReturn;
/*      */           }
/*      */ 
/*  429 */           if ((i == 0) && 
/*  431 */             (Helper.DistancePtSegSqr2D(portalApex[0], portalApex[1], portalApex[2], left[0], left[1], left[2], right[0], right[1], right[2]).x < 1.00000011116208E-006D))
/*      */           {
/*      */             continue;
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  438 */           System.arraycopy(closestEndPos, 0, left, 0, 3);
/*  439 */           System.arraycopy(closestEndPos, 0, right, 0, 3);
/*  440 */           Log.debug("CORRIDOR: right 2: " + right[0] + "," + right[1] + "," + right[2]);
/*      */ 
/*  442 */           fromType = toType = NavMeshBuilder.PolyTypeGround;
/*      */         }
/*      */ 
/*  448 */         if (Helper.TriArea2D(portalApex, portalRight, right) <= 0.0F)
/*      */         {
/*  450 */           if ((Helper.VEqual(portalApex[0], portalApex[1], portalApex[2], portalRight[0], portalRight[1], portalRight[2]).booleanValue()) || (Helper.TriArea2D(portalApex, portalLeft, right) > 0.0F))
/*      */           {
/*  453 */             System.arraycopy(right, 0, portalRight, 0, 3);
/*      */ 
/*  455 */             rightPolyRef = i + 1 < pathSize ? path[(i + 1)] : 0L;
/*  456 */             rightPolyType = toType;
/*  457 */             rightIndex = i;
/*      */           }
/*      */           else
/*      */           {
/*  461 */             if ((options & (StraightPathAreaCrossings | StraightPathAllCrossings)) != 0)
/*      */             {
/*  463 */               sr = AppendPortals(apexIndex, leftIndex, portalLeft, path, straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath, options);
/*      */ 
/*  472 */               if (sr.status.contains(Status.InProgress)) {
/*  473 */                 return sr;
/*      */               }
/*      */             }
/*      */ 
/*  477 */             System.arraycopy(portalLeft, 0, portalApex, 0, 3);
/*  478 */             apexIndex = leftIndex;
/*      */ 
/*  480 */             short flags = 0;
/*  481 */             if (leftPolyRef <= 0L)
/*  482 */               flags = StraightPathEnd;
/*  483 */             else if (leftPolyType == NavMeshBuilder.PolyTypeOffMeshConnection)
/*  484 */               flags = StraightPathOffMeshConnection;
/*  485 */             long refId = leftPolyRef;
/*      */ 
/*  487 */             Log.debug("CORRIDOR: apex: " + portalApex[0] + "," + portalApex[1] + "," + portalApex[2]);
/*  488 */             sr = AppendVertex(portalApex, flags, refId, straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath);
/*      */ 
/*  497 */             if (sr.status.contains(Status.InProgress)) {
/*  498 */               return sr;
/*      */             }
/*      */ 
/*  501 */             System.arraycopy(portalApex, 0, portalLeft, 0, 3);
/*  502 */             System.arraycopy(portalApex, 0, portalRight, 0, 3);
/*  503 */             Log.debug("CORRIDOR: portalRight 3: " + portalRight[0] + "," + portalRight[1] + "," + portalRight[2]);
/*  504 */             leftIndex = apexIndex;
/*  505 */             rightIndex = apexIndex;
/*      */ 
/*  507 */             i = apexIndex;
/*      */ 
/*  509 */             continue;
/*      */           }
/*      */         }
/*      */ 
/*  513 */         if (Helper.TriArea2D(portalApex, portalLeft, left) < 0.0F)
/*      */           continue;
/*  515 */         if ((Helper.VEqual(portalApex[0], portalApex[1], portalApex[2], portalLeft[0], portalLeft[1], portalLeft[2]).booleanValue()) || (Helper.TriArea2D(portalApex, portalRight, left) < 0.0F))
/*      */         {
/*  518 */           System.arraycopy(left, 0, portalLeft, 0, 3);
/*  519 */           leftPolyRef = i + 1 < pathSize ? path[(i + 1)] : 0L;
/*  520 */           leftPolyType = toType;
/*  521 */           leftIndex = i;
/*      */         }
/*      */         else
/*      */         {
/*  525 */           if ((options & (StraightPathAreaCrossings | StraightPathAllCrossings)) != 0)
/*      */           {
/*  527 */             sr = AppendPortals(apexIndex, rightIndex, portalRight, path, straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath, options);
/*      */ 
/*  536 */             if (sr.status.contains(Status.InProgress)) {
/*  537 */               return sr;
/*      */             }
/*      */           }
/*  540 */           Log.debug("CORRIDOR: portalRight 4: " + portalRight[0] + "," + portalRight[1] + "," + portalRight[2]);
/*  541 */           System.arraycopy(portalRight, 0, portalApex, 0, 3);
/*  542 */           apexIndex = rightIndex;
/*      */ 
/*  544 */           short flags = 0;
/*  545 */           if (rightPolyRef <= 0L)
/*  546 */             flags = StraightPathEnd;
/*  547 */           else if (rightPolyType == NavMeshBuilder.PolyTypeOffMeshConnection)
/*  548 */             flags = StraightPathOffMeshConnection;
/*  549 */           long refId = rightPolyRef;
/*      */ 
/*  551 */           sr = AppendVertex(portalApex, flags, refId, straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath);
/*      */ 
/*  561 */           if (sr.status.contains(Status.InProgress)) {
/*  562 */             return sr;
/*      */           }
/*      */ 
/*  565 */           System.arraycopy(portalApex, 0, portalLeft, 0, 3);
/*  566 */           System.arraycopy(portalApex, 0, portalRight, 0, 3);
/*  567 */           leftIndex = apexIndex;
/*  568 */           rightIndex = apexIndex;
/*      */ 
/*  570 */           i = apexIndex;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  577 */       if ((options & (StraightPathAreaCrossings | StraightPathAllCrossings)) != 0)
/*      */       {
/*  579 */         sr = AppendPortals(apexIndex, pathSize - 1, closestEndPos, path, straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath, options);
/*      */ 
/*  589 */         if (sr.status.contains(Status.InProgress)) {
/*  590 */           return sr;
/*      */         }
/*      */       }
/*      */     }
/*  594 */     sr = AppendVertex(closestEndPos, StraightPathEnd, 0L, straightPath, straightPathFlags, straightPathRefs, statusReturn.intValue, maxStraightPath);
/*      */ 
/*  604 */     statusReturn.intValue = sr.intValue;
/*  605 */     statusReturn.status.add(Status.Success);
/*  606 */     if (statusReturn.intValue >= maxStraightPath)
/*  607 */       statusReturn.status.add(Status.BufferTooSmall);
/*  608 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> InitSlicedFindPath(long startRef, long endRef, float[] startPos, float[] endPos, QueryFilter filter)
/*      */   {
/*      */     try {
/*  614 */       if (this.NavMesh == null)
/*  615 */         throw new Exception("NavMesh is not initialized");
/*  616 */       if (this.NodePool == null)
/*  617 */         throw new Exception("NodePool is not initialized");
/*  618 */       if (this._openList == null)
/*  619 */         throw new Exception("OpenList is not initialized");
/*      */     } catch (Exception e) {
/*  621 */       e.printStackTrace();
/*      */     }
/*      */ 
/*  624 */     this._query = new QueryData();
/*  625 */     this._query.Status = EnumSet.of(Status.Failure);
/*  626 */     this._query.StartRef = startRef;
/*  627 */     this._query.EndRef = endRef;
/*  628 */     System.arraycopy(startPos, 0, this._query.StartPos, 0, 3);
/*  629 */     System.arraycopy(endPos, 0, this._query.EndPos, 0, 3);
/*  630 */     this._query.Filter = filter;
/*      */ 
/*  632 */     if ((startRef <= 0L) || (endRef <= 0L)) {
/*  633 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*      */ 
/*  636 */     if ((!this.NavMesh.IsValidPolyRef(startRef).booleanValue()) || (!this.NavMesh.IsValidPolyRef(endRef).booleanValue())) {
/*  637 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*      */ 
/*  640 */     if (startRef == endRef)
/*      */     {
/*  642 */       this._query.Status = EnumSet.of(Status.Success);
/*  643 */       return EnumSet.of(Status.Success);
/*      */     }
/*      */ 
/*  646 */     this.NodePool.Clear();
/*  647 */     this._openList.Clear();
/*      */ 
/*  649 */     Node startNode = this.NodePool.GetNode(startRef);
/*  650 */     System.arraycopy(startPos, 0, startNode.Pos, 0, 3);
/*  651 */     startNode.PIdx = 0L;
/*  652 */     startNode.Cost = 0.0F;
/*  653 */     startNode.Total = (Helper.VDist(startPos[0], startPos[1], startPos[2], endPos[0], endPos[1], endPos[2]) * HScale);
/*  654 */     startNode.Id = startRef;
/*  655 */     startNode.Flags = Node.NodeOpen;
/*  656 */     this._openList.Push(startNode);
/*      */ 
/*  659 */     this._query.Status = EnumSet.of(Status.InProgress);
/*  660 */     this._query.LastBestNode = startNode;
/*  661 */     this._query.LastBestNodeCost = startNode.Total;
/*      */ 
/*  663 */     return this._query.Status;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn UpdateSlicedFindPath(int maxIter)
/*      */   {
/*  668 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*  669 */     statusReturn.intValue = 0;
/*      */ 
/*  672 */     if (!this._query.Status.contains(Status.InProgress)) {
/*  673 */       statusReturn.status = this._query.Status;
/*  674 */       return statusReturn;
/*      */     }
/*      */ 
/*  677 */     if ((!this.NavMesh.IsValidPolyRef(this._query.StartRef).booleanValue()) || (!this.NavMesh.IsValidPolyRef(this._query.EndRef).booleanValue()))
/*      */     {
/*  679 */       this._query.Status = EnumSet.of(Status.Failure);
/*  680 */       statusReturn.status = EnumSet.of(Status.Failure);
/*  681 */       return statusReturn;
/*      */     }
/*      */ 
/*  684 */     int iter = 0;
/*  685 */     while ((iter < maxIter) && (!this._openList.Empty().booleanValue()))
/*      */     {
/*  687 */       iter++;
/*      */ 
/*  689 */       Node bestNode = this._openList.Pop();
/*  690 */       bestNode.Flags &= (Node.NodeOpen ^ 0xFFFFFFFF);
/*  691 */       bestNode.Flags |= Node.NodeClosed;
/*      */ 
/*  693 */       if (bestNode.Id == this._query.EndRef)
/*      */       {
/*  695 */         this._query.LastBestNode = bestNode;
/*      */ 
/*  698 */         EnumSet details = Status.MaskDetails(this._query.Status);
/*  699 */         details.add(Status.Success);
/*  700 */         this._query.Status = details;
/*  701 */         statusReturn.intValue = iter;
/*  702 */         statusReturn.status = this._query.Status;
/*  703 */         return statusReturn;
/*      */       }
/*      */ 
/*  708 */       long bestRef = bestNode.Id;
/*  709 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(bestRef);
/*  710 */       if (tileAndPoly.status.contains(Status.Failure))
/*      */       {
/*  712 */         this._query.Status = EnumSet.of(Status.Failure);
/*  713 */         statusReturn.intValue = iter;
/*  714 */         statusReturn.status = this._query.Status;
/*  715 */         return statusReturn;
/*      */       }
/*  717 */       MeshTile bestTile = tileAndPoly.tile;
/*  718 */       Poly bestPoly = tileAndPoly.poly;
/*      */ 
/*  723 */       long parentRef = 0L;
/*  724 */       MeshTile parentTile = null;
/*  725 */       Poly parentPoly = null;
/*  726 */       if (bestNode.PIdx > 0L)
/*  727 */         parentRef = this.NodePool.GetNodeAtIdx(bestNode.PIdx).Id;
/*  728 */       if (parentRef > 0L)
/*      */       {
/*  731 */         DetourMeshTileAndPoly parentTileAndPoly = this.NavMesh.GetTileAndPolyByRef(parentRef);
/*  732 */         if (parentTileAndPoly.status.contains(Status.Failure))
/*      */         {
/*  734 */           this._query.Status = EnumSet.of(Status.Failure);
/*  735 */           statusReturn.intValue = iter;
/*  736 */           statusReturn.status = this._query.Status;
/*  737 */           return statusReturn;
/*      */         }
/*  739 */         parentTile = parentTileAndPoly.tile;
/*  740 */         parentPoly = parentTileAndPoly.poly;
/*      */       }
/*      */ 
/*  743 */       for (long i = bestPoly.FirstLink; i != NavMesh.NullLink; i = bestTile.Links[(int)i].Next)
/*      */       {
/*  745 */         long neighborRef = bestTile.Links[(int)i].Ref;
/*      */ 
/*  748 */         if ((neighborRef <= 0L) || (neighborRef == parentRef)) {
/*      */           continue;
/*      */         }
/*  751 */         DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(neighborRef);
/*  752 */         MeshTile neighborTile = neiTileAndPoly.tile;
/*  753 */         Poly neighborPoly = neiTileAndPoly.poly;
/*      */ 
/*  757 */         if (!this._query.Filter.PassFilter(neighborRef, neighborTile, neighborPoly).booleanValue()) {
/*      */           continue;
/*      */         }
/*  760 */         Node neighborNode = this.NodePool.GetNode(neighborRef);
/*  761 */         if (neighborNode == null)
/*      */         {
/*  763 */           this._query.Status.add(Status.OutOfNodes);
/*      */         }
/*      */         else
/*      */         {
/*  767 */           if (neighborNode.Flags == 0L)
/*      */           {
/*  769 */             float[] tempPos = new float[3];
/*  770 */             GetEdgeMidPoint(bestRef, bestPoly, bestTile, neighborRef, neighborPoly, neighborTile, tempPos);
/*  771 */             System.arraycopy(tempPos, 0, neighborNode.Pos, 0, 3);
/*      */           }
/*      */ 
/*  774 */           float cost = 0.0F;
/*  775 */           float heuristic = 0.0F;
/*      */ 
/*  777 */           if (neighborRef == this._query.EndRef)
/*      */           {
/*  779 */             float curCost = this._query.Filter.GetCost(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2], parentRef, parentTile, parentPoly, bestRef, bestTile, bestPoly, neighborRef, neighborTile, neighborPoly);
/*      */ 
/*  784 */             float endCost = this._query.Filter.GetCost(neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2], this._query.EndPos[0], this._query.EndPos[1], this._query.EndPos[2], bestRef, bestTile, bestPoly, neighborRef, neighborTile, neighborPoly, 0L, null, null);
/*      */ 
/*  789 */             cost = bestNode.Cost + curCost + endCost;
/*  790 */             heuristic = 0.0F;
/*      */           }
/*      */           else
/*      */           {
/*  794 */             float curCost = this._query.Filter.GetCost(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2], parentRef, parentTile, parentPoly, bestRef, bestTile, bestPoly, neighborRef, neighborTile, neighborPoly);
/*      */ 
/*  799 */             cost = bestNode.Cost + curCost;
/*  800 */             heuristic = Helper.VDist(neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2], this._query.EndPos[0], this._query.EndPos[1], this._query.EndPos[2]) * HScale;
/*      */           }
/*      */ 
/*  805 */           float total = cost + heuristic;
/*      */ 
/*  807 */           if (((neighborNode.Flags & Node.NodeOpen) != 0L) && (total >= neighborNode.Total))
/*      */             continue;
/*  809 */           if (((neighborNode.Flags & Node.NodeClosed) != 0L) && (total >= neighborNode.Total)) {
/*      */             continue;
/*      */           }
/*  812 */           neighborNode.PIdx = this.NodePool.GetNodeIdx(bestNode);
/*  813 */           neighborNode.Id = neighborRef;
/*  814 */           neighborNode.Flags &= (Node.NodeClosed ^ 0xFFFFFFFF);
/*  815 */           neighborNode.Cost = cost;
/*  816 */           neighborNode.Total = total;
/*      */ 
/*  819 */           if ((neighborNode.Flags & Node.NodeOpen) != 0L)
/*      */           {
/*  821 */             this._openList.Modify(neighborNode);
/*      */           }
/*      */           else
/*      */           {
/*  825 */             neighborNode.Flags |= Node.NodeOpen;
/*  826 */             this._openList.Push(neighborNode);
/*      */           }
/*      */ 
/*  829 */           if (heuristic >= this._query.LastBestNodeCost)
/*      */             continue;
/*  831 */           this._query.LastBestNodeCost = heuristic;
/*  832 */           this._query.LastBestNode = neighborNode;
/*      */         }
/*      */       }
/*      */     }
/*  836 */     if (this._openList.Empty().booleanValue())
/*      */     {
/*  838 */       EnumSet details = Status.MaskDetails(this._query.Status);
/*  839 */       details.add(Status.Success);
/*  840 */       this._query.Status = details;
/*      */     }
/*      */ 
/*  843 */     statusReturn.intValue = iter;
/*      */ 
/*  845 */     statusReturn.status = this._query.Status;
/*  846 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FinalizeSlicedFindPath(long[] path, int maxPath)
/*      */   {
/*  851 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*  852 */     statusReturn.intValue = 0;
/*      */ 
/*  854 */     if (this._query.Status.contains(Status.Failure))
/*      */     {
/*  856 */       this._query = new QueryData();
/*  857 */       statusReturn.status = EnumSet.of(Status.Failure);
/*  858 */       return statusReturn;
/*      */     }
/*      */ 
/*  861 */     int n = 0;
/*      */ 
/*  863 */     if (this._query.StartRef == this._query.EndRef)
/*      */     {
/*  865 */       path[(n++)] = this._query.StartRef;
/*      */     }
/*      */     else
/*      */     {
/*  869 */       if (this._query.LastBestNode == null) {
/*      */         try {
/*  871 */           throw new Exception("Query has no last best node");
/*      */         } catch (Exception e) {
/*  873 */           e.printStackTrace();
/*      */         }
/*      */       }
/*  876 */       if (this._query.LastBestNode.Id != this._query.EndRef) {
/*  877 */         this._query.Status.add(Status.PartialResult);
/*      */       }
/*  879 */       Node prev = null;
/*  880 */       Node node = this._query.LastBestNode;
/*      */       do
/*      */       {
/*  883 */         Node next = this.NodePool.GetNodeAtIdx(node.PIdx);
/*      */ 
/*  887 */         node.PIdx = this.NodePool.GetNodeIdx(prev);
/*  888 */         prev = node;
/*  889 */         node = next;
/*  890 */       }while (node != null);
/*      */ 
/*  892 */       node = prev;
/*      */       do
/*      */       {
/*  895 */         path[(n++)] = node.Id;
/*  896 */         if (n >= maxPath)
/*      */         {
/*  898 */           this._query.Status.add(Status.BufferTooSmall);
/*  899 */           break;
/*      */         }
/*  901 */         node = this.NodePool.GetNodeAtIdx(node.PIdx);
/*  902 */       }while (node != null);
/*      */     }
/*      */ 
/*  906 */     EnumSet details = Status.MaskDetails(this._query.Status);
/*      */ 
/*  908 */     this._query = new QueryData();
/*  909 */     statusReturn.intValue = n;
/*      */ 
/*  911 */     details.add(Status.Success);
/*  912 */     statusReturn.status = details;
/*  913 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FinalizeSlicedFindPathPartial(long[] existing, int existingSize, long[] path, int maxPath)
/*      */   {
/*  918 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*  919 */     statusReturn.intValue = 0;
/*  920 */     if (existingSize == 0) {
/*  921 */       statusReturn.status = EnumSet.of(Status.Failure);
/*  922 */       return statusReturn;
/*      */     }
/*      */ 
/*  925 */     if (this._query.Status.contains(Status.Failure))
/*      */     {
/*  927 */       this._query = new QueryData();
/*  928 */       statusReturn.status = EnumSet.of(Status.Failure);
/*  929 */       return statusReturn;
/*      */     }
/*      */ 
/*  932 */     int n = 0;
/*      */ 
/*  934 */     if (this._query.StartRef == this._query.EndRef)
/*      */     {
/*  936 */       path[(n++)] = this._query.StartRef;
/*      */     }
/*      */     else
/*      */     {
/*  940 */       Node prev = null;
/*  941 */       Node node = null;
/*  942 */       for (int i = existingSize - 1; i >= 0; i--)
/*      */       {
/*  944 */         node = this.NodePool.FindNode(existing[i]);
/*  945 */         if (node != null) {
/*      */           break;
/*      */         }
/*      */       }
/*  949 */       if (node == null)
/*      */       {
/*  951 */         this._query.Status.add(Status.PartialResult);
/*  952 */         if (this._query.LastBestNode == null)
/*      */           try {
/*  954 */             throw new Exception("Query Last Best Node is not initialized");
/*      */           } catch (Exception e) {
/*  956 */             e.printStackTrace();
/*      */           }
/*  958 */         node = this._query.LastBestNode;
/*      */       }
/*      */ 
/*      */       do
/*      */       {
/*  963 */         Node next = this.NodePool.GetNodeAtIdx(node.PIdx);
/*  964 */         node.PIdx = this.NodePool.GetNodeIdx(prev);
/*  965 */         prev = node;
/*  966 */         node = next;
/*  967 */       }while (node != null);
/*      */ 
/*  969 */       node = prev;
/*      */       do
/*      */       {
/*  972 */         path[(n++)] = node.Id;
/*  973 */         if (n >= maxPath)
/*      */         {
/*  975 */           this._query.Status.add(Status.BufferTooSmall);
/*  976 */           break;
/*      */         }
/*  978 */         node = this.NodePool.GetNodeAtIdx(node.PIdx);
/*  979 */       }while (node != null);
/*      */     }
/*      */ 
/*  982 */     EnumSet details = Status.MaskDetails(this._query.Status);
/*      */ 
/*  984 */     this._query = new QueryData();
/*      */ 
/*  986 */     statusReturn.intValue = n;
/*  987 */     details.add(Status.Success);
/*  988 */     statusReturn.status = details;
/*  989 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FindPolysAroundCircle(long startRef, float[] centerPos, float radius, QueryFilter filter, long[] resultRef, long[] resultParent, float[] resultCost, int maxResult)
/*      */   {
/*  995 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */     try
/*      */     {
/*  998 */       if (this.NavMesh == null)
/*  999 */         throw new Exception("NavMesh is not initialized");
/* 1000 */       if (this.NodePool == null)
/* 1001 */         throw new Exception("NodePool is not initialized");
/* 1002 */       if (this._openList == null)
/* 1003 */         throw new Exception("OpenList is not initialized");
/*      */     } catch (Exception e) {
/* 1005 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1008 */     statusReturn.intValue = 0;
/*      */ 
/* 1010 */     if ((startRef <= 0L) || (!this.NavMesh.IsValidPolyRef(startRef).booleanValue())) {
/* 1011 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 1012 */       return statusReturn;
/*      */     }
/*      */ 
/* 1015 */     this.NodePool.Clear();
/* 1016 */     this._openList.Clear();
/*      */ 
/* 1018 */     Node startNode = this.NodePool.GetNode(startRef);
/* 1019 */     System.arraycopy(centerPos, 0, startNode.Pos, 0, 3);
/* 1020 */     startNode.PIdx = 0L;
/* 1021 */     startNode.Cost = 0.0F;
/* 1022 */     startNode.Total = 0.0F;
/* 1023 */     startNode.Id = startRef;
/* 1024 */     startNode.Flags = Node.NodeOpen;
/* 1025 */     this._openList.Push(startNode);
/*      */ 
/* 1027 */     statusReturn.status = EnumSet.of(Status.Success);
/*      */ 
/* 1029 */     int n = 0;
/* 1030 */     if (n < maxResult)
/*      */     {
/* 1032 */       resultRef[n] = startNode.Id;
/* 1033 */       resultParent[n] = 0L;
/* 1034 */       resultCost[n] = 0.0F;
/* 1035 */       n++;
/*      */     }
/*      */     else
/*      */     {
/* 1039 */       statusReturn.status.add(Status.BufferTooSmall);
/*      */     }
/*      */ 
/* 1042 */     float radiusSqr = radius * radius;
/* 1043 */     while (!this._openList.Empty().booleanValue())
/*      */     {
/* 1045 */       Node bestNode = this._openList.Pop();
/* 1046 */       bestNode.Flags &= (Node.NodeOpen ^ 0xFFFFFFFF);
/* 1047 */       bestNode.Flags |= Node.NodeClosed;
/*      */ 
/* 1049 */       long bestRef = bestNode.Id;
/* 1050 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(bestRef);
/* 1051 */       MeshTile bestTile = tileAndPoly.tile;
/* 1052 */       Poly bestPoly = tileAndPoly.poly;
/*      */ 
/* 1054 */       long parentRef = 0L;
/* 1055 */       MeshTile parentTile = null;
/* 1056 */       Poly parentPoly = null;
/* 1057 */       if (bestNode.PIdx != 0L)
/* 1058 */         parentRef = this.NodePool.GetNodeAtIdx(bestNode.PIdx).Id;
/* 1059 */       if (parentRef > 0L) {
/* 1060 */         DetourMeshTileAndPoly parentTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(parentRef);
/* 1061 */         parentTile = parentTileAndPoly.tile;
/* 1062 */         parentPoly = parentTileAndPoly.poly;
/*      */       }
/*      */ 
/* 1065 */       for (long i = bestPoly.FirstLink; i != NavMesh.NullLink; i = bestTile.Links[(int)i].Next)
/*      */       {
/* 1067 */         Link link = bestTile.Links[(int)i];
/* 1068 */         long neighborRef = link.Ref;
/*      */ 
/* 1070 */         if ((neighborRef <= 0L) || (neighborRef == parentRef)) {
/*      */           continue;
/*      */         }
/* 1073 */         DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(neighborRef);
/* 1074 */         MeshTile neighborTile = neiTileAndPoly.tile;
/* 1075 */         Poly neighborPoly = neiTileAndPoly.poly;
/*      */ 
/* 1077 */         if (!filter.PassFilter(neighborRef, neighborTile, neighborPoly).booleanValue()) {
/*      */           continue;
/*      */         }
/* 1080 */         float[] va = new float[3]; float[] vb = new float[3];
/* 1081 */         if (!GetPortalPoints(bestRef, bestPoly, bestTile, neighborRef, neighborPoly, neighborTile, va, vb).contains(Status.Success)) {
/*      */           continue;
/*      */         }
/* 1084 */         float distSqr = (float)Helper.DistancePtSegSqr2D(centerPos[0], centerPos[1], centerPos[2], va[0], va[1], va[2], vb[0], vb[1], vb[2]).x;
/* 1085 */         if (distSqr > radiusSqr) {
/*      */           continue;
/*      */         }
/* 1088 */         Node neighborNode = this.NodePool.GetNode(neighborRef);
/* 1089 */         if (neighborNode == null)
/*      */         {
/* 1091 */           statusReturn.status.add(Status.OutOfNodes);
/*      */         }
/*      */         else
/*      */         {
/* 1095 */           if ((neighborNode.Flags & Node.NodeClosed) != 0L) {
/*      */             continue;
/*      */           }
/* 1098 */           if (neighborNode.Flags == 0L)
/*      */           {
/* 1100 */             float[] temp = new float[3];
/* 1101 */             temp = Helper.VLerp(temp, va[0], va[1], va[2], vb[0], vb[1], vb[2], 0.5F);
/* 1102 */             System.arraycopy(temp, 0, neighborNode.Pos, 0, 3);
/*      */           }
/*      */ 
/* 1105 */           float total = bestNode.Total + Helper.VDist(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2]);
/*      */ 
/* 1107 */           if (((neighborNode.Flags & Node.NodeOpen) != 0L) && (total >= neighborNode.Total)) {
/*      */             continue;
/*      */           }
/* 1110 */           neighborNode.Id = neighborRef;
/* 1111 */           neighborNode.Flags &= (Node.NodeClosed ^ 0xFFFFFFFF);
/* 1112 */           neighborNode.PIdx = this.NodePool.GetNodeIdx(bestNode);
/* 1113 */           neighborNode.Total = total;
/*      */ 
/* 1115 */           if ((neighborNode.Flags & Node.NodeOpen) != 0L)
/*      */           {
/* 1117 */             this._openList.Modify(neighborNode);
/*      */           }
/*      */           else
/*      */           {
/* 1121 */             if (n < maxResult)
/*      */             {
/* 1123 */               resultRef[n] = neighborNode.Id;
/* 1124 */               resultParent[n] = this.NodePool.GetNodeAtIdx(neighborNode.PIdx).Id;
/* 1125 */               resultCost[n] = neighborNode.Total;
/* 1126 */               n++;
/*      */             }
/*      */             else
/*      */             {
/* 1130 */               statusReturn.status.add(Status.BufferTooSmall);
/*      */             }
/* 1132 */             neighborNode.Flags = Node.NodeOpen;
/* 1133 */             this._openList.Push(neighborNode);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1137 */     statusReturn.intValue = n;
/* 1138 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FindPolysAroundShape(long startRef, float[] verts, int nverts, QueryFilter filter, long[] resultRef, long[] resultParent, float[] resultCost, int maxResult)
/*      */   {
/* 1144 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */     try
/*      */     {
/* 1147 */       if (this.NavMesh == null)
/* 1148 */         throw new Exception("NavMesh is not initialized");
/* 1149 */       if (this.NodePool == null)
/* 1150 */         throw new Exception("NodePool is not initialized");
/* 1151 */       if (this._openList == null)
/* 1152 */         throw new Exception("OpenList is not initialized");
/*      */     } catch (Exception e) {
/* 1154 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1157 */     statusReturn.intValue = 0;
/*      */ 
/* 1159 */     if ((startRef <= 0L) || (!this.NavMesh.IsValidPolyRef(startRef).booleanValue())) {
/* 1160 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 1161 */       return statusReturn;
/*      */     }
/*      */ 
/* 1164 */     this.NodePool.Clear();
/* 1165 */     this._openList.Clear();
/*      */ 
/* 1167 */     float[] centerPos = { 0.0F, 0.0F, 0.0F };
/* 1168 */     for (int i = 0; i < nverts; i++)
/*      */     {
/* 1170 */       centerPos = Helper.VAdd(centerPos[0], centerPos[1], centerPos[2], verts[(i * 3 + 0)], verts[(i * 3 + 1)], verts[(i * 3 + 2)]);
/*      */     }
/*      */ 
/* 1173 */     centerPos = Helper.VScale(centerPos[0], centerPos[1], centerPos[2], 1.0F / nverts);
/*      */ 
/* 1175 */     Node startNode = this.NodePool.GetNode(startRef);
/* 1176 */     System.arraycopy(centerPos, 0, startNode.Pos, 0, 3);
/* 1177 */     startNode.PIdx = 0L;
/* 1178 */     startNode.Cost = 0.0F;
/* 1179 */     startNode.Total = 0.0F;
/* 1180 */     startNode.Id = startRef;
/* 1181 */     startNode.Flags = Node.NodeOpen;
/* 1182 */     this._openList.Push(startNode);
/*      */ 
/* 1184 */     int n = 0;
/* 1185 */     if (n < maxResult)
/*      */     {
/* 1187 */       resultRef[n] = startNode.Id;
/* 1188 */       resultParent[n] = 0L;
/* 1189 */       resultCost[n] = 0.0F;
/* 1190 */       n++;
/*      */     }
/*      */     else
/*      */     {
/* 1194 */       statusReturn.status.add(Status.BufferTooSmall);
/*      */     }
/*      */ 
/* 1197 */     while (!this._openList.Empty().booleanValue())
/*      */     {
/* 1199 */       Node bestNode = this._openList.Pop();
/* 1200 */       bestNode.Flags &= Node.NodeOpen;
/* 1201 */       bestNode.Flags |= Node.NodeClosed;
/*      */ 
/* 1203 */       long bestRef = bestNode.Id;
/* 1204 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(bestRef);
/* 1205 */       MeshTile bestTile = tileAndPoly.tile;
/* 1206 */       Poly bestPoly = tileAndPoly.poly;
/*      */ 
/* 1208 */       long parentRef = 0L;
/* 1209 */       MeshTile parentTile = null;
/* 1210 */       Poly parentPoly = null;
/*      */ 
/* 1212 */       if (bestNode.PIdx > 0L)
/* 1213 */         parentRef = this.NodePool.GetNodeAtIdx(bestNode.PIdx).Id;
/* 1214 */       if (parentRef > 0L) {
/* 1215 */         DetourMeshTileAndPoly parentTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(parentRef);
/* 1216 */         parentTile = parentTileAndPoly.tile;
/* 1217 */         parentPoly = parentTileAndPoly.poly;
/*      */       }
/*      */ 
/* 1220 */       for (long i = bestPoly.FirstLink; i != NavMesh.NullLink; i = bestTile.Links[(int)i].Next)
/*      */       {
/* 1222 */         Link link = bestTile.Links[(int)i];
/* 1223 */         long neighborRef = link.Ref;
/*      */ 
/* 1225 */         if ((neighborRef <= 0L) || (neighborRef == parentRef)) {
/*      */           continue;
/*      */         }
/* 1228 */         DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(neighborRef);
/* 1229 */         MeshTile neighborTile = neiTileAndPoly.tile;
/* 1230 */         Poly neighborPoly = neiTileAndPoly.poly;
/*      */ 
/* 1232 */         float[] va = new float[3]; float[] vb = new float[3];
/* 1233 */         if (!GetPortalPoints(bestRef, bestPoly, bestTile, neighborRef, neighborPoly, neighborTile, va, vb).contains(Status.Success)) {
/*      */           continue;
/*      */         }
/* 1236 */         Vector2 tMinMax = new Vector2();
/* 1237 */         IntVector2 segMinMax = new IntVector2();
/* 1238 */         if (!Helper.IntersectSegmentPoly2D(va, vb, verts, nverts, tMinMax, segMinMax).booleanValue())
/*      */           continue;
/* 1240 */         if ((tMinMax.x > 1.0D) || (tMinMax.y < 0.0D)) {
/*      */           continue;
/*      */         }
/* 1243 */         Node neighborNode = this.NodePool.GetNode(neighborRef);
/* 1244 */         if (neighborNode == null)
/*      */         {
/* 1246 */           statusReturn.status.add(Status.OutOfNodes);
/*      */         }
/*      */         else
/*      */         {
/* 1250 */           if ((neighborNode.Flags & Node.NodeClosed) != 0L) {
/*      */             continue;
/*      */           }
/* 1253 */           if (neighborNode.Flags == 0L)
/*      */           {
/* 1255 */             float[] temp = new float[3];
/* 1256 */             temp = Helper.VLerp(temp, va[0], va[1], va[2], vb[0], vb[1], vb[2], 0.5F);
/* 1257 */             System.arraycopy(temp, 0, neighborNode.Pos, 0, 3);
/*      */           }
/*      */ 
/* 1260 */           float total = bestNode.Total + Helper.VDist(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2]);
/*      */ 
/* 1262 */           if (((neighborNode.Flags & Node.NodeOpen) != 0L) && (total >= neighborNode.Total)) {
/*      */             continue;
/*      */           }
/* 1265 */           neighborNode.Id = neighborRef;
/* 1266 */           neighborNode.Flags &= (Node.NodeClosed ^ 0xFFFFFFFF);
/* 1267 */           neighborNode.PIdx = this.NodePool.GetNodeIdx(bestNode);
/* 1268 */           neighborNode.Total = total;
/*      */ 
/* 1270 */           if ((neighborNode.Flags & Node.NodeOpen) != 0L)
/*      */           {
/* 1272 */             this._openList.Modify(neighborNode);
/*      */           }
/*      */           else
/*      */           {
/* 1276 */             if (n < maxResult)
/*      */             {
/* 1278 */               resultRef[n] = neighborNode.Id;
/* 1279 */               resultParent[n] = this.NodePool.GetNodeAtIdx(neighborNode.PIdx).Id;
/* 1280 */               resultCost[n] = neighborNode.Total;
/* 1281 */               n++;
/*      */             }
/*      */             else
/*      */             {
/* 1285 */               statusReturn.status.add(Status.BufferTooSmall);
/*      */             }
/* 1287 */             neighborNode.Flags = Node.NodeOpen;
/* 1288 */             this._openList.Push(neighborNode);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1293 */     statusReturn.intValue = n;
/* 1294 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourNumericReturn FindNearestPoly(float[] center, float[] extents, QueryFilter filter, float[] nearestPt)
/*      */   {
/*      */     try
/*      */     {
/* 1308 */       if (this.NavMesh == null)
/* 1309 */         throw new Exception("NavMesh is not initialized");
/*      */     } catch (Exception e) {
/* 1311 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1314 */     DetourNumericReturn statusReturn = new DetourNumericReturn();
/*      */ 
/* 1316 */     long[] polys = new long[''];
/*      */ 
/* 1318 */     DetourStatusReturn sr = QueryPolygons(center, extents, filter, polys, 128);
/* 1319 */     if (sr.status.contains(Status.Failure)) {
/* 1320 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 1321 */       return statusReturn;
/*      */     }
/* 1323 */     int polyCount = sr.intValue;
/*      */ 
/* 1326 */     long nearest = 0L;
/* 1327 */     float nearestDistanceSqr = 3.4028235E+38F;
/* 1328 */     for (int i = 0; i < polyCount; i++)
/*      */     {
/* 1330 */       long refId = polys[i];
/* 1331 */       float[] closestPtPoly = new float[3];
/* 1332 */       ClosestPointOnPoly(refId, center, closestPtPoly);
/*      */ 
/* 1334 */       float d = Helper.VDistSqr(center[0], center[1], center[2], closestPtPoly[0], closestPtPoly[1], closestPtPoly[2]);
/*      */ 
/* 1336 */       if (d >= nearestDistanceSqr)
/*      */         continue;
/* 1338 */       if (nearestPt != null)
/*      */       {
/* 1340 */         System.arraycopy(closestPtPoly, 0, nearestPt, 0, 3);
/*      */       }
/* 1342 */       nearestDistanceSqr = d;
/* 1343 */       nearest = refId;
/*      */     }
/*      */ 
/* 1348 */     statusReturn.longValue = nearest;
/* 1349 */     statusReturn.status = EnumSet.of(Status.Success);
/* 1350 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn QueryPolygons(float[] center, float[] extents, QueryFilter filter, long[] polys, int maxPolys)
/*      */   {
/*      */     try
/*      */     {
/* 1357 */       if (this.NavMesh == null)
/* 1358 */         throw new Exception("NavMesh is not initialized");
/*      */     } catch (Exception e) {
/* 1360 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1363 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */ 
/* 1365 */     float[] bmin = Helper.VSub(center[0], center[1], center[2], extents[0], extents[1], extents[2]);
/* 1366 */     float[] bmax = Helper.VAdd(center[0], center[1], center[2], extents[0], extents[1], extents[2]);
/*      */ 
/* 1368 */     IntVector2 min = this.NavMesh.CalcTileLoc(bmin[0], bmin[1], bmin[2]);
/* 1369 */     IntVector2 max = this.NavMesh.CalcTileLoc(bmax[0], bmax[1], bmax[2]);
/* 1370 */     int minx = min.x;
/* 1371 */     int miny = min.y;
/* 1372 */     int maxx = max.x;
/* 1373 */     int maxy = max.y;
/*      */ 
/* 1379 */     int MaxNeis = 32;
/* 1380 */     MeshTile[] neis = new MeshTile[MaxNeis];
/*      */ 
/* 1382 */     int n = 0;
/* 1383 */     for (int y = miny; y <= maxy; y++)
/*      */     {
/* 1385 */       for (int x = minx; x <= maxx; x++)
/*      */       {
/* 1387 */         int nneis = this.NavMesh.GetTilesAt(x, y, neis, MaxNeis);
/* 1388 */         for (int j = 0; j < nneis; j++)
/*      */         {
/* 1391 */           long[] tempPolys = new long[maxPolys - n];
/* 1392 */           int tempn = QueryPolygonsInTile(neis[j], bmin, bmax, filter, tempPolys, maxPolys - n);
/* 1393 */           for (int i = 0; i < tempn; i++)
/*      */           {
/* 1395 */             polys[(n + i)] = tempPolys[i];
/*      */           }
/* 1397 */           n += tempn;
/* 1398 */           if (n < maxPolys)
/*      */             continue;
/* 1400 */           statusReturn.intValue = n;
/* 1401 */           statusReturn.status = EnumSet.of(Status.Success, Status.BufferTooSmall);
/* 1402 */           return statusReturn;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1407 */     statusReturn.intValue = n;
/* 1408 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn FindLocalNeighbourhood(long startRef, float[] centerPos, float radius, QueryFilter filter, long[] resultRef, long[] resultParent, int maxResult)
/*      */   {
/*      */     try
/*      */     {
/* 1416 */       if (this.NavMesh == null)
/* 1417 */         throw new Exception("NavMesh is not initialized");
/* 1418 */       if (this._tinyNodePool == null)
/* 1419 */         throw new Exception("tinyNodePool is not initialized");
/* 1420 */       if (filter == null)
/* 1421 */         throw new Exception("QueryFilter cannot be null");
/*      */     } catch (Exception e) {
/* 1423 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1427 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/* 1428 */     statusReturn.intValue = 0;
/*      */ 
/* 1430 */     if ((startRef <= 0L) || (!this.NavMesh.IsValidPolyRef(startRef).booleanValue())) {
/* 1431 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */ 
/* 1433 */       return statusReturn;
/*      */     }
/*      */ 
/* 1437 */     int MaxStack = 48;
/* 1438 */     Node[] stack = new Node[MaxStack];
/* 1439 */     int nstack = 0;
/*      */ 
/* 1441 */     this._tinyNodePool.Clear();
/*      */ 
/* 1443 */     Node startNode = this._tinyNodePool.GetNode(startRef);
/* 1444 */     startNode.PIdx = 0L;
/* 1445 */     startNode.Id = startRef;
/* 1446 */     startNode.Flags = Node.NodeClosed;
/* 1447 */     stack[(nstack++)] = startNode;
/*      */ 
/* 1449 */     float radiusSqr = radius * radius;
/*      */ 
/* 1451 */     float[] pa = new float[NavMeshBuilder.VertsPerPoly * 3];
/* 1452 */     float[] pb = new float[NavMeshBuilder.VertsPerPoly * 3];
/*      */ 
/* 1454 */     statusReturn.status = EnumSet.of(Status.Success);
/*      */ 
/* 1456 */     int n = 0;
/* 1457 */     if (n < maxResult)
/*      */     {
/* 1459 */       resultRef[n] = startNode.Id;
/* 1460 */       if (resultParent != null)
/* 1461 */         resultParent[n] = 0L;
/* 1462 */       n++;
/*      */     }
/*      */     else
/*      */     {
/* 1466 */       statusReturn.status.add(Status.BufferTooSmall);
/*      */     }
/*      */ 
/* 1469 */     while (nstack > 0)
/*      */     {
/* 1472 */       Node curNode = stack[0];
/* 1473 */       for (int i = 0; i < nstack - 1; i++)
/*      */       {
/* 1475 */         stack[i] = stack[(i + 1)];
/*      */       }
/* 1477 */       nstack--;
/*      */ 
/* 1479 */       long curRef = curNode.Id;
/*      */ 
/* 1481 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(curRef);
/* 1482 */       MeshTile curTile = tileAndPoly.tile;
/* 1483 */       Poly curPoly = tileAndPoly.poly;
/*      */ 
/* 1487 */       for (long i = curPoly.FirstLink; i != NavMesh.NullLink; i = curTile.Links[(int)i].Next)
/*      */       {
/* 1489 */         Link link = curTile.Links[(int)i];
/*      */ 
/* 1491 */         long neighborRef = link.Ref;
/*      */ 
/* 1493 */         if (neighborRef <= 0L) {
/*      */           continue;
/*      */         }
/* 1496 */         Node neighborNode = this._tinyNodePool.GetNode(neighborRef);
/* 1497 */         if (neighborNode == null)
/*      */           continue;
/* 1499 */         if ((neighborNode.Flags & Node.NodeClosed) != 0L) {
/*      */           continue;
/*      */         }
/* 1502 */         DetourMeshTileAndPoly neitileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(neighborRef);
/* 1503 */         MeshTile neighborTile = neitileAndPoly.tile;
/* 1504 */         Poly neighborPoly = neitileAndPoly.poly;
/* 1505 */         if (neighborPoly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection) {
/*      */           continue;
/*      */         }
/* 1508 */         if (!filter.PassFilter(neighborRef, neighborTile, neighborPoly).booleanValue()) {
/*      */           continue;
/*      */         }
/* 1511 */         float[] va = new float[3]; float[] vb = new float[3];
/* 1512 */         if (!GetPortalPoints(curRef, curPoly, curTile, neighborRef, neighborPoly, neighborTile, va, vb).contains(Status.Success)) {
/*      */           continue;
/*      */         }
/* 1515 */         float distSqr = (float)Helper.DistancePtSegSqr2D(centerPos[0], centerPos[1], centerPos[2], va[0], va[1], va[2], vb[0], vb[1], vb[2]).x;
/* 1516 */         if (distSqr > radiusSqr) {
/*      */           continue;
/*      */         }
/* 1519 */         neighborNode.Flags |= Node.NodeClosed;
/* 1520 */         neighborNode.PIdx = this._tinyNodePool.GetNodeIdx(curNode);
/*      */ 
/* 1522 */         int npa = neighborPoly.VertCount;
/* 1523 */         for (int k = 0; k < npa; k++)
/*      */         {
/* 1525 */           System.arraycopy(neighborTile.Verts, neighborPoly.Verts[k] * 3, pa, k * 3, 3);
/*      */         }
/*      */ 
/* 1528 */         Boolean overlap = Boolean.valueOf(false);
/* 1529 */         for (int j = 0; j < n; j++)
/*      */         {
/* 1531 */           long pastRef = resultRef[j];
/*      */ 
/* 1533 */           Boolean connected = Boolean.valueOf(false);
/* 1534 */           for (long k = curPoly.FirstLink; k != NavMesh.NullLink; k = curTile.Links[(int)k].Next)
/*      */           {
/* 1536 */             if (curTile.Links[(int)k].Ref != pastRef)
/*      */               continue;
/* 1538 */             connected = Boolean.valueOf(true);
/* 1539 */             break;
/*      */           }
/*      */ 
/* 1542 */           if (connected.booleanValue()) {
/*      */             continue;
/*      */           }
/* 1545 */           DetourMeshTileAndPoly pastTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(pastRef);
/* 1546 */           MeshTile pastTile = pastTileAndPoly.tile;
/* 1547 */           Poly pastPoly = pastTileAndPoly.poly;
/*      */ 
/* 1549 */           if ((pastTile == null) || (pastPoly == null))
/*      */             try {
/* 1551 */               throw new Exception("past is null");
/*      */             }
/*      */             catch (Exception e) {
/* 1554 */               e.printStackTrace();
/*      */             }
/* 1556 */           int npb = pastPoly.VertCount;
/* 1557 */           for (int k = 0; k < npb; k++)
/*      */           {
/* 1559 */             System.arraycopy(pastTile.Verts, pastPoly.Verts[k] * 3, pb, k * 3, 3);
/*      */           }
/*      */ 
/* 1562 */           if (!Helper.OverlapPolyPoly2D(pa, npa, pb, npb).booleanValue())
/*      */             continue;
/* 1564 */           overlap = Boolean.valueOf(true);
/* 1565 */           break;
/*      */         }
/*      */ 
/* 1568 */         if (overlap.booleanValue())
/*      */           continue;
/* 1570 */         if (n < maxResult)
/*      */         {
/* 1572 */           resultRef[n] = neighborRef;
/* 1573 */           if (resultParent != null)
/* 1574 */             resultParent[n] = curRef;
/* 1575 */           n++;
/*      */         }
/*      */         else
/*      */         {
/* 1579 */           statusReturn.status.add(Status.BufferTooSmall);
/*      */         }
/*      */ 
/* 1582 */         if (nstack >= MaxStack)
/*      */           continue;
/* 1584 */         stack[(nstack++)] = neighborNode;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1589 */     statusReturn.intValue = n;
/* 1590 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn MoveAlongSurface(long startRef, float[] startPos, float[] endPos, QueryFilter filter, float[] resultPos, long[] visited, int maxVisitedSize)
/*      */   {
/*      */     try
/*      */     {
/* 1597 */       if (this.NavMesh == null)
/* 1598 */         throw new Exception("NavMesh is not initialized");
/* 1599 */       if (this._tinyNodePool == null)
/* 1600 */         throw new Exception("tinyNodePool is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 1603 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1606 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */ 
/* 1608 */     statusReturn.intValue = 0;
/*      */ 
/* 1610 */     if (startRef <= 0L) {
/* 1611 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 1612 */       return statusReturn;
/*      */     }
/* 1614 */     if (!this.NavMesh.IsValidPolyRef(startRef).booleanValue()) {
/* 1615 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 1616 */       return statusReturn;
/*      */     }
/*      */ 
/* 1619 */     Status status = Status.Success;
/*      */ 
/* 1621 */     int MaxStack = 48;
/* 1622 */     Node[] stack = new Node[MaxStack];
/* 1623 */     int nstack = 0;
/*      */ 
/* 1625 */     this._tinyNodePool.Clear();
/*      */ 
/* 1627 */     Node startNode = this._tinyNodePool.GetNode(startRef);
/* 1628 */     startNode.PIdx = 0L;
/* 1629 */     startNode.Cost = 0.0F;
/* 1630 */     startNode.Total = 0.0F;
/* 1631 */     startNode.Id = startRef;
/* 1632 */     startNode.Flags = Node.NodeClosed;
/* 1633 */     stack[(nstack++)] = startNode;
/*      */ 
/* 1635 */     float[] bestPos = new float[3];
/* 1636 */     float bestDist = 3.4028235E+38F;
/* 1637 */     Node bestNode = null;
/* 1638 */     System.arraycopy(startPos, 0, bestPos, 0, 3);
/*      */ 
/* 1640 */     float[] searchPos = new float[3];
/*      */ 
/* 1642 */     searchPos = Helper.VLerp(searchPos, startPos[0], startPos[1], startPos[2], endPos[0], endPos[1], endPos[2], 0.5F);
/* 1643 */     float searchRadSqr = Helper.VDist(startPos[0], startPos[1], startPos[2], endPos[0], endPos[1], endPos[2]) / 2.0F + 0.001F;
/*      */ 
/* 1645 */     searchRadSqr *= searchRadSqr;
/*      */ 
/* 1647 */     float[] verts = new float[NavMeshBuilder.VertsPerPoly * 3];
/*      */ 
/* 1649 */     while (nstack > 0)
/*      */     {
/* 1651 */       Node curNode = stack[0];
/* 1652 */       for (int i = 0; i < nstack - 1; i++)
/*      */       {
/* 1654 */         stack[i] = stack[(i + 1)];
/*      */       }
/* 1656 */       nstack--;
/*      */ 
/* 1658 */       long curRef = curNode.Id;
/* 1659 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(curRef);
/* 1660 */       MeshTile curTile = tileAndPoly.tile;
/* 1661 */       Poly curPoly = tileAndPoly.poly;
/*      */ 
/* 1663 */       int nverts = curPoly.VertCount;
/* 1664 */       for (int i = 0; i < nverts; i++)
/*      */       {
/* 1666 */         System.arraycopy(curTile.Verts, curPoly.Verts[i] * 3, verts, i * 3, 3);
/*      */       }
/*      */ 
/* 1669 */       if (Helper.PointInPolygon(endPos[0], endPos[1], endPos[2], verts, nverts).booleanValue())
/*      */       {
/* 1671 */         bestNode = curNode;
/* 1672 */         System.arraycopy(endPos, 0, bestPos, 0, 3);
/* 1673 */         break;
/*      */       }
/*      */ 
/* 1676 */       int i = 0; for (int j = curPoly.VertCount - 1; i < curPoly.VertCount; j = i++)
/*      */       {
/* 1678 */         int MaxNeis = 8;
/* 1679 */         int nneis = 0;
/* 1680 */         long[] neis = new long[MaxNeis];
/*      */ 
/* 1682 */         if ((curPoly.Neis[j] & NavMeshBuilder.ExtLink) != 0)
/*      */         {
/* 1684 */           for (long k = curPoly.FirstLink; k != NavMesh.NullLink; k = curTile.Links[(int)k].Next)
/*      */           {
/* 1686 */             Link link = curTile.Links[(int)k];
/* 1687 */             if (link.Edge != j)
/*      */               continue;
/* 1689 */             if (link.Ref == 0L) {
/*      */               continue;
/*      */             }
/* 1692 */             DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(link.Ref);
/* 1693 */             MeshTile neiTile = neiTileAndPoly.tile;
/* 1694 */             Poly neiPoly = neiTileAndPoly.poly;
/* 1695 */             if (!filter.PassFilter(link.Ref, neiTile, neiPoly).booleanValue())
/*      */               continue;
/* 1697 */             if (nneis < MaxNeis) {
/* 1698 */               neis[(nneis++)] = link.Ref;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/* 1704 */         else if (curPoly.Neis[j] > 0)
/*      */         {
/* 1706 */           long idx = curPoly.Neis[j] - 1;
/* 1707 */           long refId = this.NavMesh.GetPolyRefBase(curTile) | idx;
/* 1708 */           if (filter.PassFilter(refId, curTile, curTile.Polys[(int)idx]).booleanValue())
/*      */           {
/* 1710 */             neis[(nneis++)] = refId;
/*      */           }
/*      */         }
/*      */ 
/* 1714 */         if (nneis == 0)
/*      */         {
/* 1716 */           int vj = j * 3;
/* 1717 */           int vi = i * 3;
/*      */ 
/* 1719 */           Vector2 distVect = Helper.DistancePtSegSqr2D(endPos[0], endPos[1], endPos[2], verts[(vj + 0)], verts[(vj + 1)], verts[(vj + 2)], verts[(vi + 0)], verts[(vi + 1)], verts[(vi + 2)]);
/*      */ 
/* 1722 */           float distSqr = (float)distVect.x;
/* 1723 */           float tseg = (float)distVect.y;
/* 1724 */           if (distSqr < bestDist)
/*      */           {
/* 1726 */             bestPos = Helper.VLerp(bestPos, verts[(vj + 0)], verts[(vj + 1)], verts[(vj + 2)], verts[(vi + 0)], verts[(vi + 1)], verts[(vi + 2)], tseg);
/* 1727 */             bestDist = distSqr;
/* 1728 */             bestNode = curNode;
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1733 */           for (int k = 0; k < nneis; k++)
/*      */           {
/* 1735 */             Node neighborNode = this._tinyNodePool.GetNode(neis[k]);
/* 1736 */             if (neighborNode == null)
/*      */               continue;
/* 1738 */             if ((neighborNode.Flags & Node.NodeClosed) != 0L) {
/*      */               continue;
/*      */             }
/* 1741 */             int vj = j * 3;
/* 1742 */             int vi = i * 3;
/* 1743 */             Vector2 distSqr = Helper.DistancePtSegSqr2D(searchPos[0], searchPos[1], searchPos[2], verts[(vj + 0)], verts[(vj + 1)], verts[(vj + 2)], verts[(vi + 0)], verts[(vi + 1)], verts[(vi + 2)]);
/*      */ 
/* 1746 */             if (distSqr.x > searchRadSqr) {
/*      */               continue;
/*      */             }
/* 1749 */             if (nstack >= MaxStack)
/*      */               continue;
/* 1751 */             neighborNode.PIdx = this._tinyNodePool.GetNodeIdx(curNode);
/* 1752 */             neighborNode.Flags |= Node.NodeClosed;
/* 1753 */             stack[(nstack++)] = neighborNode;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1760 */     int n = 0;
/* 1761 */     if (bestNode != null)
/*      */     {
/* 1763 */       Node prev = null;
/* 1764 */       Node node = bestNode;
/*      */       do
/*      */       {
/* 1767 */         Node next = this._tinyNodePool.GetNodeAtIdx(node.PIdx);
/* 1768 */         node.PIdx = this._tinyNodePool.GetNodeIdx(prev);
/* 1769 */         prev = node;
/* 1770 */         node = next;
/* 1771 */       }while (node != null);
/*      */ 
/* 1773 */       node = prev;
/*      */       do
/*      */       {
/* 1776 */         visited[(n++)] = node.Id;
/* 1777 */         if (n >= maxVisitedSize)
/*      */         {
/* 1779 */           statusReturn.status.add(Status.BufferTooSmall);
/*      */         }
/* 1781 */         node = this._tinyNodePool.GetNodeAtIdx(node.PIdx);
/* 1782 */       }while (node != null);
/*      */     }
/* 1784 */     System.arraycopy(bestPos, 0, resultPos, 0, 3);
/* 1785 */     statusReturn.intValue = n;
/* 1786 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourRaycastHit Raycast(long startRef, float[] startPos, float[] endPos, QueryFilter filter, float[] hitNormal, long[] path, int maxPath)
/*      */   {
/*      */     try
/*      */     {
/* 1793 */       if (this.NavMesh == null)
/* 1794 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 1797 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1800 */     DetourRaycastHit statusReturn = new DetourRaycastHit();
/* 1801 */     statusReturn.t = 0.0F;
/* 1802 */     statusReturn.pathCount = 0;
/* 1803 */     if ((startRef <= 0L) || (!this.NavMesh.IsValidPolyRef(startRef).booleanValue())) {
/* 1804 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 1805 */       return statusReturn;
/*      */     }
/*      */ 
/* 1808 */     long curRef = startRef;
/* 1809 */     float[] verts = new float[3 * NavMeshBuilder.VertsPerPoly];
/* 1810 */     int n = 0;
/*      */ 
/* 1812 */     hitNormal[0] = 0.0F;
/* 1813 */     hitNormal[1] = 0.0F;
/* 1814 */     hitNormal[2] = 0.0F;
/*      */ 
/* 1816 */     statusReturn.status = EnumSet.of(Status.Success);
/*      */ 
/* 1818 */     while (curRef > 0L)
/*      */     {
/* 1821 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(curRef);
/* 1822 */       MeshTile tile = tileAndPoly.tile;
/* 1823 */       Poly poly = tileAndPoly.poly;
/*      */ 
/* 1825 */       int nv = 0;
/* 1826 */       for (int i = 0; i < poly.VertCount; i++)
/*      */       {
/* 1828 */         System.arraycopy(tile.Verts, poly.Verts[i] * 3, verts, nv * 3, 3);
/* 1829 */         nv++;
/*      */       }
/*      */ 
/* 1832 */       Vector2 tMinMax = new Vector2();
/* 1833 */       IntVector2 segMinMax = new IntVector2();
/* 1834 */       if (!Helper.IntersectSegmentPoly2D(startPos, endPos, verts, nv, tMinMax, segMinMax).booleanValue())
/*      */       {
/* 1836 */         statusReturn.pathCount = n;
/* 1837 */         return statusReturn;
/*      */       }
/*      */ 
/* 1840 */       if (tMinMax.y > statusReturn.t) {
/* 1841 */         statusReturn.t = (float)tMinMax.y;
/*      */       }
/* 1843 */       if (n < maxPath)
/*      */       {
/* 1845 */         path[(n++)] = curRef;
/*      */       }
/*      */       else
/*      */       {
/* 1849 */         statusReturn.status.add(Status.BufferTooSmall);
/*      */       }
/*      */ 
/* 1852 */       if (segMinMax.y == -1)
/*      */       {
/* 1854 */         statusReturn.t = 3.4028235E+38F;
/* 1855 */         statusReturn.pathCount = n;
/* 1856 */         return statusReturn;
/*      */       }
/*      */ 
/* 1859 */       long nextRef = 0L;
/*      */ 
/* 1861 */       for (long i = poly.FirstLink; i != NavMesh.NullLink; i = tile.Links[(int)i].Next)
/*      */       {
/* 1863 */         Link link = tile.Links[(int)i];
/*      */ 
/* 1865 */         if (link.Edge != segMinMax.y) {
/*      */           continue;
/*      */         }
/* 1868 */         DetourMeshTileAndPoly nextTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(link.Ref);
/* 1869 */         MeshTile nextTile = nextTileAndPoly.tile;
/* 1870 */         Poly nextPoly = nextTileAndPoly.poly;
/*      */ 
/* 1872 */         if (nextPoly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection) {
/*      */           continue;
/*      */         }
/* 1875 */         if (!filter.PassFilter(link.Ref, nextTile, nextPoly).booleanValue()) {
/*      */           continue;
/*      */         }
/* 1878 */         if (link.Side == 255)
/*      */         {
/* 1880 */           nextRef = link.Ref;
/* 1881 */           break;
/*      */         }
/*      */ 
/* 1884 */         if ((link.BMin == 0) && (link.BMax == 255))
/*      */         {
/* 1886 */           nextRef = link.Ref;
/* 1887 */           break;
/*      */         }
/*      */ 
/* 1890 */         int left = poly.Verts[link.Edge] * 3;
/* 1891 */         int right = poly.Verts[((link.Edge + 1) % poly.VertCount)] * 3;
/*      */ 
/* 1893 */         if ((link.Side == 0) || (link.Side == 4))
/*      */         {
/* 1895 */           float s = 0.003921569F;
/* 1896 */           float lmin = tile.Verts[(left + 2)] + (tile.Verts[(right + 2)] - tile.Verts[(left + 2)]) * (link.BMin * s);
/* 1897 */           float lmax = tile.Verts[(left + 2)] + (tile.Verts[(right + 2)] - tile.Verts[(left + 2)]) * (link.BMax * s);
/* 1898 */           if (lmin > lmax)
/*      */           {
/* 1900 */             float temp = lmin;
/* 1901 */             lmin = lmax;
/* 1902 */             lmax = temp;
/*      */           }
/*      */ 
/* 1905 */           float z = (float)(startPos[2] + (endPos[2] - startPos[2]) * tMinMax.y);
/* 1906 */           if ((z >= lmin) && (z <= lmax))
/*      */           {
/* 1908 */             nextRef = link.Ref;
/* 1909 */             break;
/*      */           }
/*      */         } else {
/* 1912 */           if ((link.Side != 2) && (link.Side != 6))
/*      */             continue;
/* 1914 */           float s = 0.003921569F;
/* 1915 */           float lmin = tile.Verts[(left + 0)] + (tile.Verts[(right + 0)] - tile.Verts[(left + 0)]) * (link.BMin * s);
/* 1916 */           float lmax = tile.Verts[(left + 0)] + (tile.Verts[(right + 0)] - tile.Verts[(left + 0)]) * (link.BMax * s);
/* 1917 */           if (lmin > lmax)
/*      */           {
/* 1919 */             float temp = lmin;
/* 1920 */             lmin = lmax;
/* 1921 */             lmax = temp;
/*      */           }
/*      */ 
/* 1924 */           float z = (float)(startPos[0] + (endPos[0] - startPos[0]) * tMinMax.y);
/* 1925 */           if ((z < lmin) || (z > lmax))
/*      */             continue;
/* 1927 */           nextRef = link.Ref;
/* 1928 */           break;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1933 */       if (nextRef == 0L)
/*      */       {
/* 1935 */         int a = segMinMax.y;
/* 1936 */         int b = segMinMax.y + 1 < nv ? segMinMax.y + 1 : 0;
/* 1937 */         float dx = verts[(b * 3 + 0)] - verts[(a * 3 + 0)];
/* 1938 */         float dz = verts[(b * 3 + 2)] - verts[(a * 3 + 2)];
/* 1939 */         hitNormal[0] = dz;
/* 1940 */         hitNormal[1] = 0.0F;
/* 1941 */         hitNormal[2] = (-dx);
/* 1942 */         hitNormal = Helper.VNormalize(hitNormal);
/*      */ 
/* 1944 */         statusReturn.pathCount = n;
/* 1945 */         return statusReturn;
/*      */       }
/* 1947 */       curRef = nextRef;
/*      */     }
/* 1949 */     statusReturn.pathCount = n;
/* 1950 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourNumericReturn FindDistanceToWall(long startRef, float[] centerPos, float maxRadius, QueryFilter filter, float hitDist, float[] hitPos, float[] hitNormal)
/*      */   {
/*      */     try
/*      */     {
/* 1957 */       if (this.NavMesh == null)
/* 1958 */         throw new Exception("NavMesh is not initialized");
/* 1959 */       if (this.NodePool == null)
/* 1960 */         throw new Exception("NodePool is not initialized");
/* 1961 */       if (this._openList == null)
/* 1962 */         throw new Exception("OpenList is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 1965 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1968 */     DetourNumericReturn statusReturn = new DetourNumericReturn();
/*      */ 
/* 1970 */     if ((startRef <= 0L) || (!this.NavMesh.IsValidPolyRef(startRef).booleanValue())) {
/* 1971 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 1972 */       return statusReturn;
/*      */     }
/*      */ 
/* 1975 */     this.NodePool.Clear();
/* 1976 */     this._openList.Clear();
/*      */ 
/* 1978 */     Node startNode = this.NodePool.GetNode(startRef);
/* 1979 */     System.arraycopy(centerPos, 0, startNode.Pos, 0, 3);
/* 1980 */     startNode.PIdx = 0L;
/* 1981 */     startNode.Cost = 0.0F;
/* 1982 */     startNode.Total = 0.0F;
/* 1983 */     startNode.Id = startRef;
/* 1984 */     startNode.Flags = Node.NodeOpen;
/* 1985 */     this._openList.Push(startNode);
/*      */ 
/* 1987 */     float radiusSqr = maxRadius * maxRadius;
/*      */ 
/* 1989 */     statusReturn.status = EnumSet.of(Status.Success);
/*      */ 
/* 1991 */     while (!this._openList.Empty().booleanValue())
/*      */     {
/* 1993 */       Node bestNode = this._openList.Pop();
/* 1994 */       bestNode.Flags &= (Node.NodeOpen ^ 0xFFFFFFFF);
/* 1995 */       bestNode.Flags |= Node.NodeClosed;
/*      */ 
/* 1997 */       long bestRef = bestNode.Id;
/*      */ 
/* 2000 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(bestRef);
/* 2001 */       MeshTile bestTile = tileAndPoly.tile;
/* 2002 */       Poly bestPoly = tileAndPoly.poly;
/*      */ 
/* 2004 */       long parentRef = 0L;
/* 2005 */       MeshTile parentTile = null;
/* 2006 */       Poly parentPoly = null;
/*      */ 
/* 2008 */       if (bestNode.PIdx > 0L)
/* 2009 */         parentRef = this.NodePool.GetNodeAtIdx(bestNode.PIdx).Id;
/* 2010 */       if (parentRef > 0L) {
/* 2011 */         DetourMeshTileAndPoly parentTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(parentRef);
/* 2012 */         parentTile = parentTileAndPoly.tile;
/* 2013 */         parentPoly = parentTileAndPoly.poly;
/*      */       }
/*      */ 
/* 2016 */       int i = 0; for (int j = bestPoly.VertCount - 1; i < bestPoly.VertCount; j = i++)
/*      */       {
/* 2018 */         if ((bestPoly.Neis[j] & NavMeshBuilder.ExtLink) != 0)
/*      */         {
/* 2020 */           Boolean solid = Boolean.valueOf(true);
/* 2021 */           for (long k = bestPoly.FirstLink; k < NavMesh.NullLink; k = bestTile.Links[(int)k].Next)
/*      */           {
/* 2023 */             Link link = bestTile.Links[(int)k];
/* 2024 */             if (link.Edge != j)
/*      */               continue;
/* 2026 */             if (link.Ref == 0L)
/*      */               break;
/* 2028 */             DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(link.Ref);
/* 2029 */             MeshTile neiTile = neiTileAndPoly.tile;
/* 2030 */             Poly neiPoly = neiTileAndPoly.poly;
/* 2031 */             if (filter.PassFilter(link.Ref, neiTile, neiPoly).booleanValue())
/* 2032 */               solid = Boolean.valueOf(false);
/* 2033 */             break;
/*      */           }
/*      */ 
/* 2037 */           if (!solid.booleanValue()) continue;
/*      */         }
/* 2039 */         else if (bestPoly.Neis[j] > 0)
/*      */         {
/* 2041 */           long idx = bestPoly.Neis[j] - 1;
/* 2042 */           long refId = this.NavMesh.GetPolyRefBase(bestTile) | idx;
/* 2043 */           if (filter.PassFilter(refId, bestTile, bestTile.Polys[(int)idx]).booleanValue()) {
/*      */             continue;
/*      */           }
/*      */         }
/* 2047 */         int vj = bestPoly.Verts[j] * 3;
/* 2048 */         int vi = bestPoly.Verts[i] * 3;
/*      */ 
/* 2050 */         Vector2 distVec = Helper.DistancePtSegSqr2D(centerPos[0], centerPos[1], centerPos[2], bestTile.Verts[(vj + 0)], bestTile.Verts[(vj + 1)], bestTile.Verts[(vj + 2)], bestTile.Verts[(vi + 0)], bestTile.Verts[(vi + 1)], bestTile.Verts[(vi + 2)]);
/*      */ 
/* 2054 */         float distSqr = (float)distVec.x;
/* 2055 */         float tseg = (float)distVec.y;
/* 2056 */         if (distSqr > radiusSqr) {
/*      */           continue;
/*      */         }
/* 2059 */         radiusSqr = distSqr;
/*      */ 
/* 2061 */         hitPos[0] = (bestTile.Verts[(vj + 0)] + (bestTile.Verts[(vi + 0)] - bestTile.Verts[(vj + 0)]) * tseg);
/* 2062 */         hitPos[0] = (bestTile.Verts[(vj + 1)] + (bestTile.Verts[(vi + 1)] - bestTile.Verts[(vj + 1)]) * tseg);
/* 2063 */         hitPos[0] = (bestTile.Verts[(vj + 2)] + (bestTile.Verts[(vi + 2)] - bestTile.Verts[(vj + 2)]) * tseg);
/*      */       }
/*      */ 
/* 2066 */       for (long i = bestPoly.FirstLink; i != NavMesh.NullLink; i += 1L)
/*      */       {
/* 2068 */         Link link = bestTile.Links[(int)i];
/* 2069 */         long neighborRef = link.Ref;
/*      */ 
/* 2071 */         if ((neighborRef <= 0L) || (neighborRef == parentRef))
/*      */         {
/*      */           continue;
/*      */         }
/* 2075 */         DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(neighborRef);
/* 2076 */         MeshTile neighborTile = neiTileAndPoly.tile;
/* 2077 */         Poly neighborPoly = neiTileAndPoly.poly;
/*      */ 
/* 2079 */         if (neighborPoly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection) {
/*      */           continue;
/*      */         }
/* 2082 */         int va = bestPoly.Verts[link.Edge] * 3;
/* 2083 */         int vb = bestPoly.Verts[((link.Edge + 1) % bestPoly.VertCount)] * 3;
/* 2084 */         Vector2 distSqr = Helper.DistancePtSegSqr2D(centerPos[0], centerPos[1], centerPos[2], bestTile.Verts[(va + 0)], bestTile.Verts[(va + 1)], bestTile.Verts[(va + 2)], bestTile.Verts[(vb + 0)], bestTile.Verts[(vb + 1)], bestTile.Verts[(vb + 2)]);
/*      */ 
/* 2088 */         if (distSqr.x > radiusSqr) {
/*      */           continue;
/*      */         }
/* 2091 */         if (!filter.PassFilter(neighborRef, neighborTile, neighborPoly).booleanValue()) {
/*      */           continue;
/*      */         }
/* 2094 */         Node neighborNode = this.NodePool.GetNode(neighborRef);
/* 2095 */         if (neighborNode == null)
/*      */         {
/* 2097 */           statusReturn.status.add(Status.OutOfNodes);
/*      */         }
/*      */         else
/*      */         {
/* 2101 */           if ((neighborNode.Flags & Node.NodeClosed) != 0L) {
/*      */             continue;
/*      */           }
/* 2104 */           if (neighborNode.Flags == 0L)
/*      */           {
/* 2106 */             float[] temp = new float[3];
/* 2107 */             GetEdgeMidPoint(bestRef, bestPoly, bestTile, neighborRef, neighborPoly, neighborTile, temp);
/* 2108 */             System.arraycopy(temp, 0, neighborNode.Pos, 0, 3);
/*      */           }
/*      */ 
/* 2111 */           float total = bestNode.Total + Helper.VDist(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2]);
/*      */ 
/* 2113 */           if (((neighborNode.Flags & Node.NodeOpen) != 0L) && (total >= neighborNode.Total)) {
/*      */             continue;
/*      */           }
/* 2116 */           neighborNode.Id = neighborRef;
/* 2117 */           neighborNode.Flags &= (Node.NodeClosed ^ 0xFFFFFFFF);
/* 2118 */           neighborNode.PIdx = this.NodePool.GetNodeIdx(bestNode);
/* 2119 */           neighborNode.Total = total;
/*      */ 
/* 2121 */           if ((neighborNode.Flags & Node.NodeOpen) != 0L)
/*      */           {
/* 2123 */             this._openList.Modify(neighborNode);
/*      */           }
/*      */           else
/*      */           {
/* 2127 */             neighborNode.Flags |= Node.NodeOpen;
/* 2128 */             this._openList.Push(neighborNode);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2133 */     hitNormal = Helper.VSub(centerPos[0], centerPos[1], centerPos[2], hitPos[0], hitPos[1], hitPos[2]);
/* 2134 */     hitNormal = Helper.VNormalize(hitNormal);
/*      */ 
/* 2136 */     statusReturn.floatValue = (float)Math.sqrt(radiusSqr);
/*      */ 
/* 2138 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn GetPolyWallSegments(long refId, QueryFilter filter, float[] segmentVerts, long[] segmentRefs, int maxSegments)
/*      */   {
/*      */     try
/*      */     {
/* 2145 */       if (this.NavMesh == null)
/* 2146 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 2149 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 2152 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */ 
/* 2154 */     statusReturn.intValue = 0;
/*      */ 
/* 2156 */     DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(refId);
/* 2157 */     if (tileAndPoly.status.contains(Status.Failure)) {
/* 2158 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 2159 */       return statusReturn;
/*      */     }
/* 2161 */     MeshTile tile = tileAndPoly.tile;
/* 2162 */     Poly poly = tileAndPoly.poly;
/*      */ 
/* 2164 */     int n = 0;
/* 2165 */     int MaxInterval = 16;
/* 2166 */     SegInterval[] ints = new SegInterval[MaxInterval];
/* 2167 */     for (int i = 0; i < MaxInterval; i++)
/*      */     {
/* 2169 */       ints[i] = new SegInterval();
/*      */     }
/*      */ 
/* 2173 */     Boolean storePortals = Boolean.valueOf(segmentRefs != null);
/*      */ 
/* 2175 */     statusReturn.status = EnumSet.of(Status.Success);
/*      */ 
/* 2177 */     int i = 0; for (int j = poly.VertCount - 1; i < poly.VertCount; j = i++)
/*      */     {
/* 2179 */       int nints = 0;
/* 2180 */       if ((poly.Neis[j] & NavMeshBuilder.ExtLink) != 0)
/*      */       {
/* 2182 */         for (long k = poly.FirstLink; k != NavMesh.NullLink; k = tile.Links[(int)k].Next)
/*      */         {
/* 2184 */           Link link = tile.Links[(int)k];
/* 2185 */           if (link.Edge != j)
/*      */             continue;
/* 2187 */           if (link.Ref == 0L)
/*      */             continue;
/* 2189 */           DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(link.Ref);
/* 2190 */           MeshTile neiTile = neiTileAndPoly.tile;
/* 2191 */           Poly neiPoly = neiTileAndPoly.poly;
/* 2192 */           if (!filter.PassFilter(link.Ref, neiTile, neiPoly).booleanValue())
/*      */             continue;
/* 2194 */           InsertInterval(ints, nints, MaxInterval, link.BMin, link.BMax, link.Ref);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 2202 */         long neiRef = 0L;
/* 2203 */         if (poly.Neis[j] > 0)
/*      */         {
/* 2205 */           long idx = poly.Neis[j] - 1;
/* 2206 */           neiRef = this.NavMesh.GetPolyRefBase(tile) | idx;
/* 2207 */           if (!filter.PassFilter(neiRef, tile, tile.Polys[(int)idx]).booleanValue()) {
/* 2208 */             neiRef = 0L;
/*      */           }
/*      */         }
/* 2211 */         if ((neiRef != 0L) && (!storePortals.booleanValue())) {
/*      */           continue;
/*      */         }
/* 2214 */         if (n < maxSegments)
/*      */         {
/* 2216 */           int vj1 = poly.Verts[j] * 3;
/* 2217 */           int vi1 = poly.Verts[i] * 3;
/* 2218 */           System.arraycopy(tile.Verts, vj1, segmentVerts, n * 6, 3);
/* 2219 */           System.arraycopy(tile.Verts, vi1, segmentVerts, n * 6 + 3, 3);
/* 2220 */           if (segmentRefs != null)
/* 2221 */             segmentRefs[n] = neiRef;
/* 2222 */           n++;
/* 2223 */           continue;
/*      */         }
/*      */ 
/* 2226 */         statusReturn.status.add(Status.BufferTooSmall);
/*      */ 
/* 2228 */         continue;
/*      */       }
/*      */ 
/* 2231 */       InsertInterval(ints, nints, MaxInterval, -1, 0, 0L);
/* 2232 */       InsertInterval(ints, nints, MaxInterval, 255, 256, 0L);
/*      */ 
/* 2234 */       int vj = poly.Verts[j] * 3;
/* 2235 */       int vi = poly.Verts[i] * 3;
/* 2236 */       for (int k = 1; k < nints; k++)
/*      */       {
/* 2238 */         if ((storePortals.booleanValue()) && (ints[k].RefId > 0L))
/*      */         {
/* 2240 */           float tmin = ints[k].TMin / 255.0F;
/* 2241 */           float tmax = ints[k].TMax / 255.0F;
/* 2242 */           if (n < maxSegments)
/*      */           {
/* 2244 */             float[] temp = new float[3];
/* 2245 */             temp = Helper.VLerp(temp, tile.Verts[(vj + 0)], tile.Verts[(vj + 1)], tile.Verts[(vj + 2)], tile.Verts[(vi + 0)], tile.Verts[(vi + 1)], tile.Verts[(vi + 2)], tmin);
/* 2246 */             System.arraycopy(temp, 0, segmentVerts, n * 6, 3);
/* 2247 */             temp = Helper.VLerp(temp, tile.Verts[(vj + 0)], tile.Verts[(vj + 1)], tile.Verts[(vj + 2)], tile.Verts[(vi + 0)], tile.Verts[(vi + 1)], tile.Verts[(vi + 2)], tmax);
/* 2248 */             System.arraycopy(temp, 0, segmentVerts, n * 6 + 3, 3);
/* 2249 */             if (segmentRefs != null)
/* 2250 */               segmentRefs[n] = ints[k].RefId;
/* 2251 */             n++;
/*      */           }
/*      */           else
/*      */           {
/* 2255 */             statusReturn.status.add(Status.BufferTooSmall);
/*      */           }
/*      */         }
/* 2258 */         int imin = ints[(k - 1)].TMax;
/* 2259 */         int imax = ints[k].TMin;
/* 2260 */         if (imin == imax)
/*      */           continue;
/* 2262 */         float tmin = imin / 255.0F;
/* 2263 */         float tmax = imax / 255.0F;
/* 2264 */         if (n < maxSegments)
/*      */         {
/* 2266 */           float[] temp = new float[3];
/* 2267 */           temp = Helper.VLerp(temp, tile.Verts[(vj + 0)], tile.Verts[(vj + 1)], tile.Verts[(vj + 2)], tile.Verts[(vi + 0)], tile.Verts[(vi + 1)], tile.Verts[(vi + 2)], tmin);
/* 2268 */           System.arraycopy(temp, 0, segmentVerts, n * 6, 3);
/* 2269 */           temp = Helper.VLerp(temp, tile.Verts[(vj + 0)], tile.Verts[(vj + 1)], tile.Verts[(vj + 2)], tile.Verts[(vi + 0)], tile.Verts[(vi + 1)], tile.Verts[(vi + 2)], tmax);
/* 2270 */           System.arraycopy(temp, 0, segmentVerts, n * 6 + 3, 3);
/* 2271 */           if (segmentRefs != null)
/* 2272 */             segmentRefs[n] = 0L;
/* 2273 */           n++;
/*      */         }
/*      */         else
/*      */         {
/* 2277 */           statusReturn.status.add(Status.BufferTooSmall);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2283 */     statusReturn.intValue = n;
/* 2284 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public static int InsertInterval(SegInterval[] ints, int nints, int maxInts, short tmin, short tmax, long refId)
/*      */   {
/* 2289 */     if (nints + 1 > maxInts) return nints;
/*      */ 
/* 2291 */     int idx = 0;
/* 2292 */     while (idx < nints)
/*      */     {
/* 2294 */       if (tmax <= ints[idx].TMin)
/*      */         break;
/* 2296 */       idx++;
/*      */     }
/*      */ 
/* 2299 */     if (nints - idx > 0)
/*      */     {
/* 2301 */       System.arraycopy(ints, idx, ints, idx + 1, nints - idx);
/*      */     }
/* 2303 */     ints[idx].RefId = refId;
/* 2304 */     ints[idx].TMin = tmin;
/* 2305 */     ints[idx].TMax = tmax;
/* 2306 */     nints++;
/* 2307 */     return nints;
/*      */   }
/*      */ 
/*      */   public DetourNumericReturn FindRandomPoint(QueryFilter filter, Random func, long randomRef, float[] randomPt)
/*      */   {
/* 2312 */     DetourNumericReturn statusReturn = new DetourNumericReturn();
/*      */ 
/* 2314 */     if (this.NavMesh == null) {
/* 2315 */       statusReturn.status = EnumSet.of(Status.Failure);
/* 2316 */       return statusReturn;
/*      */     }
/*      */ 
/* 2319 */     MeshTile tile = null;
/* 2320 */     float tsum = 0.0F;
/* 2321 */     for (int i = 0; i < this.NavMesh.GetMaxTiles(); i++)
/*      */     {
/* 2323 */       MeshTile temp = this.NavMesh.GetTile(i);
/* 2324 */       if ((temp == null) || (temp.Header == null)) {
/*      */         continue;
/*      */       }
/* 2327 */       float area = 1.0F;
/* 2328 */       tsum += area;
/* 2329 */       float u = func.nextFloat();
/* 2330 */       if (u * tsum <= area)
/* 2331 */         tile = temp;
/*      */     }
/* 2333 */     if (tile == null) {
/* 2334 */       statusReturn.status = EnumSet.of(Status.Failure);
/* 2335 */       return statusReturn;
/*      */     }
/*      */ 
/* 2338 */     Poly poly = null;
/* 2339 */     long polyRef = 0L;
/* 2340 */     long baseRef = (int)this.NavMesh.GetPolyRefBase(tile);
/*      */ 
/* 2342 */     float areaSum = 0.0F;
/* 2343 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/* 2345 */       Poly p = tile.Polys[i];
/*      */ 
/* 2347 */       if (p.getType() != NavMeshBuilder.PolyTypeGround) {
/*      */         continue;
/*      */       }
/* 2350 */       long refId = baseRef | i;
/* 2351 */       if (!filter.PassFilter(refId, tile, p).booleanValue()) {
/*      */         continue;
/*      */       }
/* 2354 */       float polyArea = 0.0F;
/* 2355 */       for (int j = 2; j < p.VertCount; j++)
/*      */       {
/* 2357 */         float[] va = new float[3]; float[] vb = new float[3]; float[] vc = new float[3];
/* 2358 */         System.arraycopy(tile.Verts, p.Verts[0] * 3, va, 0, 3);
/* 2359 */         System.arraycopy(tile.Verts, p.Verts[(j - 1)] * 3, vb, 0, 3);
/* 2360 */         System.arraycopy(tile.Verts, p.Verts[j] * 3, vc, 0, 3);
/* 2361 */         polyArea += Helper.TriArea2D(va, vb, vc);
/*      */       }
/* 2363 */       areaSum += polyArea;
/* 2364 */       float u = func.nextFloat();
/* 2365 */       if (u * areaSum > polyArea)
/*      */         continue;
/* 2367 */       poly = p;
/* 2368 */       polyRef = refId;
/*      */     }
/*      */ 
/* 2371 */     if (poly == null) {
/* 2372 */       statusReturn.status = EnumSet.of(Status.Failure);
/* 2373 */       return statusReturn;
/*      */     }
/*      */ 
/* 2376 */     int v = poly.Verts[0] * 3;
/* 2377 */     float[] verts = new float[3 * NavMeshBuilder.VertsPerPoly];
/* 2378 */     float[] areas = new float[NavMeshBuilder.VertsPerPoly];
/* 2379 */     System.arraycopy(tile.Verts, v, verts, 0, 3);
/* 2380 */     for (int j = 1; j < poly.VertCount; j++)
/*      */     {
/* 2382 */       v = poly.Verts[j] * 3;
/* 2383 */       System.arraycopy(tile.Verts, v, verts, j * 3, 3);
/*      */     }
/*      */ 
/* 2386 */     float s = func.nextFloat();
/* 2387 */     float t = func.nextFloat();
/*      */ 
/* 2389 */     float[] pt = new float[3];
/* 2390 */     Helper.RandomPointInConvexPoly(verts, poly.VertCount, areas, s, t, pt);
/*      */ 
/* 2392 */     float h = 0.0F;
/* 2393 */     DetourNumericReturn status = GetPolyHeight(polyRef, pt, h);
/*      */ 
/* 2395 */     if (status.status.contains(Status.Failure)) {
/* 2396 */       return status;
/*      */     }
/* 2398 */     pt[1] = status.floatValue;
/*      */ 
/* 2400 */     System.arraycopy(pt, 0, randomPt, 0, 3);
/* 2401 */     statusReturn.longValue = polyRef;
/* 2402 */     statusReturn.status = EnumSet.of(Status.Success);
/* 2403 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public DetourNumericReturn FindRandomPointAroundCircle(long startRef, float[] centerPos, float radius, QueryFilter filter, Random frand, long randomRef, float[] randomPt)
/*      */   {
/* 2409 */     DetourNumericReturn statusReturn = new DetourNumericReturn();
/*      */ 
/* 2411 */     if ((this.NavMesh == null) || (this.NodePool == null) || (this._openList == null)) {
/* 2412 */       statusReturn.status = EnumSet.of(Status.Failure);
/* 2413 */       return statusReturn;
/*      */     }
/*      */ 
/* 2416 */     if ((startRef <= 0L) || (!this.NavMesh.IsValidPolyRef(startRef).booleanValue())) {
/* 2417 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 2418 */       return statusReturn;
/*      */     }
/*      */ 
/* 2421 */     DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(startRef);
/* 2422 */     MeshTile startTile = tileAndPoly.tile;
/* 2423 */     Poly startPoly = tileAndPoly.poly;
/*      */ 
/* 2425 */     if (!filter.PassFilter(startRef, startTile, startPoly).booleanValue()) {
/* 2426 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 2427 */       return statusReturn;
/*      */     }
/*      */ 
/* 2430 */     this.NodePool.Clear();
/* 2431 */     this._openList.Clear();
/*      */ 
/* 2433 */     Node startNode = this.NodePool.GetNode(startRef);
/* 2434 */     System.arraycopy(centerPos, 0, startNode.Pos, 0, 3);
/* 2435 */     startNode.PIdx = 0L;
/* 2436 */     startNode.Cost = 0.0F;
/* 2437 */     startNode.Total = 0.0F;
/* 2438 */     startNode.Id = startRef;
/* 2439 */     startNode.Flags = Node.NodeOpen;
/* 2440 */     this._openList.Push(startNode);
/*      */ 
/* 2442 */     statusReturn.status = EnumSet.of(Status.Success);
/*      */ 
/* 2444 */     float radiusSqr = radius * radius;
/* 2445 */     float areaSum = 0.0F;
/*      */ 
/* 2447 */     MeshTile randomTile = null;
/* 2448 */     Poly randomPoly = null;
/* 2449 */     long randomPolyRef = 0L;
/*      */ 
/* 2451 */     while (!this._openList.Empty().booleanValue())
/*      */     {
/* 2453 */       Node bestNode = this._openList.Pop();
/* 2454 */       bestNode.Flags &= Node.NodeOpen;
/* 2455 */       bestNode.Flags |= Node.NodeClosed;
/*      */ 
/* 2457 */       long bestRef = bestNode.Id;
/* 2458 */       DetourMeshTileAndPoly bestTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(bestRef);
/* 2459 */       MeshTile bestTile = bestTileAndPoly.tile;
/* 2460 */       Poly bestPoly = bestTileAndPoly.poly;
/*      */ 
/* 2462 */       if (bestPoly.getType() == NavMeshBuilder.PolyTypeGround)
/*      */       {
/* 2464 */         float polyArea = 0.0F;
/* 2465 */         for (int j = 2; j < bestPoly.VertCount; j++)
/*      */         {
/* 2467 */           float[] va = new float[3]; float[] vb = new float[3]; float[] vc = new float[3];
/* 2468 */           System.arraycopy(bestTile.Verts, bestPoly.Verts[0] * 3, va, 0, 3);
/* 2469 */           System.arraycopy(bestTile.Verts, bestPoly.Verts[(j - 1)] * 3, vb, 0, 3);
/* 2470 */           System.arraycopy(bestTile.Verts, bestPoly.Verts[j] * 3, vc, 0, 3);
/* 2471 */           polyArea += Helper.TriArea2D(va, vb, vc);
/*      */         }
/* 2473 */         areaSum += polyArea;
/* 2474 */         float u = frand.nextFloat();
/* 2475 */         if (u * areaSum <= polyArea)
/*      */         {
/* 2477 */           randomTile = bestTile;
/* 2478 */           randomPoly = bestPoly;
/* 2479 */           randomPolyRef = bestRef;
/*      */         }
/*      */       }
/*      */ 
/* 2483 */       long parentRef = 0L;
/* 2484 */       MeshTile parentTile = null;
/* 2485 */       Poly parentPoly = null;
/*      */ 
/* 2487 */       if (bestNode.PIdx > 0L)
/*      */       {
/* 2489 */         parentRef = this.NodePool.GetNodeAtIdx(bestNode.PIdx).Id;
/*      */       }
/* 2491 */       if (parentRef > 0L)
/*      */       {
/* 2493 */         DetourMeshTileAndPoly parentTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(parentRef);
/* 2494 */         parentTile = parentTileAndPoly.tile;
/* 2495 */         parentPoly = parentTileAndPoly.poly;
/*      */       }
/*      */ 
/* 2498 */       for (long i = bestPoly.FirstLink; i != NavMesh.NullLink; i = bestTile.Links[(int)i].Next)
/*      */       {
/* 2500 */         Link link = bestTile.Links[(int)i];
/* 2501 */         long neighborRef = link.Ref;
/* 2502 */         if ((neighborRef <= 0L) || (neighborRef == parentRef)) {
/*      */           continue;
/*      */         }
/* 2505 */         DetourMeshTileAndPoly neiTileAndPoly = this.NavMesh.GetTileAndPolyByRefUnsafe(neighborRef);
/* 2506 */         MeshTile neighborTile = neiTileAndPoly.tile;
/* 2507 */         Poly neighborPoly = neiTileAndPoly.poly;
/*      */ 
/* 2509 */         if (!filter.PassFilter(neighborRef, neighborTile, neighborPoly).booleanValue()) {
/*      */           continue;
/*      */         }
/* 2512 */         float[] va = new float[3]; float[] vb = new float[3];
/* 2513 */         if (GetPortalPoints(bestRef, bestPoly, bestTile, neighborRef, neighborPoly, neighborTile, va, vb).contains(Status.Failure)) {
/*      */           continue;
/*      */         }
/* 2516 */         Vector2 distSqr = Helper.DistancePtSegSqr2D(centerPos[0], centerPos[1], centerPos[2], va[0], va[1], va[2], vb[0], vb[1], vb[2]);
/* 2517 */         if (distSqr.x > radiusSqr) {
/*      */           continue;
/*      */         }
/* 2520 */         Node neighborNode = this.NodePool.GetNode(neighborRef);
/* 2521 */         if (neighborNode == null)
/*      */         {
/* 2523 */           statusReturn.status.add(Status.OutOfNodes);
/*      */         }
/*      */         else
/*      */         {
/* 2527 */           if ((neighborNode.Flags & Node.NodeClosed) != 0L) {
/*      */             continue;
/*      */           }
/* 2530 */           if (neighborNode.Flags == 0L)
/*      */           {
/* 2532 */             float[] pos = new float[3];
/* 2533 */             pos = Helper.VLerp(pos, va[0], va[1], va[2], vb[0], vb[1], vb[2], 0.5F);
/* 2534 */             System.arraycopy(pos, 0, neighborNode.Pos, 0, 3);
/*      */           }
/*      */ 
/* 2537 */           float total = bestNode.Total + Helper.VDist(bestNode.Pos[0], bestNode.Pos[1], bestNode.Pos[2], neighborNode.Pos[0], neighborNode.Pos[1], neighborNode.Pos[2]);
/*      */ 
/* 2539 */           if (((neighborNode.Flags & Node.NodeOpen) != 0L) && (total >= neighborNode.Total)) {
/*      */             continue;
/*      */           }
/* 2542 */           neighborNode.Id = neighborRef;
/* 2543 */           neighborNode.Flags &= (Node.NodeClosed ^ 0xFFFFFFFF);
/* 2544 */           neighborNode.PIdx = this.NodePool.GetNodeIdx(bestNode);
/* 2545 */           neighborNode.Total = total;
/*      */ 
/* 2547 */           if ((neighborNode.Flags & Node.NodeOpen) != 0L)
/*      */           {
/* 2549 */             this._openList.Modify(neighborNode);
/*      */           }
/*      */           else
/*      */           {
/* 2553 */             neighborNode.Flags = Node.NodeOpen;
/* 2554 */             this._openList.Push(neighborNode);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2559 */     if (randomPoly == null) {
/* 2560 */       statusReturn.status = EnumSet.of(Status.Failure);
/* 2561 */       return statusReturn;
/*      */     }
/*      */ 
/* 2564 */     int v = randomPoly.Verts[0] * 3;
/* 2565 */     float[] verts = new float[3 * NavMeshBuilder.VertsPerPoly];
/* 2566 */     float[] areas = new float[NavMeshBuilder.VertsPerPoly];
/* 2567 */     System.arraycopy(randomTile.Verts, v, verts, 0, 3);
/* 2568 */     for (int j = 1; j < randomPoly.VertCount; j++)
/*      */     {
/* 2570 */       v = randomPoly.Verts[j] * 3;
/* 2571 */       System.arraycopy(randomTile.Verts, v, verts, j * 3, 3);
/*      */     }
/*      */ 
/* 2574 */     float s = frand.nextFloat();
/* 2575 */     float t = frand.nextFloat();
/*      */ 
/* 2577 */     float[] pt = new float[3];
/* 2578 */     Helper.RandomPointInConvexPoly(verts, randomPoly.VertCount, areas, s, t, pt);
/*      */ 
/* 2580 */     float h = 0.0F;
/* 2581 */     DetourNumericReturn stat = GetPolyHeight(randomPolyRef, pt, h);
/* 2582 */     if (stat.status.contains(Status.Failure)) {
/* 2583 */       return stat;
/*      */     }
/* 2585 */     pt[1] = stat.floatValue;
/*      */ 
/* 2587 */     System.arraycopy(pt, 0, randomPt, 0, 3);
/* 2588 */     statusReturn.longValue = randomPolyRef;
/* 2589 */     statusReturn.status = EnumSet.of(Status.Success);
/* 2590 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> ClosestPointOnPoly(long refId, float[] pos, float[] closest)
/*      */   {
/*      */     try {
/* 2596 */       if (this.NavMesh == null)
/* 2597 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 2600 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 2603 */     DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(refId);
/* 2604 */     if (tileAndPoly.status.contains(Status.Failure)) {
/* 2605 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/* 2607 */     MeshTile tile = tileAndPoly.tile;
/* 2608 */     Poly poly = tileAndPoly.poly;
/*      */ 
/* 2610 */     if (tile == null) {
/* 2611 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/* 2613 */     ClosestPointOnPolyInTile(tile, poly, pos, closest);
/*      */ 
/* 2615 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> ClosestPointOnPolyBoundary(long refId, float[] pos, float[] closest)
/*      */   {
/*      */     try {
/* 2621 */       if (this.NavMesh == null)
/* 2622 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 2625 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 2628 */     DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(refId);
/* 2629 */     if (tileAndPoly.status.contains(Status.Failure)) {
/* 2630 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/* 2632 */     MeshTile tile = tileAndPoly.tile;
/* 2633 */     Poly poly = tileAndPoly.poly;
/*      */ 
/* 2635 */     float[] verts = new float[3 * NavMeshBuilder.VertsPerPoly];
/* 2636 */     float[] edged = new float[NavMeshBuilder.VertsPerPoly];
/* 2637 */     float[] edget = new float[NavMeshBuilder.VertsPerPoly];
/* 2638 */     int nv = 0;
/* 2639 */     for (int i = 0; i < poly.VertCount; i++)
/*      */     {
/* 2641 */       System.arraycopy(tile.Verts, poly.Verts[i] * 3, verts, nv * 3, 3);
/* 2642 */       nv++;
/*      */     }
/*      */ 
/* 2645 */     Boolean inside = Helper.DistancePtPolyEdgesSqr(pos[0], pos[1], pos[2], verts, nv, edged, edget);
/* 2646 */     if (inside.booleanValue())
/*      */     {
/* 2648 */       System.arraycopy(pos, 0, closest, 0, 3);
/*      */     }
/*      */     else
/*      */     {
/* 2652 */       float dmin = 3.4028235E+38F;
/* 2653 */       int imin = -1;
/* 2654 */       for (int i = 0; i < nv; i++)
/*      */       {
/* 2656 */         if (edged[i] >= dmin)
/*      */           continue;
/* 2658 */         dmin = edged[i];
/* 2659 */         imin = i;
/*      */       }
/*      */ 
/* 2662 */       int va = imin * 3;
/* 2663 */       int vb = (imin + 1) % nv * 3;
/* 2664 */       closest = Helper.VLerp(closest, verts[(va + 0)], verts[(va + 1)], verts[(va + 2)], verts[(vb + 0)], verts[(vb + 1)], verts[(vb + 2)], edget[imin]);
/*      */     }
/* 2666 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public DetourNumericReturn GetPolyHeight(long refId, float[] pos, float height)
/*      */   {
/*      */     try {
/* 2672 */       if (this.NavMesh == null)
/* 2673 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 2676 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 2679 */     DetourNumericReturn statusReturn = new DetourNumericReturn();
/*      */ 
/* 2681 */     DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(refId);
/* 2682 */     if (tileAndPoly.status.contains(Status.Failure)) {
/* 2683 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 2684 */       return statusReturn;
/*      */     }
/* 2686 */     MeshTile tile = tileAndPoly.tile;
/* 2687 */     Poly poly = tileAndPoly.poly;
/*      */ 
/* 2689 */     if (poly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection)
/*      */     {
/* 2691 */       int v0 = poly.Verts[0] * 3;
/* 2692 */       int v1 = poly.Verts[1] * 3;
/* 2693 */       float d0 = Helper.VDist(pos[0], pos[1], pos[2], tile.Verts[(v0 + 0)], tile.Verts[(v0 + 1)], tile.Verts[(v0 + 2)]);
/* 2694 */       float d1 = Helper.VDist(pos[0], pos[1], pos[2], tile.Verts[(v1 + 0)], tile.Verts[(v1 + 1)], tile.Verts[(v1 + 2)]);
/* 2695 */       float u = d0 / (d0 + d1);
/* 2696 */       statusReturn.floatValue = (tile.Verts[(v0 + 1)] + (tile.Verts[(v1 + 1)] - tile.Verts[(v0 + 1)]) * u);
/* 2697 */       statusReturn.status = EnumSet.of(Status.Success);
/* 2698 */       return statusReturn;
/*      */     }
/*      */ 
/* 2702 */     long ip = 0L;
/* 2703 */     for (int i = 0; i < tile.Polys.length; i++)
/*      */     {
/* 2705 */       if (tile.Polys[i] != poly)
/*      */         continue;
/* 2707 */       ip = i;
/* 2708 */       break;
/*      */     }
/*      */ 
/* 2711 */     PolyDetail pd = tile.DetailMeshes[(int)ip];
/* 2712 */     for (int j = 0; j < pd.TriCount; j++)
/*      */     {
/* 2714 */       int t = ((int)pd.TriBase + j) * 4;
/* 2715 */       float[] v = new float[9];
/* 2716 */       for (int k = 0; k < 3; k++)
/*      */       {
/* 2718 */         if (tile.DetailTris[(t + k)] < poly.VertCount)
/*      */         {
/* 2720 */           System.arraycopy(tile.Verts, poly.Verts[tile.DetailTris[(t + k)]] * 3, v, k * 3, 3);
/*      */         }
/*      */         else
/*      */         {
/* 2724 */           System.arraycopy(tile.DetailVerts, (int)((pd.VertBase + (tile.DetailTris[(t + k)] - poly.VertCount)) * 3L), v, k * 3, 3);
/*      */         }
/*      */       }
/* 2727 */       DetourNumericReturn closestDist = Helper.ClosestHeightPointTriangle(pos[0], pos[1], pos[2], v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8]);
/* 2728 */       if (!closestDist.boolValue.booleanValue())
/*      */         continue;
/* 2730 */       statusReturn.floatValue = closestDist.floatValue;
/* 2731 */       statusReturn.status = EnumSet.of(Status.Success);
/* 2732 */       return statusReturn;
/*      */     }
/*      */ 
/* 2737 */     statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 2738 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public Boolean IsValidPolyRef(long refId, QueryFilter filter)
/*      */   {
/* 2743 */     DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(refId);
/* 2744 */     if (tileAndPoly.status.contains(Status.Failure)) {
/* 2745 */       return Boolean.valueOf(false);
/*      */     }
/* 2747 */     MeshTile tile = tileAndPoly.tile;
/* 2748 */     Poly poly = tileAndPoly.poly;
/* 2749 */     if (!filter.PassFilter(refId, tile, poly).booleanValue())
/* 2750 */       return Boolean.valueOf(false);
/* 2751 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   public Boolean IsInClosedList(long refId)
/*      */   {
/* 2756 */     if (this.NodePool == null) return Boolean.valueOf(false);
/* 2757 */     Node node = this.NodePool.FindNode(refId);
/* 2758 */     return Boolean.valueOf((node != null) && ((node.Flags & Node.NodeClosed) != 0L));
/*      */   }
/*      */ 
/*      */   public Boolean IsInOpenList(long refId)
/*      */   {
/* 2763 */     if (this.NodePool == null) return Boolean.valueOf(false);
/* 2764 */     Node node = this.NodePool.FindNode(refId);
/* 2765 */     return Boolean.valueOf((node != null) && ((node.Flags & Node.NodeOpen) != 0L));
/*      */   }
/*      */ 
/*      */   private int QueryPolygonsInTile(MeshTile tile, float[] qmin, float[] qmax, QueryFilter filter, long[] polys, int maxPolys)
/*      */   {
/*      */     try
/*      */     {
/* 2772 */       if (this.NavMesh == null)
/* 2773 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 2776 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 2779 */     if (tile.BVTree != null)
/*      */     {
/* 2781 */       int node = 0;
/* 2782 */       int end = tile.Header.BVNodeCount;
/* 2783 */       float[] tbmin = tile.Header.BMin;
/* 2784 */       float[] tbmax = tile.Header.BMax;
/* 2785 */       float qfac = tile.Header.BVQuantFactor;
/*      */ 
/* 2787 */       int[] bmin = new int[3]; int[] bmax = new int[3];
/*      */ 
/* 2789 */       float minx = Helper.Clamp(qmin[0], tbmin[0], tbmax[0]) - tbmin[0];
/* 2790 */       float miny = Helper.Clamp(qmin[1], tbmin[1], tbmax[1]) - tbmin[1];
/* 2791 */       float minz = Helper.Clamp(qmin[2], tbmin[2], tbmax[2]) - tbmin[2];
/* 2792 */       float maxx = Helper.Clamp(qmax[0], tbmin[0], tbmax[0]) - tbmin[0];
/* 2793 */       float maxy = Helper.Clamp(qmax[1], tbmin[1], tbmax[1]) - tbmin[1];
/* 2794 */       float maxz = Helper.Clamp(qmax[2], tbmin[2], tbmax[2]) - tbmin[2];
/*      */ 
/* 2805 */       bmin[0] = ((int)(qfac * minx) & 0xFFFE);
/* 2806 */       bmin[1] = ((int)(qfac * miny) & 0xFFFE);
/* 2807 */       bmin[2] = ((int)(qfac * minz) & 0xFFFE);
/* 2808 */       bmax[0] = ((int)(qfac * maxx + 1.0F) | 0x1);
/* 2809 */       bmax[1] = ((int)(qfac * maxy + 1.0F) | 0x1);
/* 2810 */       bmax[2] = ((int)(qfac * maxz + 1.0F) | 0x1);
/*      */ 
/* 2812 */       long baseRef = this.NavMesh.GetPolyRefBase(tile);
/* 2813 */       int n = 0;
/*      */ 
/* 2817 */       while (node < end)
/*      */       {
/* 2819 */         Boolean overlap = Helper.OverlapQuantBounds(bmin, bmax, tile.BVTree[node].BMin, tile.BVTree[node].BMax);
/* 2820 */         Boolean isLeafNode = Boolean.valueOf(tile.BVTree[node].I >= 0);
/*      */ 
/* 2822 */         if ((isLeafNode.booleanValue()) && (overlap.booleanValue()))
/*      */         {
/* 2824 */           long refId = baseRef | tile.BVTree[node].I;
/* 2825 */           if (filter.PassFilter(refId, tile, tile.Polys[tile.BVTree[node].I]).booleanValue())
/*      */           {
/* 2827 */             if (n < maxPolys) {
/* 2828 */               polys[(n++)] = refId;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2836 */         if ((overlap.booleanValue()) || (isLeafNode.booleanValue())) {
/* 2837 */           node++;
/*      */         }
/*      */         else {
/* 2840 */           int escapeIndex = -tile.BVTree[node].I;
/* 2841 */           node += escapeIndex;
/*      */         }
/*      */       }
/* 2844 */       return n;
/*      */     }
/*      */ 
/* 2848 */     float[] bmin = new float[3]; float[] bmax = new float[3];
/* 2849 */     int n = 0;
/* 2850 */     long baseRef = this.NavMesh.GetPolyRefBase(tile);
/* 2851 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/* 2853 */       Poly p = tile.Polys[i];
/* 2854 */       if (p.getType() == NavMeshBuilder.PolyTypeOffMeshConnection) {
/*      */         continue;
/*      */       }
/* 2857 */       long refId = baseRef | i;
/* 2858 */       if (!filter.PassFilter(refId, tile, p).booleanValue()) {
/*      */         continue;
/*      */       }
/* 2861 */       int v = p.Verts[0] * 3;
/* 2862 */       System.arraycopy(tile.Verts, v, bmin, 0, 3);
/* 2863 */       System.arraycopy(tile.Verts, v, bmax, 0, 3);
/* 2864 */       for (int j = 1; j < p.VertCount; j++)
/*      */       {
/* 2866 */         v = p.Verts[j] * 3;
/* 2867 */         bmin = Helper.VMin(bmin, tile.Verts[(v + 0)], tile.Verts[(v + 1)], tile.Verts[(v + 2)]);
/* 2868 */         bmax = Helper.VMax(bmax, tile.Verts[(v + 0)], tile.Verts[(v + 1)], tile.Verts[(v + 2)]);
/*      */       }
/* 2870 */       if (!Helper.OverlapBounds(qmin[0], qmin[1], qmin[2], qmax[0], qmax[1], qmax[2], bmin[0], bmin[1], bmin[2], bmax[0], bmax[1], bmax[2]).booleanValue()) {
/*      */         continue;
/*      */       }
/* 2873 */       if (n < maxPolys) {
/* 2874 */         polys[(n++)] = refId;
/*      */       }
/*      */     }
/* 2877 */     return n;
/*      */   }
/*      */ 
/*      */   private long FindNearestPolyInTile(MeshTile tile, float[] center, float[] extents, QueryFilter filter, float[] nearestPt)
/*      */   {
/*      */     try
/*      */     {
/* 2885 */       if (this.NavMesh == null)
/* 2886 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 2889 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 2892 */     float[] bmin = Helper.VSub(center[0], center[1], center[2], extents[0], extents[1], extents[2]);
/* 2893 */     float[] bmax = Helper.VAdd(center[0], center[1], center[2], extents[0], extents[1], extents[2]);
/*      */ 
/* 2895 */     long[] polys = new long[''];
/* 2896 */     int polyCount = QueryPolygonsInTile(tile, bmin, bmax, filter, polys, 128);
/*      */ 
/* 2898 */     long nearest = 0L;
/* 2899 */     float nearestDistanceSqr = 3.4028235E+38F;
/* 2900 */     for (int i = 0; i < polyCount; i++)
/*      */     {
/* 2902 */       long refId = polys[i];
/* 2903 */       Poly poly = tile.Polys[(int)this.NavMesh.DecodePolyIdPoly(refId)];
/* 2904 */       float[] closestPtPoly = new float[3];
/* 2905 */       ClosestPointOnPolyInTile(tile, poly, center, closestPtPoly);
/*      */ 
/* 2907 */       float d = Helper.VDistSqr(center[0], center[1], center[2], closestPtPoly[0], closestPtPoly[1], closestPtPoly[2]);
/* 2908 */       if (d >= nearestDistanceSqr)
/*      */         continue;
/* 2910 */       System.arraycopy(closestPtPoly, 0, nearestPt, 0, 3);
/* 2911 */       nearestDistanceSqr = d;
/* 2912 */       nearest = refId;
/*      */     }
/*      */ 
/* 2915 */     return nearest;
/*      */   }
/*      */ 
/*      */   private void ClosestPointOnPolyInTile(MeshTile tile, Poly poly, float[] pos, float[] closest)
/*      */   {
/* 2920 */     if (poly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection)
/*      */     {
/* 2922 */       int v0 = poly.Verts[0] * 3;
/* 2923 */       int v1 = poly.Verts[1] * 3;
/* 2924 */       float d0 = Helper.VDist(pos[0], pos[1], pos[2], tile.Verts[(v0 + 0)], tile.Verts[(v0 + 1)], tile.Verts[(v0 + 2)]);
/*      */ 
/* 2926 */       float d1 = Helper.VDist(pos[0], pos[1], pos[2], tile.Verts[(v1 + 0)], tile.Verts[(v1 + 1)], tile.Verts[(v1 + 2)]);
/*      */ 
/* 2929 */       float u = d0 / (d0 + d1);
/* 2930 */       closest = Helper.VLerp(closest, tile.Verts[(v0 + 0)], tile.Verts[(v0 + 1)], tile.Verts[(v0 + 2)], tile.Verts[(v1 + 0)], tile.Verts[(v1 + 1)], tile.Verts[(v1 + 2)], u);
/* 2931 */       return;
/*      */     }
/*      */ 
/* 2934 */     long ip = 0L;
/* 2935 */     for (int i = 0; i < tile.Polys.length; i++)
/*      */     {
/* 2937 */       if (tile.Polys[i] != poly)
/*      */         continue;
/* 2939 */       ip = i;
/* 2940 */       break;
/*      */     }
/*      */ 
/* 2945 */     PolyDetail pd = tile.DetailMeshes[(int)ip];
/*      */ 
/* 2947 */     float[] verts = new float[3 * NavMeshBuilder.VertsPerPoly];
/* 2948 */     float[] edged = new float[NavMeshBuilder.VertsPerPoly];
/* 2949 */     float[] edget = new float[NavMeshBuilder.VertsPerPoly];
/* 2950 */     int nv = poly.VertCount;
/* 2951 */     if (poly.VertCount == 0) {
/* 2952 */       Log.warn("NAVMESH: got 0 vert count for poly: " + poly.getArea() + " from tile: " + tile.Header.X + "/" + tile.Header.Y);
/*      */     }
/* 2954 */     for (int i = 0; i < nv; i++)
/*      */     {
/* 2956 */       System.arraycopy(tile.Verts, poly.Verts[i] * 3, verts, i * 3, 3);
/*      */     }
/*      */ 
/* 2959 */     System.arraycopy(pos, 0, closest, 0, 3);
/* 2960 */     if (!Helper.DistancePtPolyEdgesSqr(pos[0], pos[1], pos[2], verts, nv, edged, edget).booleanValue())
/*      */     {
/* 2962 */       float dmin = 3.4028235E+38F;
/* 2963 */       int imin = -1;
/* 2964 */       for (int i = 0; i < nv; i++)
/*      */       {
/* 2966 */         if (edged[i] >= dmin)
/*      */           continue;
/* 2968 */         dmin = edged[i];
/* 2969 */         imin = i;
/*      */       }
/*      */ 
/* 2972 */       int va = imin * 3;
/* 2973 */       int vb = (imin + 1) % nv * 3;
/* 2974 */       closest = Helper.VLerp(closest, verts[(va + 0)], verts[(va + 1)], verts[(va + 2)], verts[(vb + 0)], verts[(vb + 1)], verts[(vb + 2)], edget[imin]);
/*      */     }
/*      */ 
/* 2977 */     for (int j = 0; j < pd.TriCount; j++)
/*      */     {
/* 2979 */       int t = ((int)pd.TriBase + j) * 4;
/* 2980 */       float[] v = new float[9];
/* 2981 */       for (int k = 0; k < 3; k++)
/*      */       {
/* 2983 */         if (tile.DetailTris[(t + k)] < poly.VertCount) {
/* 2984 */           System.arraycopy(tile.Verts, poly.Verts[tile.DetailTris[(t + k)]] * 3, v, k * 3, 3);
/*      */         }
/*      */         else {
/* 2987 */           System.arraycopy(tile.DetailVerts, (int)(pd.VertBase + (tile.DetailTris[(t + k)] - poly.VertCount)) * 3, v, k * 3, 3);
/*      */         }
/*      */       }
/* 2990 */       DetourNumericReturn closestDist = Helper.ClosestHeightPointTriangle(pos[0], pos[1], pos[2], v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8]);
/* 2991 */       if (!closestDist.boolValue.booleanValue())
/*      */         continue;
/* 2993 */       closest[1] = closestDist.floatValue;
/* 2994 */       break;
/*      */     }
/*      */   }
/*      */ 
/*      */   private DetourNumericReturn GetPortalPoints(long from, long to, float[] left, float[] right)
/*      */   {
/*      */     try
/*      */     {
/* 3002 */       if (this.NavMesh == null)
/* 3003 */         throw new Exception("NavMesh is not initialized");
/*      */     }
/*      */     catch (Exception e) {
/* 3006 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 3009 */     DetourNumericReturn statusReturn = new DetourNumericReturn();
/*      */ 
/* 3011 */     DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(from);
/* 3012 */     if (tileAndPoly.status.contains(Status.Failure)) {
/* 3013 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 3014 */       return statusReturn;
/*      */     }
/* 3016 */     MeshTile fromTile = tileAndPoly.tile;
/* 3017 */     Poly fromPoly = tileAndPoly.poly;
/* 3018 */     statusReturn.intValue = fromPoly.getType();
/*      */ 
/* 3020 */     DetourMeshTileAndPoly toTileAndPoly = this.NavMesh.GetTileAndPolyByRef(to);
/* 3021 */     if (toTileAndPoly.status.contains(Status.Failure)) {
/* 3022 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 3023 */       return statusReturn;
/*      */     }
/* 3025 */     MeshTile toTile = toTileAndPoly.tile;
/* 3026 */     Poly toPoly = toTileAndPoly.poly;
/* 3027 */     statusReturn.longValue = toPoly.getType();
/*      */ 
/* 3031 */     statusReturn.status = GetPortalPoints(from, fromPoly, fromTile, to, toPoly, toTile, left, right);
/* 3032 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   private EnumSet<Status> GetPortalPoints(long from, Poly fromPoly, MeshTile fromTile, long to, Poly toPoly, MeshTile toTile, float[] left, float[] right)
/*      */   {
/* 3038 */     Link link = null;
/* 3039 */     for (long i = fromPoly.FirstLink; i != NavMesh.NullLink; i = fromTile.Links[(int)i].Next)
/*      */     {
/* 3041 */       if (fromTile.Links[(int)i].Ref != to)
/*      */         continue;
/* 3043 */       link = fromTile.Links[(int)i];
/* 3044 */       break;
/*      */     }
/*      */ 
/* 3047 */     if (link == null)
/*      */     {
/* 3049 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*      */ 
/* 3052 */     if (fromPoly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection)
/*      */     {
/* 3054 */       for (long i = fromPoly.FirstLink; i != NavMesh.NullLink; i = fromTile.Links[(int)i].Next)
/*      */       {
/* 3056 */         if (fromTile.Links[(int)i].Ref != to)
/*      */           continue;
/* 3058 */         int v = fromTile.Links[(int)i].Edge;
/* 3059 */         System.arraycopy(fromTile.Verts, fromPoly.Verts[v] * 3, left, 0, 3);
/* 3060 */         System.arraycopy(fromTile.Verts, fromPoly.Verts[v] * 3, right, 0, 3);
/*      */ 
/* 3062 */         return EnumSet.of(Status.Success);
/*      */       }
/*      */ 
/* 3065 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*      */ 
/* 3068 */     if (toPoly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection)
/*      */     {
/* 3070 */       for (long i = toPoly.FirstLink; i != NavMesh.NullLink; i = toTile.Links[(int)i].Next)
/*      */       {
/* 3072 */         if (toTile.Links[(int)i].Ref != from)
/*      */           continue;
/* 3074 */         int v = toTile.Links[(int)i].Edge;
/* 3075 */         System.arraycopy(toTile.Verts, toPoly.Verts[v] * 3, left, 0, 3);
/* 3076 */         System.arraycopy(toTile.Verts, toPoly.Verts[v] * 3, right, 0, 3);
/*      */ 
/* 3078 */         return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */       }
/*      */ 
/* 3081 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/* 3083 */     int v0 = fromPoly.Verts[link.Edge];
/* 3084 */     int v1 = fromPoly.Verts[((link.Edge + 1) % fromPoly.VertCount)];
/* 3085 */     System.arraycopy(fromTile.Verts, v0 * 3, left, 0, 3);
/* 3086 */     System.arraycopy(fromTile.Verts, v1 * 3, right, 0, 3);
/*      */ 
/* 3089 */     if (link.Side != 255)
/*      */     {
/* 3091 */       if ((link.BMin != 0) || (link.BMax != 255))
/*      */       {
/* 3093 */         float s = 0.003921569F;
/* 3094 */         float tmin = link.BMin * s;
/* 3095 */         float tmax = link.BMax * s;
/* 3096 */         left = Helper.VLerp(left, fromTile.Verts[(v0 * 3 + 0)], fromTile.Verts[(v0 * 3 + 1)], fromTile.Verts[(v0 * 3 + 2)], fromTile.Verts[(v1 + 3 + 0)], fromTile.Verts[(v1 + 3 + 1)], fromTile.Verts[(v1 + 3 + 2)], tmin);
/* 3097 */         right = Helper.VLerp(right, fromTile.Verts[(v0 * 3 + 0)], fromTile.Verts[(v0 * 3 + 1)], fromTile.Verts[(v0 * 3 + 2)], fromTile.Verts[(v1 + 3 + 0)], fromTile.Verts[(v1 + 3 + 1)], fromTile.Verts[(v1 + 3 + 2)], tmax);
/*      */       }
/*      */     }
/*      */ 
/* 3101 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   private EnumSet<Status> GetEdgeMidPoint(long from, long to, float[] mid)
/*      */   {
/* 3106 */     float[] left = new float[3]; float[] right = new float[3];
/* 3107 */     DetourNumericReturn statusReturn = GetPortalPoints(from, to, left, right);
/* 3108 */     if (statusReturn.status.contains(Status.Failure))
/*      */     {
/* 3110 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/* 3112 */     mid[0] = ((left[0] + right[0]) * 0.5F);
/* 3113 */     mid[1] = ((left[1] + right[1]) * 0.5F);
/* 3114 */     mid[2] = ((left[2] + right[2]) * 0.5F);
/* 3115 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   private EnumSet<Status> GetEdgeMidPoint(long from, Poly fromPoly, MeshTile fromTile, long to, Poly toPoly, MeshTile toTile, float[] mid)
/*      */   {
/* 3121 */     float[] left = new float[3]; float[] right = new float[3];
/*      */ 
/* 3123 */     if (GetPortalPoints(from, fromPoly, fromTile, to, toPoly, toTile, left, right).contains(Status.Failure))
/*      */     {
/* 3125 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/* 3127 */     mid[0] = ((left[0] + right[0]) * 0.5F);
/* 3128 */     mid[1] = ((left[1] + right[1]) * 0.5F);
/* 3129 */     mid[2] = ((left[2] + right[2]) * 0.5F);
/* 3130 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   private DetourStatusReturn AppendVertex(float[] pos, short flags, long refId, float[] straightPath, short[] straightPathFlags, long[] straightPathRefs, int straightPathCount, int maxStraightPath)
/*      */   {
/* 3137 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */ 
/* 3141 */     if ((straightPathCount > 0) && (Helper.VEqual(straightPath[((straightPathCount - 1) * 3 + 0)], straightPath[((straightPathCount - 1) * 3 + 1)], straightPath[((straightPathCount - 1) * 3 + 2)], pos[0], pos[1], pos[2]).booleanValue()))
/*      */     {
/* 3145 */       straightPathFlags[(straightPathCount - 1)] = flags;
/* 3146 */       straightPathRefs[(straightPathCount - 1)] = refId;
/*      */     }
/*      */     else
/*      */     {
/* 3150 */       System.arraycopy(pos, 0, straightPath, straightPathCount * 3, 3);
/* 3151 */       straightPathFlags[straightPathCount] = flags;
/* 3152 */       straightPathRefs[straightPathCount] = refId;
/* 3153 */       straightPathCount++;
/*      */ 
/* 3155 */       if ((flags == StraightPathEnd) || (straightPathCount >= maxStraightPath))
/*      */       {
/* 3157 */         statusReturn.intValue = straightPathCount;
/* 3158 */         statusReturn.status = EnumSet.of(Status.Success);
/* 3159 */         if (straightPathCount >= maxStraightPath) {
/* 3160 */           statusReturn.status.add(Status.BufferTooSmall);
/*      */         }
/* 3162 */         return statusReturn;
/*      */       }
/*      */     }
/* 3165 */     statusReturn.intValue = straightPathCount;
/* 3166 */     statusReturn.status = EnumSet.of(Status.InProgress);
/*      */ 
/* 3168 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   private DetourStatusReturn AppendPortals(int startIdx, int endIdx, float[] endPos, long[] path, float[] straightPath, short[] straightPathFlags, long[] straightPathRefs, int straightPathCount, int maxStraightPath, int options)
/*      */   {
/* 3175 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/* 3176 */     statusReturn.intValue = straightPathCount;
/* 3177 */     int startPos = (straightPathCount - 1) * 3;
/* 3178 */     for (int i = startIdx; i < endIdx; i++)
/*      */     {
/* 3180 */       long from = path[i];
/* 3181 */       DetourMeshTileAndPoly tileAndPoly = this.NavMesh.GetTileAndPolyByRef(from);
/* 3182 */       if (tileAndPoly.status.contains(Status.Failure)) {
/* 3183 */         statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 3184 */         return statusReturn;
/*      */       }
/* 3186 */       MeshTile fromTile = tileAndPoly.tile;
/* 3187 */       Poly fromPoly = tileAndPoly.poly;
/*      */ 
/* 3189 */       long to = path[(i + 1)];
/* 3190 */       DetourMeshTileAndPoly toTileAndPoly = this.NavMesh.GetTileAndPolyByRef(to);
/* 3191 */       if (toTileAndPoly.status.contains(Status.Failure)) {
/* 3192 */         statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/* 3193 */         return statusReturn;
/*      */       }
/* 3195 */       MeshTile toTile = toTileAndPoly.tile;
/* 3196 */       Poly toPoly = toTileAndPoly.poly;
/*      */ 
/* 3198 */       float[] left = new float[3]; float[] right = new float[3];
/* 3199 */       if (GetPortalPoints(from, fromPoly, fromTile, to, toPoly, toTile, left, right).contains(Status.Failure)) {
/*      */         break;
/*      */       }
/* 3202 */       if (((options & StraightPathAreaCrossings) != 0) && 
/* 3204 */         (fromPoly.getArea() == toPoly.getArea()))
/*      */       {
/*      */         continue;
/*      */       }
/* 3208 */       DetourNumericReturn segIntersected = Helper.IntersectSegSeg2D(straightPath[(startPos + 0)], straightPath[(startPos + 1)], straightPath[(startPos + 2)], endPos[0], endPos[1], endPos[2], left, right);
/*      */ 
/* 3210 */       if (!segIntersected.boolValue.booleanValue())
/*      */         continue;
/* 3212 */       float[] pt = new float[3];
/* 3213 */       pt = Helper.VLerp(pt, left[0], left[1], left[2], right[0], right[1], right[2], (float)segIntersected.vector2Value.y);
/*      */ 
/* 3215 */       DetourStatusReturn stat = AppendVertex(pt, 0, path[(i + 1)], straightPath, straightPathFlags, straightPathRefs, straightPathCount, maxStraightPath);
/*      */ 
/* 3217 */       if (stat.status.contains(Status.InProgress)) {
/* 3218 */         return stat;
/*      */       }
/*      */     }
/* 3221 */     statusReturn.status = EnumSet.of(Status.InProgress);
/* 3222 */     return statusReturn;
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.NavMeshQuery
 * JD-Core Version:    0.6.0
 */