/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class CompareNodeY
/*    */   implements Comparator<Object>
/*    */ {
/*    */   public int compare(Object va, Object vb)
/*    */   {
/* 10 */     BVNode a = (BVNode)va;
/* 11 */     BVNode b = (BVNode)vb;
/* 12 */     if ((a != null) && (b != null))
/*    */     {
/* 14 */       if (a.BMin[1] < b.BMin[1])
/* 15 */         return -1;
/* 16 */       if (a.BMin[1] > b.BMin[1])
/* 17 */         return 1;
/*    */     }
/* 19 */     return 0;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.CompareNodeY
 * JD-Core Version:    0.6.0
 */