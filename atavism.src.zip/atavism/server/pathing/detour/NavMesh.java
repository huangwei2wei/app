/*      */ package atavism.server.pathing.detour;
/*      */ 
/*      */ import atavism.server.math.IntVector2;
/*      */ import atavism.server.pathing.recast.Helper;
/*      */ import java.util.EnumSet;
/*      */ 
/*      */ public class NavMesh
/*      */ {
/*      */   public NavMeshParams _param;
/*   31 */   public float[] _orig = new float[3];
/*      */   public float _tileWidth;
/*      */   public float _tileHeight;
/*      */   public int _maxTiles;
/*      */   public int _tileLutSize;
/*      */   public int _tileLutMask;
/*      */   public MeshTile[] _posLookup;
/*      */   public MeshTile _nextFree;
/*      */   public MeshTile[] _tiles;
/*      */   public long _saltBits;
/*      */   public long _tileBits;
/*      */   public long _polyBits;
/*   45 */   public static long NullLink = -1L;
/*   46 */   public static int TileFreeData = 1;
/*      */ 
/*      */   public NavMeshParams Param() {
/*   49 */     return this._param;
/*      */   }
/*      */ 
/*      */   public NavMesh()
/*      */   {
/*   54 */     this._orig = new float[3];
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> Init(NavMeshParams param)
/*      */   {
/*   59 */     this._param = param;
/*   60 */     System.arraycopy(param.Orig, 0, this._orig, 0, 3);
/*   61 */     this._tileWidth = param.TileWidth;
/*   62 */     this._tileHeight = param.TileHeight;
/*      */ 
/*   64 */     this._maxTiles = param.MaxTiles;
/*   65 */     this._tileLutSize = (int)Helper.NextPow2(param.MaxTiles / 4);
/*   66 */     if (this._tileLutSize <= 0) this._tileLutSize = 1;
/*   67 */     this._tileLutMask = (this._tileLutSize - 1);
/*      */ 
/*   69 */     this._tiles = new MeshTile[this._maxTiles];
/*   70 */     this._posLookup = new MeshTile[this._tileLutSize];
/*      */ 
/*   72 */     for (int i = 0; i < this._tileLutSize; i++)
/*      */     {
/*   74 */       this._posLookup[i] = new MeshTile();
/*      */     }
/*      */ 
/*   77 */     this._nextFree = null;
/*   78 */     for (int i = this._maxTiles - 1; i >= 0; i--)
/*      */     {
/*   80 */       this._tiles[i] = new MeshTile(1L, this._nextFree);
/*   81 */       this._nextFree = this._tiles[i];
/*      */     }
/*      */ 
/*   84 */     this._tileBits = Helper.Ilog2(Helper.NextPow2(param.MaxTiles));
/*   85 */     this._polyBits = Helper.Ilog2(Helper.NextPow2(param.MaxPolys));
/*   86 */     this._saltBits = Math.min(31L, 32L - this._tileBits - this._polyBits);
/*   87 */     if (this._saltBits < 10L)
/*      */     {
/*   89 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*   91 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> Init(NavMeshBuilder data, int flags)
/*      */   {
/*      */     try
/*      */     {
/*   98 */       if (data.Header.Magic != Helper.NavMeshMagic)
/*   99 */         throw new Exception("Wrong Magic Number");
/*  100 */       if (data.Header.Version != Helper.NavMeshVersion)
/*  101 */         throw new Exception("Wrong Version Number");
/*      */     }
/*      */     catch (Exception e) {
/*  104 */       e.printStackTrace();
/*      */     }
/*      */ 
/*  107 */     NavMeshParams param = new NavMeshParams();
/*  108 */     System.arraycopy(data.Header.BMin, 0, param.Orig, 0, 3);
/*  109 */     param.TileWidth = (data.Header.BMax[0] - data.Header.BMin[0]);
/*  110 */     param.TileHeight = (data.Header.BMax[2] - data.Header.BMin[2]);
/*  111 */     param.MaxTiles = 1;
/*  112 */     param.MaxPolys = data.Header.PolyCount;
/*      */ 
/*  114 */     EnumSet status = Init(param);
/*  115 */     if (status.contains(Status.Failure)) {
/*  116 */       return status;
/*      */     }
/*  118 */     long temp = 0L;
/*  119 */     return AddTile(data, flags, 0L).status;
/*      */   }
/*      */ 
/*      */   public DetourNumericReturn AddTile(NavMeshBuilder data, int flags, long lastRef)
/*      */   {
/*  124 */     DetourNumericReturn statusReturn = new DetourNumericReturn();
/*  125 */     MeshHeader header = data.Header;
/*  126 */     if (header.Magic != Helper.NavMeshMagic) {
/*  127 */       statusReturn.status = EnumSet.of(Status.Failure, Status.WrongMagic);
/*  128 */       return statusReturn;
/*      */     }
/*  130 */     if (header.Version != Helper.NavMeshVersion) {
/*  131 */       statusReturn.status = EnumSet.of(Status.Failure, Status.WrongVersion);
/*  132 */       return statusReturn;
/*      */     }
/*      */ 
/*  135 */     if (GetTileAt(header.X, header.Y, header.Layer) != null) {
/*  136 */       statusReturn.status = EnumSet.of(Status.Failure);
/*  137 */       return statusReturn;
/*      */     }
/*      */ 
/*  140 */     MeshTile tile = null;
/*  141 */     if (lastRef == 0L)
/*      */     {
/*  143 */       if (this._nextFree != null)
/*      */       {
/*  145 */         tile = this._nextFree;
/*  146 */         this._nextFree = tile.Next;
/*  147 */         tile.Next = null;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  152 */       int tileIndex = (int)DecodePolyIdTile(lastRef);
/*  153 */       if (tileIndex >= this._maxTiles) {
/*  154 */         statusReturn.status = EnumSet.of(Status.Failure, Status.OutOfMemory);
/*  155 */         return statusReturn;
/*      */       }
/*      */ 
/*  158 */       MeshTile target = this._tiles[tileIndex];
/*  159 */       MeshTile prev = null;
/*  160 */       tile = this._nextFree;
/*  161 */       while ((tile != null) && (tile != target))
/*      */       {
/*  163 */         prev = tile;
/*  164 */         tile = tile.Next;
/*      */       }
/*      */ 
/*  167 */       if (tile != target) {
/*  168 */         statusReturn.status = EnumSet.of(Status.Failure, Status.OutOfMemory);
/*  169 */         return statusReturn;
/*      */       }
/*      */ 
/*  172 */       if (prev != null) {
/*  173 */         this._nextFree = tile.Next;
/*      */       }
/*      */       else {
/*  176 */         prev.Next = tile.Next;
/*      */       }
/*      */ 
/*  179 */       tile.Salt = DecodePolyIdSalt(lastRef);
/*      */     }
/*      */ 
/*  182 */     if (tile == null) {
/*  183 */       statusReturn.status = EnumSet.of(Status.Failure, Status.OutOfMemory);
/*  184 */       return statusReturn;
/*      */     }
/*      */ 
/*  188 */     int h = ComputeTileHash(header.X, header.Y, this._tileLutMask);
/*  189 */     tile.Next = this._posLookup[h];
/*  190 */     this._posLookup[h] = tile;
/*      */ 
/*  192 */     tile.Verts = data.NavVerts;
/*  193 */     tile.Polys = data.NavPolys;
/*  194 */     tile.Links = data.NavLinks;
/*  195 */     tile.DetailMeshes = data.NavDMeshes;
/*  196 */     tile.DetailVerts = data.NavDVerts;
/*  197 */     tile.DetailTris = data.NavDTris;
/*  198 */     tile.BVTree = data.NavBvTree;
/*  199 */     tile.OffMeshCons = data.OffMeshCons;
/*      */ 
/*  201 */     tile.LinksFreeList = 0L;
/*  202 */     tile.Links[(header.MaxLinkCount - 1)].Next = NullLink;
/*  203 */     for (int i = 0; i < header.MaxLinkCount - 1; i++)
/*      */     {
/*  205 */       tile.Links[i].Next = (i + 1);
/*      */     }
/*      */ 
/*  208 */     tile.Data = data;
/*  209 */     tile.Header = header;
/*  210 */     tile.Flags = flags;
/*      */ 
/*  212 */     ConnectIntLinks(tile);
/*  213 */     BaseOffMeshLinks(tile);
/*      */ 
/*  215 */     int MaxNeis = 32;
/*  216 */     MeshTile[] neis = new MeshTile[MaxNeis];
/*      */ 
/*  218 */     int nneis = GetTilesAt(header.X, header.Y, neis, MaxNeis);
/*  219 */     for (int j = 0; j < nneis; j++)
/*      */     {
/*  221 */       MeshTile temp = neis[j];
/*  222 */       if (neis[j] != tile)
/*      */       {
/*  224 */         ConnectExtLinks(tile, temp, -1);
/*  225 */         ConnectExtLinks(temp, tile, -1);
/*      */       }
/*  227 */       ConnectExtOffMeshLinks(tile, temp, -1);
/*  228 */       ConnectExtOffMeshLinks(temp, tile, -1);
/*      */     }
/*      */ 
/*  231 */     for (int i = 0; i < 8; i++)
/*      */     {
/*  233 */       nneis = GetNeighborTilesAt(header.X, header.Y, i, neis, MaxNeis);
/*  234 */       for (int j = 0; j < nneis; j++)
/*      */       {
/*  236 */         MeshTile temp = neis[j];
/*  237 */         ConnectExtLinks(tile, temp, i);
/*  238 */         ConnectExtLinks(temp, tile, Helper.OppositeTile(i));
/*  239 */         ConnectExtOffMeshLinks(tile, temp, i);
/*  240 */         ConnectExtOffMeshLinks(temp, tile, Helper.OppositeTile(i));
/*      */       }
/*      */     }
/*      */ 
/*  244 */     statusReturn.longValue = GetTileRef(tile);
/*      */ 
/*  246 */     statusReturn.status = EnumSet.of(Status.Success);
/*  247 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   private int ComputeTileHash(int x, int y, int mask)
/*      */   {
/*  252 */     long h1 = -1918454973L;
/*  253 */     long h2 = -669632447L;
/*  254 */     long n = h1 * x + h2 * y;
/*  255 */     return (int)(n & mask);
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> RemoveTile(long refId, NavMeshBuilder data)
/*      */   {
/*  260 */     data = null;
/*  261 */     if (refId == 0L)
/*  262 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*  263 */     long tileIndex = DecodePolyIdTile(refId);
/*  264 */     long tileSalt = DecodePolyIdSalt(refId);
/*  265 */     if (tileIndex >= this._maxTiles)
/*  266 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*  267 */     MeshTile tile = this._tiles[(int)tileIndex];
/*  268 */     if (tile.Salt != tileSalt) {
/*  269 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*  271 */     int h = ComputeTileHash(tile.Header.X, tile.Header.Y, this._tileLutMask);
/*  272 */     MeshTile prev = null;
/*  273 */     MeshTile cur = this._posLookup[h];
/*  274 */     while (cur != null)
/*      */     {
/*  276 */       if (cur == tile)
/*      */       {
/*  278 */         if (prev != null) {
/*  279 */           prev.Next = cur.Next; break;
/*      */         }
/*      */ 
/*  282 */         this._posLookup[h] = cur.Next;
/*      */ 
/*  284 */         break;
/*      */       }
/*  286 */       prev = cur;
/*  287 */       cur = cur.Next;
/*      */     }
/*      */ 
/*  290 */     int MaxNeis = 32;
/*  291 */     MeshTile[] neis = new MeshTile[MaxNeis];
/*      */ 
/*  294 */     int nneis = GetTilesAt(tile.Header.X, tile.Header.Y, neis, MaxNeis);
/*  295 */     for (int j = 0; j < nneis; j++)
/*      */     {
/*  297 */       if (neis[j] != tile) {
/*  298 */         MeshTile temp = neis[j];
/*  299 */         UnconnectExtLinks(temp, tile);
/*      */       }
/*      */     }
/*  302 */     for (int i = 0; i < 8; i++)
/*      */     {
/*  304 */       nneis = GetNeighborTilesAt(tile.Header.X, tile.Header.Y, i, neis, MaxNeis);
/*  305 */       for (int j = 0; j < nneis; j++)
/*      */       {
/*  307 */         MeshTile temp = neis[j];
/*  308 */         UnconnectExtLinks(temp, tile);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  313 */     if ((tile.Flags & TileFreeData) != 0)
/*      */     {
/*  315 */       tile.Data = null;
/*      */     }
/*      */     else
/*      */     {
/*  319 */       data = tile.Data;
/*      */     }
/*      */ 
/*  322 */     tile.Header = null;
/*  323 */     tile.Flags = 0;
/*  324 */     tile.LinksFreeList = 0L;
/*  325 */     tile.Polys = null;
/*  326 */     tile.Verts = null;
/*  327 */     tile.Links = null;
/*  328 */     tile.DetailMeshes = null;
/*  329 */     tile.DetailVerts = null;
/*  330 */     tile.DetailTris = null;
/*  331 */     tile.BVTree = null;
/*  332 */     tile.OffMeshCons = null;
/*      */ 
/*  334 */     tile.Salt = (tile.Salt + 1L & (1 << (int)this._saltBits) - 1);
/*  335 */     if (tile.Salt == 0L) {
/*  336 */       tile.Salt += 1L;
/*      */     }
/*  338 */     tile.Next = this._nextFree;
/*  339 */     this._nextFree = tile;
/*      */ 
/*  341 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public IntVector2 CalcTileLoc(float posx, float posy, float posz)
/*      */   {
/*  346 */     IntVector2 tileLoc = new IntVector2();
/*  347 */     tileLoc.x = (int)Math.floor((posx - this._orig[0]) / this._tileWidth);
/*  348 */     tileLoc.y = (int)Math.floor((posz - this._orig[2]) / this._tileHeight);
/*  349 */     return tileLoc;
/*      */   }
/*      */ 
/*      */   public MeshTile GetTileAt(int x, int y, int layer)
/*      */   {
/*  354 */     int h = ComputeTileHash(x, y, this._tileLutMask);
/*  355 */     MeshTile tile = this._posLookup[h];
/*  356 */     while (tile != null)
/*      */     {
/*  358 */       if ((tile.Header != null) && (tile.Header.X == x) && (tile.Header.Y == y) && (tile.Header.Layer == layer))
/*  359 */         return tile;
/*  360 */       tile = tile.Next;
/*      */     }
/*  362 */     return null;
/*      */   }
/*      */ 
/*      */   public int GetTilesAt(int x, int y, MeshTile[] tiles, int maxTiles)
/*      */   {
/*  367 */     int n = 0;
/*      */ 
/*  369 */     int h = ComputeTileHash(x, y, this._tileLutMask);
/*  370 */     MeshTile tile = this._posLookup[h];
/*  371 */     while (tile != null)
/*      */     {
/*  373 */       if ((tile.Header != null) && (tile.Header.X == x) && (tile.Header.Y == y))
/*      */       {
/*  375 */         if (n < maxTiles)
/*  376 */           tiles[(n++)] = tile;
/*      */       }
/*  378 */       tile = tile.Next;
/*      */     }
/*  380 */     return n;
/*      */   }
/*      */ 
/*      */   public long GetTileRefAt(int x, int y, int layer)
/*      */   {
/*  385 */     int h = ComputeTileHash(x, y, this._tileLutMask);
/*  386 */     MeshTile tile = this._posLookup[h];
/*  387 */     while (tile != null)
/*      */     {
/*  389 */       if ((tile.Header != null) && (tile.Header.X == x) && (tile.Header.Y == y) && (tile.Header.Layer == layer))
/*  390 */         return GetTileRef(tile);
/*  391 */       tile = tile.Next;
/*      */     }
/*  393 */     return 0L;
/*      */   }
/*      */ 
/*      */   public long GetTileRef(MeshTile tile)
/*      */   {
/*  398 */     if (tile == null) return 0L;
/*  399 */     long it = -1L;
/*  400 */     for (int i = 0; i < this._tiles.length; i++)
/*      */     {
/*  402 */       if (this._tiles[i] == tile)
/*  403 */         it = i;
/*      */     }
/*  405 */     return EncodePolyId(tile.Salt, it, 0L);
/*      */   }
/*      */ 
/*      */   public MeshTile GetTileByRef(long refId)
/*      */   {
/*  410 */     if (refId == 0L) {
/*  411 */       return null;
/*      */     }
/*  413 */     long tileIndex = DecodePolyIdTile(refId);
/*  414 */     long tileSalt = DecodePolyIdSalt(refId);
/*  415 */     if ((int)tileIndex >= this._maxTiles)
/*  416 */       return null;
/*  417 */     MeshTile tile = this._tiles[(int)tileIndex];
/*  418 */     if (tile.Salt != tileSalt)
/*  419 */       return null;
/*  420 */     return tile;
/*      */   }
/*      */ 
/*      */   public int GetMaxTiles()
/*      */   {
/*  425 */     return this._maxTiles;
/*      */   }
/*      */ 
/*      */   public MeshTile GetTile(int i)
/*      */   {
/*  430 */     return this._tiles[i];
/*      */   }
/*      */ 
/*      */   public DetourMeshTileAndPoly GetTileAndPolyByRef(long refId)
/*      */   {
/*  435 */     DetourMeshTileAndPoly tileAndPoly = new DetourMeshTileAndPoly();
/*  436 */     if (refId == 0L) {
/*  437 */       tileAndPoly.status = EnumSet.of(Status.Failure);
/*  438 */       return tileAndPoly;
/*      */     }
/*  440 */     long[] saltItIp = new long[3];
/*  441 */     DecodePolyId(refId, saltItIp);
/*  442 */     int salt = (int)saltItIp[0];
/*  443 */     int it = (int)saltItIp[1];
/*  444 */     int ip = (int)saltItIp[2];
/*  445 */     if (it >= this._maxTiles) {
/*  446 */       tileAndPoly.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*  447 */       return tileAndPoly;
/*      */     }
/*  449 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) EnumSet.of(Status.Failure, Status.InvalidParam);
/*  450 */     if (ip >= this._tiles[it].Header.PolyCount) EnumSet.of(Status.Failure, Status.InvalidParam);
/*  451 */     tileAndPoly.tile = this._tiles[it];
/*  452 */     tileAndPoly.poly = this._tiles[it].Polys[ip];
/*  453 */     tileAndPoly.status = EnumSet.of(Status.Success);
/*  454 */     return tileAndPoly;
/*      */   }
/*      */ 
/*      */   public DetourMeshTileAndPoly GetTileAndPolyByRefUnsafe(long refId)
/*      */   {
/*  459 */     long[] saltItIp = new long[3];
/*  460 */     DecodePolyId(refId, saltItIp);
/*  461 */     int salt = (int)saltItIp[0];
/*  462 */     int it = (int)saltItIp[1];
/*  463 */     int ip = (int)saltItIp[2];
/*  464 */     DetourMeshTileAndPoly meshTileAndPoly = new DetourMeshTileAndPoly();
/*  465 */     meshTileAndPoly.tile = this._tiles[it];
/*  466 */     meshTileAndPoly.poly = this._tiles[it].Polys[ip];
/*      */ 
/*  468 */     return meshTileAndPoly;
/*      */   }
/*      */ 
/*      */   public Boolean IsValidPolyRef(long refId)
/*      */   {
/*  473 */     if (refId == 0L) return Boolean.valueOf(false);
/*  474 */     long[] saltItIp = new long[3];
/*  475 */     DecodePolyId(refId, saltItIp);
/*  476 */     int salt = (int)saltItIp[0];
/*  477 */     int it = (int)saltItIp[1];
/*  478 */     int ip = (int)saltItIp[2];
/*  479 */     if (it >= this._maxTiles) return Boolean.valueOf(false);
/*  480 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) return Boolean.valueOf(false);
/*  481 */     if (ip >= this._tiles[it].Header.PolyCount) return Boolean.valueOf(false);
/*  482 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   public long GetPolyRefBase(MeshTile tile)
/*      */   {
/*  487 */     if (tile == null) return 0L;
/*  488 */     long it = -1L;
/*  489 */     for (int i = 0; i < this._tiles.length; i++)
/*      */     {
/*  491 */       if (this._tiles[i] == tile)
/*  492 */         it = i;
/*      */     }
/*  494 */     return EncodePolyId(tile.Salt, it, 0L);
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> GetOffMeshConnectionPolyEndPoints(long prevRef, long polyRef, float[] startPos, float[] endPos)
/*      */   {
/*  499 */     if (polyRef == 0L) return EnumSet.of(Status.Failure);
/*      */ 
/*  501 */     long[] saltItIp = new long[3];
/*  502 */     DecodePolyId(polyRef, saltItIp);
/*  503 */     int salt = (int)saltItIp[0];
/*  504 */     int it = (int)saltItIp[1];
/*  505 */     int ip = (int)saltItIp[2];
/*  506 */     if (it >= this._maxTiles) return EnumSet.of(Status.Failure, Status.InvalidParam);
/*  507 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) return EnumSet.of(Status.Failure, Status.InvalidParam);
/*  508 */     MeshTile tile = this._tiles[it];
/*  509 */     if (ip >= this._tiles[it].Header.PolyCount) return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */ 
/*  511 */     Poly poly = tile.Polys[ip];
/*      */ 
/*  513 */     if (poly.getType() != NavMeshBuilder.PolyTypeOffMeshConnection) {
/*  514 */       return EnumSet.of(Status.Failure);
/*      */     }
/*  516 */     int idx0 = 0; int idx1 = 1;
/*      */ 
/*  518 */     for (long i = poly.FirstLink; i != NullLink; i = tile.Links[(int)i].Next)
/*      */     {
/*  520 */       if (tile.Links[(int)i].Edge != 0)
/*      */         continue;
/*  522 */       if (tile.Links[(int)i].Ref == prevRef)
/*      */         break;
/*  524 */       idx0 = 1;
/*  525 */       idx1 = 0; break;
/*      */     }
/*      */ 
/*  531 */     System.arraycopy(tile.Verts, poly.Verts[idx0] * 3, startPos, 0, 3);
/*  532 */     System.arraycopy(tile.Verts, poly.Verts[idx1] * 3, endPos, 0, 3);
/*      */ 
/*  534 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public OffMeshConnection GetOffMeshConnectionByRef(long refId)
/*      */   {
/*  539 */     if (refId == 0L) return null;
/*      */ 
/*  541 */     long[] saltItIp = new long[3];
/*  542 */     DecodePolyId(refId, saltItIp);
/*  543 */     int salt = (int)saltItIp[0];
/*  544 */     int it = (int)saltItIp[1];
/*  545 */     int ip = (int)saltItIp[2];
/*  546 */     if (it >= this._maxTiles) return null;
/*  547 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) return null;
/*  548 */     MeshTile tile = this._tiles[it];
/*  549 */     if (ip >= this._tiles[it].Header.PolyCount) return null;
/*      */ 
/*  551 */     Poly poly = tile.Polys[ip];
/*      */ 
/*  553 */     if (poly.getType() != NavMeshBuilder.PolyTypeOffMeshConnection) {
/*  554 */       return null;
/*      */     }
/*  556 */     long idx = ip - tile.Header.OffMeshBase;
/*  557 */     return tile.OffMeshCons[(int)idx];
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> SetPolyFlags(long refId, int flags)
/*      */   {
/*  562 */     if (refId == 0L) return EnumSet.of(Status.Failure);
/*      */ 
/*  564 */     long[] saltItIp = new long[3];
/*  565 */     DecodePolyId(refId, saltItIp);
/*  566 */     int salt = (int)saltItIp[0];
/*  567 */     int it = (int)saltItIp[1];
/*  568 */     int ip = (int)saltItIp[2];
/*  569 */     if (it >= this._maxTiles) return EnumSet.of(Status.Failure, Status.InvalidParam);
/*  570 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) return EnumSet.of(Status.Failure, Status.InvalidParam);
/*  571 */     MeshTile tile = this._tiles[it];
/*  572 */     if (ip >= this._tiles[it].Header.PolyCount) return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */ 
/*  574 */     Poly poly = tile.Polys[ip];
/*  575 */     poly.Flags = flags;
/*  576 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn GetPolyFlags(long refId, int resultFlags)
/*      */   {
/*  581 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*  582 */     if (refId == 0L)
/*      */     {
/*  584 */       statusReturn.status = EnumSet.of(Status.Failure);
/*  585 */       return statusReturn;
/*      */     }
/*      */ 
/*  588 */     long[] saltItIp = new long[3];
/*  589 */     DecodePolyId(refId, saltItIp);
/*  590 */     int salt = (int)saltItIp[0];
/*  591 */     int it = (int)saltItIp[1];
/*  592 */     int ip = (int)saltItIp[2];
/*  593 */     if (it >= this._maxTiles) {
/*  594 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*  595 */       return statusReturn;
/*      */     }
/*  597 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) {
/*  598 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*  599 */       return statusReturn;
/*      */     }
/*  601 */     MeshTile tile = this._tiles[it];
/*  602 */     if (ip >= this._tiles[it].Header.PolyCount) {
/*  603 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*  604 */       return statusReturn;
/*      */     }
/*      */ 
/*  607 */     Poly poly = tile.Polys[ip];
/*  608 */     statusReturn.intValue = poly.Flags;
/*      */ 
/*  610 */     statusReturn.status = EnumSet.of(Status.Success);
/*  611 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> SetPolyArea(long refId, short area)
/*      */   {
/*  616 */     if (refId == 0L) {
/*  617 */       return EnumSet.of(Status.Failure);
/*      */     }
/*      */ 
/*  620 */     long[] saltItIp = new long[3];
/*  621 */     DecodePolyId(refId, saltItIp);
/*  622 */     int salt = (int)saltItIp[0];
/*  623 */     int it = (int)saltItIp[1];
/*  624 */     int ip = (int)saltItIp[2];
/*  625 */     if (it >= this._maxTiles) {
/*  626 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*  628 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) {
/*  629 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*  631 */     MeshTile tile = this._tiles[it];
/*  632 */     if (ip >= this._tiles[it].Header.PolyCount) {
/*  633 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*      */ 
/*  636 */     Poly poly = tile.Polys[ip];
/*  637 */     poly.setArea(area);
/*  638 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public DetourStatusReturn GetPolyArea(long refId, short resultArea)
/*      */   {
/*  643 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/*      */ 
/*  645 */     if (refId == 0L) {
/*  646 */       statusReturn.status = EnumSet.of(Status.Failure);
/*  647 */       return statusReturn;
/*      */     }
/*      */ 
/*  650 */     long[] saltItIp = new long[3];
/*  651 */     DecodePolyId(refId, saltItIp);
/*  652 */     int salt = (int)saltItIp[0];
/*  653 */     int it = (int)saltItIp[1];
/*  654 */     int ip = (int)saltItIp[2];
/*  655 */     if (it >= this._maxTiles) {
/*  656 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*  657 */       return statusReturn;
/*      */     }
/*  659 */     if ((this._tiles[it].Salt != salt) || (this._tiles[it].Header == null)) {
/*  660 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*  661 */       return statusReturn;
/*      */     }
/*  663 */     MeshTile tile = this._tiles[it];
/*  664 */     if (ip >= this._tiles[it].Header.PolyCount) {
/*  665 */       statusReturn.status = EnumSet.of(Status.Failure, Status.InvalidParam);
/*  666 */       return statusReturn;
/*      */     }
/*      */ 
/*  669 */     Poly poly = tile.Polys[ip];
/*  670 */     statusReturn.intValue = poly.getArea();
/*      */ 
/*  672 */     statusReturn.status = EnumSet.of(Status.Success);
/*  673 */     return statusReturn;
/*      */   }
/*      */ 
/*      */   public Status StoreTileState(MeshTile tile, TileState tileState)
/*      */   {
/*  678 */     tileState = new TileState();
/*  679 */     tileState.Magic = Helper.NavMeshMagic;
/*  680 */     tileState.Version = Helper.NavMeshVersion;
/*  681 */     tileState.Ref = GetTileRef(tile);
/*  682 */     tileState.PolyStates = new PolyState[tile.Header.PolyCount];
/*  683 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/*  685 */       Poly p = tile.Polys[i];
/*  686 */       tileState.PolyStates[i] = new PolyState();
/*  687 */       tileState.PolyStates[i].Flags = p.Flags;
/*  688 */       tileState.PolyStates[i].Area = p.getArea();
/*      */     }
/*      */ 
/*  691 */     return Status.Success;
/*      */   }
/*      */ 
/*      */   public EnumSet<Status> RestoreTileState(MeshTile tile, TileState tileState)
/*      */   {
/*  696 */     if (tileState.Magic != Helper.NavMeshMagic) {
/*  697 */       return EnumSet.of(Status.Failure, Status.WrongMagic);
/*      */     }
/*  699 */     if (tileState.Version != Helper.NavMeshVersion) {
/*  700 */       return EnumSet.of(Status.Failure, Status.WrongVersion);
/*      */     }
/*  702 */     if (tileState.Ref != GetTileRef(tile)) {
/*  703 */       return EnumSet.of(Status.Failure, Status.InvalidParam);
/*      */     }
/*      */ 
/*  706 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/*  708 */       Poly p = tile.Polys[i];
/*  709 */       PolyState s = tileState.PolyStates[i];
/*  710 */       p.Flags = s.Flags;
/*  711 */       p.setArea(s.Area);
/*      */     }
/*      */ 
/*  714 */     return EnumSet.of(Status.Success);
/*      */   }
/*      */ 
/*      */   public long EncodePolyId(long salt, long it, long ip)
/*      */   {
/*  719 */     return salt << (int)(this._polyBits + this._tileBits) | it << (int)this._polyBits | ip;
/*      */   }
/*      */ 
/*      */   public void DecodePolyId(long refId, long[] saltItIp)
/*      */   {
/*  724 */     long saltMask = (1 << (int)this._saltBits) - 1;
/*  725 */     long tileMask = (1 << (int)this._tileBits) - 1;
/*  726 */     long polyMask = (1 << (int)this._polyBits) - 1;
/*      */ 
/*  728 */     saltItIp[0] = (refId >> (int)(this._polyBits + this._tileBits) & saltMask);
/*  729 */     saltItIp[1] = (refId >> (int)this._polyBits & tileMask);
/*  730 */     saltItIp[2] = (refId & polyMask);
/*      */   }
/*      */ 
/*      */   public long DecodePolyIdSalt(long refId)
/*      */   {
/*  735 */     long saltMask = (1 << (int)this._saltBits) - 1;
/*  736 */     return refId >> (int)(this._polyBits + this._tileBits) & saltMask;
/*      */   }
/*      */ 
/*      */   public long DecodePolyIdTile(long refId)
/*      */   {
/*  741 */     long tileMask = (1 << (int)this._tileBits) - 1;
/*  742 */     return refId >> (int)this._polyBits & tileMask;
/*      */   }
/*      */ 
/*      */   public long DecodePolyIdPoly(long refId)
/*      */   {
/*  747 */     long polyMask = (1 << (int)this._polyBits) - 1;
/*  748 */     return refId & polyMask;
/*      */   }
/*      */ 
/*      */   private int GetNeighborTilesAt(int x, int y, int side, MeshTile[] tiles, int maxTiles)
/*      */   {
/*  753 */     int nx = x; int ny = y;
/*  754 */     switch (side)
/*      */     {
/*      */     case 0:
/*  757 */       nx++;
/*  758 */       break;
/*      */     case 1:
/*  760 */       nx++;
/*  761 */       ny++;
/*  762 */       break;
/*      */     case 2:
/*  764 */       ny++;
/*  765 */       break;
/*      */     case 3:
/*  767 */       nx--;
/*  768 */       ny++;
/*  769 */       break;
/*      */     case 4:
/*  771 */       nx--;
/*  772 */       break;
/*      */     case 5:
/*  774 */       nx--;
/*  775 */       ny--;
/*  776 */       break;
/*      */     case 6:
/*  778 */       ny--;
/*  779 */       break;
/*      */     case 7:
/*  781 */       nx++;
/*  782 */       ny--;
/*      */     }
/*      */ 
/*  786 */     return GetTilesAt(nx, ny, tiles, maxTiles);
/*      */   }
/*      */ 
/*      */   private int FindConnectingPolys(float vax, float vay, float vaz, float vbx, float vby, float vbz, MeshTile tile, int side, long[] con, float[] conarea, int maxcon)
/*      */   {
/*  792 */     if (tile == null) return 0;
/*  793 */     float[] amin = new float[2]; float[] amax = new float[2];
/*  794 */     Helper.CalcSlabEndPoints(vax, vay, vaz, vbx, vby, vbz, amin, amax, side);
/*  795 */     float apos = Helper.GetSlabCoord(vax, vay, vaz, side);
/*      */ 
/*  797 */     float[] bmin = new float[2]; float[] bmax = new float[2];
/*  798 */     int m = NavMeshBuilder.ExtLink | side;
/*  799 */     int n = 0;
/*  800 */     long baseId = GetPolyRefBase(tile);
/*      */ 
/*  802 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/*  804 */       Poly poly = tile.Polys[i];
/*  805 */       int nv = poly.VertCount;
/*  806 */       for (int j = 0; j < nv; j++)
/*      */       {
/*  808 */         if (poly.Neis[j] != m)
/*      */           continue;
/*  810 */         int vc = poly.Verts[j] * 3;
/*  811 */         int vd = poly.Verts[((j + 1) % nv)] * 3;
/*  812 */         float bpos = Helper.GetSlabCoord(tile.Verts[(vc + 0)], tile.Verts[(vc + 1)], tile.Verts[(vc + 2)], side);
/*      */ 
/*  814 */         if (Math.abs(apos - bpos) > 0.01F) {
/*      */           continue;
/*      */         }
/*  817 */         Helper.CalcSlabEndPoints(tile.Verts[(vc + 0)], tile.Verts[(vc + 1)], tile.Verts[(vc + 2)], tile.Verts[(vd + 0)], tile.Verts[(vd + 1)], tile.Verts[(vd + 2)], bmin, bmax, side);
/*      */ 
/*  819 */         if (!Helper.OverlapSlabs(amin, amax, bmin, bmax, 0.01F, tile.Header.WalkableClimb).booleanValue())
/*      */           continue;
/*  821 */         if (n >= maxcon)
/*      */           break;
/*  823 */         conarea[(n * 2 + 0)] = Math.max(amin[0], bmin[0]);
/*  824 */         conarea[(n * 2 + 1)] = Math.min(amax[0], bmax[0]);
/*  825 */         con[n] = (baseId | i);
/*  826 */         n++; break;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  831 */     return n;
/*      */   }
/*      */ 
/*      */   private void ConnectIntLinks(MeshTile tile)
/*      */   {
/*  836 */     if (tile == null) return;
/*  837 */     long baseId = GetPolyRefBase(tile);
/*      */ 
/*  839 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/*  841 */       Poly poly = tile.Polys[i];
/*  842 */       poly.FirstLink = NullLink;
/*      */ 
/*  844 */       if (poly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection) {
/*      */         continue;
/*      */       }
/*  847 */       for (int j = poly.VertCount - 1; j >= 0; j--)
/*      */       {
/*  849 */         if ((poly.Neis[j] == 0) || ((poly.Neis[j] & NavMeshBuilder.ExtLink) != 0))
/*      */           continue;
/*  851 */         long idx = AllocLink(tile);
/*  852 */         if (idx == NullLink)
/*      */           continue;
/*  854 */         Link link = tile.Links[(int)idx];
/*  855 */         link.Ref = (baseId | poly.Neis[j] - 1);
/*  856 */         link.Edge = (short)j;
/*  857 */         link.Side = 255;
/*  858 */         link.BMin = (link.BMax = 0);
/*      */ 
/*  860 */         link.Next = poly.FirstLink;
/*  861 */         poly.FirstLink = idx;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void BaseOffMeshLinks(MeshTile tile)
/*      */   {
/*  869 */     if (tile == null) return;
/*  870 */     long baseId = GetPolyRefBase(tile);
/*      */ 
/*  872 */     for (int i = 0; i < tile.Header.OffMeshConCount; i++)
/*      */     {
/*  874 */       OffMeshConnection con = tile.OffMeshCons[i];
/*  875 */       Poly poly = tile.Polys[con.Poly];
/*      */ 
/*  877 */       float[] ext = { con.Rad, tile.Header.WalkableClimb, con.Rad };
/*  878 */       int p = 0;
/*  879 */       float[] nearestPt = new float[3];
/*  880 */       long refId = FindNearestPolyInTile(tile, con.Pos[(p + 0)], con.Pos[(p + 1)], con.Pos[(p + 2)], ext[0], ext[1], ext[2], nearestPt);
/*      */ 
/*  882 */       if ((refId <= 0L) || 
/*  883 */         ((nearestPt[0] - con.Pos[(p + 0)]) * (nearestPt[0] - con.Pos[(p + 0)]) + (nearestPt[2] - con.Pos[(p + 2)]) * (nearestPt[2] - con.Pos[(p + 2)]) > con.Rad * con.Rad))
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  889 */       int v = poly.Verts[0] * 3;
/*  890 */       System.arraycopy(nearestPt, 0, tile.Verts, v, 3);
/*      */ 
/*  892 */       long idx = AllocLink(tile);
/*  893 */       if (idx != NullLink)
/*      */       {
/*  895 */         Link link = tile.Links[(int)idx];
/*  896 */         link.Ref = refId;
/*  897 */         link.Edge = 0;
/*  898 */         link.Side = 255;
/*  899 */         link.BMin = (link.BMax = 0);
/*  900 */         link.Next = poly.FirstLink;
/*  901 */         poly.FirstLink = idx;
/*      */       }
/*      */ 
/*  905 */       long tidx = AllocLink(tile);
/*  906 */       if (tidx == NullLink)
/*      */         continue;
/*  908 */       int landPolyIdx = (int)DecodePolyIdTile(refId);
/*  909 */       Poly landPoly = tile.Polys[landPolyIdx];
/*  910 */       Link link = tile.Links[(int)tidx];
/*  911 */       link.Ref = (baseId | con.Poly);
/*  912 */       link.Edge = 255;
/*  913 */       link.Side = 255;
/*  914 */       link.BMin = (link.BMax = 0);
/*  915 */       link.Next = landPoly.FirstLink;
/*  916 */       landPoly.FirstLink = tidx;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ConnectExtLinks(MeshTile tile, MeshTile target, int side)
/*      */   {
/*  924 */     if (tile == null) return;
/*      */ 
/*  926 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/*  928 */       Poly poly = tile.Polys[i];
/*      */ 
/*  930 */       int nv = poly.VertCount;
/*  931 */       for (int j = 0; j < nv; j++)
/*      */       {
/*  933 */         if ((poly.Neis[j] & NavMeshBuilder.ExtLink) == 0)
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/*  938 */         int dir = poly.Neis[j] & 0xFF;
/*  939 */         if ((side != -1) && (dir != side)) {
/*      */           continue;
/*      */         }
/*  942 */         int va = poly.Verts[j] * 3;
/*  943 */         int vb = poly.Verts[((j + 1) % nv)] * 3;
/*  944 */         long[] nei = new long[4];
/*  945 */         float[] neia = new float[8];
/*  946 */         int nnei = FindConnectingPolys(tile.Verts[(va + 0)], tile.Verts[(va + 1)], tile.Verts[(va + 2)], tile.Verts[(vb + 0)], tile.Verts[(vb + 1)], tile.Verts[(vb + 2)], target, Helper.OppositeTile(dir), nei, neia, 4);
/*      */ 
/*  949 */         for (int k = 0; k < nnei; k++)
/*      */         {
/*  951 */           long idx = AllocLink(tile);
/*  952 */           if (idx == NullLink)
/*      */             continue;
/*  954 */           Link link = tile.Links[(int)idx];
/*  955 */           link.Ref = nei[k];
/*  956 */           link.Edge = (short)j;
/*  957 */           link.Side = (short)dir;
/*      */ 
/*  959 */           link.Next = poly.FirstLink;
/*  960 */           poly.FirstLink = idx;
/*      */ 
/*  963 */           if ((dir == 0) || (dir == 4))
/*      */           {
/*  965 */             float tmin = (neia[(k * 2 + 0)] - tile.Verts[(va + 2)]) / (tile.Verts[(vb + 2)] - tile.Verts[(va + 2)]);
/*      */ 
/*  967 */             float tmax = (neia[(k * 2 + 1)] - tile.Verts[(va + 2)]) / (tile.Verts[(vb + 2)] - tile.Verts[(va + 2)]);
/*      */ 
/*  969 */             if (tmin > tmax)
/*      */             {
/*  971 */               float temp = tmin;
/*  972 */               tmin = tmax;
/*  973 */               tmax = temp;
/*      */             }
/*  975 */             link.BMin = (short)(int)(Math.min(1.0F, Math.max(tmin, 0.0F)) * 255.0F);
/*  976 */             link.BMax = (short)(int)(Math.min(1.0F, Math.max(tmax, 0.0F)) * 255.0F);
/*      */           } else {
/*  978 */             if ((dir != 2) && (dir != 6))
/*      */               continue;
/*  980 */             float tmin = (neia[(k * 2 + 0)] - tile.Verts[(va + 0)]) / (tile.Verts[(vb + 0)] - tile.Verts[(va + 0)]);
/*      */ 
/*  982 */             float tmax = (neia[(k * 2 + 1)] - tile.Verts[(va + 0)]) / (tile.Verts[(vb + 0)] - tile.Verts[(va + 0)]);
/*      */ 
/*  984 */             if (tmin > tmax)
/*      */             {
/*  986 */               float temp = tmin;
/*  987 */               tmin = tmax;
/*  988 */               tmax = temp;
/*      */             }
/*  990 */             link.BMin = (short)(int)(Math.min(1.0F, Math.max(tmin, 0.0F)) * 255.0F);
/*  991 */             link.BMax = (short)(int)(Math.min(1.0F, Math.max(tmax, 0.0F)) * 255.0F);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private long AllocLink(MeshTile tile)
/*      */   {
/* 1001 */     if (tile.LinksFreeList == NullLink)
/* 1002 */       return NullLink;
/* 1003 */     long link = tile.LinksFreeList;
/* 1004 */     tile.LinksFreeList = tile.Links[(int)link].Next;
/* 1005 */     return link;
/*      */   }
/*      */ 
/*      */   private void ConnectExtOffMeshLinks(MeshTile tile, MeshTile target, int side)
/*      */   {
/* 1010 */     if (tile == null) return;
/*      */ 
/* 1012 */     short oppositeSide = side == -1 ? 255 : (short)Helper.OppositeTile(side);
/* 1013 */     for (int i = 0; i < target.Header.OffMeshConCount; i++)
/*      */     {
/* 1015 */       OffMeshConnection targetCon = target.OffMeshCons[i];
/* 1016 */       if (targetCon.Side != oppositeSide)
/*      */         continue;
/* 1018 */       Poly targetPoly = target.Polys[targetCon.Poly];
/* 1019 */       if (targetPoly.FirstLink == NullLink) {
/*      */         continue;
/*      */       }
/* 1022 */       float[] ext = { targetCon.Rad, target.Header.WalkableClimb, targetCon.Rad };
/*      */ 
/* 1024 */       int p = 3;
/* 1025 */       float[] nearestPt = new float[3];
/* 1026 */       long refId = FindNearestPolyInTile(tile, targetCon.Pos[(p + 0)], targetCon.Pos[(p + 1)], targetCon.Pos[(p + 2)], ext[0], ext[1], ext[2], nearestPt);
/*      */ 
/* 1028 */       if (refId <= 0L) {
/*      */         continue;
/*      */       }
/* 1031 */       if ((nearestPt[0] - targetCon.Pos[(p + 0)]) * (nearestPt[0] - targetCon.Pos[(p + 0)]) + (nearestPt[2] - targetCon.Pos[(p + 2)]) * (nearestPt[2] - targetCon.Pos[(p + 2)]) > targetCon.Rad * targetCon.Rad) {
/*      */         continue;
/*      */       }
/* 1034 */       int v = targetPoly.Verts[1] * 3;
/* 1035 */       System.arraycopy(nearestPt, 0, target.Verts, v, 3);
/*      */ 
/* 1037 */       long idx = AllocLink(target);
/* 1038 */       if (idx != NullLink)
/*      */       {
/* 1040 */         Link link = target.Links[(int)idx];
/* 1041 */         link.Ref = refId;
/* 1042 */         link.Edge = 1;
/* 1043 */         link.Side = oppositeSide;
/* 1044 */         link.BMin = (link.BMax = 0);
/*      */ 
/* 1046 */         link.Next = targetPoly.FirstLink;
/* 1047 */         targetPoly.FirstLink = idx;
/*      */       }
/*      */ 
/* 1051 */       if ((targetCon.Flags & NavMeshBuilder.OffMeshConBiDir) == 0)
/*      */         continue;
/* 1053 */       long tidx = AllocLink(tile);
/* 1054 */       if (tidx == NullLink)
/*      */         continue;
/* 1056 */       int landPolyIdx = (int)DecodePolyIdPoly(refId);
/* 1057 */       Poly landPoly = tile.Polys[landPolyIdx];
/* 1058 */       Link link = tile.Links[(int)tidx];
/* 1059 */       link.Ref = (GetPolyRefBase(target) | targetCon.Poly);
/* 1060 */       link.Edge = 255;
/* 1061 */       link.Side = (side == -1 ? 255 : (short)side);
/* 1062 */       link.BMin = (link.BMax = 0);
/* 1063 */       link.Next = landPoly.FirstLink;
/* 1064 */       landPoly.FirstLink = tidx;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void UnconnectExtLinks(MeshTile tile, MeshTile target)
/*      */   {
/* 1073 */     if ((tile == null) || (target == null)) return;
/*      */ 
/* 1075 */     long targetNum = DecodePolyIdTile(GetTileRef(target));
/*      */ 
/* 1077 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/* 1079 */       Poly poly = tile.Polys[i];
/* 1080 */       int j = (int)poly.FirstLink;
/* 1081 */       int pj = (int)NullLink;
/* 1082 */       while (j != NullLink)
/*      */       {
/* 1084 */         if ((tile.Links[j].Side != 255) && (DecodePolyIdTile(tile.Links[j].Ref) == targetNum))
/*      */         {
/* 1086 */           long nj = tile.Links[j].Next;
/* 1087 */           if (pj == NullLink) {
/* 1088 */             poly.FirstLink = nj;
/*      */           }
/*      */           else
/*      */           {
/* 1093 */             tile.Links[pj].Next = nj;
/*      */           }
/* 1095 */           FreeLink(tile, j);
/* 1096 */           j = (int)nj;
/* 1097 */           continue;
/*      */         }
/*      */ 
/* 1100 */         pj = j;
/* 1101 */         j = (int)tile.Links[j].Next;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void FreeLink(MeshTile tile, long link)
/*      */   {
/* 1109 */     tile.Links[(int)link].Next = tile.LinksFreeList;
/* 1110 */     tile.LinksFreeList = link;
/*      */   }
/*      */ 
/*      */   private int QueryPolygonsInTile(MeshTile tile, float qminx, float qminy, float qminz, float qmaxx, float qmaxy, float qmaxz, long[] polys, int maxPolys)
/*      */   {
/* 1116 */     if (tile.BVTree != null)
/*      */     {
/* 1118 */       int node = 0;
/* 1119 */       int end = tile.Header.BVNodeCount;
/* 1120 */       float[] tbmin = tile.Header.BMin;
/* 1121 */       float[] tbmax = tile.Header.BMax;
/* 1122 */       float qfac = tile.Header.BVQuantFactor;
/*      */ 
/* 1124 */       int[] bmin = new int[3]; int[] bmax = new int[3];
/*      */ 
/* 1126 */       float minx = Math.min(tbmax[0], Math.max(qminx, tbmin[0])) - tbmin[0];
/* 1127 */       float miny = Math.min(tbmax[1], Math.max(qminy, tbmin[1])) - tbmin[1];
/* 1128 */       float minz = Math.min(tbmax[2], Math.max(qminz, tbmin[2])) - tbmin[2];
/* 1129 */       float maxx = Math.min(tbmax[0], Math.max(qmaxx, tbmin[0])) - tbmin[0];
/* 1130 */       float maxy = Math.min(tbmax[1], Math.max(qmaxy, tbmin[1])) - tbmin[1];
/* 1131 */       float maxz = Math.min(tbmax[2], Math.max(qmaxz, tbmin[2])) - tbmin[2];
/*      */ 
/* 1133 */       bmin[0] = ((int)(qfac * minx) & 0xFFFE);
/* 1134 */       bmin[1] = ((int)(qfac * miny) & 0xFFFE);
/* 1135 */       bmin[2] = ((int)(qfac * minz) & 0xFFFE);
/* 1136 */       bmax[0] = ((int)(qfac * maxx + 1.0F) | 0x1);
/* 1137 */       bmax[1] = ((int)(qfac * maxy + 1.0F) | 0x1);
/* 1138 */       bmax[2] = ((int)(qfac * maxz + 1.0F) | 0x1);
/*      */ 
/* 1140 */       long baseId = GetPolyRefBase(tile);
/* 1141 */       int n = 0;
/* 1142 */       while (node < end)
/*      */       {
/* 1144 */         Boolean overlap = Helper.OverlapQuantBounds(bmin, bmax, tile.BVTree[node].BMin, tile.BVTree[node].BMax);
/* 1145 */         Boolean isLeafNode = Boolean.valueOf(tile.BVTree[node].I >= 0);
/*      */ 
/* 1147 */         if ((isLeafNode.booleanValue()) && (overlap.booleanValue()))
/*      */         {
/* 1149 */           if (n < maxPolys) {
/* 1150 */             polys[(n++)] = (baseId | tile.BVTree[node].I);
/*      */           }
/*      */         }
/* 1153 */         if ((overlap.booleanValue()) || (isLeafNode.booleanValue())) {
/* 1154 */           node++;
/*      */         }
/*      */         else {
/* 1157 */           int escapeIndex = -tile.BVTree[node].I;
/* 1158 */           node += escapeIndex;
/*      */         }
/*      */       }
/* 1161 */       return n;
/*      */     }
/*      */ 
/* 1165 */     float[] bmin = new float[3]; float[] bmax = new float[3];
/* 1166 */     int n = 0;
/* 1167 */     long baseId = GetPolyRefBase(tile);
/* 1168 */     for (int i = 0; i < tile.Header.PolyCount; i++)
/*      */     {
/* 1170 */       Poly p = tile.Polys[i];
/* 1171 */       if (p.getType() == NavMeshBuilder.PolyTypeOffMeshConnection) {
/*      */         continue;
/*      */       }
/* 1174 */       int v = p.Verts[0];
/* 1175 */       System.arraycopy(tile.Verts, v, bmin, 0, 3);
/* 1176 */       System.arraycopy(tile.Verts, v, bmax, 0, 3);
/* 1177 */       for (int j = 1; j < p.VertCount; j++)
/*      */       {
/* 1179 */         v = p.Verts[j] * 3;
/* 1180 */         bmin = Helper.VMin(bmin, tile.Verts[(v + 0)], tile.Verts[(v + 1)], tile.Verts[(v + 2)]);
/* 1181 */         bmax = Helper.VMax(bmax, tile.Verts[(v + 0)], tile.Verts[(v + 1)], tile.Verts[(v + 2)]);
/*      */       }
/* 1183 */       if (!Helper.OverlapBounds(qminx, qminy, qminz, qmaxx, qmaxy, qmaxz, bmin[0], bmin[1], bmin[2], bmax[0], bmax[1], bmax[2]).booleanValue()) {
/*      */         continue;
/*      */       }
/* 1186 */       if (n < maxPolys) {
/* 1187 */         polys[(n++)] = (baseId | i);
/*      */       }
/*      */     }
/* 1190 */     return n;
/*      */   }
/*      */ 
/*      */   private long FindNearestPolyInTile(MeshTile tile, float centerx, float centery, float centerz, float extentsx, float extentsy, float extentsz, float[] nearestPt)
/*      */   {
/* 1197 */     float[] bmin = Helper.VSub(centerx, centery, centerz, extentsx, extentsy, extentsz);
/* 1198 */     float[] bmax = Helper.VAdd(centerx, centery, centerz, extentsx, extentsy, extentsz);
/*      */ 
/* 1200 */     long[] polys = new long[''];
/* 1201 */     int polyCount = QueryPolygonsInTile(tile, bmin[0], bmin[1], bmin[2], bmax[0], bmax[1], bmax[2], polys, 128);
/*      */ 
/* 1203 */     long nearest = 0L;
/* 1204 */     float nearestDistanceSqr = 3.4028235E+38F;
/* 1205 */     for (int i = 0; i < polyCount; i++)
/*      */     {
/* 1207 */       long refId = polys[i];
/* 1208 */       float[] closestPtPoly = new float[3];
/* 1209 */       ClosestPointOnPolyInTile(tile, DecodePolyIdPoly(refId), centerx, centery, centerz, closestPtPoly);
/* 1210 */       float d = Helper.VDistSqr(centerx, centery, centerz, closestPtPoly[0], closestPtPoly[1], closestPtPoly[2]);
/* 1211 */       if (d >= nearestDistanceSqr)
/*      */         continue;
/* 1213 */       if (nearestPt != null)
/* 1214 */         System.arraycopy(closestPtPoly, 0, nearestPt, 0, 3);
/* 1215 */       nearestDistanceSqr = d;
/* 1216 */       nearest = refId;
/*      */     }
/*      */ 
/* 1219 */     return nearest;
/*      */   }
/*      */ 
/*      */   private void ClosestPointOnPolyInTile(MeshTile tile, long ip, float posx, float posy, float posz, float[] closestPt)
/*      */   {
/* 1224 */     Poly poly = tile.Polys[(int)ip];
/* 1225 */     if (poly.getType() == NavMeshBuilder.PolyTypeOffMeshConnection)
/*      */     {
/* 1227 */       int v0 = poly.Verts[0] * 3;
/* 1228 */       int v1 = poly.Verts[1] * 3;
/* 1229 */       float d0 = Helper.VDist(posx, posy, posz, tile.Verts[(v0 + 0)], tile.Verts[(v0 + 1)], tile.Verts[(v0 + 2)]);
/* 1230 */       float d1 = Helper.VDist(posx, posy, posz, tile.Verts[(v1 + 0)], tile.Verts[(v1 + 1)], tile.Verts[(v1 + 2)]);
/* 1231 */       float u = d0 / (d0 + d1);
/* 1232 */       closestPt = Helper.VLerp(closestPt, tile.Verts[(v0 + 0)], tile.Verts[(v0 + 1)], tile.Verts[(v0 + 2)], tile.Verts[(v1 + 0)], tile.Verts[(v1 + 1)], tile.Verts[(v1 + 2)], u);
/* 1233 */       return;
/*      */     }
/*      */ 
/* 1236 */     PolyDetail pd = tile.DetailMeshes[(int)ip];
/*      */ 
/* 1238 */     float[] verts = new float[NavMeshBuilder.VertsPerPoly * 3];
/* 1239 */     float[] edged = new float[NavMeshBuilder.VertsPerPoly];
/* 1240 */     float[] edget = new float[NavMeshBuilder.VertsPerPoly];
/* 1241 */     int nv = poly.VertCount;
/* 1242 */     for (int i = 0; i < nv; i++)
/*      */     {
/* 1244 */       System.arraycopy(tile.Verts, poly.Verts[i] * 3, verts, i * 3, 3);
/*      */     }
/*      */ 
/* 1247 */     closestPt[0] = posx;
/* 1248 */     closestPt[1] = posy;
/* 1249 */     closestPt[2] = posz;
/*      */ 
/* 1251 */     if (!Helper.DistancePtPolyEdgesSqr(posx, posy, posz, verts, nv, edged, edget).booleanValue())
/*      */     {
/* 1253 */       float dmin = 3.4028235E+38F;
/* 1254 */       int imin = -1;
/* 1255 */       for (int i = 0; i < nv; i++)
/*      */       {
/* 1257 */         if (edged[i] >= dmin)
/*      */           continue;
/* 1259 */         dmin = edged[i];
/* 1260 */         imin = i;
/*      */       }
/*      */ 
/* 1263 */       int va = imin * 3;
/* 1264 */       int vb = (imin + 1) % nv * 3;
/* 1265 */       closestPt = Helper.VLerp(closestPt, verts[(va + 0)], verts[(va + 1)], verts[(va + 2)], verts[(vb + 0)], verts[(vb + 1)], verts[(vb + 2)], edget[imin]);
/*      */     }
/*      */ 
/* 1268 */     for (int j = 0; j < pd.TriCount; j++)
/*      */     {
/* 1270 */       int t = (int)(pd.TriBase + j) * 4;
/* 1271 */       float[] v = new float[9];
/* 1272 */       for (int k = 0; k < 3; k++)
/*      */       {
/* 1274 */         if (tile.DetailTris[(t + k)] < poly.VertCount)
/*      */         {
/* 1276 */           System.arraycopy(tile.Verts, poly.Verts[tile.DetailTris[(t + k)]] * 3, v, k * 3, 3);
/*      */         }
/*      */         else
/*      */         {
/* 1281 */           System.arraycopy(tile.DetailVerts, (int)((pd.VertBase + (tile.DetailTris[(t + k)] - poly.VertCount)) * 3L), v, k * 3, 3);
/*      */         }
/*      */       }
/*      */ 
/* 1285 */       DetourNumericReturn closestHeight = Helper.ClosestHeightPointTriangle(posx, posy, posz, v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8]);
/* 1286 */       if (!closestHeight.boolValue.booleanValue())
/*      */         continue;
/* 1288 */       closestPt[1] = closestHeight.floatValue;
/* 1289 */       break;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.NavMesh
 * JD-Core Version:    0.6.0
 */