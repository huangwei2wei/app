package atavism.server.pathing.detour;

public class TileState
{
  public int Magic;
  public int Version;
  public long Ref;
  public PolyState[] PolyStates;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.TileState
 * JD-Core Version:    0.6.0
 */