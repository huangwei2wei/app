package atavism.server.pathing.detour;

public class Link
{
  public long Ref;
  public long Next;
  public short Edge;
  public short Side;
  public short BMin;
  public short BMax;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.Link
 * JD-Core Version:    0.6.0
 */