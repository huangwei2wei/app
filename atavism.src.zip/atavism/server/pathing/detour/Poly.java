/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class Poly
/*    */ {
/*    */   public long FirstLink;
/*    */   public int[] Verts;
/*    */   public int[] Neis;
/*    */   public int Flags;
/*    */   public short VertCount;
/*    */   public short _areaAndType;
/*    */ 
/*    */   public short getArea()
/*    */   {
/* 19 */     return (short)(this._areaAndType & 0x3F);
/*    */   }
/*    */ 
/*    */   public void setArea(short value) {
/* 23 */     this._areaAndType = (short)(this._areaAndType & 0xC0 | value & 0x3F);
/*    */   }
/*    */ 
/*    */   public short getType()
/*    */   {
/* 28 */     return (short)(this._areaAndType >> 6);
/*    */   }
/*    */ 
/*    */   public void setType(short value) {
/* 32 */     this._areaAndType = (short)(this._areaAndType & 0x3F | value << 6);
/*    */   }
/*    */ 
/*    */   public Poly()
/*    */   {
/* 37 */     this.Verts = new int[NavMeshBuilder.VertsPerPoly];
/* 38 */     this.Neis = new int[NavMeshBuilder.VertsPerPoly];
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.Poly
 * JD-Core Version:    0.6.0
 */