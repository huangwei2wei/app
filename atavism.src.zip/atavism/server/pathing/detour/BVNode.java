/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class BVNode
/*    */ {
/*    */   public int[] BMin;
/*    */   public int[] BMax;
/*    */   public int I;
/*    */ 
/*    */   public BVNode()
/*    */   {
/* 17 */     this.BMin = new int[3];
/* 18 */     this.BMax = new int[3];
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.BVNode
 * JD-Core Version:    0.6.0
 */