package atavism.server.pathing.detour;

import java.util.EnumSet;

public class DetourMeshTileAndPoly
{
  public MeshTile tile;
  public Poly poly;
  public EnumSet<Status> status;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.DetourMeshTileAndPoly
 * JD-Core Version:    0.6.0
 */