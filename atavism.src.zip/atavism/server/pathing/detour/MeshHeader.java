/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class MeshHeader
/*    */ {
/*    */   public int Magic;
/*    */   public int Version;
/*    */   public int X;
/*    */   public int Y;
/*    */   public int Layer;
/*    */   public long UserId;
/*    */   public int PolyCount;
/*    */   public int VertCount;
/*    */   public int MaxLinkCount;
/*    */   public int DetailMeshCount;
/*    */   public int DetailVertCount;
/*    */   public int DetailTriCount;
/*    */   public int BVNodeCount;
/*    */   public int OffMeshConCount;
/*    */   public int OffMeshBase;
/*    */   public float WalkableHeight;
/*    */   public float WalkableRadius;
/*    */   public float WalkableClimb;
/*    */   public float[] BMin;
/*    */   public float[] BMax;
/*    */   public long TileRef;
/*    */   public float BVQuantFactor;
/*    */ 
/*    */   public MeshHeader()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MeshHeader(int Magic, int Version, int X, int Y, int Layer, long UserId, int PolyCount, int VertCount, int MaxLinkCount, int DetailMeshCount, int DetailVertCount, int DetailTriCount, float BVQuantFactor, int OffMeshBase, float WalkableHeight, float WalkableRadius, float WalkableClimb, int OffMeshConCount, int BVNodeCount, float[] Bmin, float[] Bmax)
/*    */   {
/* 44 */     this.Magic = Magic;
/* 45 */     this.Version = Version;
/* 46 */     this.X = X;
/* 47 */     this.Y = Y;
/* 48 */     this.Layer = Layer;
/* 49 */     this.UserId = UserId;
/* 50 */     this.PolyCount = PolyCount;
/* 51 */     this.VertCount = VertCount;
/* 52 */     this.MaxLinkCount = MaxLinkCount;
/* 53 */     this.DetailMeshCount = DetailMeshCount;
/*    */ 
/* 55 */     this.DetailVertCount = DetailVertCount;
/*    */ 
/* 57 */     this.DetailTriCount = DetailTriCount;
/* 58 */     this.BVNodeCount = BVNodeCount;
/* 59 */     this.OffMeshConCount = OffMeshConCount;
/* 60 */     this.OffMeshBase = OffMeshBase;
/* 61 */     this.WalkableHeight = WalkableHeight;
/* 62 */     this.WalkableRadius = WalkableRadius;
/* 63 */     this.WalkableClimb = WalkableClimb;
/* 64 */     this.BMin = Bmin;
/* 65 */     this.BMax = Bmax;
/*    */ 
/* 67 */     this.BVQuantFactor = BVQuantFactor;
/*    */   }
/*    */ 
/*    */   public MeshHeader(float f, int polyCount3, float walkableHeight2, float walkableRadius2, float walkableClimb2, int storedOffMeshConCount, int i, float[] gs, float[] gs2)
/*    */   {
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 79 */     StringBuilder builder = new StringBuilder();
/* 80 */     builder.append("PolyCount: ");
/* 81 */     builder.append(this.PolyCount);
/* 82 */     builder.append(", VertCount: ");
/* 83 */     builder.append(this.VertCount);
/* 84 */     builder.append(", DetailVertCount: ");
/* 85 */     builder.append(this.DetailVertCount);
/* 86 */     builder.append("\n");
/*    */ 
/* 90 */     return builder.toString();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.MeshHeader
 * JD-Core Version:    0.6.0
 */