/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class MeshTile
/*    */ {
/*    */   public long Salt;
/*    */   public long LinksFreeList;
/*    */   public MeshHeader Header;
/*    */   public Poly[] Polys;
/*    */   public float[] Verts;
/*    */   public Link[] Links;
/*    */   public PolyDetail[] DetailMeshes;
/*    */   public float[] DetailVerts;
/*    */   public short[] DetailTris;
/*    */   public BVNode[] BVTree;
/*    */   public OffMeshConnection[] OffMeshCons;
/*    */   public NavMeshBuilder Data;
/*    */   public int Flags;
/*    */   public MeshTile Next;
/*    */ 
/*    */   public MeshTile()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MeshTile(long Salt, MeshTile Next)
/*    */   {
/* 49 */     this.Salt = Salt;
/* 50 */     this.Next = Next;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 55 */     StringBuilder builder = new StringBuilder();
/* 56 */     builder.append("Salt: ");
/* 57 */     builder.append(this.Salt);
/* 58 */     builder.append("\n");
/* 59 */     for (PolyDetail pd : this.DetailMeshes)
/*    */     {
/* 61 */       builder.append("DetailMesh: ");
/* 62 */       builder.append(pd);
/* 63 */       builder.append("\n");
/*    */     }
/*    */ 
/* 66 */     return builder.toString();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.MeshTile
 * JD-Core Version:    0.6.0
 */