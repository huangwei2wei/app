/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class PolyDetail
/*    */ {
/*    */   public long VertBase;
/*    */   public long TriBase;
/*    */   public short VertCount;
/*    */   public short TriCount;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 19 */     return String.format("VertBase: {0}, VertCount: {1}, TriBase: {2}, TriCount: {3}", new Object[] { Long.valueOf(this.VertBase), Short.valueOf(this.VertCount), Long.valueOf(this.TriBase), Short.valueOf(this.TriCount) });
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.PolyDetail
 * JD-Core Version:    0.6.0
 */