/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ import atavism.server.pathing.recast.Helper;
/*    */ 
/*    */ public class QueryFilter
/*    */ {
/*    */   private float[] _areaCost;
/*    */   public int IncludeFlags;
/*    */   public int ExcludeFlags;
/*    */ 
/*    */   public QueryFilter()
/*    */   {
/* 27 */     this._areaCost = new float[NavMeshBuilder.MaxAreas];
/* 28 */     for (int i = 0; i < NavMeshBuilder.MaxAreas; i++)
/*    */     {
/* 30 */       this._areaCost[i] = 1.0F;
/*    */     }
/* 32 */     this.ExcludeFlags = 0;
/* 33 */     this.IncludeFlags = 65535;
/*    */   }
/*    */ 
/*    */   public Boolean PassFilter(long refId, MeshTile tile, Poly poly)
/*    */   {
/* 42 */     return Boolean.valueOf(((poly.Flags & this.IncludeFlags) != 0) && ((poly.Flags & this.ExcludeFlags) == 0));
/*    */   }
/*    */ 
/*    */   public float GetCost(float pax, float pay, float paz, float pbx, float pby, float pbz, long prevRef, MeshTile prevTile, Poly prevPoly, long curRef, MeshTile curTile, Poly curPoly, long nextRef, MeshTile nextTile, Poly nextPoly)
/*    */   {
/* 50 */     return Helper.VDist(pax, pay, paz, pbx, pby, pbz) * this._areaCost[curPoly.getArea()];
/*    */   }
/*    */ 
/*    */   public float GetAreaCost(int i)
/*    */   {
/* 55 */     return this._areaCost[i];
/*    */   }
/*    */ 
/*    */   public void SetAreaCost(int i, float cost)
/*    */   {
/* 60 */     this._areaCost[i] = cost;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.QueryFilter
 * JD-Core Version:    0.6.0
 */