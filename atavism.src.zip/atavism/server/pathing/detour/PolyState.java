package atavism.server.pathing.detour;

public class PolyState
{
  public int Flags;
  public short Area;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.PolyState
 * JD-Core Version:    0.6.0
 */