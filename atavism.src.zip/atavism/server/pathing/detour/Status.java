/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ 
/*    */ public enum Status
/*    */ {
/*  7 */   Failure(-2147483648), 
/*  8 */   Success(1073741824), 
/*  9 */   InProgress(536870912), 
/* 10 */   WrongMagic(1), 
/* 11 */   WrongVersion(2), 
/* 12 */   OutOfMemory(4), 
/* 13 */   InvalidParam(8), 
/* 14 */   BufferTooSmall(16), 
/* 15 */   OutOfNodes(32), 
/* 16 */   PartialResult(64), 
/* 17 */   DetailMask(16777215);
/*    */ 
/*    */   private final int id;
/*    */ 
/* 20 */   private Status(int id) { this.id = id; } 
/* 21 */   public int getValue() { return this.id; }
/*    */ 
/*    */   public static EnumSet<Status> MaskDetails(EnumSet<Status> status) {
/* 24 */     EnumSet details = EnumSet.allOf(Status.class);
/* 25 */     details.remove(Failure);
/* 26 */     details.remove(Success);
/* 27 */     details.remove(InProgress);
/* 28 */     status.retainAll(details);
/* 29 */     return status;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.Status
 * JD-Core Version:    0.6.0
 */