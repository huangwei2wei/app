/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class NodeQueue
/*    */ {
/*    */   public int Capacity;
/*    */   private Node[] _heap;
/*    */   private int _size;
/*    */ 
/*    */   public NodeQueue(int n)
/*    */   {
/*    */     try
/*    */     {
/* 11 */       if (n <= 0)
/* 12 */         throw new Exception("Capacity must be greater than 0");
/*    */     }
/*    */     catch (Exception e) {
/* 15 */       e.printStackTrace();
/*    */     }
/* 17 */     this.Capacity = n;
/* 18 */     this._heap = new Node[n + 1];
/* 19 */     this._size = 0;
/*    */   }
/*    */ 
/*    */   public void Clear()
/*    */   {
/* 24 */     this._size = 0;
/*    */   }
/*    */ 
/*    */   public Node Top()
/*    */   {
/* 29 */     return this._heap[0];
/*    */   }
/*    */ 
/*    */   public Node Pop()
/*    */   {
/* 34 */     Node result = this._heap[0];
/* 35 */     this._size -= 1;
/* 36 */     TrickleDown(0, this._heap[this._size]);
/* 37 */     return result;
/*    */   }
/*    */ 
/*    */   public void Push(Node node)
/*    */   {
/* 42 */     this._size += 1;
/* 43 */     BubbleUp(this._size - 1, node);
/*    */   }
/*    */ 
/*    */   public void Modify(Node node)
/*    */   {
/* 48 */     for (int i = 0; i < this._size; i++)
/*    */     {
/* 50 */       if (this._heap[i] != node)
/*    */         continue;
/* 52 */       BubbleUp(i, node);
/* 53 */       return;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Boolean Empty()
/*    */   {
/* 60 */     return Boolean.valueOf(this._size == 0);
/*    */   }
/*    */ 
/*    */   private void BubbleUp(int i, Node node)
/*    */   {
/* 67 */     int parent = (i - 1) / 2;
/* 68 */     while ((i > 0) && (this._heap[parent].Total > node.Total))
/*    */     {
/* 70 */       this._heap[i] = this._heap[parent];
/* 71 */       i = parent;
/* 72 */       parent = (i - 1) / 2;
/*    */     }
/* 74 */     this._heap[i] = node;
/*    */   }
/*    */ 
/*    */   public void TrickleDown(int i, Node node)
/*    */   {
/* 79 */     int child = i * 2 + 1;
/* 80 */     while (child < this._size)
/*    */     {
/* 82 */       if ((child + 1 < this._size) && (this._heap[child].Total > this._heap[(child + 1)].Total))
/*    */       {
/* 84 */         child++;
/*    */       }
/* 86 */       this._heap[i] = this._heap[child];
/* 87 */       i = child;
/* 88 */       child = i * 2 + 1;
/*    */     }
/* 90 */     BubbleUp(i, node);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.NodeQueue
 * JD-Core Version:    0.6.0
 */