/*     */ package atavism.server.pathing.detour;
/*     */ 
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ import atavism.server.pathing.recast.PolyMesh;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class NavMeshBuilder
/*     */ {
/*     */   public MeshHeader Header;
/*     */   public float[] NavVerts;
/*     */   public Poly[] NavPolys;
/*     */   public Link[] NavLinks;
/*     */   public PolyDetail[] NavDMeshes;
/*     */   public float[] NavDVerts;
/*     */   public short[] NavDTris;
/*     */   public BVNode[] NavBvTree;
/*     */   public OffMeshConnection[] OffMeshCons;
/*  21 */   public static int MaxAreas = 64;
/*     */ 
/*  24 */   public static int VertsPerPoly = 6;
/*  25 */   public static short PolyTypeGround = 0;
/*  26 */   public static short PolyTypeOffMeshConnection = 1;
/*     */ 
/*  28 */   public static int ExtLink = 32768;
/*  29 */   public static short OffMeshConBiDir = 1;
/*     */ 
/*     */   public NavMeshBuilder()
/*     */   {
/*     */   }
/*     */ 
/*     */   public NavMeshBuilder(NavMeshCreateParams param)
/*     */   {
/*     */     try
/*     */     {
/*  39 */       if (param.Nvp > VertsPerPoly)
/*  40 */         throw new Exception("Too many Verts per Poly for NavMeshBuilder");
/*  41 */       if (param.VertCount >= 65535)
/*  42 */         throw new Exception("Too many total verticies for NavMeshBuilder");
/*  43 */       if ((param.VertCount == 0) || (param.Verts == null))
/*  44 */         throw new Exception("No vertices, cannot generate nav mesh");
/*  45 */       if ((param.PolyCount == 0) || (param.Polys == null))
/*  46 */         throw new Exception("No Polygons, cannot generate nav mesh");
/*     */     }
/*     */     catch (Exception e) {
/*  49 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  52 */     int nvp = param.Nvp;
/*     */ 
/*  54 */     short[] offMeshConClass = new short[0];
/*  55 */     int storedOffMeshConCount = 0;
/*  56 */     int offMeshConLinkCount = 0;
/*     */ 
/*  58 */     if (param.OffMeshConCount > 0)
/*     */     {
/*  60 */       offMeshConClass = new short[param.OffMeshConCount * 2];
/*     */ 
/*  62 */       float hmin = 3.4028235E+38F;
/*  63 */       float hmax = 1.4E-45F;
/*     */ 
/*  65 */       if ((param.DetailVerts != null) && (param.DetailVertsCount > 0))
/*     */       {
/*  67 */         for (int i = 0; i < param.DetailVertsCount; i++)
/*     */         {
/*  69 */           int h = i * 3 + 1;
/*  70 */           hmin = Math.min(hmin, param.DetailVerts[h]);
/*  71 */           hmax = Math.max(hmax, param.DetailVerts[h]);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  76 */         for (int i = 0; i < param.VertCount; i++)
/*     */         {
/*  78 */           int iv = i * 3;
/*  79 */           float h = param.BMin[1] + param.Verts[(iv + 1)] * param.Ch;
/*  80 */           hmin = Math.min(hmin, h);
/*  81 */           hmax = Math.max(hmax, h);
/*     */         }
/*     */       }
/*  84 */       hmin -= param.WalkableClimb;
/*  85 */       hmax += param.WalkableClimb;
/*  86 */       float[] bmin = new float[3]; float[] bmax = new float[3];
/*  87 */       System.arraycopy(param.BMin, 0, bmin, 0, 3);
/*  88 */       System.arraycopy(param.BMax, 0, bmax, 0, 3);
/*     */ 
/*  90 */       bmin[1] = hmin;
/*  91 */       bmax[1] = hmax;
/*     */ 
/*  93 */       for (int i = 0; i < param.OffMeshConCount; i++)
/*     */       {
/*  95 */         int p0 = (i * 2 + 0) * 3;
/*  96 */         int p1 = (i * 2 + 1) * 3;
/*  97 */         offMeshConClass[(i * 2 + 0)] = ClassifyOffMeshPoint(param.OffMeshConVerts[(p0 + 0)], param.OffMeshConVerts[(p0 + 1)], param.OffMeshConVerts[(p0 + 2)], bmin, bmax);
/*     */ 
/* 100 */         offMeshConClass[(i * 2 + 1)] = ClassifyOffMeshPoint(param.OffMeshConVerts[(p1 + 0)], param.OffMeshConVerts[(p1 + 1)], param.OffMeshConVerts[(p1 + 2)], bmin, bmax);
/*     */ 
/* 104 */         if (offMeshConClass[(i * 2 + 0)] == 255)
/*     */         {
/* 106 */           if ((param.OffMeshConVerts[(p0 + 1)] < bmin[1]) || (param.OffMeshConVerts[(p0 + 1)] > bmax[1])) {
/* 107 */             offMeshConClass[(i * 2 + 0)] = 0;
/*     */           }
/*     */         }
/* 110 */         if (offMeshConClass[(i * 2 + 0)] == 255)
/* 111 */           offMeshConLinkCount++;
/* 112 */         if (offMeshConClass[(i * 2 + 1)] == 255) {
/* 113 */           offMeshConLinkCount++;
/*     */         }
/* 115 */         if (offMeshConClass[(i * 2 + 0)] == 255) {
/* 116 */           storedOffMeshConCount++;
/*     */         }
/*     */       }
/*     */     }
/* 120 */     int totPolyCount = param.PolyCount + storedOffMeshConCount;
/* 121 */     int totVertCount = param.VertCount + storedOffMeshConCount * 2;
/*     */ 
/* 123 */     int edgeCount = 0;
/* 124 */     int portalCount = 0;
/* 125 */     for (int i = 0; i < param.PolyCount; i++)
/*     */     {
/* 127 */       int p = i * 2 * nvp;
/* 128 */       for (int j = 0; j < nvp; j++)
/*     */       {
/* 130 */         if (param.Polys[(p + j)] == PolyMesh.MeshNullIdx) break;
/* 131 */         edgeCount++;
/*     */ 
/* 133 */         if ((param.Polys[(p + nvp + j)] & 0x8000) == 0)
/*     */           continue;
/* 135 */         int dir = param.Polys[(p + nvp + j)] & 0xF;
/* 136 */         if (dir != 15) {
/* 137 */           portalCount++;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 142 */     int maxLinkCount = edgeCount + portalCount * 2 + offMeshConLinkCount * 2;
/*     */ 
/* 144 */     int uniqueDetailVertCount = 0;
/* 145 */     int detailTryCount = 0;
/* 146 */     if (param.DetailMeshes != null)
/*     */     {
/* 148 */       detailTryCount = param.DetailTriCount;
/* 149 */       for (int i = 0; i < param.PolyCount; i++)
/*     */       {
/* 151 */         int p = i * nvp * 2;
/* 152 */         int ndv = (int)param.DetailMeshes[(i * 4 + 1)];
/* 153 */         int nv = 0;
/* 154 */         for (int j = 0; j < nvp; j++)
/*     */         {
/* 156 */           if (param.Polys[(p + j)] == PolyMesh.MeshNullIdx) break;
/* 157 */           nv++;
/*     */         }
/* 159 */         ndv -= nv;
/* 160 */         uniqueDetailVertCount += ndv;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 165 */       uniqueDetailVertCount = 0;
/* 166 */       detailTryCount = 0;
/* 167 */       for (int i = 0; i < param.PolyCount; i++)
/*     */       {
/* 169 */         int p = i * nvp * 2;
/* 170 */         int nv = 0;
/* 171 */         for (int j = 0; j < nvp; j++)
/*     */         {
/* 173 */           if (param.Polys[(p + j)] == PolyMesh.MeshNullIdx) break;
/* 174 */           nv++;
/*     */         }
/* 176 */         detailTryCount += nv - 2;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 181 */     this.Header = new MeshHeader(Helper.NavMeshMagic, Helper.NavMeshVersion, param.TileX, param.TileY, param.TileLayer, param.UserId, totPolyCount, totVertCount, maxLinkCount, param.PolyCount, uniqueDetailVertCount, detailTryCount, 1.0F / param.Cs, param.PolyCount, param.WalkableHeight, param.WalkableRadius, param.WalkableClimb, storedOffMeshConCount, param.BuildBvTree.booleanValue() ? param.PolyCount * 2 : 0, new float[3], new float[3]);
/*     */ 
/* 186 */     System.arraycopy(param.BMin, 0, this.Header.BMin, 0, 3);
/* 187 */     System.arraycopy(param.BMax, 0, this.Header.BMax, 0, 3);
/*     */ 
/* 189 */     this.NavVerts = new float[totVertCount * 3];
/* 190 */     this.NavPolys = new Poly[totPolyCount];
/* 191 */     for (int i = 0; i < totPolyCount; i++)
/*     */     {
/* 193 */       this.NavPolys[i] = new Poly();
/*     */     }
/* 195 */     this.NavLinks = new Link[maxLinkCount];
/* 196 */     for (int i = 0; i < maxLinkCount; i++)
/*     */     {
/* 198 */       this.NavLinks[i] = new Link();
/*     */     }
/* 200 */     this.NavDMeshes = new PolyDetail[param.PolyCount];
/* 201 */     for (int i = 0; i < param.PolyCount; i++)
/*     */     {
/* 203 */       this.NavDMeshes[i] = new PolyDetail();
/*     */     }
/* 205 */     this.NavDVerts = new float[3 * uniqueDetailVertCount];
/* 206 */     this.NavDTris = new short[4 * detailTryCount];
/* 207 */     this.NavBvTree = (param.BuildBvTree.booleanValue() ? new BVNode[param.PolyCount * 2] : new BVNode[0]);
/* 208 */     if (param.BuildBvTree.booleanValue())
/*     */     {
/* 210 */       for (int i = 0; i < param.PolyCount * 2; i++)
/*     */       {
/* 212 */         this.NavBvTree[i] = new BVNode();
/*     */       }
/*     */     }
/* 215 */     this.OffMeshCons = new OffMeshConnection[storedOffMeshConCount];
/* 216 */     for (int i = 0; i < storedOffMeshConCount; i++)
/*     */     {
/* 218 */       this.OffMeshCons[i] = new OffMeshConnection();
/*     */     }
/*     */ 
/* 222 */     int offMeshVertsBase = param.VertCount;
/* 223 */     int offMeshPolyBase = param.PolyCount;
/*     */ 
/* 227 */     for (int i = 0; i < param.VertCount; i++)
/*     */     {
/* 229 */       int iv = i * 3;
/* 230 */       int v = i * 3;
/* 231 */       this.NavVerts[(v + 0)] = (param.BMin[0] + param.Verts[(iv + 0)] * param.Cs);
/* 232 */       this.NavVerts[(v + 1)] = (param.BMin[1] + param.Verts[(iv + 1)] * param.Ch);
/* 233 */       this.NavVerts[(v + 2)] = (param.BMin[2] + param.Verts[(iv + 2)] * param.Cs);
/*     */     }
/*     */ 
/* 236 */     int n = 0;
/* 237 */     for (int i = 0; i < param.OffMeshConCount; i++)
/*     */     {
/* 239 */       if (offMeshConClass[(i * 2 + 0)] != 255)
/*     */         continue;
/* 241 */       int linkv = i * 2 * 3;
/* 242 */       int v = (offMeshVertsBase + n * 2) * 3;
/* 243 */       System.arraycopy(param.OffMeshConVerts, linkv, this.NavVerts, v, 3);
/* 244 */       System.arraycopy(param.OffMeshConVerts, linkv + 3, this.NavVerts, v + 3, 3);
/* 245 */       n++;
/*     */     }
/*     */ 
/* 251 */     int src = 0;
/* 252 */     for (int i = 0; i < param.PolyCount; i++)
/*     */     {
/* 254 */       Poly p = this.NavPolys[i];
/* 255 */       p.VertCount = 0;
/* 256 */       p.Flags = param.PolyFlags[i];
/* 257 */       p.setArea(param.PolyAreas[i]);
/* 258 */       p.setType(PolyTypeGround);
/* 259 */       for (int j = 0; j < nvp; j++)
/*     */       {
/* 261 */         if (param.Polys[(src + j)] == PolyMesh.MeshNullIdx) break;
/* 262 */         p.Verts[j] = param.Polys[(src + j)];
/* 263 */         if ((param.Polys[(src + nvp + j)] & 0x8000) != 0)
/*     */         {
/* 265 */           int dir = param.Polys[(src + nvp + j)] & 0xF;
/* 266 */           if (dir == 15)
/* 267 */             p.Neis[j] = 0;
/* 268 */           else if (dir == 0)
/* 269 */             p.Neis[j] = (ExtLink | 0x4);
/* 270 */           else if (dir == 1)
/* 271 */             p.Neis[j] = (ExtLink | 0x2);
/* 272 */           else if (dir == 2)
/* 273 */             p.Neis[j] = (ExtLink | 0x0);
/* 274 */           else if (dir == 3)
/* 275 */             p.Neis[j] = (ExtLink | 0x6);
/*     */         }
/*     */         else
/*     */         {
/* 279 */           p.Neis[j] = (param.Polys[(src + nvp + j)] + 1);
/*     */         }
/*     */         Poly tmp1813_1811 = p; tmp1813_1811.VertCount = (short)(tmp1813_1811.VertCount + 1);
/*     */       }
/* 283 */       src += nvp * 2;
/*     */     }
/*     */ 
/* 286 */     n = 0;
/* 287 */     for (int i = 0; i < param.OffMeshConCount; i++)
/*     */     {
/* 289 */       if (offMeshConClass[(i * 2 + 0)] != 255)
/*     */         continue;
/* 291 */       Poly p = this.NavPolys[(offMeshPolyBase + n)];
/* 292 */       p.VertCount = 2;
/* 293 */       p.Verts[0] = (offMeshVertsBase + n * 2 + 0);
/* 294 */       p.Verts[1] = (offMeshVertsBase + n * 2 + 1);
/* 295 */       p.Flags = param.OffMeshConFlags[i];
/* 296 */       p.setArea((short)param.OffMeshConAreas[i]);
/* 297 */       p.setType(PolyTypeOffMeshConnection);
/* 298 */       n++;
/*     */     }
/*     */ 
/* 303 */     if (param.DetailMeshes != null)
/*     */     {
/* 305 */       int vbase = 0;
/* 306 */       for (int i = 0; i < param.PolyCount; i++)
/*     */       {
/* 308 */         PolyDetail dtl = this.NavDMeshes[i];
/* 309 */         int vb = (int)param.DetailMeshes[(i * 4 + 0)];
/* 310 */         int ndv = (int)param.DetailMeshes[(i * 4 + 1)];
/* 311 */         int nv = this.NavPolys[i].VertCount;
/* 312 */         dtl.VertBase = vbase;
/* 313 */         dtl.VertCount = (short)(ndv - nv);
/* 314 */         dtl.TriBase = param.DetailMeshes[(i * 4 + 2)];
/* 315 */         dtl.TriCount = (short)(int)param.DetailMeshes[(i * 4 + 3)];
/* 316 */         if (ndv - nv <= 0)
/*     */           continue;
/* 318 */         System.arraycopy(param.DetailVerts, (vb + nv) * 3, this.NavDVerts, vbase * 3, (ndv - nv) * 3);
/* 319 */         vbase += (short)(ndv - nv);
/*     */       }
/*     */ 
/* 322 */       System.arraycopy(param.DetailTris, 0, this.NavDTris, 0, param.DetailTriCount * 4);
/*     */     }
/*     */     else
/*     */     {
/* 327 */       int tbase = 0;
/* 328 */       for (int i = 0; i < param.PolyCount; i++)
/*     */       {
/* 330 */         PolyDetail dtl = this.NavDMeshes[i];
/* 331 */         int nv = this.NavPolys[i].VertCount;
/* 332 */         dtl.VertBase = 0L;
/* 333 */         dtl.VertCount = 0;
/* 334 */         dtl.TriBase = tbase;
/* 335 */         dtl.TriCount = (short)(nv - 2);
/* 336 */         for (int j = 2; j < nv; j++)
/*     */         {
/* 338 */           int t = tbase * 4;
/* 339 */           this.NavDTris[(t + 0)] = 0;
/* 340 */           this.NavDTris[(t + 1)] = (short)(j - 1);
/* 341 */           this.NavDTris[(t + 2)] = (short)j;
/* 342 */           this.NavDTris[(t + 3)] = 4;
/* 343 */           if (j == 2)
/*     */           {
/*     */             int tmp2306_2305 = (t + 3);
/*     */             short[] tmp2306_2299 = this.NavDTris; tmp2306_2299[tmp2306_2305] = (short)(tmp2306_2299[tmp2306_2305] | 0x1);
/* 344 */           }if (j == nv - 1)
/*     */           {
/*     */             int tmp2329_2328 = (t + 3);
/*     */             short[] tmp2329_2322 = this.NavDTris; tmp2329_2322[tmp2329_2328] = (short)(tmp2329_2322[tmp2329_2328] | 0x10);
/* 345 */           }tbase++;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 351 */     if (param.BuildBvTree.booleanValue())
/*     */     {
/* 353 */       CreateBVTree(param.Verts, param.VertCount, param.Polys, param.PolyCount, nvp, param.Cs, param.Ch, param.PolyCount * 2);
/*     */     }
/*     */ 
/* 357 */     n = 0;
/* 358 */     for (int i = 0; i < param.OffMeshConCount; i++)
/*     */     {
/* 360 */       if (offMeshConClass[(i * 2 + 0)] != 255)
/*     */         continue;
/* 362 */       OffMeshConnection con = this.OffMeshCons[n];
/* 363 */       con.Poly = (offMeshPolyBase + n);
/* 364 */       int endPts = i * 2 * 3;
/* 365 */       System.arraycopy(param.OffMeshConVerts, endPts, con.Pos, 0, 3);
/* 366 */       System.arraycopy(param.OffMeshConVerts, endPts + 3, con.Pos, 3, 3);
/* 367 */       con.Rad = param.OffMeshConRad[i];
/* 368 */       con.Flags = (param.OffMeshConDir[i] > 0 ? OffMeshConBiDir : 0);
/* 369 */       con.Side = offMeshConClass[(i * 2 + 1)];
/* 370 */       if (param.OffMeshConUserId != null)
/* 371 */         con.UserId = param.OffMeshConUserId[i];
/* 372 */       n++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private int CreateBVTree(int[] verts, int nverts, int[] polys, int npolys, int nvp, float cs, float ch, int nnodes)
/*     */   {
/* 379 */     BVNode[] items = new BVNode[npolys];
/* 380 */     for (int i = 0; i < npolys; i++)
/*     */     {
/* 382 */       items[i] = new BVNode();
/*     */     }
/* 384 */     for (int i = 0; i < npolys; i++)
/*     */     {
/* 386 */       BVNode it = items[i];
/* 387 */       it.I = i;
/*     */ 
/* 389 */       int[] p = new int[polys.length - i * nvp * 2];
/* 390 */       System.arraycopy(polys, i * nvp * 2, p, 0, p.length);
/*     */       int tmp112_111 = verts[(p[0] * 3 + 0)]; it.BMax[0] = tmp112_111; it.BMin[0] = tmp112_111;
/*     */       int tmp137_136 = verts[(p[0] * 3 + 1)]; it.BMax[1] = tmp137_136; it.BMin[1] = tmp137_136;
/*     */       int tmp162_161 = verts[(p[0] * 3 + 2)]; it.BMax[2] = tmp162_161; it.BMin[2] = tmp162_161;
/*     */ 
/* 396 */       for (int j = 1; j < nvp; j++)
/*     */       {
/* 398 */         if (p[j] == PolyMesh.MeshNullIdx) break;
/* 399 */         int x = verts[(p[j] * 3 + 0)];
/* 400 */         int y = verts[(p[j] * 3 + 1)];
/* 401 */         int z = verts[(p[j] * 3 + 2)];
/*     */ 
/* 403 */         if (x < it.BMin[0]) it.BMin[0] = x;
/* 404 */         if (y < it.BMin[1]) it.BMin[1] = y;
/* 405 */         if (z < it.BMin[2]) it.BMin[2] = z;
/*     */ 
/* 407 */         if (x > it.BMax[0]) it.BMax[0] = x;
/* 408 */         if (y > it.BMax[1]) it.BMax[1] = y;
/* 409 */         if (z <= it.BMax[2]) continue; it.BMax[2] = z;
/*     */       }
/* 411 */       it.BMin[1] = (int)Math.floor(it.BMin[1] * ch / cs);
/* 412 */       it.BMax[1] = (int)Math.ceil(it.BMax[1] * ch / cs);
/*     */     }
/* 414 */     int curNode = 0;
/* 415 */     BVNode[] temp = this.NavBvTree;
/* 416 */     Subdivide(items, npolys, 0, npolys, curNode, temp);
/* 417 */     this.NavBvTree = temp;
/* 418 */     return curNode;
/*     */   }
/*     */ 
/*     */   private int Subdivide(BVNode[] items, int nitems, int imin, int imax, int curNode, BVNode[] nodes)
/*     */   {
/* 423 */     int inum = imax - imin;
/* 424 */     int icur = curNode;
/*     */ 
/* 426 */     BVNode node = nodes[(curNode++)];
/*     */ 
/* 428 */     if (inum == 1)
/*     */     {
/* 430 */       node.BMin[0] = items[imin].BMin[0];
/* 431 */       node.BMin[1] = items[imin].BMin[1];
/* 432 */       node.BMin[2] = items[imin].BMin[2];
/*     */ 
/* 434 */       node.BMax[0] = items[imin].BMax[0];
/* 435 */       node.BMax[1] = items[imin].BMax[1];
/* 436 */       node.BMax[2] = items[imin].BMax[2];
/*     */ 
/* 438 */       node.I = items[imin].I;
/*     */     }
/*     */     else
/*     */     {
/* 442 */       int[] tempBMin = new int[3]; int[] tempBMax = new int[3];
/* 443 */       CalcExtends(items, nitems, imin, imax, tempBMin, tempBMax);
/*     */ 
/* 445 */       System.arraycopy(tempBMin, 0, node.BMin, 0, 3);
/* 446 */       System.arraycopy(tempBMax, 0, node.BMax, 0, 3);
/*     */ 
/* 448 */       int axis = LongestAxis(node.BMax[0] - node.BMin[0], node.BMax[1] - node.BMin[1], node.BMax[2] - node.BMin[2]);
/*     */ 
/* 451 */       if (axis == 0)
/*     */       {
/* 453 */         Arrays.sort(items, imin, inum, new CompareNodeX());
/*     */       }
/* 455 */       else if (axis == 1)
/*     */       {
/* 457 */         Arrays.sort(items, imin, inum, new CompareNodeY());
/*     */       }
/*     */       else
/*     */       {
/* 461 */         Arrays.sort(items, imin, inum, new CompareNodeZ());
/*     */       }
/*     */ 
/* 464 */       int isplit = imin + inum / 2;
/*     */ 
/* 466 */       Subdivide(items, nitems, imin, isplit, curNode, nodes);
/* 467 */       Subdivide(items, nitems, isplit, imax, curNode, nodes);
/*     */ 
/* 469 */       int iescape = curNode - icur;
/* 470 */       node.I = (-iescape);
/*     */     }
/* 472 */     return curNode;
/*     */   }
/*     */ 
/*     */   private void CalcExtends(BVNode[] items, int nitems, int imin, int imax, int[] bmin, int[] bmax)
/*     */   {
/* 477 */     bmin[0] = items[imin].BMin[0];
/* 478 */     bmin[1] = items[imin].BMin[1];
/* 479 */     bmin[2] = items[imin].BMin[2];
/*     */ 
/* 481 */     bmax[0] = items[imin].BMax[0];
/* 482 */     bmax[1] = items[imin].BMax[1];
/* 483 */     bmax[2] = items[imin].BMax[2];
/*     */ 
/* 485 */     for (int i = imin + 1; i < imax; i++)
/*     */     {
/* 487 */       BVNode it = items[i];
/* 488 */       if (it.BMin[0] < bmin[0]) bmin[0] = it.BMin[0];
/* 489 */       if (it.BMin[1] < bmin[1]) bmin[1] = it.BMin[1];
/* 490 */       if (it.BMin[2] < bmin[2]) bmin[2] = it.BMin[2];
/*     */ 
/* 492 */       if (it.BMax[0] > bmax[0]) bmax[0] = it.BMax[0];
/* 493 */       if (it.BMax[1] > bmax[1]) bmax[1] = it.BMax[1];
/* 494 */       if (it.BMax[2] <= bmax[2]) continue; bmax[2] = it.BMax[2];
/*     */     }
/*     */   }
/*     */ 
/*     */   private int LongestAxis(int x, int y, int z)
/*     */   {
/* 500 */     int axis = 0;
/* 501 */     float maxVal = x;
/* 502 */     if (y > maxVal)
/*     */     {
/* 504 */       axis = 1;
/* 505 */       maxVal = y;
/*     */     }
/* 507 */     if (z > maxVal)
/*     */     {
/* 509 */       axis = 2;
/* 510 */       maxVal = z;
/*     */     }
/* 512 */     return axis;
/*     */   }
/*     */ 
/*     */   private short ClassifyOffMeshPoint(float ptx, float pty, float ptz, float[] bmin, float[] bmax)
/*     */   {
/* 517 */     short XP = 1;
/* 518 */     short ZP = 2;
/* 519 */     short XM = 4;
/* 520 */     short ZM = 8;
/*     */ 
/* 522 */     short outcode = 0;
/* 523 */     outcode = (short)(outcode | (ptx >= bmax[0] ? 1 : 0));
/* 524 */     outcode = (short)(outcode | (ptz >= bmax[2] ? 2 : 0));
/* 525 */     outcode = (short)(outcode | (ptx < bmin[0] ? 4 : 0));
/* 526 */     outcode = (short)(outcode | (ptz < bmin[2] ? 8 : 0));
/*     */ 
/* 528 */     switch (outcode) {
/*     */     case 1:
/* 530 */       return 0;
/*     */     case 3:
/* 531 */       return 1;
/*     */     case 2:
/* 532 */       return 2;
/*     */     case 6:
/* 533 */       return 3;
/*     */     case 4:
/* 534 */       return 4;
/*     */     case 12:
/* 535 */       return 5;
/*     */     case 8:
/* 536 */       return 6;
/*     */     case 9:
/* 537 */       return 7;
/*     */     case 5:
/*     */     case 7:
/*     */     case 10:
/* 539 */     case 11: } return 255;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.NavMeshBuilder
 * JD-Core Version:    0.6.0
 */