/*   */ package atavism.server.pathing.detour;
/*   */ 
/*   */ import java.util.EnumSet;
/*   */ 
/*   */ public class DetourRaycastHit
/*   */ {
/*   */   public int pathCount;
/*   */   public float t;
/* 8 */   public EnumSet<Status> status = EnumSet.noneOf(Status.class);
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.DetourRaycastHit
 * JD-Core Version:    0.6.0
 */