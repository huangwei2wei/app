/*    */ package atavism.server.pathing.detour;
/*    */ 
/*    */ public class OffMeshConnection
/*    */ {
/*    */   public float[] Pos;
/*    */   public float Rad;
/*    */   public int Poly;
/*    */   public short Flags;
/*    */   public short Side;
/*    */   public long UserId;
/*    */ 
/*    */   public OffMeshConnection()
/*    */   {
/* 22 */     this.Pos = new float[6];
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.detour.OffMeshConnection
 * JD-Core Version:    0.6.0
 */