/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.math.Point;
/*    */ import atavism.server.math.Quaternion;
/*    */ 
/*    */ public class PathLocAndDir
/*    */ {
/*    */   protected Point loc;
/*    */   protected AOVector dir;
/*    */   protected float lengthLeft;
/*    */ 
/*    */   public PathLocAndDir(Point loc, AOVector dir, float lengthLeft)
/*    */   {
/* 11 */     this.loc = loc;
/* 12 */     this.dir = dir;
/* 13 */     this.lengthLeft = lengthLeft;
/*    */   }
/*    */ 
/*    */   public Point getLoc() {
/* 17 */     return this.loc;
/*    */   }
/*    */ 
/*    */   public AOVector getDir() {
/* 21 */     return this.dir;
/*    */   }
/*    */ 
/*    */   public Quaternion getOrientation() {
/* 25 */     AOVector ndir = new AOVector(this.dir.getX(), 0.0F, this.dir.getZ());
/* 26 */     float length = ndir.length();
/* 27 */     if (length != 0.0F)
/*    */     {
/* 29 */       ndir.normalize();
/* 30 */       return Quaternion.fromVectorRotation(new AOVector(0.0F, 0.0F, 1.0F), ndir);
/*    */     }
/*    */ 
/* 33 */     return Quaternion.Identity;
/*    */   }
/*    */ 
/*    */   public float getLengthLeft() {
/* 37 */     return this.lengthLeft;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathLocAndDir
 * JD-Core Version:    0.6.0
 */