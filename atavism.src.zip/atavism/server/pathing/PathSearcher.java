/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.engine.QuadTree;
/*     */ import atavism.server.engine.QuadTreeElement;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class PathSearcher
/*     */ {
/* 654 */   protected static PathSearcher instance = null;
/*     */   protected Map<String, QuadTree<PathModelElement>> quadTrees;
/* 668 */   protected PathInfo pathInfo = null;
/*     */   protected String terrainString;
/* 674 */   protected static final Logger log = new Logger("PathSearcher");
/* 675 */   protected static boolean logAll = true;
/*     */ 
/*     */   protected PathSearcher(PathInfo pathInfo, Geometry geometry)
/*     */   {
/*  34 */     this.pathInfo = pathInfo;
/*  35 */     if (pathInfo != null) {
/*  36 */       Map pathDictionary = pathInfo.getPathDictionary();
/*  37 */       int count = pathDictionary.size();
/*  38 */       if (count > 0) {
/*  39 */         if (logAll)
/*  40 */           log.debug(new StringBuilder().append("PathSearcher: pathDictionary.size() = ").append(count).toString());
/*  41 */         buildQuadTrees(geometry);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static PathSearcher getInstance() {
/*  47 */     return instance;
/*     */   }
/*     */ 
/*     */   public static void createPathSearcher(PathInfo pathInfo, Geometry geometry) {
/*  51 */     instance = new PathSearcher(pathInfo, geometry);
/*     */   }
/*     */ 
/*     */   protected void buildQuadTrees(Geometry geometry)
/*     */   {
/*  91 */     this.quadTrees = new HashMap();
/*  92 */     Iterator iter = this.pathInfo.getPathDictionary().entrySet().iterator();
/*     */ 
/*  94 */     if (logAll) {
/*  95 */       log.debug(new StringBuilder().append("buildQuadTrees: pathInfo.getPathDictionary().size() = ").append(this.pathInfo.getPathDictionary().size()).toString());
/*     */     }
/*  97 */     while (iter.hasNext()) {
/*  98 */       Map.Entry entry = (Map.Entry)iter.next();
/*  99 */       PathData pathData = (PathData)entry.getValue();
/* 100 */       List pathObjects = pathData.getPathObjects();
/* 101 */       if (logAll) {
/* 102 */         log.debug(new StringBuilder().append("buildQuadTrees: pathData ").append((String)entry.getKey()).append(" has ").append(pathObjects.size()).append(" path objects").toString());
/*     */       }
/* 104 */       for (PathObject pathObject : pathObjects) {
/* 105 */         String type = pathObject.getType();
/* 106 */         if (!this.quadTrees.containsKey(type))
/* 107 */           this.quadTrees.put(type, new QuadTree(geometry));
/* 108 */         QuadTree tree = (QuadTree)this.quadTrees.get(type);
/*     */         try {
/* 110 */           if (logAll) {
/* 111 */             log.debug(new StringBuilder().append("buildQuadTrees: Adding pathObject ").append(pathObject).append(" with center ").append(pathObject.getCenter()).append(" and radius ").append(pathObject.getRadius()).toString());
/*     */           }
/* 113 */           tree.addElement(new PathModelElement(pathObject));
/*     */         } catch (AORuntimeException e) {
/* 115 */           log.error(new StringBuilder().append("In PathSearcher.buildQuadTree, exception '").append(e.getMessage()).append("' thrown").toString());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected QuadTree<PathModelElement> findQuadTreeForType(String type)
/*     */   {
/* 123 */     if (!this.quadTrees.containsKey(type)) {
/* 124 */       log.error(new StringBuilder().append("PathSearch.findModelsAtLocation: no path object type '").append(type).append("'!").toString());
/* 125 */       return null;
/*     */     }
/* 127 */     return (QuadTree)this.quadTrees.get(type);
/*     */   }
/*     */ 
/*     */   protected PathObject findModelAtLocation(String type, AOVector loc) {
/* 131 */     if (logAll)
/* 132 */       log.debug(new StringBuilder().append("findModelAtLocation: type = ").append(type).append("; loc = ").append(loc).toString());
/* 133 */     QuadTree tree = findQuadTreeForType(type);
/* 134 */     if (tree == null)
/* 135 */       return null;
/*     */     try
/*     */     {
/* 138 */       Set elements = tree.getElements(new Point(loc), 1);
/* 139 */       if (logAll)
/* 140 */         log.debug(new StringBuilder().append("findModelAtLocation: elements.size() = ").append(elements.size()).toString());
/* 141 */       for (PathModelElement elt : elements) {
/* 142 */         PathObject pathObject = (PathObject)elt.getQuadTreeObject();
/*     */ 
/* 145 */         if (logAll) {
/* 146 */           log.debug(new StringBuilder().append("findModelAtLocation: Checking pointInside2D, loc = ").append(loc).append("; pathObject = ").append(pathObject).toString());
/*     */         }
/* 148 */         if (pathObject.getBoundingPolygon().pointInside2D(loc)) {
/* 149 */           if (logAll)
/* 150 */             log.debug(new StringBuilder().append("findModelAtLocation: returning pathobject = ").append(pathObject).toString());
/* 151 */           return pathObject;
/*     */         }
/*     */       }
/* 154 */       return null;
/*     */     } catch (Exception e) {
/* 156 */       log.error(new StringBuilder().append("In PathSearcher.findModelsAtLocation, the quad tree threw error '").append(e.getMessage()).append("'!").toString());
/* 157 */     }return null;
/*     */   }
/*     */ 
/*     */   public PathObjectLocation findModelLocation(String type, AOVector loc)
/*     */   {
/* 165 */     PathObject pathObject = findModelAtLocation(type, loc);
/* 166 */     if (pathObject == null) {
/* 167 */       return null;
/*     */     }
/* 169 */     PathObjectLocation pathLoc = findModelLocation(pathObject, loc);
/* 170 */     if (pathLoc != null) {
/* 171 */       return pathLoc;
/*     */     }
/* 173 */     return new PathObjectLocation(pathObject, loc, 0, -1);
/*     */   }
/*     */ 
/*     */   public static PathObjectLocation findModelLocation(PathObject pathObject, AOVector loc)
/*     */   {
/* 178 */     int polyIndex = pathObject.findCVPolygonAtLocation(loc);
/* 179 */     if (polyIndex >= 0)
/* 180 */       return new PathObjectLocation(pathObject, loc, 1, polyIndex);
/* 181 */     polyIndex = pathObject.findTerrainPolygonAtLocation(loc);
/* 182 */     if (polyIndex >= 0) {
/* 183 */       return new PathObjectLocation(pathObject, loc, 2, polyIndex);
/*     */     }
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean legalPosition(String type, AOVector loc)
/*     */   {
/* 191 */     PathObjectLocation poLocation = findModelLocation(type, loc);
/* 192 */     return (poLocation == null) || (poLocation.getKind() != 0);
/*     */   }
/*     */ 
/*     */   public static PathFinderValue findPath(String type, AOVector loc1, AOVector loc2, boolean followsTerrain) {
/* 196 */     boolean failed = false;
/* 197 */     String why = "";
/* 198 */     if (instance == null) {
/* 199 */       failed = true;
/* 200 */       why = "PathSearcher instance not initialized";
/*     */     }
/* 202 */     else if (instance.getPathInfo() == null) {
/* 203 */       failed = true;
/* 204 */       why = "PathSearcher PathInfo member is null";
/*     */     }
/* 206 */     else if (!instance.getPathInfo().pathObjectTypeSupported(type)) {
/* 207 */       failed = true;
/* 208 */       why = new StringBuilder().append("path object type '").append(type).append("' unrecognized!").toString();
/*     */     }
/* 210 */     if (failed)
/*     */     {
/* 212 */       List path = new LinkedList();
/* 213 */       path.add(loc1);
/* 214 */       path.add(loc2);
/*     */ 
/* 219 */       String terrainString = followsTerrain ? "TT" : "CC";
/* 220 */       if (Log.loggingDebug)
/* 221 */         Log.debug(new StringBuilder().append("PathServer.findPath: didn't find path because ").append(why).toString());
/* 222 */       return new PathFinderValue(PathResult.OK, path, terrainString);
/*     */     }
/*     */ 
/* 225 */     return instance.findPathInternal(type, loc1, loc2);
/*     */   }
/*     */ 
/*     */   public static PathFinderValue findPath(OID playerOid, PathObject pathObject, AOVector loc1, AOVector loc2, float halfWidth)
/*     */   {
/* 232 */     PathObjectLocation poLoc1 = findModelLocation(pathObject, loc1);
/* 233 */     if (poLoc1 == null) {
/* 234 */       log.error(new StringBuilder().append("PathSearcher.findPath: Could not find start ").append(loc1).append(" in PathObject ").append(pathObject).toString());
/* 235 */       return null;
/*     */     }
/* 237 */     PathObjectLocation poLoc2 = findModelLocation(pathObject, loc2);
/* 238 */     if (poLoc2 == null) {
/* 239 */       log.error(new StringBuilder().append("PathSearcher.findPath: Could not find dest ").append(loc2).append(" in PathObject ").append(pathObject).toString());
/* 240 */       return null;
/*     */     }
/* 242 */     PathFinderValue value = new PathFinderValue(PathResult.OK, new LinkedList(), "");
/* 243 */     if (PathAStarSearcher.findPathInModel(value, poLoc1, poLoc2, halfWidth)) {
/* 244 */       return value;
/*     */     }
/* 246 */     return null;
/*     */   }
/*     */ 
/*     */   private PathFinderValue findPathInternal(String type, AOVector loc1, AOVector loc2)
/*     */   {
/* 265 */     if (Log.loggingDebug)
/* 266 */       log.debug(new StringBuilder().append("findPathInternal: type = ").append(type).append("; loc1 = ").append(loc1).append("; loc2 = ").append(loc2).toString());
/* 267 */     List path = new LinkedList();
/* 268 */     PathFinderValue value = new PathFinderValue(PathResult.OK, path, "");
/* 269 */     PathObjectLocation poLoc1 = findModelLocation(type, loc1);
/* 270 */     PathObjectLocation poLoc2 = findModelLocation(type, loc2);
/* 271 */     if (logAll) {
/* 272 */       log.debug(new StringBuilder().append("findPathInternal: poLoc1 = ").append(poLoc1).append("; poLoc2 = ").append(poLoc2).toString());
/*     */     }
/*     */ 
/* 275 */     float halfWidth = this.pathInfo.getTypeHalfWidth(type);
/* 276 */     if ((poLoc1 == null) && (poLoc2 == null)) {
/* 277 */       PathResult result = findPathThroughTerrain(value, type, loc1, loc2, null, null, halfWidth, false, false);
/* 278 */       value.setResult(result);
/* 279 */       return value;
/*     */     }
/* 281 */     PathObject p1 = poLoc1 != null ? poLoc1.getPathObject() : null;
/* 282 */     PathObject p2 = poLoc2 != null ? poLoc2.getPathObject() : null;
/* 283 */     if ((logAll) && (p1 != null))
/* 284 */       log.debug(new StringBuilder().append("findPathInternal p1 boundingPolygon = ").append(p1.getBoundingPolygon()).toString());
/* 285 */     if ((logAll) && (p2 != null))
/* 286 */       log.debug(new StringBuilder().append("findPathInternal p2 boundingPolygon = ").append(p2.getBoundingPolygon()).toString());
/* 287 */     boolean sameModel = (p1 != null) && (p1 == p2);
/* 288 */     if (sameModel)
/*     */     {
/* 290 */       if (!findPathInModel(value, poLoc1, poLoc2, halfWidth)) {
/* 291 */         if (logAll)
/* 292 */           log.debug(new StringBuilder().append("No path in model from ").append(loc1).append(" to ").append(loc2).toString());
/* 293 */         value.setResult(PathResult.ExitModelPath);
/* 294 */         return value;
/*     */       }
/*     */     }
/* 297 */     boolean needEgressFromStartModel = (p1 != null) && (poLoc1.getKind() == 1);
/* 298 */     boolean needToCrossTerrain = (p1 == null) || (!sameModel);
/* 299 */     boolean needEntryToEndModel = (p2 != null) && (poLoc2.getKind() == 1);
/* 300 */     if (logAll) {
/* 301 */       log.debug(new StringBuilder().append("findPathInternal: startModel = ").append(tOrF(needEgressFromStartModel)).append("; crossTerrain = ").append(tOrF(needToCrossTerrain)).append("; endModel = ").append(tOrF(needEntryToEndModel)).toString());
/*     */     }
/* 303 */     PathArc exitPortal = null;
/* 304 */     AOVector exitPortalLoc = null;
/* 305 */     PathArc entryPortal = null;
/* 306 */     AOVector entryPortalLoc = null;
/*     */ 
/* 308 */     if (needEgressFromStartModel) {
/* 309 */       exitPortal = findPortalClosestToLoc(p1, loc2);
/* 310 */       exitPortalLoc = makeTerrainLocationFromPortal(p1, exitPortal, loc2, halfWidth);
/* 311 */       if (Log.loggingDebug)
/* 312 */         log.debug(new StringBuilder().append("findPathInternal exitPortal = ").append(exitPortal).append("; exitPortalLoc = ").append(exitPortalLoc).toString());
/* 313 */       int pathSize = path.size();
/* 314 */       if (!findPathToPortal(value, halfWidth, poLoc1, exitPortal, exitPortalLoc)) {
/* 315 */         if (logAll) {
/* 316 */           log.debug(new StringBuilder().append("No path in model from ").append(loc1).append(" to exit portal ").append(exitPortal).append(" at location ").append(exitPortalLoc).toString());
/*     */         }
/* 318 */         value.setResult(PathResult.ExitModelPath);
/* 319 */         return value;
/*     */       }
/* 321 */       dumpAddedPathElements("Exiting model1", value, pathSize);
/*     */     }
/* 323 */     if (needEntryToEndModel) {
/* 324 */       entryPortal = findPortalClosestToLoc(p2, loc1);
/* 325 */       entryPortalLoc = makeTerrainLocationFromPortal(p2, entryPortal, loc1, halfWidth);
/* 326 */       if (logAll)
/* 327 */         log.debug(new StringBuilder().append("findPathInternal entryPortal = ").append(entryPortal).append("; entryPortalLoc = ").append(entryPortalLoc).toString());
/*     */     }
/* 329 */     if (needToCrossTerrain) {
/* 330 */       AOVector tloc1 = (p1 != null) && (exitPortalLoc != null) ? exitPortalLoc : loc1;
/* 331 */       AOVector tloc2 = (p2 != null) && (entryPortalLoc != null) ? entryPortalLoc : loc2;
/* 332 */       int pathSize = path.size();
/*     */ 
/* 334 */       PathResult result = findPathThroughTerrain(value, type, tloc1, tloc2, poLoc2, entryPortalLoc, halfWidth, needEgressFromStartModel, needEntryToEndModel);
/*     */ 
/* 336 */       if (result != PathResult.OK) {
/* 337 */         if (logAll)
/* 338 */           log.debug(new StringBuilder().append("findPathInternal: No path through terrain from ").append(tloc1).append(" to ").append(tloc2).toString());
/* 339 */         value.setResult(result);
/* 340 */         return value;
/*     */       }
/* 342 */       dumpAddedPathElements("Going through terrain", value, pathSize);
/*     */     }
/* 344 */     value.setResult(PathResult.OK);
/* 345 */     return value;
/*     */   }
/*     */ 
/*     */   String tOrF(boolean value) {
/* 349 */     return value ? "true" : "false";
/*     */   }
/*     */ 
/*     */   PathArc findPortalClosestToLoc(PathObject p, AOVector loc) {
/* 353 */     PathArc closestPortal = null;
/* 354 */     float closestDistance = 3.4028235E+38F;
/* 355 */     for (PathArc portal : p.getPortals()) {
/* 356 */       float d = AOVector.distanceTo(loc, portal.getEdge().getMidpoint());
/* 357 */       if (d < closestDistance) {
/* 358 */         closestDistance = d;
/* 359 */         closestPortal = portal;
/*     */       }
/*     */     }
/* 362 */     return closestPortal;
/*     */   }
/*     */ 
/*     */   void dumpAddedPathElements(String heading, PathFinderValue value, int firstElt) {
/* 366 */     String s = value.stringPath(firstElt);
/* 367 */     if (Log.loggingDebug)
/* 368 */       log.debug(new StringBuilder().append("dumpAddedPathElements for ").append(heading).append(": ").append(s).toString());
/*     */   }
/*     */ 
/*     */   AOVector makeTerrainLocationFromPortal(PathObject pathObject, PathArc portal, AOVector loc, float halfWidth)
/*     */   {
/* 375 */     PathEdge edge = portal.getEdge();
/* 376 */     AOVector start = edge.getStart();
/* 377 */     AOVector end = edge.getEnd();
/*     */ 
/* 379 */     boolean startClosest = AOVector.distanceTo(loc, start) < AOVector.distanceTo(loc, end);
/*     */ 
/* 382 */     AOVector n = new AOVector(end);
/* 383 */     n.sub(start);
/* 384 */     n.setY(0.0F);
/* 385 */     n.normalize();
/*     */     AOVector p;
/* 387 */     if (startClosest) {
/* 388 */       AOVector p = AOVector.multiply(n, halfWidth);
/* 389 */       p.add(start);
/*     */     }
/*     */     else {
/* 392 */       p = AOVector.multiply(n, -halfWidth);
/* 393 */       p.add(end);
/*     */     }
/*     */ 
/* 398 */     PathPolygon cvPolygon = pathObject.getCVPolygon(portal.getPoly1Index());
/* 399 */     PathPolygon terrainPolygon = pathObject.getTerrainPolygon(portal.getPoly2Index());
/* 400 */     AOVector cvCentroid = cvPolygon.getCentroid();
/* 401 */     AOVector terrainCentroid = terrainPolygon.getCentroid();
/* 402 */     float temp = n.getX();
/* 403 */     n.setX(n.getY());
/* 404 */     n.setY(-temp);
/* 405 */     AOVector q = new AOVector(terrainCentroid);
/* 406 */     q.sub(cvCentroid);
/*     */ 
/* 410 */     if (q.dotProduct(n) < 0.0F)
/* 411 */       n.multiply(-halfWidth);
/*     */     else
/* 413 */       n.multiply(halfWidth);
/* 414 */     p.add(n);
/* 415 */     return new AOVector(p);
/*     */   }
/*     */ 
/*     */   public PathResult findPathThroughTerrain(PathFinderValue value, String type, AOVector loc1, AOVector loc2, PathObjectLocation poLoc2, AOVector entryPortalLoc, float halfWidth, boolean haveStartModel, boolean haveEndModel)
/*     */   {
/* 424 */     if (logAll)
/* 425 */       log.debug(new StringBuilder().append("findPathThroughTerrain loc1 = ").append(loc1).append("; loc2 = ").append(loc2).toString());
/* 426 */     List path = value.getPath();
/* 427 */     int pathSize = path.size();
/* 428 */     if (!haveStartModel)
/* 429 */       value.addPathElement(loc1, true);
/* 430 */     AOVector next = loc1;
/*     */ 
/* 434 */     int limit = 100;
/* 435 */     for (int i = 0; i < limit; i++) {
/* 436 */       PathIntersection intersection = findFirstObstacle(type, next, loc2);
/* 437 */       if (intersection == null)
/*     */         break;
/* 439 */       next = findPathAroundObstacle(type, value, intersection, next, loc2, poLoc2, entryPortalLoc, halfWidth);
/* 440 */       if (next == null) {
/* 441 */         value.removePathElementsAfter(pathSize);
/* 442 */         return PathResult.TerrainPath;
/*     */       }
/* 444 */       boolean endModel = (poLoc2 != null) && (intersection.getPathObject() == poLoc2.getPathObject());
/* 445 */       if (endModel)
/*     */         break;
/*     */     }
/* 448 */     if (!haveEndModel)
/* 449 */       value.addPathElement(loc2, true);
/* 450 */     if (logAll) {
/* 451 */       log.debug(new StringBuilder().append("findPathThroughTerrain from loc1 ").append(loc1).append(" to loc2 ").append(loc2).append("; i = ").append(i).append(" ").append(value.stringPath(pathSize)).toString());
/*     */     }
/* 453 */     if (i == limit)
/*     */     {
/* 455 */       value.removePathElementsAfter(pathSize);
/* 456 */       if (logAll)
/* 457 */         log.error(new StringBuilder().append("findPathThroughTerrain: Didn't find path in ").append(limit).append(" tries").toString());
/* 458 */       return PathResult.TerrainPath;
/*     */     }
/*     */ 
/* 461 */     return PathResult.OK;
/*     */   }
/*     */ 
/*     */   public PathIntersection findFirstObstacle(String type, AOVector loc1, AOVector loc2)
/*     */   {
/* 468 */     if (logAll)
/* 469 */       log.debug(new StringBuilder().append("findFirstObstacle: loc1 = ").append(loc1).append("; loc2 = ").append(loc2).toString());
/* 470 */     QuadTree tree = findQuadTreeForType(type);
/* 471 */     if (tree == null)
/* 472 */       return null;
/* 473 */     Set elems = tree.getElementsBetween(new Point(loc1), new Point(loc2));
/* 474 */     if (logAll)
/* 475 */       log.debug(new StringBuilder().append("findFirstObstacle: elems = ").append(elems == null ? elems : Integer.valueOf(elems.size())).toString());
/* 476 */     if ((elems == null) || (elems.size() == 0))
/* 477 */       return null;
/*     */     while (true) {
/* 479 */       PathIntersection closest = null;
/* 480 */       QuadTreeElement closestElem = null;
/* 481 */       for (PathModelElement elem : elems) {
/* 482 */         if (logAll)
/* 483 */           log.debug(new StringBuilder().append("findFirstObstacle elem = ").append(elem).toString());
/* 484 */         PathObject pathObject = (PathObject)elem.getQuadTreeObject();
/* 485 */         PathIntersection intersection = pathObject.getBoundingPolygon().closestIntersection(pathObject, loc1, loc2);
/*     */ 
/* 487 */         if ((intersection != null) && ((closest == null) || (intersection.getWhere1() < closest.getWhere1())))
/*     */         {
/* 489 */           closest = intersection;
/* 490 */           closestElem = elem;
/*     */         }
/*     */       }
/* 493 */       if (closest == null)
/* 494 */         return null;
/* 495 */       PathObject pathObject = closest.getPathObject();
/* 496 */       PathIntersection pathObjectClosest = pathObject.closestIntersection(loc1, loc2);
/* 497 */       if (pathObjectClosest != null) {
/* 498 */         if (logAll)
/* 499 */           log.debug(new StringBuilder().append("findFirstObstacle: pathObjectClosest = ").append(pathObjectClosest).toString());
/* 500 */         return pathObjectClosest;
/*     */       }
/*     */ 
/* 503 */       elems.remove(closestElem);
/*     */     }
/*     */   }
/*     */ 
/*     */   AOVector findPathAroundObstacle(String type, PathFinderValue value, PathIntersection intersection, AOVector loc1, AOVector loc2, PathObjectLocation poLoc2, AOVector entryPortalLoc, float halfWidth)
/*     */   {
/* 512 */     PathObject pathObject = intersection.getPathObject();
/* 513 */     boolean endModel = (poLoc2 != null) && (pathObject == poLoc2.getPathObject());
/* 514 */     int corner1 = endModel ? findCornerOnPathToPortal(loc1, poLoc2, entryPortalLoc) : pathObject.getClosestCornerToPoint(loc1);
/*     */ 
/* 516 */     AOVector cornerPoint1 = (AOVector)pathObject.getBoundingPolygon().getCorners().get(corner1);
/* 517 */     PathPolygon terrainPoly1 = pathObject.getTerrainPolygonAtCorner(corner1);
/* 518 */     if (terrainPoly1 == null) {
/* 519 */       log.error("findPathAroundObstacle: terrainPoly1 = null!");
/* 520 */       return null;
/*     */     }
/* 522 */     AOVector endPoint = null;
/* 523 */     PathPolygon endPolygon = null;
/* 524 */     PathObjectLocation poLoc1 = new PathObjectLocation(pathObject, cornerPoint1, 2, terrainPoly1.getIndex());
/*     */ 
/* 526 */     if (!endModel) {
/* 527 */       int corner2 = pathObject.getClosestCornerToPoint(loc2);
/* 528 */       endPoint = (AOVector)pathObject.getBoundingPolygon().getCorners().get(corner2);
/* 529 */       endPolygon = pathObject.getTerrainPolygonAtCorner(corner2);
/* 530 */       if (endPolygon == null) {
/* 531 */         log.error("findPathAroundObstacle: endPolygon = null!");
/* 532 */         return null;
/*     */       }
/*     */     }
/* 535 */     if (logAll) {
/* 536 */       log.debug(new StringBuilder().append("findPathAroundObstacle: loc1 = ").append(loc1).append("; corner1 = ").append(corner1).append("; cornerPoint1 = ").append(cornerPoint1).append("; terrainPoly1 = ").append(terrainPoly1).append("; endModel = ").append(tOrF(endModel)).append("; loc2 = ").append(loc2).append("; endPoint = ").append(endPoint).append("; endPoint = ").append(endPoint).append("; endPolygon = ").append(endPolygon).toString());
/*     */     }
/*     */ 
/* 541 */     PathObjectLocation poLoc = endModel ? poLoc2 : new PathObjectLocation(pathObject, endPoint, endPolygon.getKind(), endPolygon.getIndex());
/*     */ 
/* 543 */     if (PathAStarSearcher.findPathInModel(value, poLoc1, poLoc, halfWidth))
/*     */     {
/* 548 */       return endModel ? cornerPoint1 : endPoint;
/*     */     }
/* 550 */     return null;
/*     */   }
/*     */ 
/*     */   protected int findCornerOnPathToPortal(AOVector loc, PathObjectLocation poLoc, AOVector entryPortalLoc)
/*     */   {
/* 556 */     float closestDistance = 3.4028235E+38F;
/* 557 */     int closestCorner = -1;
/* 558 */     PathPolygon poly = poLoc.getPathObject().getBoundingPolygon();
/* 559 */     List corners = poly.getCorners();
/* 560 */     if (logAll) {
/* 561 */       log.debug(new StringBuilder().append("findCornerOnPathToPortal: loc = ").append(loc).append("; poLoc = ").append(poLoc).append("; entryPortalLoc = ").append(entryPortalLoc).append("; poly = ").append(poly).toString());
/*     */     }
/* 563 */     for (int i = 0; i < corners.size(); i++) {
/* 564 */       AOVector corner = (AOVector)corners.get(i);
/* 565 */       float toCorner = AOVector.distanceTo(loc, corner);
/* 566 */       float cornerToEntryLoc = AOVector.distanceTo(corner, entryPortalLoc);
/* 567 */       float d = toCorner + cornerToEntryLoc;
/* 568 */       if (d < closestDistance) {
/* 569 */         closestDistance = d;
/* 570 */         closestCorner = i;
/*     */       }
/*     */     }
/* 573 */     return closestCorner;
/*     */   }
/*     */ 
/*     */   boolean findPathToPortal(PathFinderValue value, float halfWidth, PathObjectLocation poLoc, PathArc portal, AOVector portalLoc)
/*     */   {
/* 632 */     PathObjectLocation startLoc = new PathObjectLocation(poLoc.getPathObject(), portalLoc, 1, portal.getPoly1Index());
/*     */ 
/* 634 */     if (logAll)
/* 635 */       log.debug(new StringBuilder().append("findPathToPortal portal = ").append(portal).append("; halfWidth = ").append(halfWidth).append("; startLoc = ").append(startLoc).toString());
/* 636 */     return findPathInModel(value, poLoc, startLoc, halfWidth);
/*     */   }
/*     */ 
/*     */   boolean findPathFromPortal(PathFinderValue value, float halfWidth, PathObjectLocation poLoc, PathArc portal, AOVector portalLoc)
/*     */   {
/* 641 */     PathObjectLocation startLoc = new PathObjectLocation(poLoc.getPathObject(), portalLoc, 1, portal.getPoly1Index());
/*     */ 
/* 643 */     if (logAll)
/* 644 */       log.debug(new StringBuilder().append("findPathFromPortal portal = ").append(portal).append("; halfWidth = ").append(halfWidth).append("; startLoc = ").append(startLoc).toString());
/* 645 */     return findPathInModel(value, startLoc, poLoc, halfWidth);
/*     */   }
/*     */ 
/*     */   protected boolean findPathInModel(PathFinderValue value, PathObjectLocation poLoc1, PathObjectLocation poLoc2, float halfWidth) {
/* 649 */     return PathAStarSearcher.findPathInModel(value, poLoc1, poLoc2, halfWidth);
/*     */   }
/*     */ 
/*     */   public PathInfo getPathInfo()
/*     */   {
/* 662 */     return this.pathInfo;
/*     */   }
/*     */ 
/*     */   public static enum PathResult
/*     */   {
/*  55 */     Illegal(0), 
/*  56 */     OK(1), 
/*  57 */     ExitModelPath(2), 
/*  58 */     TerrainPath(3), 
/*  59 */     EntryModelPath(4);
/*     */ 
/*  82 */     byte val = -1;
/*     */ 
/*     */     private PathResult(byte val)
/*     */     {
/*  62 */       this.val = val;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  66 */       switch (this.val) {
/*     */       case 0:
/*  68 */         return "Illegal";
/*     */       case 1:
/*  70 */         return "Success";
/*     */       case 2:
/*  72 */         return "Failure - could not calculate exit model path";
/*     */       case 3:
/*  74 */         return "Failure - could not calculate terrain crossing path";
/*     */       case 4:
/*  76 */         return "Failure - could not calculate entry model path";
/*     */       }
/*  78 */       return "Failure - unknown PathResult value " + this.val;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathSearcher
 * JD-Core Version:    0.6.0
 */