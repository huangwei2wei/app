/*    */ package atavism.server.pathing.crowd;
/*    */ 
/*    */ public final class ObstacleState
/*    */ {
/* 13 */   public static final ObstacleState DT_OBSTACLE_EMPTY = new ObstacleState("DT_OBSTACLE_EMPTY");
/* 14 */   public static final ObstacleState DT_OBSTACLE_PROCESSING = new ObstacleState("DT_OBSTACLE_PROCESSING");
/* 15 */   public static final ObstacleState DT_OBSTACLE_PROCESSED = new ObstacleState("DT_OBSTACLE_PROCESSED");
/* 16 */   public static final ObstacleState DT_OBSTACLE_REMOVING = new ObstacleState("DT_OBSTACLE_REMOVING");
/*    */ 
/* 52 */   private static ObstacleState[] swigValues = { DT_OBSTACLE_EMPTY, DT_OBSTACLE_PROCESSING, DT_OBSTACLE_PROCESSED, DT_OBSTACLE_REMOVING };
/* 53 */   private static int swigNext = 0;
/*    */   private final int swigValue;
/*    */   private final String swigName;
/*    */ 
/*    */   public final int swigValue()
/*    */   {
/* 19 */     return this.swigValue;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 23 */     return this.swigName;
/*    */   }
/*    */ 
/*    */   public static ObstacleState swigToEnum(int swigValue) {
/* 27 */     if ((swigValue < swigValues.length) && (swigValue >= 0) && (swigValues[swigValue].swigValue == swigValue))
/* 28 */       return swigValues[swigValue];
/* 29 */     for (int i = 0; i < swigValues.length; i++)
/* 30 */       if (swigValues[i].swigValue == swigValue)
/* 31 */         return swigValues[i];
/* 32 */     throw new IllegalArgumentException("No enum " + ObstacleState.class + " with value " + swigValue);
/*    */   }
/*    */ 
/*    */   private ObstacleState(String swigName) {
/* 36 */     this.swigName = swigName;
/* 37 */     this.swigValue = (swigNext++);
/*    */   }
/*    */ 
/*    */   private ObstacleState(String swigName, int swigValue) {
/* 41 */     this.swigName = swigName;
/* 42 */     this.swigValue = swigValue;
/* 43 */     swigNext = swigValue + 1;
/*    */   }
/*    */ 
/*    */   private ObstacleState(String swigName, ObstacleState swigEnum) {
/* 47 */     this.swigName = swigName;
/* 48 */     this.swigValue = swigEnum.swigValue;
/* 49 */     swigNext = this.swigValue + 1;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.ObstacleState
 * JD-Core Version:    0.6.0
 */