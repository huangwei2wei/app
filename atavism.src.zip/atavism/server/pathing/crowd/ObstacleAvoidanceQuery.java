/*     */ package atavism.server.pathing.crowd;
/*     */ 
/*     */ import atavism.server.objects.Vector2;
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ 
/*     */ public class ObstacleAvoidanceQuery
/*     */ {
/*     */   private ObstacleAvoidanceParams _params;
/*     */   private float _invHorizTime;
/*     */   private float _vmax;
/*     */   private float _invVmax;
/*     */   private int _maxCircles;
/*     */   private ObstacleCircle[] _circles;
/*     */   private int _nCircles;
/*     */   private int _maxSegments;
/*     */   private ObstacleSegment[] _segments;
/*     */   private int _nSegments;
/*  22 */   private final int MaxPatternDivs = 32;
/*  23 */   private final int MaxPatternRings = 4;
/*     */ 
/*     */   public ObstacleAvoidanceQuery()
/*     */   {
/*  27 */     this._maxCircles = 0;
/*  28 */     this._circles = null;
/*  29 */     this._nCircles = 0;
/*     */ 
/*  31 */     this._maxSegments = 0;
/*  32 */     this._segments = null;
/*  33 */     this._nSegments = 0;
/*     */   }
/*     */ 
/*     */   public Boolean Init(int maxCircles, int maxSegments)
/*     */   {
/*  38 */     this._maxCircles = maxCircles;
/*  39 */     this._nCircles = 0;
/*  40 */     this._circles = new ObstacleCircle[this._maxCircles];
/*  41 */     for (int i = 0; i < this._maxCircles; i++)
/*     */     {
/*  43 */       this._circles[i] = new ObstacleCircle();
/*     */     }
/*  45 */     this._maxSegments = maxSegments;
/*  46 */     this._nSegments = 0;
/*  47 */     this._segments = new ObstacleSegment[this._maxSegments];
/*  48 */     for (int i = 0; i < this._maxSegments; i++)
/*     */     {
/*  50 */       this._segments[i] = new ObstacleSegment();
/*     */     }
/*  52 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public void Reset()
/*     */   {
/*  57 */     this._nCircles = 0;
/*  58 */     this._nSegments = 0;
/*     */   }
/*     */ 
/*     */   private void Prepare(float[] pos, float[] dvel)
/*     */   {
/*  63 */     for (int i = 0; i < this._nCircles; i++)
/*     */     {
/*  65 */       ObstacleCircle cir = this._circles[i];
/*     */ 
/*  67 */       float[] pa = pos;
/*  68 */       float[] pb = cir.p;
/*     */ 
/*  70 */       float[] orig = new float[3];
/*  71 */       orig[0] = 0.0F;
/*  72 */       orig[1] = 0.0F;
/*     */ 
/*  74 */       float[] dv = new float[3];
/*  75 */       cir.dp = Helper.VSub(pb[0], pb[1], pb[2], pa[0], pa[1], pa[2]);
/*  76 */       cir.dp = Helper.VNormalize(cir.dp);
/*  77 */       dv = Helper.VSub(cir.dvel[0], cir.dvel[1], cir.dvel[2], dvel[0], dvel[1], dvel[2]);
/*     */ 
/*  79 */       float a = Helper.TriArea2D(orig, cir.dp, dv);
/*  80 */       if (a < 0.01F)
/*     */       {
/*  82 */         cir.np[0] = (-cir.dp[2]);
/*  83 */         cir.np[2] = cir.dp[0];
/*     */       }
/*     */       else
/*     */       {
/*  87 */         cir.np[0] = cir.dp[2];
/*  88 */         cir.np[2] = (-cir.dp[0]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  93 */     for (int i = 0; i < this._nSegments; i++)
/*     */     {
/*  95 */       ObstacleSegment seg = this._segments[i];
/*     */ 
/*  97 */       float r = 0.01F;
/*  98 */       seg.touch = Boolean.valueOf(Helper.DistancePtSegSqr2D(pos[0], pos[1], pos[2], seg.p[0], seg.p[1], seg.p[2], seg.q[0], seg.q[1], seg.q[2]).x < r * r);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int SweetCircleCircle(float[] c0, float r0, float[] v, float[] c1, float r1, Vector2 htMinMax)
/*     */   {
/* 104 */     float EPS = 0.001F;
/* 105 */     float[] s = Helper.VSub(c1[0], c1[1], c1[2], c0[0], c0[1], c0[2]);
/* 106 */     float r = r0 + r1;
/* 107 */     float c = Helper.VDot2D(s, s) - r * r;
/* 108 */     float a = Helper.VDot2D(v, v);
/* 109 */     if (a < EPS) return 0;
/*     */ 
/* 111 */     float b = Helper.VDot2D(v, s);
/* 112 */     float d = b * b - a * c;
/* 113 */     if (d < 0.0F) return 0;
/* 114 */     a = 1.0F / a;
/* 115 */     float rd = (float)Math.sqrt(d);
/* 116 */     htMinMax.x = ((b - rd) * a);
/* 117 */     htMinMax.y = ((b + rd) * a);
/* 118 */     return 1;
/*     */   }
/*     */ 
/*     */   public Vector2 isectRaySeg(float[] ap, float[] u, float[] bp, float[] bq)
/*     */   {
/* 123 */     Vector2 raySeg = new Vector2();
/* 124 */     float[] v = Helper.VSub(bq[0], bq[1], bq[2], bp[0], bp[1], bp[2]);
/* 125 */     float[] w = Helper.VSub(ap[0], ap[1], ap[2], bp[0], bp[1], bp[2]);
/* 126 */     float d = Helper.VPerp2D(u, v);
/* 127 */     if (Math.abs(d) < 1.0E-006F) {
/* 128 */       raySeg.x = 0.0D;
/* 129 */       return raySeg;
/*     */     }
/* 131 */     d = 1.0F / d;
/* 132 */     raySeg.y = (Helper.VPerp2D(v, w) * d);
/* 133 */     if ((raySeg.y < 0.0D) || (raySeg.y > 1.0D)) {
/* 134 */       raySeg.x = 0.0D;
/* 135 */       return raySeg;
/*     */     }
/* 137 */     float s = Helper.VPerp2D(u, w) * d;
/* 138 */     if ((s < 0.0F) || (s > 1.0F)) {
/* 139 */       raySeg.x = 0.0D;
/* 140 */       return raySeg;
/*     */     }
/* 142 */     raySeg.x = 1.0D;
/* 143 */     return raySeg;
/*     */   }
/*     */ 
/*     */   private float ProcessSample(float[] vcand, float cs, float[] pos, float rad, float[] vel, float[] dvel)
/*     */   {
/* 148 */     return ProcessSample(vcand, cs, pos, rad, vel, dvel, null);
/*     */   }
/*     */ 
/*     */   private float ProcessSample(float[] vcand, float cs, float[] pos, float rad, float[] vel, float[] dvel, ObstacleAvoidanceDebugData debug)
/*     */   {
/* 153 */     float tmin = this._params.horizTime;
/* 154 */     float side = 0.0F;
/* 155 */     int nside = 0;
/*     */ 
/* 157 */     for (int i = 0; i < this._nCircles; i++)
/*     */     {
/* 159 */       ObstacleCircle cir = this._circles[i];
/*     */ 
/* 161 */       float[] vab = Helper.VScale(vcand[0], vcand[1], vcand[2], 2.0F);
/* 162 */       vab = Helper.VSub(vab[0], vab[1], vab[2], vel[0], vel[1], vel[2]);
/*     */ 
/* 164 */       side += (float)Math.max(0.0D, Math.min(1.0D, Math.min(Helper.VDot2D(cir.dp, vab) * 0.5F + 0.5F, Helper.VDot2D(cir.np, vab) * 2.0F)));
/* 165 */       nside++;
/*     */ 
/* 167 */       Vector2 htMinMax = new Vector2();
/* 168 */       if (SweetCircleCircle(pos, rad, vab, cir.p, cir.rad, htMinMax) == 0)
/*     */       {
/*     */         continue;
/*     */       }
/* 172 */       float htmin = (float)htMinMax.x;
/* 173 */       float htmax = (float)htMinMax.y;
/*     */ 
/* 175 */       if ((htmin < 0.0F) && (htmax > 0.0F))
/*     */       {
/* 177 */         htmin = -htmin * 0.5F;
/*     */       }
/*     */ 
/* 180 */       if (htmin < 0.0F)
/*     */         continue;
/* 182 */       if (htmin < tmin) {
/* 183 */         tmin = htmin;
/*     */       }
/*     */     }
/*     */ 
/* 187 */     for (int i = 0; i < this._nSegments; i++)
/*     */     {
/* 189 */       ObstacleSegment seg = this._segments[i];
/* 190 */       float htmin = 0.0F;
/*     */ 
/* 192 */       if (seg.touch.booleanValue())
/*     */       {
/* 194 */         float[] sdir = Helper.VSub(seg.q[0], seg.q[1], seg.q[2], seg.p[0], seg.p[1], seg.p[2]);
/* 195 */         float[] snorm = new float[3];
/* 196 */         snorm[0] = (-sdir[2]);
/* 197 */         snorm[2] = sdir[0];
/*     */ 
/* 199 */         if (Helper.VDot2D(snorm, vcand) < 0.0F) {
/*     */           continue;
/*     */         }
/* 202 */         htmin = 0.0F;
/*     */       }
/*     */       else
/*     */       {
/* 206 */         Vector2 raySeg = isectRaySeg(pos, vcand, seg.p, seg.q);
/* 207 */         htmin = (float)raySeg.y;
/* 208 */         if (raySeg.x == 0.0D) {
/*     */           continue;
/*     */         }
/*     */       }
/* 212 */       htmin *= 2.0F;
/*     */ 
/* 214 */       if (htmin < tmin) {
/* 215 */         tmin = htmin;
/*     */       }
/*     */     }
/* 218 */     if (nside > 0) {
/* 219 */       side /= nside;
/*     */     }
/* 221 */     float vpen = this._params.weightDesVel * (Helper.VDist2D(vcand, dvel) * this._invVmax);
/* 222 */     float vcpen = this._params.weightCurVel * (Helper.VDist2D(vcand, vel) * this._invVmax);
/* 223 */     float spen = this._params.weightSide * side;
/* 224 */     float tpen = this._params.weightToi * (1.0F / (0.1F + tmin * this._invHorizTime));
/*     */ 
/* 226 */     float penalty = vpen + vcpen + spen + tpen;
/*     */ 
/* 228 */     if (debug != null) {
/* 229 */       debug.AddSample(vcand, cs, penalty, vpen, vcpen, spen, tpen);
/*     */     }
/* 231 */     return penalty;
/*     */   }
/*     */ 
/*     */   public void AddCircle(float[] pos, float rad, float[] vel, float[] dvel)
/*     */   {
/* 236 */     if (this._nCircles >= this._maxCircles) {
/* 237 */       return;
/*     */     }
/* 239 */     ObstacleCircle cir = this._circles[(this._nCircles++)];
/* 240 */     Helper.VCopy(cir.p, pos);
/* 241 */     cir.rad = rad;
/* 242 */     Helper.VCopy(cir.vel, vel);
/* 243 */     Helper.VCopy(cir.dvel, dvel);
/*     */   }
/*     */ 
/*     */   public void AddSegment(float[] p, float[] q)
/*     */   {
/* 248 */     if (this._nSegments >= this._maxSegments) {
/* 249 */       return;
/*     */     }
/* 251 */     ObstacleSegment seg = this._segments[(this._nSegments++)];
/* 252 */     Helper.VCopy(seg.p, p);
/* 253 */     Helper.VCopy(seg.q, q);
/*     */   }
/*     */ 
/*     */   public int SampleVelocityGrid(float[] pos, float rad, float vmax, float[] vel, float[] dvel, float[] nvel, ObstacleAvoidanceParams param)
/*     */   {
/* 258 */     return SampleVelocityGrid(pos, rad, vmax, vel, dvel, nvel, null);
/*     */   }
/*     */ 
/*     */   public int SampleVelocityGrid(float[] pos, float rad, float vmax, float[] vel, float[] dvel, float[] nvel, ObstacleAvoidanceParams param, ObstacleAvoidanceDebugData debug)
/*     */   {
/* 264 */     Prepare(pos, dvel);
/*     */ 
/* 266 */     this._params = new ObstacleAvoidanceParams(param);
/* 267 */     this._invHorizTime = (1.0F / this._params.horizTime);
/* 268 */     this._vmax = vmax;
/* 269 */     this._invVmax = (1.0F / vmax);
/*     */ 
/* 271 */     Helper.VSet(nvel, 0.0F, 0.0F, 0.0F);
/*     */ 
/* 273 */     if (debug != null) {
/* 274 */       debug.Reset();
/*     */     }
/* 276 */     float cvx = dvel[0] * this._params.velBias;
/* 277 */     float cvz = dvel[2] * this._params.velBias;
/* 278 */     float cs = vmax * 2.0F * (1.0F - this._params.velBias) / (this._params.gridSize - 1);
/* 279 */     float half = (this._params.gridSize - 1) * cs * 0.5F;
/*     */ 
/* 281 */     float minPenalty = 3.4028235E+38F;
/* 282 */     int ns = 0;
/*     */ 
/* 284 */     for (int y = 0; y < this._params.gridSize; y++)
/*     */     {
/* 286 */       for (int x = 0; x < this._params.gridSize; x++)
/*     */       {
/* 288 */         float[] vcand = new float[3];
/* 289 */         vcand[0] = (cvx + x * cs - half);
/* 290 */         vcand[1] = 0.0F;
/* 291 */         vcand[2] = (cvz + y * cs - half);
/*     */ 
/* 293 */         if (vcand[0] * vcand[0] + vcand[2] * vcand[2] > (vmax + cs / 2.0F) * (vmax + cs / 2.0F))
/*     */           continue;
/* 295 */         float penalty = ProcessSample(vcand, cs, pos, rad, vel, dvel, debug);
/* 296 */         ns++;
/* 297 */         if (penalty >= minPenalty)
/*     */           continue;
/* 299 */         minPenalty = penalty;
/* 300 */         Helper.VCopy(nvel, vcand);
/*     */       }
/*     */     }
/*     */ 
/* 304 */     return ns;
/*     */   }
/*     */ 
/*     */   public int SampleVelocityAdaptive(float[] pos, float rad, float vmax, float[] vel, float[] dvel, float[] nvel, ObstacleAvoidanceParams param)
/*     */   {
/* 309 */     return SampleVelocityAdaptive(pos, rad, vmax, vel, dvel, nvel, param, null);
/*     */   }
/*     */ 
/*     */   public int SampleVelocityAdaptive(float[] pos, float rad, float vmax, float[] vel, float[] dvel, float[] nvel, ObstacleAvoidanceParams param, ObstacleAvoidanceDebugData debug)
/*     */   {
/* 316 */     Prepare(pos, dvel);
/*     */ 
/* 318 */     this._params = new ObstacleAvoidanceParams(param);
/* 319 */     this._invHorizTime = (1.0F / this._params.horizTime);
/* 320 */     this._vmax = vmax;
/* 321 */     this._invVmax = (1.0F / vmax);
/*     */ 
/* 323 */     Helper.VSet(nvel, 0.0F, 0.0F, 0.0F);
/*     */ 
/* 325 */     if (debug != null) {
/* 326 */       debug.Reset();
/*     */     }
/* 328 */     float[] pat = new float[258];
/* 329 */     int npat = 0;
/*     */ 
/* 331 */     int ndivs = this._params.adaptiveDivs;
/* 332 */     int nrings = this._params.adaptiveRings;
/* 333 */     int depth = this._params.adaptiveDepth;
/*     */ 
/* 335 */     int nd = Math.max(1, Math.min(32, ndivs));
/* 336 */     int nr = Math.max(1, Math.min(4, nrings));
/* 337 */     float da = 1.0F / nd * 3.141593F * 2.0F;
/* 338 */     float dang = (float)Math.atan2(dvel[2], dvel[0]);
/*     */ 
/* 340 */     pat[(npat * 2 + 0)] = 0.0F;
/* 341 */     pat[(npat * 2 + 1)] = 0.0F;
/* 342 */     npat++;
/*     */ 
/* 344 */     for (int j = 0; j < nr; j++)
/*     */     {
/* 346 */       float r = (nr - j) / nr;
/* 347 */       float a = dang + (j & 0x1) * 0.5F * da;
/* 348 */       for (int i = 0; i < nd; i++)
/*     */       {
/* 350 */         pat[(npat * 2 + 0)] = ((float)Math.cos(a) * r);
/* 351 */         pat[(npat * 2 + 1)] = ((float)Math.sin(a) * r);
/* 352 */         npat++;
/* 353 */         a += da;
/*     */       }
/*     */     }
/*     */ 
/* 357 */     float cr = vmax * (1.0F - this._params.velBias);
/* 358 */     float[] res = new float[3];
/* 359 */     Helper.VSet(res, dvel[0] * this._params.velBias, 0.0F, dvel[2] * this._params.velBias);
/* 360 */     int ns = 0;
/*     */ 
/* 362 */     for (int k = 0; k < depth; k++)
/*     */     {
/* 364 */       float minPenalty = 3.4028235E+38F;
/* 365 */       float[] bvel = new float[3];
/* 366 */       Helper.VSet(bvel, 0.0F, 0.0F, 0.0F);
/*     */ 
/* 368 */       for (int i = 0; i < npat; i++)
/*     */       {
/* 370 */         float[] vcand = { res[0] + pat[(i * 2 + 0)] * cr, 0.0F, res[2] + pat[(i * 2 + 1)] * cr };
/*     */ 
/* 372 */         if (vcand[0] * vcand[0] + vcand[2] * vcand[2] > (vmax + 0.001F) * (vmax + 0.001F))
/*     */           continue;
/* 374 */         float penalty = ProcessSample(vcand, cr / 10.0F, pos, rad, vel, dvel, debug);
/* 375 */         ns++;
/* 376 */         if (penalty >= minPenalty)
/*     */           continue;
/* 378 */         minPenalty = penalty;
/* 379 */         Helper.VCopy(bvel, vcand);
/*     */       }
/*     */ 
/* 382 */       Helper.VCopy(res, bvel);
/*     */ 
/* 384 */       cr *= 0.5F;
/*     */     }
/*     */ 
/* 387 */     Helper.VCopy(nvel, res);
/*     */ 
/* 389 */     return ns;
/*     */   }
/*     */ 
/*     */   public int ObstacleCircleCount()
/*     */   {
/* 394 */     return this._nCircles;
/*     */   }
/*     */ 
/*     */   public ObstacleCircle GetObstacleCircle(int i)
/*     */   {
/* 399 */     return this._circles[i];
/*     */   }
/*     */ 
/*     */   public int ObstacleSegmentCount()
/*     */   {
/* 404 */     return this._nSegments;
/*     */   }
/*     */ 
/*     */   public ObstacleSegment GetObstacleSegment(int i)
/*     */   {
/* 409 */     return this._segments[i];
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.ObstacleAvoidanceQuery
 * JD-Core Version:    0.6.0
 */