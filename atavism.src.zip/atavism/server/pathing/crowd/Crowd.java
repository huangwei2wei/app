/*      */ package atavism.server.pathing.crowd;
/*      */ 
/*      */ import atavism.server.pathing.detour.DetourNumericReturn;
/*      */ import atavism.server.pathing.detour.DetourStatusReturn;
/*      */ import atavism.server.pathing.detour.NavMesh;
/*      */ import atavism.server.pathing.detour.NavMeshQuery;
/*      */ import atavism.server.pathing.detour.QueryFilter;
/*      */ import atavism.server.pathing.detour.Status;
/*      */ import atavism.server.pathing.recast.Helper;
/*      */ import atavism.server.util.Log;
/*      */ import java.util.EnumSet;
/*      */ 
/*      */ public class Crowd
/*      */ {
/*   15 */   public static int CrowdMaxObstAvoidanceParams = 8;
/*      */   private int _maxAgents;
/*      */   private CrowdAgent[] _agents;
/*      */   private CrowdAgent[] _activeAgents;
/*      */   private CrowdAgentAnimation[] _agentAnims;
/*      */   private PathQueue _pathq;
/*   23 */   private ObstacleAvoidanceParams[] _obstacleQueryParams = new ObstacleAvoidanceParams[CrowdMaxObstAvoidanceParams];
/*      */   private ObstacleAvoidanceQuery _obstacleQuery;
/*      */   private ProximityGrid _grid;
/*      */   private long[] _pathResult;
/*      */   private int _maxPathResult;
/*   30 */   private float[] _ext = new float[3];
/*      */   private QueryFilter _filter;
/*      */   private float _maxAgentRadius;
/*      */   private int _velocitySampleCount;
/*      */   private NavMeshQuery _navQuery;
/*   37 */   public static int MaxPathQueueNodes = 4096;
/*   38 */   public static int MaxCommonNodes = 512;
/*   39 */   public static int MaxItersPerUpdate = 100;
/*      */ 
/*      */   public Crowd() {
/*   42 */     this._maxAgents = 0;
/*   43 */     this._agents = null;
/*   44 */     this._activeAgents = null;
/*   45 */     this._agentAnims = null;
/*   46 */     this._obstacleQuery = null;
/*   47 */     this._grid = null;
/*   48 */     this._pathResult = null;
/*   49 */     this._maxPathResult = 0;
/*   50 */     this._maxAgentRadius = 0.0F;
/*   51 */     this._velocitySampleCount = 0;
/*   52 */     this._navQuery = null;
/*   53 */     this._filter = new QueryFilter();
/*      */   }
/*      */ 
/*      */   private void UpdateMoveRequest(float dt)
/*      */   {
/*   58 */     int PathMaxAgents = 8;
/*   59 */     CrowdAgent[] queue = new CrowdAgent[PathMaxAgents];
/*   60 */     int nqueue = 0;
/*   61 */     EnumSet status = null;
/*      */ 
/*   63 */     for (int i = 0; i < this._maxAgents; i++)
/*      */     {
/*   65 */       CrowdAgent ag = this._agents[i];
/*   66 */       if ((!ag.Active.booleanValue()) || 
/*   67 */         (ag.State == CrowdAgentState.Invalid) || 
/*   68 */         (ag.TargetState == MoveRequestState.TargetNone) || (ag.TargetState == MoveRequestState.TargetVelocity)) {
/*      */         continue;
/*      */       }
/*   71 */       if (ag.TargetState == MoveRequestState.TargetRequesting)
/*      */       {
/*   73 */         long[] path = ag.Corridor.GetPath();
/*   74 */         int npath = ag.Corridor.PathCount();
/*      */ 
/*   76 */         int MaxRes = 32;
/*   77 */         float[] reqPos = new float[3];
/*   78 */         long[] reqPath = new long[MaxRes];
/*   79 */         int reqPathCount = 0;
/*      */ 
/*   81 */         int MaxIter = 20;
/*   82 */         this._navQuery.InitSlicedFindPath(path[0], ag.TargetRef, ag.npos, ag.TargetPos, this._filter);
/*   83 */         int doneIters = 0;
/*   84 */         this._navQuery.UpdateSlicedFindPath(MaxIter);
/*   85 */         if (ag.TargetReplan.booleanValue()) {
/*   86 */           DetourStatusReturn statusReturn = this._navQuery.FinalizeSlicedFindPathPartial(path, npath, reqPath, MaxRes);
/*   87 */           status = statusReturn.status;
/*   88 */           reqPathCount = statusReturn.intValue;
/*      */         }
/*      */         else {
/*   91 */           DetourStatusReturn statusReturn = this._navQuery.FinalizeSlicedFindPath(reqPath, MaxRes);
/*   92 */           status = statusReturn.status;
/*   93 */           reqPathCount = statusReturn.intValue;
/*      */         }
/*      */ 
/*   97 */         if ((!status.contains(Status.Failure)) && (reqPathCount > 0))
/*      */         {
/*   99 */           if (reqPath[(reqPathCount - 1)] != ag.TargetRef)
/*      */           {
/*  101 */             status = this._navQuery.ClosestPointOnPoly(reqPath[(reqPathCount - 1)], ag.TargetPos, reqPos);
/*  102 */             if (status.contains(Status.Failure))
/*  103 */               reqPathCount = 0;
/*      */           }
/*      */           else
/*      */           {
/*  107 */             Helper.VCopy(reqPos, ag.TargetPos);
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  113 */           reqPathCount = 0;
/*      */         }
/*      */ 
/*  116 */         if (reqPathCount <= 0)
/*      */         {
/*  118 */           Helper.VCopy(reqPos, ag.npos);
/*  119 */           reqPos[0] = (float)path[0];
/*  120 */           reqPathCount = 1;
/*      */         }
/*      */ 
/*  124 */         ag.Corridor.SetCorridor(reqPos, reqPath, reqPathCount);
/*  125 */         ag.Boundary.Reset();
/*      */ 
/*  127 */         if (reqPath[(reqPathCount - 1)] == ag.TargetRef)
/*      */         {
/*  129 */           ag.TargetState = MoveRequestState.TargetValid;
/*  130 */           ag.TargetReplanTime = 0.0F;
/*      */         }
/*      */         else
/*      */         {
/*  134 */           ag.TargetState = MoveRequestState.TargetWaitingForQueue;
/*      */         }
/*      */       }
/*      */ 
/*  138 */       if (ag.TargetState != MoveRequestState.TargetWaitingForQueue)
/*      */         continue;
/*  140 */       nqueue = AddToPlanQueue(ag, queue, nqueue, PathMaxAgents);
/*      */     }
/*      */ 
/*  143 */     for (int i = 0; i < nqueue; i++)
/*      */     {
/*  145 */       CrowdAgent ag = queue[i];
/*  146 */       ag.TargetPathQRef = this._pathq.Request(ag.Corridor.LastPoly(), ag.TargetRef, ag.Corridor.Target(), ag.TargetPos, this._filter);
/*  147 */       if (ag.TargetPathQRef != 0L) {
/*  148 */         ag.TargetState = MoveRequestState.TargetWaitingForPath;
/*      */       }
/*      */     }
/*  151 */     this._pathq.Update(MaxItersPerUpdate);
/*      */ 
/*  153 */     for (int i = 0; i < this._maxAgents; i++)
/*      */     {
/*  155 */       CrowdAgent ag = this._agents[i];
/*  156 */       if ((!ag.Active.booleanValue()) || 
/*  157 */         (ag.TargetState == MoveRequestState.TargetNone) || (ag.TargetState == MoveRequestState.TargetVelocity)) {
/*      */         continue;
/*      */       }
/*  160 */       if (ag.TargetState != MoveRequestState.TargetWaitingForPath)
/*      */         continue;
/*  162 */       status = this._pathq.GetRequestStatus(ag.TargetPathQRef);
/*  163 */       if (status.contains(Status.Failure))
/*      */       {
/*  165 */         ag.TargetPathQRef = 0L;
/*  166 */         if (ag.TargetRef > 0L)
/*  167 */           ag.TargetState = MoveRequestState.TargetRequesting;
/*      */         else {
/*  169 */           ag.TargetState = MoveRequestState.TargetFailed;
/*      */         }
/*  171 */         ag.TargetReplanTime = 0.0F;
/*      */       } else {
/*  173 */         if (!status.contains(Status.Success))
/*      */           continue;
/*  175 */         long[] path = ag.Corridor.GetPath();
/*  176 */         int npath = ag.Corridor.PathCount();
/*      */ 
/*  178 */         float[] targetPos = new float[3];
/*  179 */         Helper.VCopy(targetPos, ag.TargetPos);
/*      */ 
/*  181 */         long[] res = this._pathResult;
/*  182 */         Boolean valid = Boolean.valueOf(true);
/*  183 */         int nres = 0;
/*  184 */         DetourStatusReturn statusReturn = this._pathq.GetPathResult(ag.TargetPathQRef, res, nres, this._maxPathResult);
/*  185 */         nres = statusReturn.intValue;
/*  186 */         status = statusReturn.status;
/*  187 */         if ((status.contains(Status.Failure)) || (nres <= 0)) {
/*  188 */           valid = Boolean.valueOf(false);
/*      */         }
/*  190 */         if (valid.booleanValue())
/*      */         {
/*  192 */           if (npath > 1)
/*      */           {
/*  194 */             if (npath - 1 + nres > this._maxPathResult) {
/*  195 */               nres = this._maxPathResult - (npath - 1);
/*      */             }
/*  197 */             System.arraycopy(res, 0, res, npath - 1, nres);
/*  198 */             System.arraycopy(path, 0, res, 0, npath - 1);
/*  199 */             nres += npath - 1;
/*      */ 
/*  201 */             for (int j = 0; j < nres; j++)
/*      */             {
/*  203 */               if ((j - 1 < 0) || (j + 1 >= nres))
/*      */                 continue;
/*  205 */               if (res[(j - 1)] != res[(j + 1)])
/*      */                 continue;
/*  207 */               System.arraycopy(res, j + 1, res, j - 1, nres - (j + 1));
/*  208 */               nres -= 2;
/*  209 */               j -= 2;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  215 */           if (res[(nres - 1)] != ag.TargetRef)
/*      */           {
/*  217 */             float[] nearest = new float[3];
/*      */ 
/*  219 */             status = this._navQuery.ClosestPointOnPoly(res[(nres - 1)], targetPos, nearest);
/*  220 */             if (status.contains(Status.Success))
/*  221 */               Helper.VCopy(targetPos, nearest);
/*      */             else {
/*  223 */               valid = Boolean.valueOf(false);
/*      */             }
/*      */           }
/*      */         }
/*  227 */         if (valid.booleanValue())
/*      */         {
/*  229 */           ag.Corridor.SetCorridor(targetPos, res, nres);
/*  230 */           ag.Boundary.Reset();
/*  231 */           ag.TargetState = MoveRequestState.TargetValid;
/*      */         }
/*      */         else
/*      */         {
/*  235 */           ag.TargetState = MoveRequestState.TargetFailed;
/*      */         }
/*      */ 
/*  238 */         ag.TargetReplanTime = 0.0F;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void UpdateTopologyOptimization(CrowdAgent[] agents, int nagents, float dt)
/*      */   {
/*  246 */     if (nagents <= 0) {
/*  247 */       return;
/*      */     }
/*  249 */     float OptTimeThr = 0.5F;
/*  250 */     int OptMaxAgents = 1;
/*  251 */     CrowdAgent[] queue = new CrowdAgent[OptMaxAgents];
/*  252 */     queue[0] = new CrowdAgent();
/*  253 */     int nqueue = 0;
/*      */ 
/*  255 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  257 */       CrowdAgent ag = agents[i];
/*  258 */       if ((ag.State != CrowdAgentState.Walking) || 
/*  259 */         (ag.TargetState == MoveRequestState.TargetNone) || (ag.TargetState == MoveRequestState.TargetVelocity) || 
/*  260 */         ((ag.Param.UpdateFlags.getValue() & UpdateFlags.OptimizeTopology.getValue()) == 0)) continue;
/*  261 */       ag.TopologyOptTime += dt;
/*  262 */       if (ag.TopologyOptTime >= OptTimeThr) {
/*  263 */         nqueue = AddToOptQueue(ag, queue, nqueue, OptMaxAgents);
/*      */       }
/*      */     }
/*  266 */     for (int i = 0; i < nqueue; i++)
/*      */     {
/*  268 */       CrowdAgent ag = queue[i];
/*  269 */       ag.Corridor.OptimizePathTopology(this._navQuery, this._filter);
/*  270 */       ag.TopologyOptTime = 0.0F;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void CheckPathValitidy(CrowdAgent[] agents, int nagents, float dt)
/*      */   {
/*  276 */     int CheckLookAhead = 10;
/*  277 */     float TargetReplanDelay = 1.0F;
/*      */ 
/*  279 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  281 */       CrowdAgent ag = agents[i];
/*      */ 
/*  283 */       if ((ag.State != CrowdAgentState.Walking) || 
/*  284 */         (ag.TargetState == MoveRequestState.TargetNone) || (ag.TargetState == MoveRequestState.TargetVelocity))
/*      */         continue;
/*  286 */       ag.TargetReplanTime += dt;
/*  287 */       Boolean replan = Boolean.valueOf(false);
/*      */ 
/*  289 */       int idx = AgentIndex(ag);
/*  290 */       float[] agentPos = new float[3];
/*  291 */       long agentRef = ag.Corridor.FirstPoly();
/*  292 */       Helper.VCopy(agentPos, ag.npos);
/*  293 */       if (!this._navQuery.IsValidPolyRef(agentRef, this._filter).booleanValue())
/*      */       {
/*  295 */         float[] nearest = new float[3];
/*  296 */         agentRef = 0L;
/*  297 */         agentRef = this._navQuery.FindNearestPoly(ag.npos, this._ext, this._filter, nearest).longValue;
/*  298 */         Helper.VCopy(agentPos, nearest);
/*      */ 
/*  300 */         if (agentRef <= 0L)
/*      */         {
/*  302 */           ag.Corridor.Reset(0L, agentPos);
/*  303 */           ag.Boundary.Reset();
/*  304 */           ag.State = CrowdAgentState.Invalid;
/*      */         }
/*      */         else
/*      */         {
/*  308 */           ag.Corridor.FixPathStart(agentRef, agentPos);
/*  309 */           ag.Boundary.Reset();
/*  310 */           Helper.VCopy(ag.npos, agentPos);
/*      */ 
/*  312 */           replan = Boolean.valueOf(true);
/*      */         }
/*      */       } else {
/*  315 */         if ((ag.TargetState != MoveRequestState.TargetNone) && (ag.TargetState != MoveRequestState.TargetFailed))
/*      */         {
/*  317 */           if (!this._navQuery.IsValidPolyRef(ag.TargetRef, this._filter).booleanValue())
/*      */           {
/*  319 */             float[] nearest = new float[3];
/*  320 */             ag.TargetRef = this._navQuery.FindNearestPoly(ag.TargetPos, this._ext, this._filter, nearest).longValue;
/*  321 */             Helper.VCopy(ag.TargetPos, nearest);
/*  322 */             replan = Boolean.valueOf(true);
/*      */           }
/*  324 */           if (ag.TargetRef <= 0L)
/*      */           {
/*  326 */             ag.Corridor.Reset(agentRef, agentPos);
/*  327 */             ag.TargetState = MoveRequestState.TargetNone;
/*      */           }
/*      */         }
/*      */ 
/*  331 */         if (!ag.Corridor.IsValid(CheckLookAhead, this._navQuery, this._filter).booleanValue()) {
/*  332 */           replan = Boolean.valueOf(true);
/*      */         }
/*  334 */         if (ag.TargetState == MoveRequestState.TargetValid)
/*      */         {
/*  336 */           if ((ag.TargetReplanTime > TargetReplanDelay) && (ag.Corridor.PathCount() < CheckLookAhead) && (ag.Corridor.LastPoly() != ag.TargetRef))
/*      */           {
/*  338 */             replan = Boolean.valueOf(true);
/*      */           }
/*      */         }
/*  341 */         if (!replan.booleanValue())
/*      */           continue;
/*  343 */         if (ag.TargetState == MoveRequestState.TargetNone)
/*      */           continue;
/*  345 */         RequestMoveTargetReplan(idx, ag.TargetRef, ag.TargetPos);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private int AgentIndex(CrowdAgent agent)
/*      */   {
/*  353 */     for (int i = 0; i < this._agents.length; i++)
/*      */     {
/*  355 */       if (this._agents[i] == agent)
/*  356 */         return i;
/*      */     }
/*  358 */     return -1;
/*      */   }
/*      */ 
/*      */   private Boolean RequestMoveTargetReplan(int idx, long refId, float[] pos)
/*      */   {
/*  363 */     if ((idx < 0) || (idx > this._maxAgents)) {
/*  364 */       return Boolean.valueOf(false);
/*      */     }
/*  366 */     CrowdAgent ag = this._agents[idx];
/*  367 */     ag.TargetRef = refId;
/*  368 */     Helper.VCopy(ag.TargetPos, pos);
/*  369 */     ag.TargetPathQRef = 0L;
/*  370 */     ag.TargetReplan = Boolean.valueOf(true);
/*  371 */     if (ag.TargetRef > 0L) {
/*  372 */       ag.TargetState = MoveRequestState.TargetRequesting;
/*      */     }
/*      */     else {
/*  375 */       ag.TargetState = MoveRequestState.TargetFailed;
/*      */     }
/*      */ 
/*  378 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   private void Purge()
/*      */   {
/*  383 */     this._agents = null;
/*  384 */     this._maxAgents = 0;
/*  385 */     this._activeAgents = null;
/*  386 */     this._agentAnims = null;
/*  387 */     this._pathResult = null;
/*  388 */     this._grid = null;
/*  389 */     this._obstacleQuery = null;
/*  390 */     this._navQuery = null;
/*      */   }
/*      */ 
/*      */   public Boolean Init(int maxAgents, float maxAgentRadius, NavMesh nav)
/*      */   {
/*  395 */     Purge();
/*  396 */     this._maxAgents = maxAgents;
/*  397 */     this._maxAgentRadius = maxAgentRadius;
/*      */ 
/*  399 */     Helper.VSet(this._ext, this._maxAgentRadius * 2.0F, this._maxAgentRadius * 1.5F, this._maxAgentRadius * 2.0F);
/*      */ 
/*  401 */     this._grid = new ProximityGrid();
/*  402 */     this._grid.Init(this._maxAgents * 4, maxAgentRadius * 3.0F);
/*      */ 
/*  404 */     this._obstacleQuery = new ObstacleAvoidanceQuery();
/*  405 */     this._obstacleQuery.Init(6, 8);
/*      */ 
/*  407 */     for (int i = 0; i < this._obstacleQueryParams.length; i++)
/*      */     {
/*  409 */       this._obstacleQueryParams[i] = new ObstacleAvoidanceParams(0.4F, 2.0F, 0.75F, 0.75F, 2.5F, 2.5F, 33, 7, 2, 5);
/*      */     }
/*      */ 
/*  413 */     this._maxPathResult = 256;
/*  414 */     this._pathResult = new long[this._maxPathResult];
/*      */ 
/*  416 */     this._pathq = new PathQueue();
/*  417 */     this._pathq.Init(this._maxPathResult, MaxPathQueueNodes, nav);
/*      */ 
/*  419 */     this._agents = new CrowdAgent[this._maxAgents];
/*  420 */     this._activeAgents = new CrowdAgent[this._maxAgents];
/*  421 */     this._agentAnims = new CrowdAgentAnimation[this._maxAgents];
/*      */ 
/*  423 */     for (int i = 0; i < this._maxAgents; i++)
/*      */     {
/*  425 */       this._agents[i] = new CrowdAgent();
/*  426 */       this._agents[i].Active = Boolean.valueOf(false);
/*  427 */       this._agents[i].Corridor.Init(this._maxPathResult);
/*      */     }
/*      */ 
/*  430 */     for (int i = 0; i < this._maxAgents; i++)
/*      */     {
/*  432 */       this._agentAnims[i] = new CrowdAgentAnimation();
/*  433 */       this._agentAnims[i].Active = Boolean.valueOf(false);
/*      */     }
/*      */ 
/*  436 */     this._navQuery = new NavMeshQuery();
/*  437 */     this._navQuery.Init(nav, MaxCommonNodes);
/*      */ 
/*  439 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   public void SetObstacleAvoidanceParams(int idx, ObstacleAvoidanceParams param)
/*      */   {
/*  444 */     if ((idx >= 0) && (idx < CrowdMaxObstAvoidanceParams))
/*  445 */       this._obstacleQueryParams[idx] = param;
/*      */   }
/*      */ 
/*      */   public ObstacleAvoidanceParams GetObstacleAvoidanceParams(int idx)
/*      */   {
/*  450 */     if ((idx >= 0) && (idx < CrowdMaxObstAvoidanceParams)) {
/*  451 */       return this._obstacleQueryParams[idx];
/*      */     }
/*  453 */     return null;
/*      */   }
/*      */ 
/*      */   public CrowdAgent GetAgent(int idx)
/*      */   {
/*  458 */     return this._agents[idx];
/*      */   }
/*      */ 
/*      */   public int AgentCount()
/*      */   {
/*  463 */     return this._maxAgents;
/*      */   }
/*      */ 
/*      */   public int AddAgent(float[] pos, CrowdAgentParams param)
/*      */   {
/*  468 */     int idx = -1;
/*  469 */     for (int i = 0; i < this._maxAgents; i++)
/*      */     {
/*  471 */       if (this._agents[i].Active.booleanValue())
/*      */         continue;
/*  473 */       idx = i;
/*  474 */       break;
/*      */     }
/*      */ 
/*  477 */     if (idx == -1) {
/*  478 */       return -1;
/*      */     }
/*  480 */     CrowdAgent ag = this._agents[idx];
/*      */ 
/*  482 */     float[] nearest = new float[3];
/*  483 */     long refId = this._navQuery.FindNearestPoly(pos, this._ext, this._filter, nearest).longValue;
/*  484 */     Log.debug("DETOUR: added agent to refId: " + refId);
/*      */ 
/*  486 */     ag.Corridor.Reset(refId, nearest);
/*  487 */     ag.Boundary.Reset();
/*      */ 
/*  489 */     UpdateAgentParameters(idx, param);
/*      */ 
/*  491 */     ag.TopologyOptTime = 0.0F;
/*  492 */     ag.TargetReplanTime = 0.0F;
/*  493 */     ag.NNeis = 0;
/*      */ 
/*  495 */     Helper.VSet(ag.dvel, 0.0F, 0.0F, 0.0F);
/*  496 */     Helper.VSet(ag.nvel, 0.0F, 0.0F, 0.0F);
/*  497 */     Helper.VSet(ag.vel, 0.0F, 0.0F, 0.0F);
/*  498 */     Helper.VCopy(ag.npos, nearest);
/*      */ 
/*  500 */     ag.DesiredSpeed = 0.0F;
/*      */ 
/*  502 */     if (refId > 0L) {
/*  503 */       ag.State = CrowdAgentState.Walking;
/*      */     }
/*      */     else {
/*  506 */       ag.State = CrowdAgentState.Invalid;
/*      */     }
/*      */ 
/*  509 */     ag.TargetState = MoveRequestState.TargetNone;
/*      */ 
/*  511 */     ag.Active = Boolean.valueOf(true);
/*      */ 
/*  513 */     return idx;
/*      */   }
/*      */ 
/*      */   public void UpdateAgentParameters(int idx, CrowdAgentParams param)
/*      */   {
/*  518 */     if ((idx < 0) || (idx > this._maxAgents)) {
/*  519 */       return;
/*      */     }
/*  521 */     this._agents[idx].Param = param;
/*      */   }
/*      */ 
/*      */   public void RemoveAgent(int idx)
/*      */   {
/*  526 */     if ((idx >= 0) || (idx < this._maxAgents))
/*  527 */       this._agents[idx].Active = Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Boolean RequestMoveTarget(int idx, long refId, float[] pos)
/*      */   {
/*  532 */     if ((idx < 0) || (idx > this._maxAgents))
/*  533 */       return Boolean.valueOf(false);
/*  534 */     if (refId <= 0L) {
/*  535 */       return Boolean.valueOf(false);
/*      */     }
/*  537 */     CrowdAgent ag = this._agents[idx];
/*  538 */     ag.TargetRef = refId;
/*  539 */     Helper.VCopy(ag.TargetPos, pos);
/*  540 */     ag.TargetPathQRef = 0L;
/*  541 */     ag.TargetReplan = Boolean.valueOf(false);
/*  542 */     if (ag.TargetRef > 0L)
/*  543 */       ag.TargetState = MoveRequestState.TargetRequesting;
/*      */     else
/*  545 */       ag.TargetState = MoveRequestState.TargetFailed;
/*  546 */     Log.debug("DETOUR: set target to pos: " + pos[0] + "," + pos[1] + "," + pos[2] + " with currentPos: " + ag.npos[0] + "," + ag.npos[1] + "," + ag.npos[2] + " and EndRef: " + refId);
/*      */ 
/*  548 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   public Boolean RequestMoveVelocity(int idx, float[] vel)
/*      */   {
/*  553 */     if ((idx < 0) || (idx > this._maxAgents)) {
/*  554 */       return Boolean.valueOf(false);
/*      */     }
/*  556 */     CrowdAgent ag = this._agents[idx];
/*      */ 
/*  558 */     ag.TargetRef = 0L;
/*  559 */     Helper.VCopy(ag.TargetPos, vel);
/*  560 */     ag.TargetPathQRef = 0L;
/*  561 */     ag.TargetReplan = Boolean.valueOf(false);
/*  562 */     ag.TargetState = MoveRequestState.TargetVelocity;
/*      */ 
/*  564 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   public Boolean ResetMoveTarget(int idx)
/*      */   {
/*  569 */     if ((idx < 0) || (idx > this._maxAgents)) {
/*  570 */       return Boolean.valueOf(false);
/*      */     }
/*  572 */     CrowdAgent ag = this._agents[idx];
/*      */ 
/*  574 */     ag.TargetRef = 0L;
/*  575 */     Helper.VSet(ag.TargetPos, 0.0F, 0.0F, 0.0F);
/*  576 */     ag.TargetPathQRef = 0L;
/*  577 */     ag.TargetReplan = Boolean.valueOf(false);
/*  578 */     ag.TargetState = MoveRequestState.TargetNone;
/*      */ 
/*  580 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   public int GetActiveAgents(CrowdAgent[] agents, int maxAgents)
/*      */   {
/*  585 */     int n = 0;
/*  586 */     for (int i = 0; i < this._maxAgents; i++)
/*      */     {
/*  588 */       if ((!this._agents[i].Active.booleanValue()) || 
/*  589 */         (n >= maxAgents)) continue;
/*  590 */       agents[(n++)] = this._agents[i];
/*      */     }
/*  592 */     return n;
/*      */   }
/*      */ 
/*      */   public CrowdAgentDebugInfo Update(float dt, CrowdAgentDebugInfo debug)
/*      */   {
/*  597 */     Log.debug("CROWD: starting update with time: " + dt);
/*  598 */     this._velocitySampleCount = 0;
/*  599 */     int debugIdx = debug != null ? debug.Idx : -1;
/*      */ 
/*  601 */     CrowdAgent[] agents = this._activeAgents;
/*  602 */     int nagents = GetActiveAgents(agents, this._maxAgents);
/*      */ 
/*  604 */     CheckPathValitidy(agents, nagents, dt);
/*      */ 
/*  606 */     UpdateMoveRequest(dt);
/*      */ 
/*  608 */     UpdateTopologyOptimization(agents, nagents, dt);
/*      */ 
/*  610 */     this._grid.Clear();
/*  611 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  614 */       CrowdAgent ag = agents[i];
/*  615 */       float[] p = ag.npos;
/*  616 */       float r = ag.Param.Radius;
/*  617 */       this._grid.AddItem(i, p[0] - r, p[2] - r, p[0] + r, p[2] + r);
/*      */     }
/*      */ 
/*  622 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  625 */       CrowdAgent ag = agents[i];
/*  626 */       if (ag.State != CrowdAgentState.Walking)
/*      */         continue;
/*  628 */       float updateThr = ag.Param.CollisionQueryRange * 0.25F;
/*      */ 
/*  630 */       float dist = Helper.VDist2DSqr(ag.npos[0], ag.npos[1], ag.npos[2], ag.Boundary.getCenter()[0], ag.Boundary.getCenter()[1], ag.Boundary.getCenter()[2]);
/*      */ 
/*  632 */       if ((dist > updateThr * updateThr) || (!ag.Boundary.IsValid(this._navQuery, this._filter).booleanValue()))
/*      */       {
/*  635 */         ag.Boundary.Update(ag.Corridor.FirstPoly(), ag.npos, ag.Param.CollisionQueryRange, this._navQuery, this._filter);
/*      */       }
/*      */ 
/*  640 */       ag.NNeis = GetNeighbors(ag.npos, ag.Param.Height, ag.Param.CollisionQueryRange, ag, ag.Neis, CrowdAgent.CrowdAgentMaxNeighbors, agents, nagents, this._grid);
/*      */ 
/*  644 */       for (int j = 0; j < ag.NNeis; j++)
/*      */       {
/*  646 */         ag.Neis[j].Idx = AgentIndex(agents[ag.Neis[j].Idx]);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  652 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  654 */       CrowdAgent ag = agents[i];
/*      */ 
/*  656 */       if ((ag.State != CrowdAgentState.Walking) || 
/*  657 */         (ag.TargetState == MoveRequestState.TargetNone) || (ag.TargetState == MoveRequestState.TargetVelocity)) {
/*      */         continue;
/*      */       }
/*  660 */       ag.NCorners = ag.Corridor.FindCorners(ag.CornerVerts, ag.CornerFlags, ag.CornerPolys, CrowdAgent.CrowdAgentMaxCorners, this._navQuery, this._filter);
/*      */ 
/*  664 */       if (((ag.Param.UpdateFlags.getValue() & UpdateFlags.OptimizeVisibility.getValue()) != 0) && (ag.NCorners > 0))
/*      */       {
/*  666 */         float[] target = new float[3];
/*  667 */         System.arraycopy(ag.CornerVerts, Math.min(1, ag.NCorners - 1) * 3, target, 0, 3);
/*  668 */         ag.Corridor.OptimizePathVisibility(target, ag.Param.PathOptimizationRange, this._navQuery, this._filter);
/*  669 */         if (debugIdx == i)
/*      */         {
/*  671 */           Helper.VCopy(debug.OptStart, ag.Corridor.Pos());
/*  672 */           Helper.VCopy(debug.OptEnd, target);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  677 */         if (debugIdx != i)
/*      */           continue;
/*  679 */         Helper.VSet(debug.OptStart, 0.0F, 0.0F, 0.0F);
/*  680 */         Helper.VSet(debug.OptEnd, 0.0F, 0.0F, 0.0F);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  687 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  690 */       CrowdAgent ag = agents[i];
/*      */ 
/*  692 */       if ((ag.State != CrowdAgentState.Walking) || 
/*  693 */         (ag.TargetState == MoveRequestState.TargetNone) || (ag.TargetState == MoveRequestState.TargetVelocity)) {
/*      */         continue;
/*      */       }
/*  696 */       float triggerRadius = ag.Param.Radius * 2.25F;
/*  697 */       if (!ag.OverOffMeshConnection(triggerRadius).booleanValue())
/*      */         continue;
/*  699 */       int idx = AgentIndex(ag);
/*  700 */       CrowdAgentAnimation anim = this._agentAnims[idx];
/*      */ 
/*  702 */       long[] refs = new long[2];
/*  703 */       if (!ag.Corridor.MoveOverOffmeshConnection(ag.CornerPolys[(ag.NCorners - 1)], refs, anim.StartPos, anim.EndPos, this._navQuery).booleanValue())
/*      */         continue;
/*  705 */       Helper.VCopy(anim.InitPos, ag.npos);
/*  706 */       anim.PolyRef = refs[1];
/*  707 */       anim.Active = Boolean.valueOf(true);
/*  708 */       anim.T = 0.0F;
/*  709 */       anim.TMax = (Helper.VDist2D(anim.StartPos, anim.EndPos) / ag.Param.MaxSpeed * 0.5F);
/*      */ 
/*  711 */       ag.State = CrowdAgentState.OffMesh;
/*  712 */       ag.NCorners = 0;
/*  713 */       ag.NNeis = 0;
/*      */     }
/*      */ 
/*  721 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  723 */       CrowdAgent ag = agents[i];
/*      */ 
/*  727 */       if (ag.State == CrowdAgentState.Walking) {
/*  728 */         if (ag.TargetState == MoveRequestState.TargetNone) {
/*  729 */           Helper.VSet(ag.dvel, 0.0F, 0.0F, 0.0F);
/*      */         }
/*      */         else
/*      */         {
/*  733 */           float[] dvel = { 0.0F, 0.0F, 0.0F };
/*      */ 
/*  735 */           if (ag.TargetState == MoveRequestState.TargetVelocity)
/*      */           {
/*  737 */             Helper.VCopy(dvel, ag.TargetPos);
/*  738 */             ag.DesiredSpeed = Helper.VLen(ag.TargetPos);
/*      */           }
/*      */           else
/*      */           {
/*  742 */             if ((ag.Param.UpdateFlags.getValue() & UpdateFlags.AnticipateTurns.getValue()) != 0)
/*      */             {
/*  744 */               dvel = ag.CalcSmoothSteerDirection(dvel);
/*      */             }
/*      */             else
/*      */             {
/*  748 */               dvel = ag.CalcStraightSteerDirection(dvel);
/*      */             }
/*      */ 
/*  751 */             float slowDownRadius = ag.Param.Radius * 2.0F;
/*  752 */             float speedScale = ag.GetDistanceToGoal(slowDownRadius) / slowDownRadius;
/*      */ 
/*  755 */             dvel = Helper.VScale(dvel[0], dvel[1], dvel[2], ag.DesiredSpeed * speedScale);
/*      */           }
/*      */ 
/*  761 */           if ((ag.Param.UpdateFlags.getValue() & UpdateFlags.Separation.getValue()) != 0)
/*      */           {
/*  763 */             float separationDist = ag.Param.CollisionQueryRange;
/*  764 */             float invSeparationDist = 1.0F / separationDist;
/*  765 */             float separationWeight = ag.Param.SeparationWeight;
/*      */ 
/*  767 */             float w = 0.0F;
/*  768 */             float[] disp = { 0.0F, 0.0F, 0.0F };
/*      */ 
/*  770 */             for (int j = 0; j < ag.NNeis; j++)
/*      */             {
/*  772 */               CrowdAgent nei = this._agents[ag.Neis[j].Idx];
/*      */ 
/*  774 */               float[] diff = Helper.VSub(ag.npos[0], ag.npos[1], ag.npos[2], nei.npos[0], nei.npos[1], nei.npos[2]);
/*  775 */               diff[1] = 0.0F;
/*      */ 
/*  777 */               float distSqr = Helper.VLenSqr(diff);
/*  778 */               if ((distSqr < 1.0E-005F) || 
/*  779 */                 (distSqr > separationDist * separationDist)) continue;
/*  780 */               float dist = (float)Math.sqrt(distSqr);
/*  781 */               float weight = separationWeight * (1.0F - dist * invSeparationDist * dist * invSeparationDist);
/*      */ 
/*  783 */               disp = Helper.VMad(disp, disp, diff, weight / dist);
/*  784 */               w += 1.0F;
/*      */             }
/*      */ 
/*  787 */             if (w > 1.0E-004F)
/*      */             {
/*  789 */               dvel = Helper.VMad(dvel, dvel, disp, 1.0F / w);
/*  790 */               float speedSqr = Helper.VLenSqr(dvel);
/*  791 */               float desiredSpeed = ag.DesiredSpeed * ag.DesiredSpeed;
/*  792 */               if (speedSqr > desiredSpeed) {
/*  793 */                 dvel = Helper.VScale(dvel[0], dvel[1], dvel[2], desiredSpeed / speedSqr);
/*      */               }
/*      */             }
/*      */           }
/*  797 */           Helper.VCopy(ag.dvel, dvel);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  803 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  805 */       CrowdAgent ag = agents[i];
/*      */ 
/*  807 */       if (ag.State != CrowdAgentState.Walking) {
/*      */         continue;
/*      */       }
/*  810 */       if ((ag.Param.UpdateFlags.getValue() & UpdateFlags.ObstacleAvoidance.getValue()) != 0)
/*      */       {
/*  813 */         this._obstacleQuery.Reset();
/*      */ 
/*  815 */         for (int j = 0; j < ag.NNeis; j++)
/*      */         {
/*  818 */           CrowdAgent nei = this._agents[ag.Neis[j].Idx];
/*  819 */           this._obstacleQuery.AddCircle(nei.npos, nei.Param.Radius, nei.vel, nei.dvel);
/*      */         }
/*      */ 
/*  823 */         for (int j = 0; j < ag.Boundary.SegmentCount(); j++)
/*      */         {
/*  825 */           Log.debug("CROWD: getting segment: " + j);
/*  826 */           float[] s0 = new float[3];
/*  827 */           float[] s1 = new float[3];
/*  828 */           System.arraycopy(ag.Boundary.GetSegment(j), 0, s0, 0, 3);
/*  829 */           System.arraycopy(ag.Boundary.GetSegment(j), 3, s1, 0, 3);
/*  830 */           if (Helper.TriArea2D(ag.npos, s0, s1) >= 0.0F) {
/*  831 */             this._obstacleQuery.AddSegment(s0, s1);
/*      */           }
/*      */         }
/*      */ 
/*  835 */         ObstacleAvoidanceDebugData vod = null;
/*  836 */         if (debugIdx == i) {
/*  837 */           vod = debug.Vod;
/*      */         }
/*  839 */         Boolean adaptive = Boolean.valueOf(true);
/*  840 */         int ns = 0;
/*      */ 
/*  843 */         ObstacleAvoidanceParams param = this._obstacleQueryParams[ag.Param.ObstacleAvoidanceType];
/*      */ 
/*  846 */         if (adaptive.booleanValue())
/*      */         {
/*  848 */           ns = this._obstacleQuery.SampleVelocityAdaptive(ag.npos, ag.Param.Radius, ag.DesiredSpeed, ag.vel, ag.dvel, ag.nvel, param, vod);
/*      */         }
/*      */         else
/*      */         {
/*  854 */           ns = this._obstacleQuery.SampleVelocityGrid(ag.npos, ag.Param.Radius, ag.DesiredSpeed, ag.vel, ag.dvel, ag.nvel, param, vod);
/*      */         }
/*      */ 
/*  858 */         this._velocitySampleCount += ns;
/*      */       }
/*      */       else
/*      */       {
/*  863 */         Helper.VCopy(ag.nvel, ag.dvel);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  870 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  873 */       CrowdAgent ag = agents[i];
/*  874 */       if (ag.State != CrowdAgentState.Walking)
/*      */         continue;
/*  876 */       ag.Integrate(dt);
/*      */     }
/*      */ 
/*  881 */     float CollisionResolveFactor = 0.7F;
/*      */ 
/*  883 */     for (int iter = 0; iter < 4; iter++)
/*      */     {
/*  885 */       for (int i = 0; i < nagents; i++)
/*      */       {
/*  888 */         CrowdAgent ag = agents[i];
/*  889 */         int idx0 = AgentIndex(ag);
/*      */ 
/*  891 */         if (ag.State != CrowdAgentState.Walking)
/*      */           continue;
/*  893 */         Helper.VSet(ag.disp, 0.0F, 0.0F, 0.0F);
/*      */ 
/*  895 */         float w = 0.0F;
/*      */ 
/*  897 */         for (int j = 0; j < ag.NNeis; j++)
/*      */         {
/*  900 */           CrowdAgent nei = this._agents[ag.Neis[j].Idx];
/*  901 */           int idx1 = AgentIndex(nei);
/*      */ 
/*  903 */           float[] diff = Helper.VSub(ag.npos[0], ag.npos[1], ag.npos[2], nei.npos[0], nei.npos[1], nei.npos[2]);
/*      */ 
/*  905 */           diff[1] = 0.0F;
/*      */ 
/*  907 */           float dist = Helper.VLenSqr(diff);
/*  908 */           if (dist <= (ag.Param.Radius + nei.Param.Radius) * (ag.Param.Radius + nei.Param.Radius)) {
/*  909 */             dist = (float)Math.sqrt(dist);
/*  910 */             float pen = ag.Param.Radius + nei.Param.Radius - dist;
/*  911 */             if (dist < 1.0E-004F)
/*      */             {
/*  913 */               if (idx0 > idx1)
/*  914 */                 Helper.VSet(diff, -ag.dvel[2], 0.0F, ag.dvel[0]);
/*      */               else
/*  916 */                 Helper.VSet(diff, ag.dvel[2], 0.0F, -ag.vel[0]);
/*  917 */               pen = 0.01F;
/*      */             }
/*      */             else
/*      */             {
/*  921 */               pen = 1.0F / dist * (pen * 0.5F) * CollisionResolveFactor;
/*      */             }
/*      */ 
/*  924 */             ag.disp = Helper.VMad(ag.disp, ag.disp, diff, pen);
/*      */ 
/*  926 */             w += 1.0F;
/*      */           }
/*      */         }
/*  929 */         if (w <= 1.0E-004F)
/*      */           continue;
/*  931 */         float iw = 1.0F / w;
/*  932 */         ag.disp = Helper.VScale(ag.disp[0], ag.disp[1], ag.disp[2], iw);
/*      */       }
/*      */ 
/*  937 */       for (int i = 0; i < nagents; i++)
/*      */       {
/*  939 */         CrowdAgent ag = agents[i];
/*  940 */         if (ag.State != CrowdAgentState.Walking)
/*      */           continue;
/*  942 */         ag.npos = Helper.VAdd(ag.npos[0], ag.npos[1], ag.npos[2], ag.disp[0], ag.disp[1], ag.disp[2]);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  947 */     for (int i = 0; i < nagents; i++)
/*      */     {
/*  949 */       CrowdAgent ag = agents[i];
/*  950 */       if (ag.State != CrowdAgentState.Walking)
/*      */         continue;
/*  952 */       ag.Corridor.MovePosition(ag.npos, this._navQuery, this._filter);
/*  953 */       Helper.VCopy(ag.npos, ag.Corridor.Pos());
/*      */ 
/*  955 */       if ((ag.TargetState != MoveRequestState.TargetNone) && (ag.TargetState != MoveRequestState.TargetVelocity))
/*      */         continue;
/*  957 */       ag.Corridor.Reset(ag.Corridor.FirstPoly(), ag.npos);
/*      */     }
/*      */ 
/*  962 */     for (int i = 0; i < this._maxAgents; i++)
/*      */     {
/*  964 */       CrowdAgentAnimation anim = this._agentAnims[i];
/*  965 */       if (!anim.Active.booleanValue()) {
/*      */         continue;
/*      */       }
/*  968 */       CrowdAgent ag = agents[i];
/*      */ 
/*  970 */       anim.T += dt;
/*  971 */       if (anim.T > anim.TMax)
/*      */       {
/*  973 */         anim.Active = Boolean.valueOf(false);
/*  974 */         ag.State = CrowdAgentState.Walking;
/*      */       }
/*      */       else
/*      */       {
/*  978 */         float ta = anim.TMax * 0.15F;
/*  979 */         float tb = anim.TMax;
/*  980 */         if (anim.T < ta)
/*      */         {
/*  982 */           float u = Tween(anim.T, 0.0F, ta);
/*  983 */           ag.npos = Helper.VLerp(ag.npos, anim.InitPos[0], anim.InitPos[1], anim.InitPos[2], anim.StartPos[0], anim.StartPos[1], anim.StartPos[2], u);
/*      */         }
/*      */         else
/*      */         {
/*  987 */           float u = Tween(anim.T, ta, tb);
/*  988 */           ag.npos = Helper.VLerp(ag.npos, anim.StartPos[0], anim.StartPos[1], anim.StartPos[2], anim.EndPos[0], anim.EndPos[1], anim.EndPos[2], u);
/*      */         }
/*      */ 
/*  991 */         Helper.VSet(ag.vel, 0.0F, 0.0F, 0.0F);
/*  992 */         Helper.VSet(ag.dvel, 0.0F, 0.0F, 0.0F);
/*      */       }
/*      */     }
/*  995 */     return debug;
/*      */   }
/*      */ 
/*      */   public QueryFilter getFilter()
/*      */   {
/* 1000 */     return this._filter;
/*      */   }
/*      */ 
/*      */   public void setFilter(QueryFilter value) {
/* 1004 */     this._filter = value;
/*      */   }
/*      */ 
/*      */   public float[] QueryExtents()
/*      */   {
/* 1009 */     return this._ext;
/*      */   }
/*      */ 
/*      */   public int VelocitySample()
/*      */   {
/* 1014 */     return this._velocitySampleCount;
/*      */   }
/*      */ 
/*      */   public ProximityGrid Grid()
/*      */   {
/* 1019 */     return this._grid;
/*      */   }
/*      */ 
/*      */   public NavMeshQuery NavMeshQuery()
/*      */   {
/* 1024 */     return this._navQuery;
/*      */   }
/*      */ 
/*      */   public static int AddNeighbor(int idx, float dist, CrowdNeighbour[] neis, int nneis, int maxNeis)
/*      */   {
/* 1029 */     CrowdNeighbour nei = null;
/* 1030 */     if ((neis != null) || (neis.length > 0))
/*      */     {
/* 1032 */       nei = neis[nneis];
/*      */     }
/* 1034 */     else if (dist >= neis[(nneis - 1)].Dist)
/*      */     {
/* 1036 */       if (nneis >= maxNeis)
/* 1037 */         return nneis;
/* 1038 */       nei = neis[nneis];
/*      */     }
/*      */     else
/*      */     {
/* 1043 */       for (int i = 0; i < nneis; i++)
/*      */       {
/* 1045 */         if (dist <= neis[i].Dist) {
/*      */           break;
/*      */         }
/*      */       }
/* 1049 */       int tgt = i + 1;
/* 1050 */       int n = Math.min(nneis - i, maxNeis - tgt);
/*      */ 
/* 1052 */       if (n > 0)
/* 1053 */         System.arraycopy(neis, i, neis, tgt, n);
/* 1054 */       nei = neis[i];
/*      */     }
/*      */ 
/* 1057 */     nei = new CrowdNeighbour();
/* 1058 */     nei.Idx = idx;
/* 1059 */     nei.Dist = dist;
/*      */ 
/* 1061 */     return Math.min(nneis + 1, maxNeis);
/*      */   }
/*      */ 
/*      */   public static int GetNeighbors(float[] pos, float height, float range, CrowdAgent skip, CrowdNeighbour[] result, int maxResult, CrowdAgent[] agents, int nagents, ProximityGrid grid)
/*      */   {
/* 1068 */     int n = 0;
/*      */ 
/* 1070 */     int MaxNeis = 32;
/* 1071 */     int[] ids = new int[MaxNeis];
/* 1072 */     int nids = grid.QueryItems(pos[0] - range, pos[2] - range, pos[0] + range, pos[2] + range, ids, MaxNeis);
/*      */ 
/* 1074 */     for (int i = 0; i < nids; i++)
/*      */     {
/* 1076 */       CrowdAgent ag = agents[ids[i]];
/*      */ 
/* 1078 */       if (ag == skip)
/*      */         continue;
/* 1080 */       float[] diff = Helper.VSub(pos[0], pos[1], pos[2], ag.npos[0], ag.npos[1], ag.npos[2]);
/* 1081 */       if (Math.abs(diff[1]) >= (height + ag.Param.Height) / 2.0F) {
/*      */         continue;
/*      */       }
/* 1084 */       diff[1] = 0.0F;
/* 1085 */       float distSqr = Helper.VLenSqr(diff);
/*      */ 
/* 1087 */       if (distSqr > range * range) {
/*      */         continue;
/*      */       }
/* 1090 */       n = AddNeighbor(ids[i], distSqr, result, n, maxResult);
/*      */     }
/*      */ 
/* 1093 */     return n;
/*      */   }
/*      */ 
/*      */   public static int AddToOptQueue(CrowdAgent newag, CrowdAgent[] agents, int nagents, int maxAgents)
/*      */   {
/* 1098 */     int slot = 0;
/* 1099 */     if (nagents <= 0) {
/* 1100 */       slot = 0;
/* 1101 */     } else if (newag.TopologyOptTime <= agents[(nagents - 1)].TopologyOptTime)
/*      */     {
/* 1103 */       if (nagents >= maxAgents)
/* 1104 */         return nagents;
/* 1105 */       slot = nagents;
/*      */     }
/*      */     else
/*      */     {
/* 1110 */       for (int i = 0; i < nagents; i++)
/*      */       {
/* 1112 */         if (newag.TopologyOptTime >= agents[i].TopologyOptTime) {
/*      */           break;
/*      */         }
/*      */       }
/* 1116 */       int tgt = i + 1;
/* 1117 */       int n = Math.min(nagents - i, maxAgents - tgt);
/*      */ 
/* 1119 */       if (n > 0)
/* 1120 */         System.arraycopy(agents, i, agents, tgt, n);
/* 1121 */       slot = i;
/*      */     }
/*      */ 
/* 1124 */     agents[slot] = newag;
/*      */ 
/* 1126 */     return Math.min(nagents + 1, maxAgents);
/*      */   }
/*      */ 
/*      */   public static int AddToPlanQueue(CrowdAgent newag, CrowdAgent[] agents, int nagents, int maxAgents)
/*      */   {
/* 1131 */     int slot = 0;
/* 1132 */     if (nagents <= 0) {
/* 1133 */       slot = 0;
/* 1134 */     } else if (newag.TargetReplanTime <= agents[(nagents - 1)].TargetReplanTime)
/*      */     {
/* 1136 */       if (nagents >= maxAgents)
/* 1137 */         return nagents;
/* 1138 */       slot = nagents;
/*      */     }
/*      */     else
/*      */     {
/* 1143 */       for (int i = 0; i < nagents; i++)
/*      */       {
/* 1145 */         if (newag.TargetReplanTime >= agents[i].TargetReplanTime) {
/*      */           break;
/*      */         }
/*      */       }
/* 1149 */       int tgt = i + 1;
/* 1150 */       int n = Math.min(nagents - i, maxAgents - tgt);
/*      */ 
/* 1152 */       if (n > 0)
/* 1153 */         System.arraycopy(agents, i, agents, tgt, n);
/* 1154 */       slot = i;
/*      */     }
/*      */ 
/* 1157 */     agents[slot] = newag;
/*      */ 
/* 1159 */     return Math.min(nagents + 1, maxAgents);
/*      */   }
/*      */ 
/*      */   public float Tween(float t, float t0, float t1)
/*      */   {
/* 1164 */     return Math.max(0.0F, Math.min(1.0F, (t - t0) / (t1 - t0)));
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.Crowd
 * JD-Core Version:    0.6.0
 */