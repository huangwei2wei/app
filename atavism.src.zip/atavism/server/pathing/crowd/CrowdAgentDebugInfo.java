/*   */ package atavism.server.pathing.crowd;
/*   */ 
/*   */ public class CrowdAgentDebugInfo
/*   */ {
/*   */   public int Idx;
/* 6 */   public float[] OptStart = new float[3];
/* 7 */   public float[] OptEnd = new float[3];
/*   */   public ObstacleAvoidanceDebugData Vod;
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.CrowdAgentDebugInfo
 * JD-Core Version:    0.6.0
 */