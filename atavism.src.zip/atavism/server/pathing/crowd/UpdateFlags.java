/*    */ package atavism.server.pathing.crowd;
/*    */ 
/*    */ public enum UpdateFlags
/*    */ {
/*  4 */   None(0), 
/*  5 */   AnticipateTurns(1), 
/*  6 */   ObstacleAvoidance(2), 
/*  7 */   Separation(4), 
/*  8 */   OptimizeVisibility(8), 
/*  9 */   OptimizeTopology(16);
/*    */ 
/*    */   private final int id;
/*    */ 
/* 12 */   private UpdateFlags(int id) { this.id = id; } 
/* 13 */   public int getValue() { return this.id;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.UpdateFlags
 * JD-Core Version:    0.6.0
 */