/*     */ package atavism.server.pathing.crowd;
/*     */ 
/*     */ import atavism.server.pathing.detour.NavMeshQuery;
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ 
/*     */ public class CrowdAgent
/*     */ {
/*   9 */   public static int CrowdAgentMaxNeighbors = 6;
/*  10 */   public static int CrowdAgentMaxCorners = 4;
/*     */   public Boolean Active;
/*     */   public CrowdAgentState State;
/*     */   public PathCorridor Corridor;
/*     */   public LocalBoundary Boundary;
/*     */   public float TopologyOptTime;
/*  20 */   public CrowdNeighbour[] Neis = new CrowdNeighbour[CrowdAgentMaxNeighbors];
/*     */   public int NNeis;
/*     */   public float DesiredSpeed;
/*  24 */   public float[] npos = new float[3];
/*  25 */   public float[] disp = new float[3];
/*  26 */   public float[] dvel = new float[3];
/*  27 */   public float[] nvel = new float[3];
/*  28 */   public float[] vel = new float[3];
/*     */   public CrowdAgentParams Param;
/*  31 */   public float[] CornerVerts = new float[CrowdAgentMaxCorners * 3];
/*  32 */   public short[] CornerFlags = new short[CrowdAgentMaxCorners];
/*  33 */   public long[] CornerPolys = new long[CrowdAgentMaxCorners];
/*     */   public int NCorners;
/*     */   public MoveRequestState TargetState;
/*     */   public long TargetRef;
/*  38 */   public float[] TargetPos = new float[3];
/*     */   public long TargetPathQRef;
/*     */   public Boolean TargetReplan;
/*     */   public float TargetReplanTime;
/*     */ 
/*     */   public CrowdAgent()
/*     */   {
/*  45 */     this.Corridor = new PathCorridor();
/*  46 */     this.Boundary = new LocalBoundary();
/*  47 */     for (int i = 0; i < CrowdAgentMaxNeighbors; i++)
/*     */     {
/*  49 */       this.Neis[i] = new CrowdNeighbour();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void Integrate(float dt)
/*     */   {
/*  56 */     float maxDelta = this.Param.MaxAcceleration * dt;
/*     */ 
/*  58 */     float[] dv = Helper.VSub(this.nvel[0], this.nvel[1], this.nvel[2], this.vel[0], this.vel[1], this.vel[2]);
/*     */ 
/*  61 */     float ds = Helper.VLen(dv);
/*  62 */     if (ds > maxDelta) {
/*  63 */       dv = Helper.VScale(dv[0], dv[1], dv[2], maxDelta / ds);
/*     */     }
/*     */ 
/*  66 */     this.vel = Helper.VAdd(this.vel[0], this.vel[1], this.vel[2], dv[0], dv[1], dv[2]);
/*     */ 
/*  68 */     if (Helper.VLen(this.vel) > 1.0E-004F) {
/*  69 */       this.npos = Helper.VMad(this.npos, this.npos, this.vel, dt);
/*     */     }
/*     */     else
/*  72 */       Helper.VSet(this.vel, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   public Boolean OverOffMeshConnection(float radius)
/*     */   {
/*  79 */     if (this.NCorners <= 0) {
/*  80 */       return Boolean.valueOf(false);
/*     */     }
/*  82 */     Boolean offMeshConnection = Boolean.valueOf((this.CornerFlags[(this.NCorners - 1)] & NavMeshQuery.StraightPathOffMeshConnection) != 0);
/*  83 */     if (offMeshConnection.booleanValue())
/*     */     {
/*  85 */       float distSq = Helper.VDist2DSqr(this.npos[0], this.npos[1], this.npos[2], this.CornerVerts[((this.NCorners - 1) * 3 + 0)], this.CornerVerts[((this.NCorners - 1) * 3 + 1)], this.CornerVerts[((this.NCorners - 1) * 3 + 2)]);
/*  86 */       if (distSq < radius * radius)
/*  87 */         return Boolean.valueOf(true);
/*     */     }
/*  89 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */   public float GetDistanceToGoal(float range)
/*     */   {
/*  94 */     if (this.NCorners <= 0) {
/*  95 */       return range;
/*     */     }
/*  97 */     Boolean endOfPath = Boolean.valueOf((this.CornerFlags[(this.NCorners - 1)] & NavMeshQuery.StraightPathEnd) != 0);
/*  98 */     if (endOfPath.booleanValue())
/*     */     {
/* 100 */       float[] temp = new float[3];
/* 101 */       System.arraycopy(this.CornerVerts, (this.NCorners - 1) * 3, temp, 0, 3);
/* 102 */       return Math.min(Helper.VDist2D(this.npos, temp), range);
/*     */     }
/*     */ 
/* 105 */     return range;
/*     */   }
/*     */ 
/*     */   public float[] CalcSmoothSteerDirection(float[] dir)
/*     */   {
/* 110 */     if (this.NCorners <= 0)
/*     */     {
/* 112 */       Helper.VSet(dir, 0.0F, 0.0F, 0.0F);
/* 113 */       return dir;
/*     */     }
/*     */ 
/* 116 */     int ip0 = 0;
/* 117 */     int ip1 = Math.min(1, this.NCorners - 1);
/* 118 */     float[] p0 = new float[3]; float[] p1 = new float[3];
/*     */ 
/* 120 */     int sourcePos0 = ip0 * 3;
/* 121 */     int sourcePos1 = ip1 * 3;
/* 122 */     System.arraycopy(this.CornerVerts, sourcePos0, p0, 0, 3);
/* 123 */     System.arraycopy(this.CornerVerts, sourcePos1, p1, 0, 3);
/*     */ 
/* 125 */     float[] dir0 = Helper.VSub(p0[0], p0[1], p0[2], this.npos[0], this.npos[1], this.npos[2]);
/* 126 */     float[] dir1 = Helper.VSub(p1[0], p1[1], p1[2], this.npos[0], this.npos[1], this.npos[2]);
/* 127 */     dir0[1] = 0.0F;
/* 128 */     dir1[1] = 0.0F;
/*     */ 
/* 130 */     float len0 = Helper.VLen(dir0);
/* 131 */     float len1 = Helper.VLen(dir1);
/*     */ 
/* 133 */     if (len1 > 0.001F) {
/* 134 */       dir1 = Helper.VScale(dir1[0], dir1[1], dir1[2], 1.0F / len1);
/*     */     }
/* 136 */     dir0[0] -= dir1[0] * len0 * 0.5F;
/* 137 */     dir[1] = 0.0F;
/* 138 */     dir0[2] -= dir1[2] * len0 * 0.5F;
/*     */ 
/* 140 */     dir = Helper.VNormalize(dir);
/* 141 */     return dir;
/*     */   }
/*     */ 
/*     */   public float[] CalcStraightSteerDirection(float[] dir)
/*     */   {
/* 147 */     if (this.NCorners <= 0)
/*     */     {
/* 149 */       Helper.VSet(dir, 0.0F, 0.0F, 0.0F);
/* 150 */       return dir;
/*     */     }
/*     */ 
/* 153 */     dir = Helper.VSub(this.CornerVerts[0], this.CornerVerts[1], this.CornerVerts[2], this.npos[0], this.npos[1], this.npos[2]);
/* 154 */     dir[1] = 0.0F;
/* 155 */     dir = Helper.VNormalize(dir);
/* 156 */     return dir;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.CrowdAgent
 * JD-Core Version:    0.6.0
 */