/*   */ package atavism.server.pathing.crowd;
/*   */ 
/*   */ public class CrowdAgentAnimation
/*   */ {
/*   */   public Boolean Active;
/* 6 */   public float[] InitPos = new float[3];
/* 7 */   public float[] StartPos = new float[3];
/* 8 */   public float[] EndPos = new float[3];
/*   */   public long PolyRef;
/*   */   public float T;
/*   */   public float TMax;
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.CrowdAgentAnimation
 * JD-Core Version:    0.6.0
 */