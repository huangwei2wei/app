/*    */ package atavism.server.pathing.crowd;
/*    */ 
/*    */ public class ObstacleAvoidanceParams
/*    */ {
/*    */   public float velBias;
/*    */   public float weightDesVel;
/*    */   public float weightCurVel;
/*    */   public float weightSide;
/*    */   public float weightToi;
/*    */   public float horizTime;
/*    */   public short gridSize;
/*    */   public short adaptiveDivs;
/*    */   public short adaptiveRings;
/*    */   public short adaptiveDepth;
/*    */ 
/*    */   public ObstacleAvoidanceParams()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ObstacleAvoidanceParams(float velBias, float weightDesVel, float weightCurVel, float weightSide, float weightToi, float horizTime, short gridSize, short adaptiveDivs, short adaptiveRings, short adaptiveDepth)
/*    */   {
/* 23 */     this.velBias = velBias;
/* 24 */     this.weightDesVel = weightDesVel;
/* 25 */     this.weightCurVel = weightCurVel;
/* 26 */     this.weightSide = weightSide;
/* 27 */     this.weightToi = weightToi;
/* 28 */     this.horizTime = horizTime;
/* 29 */     this.gridSize = gridSize;
/* 30 */     this.adaptiveDivs = adaptiveDivs;
/* 31 */     this.adaptiveRings = adaptiveRings;
/* 32 */     this.adaptiveDepth = adaptiveDepth;
/*    */   }
/*    */ 
/*    */   public ObstacleAvoidanceParams(ObstacleAvoidanceParams param)
/*    */   {
/* 37 */     this.velBias = param.velBias;
/* 38 */     this.weightDesVel = param.weightDesVel;
/* 39 */     this.weightCurVel = param.weightCurVel;
/* 40 */     this.weightSide = param.weightSide;
/* 41 */     this.weightToi = param.weightToi;
/* 42 */     this.horizTime = param.horizTime;
/* 43 */     this.gridSize = param.gridSize;
/* 44 */     this.adaptiveDivs = param.adaptiveDivs;
/* 45 */     this.adaptiveRings = param.adaptiveRings;
/* 46 */     this.adaptiveDepth = param.adaptiveDepth;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.ObstacleAvoidanceParams
 * JD-Core Version:    0.6.0
 */