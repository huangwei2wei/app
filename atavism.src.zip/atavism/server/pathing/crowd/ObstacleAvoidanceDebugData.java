/*     */ package atavism.server.pathing.crowd;
/*     */ 
/*     */ public class ObstacleAvoidanceDebugData
/*     */ {
/*     */   private int _nsamples;
/*     */   private int _maxSamples;
/*     */   private float[] _vel;
/*     */   private float[] _ssize;
/*     */   private float[] _pen;
/*     */   private float[] _vpen;
/*     */   private float[] _vcpen;
/*     */   private float[] _spen;
/*     */   private float[] _tpen;
/*     */ 
/*     */   public ObstacleAvoidanceDebugData()
/*     */   {
/*  17 */     this._nsamples = 0;
/*  18 */     this._maxSamples = 0;
/*  19 */     this._vel = null;
/*  20 */     this._ssize = null;
/*  21 */     this._pen = null;
/*  22 */     this._vpen = null;
/*  23 */     this._vcpen = null;
/*  24 */     this._spen = null;
/*  25 */     this._tpen = null;
/*     */   }
/*     */ 
/*     */   public Boolean Init(int maxSamples)
/*     */   {
/*     */     try {
/*  31 */       if (maxSamples <= 0)
/*  32 */         throw new Exception("Max Samples must be larger than 0");
/*     */     }
/*     */     catch (Exception e) {
/*  35 */       e.printStackTrace();
/*     */     }
/*  37 */     this._maxSamples = maxSamples;
/*     */ 
/*  39 */     this._vel = new float[maxSamples * 3];
/*  40 */     this._pen = new float[maxSamples];
/*  41 */     this._ssize = new float[maxSamples];
/*  42 */     this._vpen = new float[maxSamples];
/*  43 */     this._vcpen = new float[maxSamples];
/*  44 */     this._spen = new float[maxSamples];
/*  45 */     this._tpen = new float[maxSamples];
/*     */ 
/*  47 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public void Reset()
/*     */   {
/*  52 */     this._nsamples = 0;
/*     */   }
/*     */ 
/*     */   public void AddSample(float[] vel, float ssize, float pen, float vpen, float vcpen, float spen, float tpen)
/*     */   {
/*  57 */     if (this._nsamples >= this._maxSamples) {
/*  58 */       return;
/*     */     }
/*  60 */     System.arraycopy(this._vel, this._nsamples * 3, vel, 0, 3);
/*  61 */     this._ssize[this._nsamples] = ssize;
/*  62 */     this._pen[this._nsamples] = pen;
/*  63 */     this._vpen[this._nsamples] = vpen;
/*  64 */     this._vcpen[this._nsamples] = vcpen;
/*  65 */     this._spen[this._nsamples] = spen;
/*  66 */     this._tpen[this._nsamples] = tpen;
/*  67 */     this._nsamples += 1;
/*     */   }
/*     */ 
/*     */   public void NormalizeSamples()
/*     */   {
/*  72 */     this._pen = NormalizeArray(this._pen, this._nsamples);
/*  73 */     this._vpen = NormalizeArray(this._vpen, this._nsamples);
/*  74 */     this._vcpen = NormalizeArray(this._vcpen, this._nsamples);
/*  75 */     this._spen = NormalizeArray(this._spen, this._nsamples);
/*  76 */     this._tpen = NormalizeArray(this._tpen, this._nsamples);
/*     */   }
/*     */ 
/*     */   private float[] NormalizeArray(float[] arr, int n)
/*     */   {
/*  81 */     float minPen = 3.4028235E+38F;
/*  82 */     float maxPen = -3.402824E+038F;
/*  83 */     for (int i = 0; i < n; i++)
/*     */     {
/*  85 */       minPen = Math.min(minPen, arr[i]);
/*  86 */       maxPen = Math.max(maxPen, arr[i]);
/*     */     }
/*     */ 
/*  89 */     float penRange = maxPen - minPen;
/*  90 */     float s = penRange > 0.001F ? 1.0F / penRange : 1.0F;
/*  91 */     for (int i = 0; i < n; i++)
/*     */     {
/*  93 */       arr[i] = Math.max(0.0F, Math.min(1.0F, (arr[i] - minPen) * s));
/*     */     }
/*  95 */     return arr;
/*     */   }
/*     */ 
/*     */   public int SampleCount()
/*     */   {
/* 100 */     return this._nsamples;
/*     */   }
/*     */ 
/*     */   public float[] SampleVelocity(int i)
/*     */   {
/* 105 */     float[] ret = new float[3];
/* 106 */     System.arraycopy(this._vel, i * 3, ret, 0, 3);
/* 107 */     return ret;
/*     */   }
/*     */ 
/*     */   public float SampleSize(int i)
/*     */   {
/* 112 */     return this._ssize[i];
/*     */   }
/*     */ 
/*     */   public float SamplePenalty(int i)
/*     */   {
/* 117 */     return this._pen[i];
/*     */   }
/*     */ 
/*     */   public float SampleDesiredVelocityPenalty(int i)
/*     */   {
/* 122 */     return this._vpen[i];
/*     */   }
/*     */ 
/*     */   public float SampleCurrentVelocityPenalty(int i)
/*     */   {
/* 127 */     return this._vcpen[i];
/*     */   }
/*     */ 
/*     */   public float SamplePreferredSidePenalty(int i)
/*     */   {
/* 132 */     return this._spen[i];
/*     */   }
/*     */ 
/*     */   public float SampleCollisionTimePenalty(int i)
/*     */   {
/* 137 */     return this._tpen[i];
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.ObstacleAvoidanceDebugData
 * JD-Core Version:    0.6.0
 */