/*   */ package atavism.server.pathing.crowd;
/*   */ 
/*   */ public class ObstacleSegment
/*   */ {
/* 5 */   public float[] p = new float[3];
/* 6 */   public float[] q = new float[3];
/*   */   public Boolean touch;
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.ObstacleSegment
 * JD-Core Version:    0.6.0
 */