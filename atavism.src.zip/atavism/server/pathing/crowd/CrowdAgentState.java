/*   */ package atavism.server.pathing.crowd;
/*   */ 
/*   */ public enum CrowdAgentState
/*   */ {
/* 4 */   Invalid, 
/* 5 */   Walking, 
/* 6 */   OffMesh;
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.CrowdAgentState
 * JD-Core Version:    0.6.0
 */