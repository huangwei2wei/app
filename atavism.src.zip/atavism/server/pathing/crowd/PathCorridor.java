/*     */ package atavism.server.pathing.crowd;
/*     */ 
/*     */ import atavism.server.pathing.detour.DetourNumericReturn;
/*     */ import atavism.server.pathing.detour.DetourRaycastHit;
/*     */ import atavism.server.pathing.detour.DetourStatusReturn;
/*     */ import atavism.server.pathing.detour.NavMesh;
/*     */ import atavism.server.pathing.detour.NavMeshQuery;
/*     */ import atavism.server.pathing.detour.QueryFilter;
/*     */ import atavism.server.pathing.detour.Status;
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ public class PathCorridor
/*     */ {
/*  16 */   private float[] _pos = new float[3];
/*  17 */   private float[] _target = new float[3];
/*     */   private long[] _path;
/*     */   private int _npath;
/*     */   private int _maxPath;
/*     */ 
/*     */   public PathCorridor()
/*     */   {
/*  25 */     this._path = null;
/*  26 */     this._npath = 0;
/*  27 */     this._maxPath = 0;
/*     */   }
/*     */ 
/*     */   public Boolean Init(int maxPath)
/*     */   {
/*     */     try {
/*  33 */       if (this._path != null)
/*  34 */         throw new Exception("Path already exists, reset before initializing");
/*     */     }
/*     */     catch (Exception e) {
/*  37 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  40 */     this._path = new long[maxPath];
/*  41 */     this._npath = 0;
/*  42 */     this._maxPath = maxPath;
/*  43 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public void Reset(long refId, float[] pos)
/*     */   {
/*  48 */     Helper.VCopy(this._pos, pos);
/*  49 */     Helper.VCopy(this._target, pos);
/*  50 */     this._path[0] = refId;
/*  51 */     this._npath = 1;
/*     */   }
/*     */ 
/*     */   public int FindCorners(float[] cornerVerts, short[] cornerFlags, long[] cornerPolys, int maxCorners, NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/*     */     try
/*     */     {
/*  59 */       if ((this._path == null) || (this._npath == 0))
/*  60 */         throw new Exception("Corridor must be initialised first");
/*     */     } catch (Exception e) {
/*  62 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  65 */     float MinTargetDist = 0.01F;
/*     */ 
/*  67 */     DetourStatusReturn statusReturn = navQuery.FindStraightPath(this._pos, this._target, this._path, this._npath, cornerVerts, cornerFlags, cornerPolys, maxCorners);
/*     */ 
/*  69 */     int ncorners = statusReturn.intValue;
/*  70 */     Log.debug("CROWD: got nCorners: " + ncorners + " with pos: " + this._pos[0] + "," + this._pos[1] + "," + this._pos[2] + " and target: " + this._target[0] + "," + this._target[1] + "," + this._target[2]);
/*     */ 
/*  73 */     while (ncorners > 0)
/*     */     {
/*  75 */       Log.debug("CROWD: cornerFlags: " + cornerFlags[0] + " against: " + NavMeshQuery.StraightPathOffMeshConnection + " with distance: " + Helper.VDist2DSqr(cornerVerts[0], cornerVerts[1], cornerVerts[2], this._pos[0], this._pos[1], this._pos[2]) + " and min: " + MinTargetDist + " and cornerVerts: " + cornerVerts[0] + "," + cornerVerts[1] + "," + cornerVerts[2]);
/*     */ 
/*  78 */       if (((cornerFlags[0] & NavMeshQuery.StraightPathOffMeshConnection) != 0) || (Helper.VDist2DSqr(cornerVerts[0], cornerVerts[1], cornerVerts[2], this._pos[0], this._pos[1], this._pos[2]) > MinTargetDist * MinTargetDist)) {
/*     */         break;
/*     */       }
/*  81 */       ncorners--;
/*  82 */       if (ncorners <= 0)
/*     */         continue;
/*  84 */       System.arraycopy(cornerFlags, 1, cornerFlags, 0, ncorners);
/*  85 */       System.arraycopy(cornerPolys, 1, cornerPolys, 0, ncorners);
/*  86 */       System.arraycopy(cornerVerts, 3, cornerVerts, 0, ncorners * 3);
/*     */     }
/*     */ 
/*  90 */     for (int i = 0; i < ncorners; i++)
/*     */     {
/*  92 */       if ((cornerFlags[i] & NavMeshQuery.StraightPathOffMeshConnection) == 0)
/*     */         continue;
/*  94 */       ncorners = i + 1;
/*  95 */       break;
/*     */     }
/*     */ 
/*  98 */     return ncorners;
/*     */   }
/*     */ 
/*     */   public void OptimizePathVisibility(float[] next, float pathOptimizationRange, NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/*     */     try
/*     */     {
/* 105 */       if (this._path == null)
/* 106 */         throw new Exception("Corridor must be initialised first");
/*     */     }
/*     */     catch (Exception e) {
/* 109 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 112 */     float[] goal = new float[3];
/* 113 */     Helper.VCopy(goal, next);
/* 114 */     float dist = Helper.VDist2D(this._pos, goal);
/*     */ 
/* 116 */     if (dist < 0.01F) {
/* 117 */       return;
/*     */     }
/* 119 */     dist = Math.min(dist + 0.01F, pathOptimizationRange);
/*     */ 
/* 121 */     float[] delta = Helper.VSub(goal[0], goal[1], goal[2], this._pos[0], this._pos[1], this._pos[2]);
/* 122 */     goal = Helper.VMad(goal, this._pos, delta, pathOptimizationRange / dist);
/*     */ 
/* 124 */     int MaxRes = 32;
/* 125 */     long[] res = new long[MaxRes];
/* 126 */     float[] norm = new float[3];
/*     */ 
/* 128 */     DetourRaycastHit raycastHit = navQuery.Raycast(this._path[0], this._pos, goal, filter, norm, res, MaxRes);
/* 129 */     int nres = raycastHit.pathCount;
/* 130 */     if ((nres > 1) && (raycastHit.t > 0.99F))
/*     */     {
/* 132 */       this._npath = MergeCorridorStartShortcut(this._path, this._npath, this._maxPath, res, nres);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Boolean OptimizePathTopology(NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/* 138 */     if (this._npath < 3) {
/* 139 */       return Boolean.valueOf(false);
/*     */     }
/* 141 */     int MaxIters = 32;
/* 142 */     int MaxRes = 32;
/*     */ 
/* 144 */     long[] res = new long[MaxRes];
/*     */ 
/* 146 */     navQuery.InitSlicedFindPath(this._path[0], this._path[(this._npath - 1)], this._pos, this._target, filter);
/* 147 */     navQuery.UpdateSlicedFindPath(MaxIters);
/*     */ 
/* 149 */     DetourStatusReturn statusReturn = navQuery.FinalizeSlicedFindPathPartial(this._path, this._npath, res, MaxRes);
/* 150 */     int nres = statusReturn.intValue;
/* 151 */     if ((statusReturn.status.contains(Status.Success)) && (nres > 0))
/*     */     {
/* 153 */       this._npath = MergeCorridorStartShortcut(this._path, this._npath, this._maxPath, res, nres);
/* 154 */       return Boolean.valueOf(true);
/*     */     }
/*     */ 
/* 157 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */   public Boolean MoveOverOffmeshConnection(long offMeshConRef, long[] refs, float[] startPos, float[] endPos, NavMeshQuery navQuery)
/*     */   {
/* 163 */     long prefRef = 0L; long polyRef = this._path[0];
/* 164 */     int npos = 0;
/* 165 */     while ((npos < this._npath) && (polyRef != offMeshConRef))
/*     */     {
/* 167 */       prefRef = polyRef;
/* 168 */       polyRef = this._path[npos];
/* 169 */       npos++;
/*     */     }
/* 171 */     if (npos == this._npath) {
/* 172 */       return Boolean.valueOf(false);
/*     */     }
/* 174 */     for (int i = npos; i < this._npath; i++)
/*     */     {
/* 176 */       this._path[(i - npos)] = this._path[i];
/*     */     }
/*     */ 
/* 179 */     this._npath -= npos;
/*     */ 
/* 181 */     refs[0] = prefRef;
/* 182 */     refs[1] = polyRef;
/*     */ 
/* 184 */     NavMesh nav = navQuery.NavMesh;
/*     */ 
/* 186 */     EnumSet status = nav.GetOffMeshConnectionPolyEndPoints(refs[0], refs[1], startPos, endPos);
/* 187 */     if (status.contains(Status.Success))
/*     */     {
/* 189 */       Helper.VCopy(this._pos, endPos);
/* 190 */       return Boolean.valueOf(true);
/*     */     }
/*     */ 
/* 193 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */   public Boolean FixPathStart(long safeRef, float[] safePos)
/*     */   {
/* 198 */     Helper.VCopy(this._pos, safePos);
/* 199 */     if ((this._npath < 3) && (this._npath > 0))
/*     */     {
/* 201 */       this._path[2] = this._path[(this._npath - 1)];
/* 202 */       this._path[0] = safeRef;
/* 203 */       this._path[1] = 0L;
/* 204 */       this._npath = 3;
/*     */     }
/*     */     else
/*     */     {
/* 208 */       this._path[0] = safeRef;
/* 209 */       this._path[1] = 0L;
/*     */     }
/*     */ 
/* 212 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public Boolean TrimInvalidPath(long safeRef, float[] safePos, NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/* 217 */     int n = 0;
/* 218 */     while ((n < this._npath) && (navQuery.IsValidPolyRef(this._path[n], filter).booleanValue()))
/*     */     {
/* 220 */       n++;
/*     */     }
/*     */ 
/* 223 */     if (n == this._npath)
/* 224 */       return Boolean.valueOf(true);
/* 225 */     if (n == 0)
/*     */     {
/* 227 */       Helper.VCopy(this._pos, safePos);
/* 228 */       this._path[0] = safeRef;
/* 229 */       this._npath = 1;
/*     */     }
/*     */     else
/*     */     {
/* 233 */       this._npath = n;
/*     */     }
/*     */ 
/* 236 */     float[] tgt = new float[3];
/* 237 */     Helper.VCopy(tgt, this._target);
/* 238 */     navQuery.ClosestPointOnPolyBoundary(this._path[(this._npath - 1)], tgt, this._target);
/*     */ 
/* 240 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public Boolean IsValid(int maxLookAhead, NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/* 245 */     int n = Math.min(this._npath, maxLookAhead);
/* 246 */     for (int i = 0; i < n; i++)
/*     */     {
/* 248 */       if (!navQuery.IsValidPolyRef(this._path[i], filter).booleanValue())
/* 249 */         return Boolean.valueOf(false);
/*     */     }
/* 251 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public void MovePosition(float[] npos, NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/* 256 */     float[] result = new float[3];
/* 257 */     int MaxVisited = 16;
/* 258 */     long[] visited = new long[MaxVisited];
/*     */ 
/* 260 */     int nvisited = navQuery.MoveAlongSurface(this._path[0], this._pos, npos, filter, result, visited, MaxVisited).intValue;
/* 261 */     this._npath = MergeCorridorStartMoved(this._path, this._npath, this._maxPath, visited, nvisited);
/*     */ 
/* 263 */     float h = this._pos[1];
/* 264 */     result[1] = navQuery.GetPolyHeight(this._path[0], result, h).floatValue;
/* 265 */     Helper.VCopy(this._pos, result);
/*     */   }
/*     */ 
/*     */   public void MoveTargetPosition(float[] npos, NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/* 270 */     float[] result = new float[3];
/* 271 */     int MaxVisited = 16;
/* 272 */     long[] visited = new long[MaxVisited];
/* 273 */     int nvisited = navQuery.MoveAlongSurface(this._path[(this._npath - 1)], this._target, npos, filter, result, visited, MaxVisited).intValue;
/* 274 */     this._npath = MergeCorridorEndMoved(this._path, this._npath, this._maxPath, visited, nvisited);
/*     */ 
/* 276 */     Helper.VCopy(this._target, result);
/*     */   }
/*     */ 
/*     */   public void SetCorridor(float[] target, long[] path, int npath)
/*     */   {
/* 281 */     Helper.VCopy(this._target, target);
/* 282 */     System.arraycopy(path, 0, this._path, 0, npath);
/* 283 */     this._npath = npath;
/* 284 */     Log.debug("CORRIDOR: set target to: " + this._target[0] + "," + target[2]);
/*     */   }
/*     */ 
/*     */   public float[] Pos()
/*     */   {
/* 289 */     return this._pos;
/*     */   }
/*     */ 
/*     */   public float[] Target()
/*     */   {
/* 294 */     return this._target;
/*     */   }
/*     */ 
/*     */   public long FirstPoly()
/*     */   {
/* 299 */     return this._npath > 0 ? this._path[0] : 0L;
/*     */   }
/*     */ 
/*     */   public long LastPoly()
/*     */   {
/* 304 */     return this._npath > 0 ? this._path[(this._npath - 1)] : 0L;
/*     */   }
/*     */ 
/*     */   public long[] GetPath()
/*     */   {
/* 309 */     return this._path;
/*     */   }
/*     */ 
/*     */   public int PathCount()
/*     */   {
/* 314 */     return this._npath;
/*     */   }
/*     */ 
/*     */   public static int MergeCorridorStartMoved(long[] path, int npath, int maxPath, long[] visited, int nvisited)
/*     */   {
/* 319 */     int furthestPath = -1;
/* 320 */     int furthestVisited = -1;
/*     */ 
/* 322 */     for (int i = npath - 1; i >= 0; i--)
/*     */     {
/* 324 */       Boolean found = Boolean.valueOf(false);
/* 325 */       for (int j = nvisited - 1; j >= 0; j--)
/*     */       {
/* 327 */         if (path[i] != visited[j])
/*     */           continue;
/* 329 */         furthestPath = i;
/* 330 */         furthestVisited = j;
/* 331 */         found = Boolean.valueOf(true);
/*     */       }
/*     */ 
/* 334 */       if (found.booleanValue()) {
/*     */         break;
/*     */       }
/*     */     }
/* 338 */     if ((furthestPath == -1) || (furthestVisited == -1))
/*     */     {
/* 340 */       return npath;
/*     */     }
/*     */ 
/* 343 */     int req = nvisited - furthestVisited;
/* 344 */     int orig = Math.min(furthestPath + 1, npath);
/* 345 */     int size = Math.max(0, npath - orig);
/* 346 */     if (req + size > maxPath)
/* 347 */       size = maxPath - req;
/* 348 */     if (size >= 0) {
/* 349 */       System.arraycopy(path, orig, path, req, size);
/*     */     }
/* 351 */     for (int i = 0; i < req; i++)
/*     */     {
/* 353 */       path[i] = visited[(nvisited - 1 - i)];
/*     */     }
/*     */ 
/* 356 */     return req + size;
/*     */   }
/*     */ 
/*     */   public static int MergeCorridorEndMoved(long[] path, int npath, int maxPath, long[] visited, int nvisited)
/*     */   {
/* 361 */     int furthestPath = -1;
/* 362 */     int furthestVisited = -1;
/*     */ 
/* 364 */     for (int i = 0; i < npath; i++)
/*     */     {
/* 366 */       Boolean found = Boolean.valueOf(false);
/* 367 */       for (int j = nvisited - 1; j >= 0; j--)
/*     */       {
/* 369 */         if (path[i] != visited[j])
/*     */           continue;
/* 371 */         furthestPath = i;
/* 372 */         furthestVisited = j;
/* 373 */         found = Boolean.valueOf(true);
/*     */       }
/*     */ 
/* 376 */       if (found.booleanValue()) {
/*     */         break;
/*     */       }
/*     */     }
/* 380 */     if ((furthestPath == -1) || (furthestVisited == -1)) {
/* 381 */       return npath;
/*     */     }
/* 383 */     int ppos = furthestPath + 1;
/* 384 */     int vpos = furthestVisited + 1;
/* 385 */     int count = Math.min(nvisited - vpos, maxPath - ppos);
/* 386 */     if (count >= 0) {
/* 387 */       System.arraycopy(visited, vpos, path, ppos, count);
/*     */     }
/* 389 */     return ppos + count;
/*     */   }
/*     */ 
/*     */   public static int MergeCorridorStartShortcut(long[] path, int npath, int maxPath, long[] visited, int nvisited)
/*     */   {
/* 395 */     int furthestPath = -1;
/* 396 */     int furthestVisited = -1;
/*     */ 
/* 398 */     for (int i = npath - 1; i >= 0; i--)
/*     */     {
/* 400 */       Boolean found = Boolean.valueOf(false);
/* 401 */       for (int j = nvisited - 1; j >= 0; j--)
/*     */       {
/* 403 */         if (path[i] != visited[j])
/*     */           continue;
/* 405 */         furthestPath = i;
/* 406 */         furthestVisited = j;
/* 407 */         found = Boolean.valueOf(true);
/*     */       }
/*     */ 
/* 410 */       if (found.booleanValue()) {
/*     */         break;
/*     */       }
/*     */     }
/* 414 */     if ((furthestPath == -1) || (furthestVisited == -1)) {
/* 415 */       return npath;
/*     */     }
/* 417 */     int req = furthestVisited;
/* 418 */     if (req <= 0) {
/* 419 */       return npath;
/*     */     }
/* 421 */     int orig = furthestPath;
/* 422 */     int size = Math.max(0, npath - orig);
/* 423 */     if (req + size > maxPath)
/* 424 */       size = maxPath - req;
/* 425 */     if (size > 0) {
/* 426 */       System.arraycopy(path, orig, path, req, size);
/*     */     }
/* 428 */     for (int i = 0; i < req; i++)
/*     */     {
/* 430 */       path[i] = visited[i];
/*     */     }
/*     */ 
/* 433 */     return req + size;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.PathCorridor
 * JD-Core Version:    0.6.0
 */