/*     */ package atavism.server.pathing.crowd;
/*     */ 
/*     */ import atavism.server.pathing.detour.DetourStatusReturn;
/*     */ import atavism.server.pathing.detour.NavMesh;
/*     */ import atavism.server.pathing.detour.NavMeshQuery;
/*     */ import atavism.server.pathing.detour.QueryFilter;
/*     */ import atavism.server.pathing.detour.Status;
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ public class PathQueue
/*     */ {
/*     */   public static final long PathQInvalid = 0L;
/*  28 */   private final int MaxQueue = 8;
/*     */   private PathQuery[] _queue;
/*     */   private long _nextHandle;
/*     */   private int _maxPathSize;
/*     */   private int _queueHead;
/*     */   private NavMeshQuery _navQuery;
/*     */ 
/*     */   public PathQueue()
/*     */   {
/*  37 */     this._nextHandle = 1L;
/*  38 */     this._maxPathSize = 0;
/*  39 */     this._queueHead = 0;
/*  40 */     this._navQuery = null;
/*  41 */     this._queue = new PathQuery[8];
/*  42 */     for (int i = 0; i < 8; i++)
/*     */     {
/*  44 */       this._queue[i] = new PathQuery(null);
/*  45 */       this._queue[i].path = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void Purge()
/*     */   {
/*  51 */     this._navQuery = null;
/*  52 */     for (int i = 0; i < 8; i++)
/*     */     {
/*  54 */       this._queue[i].path = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Boolean Init(int maxPathSize, int maxSearchNodeCount, NavMesh nav)
/*     */   {
/*  60 */     Purge();
/*  61 */     this._navQuery = new NavMeshQuery();
/*  62 */     if ((this._navQuery.Init(nav, maxSearchNodeCount).getValue() & Status.Failure.getValue()) != 0)
/*  63 */       return Boolean.valueOf(false);
/*  64 */     this._maxPathSize = maxPathSize;
/*  65 */     for (int i = 0; i < 8; i++)
/*     */     {
/*  67 */       this._queue[i].refId = 0L;
/*  68 */       this._queue[i].path = new long[this._maxPathSize];
/*     */     }
/*     */ 
/*  71 */     this._queueHead = 0;
/*  72 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public void Update(int maxIters)
/*     */   {
/*  77 */     int MaxKeepAlive = 2;
/*  78 */     int iterCount = maxIters;
/*  79 */     for (int i = 0; i < 8; i++)
/*     */     {
/*  81 */       PathQuery q = this._queue[(this._queueHead % 8)];
/*  82 */       if (q.refId == 0L)
/*     */       {
/*  84 */         this._queueHead += 1;
/*     */       }
/*  88 */       else if ((q.status != null) && ((q.status.contains(Status.Success)) || (q.status.contains(Status.Failure))))
/*     */       {
/*  90 */         q.keepAlive += 1;
/*  91 */         if (q.keepAlive > MaxKeepAlive)
/*     */         {
/*  93 */           q.refId = 0L;
/*  94 */           q.status = null;
/*     */         }
/*     */ 
/*  97 */         this._queueHead += 1;
/*     */       }
/*     */       else
/*     */       {
/* 101 */         if (q.status == null)
/*     */         {
/* 103 */           q.status = this._navQuery.InitSlicedFindPath(q.startRef, q.endRef, q.startPos, q.endPos, q.filter);
/*     */         }
/*     */ 
/* 106 */         if (q.status.contains(Status.InProgress))
/*     */         {
/* 108 */           DetourStatusReturn statusReturn = this._navQuery.UpdateSlicedFindPath(iterCount);
/* 109 */           q.status = statusReturn.status;
/* 110 */           iterCount -= statusReturn.intValue;
/*     */         }
/* 112 */         if (q.status.contains(Status.Success))
/*     */         {
/* 114 */           q.status = this._navQuery.FinalizeSlicedFindPath(q.path, this._maxPathSize).status;
/*     */         }
/*     */ 
/* 117 */         if (iterCount <= 0) {
/*     */           break;
/*     */         }
/* 120 */         this._queueHead += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public long Request(long startRef, long endRef, float[] startPos, float[] endPos, QueryFilter filter) {
/* 126 */     int slot = -1;
/* 127 */     for (int i = 0; i < 8; i++)
/*     */     {
/* 129 */       if (this._queue[i].refId != 0L)
/*     */         continue;
/* 131 */       slot = i;
/* 132 */       break;
/*     */     }
/*     */ 
/* 136 */     if (slot == -1)
/*     */     {
/* 138 */       return 0L;
/*     */     }
/*     */ 
/* 141 */     long refId = this._nextHandle++;
/* 142 */     if (this._nextHandle == 0L) this._nextHandle += 1L;
/*     */ 
/* 144 */     PathQuery q = this._queue[slot];
/* 145 */     q.refId = refId;
/* 146 */     Helper.VCopy(q.startPos, startPos);
/* 147 */     q.startRef = startRef;
/* 148 */     Helper.VCopy(q.endPos, endPos);
/* 149 */     q.endRef = endRef;
/*     */ 
/* 151 */     q.status = null;
/* 152 */     q.npath = 0;
/* 153 */     q.filter = filter;
/* 154 */     q.keepAlive = 0;
/*     */ 
/* 156 */     return refId;
/*     */   }
/*     */ 
/*     */   public EnumSet<Status> GetRequestStatus(long refId)
/*     */   {
/* 161 */     for (int i = 0; i < 8; i++)
/*     */     {
/* 163 */       if (this._queue[i].refId == refId)
/* 164 */         return this._queue[i].status;
/*     */     }
/* 166 */     return EnumSet.of(Status.Failure);
/*     */   }
/*     */ 
/*     */   public DetourStatusReturn GetPathResult(long refId, long[] path, int pathSize, int maxPath)
/*     */   {
/* 171 */     DetourStatusReturn statusReturn = new DetourStatusReturn();
/* 172 */     for (int i = 0; i < 8; i++)
/*     */     {
/* 174 */       if (this._queue[i].refId != refId)
/*     */         continue;
/* 176 */       PathQuery q = this._queue[i];
/* 177 */       q.refId = 0L;
/* 178 */       q.status = null;
/* 179 */       int n = Math.min(q.npath, maxPath);
/* 180 */       System.arraycopy(q.path, 0, path, 0, n);
/* 181 */       statusReturn.intValue = n;
/* 182 */       statusReturn.status = EnumSet.of(Status.Success);
/* 183 */       return statusReturn;
/*     */     }
/*     */ 
/* 186 */     statusReturn.status = EnumSet.of(Status.Failure);
/* 187 */     return statusReturn;
/*     */   }
/*     */ 
/*     */   public NavMeshQuery NavQuery()
/*     */   {
/* 192 */     return this._navQuery;
/*     */   }
/*     */ 
/*     */   private class PathQuery
/*     */   {
/*     */     public long refId;
/*  19 */     public float[] startPos = new float[3]; public float[] endPos = new float[3];
/*     */     public long startRef;
/*     */     public long endRef;
/*     */     public long[] path;
/*     */     public int npath;
/*     */     public EnumSet<Status> status;
/*     */     public int keepAlive;
/*     */     public QueryFilter filter;
/*     */ 
/*     */     private PathQuery()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.PathQueue
 * JD-Core Version:    0.6.0
 */