/*    */ package atavism.server.pathing.crowd;
/*    */ 
/*    */ public enum MoveRequestState
/*    */ {
/*  6 */   TargetNone, 
/*  7 */   TargetFailed, 
/*  8 */   TargetValid, 
/*  9 */   TargetRequesting, 
/* 10 */   TargetWaitingForQueue, 
/* 11 */   TargetWaitingForPath, 
/* 12 */   TargetVelocity;
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.MoveRequestState
 * JD-Core Version:    0.6.0
 */