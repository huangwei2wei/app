/*     */ package atavism.server.pathing.crowd;
/*     */ 
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class ProximityGrid
/*     */ {
/*     */   private int _maxItems;
/*     */   private float _cellSize;
/*     */   private float _invCellSize;
/*     */   private Item[] _pool;
/*     */   private int _poolHead;
/*     */   private int _poolSize;
/*     */   private int[] _buckets;
/*     */   private int _bucketSize;
/*  29 */   private int[] _bounds = new int[4];
/*     */ 
/*     */   public ProximityGrid()
/*     */   {
/*  33 */     this._maxItems = 0;
/*  34 */     this._cellSize = 0.0F;
/*  35 */     this._pool = null;
/*  36 */     this._poolHead = 0;
/*  37 */     this._poolSize = 0;
/*  38 */     this._buckets = null;
/*  39 */     this._bucketSize = 0;
/*     */   }
/*     */ 
/*     */   public Boolean Init(int poolSize, float cellSize)
/*     */   {
/*     */     try
/*     */     {
/*  46 */       if (poolSize <= 0)
/*  47 */         throw new Exception("Pool Size must be greater than 0");
/*  48 */       if (cellSize <= 0.0F)
/*  49 */         throw new Exception("Cell Size must be greater than 0");
/*     */     }
/*     */     catch (Exception e) {
/*  52 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  55 */     this._cellSize = cellSize;
/*  56 */     this._invCellSize = (1.0F / this._cellSize);
/*  57 */     this._bucketSize = (int)Helper.NextPow2(poolSize);
/*  58 */     this._buckets = new int[this._bucketSize];
/*     */ 
/*  60 */     this._poolSize = poolSize;
/*  61 */     this._poolHead = 0;
/*  62 */     this._pool = new Item[this._poolSize];
/*  63 */     for (int i = 0; i < this._poolSize; i++)
/*     */     {
/*  65 */       this._pool[i] = new Item();
/*     */     }
/*  67 */     Clear();
/*     */ 
/*  69 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public void Clear()
/*     */   {
/*  74 */     for (int i = 0; i < this._bucketSize; i++)
/*     */     {
/*  76 */       this._buckets[i] = 65535;
/*     */     }
/*  78 */     this._poolHead = 0;
/*  79 */     this._bounds[0] = 65535;
/*  80 */     this._bounds[1] = 65535;
/*  81 */     this._bounds[2] = -65535;
/*  82 */     this._bounds[3] = -65535;
/*     */   }
/*     */ 
/*     */   public void AddItem(int id, float minx, float miny, float maxx, float maxy)
/*     */   {
/*  88 */     int iminx = (int)Math.floor(minx * this._invCellSize);
/*  89 */     int iminy = (int)Math.floor(miny * this._invCellSize);
/*  90 */     int imaxx = (int)Math.floor(maxx * this._invCellSize);
/*  91 */     int imaxy = (int)Math.floor(maxy * this._invCellSize);
/*     */ 
/*  93 */     this._bounds[0] = Math.min(this._bounds[0], iminx);
/*  94 */     this._bounds[1] = Math.min(this._bounds[1], iminy);
/*  95 */     this._bounds[2] = Math.min(this._bounds[2], imaxx);
/*  96 */     this._bounds[3] = Math.min(this._bounds[3], imaxy);
/*     */ 
/* 100 */     for (int y = iminy; y <= imaxy; y++)
/*     */     {
/* 102 */       for (int x = iminx; x <= imaxx; x++)
/*     */       {
/* 104 */         if (this._poolHead >= this._poolSize) {
/*     */           continue;
/*     */         }
/* 107 */         int h = HashPos2(x, y, this._bucketSize);
/* 108 */         int idx = this._poolHead;
/* 109 */         this._poolHead += 1;
/* 110 */         Item item = this._pool[idx];
/* 111 */         item.x = (short)x;
/* 112 */         item.y = (short)y;
/* 113 */         item.id = id;
/* 114 */         item.next = this._buckets[h];
/* 115 */         this._buckets[h] = idx;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int QueryItems(float minx, float miny, float maxx, float maxy, int[] ids, int maxIds)
/*     */   {
/* 123 */     int iminx = (int)Math.floor(minx * this._invCellSize);
/* 124 */     int iminy = (int)Math.floor(miny * this._invCellSize);
/* 125 */     int imaxx = (int)Math.floor(maxx * this._invCellSize);
/* 126 */     int imaxy = (int)Math.floor(maxy * this._invCellSize);
/*     */ 
/* 128 */     int n = 0;
/*     */ 
/* 130 */     for (int y = iminy; y <= imaxy; y++)
/*     */     {
/* 132 */       for (int x = iminx; x <= imaxx; x++)
/*     */       {
/* 134 */         int h = HashPos2(x, y, this._bucketSize);
/* 135 */         int idx = this._buckets[h];
/* 136 */         while (idx != 65535)
/*     */         {
/* 138 */           Item item = this._pool[idx];
/* 139 */           if ((item.x == x) && (item.y == y))
/*     */           {
/* 142 */             if (Arrays.toString(ids).matches(".*[\\[ ]" + item.id + "[\\],].*"))
/*     */             {
/* 144 */               if (n >= maxIds)
/* 145 */                 return n;
/* 146 */               ids[(n++)] = item.id;
/*     */             }
/*     */           }
/* 149 */           idx = item.next;
/*     */         }
/*     */       }
/*     */     }
/* 153 */     return n;
/*     */   }
/*     */ 
/*     */   public int GetItemCountAt(int x, int y)
/*     */   {
/* 158 */     int n = 0;
/* 159 */     int h = HashPos2(x, y, this._bucketSize);
/* 160 */     int idx = this._buckets[h];
/* 161 */     while (idx != 65535)
/*     */     {
/* 163 */       Item item = this._pool[idx];
/* 164 */       if ((item.x == x) && (item.y == y))
/* 165 */         n++;
/* 166 */       idx = item.next;
/*     */     }
/*     */ 
/* 169 */     return n;
/*     */   }
/*     */ 
/*     */   public int[] Bounds()
/*     */   {
/* 174 */     return this._bounds;
/*     */   }
/*     */ 
/*     */   public float CellSize()
/*     */   {
/* 179 */     return this._cellSize;
/*     */   }
/*     */ 
/*     */   public int HashPos2(int x, int y, int n)
/*     */   {
/* 184 */     return (x * 73856093 ^ y * 19349663) & n - 1;
/*     */   }
/*     */ 
/*     */   class Item
/*     */   {
/*     */     public int id;
/*     */     public short x;
/*     */     public short y;
/*     */     public int next;
/*     */ 
/*     */     Item()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.ProximityGrid
 * JD-Core Version:    0.6.0
 */