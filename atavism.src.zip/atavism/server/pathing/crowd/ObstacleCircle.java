/*    */ package atavism.server.pathing.crowd;
/*    */ 
/*    */ public class ObstacleCircle
/*    */ {
/*  5 */   public float[] p = new float[3];
/*  6 */   public float[] vel = new float[3];
/*  7 */   public float[] dvel = new float[3];
/*    */   public float rad;
/*  9 */   public float[] dp = new float[3];
/* 10 */   public float[] np = new float[3];
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.ObstacleCircle
 * JD-Core Version:    0.6.0
 */