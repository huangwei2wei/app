/*    */ package atavism.server.pathing.crowd;
/*    */ 
/*    */ public final class dtAllocHint
/*    */ {
/* 13 */   public static final dtAllocHint DT_ALLOC_PERM = new dtAllocHint("DT_ALLOC_PERM");
/* 14 */   public static final dtAllocHint DT_ALLOC_TEMP = new dtAllocHint("DT_ALLOC_TEMP");
/*    */ 
/* 50 */   private static dtAllocHint[] swigValues = { DT_ALLOC_PERM, DT_ALLOC_TEMP };
/* 51 */   private static int swigNext = 0;
/*    */   private final int swigValue;
/*    */   private final String swigName;
/*    */ 
/*    */   public final int swigValue()
/*    */   {
/* 17 */     return this.swigValue;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 21 */     return this.swigName;
/*    */   }
/*    */ 
/*    */   public static dtAllocHint swigToEnum(int swigValue) {
/* 25 */     if ((swigValue < swigValues.length) && (swigValue >= 0) && (swigValues[swigValue].swigValue == swigValue))
/* 26 */       return swigValues[swigValue];
/* 27 */     for (int i = 0; i < swigValues.length; i++)
/* 28 */       if (swigValues[i].swigValue == swigValue)
/* 29 */         return swigValues[i];
/* 30 */     throw new IllegalArgumentException("No enum " + dtAllocHint.class + " with value " + swigValue);
/*    */   }
/*    */ 
/*    */   private dtAllocHint(String swigName) {
/* 34 */     this.swigName = swigName;
/* 35 */     this.swigValue = (swigNext++);
/*    */   }
/*    */ 
/*    */   private dtAllocHint(String swigName, int swigValue) {
/* 39 */     this.swigName = swigName;
/* 40 */     this.swigValue = swigValue;
/* 41 */     swigNext = swigValue + 1;
/*    */   }
/*    */ 
/*    */   private dtAllocHint(String swigName, dtAllocHint swigEnum) {
/* 45 */     this.swigName = swigName;
/* 46 */     this.swigValue = swigEnum.swigValue;
/* 47 */     swigNext = this.swigValue + 1;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.dtAllocHint
 * JD-Core Version:    0.6.0
 */