/*     */ package atavism.server.pathing.crowd;
/*     */ 
/*     */ import atavism.server.objects.Vector2;
/*     */ import atavism.server.pathing.detour.DetourStatusReturn;
/*     */ import atavism.server.pathing.detour.NavMeshBuilder;
/*     */ import atavism.server.pathing.detour.NavMeshQuery;
/*     */ import atavism.server.pathing.detour.QueryFilter;
/*     */ import atavism.server.pathing.recast.Helper;
/*     */ import atavism.server.util.Log;
/*     */ 
/*     */ public class LocalBoundary
/*     */ {
/*  12 */   private final int MaxLocalSegs = 8;
/*  13 */   private final int MaxLocalPolys = 18;
/*     */ 
/*  21 */   private float[] _center = new float[3];
/*  22 */   private Segment[] _segs = new Segment[8];
/*     */   private int _nsegs;
/*  25 */   private long[] _polys = new long[18];
/*     */   private int _npolys;
/*     */ 
/*     */   public LocalBoundary()
/*     */   {
/*  30 */     for (int i = 0; i < 8; i++)
/*     */     {
/*  32 */       this._segs[i] = new Segment();
/*     */     }
/*  34 */     Reset();
/*     */   }
/*     */ 
/*     */   private void AddSegment(float dist, float[] s)
/*     */   {
/*  39 */     Segment seg = null;
/*  40 */     if (this._nsegs <= 0)
/*     */     {
/*  42 */       seg = this._segs[0];
/*     */     }
/*  44 */     else if (dist >= this._segs[(this._nsegs - 1)].d)
/*     */     {
/*  46 */       if (this._nsegs >= 8)
/*  47 */         return;
/*  48 */       seg = this._segs[this._nsegs];
/*     */     }
/*     */     else
/*     */     {
/*  54 */       for (int i = 0; i < this._nsegs; i++)
/*     */       {
/*  56 */         if (dist <= this._segs[i].d) {
/*     */           break;
/*     */         }
/*     */       }
/*  60 */       int tgt = i + 1;
/*  61 */       int n = Math.min(this._nsegs - i, 8 - tgt);
/*  62 */       if (n < 0)
/*     */       {
/*  64 */         System.arraycopy(this._segs, i, this._segs, tgt, n);
/*     */       }
/*     */ 
/*  67 */       seg = this._segs[i];
/*     */     }
/*     */ 
/*  70 */     seg.d = dist;
/*  71 */     System.arraycopy(s, 0, seg.s, 0, 6);
/*     */ 
/*  73 */     if (this._nsegs < 8)
/*  74 */       this._nsegs += 1;
/*     */   }
/*     */ 
/*     */   public void Reset()
/*     */   {
/*  79 */     this._nsegs = 0;
/*  80 */     this._npolys = 0;
/*     */ 
/*  82 */     Helper.VSet(this._center, 3.4028235E+38F, 3.4028235E+38F, 3.4028235E+38F);
/*     */   }
/*     */ 
/*     */   public void Update(long refId, float[] pos, float collisionQueryRange, NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/*  87 */     int MaxSegsPerPoly = NavMeshBuilder.VertsPerPoly * 3;
/*     */ 
/*  89 */     if (refId <= 0L)
/*     */     {
/*  91 */       Reset();
/*  92 */       return;
/*     */     }
/*     */ 
/*  95 */     Helper.VCopy(this._center, pos);
/*  96 */     long[] parentPoly = null;
/*  97 */     this._npolys = navQuery.FindLocalNeighbourhood(refId, pos, collisionQueryRange, filter, this._polys, parentPoly, 18).intValue;
/*     */ 
/*  99 */     this._nsegs = 0;
/* 100 */     float[] segs = new float[MaxSegsPerPoly * 6];
/* 101 */     int nsegs = 0;
/* 102 */     long[] parentrefs = null;
/* 103 */     for (int j = 0; j < this._npolys; j++)
/*     */     {
/* 105 */       nsegs = navQuery.GetPolyWallSegments(this._polys[j], filter, segs, parentrefs, MaxSegsPerPoly).intValue;
/* 106 */       for (int k = 0; k < nsegs; k++)
/*     */       {
/* 108 */         int s = k * 6;
/*     */ 
/* 110 */         Vector2 distSqr = Helper.DistancePtSegSqr2D(pos[0], pos[1], pos[2], segs[(s + 0)], segs[(s + 1)], segs[(s + 2)], segs[(s + 3)], segs[(s + 4)], segs[(s + 5)]);
/*     */ 
/* 112 */         if (distSqr.x > collisionQueryRange * collisionQueryRange)
/*     */           continue;
/* 114 */         float[] tempS = new float[6];
/* 115 */         System.arraycopy(segs, s, tempS, 0, 6);
/* 116 */         Log.debug("Adding segment");
/* 117 */         AddSegment((float)distSqr.x, tempS);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Boolean IsValid(NavMeshQuery navQuery, QueryFilter filter)
/*     */   {
/* 124 */     if (this._npolys <= 0) {
/* 125 */       return Boolean.valueOf(false);
/*     */     }
/* 127 */     for (int i = 0; i < this._npolys; i++)
/*     */     {
/* 130 */       if (!navQuery.IsValidPolyRef(this._polys[i], filter).booleanValue())
/* 131 */         return Boolean.valueOf(false);
/*     */     }
/* 133 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   public float[] getCenter()
/*     */   {
/* 138 */     return this._center;
/*     */   }
/*     */ 
/*     */   public int SegmentCount()
/*     */   {
/* 143 */     return this._nsegs;
/*     */   }
/*     */ 
/*     */   public float[] GetSegment(int i)
/*     */   {
/* 148 */     return this._segs[i].s;
/*     */   }
/*     */ 
/*     */   class Segment
/*     */   {
/*  17 */     public float[] s = new float[6];
/*     */     public float d;
/*     */ 
/*     */     Segment()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.LocalBoundary
 * JD-Core Version:    0.6.0
 */