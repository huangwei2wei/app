package atavism.server.pathing.crowd;

public class CrowdBuilder
{
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.CrowdBuilder
 * JD-Core Version:    0.6.0
 */