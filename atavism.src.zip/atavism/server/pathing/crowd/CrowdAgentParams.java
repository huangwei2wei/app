package atavism.server.pathing.crowd;

public class CrowdAgentParams
{
  public float Radius;
  public float Height;
  public float MaxAcceleration;
  public float MaxSpeed;
  public float CollisionQueryRange;
  public float PathOptimizationRange;
  public float SeparationWeight;
  public UpdateFlags UpdateFlags;
  public short ObstacleAvoidanceType;
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.crowd.CrowdAgentParams
 * JD-Core Version:    0.6.0
 */