/*    */ package atavism.server.pathing;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.math.Point;
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class PathInterpolator
/*    */ {
/*    */   protected OID oid;
/*    */   protected float speed;
/*    */   protected String terrainString;
/*    */   protected List<Point> path;
/*    */   protected float totalTime;
/*    */   protected long startTime;
/*    */ 
/*    */   public PathInterpolator(OID oid, long startTime, float speed, String terrainString, List<Point> path)
/*    */   {
/* 11 */     this.oid = oid;
/* 12 */     this.startTime = startTime;
/* 13 */     this.speed = speed;
/* 14 */     this.terrainString = terrainString;
/* 15 */     this.path = path;
/*    */   }
/*    */   public abstract String toString();
/*    */ 
/*    */   public abstract PathLocAndDir interpolate(float paramFloat);
/*    */ 
/* 23 */   public PathLocAndDir interpolate(long systemTime) { return interpolate((float)(systemTime - this.startTime) / 1000.0F);
/*    */   }
/*    */ 
/*    */   public Point zeroYIfOnTerrain(AOVector loc, int pointIndex)
/*    */   {
/* 31 */     Point iloc = new Point(loc);
/*    */ 
/* 34 */     return iloc;
/*    */   }
/*    */ 
/*    */   public OID getOid() {
/* 38 */     return this.oid;
/*    */   }
/*    */ 
/*    */   public float getSpeed() {
/* 42 */     return this.speed;
/*    */   }
/*    */ 
/*    */   public String getTerrainString() {
/* 46 */     return this.terrainString;
/*    */   }
/*    */ 
/*    */   public long getStartTime() {
/* 50 */     return this.startTime;
/*    */   }
/*    */ 
/*    */   public float getTotalTime() {
/* 54 */     return this.totalTime;
/*    */   }
/*    */ 
/*    */   public Point getLastPoint() {
/* 58 */     int len = this.path.size();
/* 59 */     if (len > 0) {
/* 60 */       return (Point)this.path.get(len - 1);
/*    */     }
/* 62 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathInterpolator
 * JD-Core Version:    0.6.0
 */