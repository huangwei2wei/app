/*      */ package atavism.server.pathing;
/*      */ 
/*      */ import atavism.server.math.AOVector;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.Logger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ 
/*      */ public class Triangulate
/*      */ {
/*      */   protected static final Logger log;
/*      */   static boolean debugProfileTriangulate;
/*      */   private static final long serialVersionUID = 1L;
/*      */ 
/*      */   public List<PathPolygon> computeTriangulation(String description, PathPolygon boundary, List<PathPolygon> obstacles)
/*      */   {
/*   40 */     log.info(description + " boundary: " + boundary);
/*   41 */     dumpPolygons(description + " obstacles:", obstacles);
/*   42 */     ArrayList result = new ArrayList();
/*   43 */     int pathCount = obstacles.size() + 1;
/*   44 */     ArrayList paths = new ArrayList();
/*   45 */     List allPaths = new LinkedList();
/*   46 */     allPaths.add(boundary);
/*   47 */     allPaths.addAll(obstacles);
/*   48 */     for (PathPolygon p : allPaths) {
/*   49 */       List corners = p.getCorners();
/*   50 */       path = new float[corners.size() * 2];
/*   51 */       paths.add(path);
/*   52 */       i = 0;
/*   53 */       for (AOVector vert : corners) {
/*   54 */         path[(i++)] = vert.getX();
/*   55 */         path[(i++)] = vert.getZ();
/*      */       }
/*      */     }
/*      */     float[] path;
/*      */     int i;
/*   58 */     PolyEnv env = new PolyEnv();
/*   59 */     env.computeTriangulation(result, pathCount, paths, 0, null);
/*      */ 
/*   62 */     int polyIndex = 1;
/*   63 */     List resultPolys = new LinkedList();
/*   64 */     for (int i = 0; i < result.size(); i += 6) {
/*   65 */       List corners = new ArrayList(3);
/*   66 */       corners.add(new AOVector(((Float)result.get(i)).floatValue(), 0.0F, ((Float)result.get(i + 1)).floatValue()));
/*   67 */       corners.add(new AOVector(((Float)result.get(i + 2)).floatValue(), 0.0F, ((Float)result.get(i + 3)).floatValue()));
/*   68 */       corners.add(new AOVector(((Float)result.get(i + 4)).floatValue(), 0.0F, ((Float)result.get(i + 5)).floatValue()));
/*   69 */       resultPolys.add(new PathPolygon(polyIndex++, 1, corners));
/*      */     }
/*   71 */     dumpPolygons(description + " results:", resultPolys);
/*   72 */     return resultPolys;
/*      */   }
/*      */ 
/*      */   static void dumpPolygons(String description, List<PathPolygon> polygons) {
/*   76 */     log.info(description + ": " + polygons.size() + " polygons");
/*   77 */     for (PathPolygon poly : polygons)
/*   78 */       log.info(description + ": Polygon " + poly);
/*      */   }
/*      */ 
/*      */   static double determinantFloat(AOVector a, AOVector b, AOVector c) {
/*   82 */     double fact11 = b.getX() - a.getX();
/*   83 */     double fact12 = c.getZ() - a.getZ();
/*   84 */     double fact21 = b.getZ() - a.getZ();
/*   85 */     double fact22 = c.getX() - a.getX();
/*   86 */     return fact11 * fact12 - fact21 * fact22;
/*      */   }
/*      */ 
/*      */   static boolean coordEquals(AOVector v1, AOVector v2) {
/*   90 */     return AOVector.distanceToSquared(v1, v2) < 0.01F;
/*      */   }
/*      */ 
/*      */   static boolean indexPointFloatEquals(IndexPointFloat p1, IndexPointFloat p2) {
/*   94 */     return (Math.abs(p1.x - p2.x) < 0.01F) && (Math.abs(p1.z - p2.z) < 0.01F);
/*      */   }
/*      */ 
/*      */   static boolean indexBoxFloatEquals(IndexBoxFloat p1, IndexBoxFloat p2) {
/*   98 */     return (indexPointFloatEquals(p1.min, p2.min)) && (indexPointFloatEquals(p1.max, p2.min));
/*      */   }
/*      */ 
/*      */   int vertexLeftTest(AOVector a, AOVector b, AOVector c)
/*      */   {
/*  105 */     double det = determinantFloat(a, b, c);
/*  106 */     if (det > 0.0D) return 1;
/*  107 */     if (det < 0.0D) return -1;
/*  108 */     return 0;
/*      */   }
/*      */ 
/*      */   int iclamp(int v, int lo, int high) {
/*  112 */     return Math.max(lo, Math.min(high, v));
/*      */   }
/*      */ 
/*      */   boolean vertexInEar(AOVector v, AOVector a, AOVector b, AOVector c)
/*      */   {
/*  118 */     assert (vertexLeftTest(b, a, c) <= 0);
/*      */ 
/*  120 */     if ((coordEquals(v, a)) || (coordEquals(v, c)))
/*      */     {
/*  122 */       return false;
/*      */     }
/*      */ 
/*  125 */     boolean abIn = vertexLeftTest(a, b, v) >= 0;
/*  126 */     boolean bcIn = vertexLeftTest(b, c, v) >= 0;
/*  127 */     boolean caIn = vertexLeftTest(c, a, v) >= 0;
/*      */ 
/*  129 */     return (abIn) && (bcIn) && (caIn);
/*      */   }
/*      */ 
/*      */   int remapIndexForDupedVerts(int index, int dupedV0, int dupedV1)
/*      */   {
/*  135 */     assert (dupedV0 < dupedV1);
/*  136 */     if (index <= dupedV0)
/*      */     {
/*  138 */       return index;
/*  139 */     }if (index <= dupedV1)
/*      */     {
/*  141 */       return index + 1;
/*      */     }
/*      */ 
/*  144 */     return index + 2;
/*      */   }
/*      */ 
/*      */   int compareVertices(PolyVert vertA, PolyVert vertB)
/*      */   {
/*  149 */     if (vertA.v.getX() < vertB.v.getX())
/*  150 */       return -1;
/*  151 */     if (vertA.v.getX() > vertB.v.getX()) {
/*  152 */       return 1;
/*      */     }
/*  154 */     if (vertA.v.getZ() < vertB.v.getZ())
/*  155 */       return -1;
/*  156 */     if (vertA.v.getZ() > vertB.v.getZ()) {
/*  157 */       return 1;
/*      */     }
/*  159 */     return 0;
/*      */   }
/*      */ 
/*      */   boolean edgesIntersectSub(ArrayList<PolyVert> sortedVerts, int e0v0i, int e0v1i, int e1v0i, int e1v1i)
/*      */   {
/*  875 */     AOVector e0v0 = ((PolyVert)sortedVerts.get(e0v0i)).v;
/*  876 */     AOVector e0v1 = ((PolyVert)sortedVerts.get(e0v1i)).v;
/*  877 */     AOVector e1v0 = ((PolyVert)sortedVerts.get(e1v0i)).v;
/*  878 */     AOVector e1v1 = ((PolyVert)sortedVerts.get(e1v1i)).v;
/*      */ 
/*  884 */     if ((e0v0.getX() == e0v1.getX()) && (e0v0.getZ() == e0v1.getZ()))
/*      */     {
/*  886 */       if ((e1v0.getX() == e1v1.getX()) && (e1v0.getZ() == e1v1.getZ()))
/*      */       {
/*  889 */         return (e0v0.getX() == e1v0.getX()) && (e0v0.getZ() == e1v0.getZ());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  894 */     double det10 = determinantFloat(e0v0, e0v1, e1v0);
/*  895 */     double det11 = determinantFloat(e0v0, e0v1, e1v1);
/*      */ 
/*  903 */     if (det10 * det11 > 0.0D)
/*      */     {
/*  905 */       return false;
/*      */     }
/*      */ 
/*  908 */     double det00 = determinantFloat(e1v0, e1v1, e0v0);
/*  909 */     double det01 = determinantFloat(e1v0, e1v1, e0v1);
/*      */ 
/*  913 */     return det00 * det01 <= 0.0D;
/*      */   }
/*      */ 
/*      */   boolean edgesIntersect(ArrayList<PolyVert> sortedVerts, int e0v0, int e0v1, int e1v0, int e1v1)
/*      */   {
/*  930 */     boolean[][] coincident = new boolean[2][2];
/*  931 */     coincident[0][0] = coordEquals(((PolyVert)sortedVerts.get(e0v0)).v, ((PolyVert)sortedVerts.get(e1v0)).v);
/*  932 */     coincident[0][1] = coordEquals(((PolyVert)sortedVerts.get(e0v0)).v, ((PolyVert)sortedVerts.get(e1v1)).v);
/*  933 */     coincident[1][0] = coordEquals(((PolyVert)sortedVerts.get(e0v1)).v, ((PolyVert)sortedVerts.get(e1v0)).v);
/*  934 */     coincident[1][1] = coordEquals(((PolyVert)sortedVerts.get(e0v1)).v, ((PolyVert)sortedVerts.get(e1v1)).v);
/*  935 */     if ((coincident[0][0] != 0) && (coincident[1][1] == 0)) return false;
/*  936 */     if ((coincident[1][0] != 0) && (coincident[0][1] == 0)) return false;
/*  937 */     if ((coincident[0][1] != 0) && (coincident[1][0] == 0)) return false;
/*  938 */     if ((coincident[1][1] != 0) && (coincident[0][0] == 0)) return false;
/*      */ 
/*  951 */     return edgesIntersectSub(sortedVerts, e0v0, e0v1, e1v0, e1v1);
/*      */   }
/*      */ 
/*      */   boolean isConvexVert(ArrayList<PolyVert> sortedVerts, int vi)
/*      */   {
/*  959 */     PolyVert pvi = (PolyVert)sortedVerts.get(vi);
/*  960 */     PolyVert pvPrev = (PolyVert)sortedVerts.get(pvi.prev);
/*  961 */     PolyVert pvNext = (PolyVert)sortedVerts.get(pvi.next);
/*  962 */     return vertexLeftTest(pvPrev.v, pvi.v, pvNext.v) > 0;
/*      */   }
/*      */ 
/*      */   int comparePolysByLeftmostVert(TriPoly polyA, TriPoly polyB)
/*      */   {
/*  969 */     if (polyA.leftmostVert < polyB.leftmostVert) {
/*  970 */       return -1;
/*      */     }
/*      */ 
/*  974 */     assert (polyA.leftmostVert > polyB.leftmostVert);
/*  975 */     return 1;
/*      */   }
/*      */ 
/*      */   private static void test1(Triangulate triangulator)
/*      */   {
/* 2576 */     log.info("PathSynth.main: Starting test1");
/*      */ 
/* 2578 */     List corners = new LinkedList();
/* 2579 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2580 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2581 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2582 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2583 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2585 */     List obstacles = new LinkedList();
/* 2586 */     corners = new LinkedList();
/* 2587 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2588 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2589 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2590 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2591 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2592 */     triangulator.computeTriangulation("test1", boundary, obstacles);
/* 2593 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test2(Triangulate triangulator) {
/* 2597 */     log.info("PathSynth.main: Starting test2");
/*      */ 
/* 2599 */     List corners = new LinkedList();
/* 2600 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2601 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2602 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2603 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2604 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2606 */     List obstacles = new LinkedList();
/* 2607 */     corners = new LinkedList();
/* 2608 */     corners.add(new AOVector(500.0F, 0.0F, 250.0F));
/* 2609 */     corners.add(new AOVector(250.0F, 0.0F, 500.0F));
/* 2610 */     corners.add(new AOVector(500.0F, 0.0F, 750.0F));
/* 2611 */     corners.add(new AOVector(750.0F, 0.0F, 500.0F));
/* 2612 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2613 */     triangulator.computeTriangulation("test2", boundary, obstacles);
/* 2614 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test3(Triangulate triangulator) {
/* 2618 */     log.info("PathSynth.main: Starting test3");
/*      */ 
/* 2620 */     List corners = new LinkedList();
/* 2621 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2622 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2623 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2624 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2625 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2627 */     List obstacles = new LinkedList();
/* 2628 */     corners = new LinkedList();
/* 2629 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2630 */     corners.add(new AOVector(200.0F, 0.0F, 400.0F));
/* 2631 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2632 */     corners.add(new AOVector(500.0F, 0.0F, 800.0F));
/* 2633 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2634 */     corners.add(new AOVector(800.0F, 0.0F, 500.0F));
/* 2635 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2636 */     corners.add(new AOVector(250.0F, 0.0F, 200.0F));
/* 2637 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2638 */     triangulator.computeTriangulation("test3", boundary, obstacles);
/* 2639 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test4(Triangulate triangulator)
/*      */   {
/* 2646 */     log.info("PathSynth.main: Starting test4");
/*      */ 
/* 2648 */     List corners = new LinkedList();
/* 2649 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2650 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2651 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2652 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2653 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2655 */     List obstacles = new LinkedList();
/* 2656 */     corners = new LinkedList();
/* 2657 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2658 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2659 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2660 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2661 */     corners.add(new AOVector(500.0F, 0.0F, 500.0F));
/* 2662 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2663 */     triangulator.computeTriangulation("test4", boundary, obstacles);
/* 2664 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test5(Triangulate triangulator)
/*      */   {
/* 2671 */     log.info("PathSynth.main: Starting test5");
/*      */ 
/* 2673 */     List corners = new LinkedList();
/* 2674 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2675 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2676 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2677 */     corners.add(new AOVector(0.5F, 0.0F, 1.25F));
/* 2678 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2679 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2681 */     List obstacles = new LinkedList();
/* 2682 */     corners = new LinkedList();
/* 2683 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2684 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2685 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2686 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2687 */     corners.add(new AOVector(500.0F, 0.0F, 500.0F));
/* 2688 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2689 */     triangulator.computeTriangulation("test5", boundary, obstacles);
/* 2690 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test6(Triangulate triangulator)
/*      */   {
/* 2697 */     log.info("PathSynth.main: Starting test6");
/*      */ 
/* 2699 */     List corners = new LinkedList();
/* 2700 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2701 */     corners.add(new AOVector(500.0F, 0.0F, 250.0F));
/* 2702 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2703 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2704 */     corners.add(new AOVector(500.0F, 0.0F, 1250.0F));
/* 2705 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2706 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2708 */     List obstacles = new LinkedList();
/* 2709 */     corners = new LinkedList();
/* 2710 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2711 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2712 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2713 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2714 */     corners.add(new AOVector(500.0F, 0.0F, 500.0F));
/* 2715 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2716 */     triangulator.computeTriangulation("test6", boundary, obstacles);
/* 2717 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test7(Triangulate triangulator)
/*      */   {
/* 2726 */     log.info("PathSynth.main: Starting test7");
/*      */ 
/* 2728 */     List corners = new LinkedList();
/* 2729 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2730 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2731 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2732 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2733 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2735 */     List obstacles = new LinkedList();
/* 2736 */     corners = new LinkedList();
/* 2737 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2738 */     corners.add(new AOVector(250.0F, 0.0F, 1250.0F));
/* 2739 */     corners.add(new AOVector(750.0F, 0.0F, 1250.0F));
/* 2740 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2741 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2742 */     triangulator.computeTriangulation("test7", boundary, obstacles);
/* 2743 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test8(Triangulate triangulator)
/*      */   {
/* 2751 */     log.info("PathSynth.main: Starting test8");
/*      */ 
/* 2753 */     List corners = new LinkedList();
/* 2754 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2755 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2756 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2757 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2758 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2760 */     List obstacles = new LinkedList();
/* 2761 */     corners = new LinkedList();
/* 2762 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2763 */     corners.add(new AOVector(0.25F, 0.0F, 1.0F));
/* 2764 */     corners.add(new AOVector(0.75F, 0.0F, 1.0F));
/* 2765 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2766 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2767 */     triangulator.computeTriangulation("test8", boundary, obstacles);
/* 2768 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test9(Triangulate triangulator)
/*      */   {
/* 2773 */     log.info("PathSynth.main: Starting test9");
/*      */ 
/* 2775 */     List corners = new LinkedList();
/* 2776 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2777 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2778 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2779 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2780 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2782 */     List obstacles = new LinkedList();
/* 2783 */     corners = new LinkedList();
/* 2784 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2785 */     corners.add(new AOVector(250.0F, 0.0F, 400.0F));
/* 2786 */     corners.add(new AOVector(750.0F, 0.0F, 400.0F));
/* 2787 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2788 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2789 */     corners = new LinkedList();
/* 2790 */     corners.add(new AOVector(250.0F, 0.0F, 500.0F));
/* 2791 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2792 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2793 */     corners.add(new AOVector(750.0F, 0.0F, 500.0F));
/* 2794 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2795 */     triangulator.computeTriangulation("test9", boundary, obstacles);
/* 2796 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test10(Triangulate triangulator)
/*      */   {
/* 2801 */     log.info("PathSynth.main: Starting test10");
/*      */ 
/* 2803 */     List corners = new LinkedList();
/* 2804 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2805 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2806 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2807 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2808 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2810 */     List obstacles = new LinkedList();
/* 2811 */     corners = new LinkedList();
/* 2812 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2813 */     corners.add(new AOVector(250.0F, 0.0F, 500.0F));
/* 2814 */     corners.add(new AOVector(750.0F, 0.0F, 500.0F));
/* 2815 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2816 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2817 */     corners = new LinkedList();
/* 2818 */     corners.add(new AOVector(250.0F, 0.0F, 400.0F));
/* 2819 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2820 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2821 */     corners.add(new AOVector(750.0F, 0.0F, 400.0F));
/* 2822 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2823 */     triangulator.computeTriangulation("test10", boundary, obstacles);
/* 2824 */     log.info("");
/*      */   }
/*      */ 
/*      */   private static void test11(Triangulate triangulator)
/*      */   {
/* 2829 */     log.info("PathSynth.main: Starting test11");
/*      */ 
/* 2831 */     List corners = new LinkedList();
/* 2832 */     corners.add(new AOVector(0.0F, 0.0F, 0.0F));
/* 2833 */     corners.add(new AOVector(1.0F, 0.0F, 0.0F));
/* 2834 */     corners.add(new AOVector(1.0F, 0.0F, 1.0F));
/* 2835 */     corners.add(new AOVector(0.0F, 0.0F, 1.0F));
/* 2836 */     PathPolygon boundary = new PathPolygon(0, 1, corners);
/*      */ 
/* 2838 */     List obstacles = new LinkedList();
/* 2839 */     corners = new LinkedList();
/* 2840 */     corners.add(new AOVector(250.0F, 0.0F, 250.0F));
/* 2841 */     corners.add(new AOVector(250.0F, 0.0F, 500.0F));
/* 2842 */     corners.add(new AOVector(750.0F, 0.0F, 500.0F));
/* 2843 */     corners.add(new AOVector(750.0F, 0.0F, 250.0F));
/* 2844 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2845 */     corners = new LinkedList();
/* 2846 */     corners.add(new AOVector(250.0F, 0.0F, 500.0F));
/* 2847 */     corners.add(new AOVector(250.0F, 0.0F, 750.0F));
/* 2848 */     corners.add(new AOVector(750.0F, 0.0F, 750.0F));
/* 2849 */     corners.add(new AOVector(750.0F, 0.0F, 500.0F));
/* 2850 */     obstacles.add(new PathPolygon(0, 1, corners));
/* 2851 */     triangulator.computeTriangulation("test11", boundary, obstacles);
/* 2852 */     log.info("");
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/* 2864 */     Properties props = new Properties();
/* 2865 */     props.put("log4j.appender.FILE", "org.apache.log4j.RollingFileAppender");
/* 2866 */     props.put("log4j.appender.FILE.File", "${atavism.logs}/pathing.out");
/* 2867 */     props.put("log4j.appender.FILE.MaxFileSize", "50MB");
/* 2868 */     props.put("log4j.appender.FILE.layout", "org.apache.log4j.PatternLayout");
/* 2869 */     props.put("log4j.appender.FILE.layout.ConversionPattern", "%-5p %m%n");
/* 2870 */     props.put("atavism.log_level", "0");
/* 2871 */     props.put("log4j.rootLogger", "DEBUG, FILE");
/* 2872 */     Log.init(props);
/* 2873 */     Triangulate triangulator = new Triangulate();
/*      */ 
/* 2877 */     test1(triangulator);
/* 2878 */     test2(triangulator);
/* 2879 */     test3(triangulator);
/* 2880 */     test4(triangulator);
/* 2881 */     test5(triangulator);
/* 2882 */     test6(triangulator);
/* 2883 */     test7(triangulator);
/* 2884 */     test8(triangulator);
/* 2885 */     test9(triangulator);
/* 2886 */     test10(triangulator);
/* 2887 */     test11(triangulator);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   35 */     log = new Logger("Triangulate");
/*      */ 
/*   37 */     debugProfileTriangulate = true;
/*      */   }
/*      */   public class PolyEnv {
/* 2028 */     ArrayList<Triangulate.PolyVert> sortedVerts = new ArrayList();
/* 2029 */     ArrayList<Triangulate.TriPoly> polys = new ArrayList();
/*      */     Triangulate.IndexBoxFloat bound;
/*      */     int estimatedTriangleCount;
/*      */ 
/* 2035 */     public PolyEnv() { this.bound = new Triangulate.IndexBoxFloat(Triangulate.this, new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F), new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F));
/* 2036 */       this.estimatedTriangleCount = 0;
/*      */     }
/*      */ 
/*      */     public void init(int pathCount, ArrayList<float[]> paths)
/*      */     {
/* 2043 */       assert (this.sortedVerts.size() == 0);
/* 2044 */       assert (this.polys.size() == 0);
/*      */ 
/* 2047 */       int vertCount = 0;
/* 2048 */       for (int i = 0; i < pathCount; i++) {
/* 2049 */         vertCount += ((float[])paths.get(i)).length;
/*      */       }
/*      */ 
/* 2053 */       this.estimatedTriangleCount = vertCount;
/*      */ 
/* 2056 */       this.sortedVerts.ensureCapacity(vertCount + (pathCount - 1) * 2);
/* 2057 */       this.polys.ensureCapacity(pathCount);
/*      */ 
/* 2059 */       for (int i = 0; i < pathCount; i++)
/*      */       {
/* 2061 */         float[] path = (float[])paths.get(i);
/*      */ 
/* 2063 */         if (path.length < 3)
/*      */         {
/*      */           continue;
/*      */         }
/* 2067 */         Triangulate.TriPoly p = new Triangulate.TriPoly(Triangulate.this);
/* 2068 */         this.polys.add(p);
/*      */ 
/* 2071 */         int pathSize = path.length;
/* 2072 */         if ((path.length & 0x1) != 0)
/*      */         {
/* 2074 */           if (!$assertionsDisabled) throw new AssertionError();
/* 2075 */           Triangulate.log.error("pathEnv.init: path[" + i + "] has odd number of coords (" + path.length + ", dropping last value");
/* 2076 */           pathSize--;
/*      */         }
/* 2078 */         for (int j = 0; j < pathSize; j += 2) {
/* 2079 */           int prevPoint = j - 2;
/* 2080 */           if (j == 0) {
/* 2081 */             prevPoint = pathSize - 2;
/*      */           }
/* 2083 */           if ((path[j] == path[prevPoint]) && (path[(j + 1)] == path[(prevPoint + 1)]))
/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 2088 */           int vertIndex = this.sortedVerts.size();
/*      */ 
/* 2090 */           Triangulate.PolyVert vert = new Triangulate.PolyVert(Triangulate.this, path[j], path[(j + 1)], p, vertIndex);
/* 2091 */           this.sortedVerts.add(vert);
/*      */ 
/* 2093 */           p.appendVert(this.sortedVerts, vertIndex);
/*      */ 
/* 2095 */           Triangulate.IndexPointFloat ip = new Triangulate.IndexPointFloat(Triangulate.this, vert.v.getX(), vert.v.getZ());
/* 2096 */           if (vertIndex == 0)
/*      */           {
/* 2098 */             this.bound.min = ip;
/* 2099 */             this.bound.max = ((Triangulate.IndexPointFloat)ip.clone());
/*      */           }
/*      */           else
/*      */           {
/* 2103 */             this.bound.expandToEnclose(ip);
/* 2104 */           }assert (this.bound.containsPoint(ip));
/*      */         }
/* 2106 */         assert (p.isValid(this.sortedVerts));
/*      */ 
/* 2108 */         if (p.vertexCount != 0)
/*      */           continue;
/* 2110 */         this.polys.remove(this.polys.size() - 1);
/*      */       }
/*      */ 
/* 2115 */       Collections.sort(this.sortedVerts);
/* 2116 */       assert ((this.sortedVerts.size() <= 1) || (Triangulate.this.compareVertices((Triangulate.PolyVert)this.sortedVerts.get(0), (Triangulate.PolyVert)this.sortedVerts.get(1)) <= 0));
/*      */ 
/* 2123 */       int[] vertRemap = new int[this.sortedVerts.size()];
/* 2124 */       int i = 0; for (int n = this.sortedVerts.size(); i < n; i++) {
/* 2125 */         int newIndex = i;
/* 2126 */         int originalIndex = ((Triangulate.PolyVert)this.sortedVerts.get(newIndex)).myIndex;
/* 2127 */         vertRemap[originalIndex] = newIndex;
/*      */       }
/* 2129 */       int i = 0; for (int n = this.sortedVerts.size(); i < n; i++)
/* 2130 */         ((Triangulate.PolyVert)this.sortedVerts.get(i)).remap(vertRemap);
/* 2131 */       int i = 0; for (int n = this.polys.size(); i < n; i++) {
/* 2132 */         ((Triangulate.TriPoly)this.polys.get(i)).remap(vertRemap);
/* 2133 */         assert (((Triangulate.TriPoly)this.polys.get(i)).isValid(this.sortedVerts));
/*      */       }
/*      */     }
/*      */ 
/*      */     int getEstimatedTriangleCount() {
/* 2138 */       return this.estimatedTriangleCount;
/*      */     }
/*      */ 
/*      */     public void joinPathsIntoOnePoly()
/*      */     {
/* 2148 */       if (this.polys.size() > 1)
/*      */       {
/* 2150 */         Collections.sort(this.polys);
/* 2151 */         assert ((this.polys.size() <= 1) || (Triangulate.this.comparePolysByLeftmostVert((Triangulate.TriPoly)this.polys.get(0), (Triangulate.TriPoly)this.polys.get(1)) == -1));
/*      */ 
/* 2157 */         Triangulate.TriPoly fullPoly = (Triangulate.TriPoly)this.polys.get(0);
/*      */ 
/* 2159 */         fullPoly.initEdgeIndex(this.sortedVerts, this.bound);
/*      */ 
/* 2162 */         while (this.polys.size() > 1) {
/* 2163 */           int v1 = ((Triangulate.TriPoly)this.polys.get(1)).leftmostVert;
/*      */ 
/* 2173 */           int v2 = fullPoly.findValidBridgeVert(this.sortedVerts, v1);
/*      */ 
/* 2178 */           assert (((Triangulate.PolyVert)this.sortedVerts.get(v2)).polyOwner == this.polys.get(0));
/* 2179 */           assert (((Triangulate.PolyVert)this.sortedVerts.get(v1)).polyOwner == this.polys.get(1));
/* 2180 */           joinPathsWithBridge(fullPoly, (Triangulate.TriPoly)this.polys.get(1), v2, v1);
/*      */ 
/* 2183 */           this.polys.remove(1);
/*      */         }
/*      */       }
/*      */ 
/* 2187 */       ((Triangulate.TriPoly)this.polys.get(0)).initForEarClipping(this.sortedVerts);
/*      */ 
/* 2189 */       assert (this.polys.size() == 1);
/*      */     }
/*      */ 
/*      */     public void joinPathsWithBridge(Triangulate.TriPoly mainPoly, Triangulate.TriPoly subPoly, int vertOnMainPoly, int vertOnSubPoly)
/*      */     {
/* 2196 */       assert (vertOnMainPoly != vertOnSubPoly);
/* 2197 */       assert (mainPoly != null);
/* 2198 */       assert (subPoly != null);
/* 2199 */       assert (mainPoly != subPoly);
/* 2200 */       assert (mainPoly == ((Triangulate.PolyVert)this.sortedVerts.get(vertOnMainPoly)).polyOwner);
/* 2201 */       assert (subPoly == ((Triangulate.PolyVert)this.sortedVerts.get(vertOnSubPoly)).polyOwner);
/*      */ 
/* 2203 */       if (Triangulate.coordEquals(((Triangulate.PolyVert)this.sortedVerts.get(vertOnMainPoly)).v, ((Triangulate.PolyVert)this.sortedVerts.get(vertOnSubPoly)).v))
/*      */       {
/* 2208 */         Triangulate.PolyVert pvMain = (Triangulate.PolyVert)this.sortedVerts.get(vertOnMainPoly);
/* 2209 */         Triangulate.PolyVert pvSub = (Triangulate.PolyVert)this.sortedVerts.get(vertOnSubPoly);
/*      */ 
/* 2211 */         int mainNext = pvMain.next;
/*      */ 
/* 2214 */         mainPoly.removeEdge(this.sortedVerts, vertOnMainPoly);
/*      */ 
/* 2216 */         pvMain.next = pvSub.next;
/* 2217 */         ((Triangulate.PolyVert)this.sortedVerts.get(pvMain.next)).prev = vertOnMainPoly;
/*      */ 
/* 2219 */         pvSub.next = mainNext;
/* 2220 */         ((Triangulate.PolyVert)this.sortedVerts.get(mainNext)).prev = vertOnSubPoly;
/*      */ 
/* 2223 */         mainPoly.addEdge(this.sortedVerts, vertOnMainPoly);
/*      */ 
/* 2226 */         mainPoly.updateConnectedSubPoly(this.sortedVerts, pvMain.next, mainNext);
/* 2227 */         subPoly.invalidate(this.sortedVerts);
/*      */ 
/* 2229 */         return;
/*      */       }
/*      */ 
/* 2233 */       dupeTwoVerts(vertOnMainPoly, vertOnSubPoly);
/*      */ 
/* 2236 */       if (vertOnSubPoly < vertOnMainPoly)
/* 2237 */         vertOnMainPoly++;
/*      */       else {
/* 2239 */         vertOnSubPoly++;
/*      */       }
/* 2241 */       Triangulate.PolyVert pvMain = (Triangulate.PolyVert)this.sortedVerts.get(vertOnMainPoly);
/* 2242 */       Triangulate.PolyVert pvSub = (Triangulate.PolyVert)this.sortedVerts.get(vertOnSubPoly);
/* 2243 */       Triangulate.PolyVert pvMain2 = (Triangulate.PolyVert)this.sortedVerts.get(vertOnMainPoly + 1);
/* 2244 */       Triangulate.PolyVert pvSub2 = (Triangulate.PolyVert)this.sortedVerts.get(vertOnSubPoly + 1);
/*      */ 
/* 2247 */       mainPoly.removeEdge(this.sortedVerts, vertOnMainPoly);
/*      */ 
/* 2250 */       pvMain2.next = pvMain.next;
/* 2251 */       pvMain2.prev = (vertOnSubPoly + 1);
/* 2252 */       ((Triangulate.PolyVert)this.sortedVerts.get(pvMain2.next)).prev = pvMain2.myIndex;
/*      */ 
/* 2254 */       pvSub2.prev = pvSub.prev;
/* 2255 */       pvSub2.next = (vertOnMainPoly + 1);
/* 2256 */       ((Triangulate.PolyVert)this.sortedVerts.get(pvSub2.prev)).next = pvSub2.myIndex;
/*      */ 
/* 2258 */       pvMain.next = vertOnSubPoly;
/* 2259 */       pvSub.prev = vertOnMainPoly;
/*      */ 
/* 2262 */       mainPoly.addEdge(this.sortedVerts, vertOnMainPoly);
/*      */ 
/* 2265 */       mainPoly.updateConnectedSubPoly(this.sortedVerts, vertOnSubPoly, pvMain2.next);
/* 2266 */       subPoly.invalidate(this.sortedVerts);
/*      */ 
/* 2268 */       assert (pvMain.polyOwner.isValid(this.sortedVerts));
/*      */     }
/*      */ 
/*      */     void dupeTwoVerts(int v0, int v1)
/*      */     {
/* 2274 */       if (v0 > v1) {
/* 2275 */         int t = v0;
/* 2276 */         v0 = v1;
/* 2277 */         v1 = t;
/*      */       }
/* 2279 */       assert (v0 < v1);
/*      */ 
/* 2282 */       Triangulate.PolyVert v0Copy = (Triangulate.PolyVert)((Triangulate.PolyVert)this.sortedVerts.get(v0)).clone();
/* 2283 */       Triangulate.PolyVert v1Copy = (Triangulate.PolyVert)((Triangulate.PolyVert)this.sortedVerts.get(v1)).clone();
/*      */ 
/* 2289 */       this.sortedVerts.add(v1 + 1, v1Copy);
/* 2290 */       this.sortedVerts.add(v0 + 1, v0Copy);
/*      */ 
/* 2293 */       int i = 0; for (int n = this.sortedVerts.size(); i < n; i++) {
/* 2294 */         ((Triangulate.PolyVert)this.sortedVerts.get(i)).myIndex = i;
/* 2295 */         ((Triangulate.PolyVert)this.sortedVerts.get(i)).next = Triangulate.this.remapIndexForDupedVerts(((Triangulate.PolyVert)this.sortedVerts.get(i)).next, v0, v1);
/* 2296 */         ((Triangulate.PolyVert)this.sortedVerts.get(i)).prev = Triangulate.this.remapIndexForDupedVerts(((Triangulate.PolyVert)this.sortedVerts.get(i)).prev, v0, v1);
/*      */       }
/*      */ 
/* 2300 */       int i = 0; for (int n = this.polys.size(); i < n; i++) {
/* 2301 */         ((Triangulate.TriPoly)this.polys.get(i)).remapForDupedVerts(this.sortedVerts, v0, v1);
/* 2302 */         assert (((Triangulate.TriPoly)this.polys.get(i)).isValid(this.sortedVerts));
/*      */       }
/*      */     }
/*      */ 
/*      */     void debugEmitPolyLoop(ArrayList<Float> result, ArrayList<Triangulate.PolyVert> sortedVerts, Triangulate.TriPoly P)
/*      */     {
/* 2312 */       result.clear();
/*      */ 
/* 2314 */       int firstVert = P.loop;
/* 2315 */       int vi = firstVert;
/*      */       do {
/* 2317 */         result.add(Float.valueOf(((Triangulate.PolyVert)sortedVerts.get(vi)).v.getX()));
/* 2318 */         result.add(Float.valueOf(((Triangulate.PolyVert)sortedVerts.get(vi)).v.getZ()));
/* 2319 */         vi = ((Triangulate.PolyVert)sortedVerts.get(vi)).next;
/*      */       }
/* 2321 */       while (vi != firstVert);
/*      */       do
/*      */       {
/* 2325 */         result.add(Float.valueOf(((Triangulate.PolyVert)sortedVerts.get(vi)).v.getX()));
/* 2326 */         result.add(Float.valueOf(((Triangulate.PolyVert)sortedVerts.get(vi)).v.getZ()));
/*      */       }
/* 2328 */       while (result.size() % 6 != 0);
/*      */     }
/*      */ 
/*      */     void computeTriangulation(ArrayList<Float> result, int pathCount, ArrayList<float[]> paths, int debugHaltStep, ArrayList<Float> debugRemainingLoop)
/*      */     {
/* 2337 */       Random rg = new Random();
/* 2338 */       if (pathCount <= 0)
/*      */       {
/* 2340 */         return;
/*      */       }
/* 2342 */       long startTicks = System.currentTimeMillis();
/*      */ 
/* 2345 */       PolyEnv penv = new PolyEnv(Triangulate.this);
/*      */ 
/* 2347 */       penv.init(pathCount, paths);
/*      */ 
/* 2349 */       penv.joinPathsIntoOnePoly();
/*      */ 
/* 2351 */       result.ensureCapacity(6 * penv.getEstimatedTriangleCount());
/*      */ 
/* 2353 */       long joinTicks = System.currentTimeMillis();
/*      */ 
/* 2356 */       boolean debugDumpJoinedPoly = false;
/* 2357 */       if (debugDumpJoinedPoly) {
/* 2358 */         int firstVert = ((Triangulate.TriPoly)penv.polys.get(0)).loop;
/* 2359 */         int vi = firstVert;
/*      */         do {
/* 2361 */           Triangulate.log.info(((Triangulate.PolyVert)penv.sortedVerts.get(vi)).v.getX() + ", " + ((Triangulate.PolyVert)penv.sortedVerts.get(vi)).v.getZ());
/* 2362 */           vi = ((Triangulate.PolyVert)penv.sortedVerts.get(vi)).next;
/*      */         }
/* 2364 */         while (vi != firstVert);
/*      */       }
/*      */ 
/* 2367 */       boolean debugEmitJoinedPoly = false;
/* 2368 */       if (debugEmitJoinedPoly) {
/* 2369 */         int firstVert = ((Triangulate.TriPoly)penv.polys.get(0)).loop;
/* 2370 */         int vi = firstVert;
/*      */         do {
/* 2372 */           result.add(Float.valueOf(((Triangulate.PolyVert)penv.sortedVerts.get(vi)).v.getX()));
/* 2373 */           result.add(Float.valueOf(((Triangulate.PolyVert)penv.sortedVerts.get(vi)).v.getZ()));
/* 2374 */           vi = ((Triangulate.PolyVert)penv.sortedVerts.get(vi)).next;
/*      */         }
/* 2376 */         while (vi != firstVert);
/*      */         do
/*      */         {
/* 2380 */           result.add(Float.valueOf(((Triangulate.PolyVert)penv.sortedVerts.get(vi)).v.getX()));
/* 2381 */           result.add(Float.valueOf(((Triangulate.PolyVert)penv.sortedVerts.get(vi)).v.getZ()));
/*      */         }
/* 2383 */         while (result.size() % 6 != 0);
/* 2384 */         return;
/*      */       }
/*      */ 
/* 2406 */       while (penv.polys.size() != 0) {
/* 2407 */         Triangulate.TriPoly P = (Triangulate.TriPoly)penv.polys.remove(penv.polys.size() - 1);
/* 2408 */         P.buildEarList(penv.sortedVerts, rg);
/* 2409 */         boolean earWasClipped = false;
/* 2410 */         while (P.getVertexCount() > 3) {
/* 2411 */           if (P.getEarCount() > 0)
/*      */           {
/* 2413 */             int v1 = P.getNextEar(penv.sortedVerts, rg);
/* 2414 */             int v0 = ((Triangulate.PolyVert)penv.sortedVerts.get(v1)).prev;
/* 2415 */             int v2 = ((Triangulate.PolyVert)penv.sortedVerts.get(v1)).next;
/*      */ 
/* 2417 */             P.emitAndRemoveEar(result, penv.sortedVerts, v0, v1, v2);
/* 2418 */             earWasClipped = true;
/*      */ 
/* 2421 */             debugHaltStep--;
/* 2422 */             if (debugHaltStep == 0) {
/* 2423 */               if (debugRemainingLoop != null) {
/* 2424 */                 debugEmitPolyLoop(debugRemainingLoop, penv.sortedVerts, P);
/*      */               }
/* 2426 */               return;
/*      */             }
/* 2428 */             continue;
/* 2429 */           }if (earWasClipped == true)
/*      */           {
/* 2431 */             earWasClipped = P.buildEarList(penv.sortedVerts, rg); continue;
/*      */           }
/*      */ 
/* 2435 */           boolean debugSkipRecovery = true;
/* 2436 */           if (debugSkipRecovery)
/*      */           {
/* 2438 */             debugEmitPolyLoop(result, penv.sortedVerts, P);
/* 2439 */             return;
/*      */           }
/* 2441 */           recoveryProcess(penv.polys, P, penv.sortedVerts, rg);
/* 2442 */           earWasClipped = false;
/*      */         }
/*      */ 
/* 2446 */         if (P.getVertexCount() == 3)
/*      */         {
/* 2448 */           if (!((Triangulate.PolyVert)penv.sortedVerts.get(P.loop)).isEar)
/*      */           {
/* 2450 */             ((Triangulate.PolyVert)penv.sortedVerts.get(P.loop)).isEar = true;
/* 2451 */             P.earCount += 1;
/*      */           }
/* 2453 */           P.emitAndRemoveEar(result, penv.sortedVerts, ((Triangulate.PolyVert)penv.sortedVerts.get(P.loop)).prev, P.loop, ((Triangulate.PolyVert)penv.sortedVerts.get(P.loop)).next);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2458 */       if (Triangulate.debugProfileTriangulate) {
/* 2459 */         long clipTicks = System.currentTimeMillis();
/* 2460 */         Triangulate.log.info("computeTriangulation: clip poly = " + (clipTicks - joinTicks) + "ms");
/* 2461 */         Triangulate.log.info("computeTriangulation: total for poly " + (clipTicks - startTicks) + "ms");
/*      */       }
/*      */ 
/* 2466 */       assert (penv.polys.size() == 0);
/*      */ 
/* 2468 */       assert (result.size() % 6 == 0);
/*      */     }
/*      */ 
/*      */     private void recoveryProcess(ArrayList<Triangulate.TriPoly> polys, Triangulate.TriPoly P, ArrayList<Triangulate.PolyVert> sortedVerts, Random rg)
/*      */     {
/* 2487 */       for (int vi = ((Triangulate.PolyVert)sortedVerts.get(P.loop)).next; vi != P.loop; vi = ((Triangulate.PolyVert)sortedVerts.get(vi)).next) {
/* 2488 */         int ev0 = vi;
/* 2489 */         int ev1 = ((Triangulate.PolyVert)sortedVerts.get(ev0)).next;
/* 2490 */         int ev2 = ((Triangulate.PolyVert)sortedVerts.get(ev1)).next;
/* 2491 */         int ev3 = ((Triangulate.PolyVert)sortedVerts.get(ev2)).next;
/* 2492 */         if (!Triangulate.this.edgesIntersect(sortedVerts, ev0, ev1, ev2, ev3))
/*      */           continue;
/* 2494 */         ((Triangulate.PolyVert)sortedVerts.get(ev2)).isEar = true;
/* 2495 */         P.earCount += 1;
/* 2496 */         Triangulate.log.error("recoveryProcess: self-intersecting sequence, treating " + ev2 + " as an ear");
/*      */ 
/* 2499 */         return;
/*      */       }
/*      */ 
/* 2538 */       int firstVert = P.loop;
/* 2539 */       int vi = firstVert;
/* 2540 */       int vertCount = 0;
/*      */       do {
/* 2542 */         if (Triangulate.this.isConvexVert(sortedVerts, vi))
/*      */         {
/* 2545 */           ((Triangulate.PolyVert)sortedVerts.get(vi)).isEar = true;
/* 2546 */           P.earCount += 1;
/*      */ 
/* 2548 */           Triangulate.log.error("PolyEnv.recoveryProcess: found convex vert, treating " + vi + " as an ear");
/*      */ 
/* 2551 */           return;
/*      */         }
/* 2553 */         vertCount++;
/* 2554 */         vi = ((Triangulate.PolyVert)sortedVerts.get(vi)).next;
/*      */       }
/* 2556 */       while (vi != firstVert);
/*      */ 
/* 2559 */       int randovert = (int)(rg.nextLong() % vertCount);
/* 2560 */       for (vi = firstVert; randovert > 0; randovert--) {
/* 2561 */         vi = ((Triangulate.PolyVert)sortedVerts.get(vi)).next;
/*      */       }
/* 2563 */       ((Triangulate.PolyVert)sortedVerts.get(vi)).isEar = true;
/* 2564 */       P.earCount += 1;
/*      */ 
/* 2566 */       Triangulate.log.error("PolyEnv.recoveryProcess: treating random vert " + vi + " as an ear");
/*      */     }
/*      */   }
/*      */ 
/*      */   public class TriPoly
/*      */     implements Comparable
/*      */   {
/*      */     int loop;
/*      */     int leftmostVert;
/*      */     int vertexCount;
/*      */     int earCount;
/*      */     Triangulate.GridIndexBox edgeIndex;
/*      */     Triangulate.GridIndexPoint reflexPointIndex;
/*      */     static final int MASK_TABLE_SIZE = 8;
/* 1372 */     int[] randomask = { 1, 1, 1, 3, 3, 3, 3, 7 };
/*      */ 
/*      */     public TriPoly()
/*      */     {
/*  991 */       this.loop = -1;
/*  992 */       this.leftmostVert = -1;
/*  993 */       this.vertexCount = 0;
/*  994 */       this.earCount = 0;
/*  995 */       this.edgeIndex = null;
/*  996 */       this.reflexPointIndex = null;
/*      */     }
/*      */ 
/*      */     public int compareTo(Object object)
/*      */     {
/* 1001 */       TriPoly poly = (TriPoly)object;
/*      */ 
/* 1004 */       if (this.leftmostVert < poly.leftmostVert) {
/* 1005 */         return -1;
/*      */       }
/*      */ 
/* 1009 */       assert (this.leftmostVert > poly.leftmostVert);
/* 1010 */       return 1;
/*      */     }
/*      */ 
/*      */     int getVertexCount()
/*      */     {
/* 1015 */       return this.vertexCount;
/*      */     }
/*      */ 
/*      */     int getEarCount() {
/* 1019 */       return this.earCount;
/*      */     }
/*      */ 
/*      */     boolean isValid(ArrayList<Triangulate.PolyVert> sortedVerts) {
/* 1023 */       return isValid(sortedVerts, true);
/*      */     }
/*      */ 
/*      */     boolean isValid(ArrayList<Triangulate.PolyVert> sortedVerts, boolean checkConsecutiveDupes)
/*      */     {
/* 1028 */       if ((this.loop == -1) && (this.leftmostVert == -1) && (this.vertexCount == 0))
/*      */       {
/* 1030 */         return true;
/*      */       }
/* 1032 */       assert ((this.leftmostVert == -1) || (((Triangulate.PolyVert)sortedVerts.get(this.leftmostVert)).polyOwner == this));
/*      */ 
/* 1035 */       int firstVert = this.loop;
/* 1036 */       int vi = firstVert;
/* 1037 */       int vertCount = 0;
/* 1038 */       int foundEarCount = 0;
/* 1039 */       boolean foundLeftmost = false;
/* 1040 */       int reflexVertCount = 0;
/*      */       do {
/* 1042 */         Triangulate.PolyVert pvi = (Triangulate.PolyVert)sortedVerts.get(vi);
/*      */ 
/* 1045 */         assert (pvi.polyOwner == this);
/*      */ 
/* 1048 */         assert ((this.leftmostVert == -1) || (Triangulate.this.compareVertices((Triangulate.PolyVert)sortedVerts.get(this.leftmostVert), (Triangulate.PolyVert)sortedVerts.get(vi)) <= 0));
/*      */ 
/* 1054 */         int vNext = pvi.next;
/* 1055 */         assert (((Triangulate.PolyVert)sortedVerts.get(vNext)).prev == vi);
/*      */ 
/* 1057 */         if (vi == this.leftmostVert) {
/* 1058 */           foundLeftmost = true;
/*      */         }
/* 1060 */         if ((checkConsecutiveDupes) && (vNext != vi))
/*      */         {
/* 1064 */           assert (!Triangulate.coordEquals(pvi.v, ((Triangulate.PolyVert)sortedVerts.get(vNext)).v));
/*      */         }
/* 1066 */         if (pvi.convexResult < 0) {
/* 1067 */           reflexVertCount++;
/*      */         }
/* 1069 */         if (pvi.isEar) {
/* 1070 */           foundEarCount++;
/*      */         }
/* 1072 */         vertCount++;
/* 1073 */         vi = vNext;
/*      */       }
/* 1075 */       while (vi != firstVert);
/*      */ 
/* 1077 */       assert (foundEarCount == this.earCount);
/* 1078 */       assert (vertCount == this.vertexCount);
/* 1079 */       assert ((foundLeftmost) || (this.leftmostVert == -1));
/*      */ 
/* 1082 */       if (this.reflexPointIndex != null) {
/* 1083 */         int checkCount = 0;
/* 1084 */         Triangulate.GridIndexPoint.GridIndexPointIterator it = this.reflexPointIndex.begin((Triangulate.IndexBoxFloat)this.reflexPointIndex.getBound().clone());
/* 1085 */         while (!it.atEnd())
/*      */         {
/* 1087 */           checkCount++;
/*      */ 
/* 1086 */           it.advanceIfNotEnded();
/*      */         }
/*      */ 
/* 1090 */         assert (checkCount == reflexVertCount);
/*      */       }
/*      */ 
/* 1094 */       if (this.edgeIndex != null) {
/* 1095 */         int checkCount = 0;
/* 1096 */         Triangulate.GridIndexBox.GridIndexBoxIterator it = this.edgeIndex.begin(this.edgeIndex.getBound());
/* 1097 */         while (!it.atEnd())
/*      */         {
/* 1099 */           checkCount++;
/*      */ 
/* 1098 */           it.advanceIfNotEnded();
/*      */         }
/*      */ 
/* 1101 */         assert (checkCount == vertCount);
/*      */       }
/*      */ 
/* 1106 */       return true;
/*      */     }
/*      */ 
/*      */     void invalidate(ArrayList<Triangulate.PolyVert> sortedVerts)
/*      */     {
/* 1112 */       assert ((this.loop == -1) || (((Triangulate.PolyVert)sortedVerts.get(this.loop)).polyOwner != this));
/* 1113 */       this.loop = -1;
/* 1114 */       this.leftmostVert = -1;
/* 1115 */       this.vertexCount = 0;
/* 1116 */       assert (isValid(sortedVerts));
/*      */     }
/*      */ 
/*      */     void appendVert(ArrayList<Triangulate.PolyVert> sortedVerts, int vertIndex)
/*      */     {
/* 1121 */       assert ((vertIndex >= 0) && (vertIndex < sortedVerts.size()));
/* 1122 */       assert (isValid(sortedVerts, false));
/*      */ 
/* 1124 */       this.vertexCount += 1;
/*      */ 
/* 1126 */       if (this.loop == -1)
/*      */       {
/* 1128 */         assert (this.vertexCount == 1);
/* 1129 */         this.loop = vertIndex;
/* 1130 */         Triangulate.PolyVert pv = (Triangulate.PolyVert)sortedVerts.get(vertIndex);
/* 1131 */         pv.next = vertIndex;
/* 1132 */         pv.prev = vertIndex;
/* 1133 */         pv.polyOwner = this;
/* 1134 */         this.leftmostVert = vertIndex;
/*      */       }
/*      */       else
/*      */       {
/* 1139 */         Triangulate.PolyVert pv0 = (Triangulate.PolyVert)sortedVerts.get(this.loop);
/* 1140 */         Triangulate.PolyVert pv = (Triangulate.PolyVert)sortedVerts.get(vertIndex);
/* 1141 */         pv.next = this.loop;
/* 1142 */         pv.prev = pv0.prev;
/* 1143 */         pv.polyOwner = this;
/* 1144 */         ((Triangulate.PolyVert)sortedVerts.get(pv0.prev)).next = vertIndex;
/* 1145 */         pv0.prev = vertIndex;
/*      */ 
/* 1148 */         Triangulate.PolyVert pvl = (Triangulate.PolyVert)sortedVerts.get(this.leftmostVert);
/* 1149 */         if (Triangulate.this.compareVertices(pv, pvl) < 0)
/*      */         {
/* 1151 */           this.leftmostVert = vertIndex;
/*      */         }
/*      */       }
/* 1154 */       assert (isValid(sortedVerts, false));
/*      */     }
/*      */ 
/*      */     int findValidBridgeVert(ArrayList<Triangulate.PolyVert> sortedVerts, int v1)
/*      */     {
/* 1160 */       assert (isValid(sortedVerts));
/*      */ 
/* 1162 */       Triangulate.PolyVert pv1 = (Triangulate.PolyVert)sortedVerts.get(v1);
/* 1163 */       assert (pv1.polyOwner != this);
/*      */ 
/* 1171 */       int vi = v1;
/* 1172 */       while ((vi + 1 < sortedVerts.size()) && (Triangulate.coordEquals(((Triangulate.PolyVert)sortedVerts.get(vi + 1)).v, pv1.v))) {
/* 1173 */         vi++;
/*      */       }
/*      */ 
/* 1176 */       for (; vi >= 0; vi--) {
/* 1177 */         Triangulate.PolyVert pvi = (Triangulate.PolyVert)sortedVerts.get(vi);
/*      */ 
/* 1179 */         assert (Triangulate.this.compareVertices(pvi, pv1) <= 0);
/*      */ 
/* 1181 */         if (pvi.polyOwner != this)
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 1189 */         if (!anyEdgeIntersection(sortedVerts, v1, vi)) {
/* 1190 */           return vi;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1197 */       Triangulate.log.error("findValidBridgeVert: can't find bridge for vert " + v1 + "!");
/*      */ 
/* 1199 */       return this.leftmostVert;
/*      */     }
/*      */ 
/*      */     void remap(int[] remapTable) {
/* 1203 */       assert (this.loop > -1);
/* 1204 */       assert (this.leftmostVert > -1);
/*      */ 
/* 1206 */       this.loop = remapTable[this.loop];
/* 1207 */       this.leftmostVert = remapTable[this.leftmostVert];
/*      */     }
/*      */ 
/*      */     void remapForDupedVerts(ArrayList<Triangulate.PolyVert> sortedVerts, int v0, int v1)
/*      */     {
/* 1213 */       assert (this.loop > -1);
/* 1214 */       assert (this.leftmostVert > -1);
/*      */ 
/* 1216 */       this.loop = Triangulate.this.remapIndexForDupedVerts(this.loop, v0, v1);
/* 1217 */       this.leftmostVert = Triangulate.this.remapIndexForDupedVerts(this.leftmostVert, v0, v1);
/*      */ 
/* 1220 */       if (this.edgeIndex != null)
/*      */       {
/* 1225 */         assert (v0 < v1);
/* 1226 */         Triangulate.IndexBoxFloat bound = (Triangulate.IndexBoxFloat)this.edgeIndex.getBound().clone();
/* 1227 */         bound.min.x = ((Triangulate.PolyVert)sortedVerts.get(v0)).v.getX();
/* 1228 */         Triangulate.GridIndexBox.GridIndexBoxIterator it = this.edgeIndex.begin(bound);
/* 1229 */         while (!it.atEnd())
/*      */         {
/* 1231 */           it.currentEntry.value = Triangulate.this.remapIndexForDupedVerts(it.currentEntry.value, v0, v1);
/*      */ 
/* 1230 */           it.advanceIfNotEnded();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1236 */       assert (this.reflexPointIndex == null);
/*      */     }
/*      */ 
/*      */     void classifyVert(ArrayList<Triangulate.PolyVert> sortedVerts, int vi)
/*      */     {
/* 1242 */       Triangulate.PolyVert pvi = (Triangulate.PolyVert)sortedVerts.get(vi);
/* 1243 */       Triangulate.PolyVert pvPrev = (Triangulate.PolyVert)sortedVerts.get(pvi.prev);
/* 1244 */       Triangulate.PolyVert pvNext = (Triangulate.PolyVert)sortedVerts.get(pvi.next);
/*      */ 
/* 1246 */       if (pvi.convexResult > 0)
/*      */       {
/* 1248 */         if ((vertInCone(sortedVerts, pvi.prev, vi, pvi.next, pvNext.next)) && (vertInCone(sortedVerts, pvi.next, pvPrev.prev, pvi.prev, vi)))
/*      */         {
/* 1251 */           if (!earContainsReflexVertex(sortedVerts, pvi.prev, vi, pvi.next))
/*      */           {
/* 1254 */             assert (!pvi.isEar);
/* 1255 */             pvi.isEar = true;
/* 1256 */             this.earCount += 1;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     void dirtyVert(ArrayList<Triangulate.PolyVert> sortedVerts, int vi)
/*      */     {
/* 1266 */       Triangulate.PolyVert pvi = (Triangulate.PolyVert)sortedVerts.get(vi);
/*      */ 
/* 1268 */       int newConvexResult = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(pvi.prev)).v, pvi.v, ((Triangulate.PolyVert)sortedVerts.get(pvi.next)).v);
/*      */ 
/* 1270 */       if ((newConvexResult < 0) && (pvi.convexResult >= 0))
/*      */       {
/* 1274 */         assert (this.reflexPointIndex != null);
/* 1275 */         this.reflexPointIndex.add(new Triangulate.IndexPointFloat(Triangulate.this, pvi.v.getX(), pvi.v.getZ()), vi);
/*      */       }
/* 1277 */       else if ((pvi.convexResult < 0) && (newConvexResult >= 0))
/*      */       {
/* 1281 */         assert (this.reflexPointIndex != null);
/* 1282 */         Triangulate.GridIndexPoint.GridIndexPointIterator it = this.reflexPointIndex.find(new Triangulate.IndexPointFloat(Triangulate.this, pvi.v.getX(), pvi.v.getZ()), vi);
/* 1283 */         assert (!it.atEnd());
/*      */ 
/* 1285 */         this.reflexPointIndex.remove(it.currentEntry);
/*      */       }
/* 1287 */       pvi.convexResult = newConvexResult;
/*      */ 
/* 1289 */       if (pvi.isEar)
/*      */       {
/* 1292 */         pvi.isEar = false;
/* 1293 */         this.earCount -= 1;
/*      */       }
/*      */     }
/*      */ 
/*      */     boolean buildEarList(ArrayList<Triangulate.PolyVert> sortedVerts, Random rg)
/*      */     {
/* 1301 */       assert (isValid(sortedVerts));
/* 1302 */       assert (this.earCount == 0);
/* 1303 */       boolean clippedAnyDegenerates = false;
/*      */ 
/* 1305 */       if (this.vertexCount < 3)
/*      */       {
/* 1307 */         return false;
/*      */       }
/*      */ 
/* 1310 */       int vi = this.loop;
/* 1311 */       int vertsProcessedCount = 0;
/*      */       while (true) {
/* 1313 */         Triangulate.PolyVert pvi = (Triangulate.PolyVert)sortedVerts.get(vi);
/* 1314 */         Triangulate.PolyVert pvPrev = (Triangulate.PolyVert)sortedVerts.get(pvi.prev);
/* 1315 */         Triangulate.PolyVert pvNext = (Triangulate.PolyVert)sortedVerts.get(pvi.next);
/*      */ 
/* 1331 */         if ((pvi == pvNext) || (pvi == pvPrev) || ((Triangulate.this.vertexLeftTest(pvPrev.v, pvi.v, pvNext.v) == 0) && (!vertIsDuplicated(sortedVerts, vi))))
/*      */         {
/* 1338 */           vi = removeDegenerateChain(sortedVerts, vi);
/*      */ 
/* 1340 */           clippedAnyDegenerates = true;
/*      */ 
/* 1342 */           if (this.vertexCount < 3) {
/* 1343 */             break;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1348 */         classifyVert(sortedVerts, vi);
/*      */ 
/* 1350 */         vi = pvi.next;
/* 1351 */         vertsProcessedCount++;
/*      */ 
/* 1353 */         if (vertsProcessedCount >= this.vertexCount)
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/* 1359 */         if ((this.earCount > 5) && (vertsProcessedCount > 10)) {
/*      */           break;
/*      */         }
/*      */       }
/* 1363 */       assert (isValid(sortedVerts, true));
/*      */ 
/* 1367 */       return clippedAnyDegenerates;
/*      */     }
/*      */ 
/*      */     int getNextEar(ArrayList<Triangulate.PolyVert> sortedVerts, Random rg)
/*      */     {
/* 1376 */       assert (this.earCount > 0);
/*      */ 
/* 1378 */       while (!((Triangulate.PolyVert)sortedVerts.get(this.loop)).isEar) {
/* 1379 */         this.loop = ((Triangulate.PolyVert)sortedVerts.get(this.loop)).next;
/*      */       }
/* 1381 */       int nextEar = this.loop;
/*      */ 
/* 1386 */       if (this.earCount > 6)
/*      */       {
/* 1390 */         int randorange = this.earCount >> 2;
/* 1391 */         if (randorange >= 8) randorange = 7;
/* 1392 */         assert (randorange > 0);
/*      */ 
/* 1394 */         int randoskip = (int)(rg.nextLong() & this.randomask[randorange]);
/*      */ 
/* 1397 */         while (randoskip > 0) {
/* 1398 */           if (((Triangulate.PolyVert)sortedVerts.get(this.loop)).isEar)
/* 1399 */             randoskip--;
/* 1400 */           this.loop = ((Triangulate.PolyVert)sortedVerts.get(this.loop)).next;
/*      */         }
/* 1402 */         assert (isValid(sortedVerts));
/*      */       }
/* 1404 */       assert (((Triangulate.PolyVert)sortedVerts.get(nextEar)).isEar == true);
/*      */ 
/* 1406 */       return nextEar;
/*      */     }
/*      */ 
/*      */     void emitAndRemoveEar(Collection<Float> result, ArrayList<Triangulate.PolyVert> sortedVerts, int v0, int v1, int v2)
/*      */     {
/* 1413 */       assert (isValid(sortedVerts));
/* 1414 */       assert (this.vertexCount >= 3);
/*      */ 
/* 1416 */       Triangulate.PolyVert pv0 = (Triangulate.PolyVert)sortedVerts.get(v0);
/* 1417 */       Triangulate.PolyVert pv1 = (Triangulate.PolyVert)sortedVerts.get(v1);
/* 1418 */       Triangulate.PolyVert pv2 = (Triangulate.PolyVert)sortedVerts.get(v2);
/*      */ 
/* 1420 */       assert (((Triangulate.PolyVert)sortedVerts.get(v1)).isEar);
/*      */ 
/* 1422 */       if (this.loop == v1)
/*      */       {
/* 1424 */         this.loop = v0;
/*      */       }
/*      */ 
/* 1427 */       this.leftmostVert = -1;
/*      */ 
/* 1429 */       if (Triangulate.this.vertexLeftTest(pv0.v, pv1.v, pv2.v) == 0)
/*      */       {
/* 1432 */         if (!$assertionsDisabled) throw new AssertionError(); 
/*      */       }
/*      */       else
/*      */       {
/* 1435 */         result.add(Float.valueOf(pv0.v.getX()));
/* 1436 */         result.add(Float.valueOf(pv0.v.getZ()));
/* 1437 */         result.add(Float.valueOf(pv1.v.getX()));
/* 1438 */         result.add(Float.valueOf(pv1.v.getZ()));
/* 1439 */         result.add(Float.valueOf(pv2.v.getX()));
/* 1440 */         result.add(Float.valueOf(pv2.v.getZ()));
/*      */       }
/*      */ 
/* 1445 */       if (pv1.convexResult < 0)
/*      */       {
/* 1448 */         assert (this.reflexPointIndex != null);
/* 1449 */         Triangulate.GridIndexPoint.GridIndexPointIterator it = this.reflexPointIndex.find(new Triangulate.IndexPointFloat(Triangulate.this, pv1.v.getX(), pv1.v.getZ()), v1);
/* 1450 */         assert (!it.atEnd());
/*      */ 
/* 1452 */         this.reflexPointIndex.remove(it.currentEntry);
/*      */       }
/*      */ 
/* 1455 */       assert (pv0.polyOwner == this);
/* 1456 */       assert (pv1.polyOwner == this);
/* 1457 */       assert (pv2.polyOwner == this);
/*      */ 
/* 1459 */       pv0.next = v2;
/* 1460 */       pv2.prev = v0;
/*      */ 
/* 1462 */       pv1.next = -1;
/* 1463 */       pv1.prev = -1;
/* 1464 */       pv1.polyOwner = null;
/*      */ 
/* 1467 */       this.vertexCount -= 1;
/* 1468 */       this.earCount -= 1;
/*      */ 
/* 1470 */       if (Triangulate.coordEquals(pv0.v, pv2.v))
/*      */       {
/* 1473 */         if (!$assertionsDisabled) throw new AssertionError();
/*      */ 
/*      */       }
/*      */ 
/* 1477 */       dirtyVert(sortedVerts, v0);
/* 1478 */       dirtyVert(sortedVerts, v2);
/*      */ 
/* 1484 */       classifyVert(sortedVerts, v0);
/* 1485 */       classifyVert(sortedVerts, v2);
/*      */ 
/* 1487 */       assert (isValid(sortedVerts));
/*      */     }
/*      */ 
/*      */     int removeDegenerateChain(ArrayList<Triangulate.PolyVert> sortedVerts, int vi)
/*      */     {
/* 1495 */       assert (this.leftmostVert == -1);
/*      */ 
/* 1497 */       int retval = vi;
/*      */       while (true)
/*      */       {
/* 1500 */         assert (isValid(sortedVerts, false));
/*      */ 
/* 1502 */         Triangulate.PolyVert pv1 = (Triangulate.PolyVert)sortedVerts.get(vi);
/* 1503 */         Triangulate.PolyVert pv0 = (Triangulate.PolyVert)sortedVerts.get(pv1.prev);
/* 1504 */         Triangulate.PolyVert pv2 = (Triangulate.PolyVert)sortedVerts.get(pv1.next);
/*      */ 
/* 1506 */         if (this.loop == vi)
/*      */         {
/* 1508 */           this.loop = pv0.myIndex;
/*      */         }
/*      */ 
/* 1512 */         assert (pv0.polyOwner == this);
/* 1513 */         assert (pv1.polyOwner == this);
/* 1514 */         assert (pv2.polyOwner == this);
/*      */ 
/* 1516 */         pv0.next = pv2.myIndex;
/* 1517 */         pv2.prev = pv0.myIndex;
/*      */ 
/* 1519 */         pv1.next = -1;
/* 1520 */         pv1.prev = -1;
/* 1521 */         pv1.polyOwner = null;
/*      */ 
/* 1523 */         if (pv1.convexResult < 0)
/*      */         {
/* 1525 */           assert (this.reflexPointIndex != null);
/* 1526 */           Triangulate.GridIndexPoint.GridIndexPointIterator it = this.reflexPointIndex.find(new Triangulate.IndexPointFloat(Triangulate.this, pv1.v.getX(), pv1.v.getZ()), vi);
/* 1527 */           assert (!it.atEnd());
/*      */ 
/* 1529 */           this.reflexPointIndex.remove(it.currentEntry);
/*      */         }
/*      */ 
/* 1532 */         if (pv1.isEar) {
/* 1533 */           this.earCount -= 1;
/*      */         }
/*      */ 
/* 1536 */         this.vertexCount -= 1;
/*      */ 
/* 1538 */         assert (isValid(sortedVerts, false));
/*      */ 
/* 1540 */         if (this.vertexCount < 3) {
/* 1541 */           retval = pv0.myIndex;
/* 1542 */           break;
/*      */         }
/*      */ 
/* 1546 */         if (Triangulate.coordEquals(pv0.v, pv2.v))
/*      */         {
/* 1548 */           vi = pv0.myIndex;
/*      */         }
/* 1550 */         else if (Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(pv0.prev)).v, pv0.v, pv2.v) == 0)
/*      */         {
/* 1552 */           vi = pv0.myIndex;
/* 1553 */         } else if (Triangulate.this.vertexLeftTest(pv0.v, pv2.v, ((Triangulate.PolyVert)sortedVerts.get(pv2.next)).v) == 0)
/*      */         {
/* 1555 */           vi = pv2.myIndex;
/*      */         }
/*      */         else {
/* 1558 */           dirtyVert(sortedVerts, pv0.myIndex);
/* 1559 */           dirtyVert(sortedVerts, pv2.myIndex);
/* 1560 */           retval = pv0.myIndex;
/* 1561 */           break;
/*      */         }
/*      */       }
/*      */ 
/* 1565 */       assert (isValid(sortedVerts, true));
/*      */ 
/* 1567 */       return retval;
/*      */     }
/*      */ 
/*      */     void updateConnectedSubPoly(ArrayList<Triangulate.PolyVert> sortedVerts, int vFirstInSubloop, int vFirstAfterSubloop)
/*      */     {
/* 1574 */       assert (vFirstInSubloop != vFirstAfterSubloop);
/*      */ 
/* 1576 */       int vi = vFirstInSubloop;
/*      */       do {
/* 1578 */         Triangulate.PolyVert pv = (Triangulate.PolyVert)sortedVerts.get(vi);
/*      */ 
/* 1580 */         pv.polyOwner = this;
/* 1581 */         this.vertexCount += 1;
/*      */ 
/* 1584 */         if (pv.myIndex < this.leftmostVert) {
/* 1585 */           this.leftmostVert = pv.myIndex;
/*      */         }
/*      */ 
/* 1588 */         addEdge(sortedVerts, vi);
/*      */ 
/* 1590 */         vi = pv.next;
/*      */       }
/* 1592 */       while (vi != vFirstAfterSubloop);
/*      */ 
/* 1594 */       assert (isValid(sortedVerts));
/*      */     }
/*      */ 
/*      */     void initEdgeIndex(ArrayList<Triangulate.PolyVert> sortedVerts, Triangulate.IndexBoxFloat boundOfAllVerts)
/*      */     {
/* 1600 */       assert (isValid(sortedVerts));
/* 1601 */       assert (this.edgeIndex == null);
/*      */ 
/* 1604 */       int xCells = 1;
/* 1605 */       int yCells = 1;
/* 1606 */       if (sortedVerts.size() > 0) {
/* 1607 */         float GRIDSCALE = (float)Math.sqrt(0.5D);
/* 1608 */         float width = boundOfAllVerts.getWidth();
/* 1609 */         float height = boundOfAllVerts.getHeight();
/* 1610 */         float area = width * height;
/* 1611 */         if (area > 0.0F) {
/* 1612 */           float sqrtN = (float)Math.sqrt(sortedVerts.size());
/* 1613 */           float w = width * width / area * GRIDSCALE;
/* 1614 */           float h = height * height / area * GRIDSCALE;
/* 1615 */           xCells = (int)(w * sqrtN);
/* 1616 */           yCells = (int)(h * sqrtN);
/*      */         }
/* 1620 */         else if (width > 0.0F) {
/* 1621 */           xCells = (int)(GRIDSCALE * GRIDSCALE * sortedVerts.size());
/*      */         } else {
/* 1623 */           yCells = (int)(GRIDSCALE * GRIDSCALE * sortedVerts.size());
/*      */         }
/* 1625 */         xCells = Triangulate.this.iclamp(xCells, 1, 256);
/* 1626 */         yCells = Triangulate.this.iclamp(yCells, 1, 256);
/*      */       }
/*      */ 
/* 1629 */       this.edgeIndex = new Triangulate.GridIndexBox(Triangulate.this, boundOfAllVerts, xCells, yCells);
/*      */ 
/* 1632 */       int vi = this.loop;
/*      */       while (true) {
/* 1634 */         addEdge(sortedVerts, vi);
/*      */ 
/* 1636 */         vi = ((Triangulate.PolyVert)sortedVerts.get(vi)).next;
/* 1637 */         if (vi == this.loop)
/* 1638 */           break;
/*      */       }
/* 1640 */       assert (isValid(sortedVerts));
/*      */     }
/*      */ 
/*      */     void initForEarClipping(ArrayList<Triangulate.PolyVert> sortedVerts)
/*      */     {
/* 1648 */       assert (isValid(sortedVerts));
/*      */ 
/* 1652 */       this.leftmostVert = -1;
/*      */ 
/* 1654 */       this.edgeIndex = null;
/* 1655 */       int reflexVertCount = 0;
/* 1656 */       boolean boundInited = false;
/* 1657 */       Triangulate.IndexBoxFloat reflexBound = new Triangulate.IndexBoxFloat(Triangulate.this, new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F), new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F));
/* 1658 */       int vi = this.loop;
/*      */       while (true)
/*      */       {
/* 1661 */         Triangulate.PolyVert pvi = (Triangulate.PolyVert)sortedVerts.get(vi);
/* 1662 */         pvi.convexResult = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(pvi.prev)).v, pvi.v, ((Triangulate.PolyVert)sortedVerts.get(pvi.next)).v);
/*      */ 
/* 1664 */         if (pvi.convexResult < 0) {
/* 1665 */           reflexVertCount++;
/*      */ 
/* 1668 */           Triangulate.IndexPointFloat location = new Triangulate.IndexPointFloat(Triangulate.this, pvi.v.getX(), pvi.v.getZ());
/* 1669 */           if (!boundInited) {
/* 1670 */             boundInited = true;
/* 1671 */             reflexBound = new Triangulate.IndexBoxFloat(Triangulate.this, (Triangulate.IndexPointFloat)location.clone(), (Triangulate.IndexPointFloat)location.clone());
/*      */           }
/*      */           else {
/* 1674 */             reflexBound.expandToEnclose(location);
/*      */           }
/*      */         }
/* 1677 */         vi = ((Triangulate.PolyVert)sortedVerts.get(vi)).next;
/* 1678 */         if (vi == this.loop)
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1685 */       int xCells = 1;
/* 1686 */       int yCells = 1;
/* 1687 */       if (reflexVertCount > 0) {
/* 1688 */         float GRIDSCALE = (float)Math.sqrt(0.5D);
/* 1689 */         float width = reflexBound.getWidth();
/* 1690 */         float height = reflexBound.getHeight();
/* 1691 */         float area = width * height;
/* 1692 */         if (area > 0.0F) {
/* 1693 */           float sqrtN = (float)Math.sqrt(reflexVertCount);
/* 1694 */           float w = width * width / area * GRIDSCALE;
/* 1695 */           float h = height * height / area * GRIDSCALE;
/* 1696 */           xCells = (int)(w * sqrtN);
/* 1697 */           yCells = (int)(h * sqrtN);
/*      */         }
/* 1701 */         else if (width > 0.0F) {
/* 1702 */           xCells = (int)(GRIDSCALE * GRIDSCALE * reflexVertCount);
/*      */         } else {
/* 1704 */           yCells = (int)(GRIDSCALE * GRIDSCALE * reflexVertCount);
/*      */         }
/* 1706 */         xCells = Triangulate.this.iclamp(xCells, 1, 256);
/* 1707 */         yCells = Triangulate.this.iclamp(yCells, 1, 256);
/*      */       }
/*      */ 
/* 1710 */       this.reflexPointIndex = new Triangulate.GridIndexPoint(Triangulate.this, reflexBound, xCells, yCells);
/*      */ 
/* 1713 */       vi = this.loop;
/*      */       while (true) {
/* 1715 */         Triangulate.PolyVert pvi = (Triangulate.PolyVert)sortedVerts.get(vi);
/* 1716 */         if (pvi.convexResult < 0)
/*      */         {
/* 1718 */           this.reflexPointIndex.add(new Triangulate.IndexPointFloat(Triangulate.this, pvi.v.getX(), pvi.v.getZ()), vi);
/*      */         }
/* 1720 */         vi = ((Triangulate.PolyVert)sortedVerts.get(vi)).next;
/* 1721 */         if (vi == this.loop) {
/*      */           break;
/*      */         }
/*      */       }
/* 1725 */       assert (isValid(sortedVerts));
/*      */     }
/*      */ 
/*      */     void addEdge(ArrayList<Triangulate.PolyVert> sortedVerts, int vi)
/*      */     {
/* 1730 */       Triangulate.IndexBoxFloat ib = new Triangulate.IndexBoxFloat(Triangulate.this, ((Triangulate.PolyVert)sortedVerts.get(vi)).getIndexPoint());
/* 1731 */       ib.expandToEnclose(((Triangulate.PolyVert)sortedVerts.get(((Triangulate.PolyVert)sortedVerts.get(vi)).next)).getIndexPoint());
/*      */ 
/* 1733 */       assert (this.edgeIndex != null);
/*      */ 
/* 1736 */       assert (this.edgeIndex.findPayloadFropoint(((Triangulate.PolyVert)sortedVerts.get(vi)).getIndexPoint(), vi) == null);
/*      */ 
/* 1738 */       this.edgeIndex.add(ib, vi);
/*      */     }
/*      */ 
/*      */     void removeEdge(ArrayList<Triangulate.PolyVert> sortedVerts, int vi)
/*      */     {
/* 1743 */       assert (this.edgeIndex != null);
/*      */ 
/* 1745 */       Triangulate.GridEntryBox entry = this.edgeIndex.findPayloadFropoint(((Triangulate.PolyVert)sortedVerts.get(vi)).getIndexPoint(), vi);
/* 1746 */       assert (entry != null);
/*      */ 
/* 1748 */       this.edgeIndex.remove(entry);
/*      */     }
/*      */ 
/*      */     boolean vertCanSeeConeA(ArrayList<Triangulate.PolyVert> sortedVerts, int v, int coneAVert, int coneBVert)
/*      */     {
/* 1754 */       assert (Triangulate.coordEquals(((Triangulate.PolyVert)sortedVerts.get(coneAVert)).v, ((Triangulate.PolyVert)sortedVerts.get(coneBVert)).v));
/*      */ 
/* 1766 */       Triangulate.PolyVert pa = (Triangulate.PolyVert)sortedVerts.get(coneAVert);
/* 1767 */       AOVector[] coneA = { ((Triangulate.PolyVert)sortedVerts.get(pa.prev)).v, pa.v, ((Triangulate.PolyVert)sortedVerts.get(pa.next)).v };
/* 1768 */       if (Triangulate.this.vertexLeftTest(coneA[0], coneA[1], coneA[2]) < 0) {
/* 1769 */         AOVector t = coneA[0];
/* 1770 */         coneA[0] = coneA[2];
/* 1771 */         coneA[2] = t;
/*      */       }
/* 1773 */       Triangulate.PolyVert pb = (Triangulate.PolyVert)sortedVerts.get(coneBVert);
/* 1774 */       AOVector[] coneB = { ((Triangulate.PolyVert)sortedVerts.get(pb.prev)).v, pb.v, ((Triangulate.PolyVert)sortedVerts.get(pb.next)).v };
/* 1775 */       if (Triangulate.this.vertexLeftTest(coneB[0], coneB[1], coneB[2]) < 0) {
/* 1776 */         AOVector t = coneB[0];
/* 1777 */         coneB[0] = coneB[2];
/* 1778 */         coneB[2] = t;
/*      */       }
/*      */ 
/* 1782 */       int aInBSum = 0;
/* 1783 */       aInBSum += Triangulate.this.vertexLeftTest(coneB[0], coneB[1], coneA[0]);
/* 1784 */       aInBSum += Triangulate.this.vertexLeftTest(coneB[1], coneB[2], coneA[0]);
/* 1785 */       aInBSum += Triangulate.this.vertexLeftTest(coneB[0], coneB[1], coneA[2]);
/* 1786 */       aInBSum += Triangulate.this.vertexLeftTest(coneB[1], coneB[2], coneA[2]);
/*      */ 
/* 1788 */       int bInASum = 0;
/* 1789 */       bInASum += Triangulate.this.vertexLeftTest(coneA[0], coneA[1], coneB[0]);
/* 1790 */       bInASum += Triangulate.this.vertexLeftTest(coneA[1], coneA[2], coneB[0]);
/* 1791 */       bInASum += Triangulate.this.vertexLeftTest(coneA[0], coneA[1], coneB[2]);
/* 1792 */       bInASum += Triangulate.this.vertexLeftTest(coneA[1], coneA[2], coneB[2]);
/*      */ 
/* 1795 */       boolean aInB = false;
/* 1796 */       if (aInBSum >= 4) {
/* 1797 */         assert (bInASum <= -2);
/* 1798 */         aInB = true;
/*      */       }
/* 1800 */       else if (aInBSum == 3) {
/* 1801 */         assert (bInASum <= 3);
/* 1802 */         if (bInASum >= 3)
/*      */         {
/* 1804 */           return false;
/* 1805 */         }aInB = true;
/*      */       }
/* 1807 */       else if (aInBSum <= -4) {
/* 1808 */         assert (bInASum >= 2);
/* 1809 */         aInB = false;
/*      */       }
/* 1811 */       else if (aInBSum == -3) {
/* 1812 */         assert (bInASum >= -3);
/* 1813 */         if (bInASum <= -3)
/*      */         {
/* 1815 */           return false;
/*      */         }
/* 1817 */         aInB = false;
/*      */       }
/* 1820 */       else if (bInASum >= 4) {
/* 1821 */         assert (aInBSum <= -2);
/* 1822 */         aInB = false;
/*      */       }
/* 1824 */       else if (bInASum == 3) {
/* 1825 */         aInB = false;
/*      */       }
/* 1827 */       else if (bInASum <= -4) {
/* 1828 */         assert (aInBSum >= 2);
/* 1829 */         aInB = true;
/*      */       }
/* 1831 */       else if (bInASum == -3) {
/* 1832 */         aInB = true;
/*      */       }
/*      */       else
/*      */       {
/* 1836 */         return false;
/*      */       }
/*      */ 
/* 1839 */       if (aInB) {
/* 1840 */         assert (aInB);
/*      */ 
/* 1842 */         boolean vInA = (Triangulate.this.vertexLeftTest(coneA[0], coneA[1], ((Triangulate.PolyVert)sortedVerts.get(v)).v) > 0) && (Triangulate.this.vertexLeftTest(coneA[1], coneA[2], ((Triangulate.PolyVert)sortedVerts.get(v)).v) > 0);
/*      */ 
/* 1846 */         return vInA;
/*      */       }
/*      */ 
/* 1852 */       boolean vInB = (Triangulate.this.vertexLeftTest(coneB[0], coneB[1], ((Triangulate.PolyVert)sortedVerts.get(v)).v) > 0) && (Triangulate.this.vertexLeftTest(coneB[1], coneB[2], ((Triangulate.PolyVert)sortedVerts.get(v)).v) > 0);
/*      */ 
/* 1856 */       return !vInB;
/*      */     }
/*      */ 
/*      */     boolean anyEdgeIntersection(ArrayList<Triangulate.PolyVert> sortedVerts, int externalVert, int myVert)
/*      */     {
/* 1866 */       Triangulate.PolyVert pmv = (Triangulate.PolyVert)sortedVerts.get(myVert);
/* 1867 */       Triangulate.PolyVert pev = (Triangulate.PolyVert)sortedVerts.get(externalVert);
/*      */ 
/* 1869 */       assert (this.edgeIndex != null);
/*      */ 
/* 1871 */       Triangulate.IndexBoxFloat queryBox = new Triangulate.IndexBoxFloat(Triangulate.this, pmv.getIndexPoint());
/* 1872 */       queryBox.expandToEnclose(pev.getIndexPoint());
/*      */ 
/* 1874 */       Triangulate.GridIndexBox.GridIndexBoxIterator it = this.edgeIndex.begin(queryBox);
/* 1875 */       while (!it.atEnd())
/*      */       {
/* 1877 */         int vi = it.currentEntry.value;
/* 1878 */         int vNext = ((Triangulate.PolyVert)sortedVerts.get(vi)).next;
/*      */ 
/* 1880 */         if (vi != myVert)
/* 1881 */           if (Triangulate.coordEquals(((Triangulate.PolyVert)sortedVerts.get(vi)).v, ((Triangulate.PolyVert)sortedVerts.get(myVert)).v))
/*      */           {
/* 1883 */             if (!vertCanSeeConeA(sortedVerts, externalVert, myVert, vi))
/*      */             {
/* 1885 */               return true;
/*      */             }
/* 1887 */           } else if (Triangulate.this.edgesIntersect(sortedVerts, vi, vNext, externalVert, myVert))
/* 1888 */             return true;
/* 1876 */         it.advanceIfNotEnded();
/*      */       }
/*      */ 
/* 1891 */       return false;
/*      */     }
/*      */ 
/*      */     boolean earContainsReflexVertex(ArrayList<Triangulate.PolyVert> sortedVerts, int v0, int v1, int v2)
/*      */     {
/* 1900 */       Triangulate.IndexBoxFloat queryBound = new Triangulate.IndexBoxFloat(Triangulate.this, (Triangulate.IndexPointFloat)((Triangulate.PolyVert)sortedVerts.get(v0)).getIndexPoint().clone());
/* 1901 */       queryBound.expandToEnclose(new Triangulate.IndexPointFloat(Triangulate.this, ((Triangulate.PolyVert)sortedVerts.get(v1)).v.getX(), ((Triangulate.PolyVert)sortedVerts.get(v1)).v.getZ()));
/* 1902 */       queryBound.expandToEnclose(new Triangulate.IndexPointFloat(Triangulate.this, ((Triangulate.PolyVert)sortedVerts.get(v2)).v.getX(), ((Triangulate.PolyVert)sortedVerts.get(v2)).v.getZ()));
/*      */ 
/* 1904 */       Triangulate.GridIndexPoint.GridIndexPointIterator it = this.reflexPointIndex.begin(queryBound);
/* 1905 */       while (!it.atEnd())
/*      */       {
/* 1907 */         int vk = it.currentEntry.value;
/*      */ 
/* 1909 */         Triangulate.PolyVert pvk = (Triangulate.PolyVert)sortedVerts.get(vk);
/* 1910 */         if (pvk.polyOwner == this)
/*      */         {
/* 1914 */           if ((vk != v0) && (vk != v1) && (vk != v2) && (queryBound.containsPoint(new Triangulate.IndexPointFloat(Triangulate.this, pvk.v.getX(), pvk.v.getZ()))))
/*      */           {
/* 1916 */             int vNext = pvk.next;
/* 1917 */             int vPrev = pvk.prev;
/*      */ 
/* 1919 */             if (Triangulate.coordEquals(pvk.v, ((Triangulate.PolyVert)sortedVerts.get(v1)).v))
/*      */             {
/* 1931 */               int vPrevLeft01 = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(v0)).v, ((Triangulate.PolyVert)sortedVerts.get(v1)).v, ((Triangulate.PolyVert)sortedVerts.get(vPrev)).v);
/* 1932 */               int vNextLeft01 = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(v0)).v, ((Triangulate.PolyVert)sortedVerts.get(v1)).v, ((Triangulate.PolyVert)sortedVerts.get(vNext)).v);
/* 1933 */               int vPrevLeft12 = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(v1)).v, ((Triangulate.PolyVert)sortedVerts.get(v2)).v, ((Triangulate.PolyVert)sortedVerts.get(vPrev)).v);
/* 1934 */               int vNextLeft12 = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(v1)).v, ((Triangulate.PolyVert)sortedVerts.get(v2)).v, ((Triangulate.PolyVert)sortedVerts.get(vNext)).v);
/*      */ 
/* 1936 */               if (((vPrevLeft01 > 0) && (vPrevLeft12 > 0)) || ((vNextLeft01 > 0) && (vNextLeft12 > 0)))
/*      */               {
/* 1940 */                 return true;
/*      */               }
/*      */ 
/* 1944 */               if (((vPrevLeft01 == 0) && (vNextLeft12 == 0)) || ((vPrevLeft12 == 0) && (vNextLeft01 == 0)))
/*      */               {
/* 1958 */                 return true;
/*      */               }
/*      */             }
/*      */             else {
/* 1962 */               assert (pvk.convexResult < 0);
/* 1963 */               if (Triangulate.this.vertexInEar(pvk.v, ((Triangulate.PolyVert)sortedVerts.get(v0)).v, ((Triangulate.PolyVert)sortedVerts.get(v1)).v, ((Triangulate.PolyVert)sortedVerts.get(v2)).v))
/*      */               {
/* 1965 */                 return true;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 1906 */         it.advanceIfNotEnded();
/*      */       }
/*      */ 
/* 1970 */       return false;
/*      */     }
/*      */ 
/*      */     boolean vertInCone(ArrayList<Triangulate.PolyVert> sortedVerts, int vert, int coneV0, int coneV1, int coneV2)
/*      */     {
/* 1984 */       boolean acuteCone = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(coneV0)).v, ((Triangulate.PolyVert)sortedVerts.get(coneV1)).v, ((Triangulate.PolyVert)sortedVerts.get(coneV2)).v) > 0;
/*      */ 
/* 1987 */       boolean leftOf01 = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(coneV0)).v, ((Triangulate.PolyVert)sortedVerts.get(coneV1)).v, ((Triangulate.PolyVert)sortedVerts.get(vert)).v) >= 0;
/* 1988 */       boolean leftOf12 = Triangulate.this.vertexLeftTest(((Triangulate.PolyVert)sortedVerts.get(coneV1)).v, ((Triangulate.PolyVert)sortedVerts.get(coneV2)).v, ((Triangulate.PolyVert)sortedVerts.get(vert)).v) >= 0;
/*      */ 
/* 1990 */       if (acuteCone)
/*      */       {
/* 1992 */         return (leftOf01) && (leftOf12);
/*      */       }
/*      */ 
/* 1995 */       return (leftOf01) || (leftOf12);
/*      */     }
/*      */ 
/*      */     boolean vertIsDuplicated(ArrayList<Triangulate.PolyVert> sortedVerts, int vert)
/*      */     {
/* 2001 */       for (int vi = vert - 1; (vi >= 0) && 
/* 2002 */         (Triangulate.coordEquals(((Triangulate.PolyVert)sortedVerts.get(vi)).v, ((Triangulate.PolyVert)sortedVerts.get(vert)).v)); vi--)
/*      */       {
/* 2005 */         if (((Triangulate.PolyVert)sortedVerts.get(vi)).polyOwner == this)
/*      */         {
/* 2007 */           return true;
/*      */         }
/*      */       }
/*      */ 
/* 2011 */       int vi = vert + 1; for (int n = sortedVerts.size(); (vi < n) && 
/* 2012 */         (Triangulate.coordEquals(((Triangulate.PolyVert)sortedVerts.get(vi)).v, ((Triangulate.PolyVert)sortedVerts.get(vert)).v)); vi++)
/*      */       {
/* 2015 */         if (((Triangulate.PolyVert)sortedVerts.get(vi)).polyOwner == this)
/*      */         {
/* 2017 */           return true;
/*      */         }
/*      */       }
/* 2020 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public class GridIndexBox
/*      */   {
/*      */     Triangulate.IndexBoxFloat bound;
/*      */     int xCells;
/*      */     int zCells;
/*      */     int queryId;
/*      */     ArrayList<Triangulate.GridEntryBox>[][] grid;
/*      */ 
/*      */     public GridIndexBox(Triangulate.IndexBoxFloat bound, int xCells, int zCells)
/*      */     {
/*  598 */       this.bound = ((Triangulate.IndexBoxFloat)bound.clone());
/*  599 */       this.xCells = xCells;
/*  600 */       this.zCells = zCells;
/*  601 */       this.queryId = 0;
/*  602 */       assert ((xCells > 0) && (zCells > 0));
/*  603 */       assert (bound.min.x <= bound.max.x);
/*  604 */       assert (bound.min.z <= bound.max.z);
/*      */ 
/*  607 */       this.grid = new ArrayList[xCells][zCells];
/*  608 */       for (int x = 0; x < xCells; x++)
/*  609 */         for (int z = 0; z < zCells; z++)
/*  610 */           this.grid[x][z] = new ArrayList();
/*      */     }
/*      */ 
/*      */     Triangulate.IndexBoxFloat getBound()
/*      */     {
/*  616 */       return this.bound;
/*      */     }
/*      */ 
/*      */     int getQueryId() {
/*  620 */       return this.queryId;
/*      */     }
/*      */ 
/*      */     GridIndexBoxIterator begin(Triangulate.IndexBoxFloat q)
/*      */     {
/*  712 */       this.queryId += 1;
/*  713 */       if (this.queryId == 0)
/*      */       {
/*  716 */         for (int i = 0; i < this.xCells; i++) {
/*  717 */           int j = 0; for (int n = this.zCells; j < n; j++) {
/*  718 */             ArrayList cellArray = this.grid[i][j];
/*  719 */             for (Triangulate.GridEntryBox entryBox : cellArray)
/*  720 */               entryBox.lastQueryId = 0;
/*      */           }
/*      */         }
/*  723 */         this.queryId = 1;
/*      */       }
/*      */ 
/*  726 */       GridIndexBoxIterator it = new GridIndexBoxIterator();
/*  727 */       it.index = this;
/*  728 */       it.query = ((Triangulate.IndexBoxFloat)q.clone());
/*  729 */       it.queryCells.min = getContainingCellClamped(q.min);
/*  730 */       it.queryCells.max = getContainingCellClamped(q.max);
/*      */ 
/*  732 */       assert (it.queryCells.min.x <= it.queryCells.max.x);
/*  733 */       assert (it.queryCells.min.z <= it.queryCells.max.z);
/*      */ 
/*  735 */       it.currentCellX = it.queryCells.min.x;
/*  736 */       it.currentCellZ = it.queryCells.min.z;
/*      */ 
/*  738 */       it.advance();
/*  739 */       return it;
/*      */     }
/*      */ 
/*      */     GridIndexBoxIterator beginAll()
/*      */     {
/*  744 */       return begin(getBound());
/*      */     }
/*      */ 
/*      */     GridIndexBoxIterator end() {
/*  748 */       GridIndexBoxIterator it = new GridIndexBoxIterator();
/*  749 */       it.index = this;
/*  750 */       it.currentEntry = null;
/*  751 */       return it;
/*      */     }
/*      */ 
/*      */     void add(Triangulate.IndexBoxFloat bound, int p)
/*      */     {
/*  756 */       Triangulate.IndexBoxInt ib = getContainingCellsClamped(bound);
/*      */ 
/*  758 */       Triangulate.GridEntryBox newEntry = new Triangulate.GridEntryBox(Triangulate.this);
/*  759 */       newEntry.bound = bound;
/*  760 */       newEntry.value = p;
/*      */ 
/*  763 */       for (int iz = ib.min.z; iz <= ib.max.z; iz++)
/*  764 */         for (int ix = ib.min.x; ix <= ib.max.x; ix++) {
/*  765 */           ArrayList cellArray = getCell(ix, iz);
/*  766 */           cellArray.add(newEntry);
/*      */         }
/*      */     }
/*      */ 
/*      */     void remove(Triangulate.GridEntryBox entry)
/*      */     {
/*  774 */       assert (entry != null);
/*      */ 
/*  777 */       Triangulate.IndexBoxInt ib = getContainingCellsClamped(entry.bound);
/*      */ 
/*  779 */       for (int iz = ib.min.z; iz <= ib.max.z; iz++)
/*  780 */         for (int ix = ib.min.x; ix <= ib.max.x; ix++) {
/*  781 */           ArrayList cellArray = getCell(ix, iz);
/*      */ 
/*  784 */           int i = 0; for (int n = cellArray.size(); i < n; i++)
/*      */           {
/*  786 */             if (cellArray.get(i) == entry) {
/*  787 */               cellArray.remove(i);
/*  788 */               break;
/*      */             }
/*      */           }
/*  791 */           assert (i < n);
/*      */         }
/*      */     }
/*      */ 
/*      */     GridIndexBoxIterator find(Triangulate.IndexBoxFloat bound, int p)
/*      */     {
/*  800 */       for (GridIndexBoxIterator it = begin(bound); !it.atEnd(); it.advanceIfNotEnded()) {
/*  801 */         if ((Triangulate.indexBoxFloatEquals(it.currentEntry.bound, bound)) && (it.currentEntry.value == p))
/*      */         {
/*  803 */           return it;
/*      */         }
/*      */       }
/*  806 */       assert (it.atEnd());
/*  807 */       return it;
/*      */     }
/*      */ 
/*      */     Triangulate.GridEntryBox findPayloadFropoint(Triangulate.IndexPointFloat loc, int p)
/*      */     {
/*  813 */       Triangulate.IndexPointInt ip = getContainingCellClamped(loc);
/*  814 */       ArrayList cellArray = getCell(ip.x, ip.z);
/*      */ 
/*  816 */       int i = 0; for (int n = cellArray.size(); i < n; i++) {
/*  817 */         Triangulate.GridEntryBox entry = (Triangulate.GridEntryBox)cellArray.get(i);
/*  818 */         if (entry.value == p)
/*      */         {
/*  820 */           return entry;
/*      */         }
/*      */       }
/*  823 */       return null;
/*      */     }
/*      */ 
/*      */     ArrayList<Triangulate.GridEntryBox> getCell(int x, int z) {
/*  827 */       assert ((x >= 0) && (x < this.xCells));
/*  828 */       assert ((z >= 0) && (z < this.zCells));
/*  829 */       return this.grid[x][z];
/*      */     }
/*      */ 
/*      */     Triangulate.IndexPointInt getContainingCellClamped(Triangulate.IndexPointFloat p)
/*      */     {
/*  834 */       Triangulate.IndexPointInt ip = new Triangulate.IndexPointInt(Triangulate.this, (int)((p.x - this.bound.min.x) * this.xCells / (this.bound.max.x - this.bound.min.x)), (int)((p.z - this.bound.min.z) * this.zCells / (this.bound.max.z - this.bound.min.z)));
/*      */ 
/*  839 */       if (ip.x < 0)
/*  840 */         ip.x = 0;
/*  841 */       if (ip.x >= this.xCells)
/*  842 */         ip.x = (this.xCells - 1);
/*  843 */       if (ip.z < 0)
/*  844 */         ip.z = 0;
/*  845 */       if (ip.z >= this.zCells) {
/*  846 */         ip.z = (this.zCells - 1);
/*      */       }
/*  848 */       return ip;
/*      */     }
/*      */ 
/*      */     Triangulate.IndexBoxInt getContainingCellsClamped(Triangulate.IndexBoxFloat p)
/*      */     {
/*  853 */       return new Triangulate.IndexBoxInt(Triangulate.this, getContainingCellClamped(p.min), getContainingCellClamped(p.max));
/*      */     }
/*      */ 
/*      */     public class GridIndexBoxIterator
/*      */     {
/*      */       Triangulate.GridIndexBox index;
/*      */       Triangulate.IndexBoxFloat query;
/*      */       Triangulate.IndexBoxInt queryCells;
/*      */       int currentCellX;
/*      */       int currentCellZ;
/*      */       int currentCellArrayIndex;
/*      */       Triangulate.GridEntryBox currentEntry;
/*      */ 
/*      */       public GridIndexBoxIterator()
/*      */       {
/*  632 */         this.index = null;
/*  633 */         this.query = new Triangulate.IndexBoxFloat(Triangulate.this, new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F), new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F));
/*  634 */         this.queryCells = new Triangulate.IndexBoxInt(Triangulate.this, new Triangulate.IndexPointInt(Triangulate.this, 0, 0), new Triangulate.IndexPointInt(Triangulate.this, 0, 0));
/*  635 */         this.currentCellX = 0;
/*  636 */         this.currentCellZ = 0;
/*  637 */         this.currentCellArrayIndex = -1;
/*  638 */         this.currentEntry = null;
/*      */       }
/*      */ 
/*      */       boolean atEnd() {
/*  642 */         return this.currentEntry == null;
/*      */       }
/*      */ 
/*      */       void advanceIfNotEnded() {
/*  646 */         if (!atEnd())
/*  647 */           advance();
/*      */       }
/*      */ 
/*      */       void advance()
/*      */       {
/*  652 */         if (advanceInCell()) {
/*  653 */           return;
/*      */         }
/*      */ 
/*  656 */         this.currentCellX += 1;
/*  657 */         while (this.currentCellZ <= this.queryCells.max.z)
/*      */         {
/*  659 */           while (this.currentCellX <= this.queryCells.max.x)
/*      */           {
/*  662 */             if (advanceInCell())
/*      */             {
/*  664 */               return;
/*      */             }
/*  666 */             this.currentCellX += 1;
/*      */           }
/*  668 */           this.currentCellX = this.queryCells.min.x;
/*  669 */           this.currentCellZ += 1;
/*      */         }
/*      */ 
/*  672 */         assert (this.currentCellX == this.queryCells.min.x);
/*  673 */         assert (this.currentCellZ == this.queryCells.max.z + 1);
/*      */ 
/*  676 */         assert (atEnd());
/*      */       }
/*      */ 
/*      */       boolean advanceInCell()
/*      */       {
/*  685 */         int queryId = this.index.getQueryId();
/*  686 */         ArrayList cellArray = this.index.getCell(this.currentCellX, this.currentCellZ);
/*      */ 
/*  688 */         while (++this.currentCellArrayIndex < cellArray.size())
/*      */         {
/*  690 */           this.currentEntry = ((Triangulate.GridEntryBox)cellArray.get(this.currentCellArrayIndex));
/*  691 */           if (this.currentEntry.lastQueryId == queryId)
/*      */             continue;
/*  693 */           this.currentEntry.lastQueryId = queryId;
/*  694 */           return true;
/*      */         }
/*      */ 
/*  699 */         this.currentEntry = null;
/*  700 */         this.currentCellArrayIndex = -1;
/*      */ 
/*  702 */         return false;
/*      */       }
/*      */ 
/*      */       Triangulate.GridEntryBox getCurrent() {
/*  706 */         assert ((!atEnd()) && (this.currentEntry != null));
/*  707 */         return this.currentEntry;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public class GridIndexPoint
/*      */   {
/*      */     Triangulate.IndexBoxFloat bound;
/*      */     int xCells;
/*      */     int zCells;
/*      */     Triangulate.GridEntryPoint[] grid;
/*      */ 
/*      */     public GridIndexPoint(Triangulate.IndexBoxFloat bound, int xCells, int zCells)
/*      */     {
/*  379 */       this.bound = bound;
/*  380 */       this.xCells = xCells;
/*  381 */       this.zCells = zCells;
/*  382 */       assert ((xCells > 0) && (zCells > 0));
/*  383 */       assert (bound.min.x <= bound.max.x);
/*  384 */       assert (bound.min.z <= bound.max.z);
/*      */ 
/*  387 */       int count = xCells * zCells;
/*  388 */       this.grid = new Triangulate.GridEntryPoint[count];
/*      */     }
/*      */ 
/*      */     Triangulate.IndexBoxFloat getBound() {
/*  392 */       return this.bound;
/*      */     }
/*      */ 
/*      */     GridIndexPointIterator begin(Triangulate.IndexBoxFloat q)
/*      */     {
/*  464 */       GridIndexPointIterator it = new GridIndexPointIterator();
/*  465 */       it.index = this;
/*  466 */       it.query = ((Triangulate.IndexBoxFloat)q.clone());
/*  467 */       it.queryCells.min = ((Triangulate.IndexPointInt)getContainingCellClamped(q.min).clone());
/*  468 */       it.queryCells.max = ((Triangulate.IndexPointInt)getContainingCellClamped(q.max).clone());
/*      */ 
/*  470 */       assert (it.queryCells.min.x <= it.queryCells.max.x);
/*  471 */       assert (it.queryCells.min.z <= it.queryCells.max.z);
/*      */ 
/*  473 */       it.currentCellX = it.queryCells.min.x;
/*  474 */       it.currentCellY = it.queryCells.min.z;
/*  475 */       it.currentEntry = getCell(it.currentCellX, it.currentCellY);
/*      */ 
/*  478 */       if (it.currentEntry == null) {
/*  479 */         it.advance();
/*      */       }
/*  481 */       return it;
/*      */     }
/*      */ 
/*      */     GridIndexPointIterator end() {
/*  485 */       GridIndexPointIterator it = new GridIndexPointIterator();
/*  486 */       it.index = this;
/*  487 */       it.currentEntry = null;
/*      */ 
/*  489 */       return it;
/*      */     }
/*      */ 
/*      */     void add(Triangulate.IndexPointFloat location, int p)
/*      */     {
/*  495 */       Triangulate.IndexPointInt ip = getContainingCellClamped(location);
/*      */ 
/*  497 */       Triangulate.GridEntryPoint newEntry = new Triangulate.GridEntryPoint(Triangulate.this);
/*  498 */       newEntry.location = ((Triangulate.IndexPointFloat)location.clone());
/*  499 */       newEntry.value = p;
/*      */ 
/*  502 */       int index = getCellIndex(ip);
/*  503 */       newEntry.next = this.grid[index];
/*  504 */       this.grid[index] = newEntry;
/*      */     }
/*      */ 
/*      */     void remove(Triangulate.GridEntryPoint entry)
/*      */     {
/*  509 */       assert (entry != null);
/*      */ 
/*  511 */       Triangulate.IndexPointInt ip = getContainingCellClamped(entry.location);
/*  512 */       int index = getCellIndex(ip);
/*      */ 
/*  515 */       Triangulate.GridEntryPoint value = this.grid[index];
/*  516 */       if (value == entry) {
/*  517 */         this.grid[index] = value.next;
/*  518 */         return;
/*      */       }
/*      */ 
/*  521 */       while (value != null) {
/*  522 */         if ((value.next != null) && (value.next == entry))
/*      */         {
/*  524 */           value.next = value.next.next;
/*  525 */           return;
/*      */         }
/*      */ 
/*  529 */         value = value.next;
/*      */       }
/*      */ 
/*  534 */       if (!$assertionsDisabled) throw new AssertionError();
/*      */     }
/*      */ 
/*      */     GridIndexPointIterator find(Triangulate.IndexPointFloat location, int p)
/*      */     {
/*  539 */       GridIndexPointIterator it = null;
/*  540 */       for (it = begin(new Triangulate.IndexBoxFloat(Triangulate.this, location, location)); !it.atEnd(); it.advanceIfNotEnded()) {
/*  541 */         if ((Triangulate.indexPointFloatEquals(it.currentEntry.location, location)) && (it.currentEntry.value == p))
/*      */         {
/*  543 */           return it;
/*      */         }
/*      */       }
/*      */ 
/*  547 */       assert (it.atEnd());
/*  548 */       return it;
/*      */     }
/*      */ 
/*      */     Triangulate.GridEntryPoint getCell(int x, int z) {
/*  552 */       assert ((x >= 0) && (x < this.xCells));
/*  553 */       assert ((z >= 0) && (z < this.zCells));
/*      */ 
/*  555 */       return this.grid[(x + z * this.xCells)];
/*      */     }
/*      */ 
/*      */     int getCellIndex(Triangulate.IndexPointInt ip)
/*      */     {
/*  560 */       assert ((ip.x >= 0) && (ip.x < this.xCells));
/*  561 */       assert ((ip.z >= 0) && (ip.z < this.zCells));
/*      */ 
/*  563 */       int index = ip.x + ip.z * this.xCells;
/*      */ 
/*  565 */       return index;
/*      */     }
/*      */ 
/*      */     Triangulate.IndexPointInt getContainingCellClamped(Triangulate.IndexPointFloat p)
/*      */     {
/*  570 */       Triangulate.IndexPointInt ip = new Triangulate.IndexPointInt(Triangulate.this, (int)((p.x - this.bound.min.x) * this.xCells / (this.bound.max.x - this.bound.min.x)), (int)((p.z - this.bound.min.z) * this.zCells / (this.bound.max.z - this.bound.min.z)));
/*      */ 
/*  575 */       if (ip.x < 0)
/*  576 */         ip.x = 0;
/*  577 */       if (ip.x >= this.xCells)
/*  578 */         ip.x = (this.xCells - 1);
/*  579 */       if (ip.z < 0)
/*  580 */         ip.z = 0;
/*  581 */       if (ip.z >= this.zCells) {
/*  582 */         ip.z = (this.zCells - 1);
/*      */       }
/*  584 */       return ip;
/*      */     }
/*      */ 
/*      */     public class GridIndexPointIterator
/*      */     {
/*      */       Triangulate.GridIndexPoint index;
/*      */       Triangulate.IndexBoxFloat query;
/*      */       Triangulate.IndexBoxInt queryCells;
/*      */       int currentCellX;
/*      */       int currentCellY;
/*      */       Triangulate.GridEntryPoint currentEntry;
/*      */ 
/*      */       public GridIndexPointIterator()
/*      */       {
/*  403 */         this.index = null;
/*  404 */         this.query = new Triangulate.IndexBoxFloat(Triangulate.this, new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F), new Triangulate.IndexPointFloat(Triangulate.this, 0.0F, 0.0F));
/*  405 */         this.queryCells = new Triangulate.IndexBoxInt(Triangulate.this, new Triangulate.IndexPointInt(Triangulate.this, 0, 0), new Triangulate.IndexPointInt(Triangulate.this, 0, 0));
/*  406 */         this.currentCellX = 0;
/*  407 */         this.currentCellY = 0;
/*  408 */         this.currentEntry = null;
/*      */       }
/*      */ 
/*      */       boolean atEnd() {
/*  412 */         return this.currentEntry == null;
/*      */       }
/*      */ 
/*      */       void advanceIfNotEnded() {
/*  416 */         if (!atEnd())
/*  417 */           advance();
/*      */       }
/*      */ 
/*      */       void advance()
/*      */       {
/*  422 */         if (this.currentEntry != null)
/*      */         {
/*  424 */           this.currentEntry = this.currentEntry.next;
/*      */ 
/*  426 */           if (!atEnd())
/*  427 */             return;
/*      */         }
/*  429 */         assert (this.currentEntry == null);
/*      */ 
/*  432 */         this.currentCellX += 1;
/*  433 */         while (this.currentCellY <= this.queryCells.max.z)
/*      */         {
/*  435 */           while (this.currentCellX <= this.queryCells.max.x)
/*      */           {
/*  438 */             this.currentEntry = this.index.getCell(this.currentCellX, this.currentCellY);
/*  439 */             if (this.currentEntry != null)
/*      */             {
/*  441 */               return;
/*      */             }
/*  443 */             this.currentCellX += 1;
/*      */           }
/*  445 */           this.currentCellX = this.queryCells.min.x;
/*  446 */           this.currentCellY += 1;
/*      */         }
/*      */ 
/*  449 */         assert (this.currentCellX == this.queryCells.min.x);
/*  450 */         assert (this.currentCellY == this.queryCells.max.z + 1);
/*      */ 
/*  453 */         assert (atEnd());
/*      */       }
/*      */ 
/*      */       Triangulate.GridEntryPoint get() {
/*  457 */         assert ((!atEnd()) && (this.currentEntry != null));
/*  458 */         return this.currentEntry;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public class GridEntryPoint
/*      */   {
/*      */     Triangulate.IndexPointFloat location;
/*      */     int value;
/*      */     public GridEntryPoint next;
/*      */ 
/*      */     public GridEntryPoint()
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public class GridEntryBox
/*      */   {
/*      */     Triangulate.IndexBoxFloat bound;
/*      */     int value;
/*      */     int lastQueryId;
/*      */ 
/*      */     public GridEntryBox()
/*      */     {
/*  364 */       this.lastQueryId = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public class IndexBoxFloat
/*      */     implements Cloneable
/*      */   {
/*      */     Triangulate.IndexPointFloat min;
/*      */     Triangulate.IndexPointFloat max;
/*      */ 
/*      */     public IndexBoxFloat()
/*      */     {
/*      */     }
/*      */ 
/*      */     public IndexBoxFloat(Triangulate.IndexPointFloat minMaxIn)
/*      */     {
/*  315 */       this.min = ((Triangulate.IndexPointFloat)minMaxIn.clone());
/*  316 */       this.max = ((Triangulate.IndexPointFloat)minMaxIn.clone());
/*      */     }
/*      */ 
/*      */     public IndexBoxFloat(Triangulate.IndexPointFloat minIn, Triangulate.IndexPointFloat maxIn) {
/*  320 */       this.min = ((Triangulate.IndexPointFloat)minIn.clone());
/*  321 */       this.max = ((Triangulate.IndexPointFloat)maxIn.clone());
/*      */     }
/*      */ 
/*      */     public Object clone() {
/*  325 */       return new IndexBoxFloat(Triangulate.this, this.min, this.max);
/*      */     }
/*      */ 
/*      */     float getWidth() {
/*  329 */       return this.max.x - this.min.x;
/*      */     }
/*      */ 
/*      */     float getHeight() {
/*  333 */       return this.max.z - this.min.z;
/*      */     }
/*      */ 
/*      */     void expandToEnclose(Triangulate.IndexPointFloat loc) {
/*  337 */       if (loc.x < this.min.x) this.min.x = loc.x;
/*  338 */       if (loc.z < this.min.z) this.min.z = loc.z;
/*  339 */       if (loc.x > this.max.x) this.max.x = loc.x;
/*  340 */       if (loc.z > this.max.z) this.max.z = loc.z;
/*      */     }
/*      */ 
/*      */     boolean containsPoint(Triangulate.IndexPointFloat loc)
/*      */     {
/*  345 */       return (loc.x >= this.min.x) && (loc.x <= this.max.x) && (loc.z >= this.min.z) && (loc.z <= this.max.z);
/*      */     }
/*      */   }
/*      */ 
/*      */   public class IndexBoxInt
/*      */   {
/*      */     Triangulate.IndexPointInt min;
/*      */     Triangulate.IndexPointInt max;
/*      */ 
/*      */     public IndexBoxInt()
/*      */     {
/*      */     }
/*      */ 
/*      */     public IndexBoxInt(Triangulate.IndexPointInt minMaxIn)
/*      */     {
/*  273 */       this.min = minMaxIn;
/*  274 */       this.max = minMaxIn;
/*      */     }
/*      */ 
/*      */     public IndexBoxInt(Triangulate.IndexPointInt minIn, Triangulate.IndexPointInt maxIn) {
/*  278 */       this.min = minIn;
/*  279 */       this.max = maxIn;
/*      */     }
/*      */ 
/*      */     float getWidth() {
/*  283 */       return this.max.x - this.min.x;
/*      */     }
/*      */ 
/*      */     float getHeight() {
/*  287 */       return this.max.z - this.min.z;
/*      */     }
/*      */ 
/*      */     void expandToEnclose(Triangulate.IndexPointInt loc) {
/*  291 */       if (loc.x < this.min.x) this.min.x = loc.x;
/*  292 */       if (loc.z < this.min.z) this.min.z = loc.z;
/*  293 */       if (loc.x > this.max.x) this.max.x = loc.x;
/*  294 */       if (loc.z > this.max.z) this.max.z = loc.z;
/*      */     }
/*      */ 
/*      */     boolean containsPoint(Triangulate.IndexPointInt loc)
/*      */     {
/*  299 */       return (loc.x >= this.min.x) && (loc.x <= this.max.x) && (loc.z >= this.min.z) && (loc.z <= this.max.z);
/*      */     }
/*      */   }
/*      */ 
/*      */   public class IndexPointInt
/*      */     implements Cloneable
/*      */   {
/*      */     int x;
/*      */     int z;
/*      */ 
/*      */     public IndexPointInt()
/*      */     {
/*      */     }
/*      */ 
/*      */     public IndexPointInt(int x, int z)
/*      */     {
/*  250 */       this.x = x;
/*  251 */       this.z = z;
/*      */     }
/*      */ 
/*      */     public Object clone() {
/*  255 */       return new IndexPointInt(Triangulate.this, this.x, this.z);
/*      */     }
/*      */ 
/*      */     boolean compare(IndexPointInt pt) {
/*  259 */       return (this.x == pt.x) && (this.z == pt.z);
/*      */     }
/*      */   }
/*      */ 
/*      */   public class IndexPointFloat
/*      */     implements Cloneable
/*      */   {
/*      */     float x;
/*      */     float z;
/*      */ 
/*      */     public IndexPointFloat()
/*      */     {
/*      */     }
/*      */ 
/*      */     public IndexPointFloat(float x, float z)
/*      */     {
/*  227 */       this.x = x;
/*  228 */       this.z = z;
/*      */     }
/*      */ 
/*      */     boolean compare(IndexPointFloat pt) {
/*  232 */       return (this.x == pt.x) && (this.z == pt.z);
/*      */     }
/*      */ 
/*      */     public Object clone() {
/*  236 */       return new IndexPointFloat(Triangulate.this, this.x, this.z);
/*      */     }
/*      */   }
/*      */ 
/*      */   public class PolyVert
/*      */     implements Comparable, Cloneable
/*      */   {
/*      */     AOVector v;
/*      */     int myIndex;
/*      */     int next;
/*      */     int prev;
/*      */     int convexResult;
/*      */     boolean isEar;
/*      */     Triangulate.TriPoly polyOwner;
/*      */ 
/*      */     public PolyVert()
/*      */     {
/*      */     }
/*      */ 
/*      */     public PolyVert(float x, float z, Triangulate.TriPoly owner, int myIndex)
/*      */     {
/*  167 */       this.v = new AOVector(x, 0.0F, z);
/*  168 */       this.myIndex = myIndex;
/*  169 */       this.next = -1;
/*  170 */       this.prev = -1;
/*  171 */       this.convexResult = 0;
/*  172 */       this.isEar = false;
/*  173 */       this.polyOwner = owner;
/*      */     }
/*      */ 
/*      */     public Object clone() {
/*  177 */       PolyVert vert = new PolyVert(Triangulate.this, this.v.getX(), this.v.getZ(), this.polyOwner, this.myIndex);
/*  178 */       vert.next = this.next;
/*  179 */       vert.prev = this.prev;
/*  180 */       vert.convexResult = this.convexResult;
/*  181 */       vert.isEar = this.isEar;
/*  182 */       return vert;
/*      */     }
/*      */ 
/*      */     public int compareTo(Object object)
/*      */     {
/*  187 */       PolyVert vert = (PolyVert)object;
/*  188 */       if (this.v.getX() < vert.v.getX())
/*  189 */         return -1;
/*  190 */       if (this.v.getX() > vert.v.getX()) {
/*  191 */         return 1;
/*      */       }
/*  193 */       if (this.v.getZ() < vert.v.getZ())
/*  194 */         return -1;
/*  195 */       if (this.v.getZ() > vert.v.getZ()) {
/*  196 */         return 1;
/*      */       }
/*  198 */       return 0;
/*      */     }
/*      */ 
/*      */     void remap(int[] remapTable) {
/*  202 */       this.myIndex = remapTable[this.myIndex];
/*  203 */       this.next = remapTable[this.next];
/*  204 */       this.prev = remapTable[this.prev];
/*      */     }
/*      */ 
/*      */     public Triangulate.IndexPointFloat getIndexPoint() {
/*  208 */       return new Triangulate.IndexPointFloat(Triangulate.this, this.v.getX(), this.v.getZ());
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.Triangulate
 * JD-Core Version:    0.6.0
 */