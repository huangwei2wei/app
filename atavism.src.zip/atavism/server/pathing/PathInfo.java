/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class PathInfo
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private Map<String, PathObjectType> typeDictionary;
/*     */   private Map<String, PathData> pathDictionary;
/* 141 */   protected static final Logger log = new Logger("PathInfo");
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public PathInfo(Map<String, PathObjectType> typeDictionary, Map<String, PathData> pathDictionary)
/*     */   {
/*  15 */     this.typeDictionary = typeDictionary;
/*  16 */     this.pathDictionary = pathDictionary;
/*     */   }
/*     */ 
/*     */   public PathInfo() {
/*  20 */     this.typeDictionary = new HashMap();
/*  21 */     this.pathDictionary = new HashMap();
/*     */   }
/*     */ 
/*     */   public void performPathingTest(Geometry geometry) {
/*  25 */     performPathingTest1(geometry);
/*  26 */     performPathingTest2(geometry);
/*  27 */     performPathingTest3(geometry);
/*  28 */     performPathingTest4(geometry);
/*     */   }
/*     */ 
/*     */   protected void performPathingTest1(Geometry geometry) {
/*  32 */     log.debug("PATHING TEST 1");
/*     */ 
/*  37 */     String type = "Generic";
/*  38 */     AOVector loc1 = getCenterOfPolygon(type, "meetinghouse1", 6);
/*  39 */     AOVector loc2 = getCenterOfPolygon(type, "meetinghouse2", 7);
/*  40 */     PathFinderValue value = performSearch(type, geometry, loc1, loc2);
/*  41 */     showTestResult(value, loc1, loc2);
/*     */   }
/*     */ 
/*     */   protected void performPathingTest2(Geometry geometry) {
/*  45 */     log.debug("PATHING TEST 2");
/*     */ 
/*  48 */     AOVector loc1 = new AOVector(-146466.0F, 25908.0F, -302033.0F);
/*  49 */     String type = "Generic";
/*  50 */     AOVector loc2 = getCenterOfPolygon(type, "meetinghouse2", 7);
/*  51 */     PathFinderValue value = performSearch(type, geometry, loc1, loc2);
/*  52 */     showTestResult(value, loc1, loc2);
/*     */   }
/*     */ 
/*     */   protected void performPathingTest3(Geometry geometry) {
/*  56 */     log.debug("PATHING TEST 3");
/*     */ 
/*  60 */     AOVector loc1 = new AOVector(-123465.0F, 27281.0F, -303274.0F);
/*  61 */     String type = "Generic";
/*  62 */     AOVector loc2 = getCenterOfPolygon(type, "meetinghouse2", 7);
/*  63 */     PathFinderValue value = performSearch(type, geometry, loc1, loc2);
/*  64 */     showTestResult(value, loc1, loc2);
/*     */   }
/*     */ 
/*     */   protected void performPathingTest4(Geometry geometry) {
/*  68 */     log.debug("PATHING TEST 4");
/*     */ 
/*  71 */     AOVector loc1 = new AOVector(-123465.0F, 27281.0F, -303274.0F);
/*  72 */     AOVector loc2 = new AOVector(-136465.0F, 27597.0F, -214821.0F);
/*  73 */     String type = "Generic";
/*  74 */     PathFinderValue value = performSearch(type, geometry, loc1, loc2);
/*  75 */     showTestResult(value, loc1, loc2);
/*     */   }
/*     */ 
/*     */   protected AOVector getCenterOfPolygon(String type, String modelName, int polygonIndex) {
/*  79 */     if (Log.loggingDebug)
/*  80 */       log.debug("Getting PathData for model " + modelName);
/*  81 */     PathData pd = (PathData)this.pathDictionary.get(modelName);
/*  82 */     PathObject po = pd.getPathObjectForType(type);
/*  83 */     PathPolygon cv = po.getCVPolygon(polygonIndex);
/*  84 */     AOVector loc = cv.getCentroid();
/*  85 */     if (Log.loggingDebug)
/*  86 */       log.debug(modelName + " polygon " + polygonIndex + " centroid is " + loc);
/*  87 */     return loc;
/*     */   }
/*     */ 
/*     */   protected PathFinderValue performSearch(String type, Geometry geometry, AOVector loc1, AOVector loc2) {
/*  91 */     log.debug("Creating PathSearcher");
/*  92 */     PathSearcher.createPathSearcher(this, geometry);
/*  93 */     log.debug("Calling PathSearcher.findPath");
/*  94 */     return PathSearcher.findPath(type, loc1, loc2, true);
/*     */   }
/*     */ 
/*     */   protected void showTestResult(PathFinderValue value, AOVector loc1, AOVector loc2) {
/*  98 */     if (Log.loggingDebug) {
/*  99 */       log.debug("Plotting path from " + loc1 + " to " + loc2 + ", PathResult was " + value.getResult().toString());
/* 100 */       log.debug("Calculated path is " + value.stringPath(0));
/* 101 */       log.debug("TerrainString is '" + value.getTerrainString() + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   public float getTypeHalfWidth(String type) {
/* 106 */     if (this.typeDictionary.containsKey(type)) {
/* 107 */       return ((PathObjectType)this.typeDictionary.get(type)).getWidth();
/*     */     }
/* 109 */     log.error("In getTypeHalfWidth, can't find path object type '" + type + "'!");
/* 110 */     return 100.0F;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 115 */     return new PathInfo(this.typeDictionary, this.pathDictionary);
/*     */   }
/*     */ 
/*     */   public boolean pathObjectTypeSupported(String type) {
/* 119 */     return this.typeDictionary.containsKey(type);
/*     */   }
/*     */ 
/*     */   public void setTypeDictionary(Map<String, PathObjectType> typeDictionary) {
/* 123 */     this.typeDictionary = typeDictionary;
/*     */   }
/*     */ 
/*     */   public Map<String, PathObjectType> getTypeDictionary() {
/* 127 */     return this.typeDictionary;
/*     */   }
/*     */ 
/*     */   public void setPathDictionary(Map<String, PathData> pathDictionary) {
/* 131 */     this.pathDictionary = pathDictionary;
/*     */   }
/*     */ 
/*     */   public Map<String, PathData> getPathDictionary() {
/* 135 */     return this.pathDictionary;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathInfo
 * JD-Core Version:    0.6.0
 */