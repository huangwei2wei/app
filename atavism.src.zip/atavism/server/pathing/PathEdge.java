/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PathEdge
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   AOVector start;
/*     */   AOVector end;
/* 133 */   protected static final Logger log = new Logger("PathEdge");
/* 134 */   protected static boolean logAll = false;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public PathEdge()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PathEdge(AOVector start, AOVector end)
/*     */   {
/*  18 */     this.start = start;
/*  19 */     this.end = end;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  23 */     return new StringBuilder().append("[PathEdge start=").append(getStart()).append(",end=").append(getEnd()).append("]").toString();
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  28 */     return new PathEdge(this.start, this.end);
/*     */   }
/*     */ 
/*     */   public AOVector getStart() {
/*  32 */     return this.start;
/*     */   }
/*     */ 
/*     */   public AOVector getEnd() {
/*  36 */     return this.end;
/*     */   }
/*     */ 
/*     */   public AOVector getMidpoint() {
/*  40 */     return new AOVector((this.start.getX() + this.end.getX()) * 0.5F, (this.start.getY() + this.end.getY()) * 0.5F, (this.start.getZ() + this.end.getZ()) * 0.5F);
/*     */   }
/*     */ 
/*     */   public AOVector bestPoint(AOVector loc1, AOVector loc2, float offset)
/*     */   {
/*  49 */     PathIntersection intersection = PathIntersection.findIntersection(loc1, loc2, this.start, this.end);
/*  50 */     float len = AOVector.distanceTo(this.start, this.end);
/*  51 */     float offsetFraction = offset / len;
/*     */ 
/*  53 */     AOVector delta = new AOVector(this.end.getX() - this.start.getX(), 0.0F, this.end.getZ() - this.start.getZ());
/*  54 */     delta.normalize();
/*     */     float w2;
/*     */     float w2;
/*  56 */     if (intersection == null) {
/*  57 */       w2 = PathIntersection.distancePointLine(this.start, loc1, loc2) < PathIntersection.distancePointLine(this.end, loc1, loc2) ? offsetFraction : 1.0F - offsetFraction;
/*     */     }
/*     */     else
/*  60 */       w2 = intersection.getWhere2();
/*  61 */     AOVector best = null;
/*  62 */     if (w2 < offsetFraction) {
/*  63 */       best = new AOVector(this.start.getX() + delta.getX() * offset, this.start.getY(), this.start.getZ() + delta.getZ() * offset);
/*     */     }
/*  66 */     else if (w2 > 1.0F - offsetFraction) {
/*  67 */       best = new AOVector(this.end.getX() - delta.getX() * offset, this.end.getY(), this.end.getZ() - delta.getZ() * offset);
/*     */     }
/*     */     else
/*     */     {
/*  72 */       best = new AOVector(PathIntersection.getLinePoint(w2, new AOVector(this.start), new AOVector(this.end)));
/*  73 */     }if (logAll) {
/*  74 */       log.debug(new StringBuilder().append("bestPoint: start = ").append(this.start).append("; end = ").append(this.end).append("; best = ").append(best).append("; offset = ").append(offset).append("; offsetFraction = ").append(offsetFraction).append("; w2 = ").append(w2).toString());
/*     */     }
/*     */ 
/*  77 */     return best;
/*     */   }
/*     */ 
/*     */   public List<AOVector> getNearAndFarNormalPoints(AOVector loc1, AOVector loc2, float offset) {
/*  81 */     List list = new LinkedList();
/*  82 */     AOVector fbest = new AOVector(bestPoint(loc1, loc2, offset));
/*  83 */     AOVector p = new AOVector(this.end).sub(this.start);
/*  84 */     p.setY(0.0F);
/*  85 */     p.normalize();
/*     */ 
/*  87 */     float t = p.getX();
/*  88 */     p.setX(-p.getZ());
/*  89 */     p.setZ(t);
/*  90 */     p.multiply(offset);
/*  91 */     AOVector near = AOVector.add(fbest, p);
/*  92 */     p.multiply(-1.0F);
/*  93 */     AOVector far = AOVector.add(fbest, p);
/*     */ 
/*  97 */     float loc2ToNear = AOVector.distanceTo(loc2, near);
/*  98 */     float loc2ToFar = AOVector.distanceTo(loc2, far);
/*  99 */     if (loc2ToNear < loc2ToFar) {
/* 100 */       AOVector pt = near;
/* 101 */       near = far;
/* 102 */       far = pt;
/*     */     }
/* 104 */     AOVector best = new AOVector(fbest);
/* 105 */     float loc1ToBest = AOVector.distanceTo(loc1, best);
/* 106 */     float loc2ToBest = AOVector.distanceTo(loc2, best);
/* 107 */     boolean useNear = (loc1ToBest > offset) && (loc1ToBest > AOVector.distanceTo(near, best));
/* 108 */     boolean useFar = (loc2ToBest > offset) && (loc2ToBest > AOVector.distanceTo(far, best));
/* 109 */     if ((useNear) && (useFar)) {
/* 110 */       list.add(near);
/* 111 */       list.add(far);
/*     */     }
/* 113 */     else if ((useNear) && (!useFar)) {
/* 114 */       list.add(near);
/* 115 */       list.add(best);
/*     */     }
/* 117 */     else if ((!useNear) && (!useFar)) {
/* 118 */       list.add(best);
/* 119 */     } else if ((!useNear) && (useFar)) {
/* 120 */       list.add(best);
/* 121 */       list.add(far);
/*     */     }
/* 123 */     if (logAll) {
/* 124 */       log.debug(new StringBuilder().append("getNearAndFarNormalPoints: loc1 = ").append(loc1).append("; loc2 = ").append(loc2).append("; best = ").append(best).append("; useNear = ").append(useNear ? "true" : "false").append("; near = ").append(near).append("; useFar = ").append(useFar ? "true" : "false").append("; far = ").append(far).toString());
/*     */     }
/*     */ 
/* 127 */     return list;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathEdge
 * JD-Core Version:    0.6.0
 */