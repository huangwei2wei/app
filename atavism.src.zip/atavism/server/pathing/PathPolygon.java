/*     */ package atavism.server.pathing;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Plane;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PathPolygon
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   public static final byte Illegal = 0;
/*     */   public static final byte CV = 1;
/*     */   public static final byte Terrain = 2;
/*     */   public static final byte Bounding = 3;
/*     */   int index;
/*     */   byte polygonKind;
/*     */   List<AOVector> corners;
/* 237 */   Plane plane = null;
/* 238 */   protected static final Logger log = new Logger("PathPolygon");
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public PathPolygon()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PathPolygon(int index, byte kind, List<AOVector> corners)
/*     */   {
/*  18 */     this.index = index;
/*  19 */     this.polygonKind = kind;
/*  20 */     this.corners = new LinkedList();
/*  21 */     for (AOVector p : corners)
/*  22 */       this.corners.add(p);
/*     */   }
/*     */ 
/*     */   public String formatPolygonKind(byte val)
/*     */   {
/*  31 */     switch (val) {
/*     */     case 0:
/*  33 */       return "Illegal";
/*     */     case 1:
/*  35 */       return "CV";
/*     */     case 2:
/*  37 */       return "Terrain";
/*     */     case 3:
/*  39 */       return "Bounding";
/*     */     }
/*  41 */     return "Unknown PolygonKind " + val;
/*     */   }
/*     */ 
/*     */   public PathPolygon ensureWindingOrder(boolean ccw)
/*     */   {
/*  46 */     int ccwCount = 0;
/*  47 */     int size = this.corners.size();
/*  48 */     for (int i = 0; i < size; i++) {
/*  49 */       if (AOVector.counterClockwisePoints((AOVector)this.corners.get(PathSynth.wrap(i - 1, size)), (AOVector)this.corners.get(i), (AOVector)this.corners.get(PathSynth.wrap(i + 1, size))))
/*  50 */         ccwCount++;
/*     */     }
/*  52 */     boolean mustReverse = ((ccw) && (ccwCount < size / 2)) || ((!ccw) && (ccwCount > size / 2));
/*  53 */     if (mustReverse) {
/*  54 */       List newCorners = new LinkedList();
/*  55 */       for (int i = 0; i < size; i++)
/*  56 */         newCorners.add(i, this.corners.get(size - i - 1));
/*  57 */       this.corners = newCorners;
/*     */     }
/*  59 */     return this;
/*     */   }
/*     */ 
/*     */   public static byte parsePolygonKind(String s) {
/*  63 */     if (s.equals("Illegal"))
/*  64 */       return 0;
/*  65 */     if (s.equals("CV"))
/*  66 */       return 1;
/*  67 */     if (s.equals("Terrain"))
/*  68 */       return 2;
/*  69 */     if (s.equals("Bounding")) {
/*  70 */       return 3;
/*     */     }
/*  72 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean pointInside2D(AOVector p) {
/*  76 */     boolean inside = false;
/*  77 */     int j = this.corners.size() - 1;
/*  78 */     for (int i = 0; i < this.corners.size(); j = i++) {
/*  79 */       AOVector ci = new AOVector((AOVector)this.corners.get(i));
/*  80 */       AOVector cj = new AOVector((AOVector)this.corners.get(j));
/*  81 */       float fa = (cj.getZ() - ci.getZ()) * (p.getX() - ci.getX());
/*  82 */       float fb = (cj.getX() - ci.getX()) * (p.getZ() - ci.getZ());
/*  83 */       if (((ci.getZ() > p.getZ()) || (p.getZ() >= cj.getZ()) || (fa >= fb)) && ((cj.getZ() > p.getZ()) || (p.getZ() >= ci.getZ()) || (fa <= fb)))
/*     */         continue;
/*  85 */       inside = !inside;
/*     */     }
/*  87 */     return inside;
/*     */   }
/*     */ 
/*     */   public boolean pointInside(AOVector p, float tolerance) {
/*  91 */     if (!pointInside2D(p))
/*  92 */       return false;
/*  93 */     if (this.plane == null)
/*  94 */       this.plane = new Plane((AOVector)this.corners.get(0), (AOVector)this.corners.get(1), (AOVector)this.corners.get(2));
/*  95 */     return this.plane.getDistance(p) <= tolerance;
/*     */   }
/*     */ 
/*     */   public Integer cornerNumberForPoint(AOVector point, float epsilon) {
/*  99 */     int i = 0;
/* 100 */     for (AOVector corner : this.corners) {
/* 101 */       if (AOVector.distanceToSquared(point, corner) < epsilon)
/* 102 */         return Integer.valueOf(i);
/* 103 */       i++;
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   public int getClosestCornerToPoint(AOVector loc)
/*     */   {
/* 110 */     int count = this.corners.size();
/* 111 */     int closestCorner = -1;
/* 112 */     float closestDistance = 3.4028235E+38F;
/* 113 */     for (int i = 0; i < count; i++) {
/* 114 */       float d = AOVector.distanceTo(loc, (AOVector)this.corners.get(i));
/* 115 */       if (d < closestDistance) {
/* 116 */         closestDistance = d;
/* 117 */         closestCorner = i;
/*     */       }
/*     */     }
/* 120 */     return closestCorner;
/*     */   }
/*     */ 
/*     */   public int getFarthestCornerFromPoint(AOVector loc)
/*     */   {
/* 125 */     int count = this.corners.size();
/* 126 */     int farthestCorner = -1;
/* 127 */     float farthestDistance = 1.4E-45F;
/* 128 */     for (int i = 0; i < count; i++) {
/* 129 */       float d = AOVector.distanceTo(loc, (AOVector)this.corners.get(i));
/* 130 */       if (d > farthestDistance) {
/* 131 */         farthestDistance = d;
/* 132 */         farthestCorner = i;
/*     */       }
/*     */     }
/* 135 */     return farthestCorner;
/*     */   }
/*     */ 
/*     */   public static List<PolyIntersection> findPolyIntersections(PathPolygon poly1, PathPolygon poly2)
/*     */   {
/* 141 */     int p1Size = poly1.corners.size();
/* 142 */     int p2Size = poly2.corners.size();
/* 143 */     if (Log.loggingDebug)
/* 144 */       log.debug("PathPolygon.findPolyIntersections: Finding intersections of " + poly1 + " and " + poly2);
/* 145 */     List intersections = null;
/* 146 */     for (int p1Index = 0; p1Index < p1Size - 1; p1Index++) {
/* 147 */       AOVector p1Corner1 = (AOVector)poly1.corners.get(p1Index);
/* 148 */       AOVector p1Corner2 = (AOVector)poly1.corners.get(p1Index + 1);
/* 149 */       for (int p2Index = 0; p2Index < p2Size - 1; p2Index++) {
/* 150 */         AOVector p2Corner1 = (AOVector)poly2.corners.get(p2Index);
/* 151 */         AOVector p2Corner2 = (AOVector)poly2.corners.get(p2Index + 1);
/* 152 */         PathIntersection intr = PathIntersection.findIntersection(p1Corner1, p1Corner2, p2Corner1, p2Corner2);
/* 153 */         if (intr != null) {
/* 154 */           if (intersections == null)
/* 155 */             intersections = new LinkedList();
/* 156 */           intersections.add(new PolyIntersection(p1Index, p2Index, intr));
/*     */         }
/*     */       }
/*     */     }
/* 160 */     return intersections;
/*     */   }
/*     */ 
/*     */   public PathIntersection closestIntersection(PathObject pathObject, AOVector loc1, AOVector loc2)
/*     */   {
/* 167 */     float dispX = loc2.getX() - loc1.getX();
/* 168 */     float dispZ = loc2.getZ() - loc1.getZ();
/* 169 */     PathIntersection closest = null;
/* 170 */     int j = this.corners.size() - 1;
/* 171 */     for (int i = 0; i < this.corners.size(); j = i++) {
/* 172 */       AOVector ci = (AOVector)this.corners.get(i);
/* 173 */       AOVector cj = (AOVector)this.corners.get(j);
/* 174 */       float ciX = ci.getX();
/* 175 */       float ciZ = ci.getZ();
/* 176 */       PathIntersection intersection = PathIntersection.findIntersection(pathObject, this, loc1.getX(), loc1.getZ(), dispX, dispZ, ciX, ciZ, cj.getX() - ciX, cj.getZ() - ciZ);
/*     */ 
/* 179 */       if (intersection == null)
/*     */         continue;
/* 181 */       if ((closest == null) || (intersection.getWhere1() < closest.getWhere1()))
/* 182 */         closest = intersection;
/*     */     }
/* 184 */     return closest;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 188 */     String pts = "";
/* 189 */     for (AOVector corner : this.corners) {
/* 190 */       if (pts.length() > 0)
/* 191 */         pts = pts + ", ";
/* 192 */       pts = pts + corner.toString();
/*     */     }
/* 194 */     return "[PathPolygon: index = " + this.index + "; kind = " + formatPolygonKind(this.polygonKind) + "; corners = " + pts + "]";
/*     */   }
/*     */ 
/*     */   public AOVector getCentroid()
/*     */   {
/* 199 */     AOVector result = new AOVector(0.0F, 0.0F, 0.0F);
/* 200 */     for (AOVector corner : this.corners)
/* 201 */       result.add(corner);
/* 202 */     result.multiply(1.0F / this.corners.size());
/* 203 */     return result;
/*     */   }
/*     */ 
/*     */   public Object clone() {
/* 207 */     return new PathPolygon(this.index, this.polygonKind, this.corners);
/*     */   }
/*     */ 
/*     */   public byte getKind() {
/* 211 */     return this.polygonKind;
/*     */   }
/*     */ 
/*     */   public void setKind(byte val) {
/* 215 */     this.polygonKind = val;
/*     */   }
/*     */ 
/*     */   public int getIndex() {
/* 219 */     return this.index;
/*     */   }
/*     */ 
/*     */   public void setIndex(int index) {
/* 223 */     this.index = index;
/*     */   }
/*     */ 
/*     */   public List<AOVector> getCorners() {
/* 227 */     return this.corners;
/*     */   }
/*     */ 
/*     */   public void setCorners(List<AOVector> corners) {
/* 231 */     this.corners = corners;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.pathing.PathPolygon
 * JD-Core Version:    0.6.0
 */