/*    */ package atavism.server.worldmgr;
/*    */ 
/*    */ public class CharacterGenerator
/*    */ {
/* 15 */   protected CharacterFactory charFactory = null;
/*    */ 
/*    */   public CharacterFactory getCharacterFactory()
/*    */   {
/*  9 */     return this.charFactory;
/*    */   }
/*    */   public void setCharacterFactory(CharacterFactory fact) {
/* 12 */     this.charFactory = fact;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.worldmgr.CharacterGenerator
 * JD-Core Version:    0.6.0
 */