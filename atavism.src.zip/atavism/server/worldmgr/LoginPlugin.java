/*      */ package atavism.server.worldmgr;
/*      */ 
/*      */ import atavism.msgsys.MessageAgent;
/*      */ import atavism.server.engine.Database;
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.engine.EnginePlugin;
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.engine.PluginStatus;
/*      */ import atavism.server.messages.PropertyMessage;
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.network.TcpAcceptCallback;
/*      */ import atavism.server.network.TcpServer;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.NamedThreadFactory;
/*      */ import atavism.server.util.SecureToken;
/*      */ import atavism.server.util.SecureTokenManager;
/*      */ import atavism.server.util.SecureTokenSpec;
/*      */ import atavism.server.util.ServerVersion;
/*      */ import java.io.IOException;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.Serializable;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketAddress;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.SelectionKey;
/*      */ import java.nio.channels.Selector;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ 
/*      */ public class LoginPlugin extends EnginePlugin
/*      */   implements TcpAcceptCallback
/*      */ {
/*      */   public static final int MSGCODE_CHARACTER_RESPONSE = 2;
/*      */   public static final int MSGCODE_CHARACTER_DELETE = 3;
/*      */   public static final int MSGCODE_CHARACTER_DELETE_RESPONSE = 4;
/*      */   public static final int MSGCODE_CHARACTER_CREATE = 5;
/*      */   public static final int MSGCODE_CHARACTER_CREATE_RESPONSE = 6;
/*      */   public static final int MSGCODE_CHARACTER_REQUEST = 7;
/*      */   public static final int MSGCODE_CHARACTER_SELECT_REQUEST = 8;
/*      */   public static final int MSGCODE_CHARACTER_SELECT_RESPONSE = 9;
/*      */   public static final int MSGCODE_SECURE_CHARACTER_REQUEST = 10;
/*      */   public static final int LOGIN_IDLE_TIMEOUT = 2000000;
/*  943 */   private static ExecutorService threadPool = Executors.newCachedThreadPool(new NamedThreadFactory("LoginConnection"));
/*      */ 
/*  993 */   private TcpServer loginListener = null;
/*      */ 
/*  995 */   private Integer tcpPort = null;
/*      */ 
/*  997 */   private Object characterCreateLock = new Object();
/*      */ 
/* 1005 */   public static boolean SecureToken = true;
/* 1006 */   public static long TokenValidTime = 60000L;
/*      */ 
/* 1012 */   public static Integer WorldId = null;
/*      */ 
/* 1014 */   private static CharacterGenerator characterGenerator = new CharacterGenerator();
/*      */ 
/*      */   public LoginPlugin()
/*      */   {
/*   37 */     super("Login");
/*   38 */     setPluginType("Login");
/*      */ 
/*   42 */     String secureTokenString = Engine.getProperty("atavism.security.secure_token");
/*   43 */     Log.debug("constructor: secureTokenString=" + secureTokenString);
/*   44 */     if (secureTokenString != null) {
/*   45 */       Boolean secureToken = Boolean.valueOf(Boolean.parseBoolean(secureTokenString));
/*   46 */       SecureToken = secureToken.booleanValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void dbConnect()
/*      */   {
/*   69 */     if (Engine.getDatabase() == null) {
/*   70 */       Log.debug("Setting Database in WorldManager.dbConnect");
/*   71 */       Engine.setDatabase(new Database(Engine.getDBDriver()));
/*      */     }
/*      */ 
/*   74 */     Engine.getDatabase().connect(Engine.getDBUrl(), Engine.getDBUser(), Engine.getDBPassword());
/*      */   }
/*      */ 
/*      */   public void setTCPPort(int port)
/*      */   {
/*   86 */     this.tcpPort = Integer.valueOf(port);
/*      */   }
/*      */ 
/*      */   public int getTCPPort()
/*      */   {
/*   97 */     if (this.tcpPort == null) {
/*   98 */       return Engine.getWorldMgrPort().intValue();
/*      */     }
/*  100 */     return this.tcpPort.intValue();
/*      */   }
/*      */ 
/*      */   public void onActivate()
/*      */   {
/*      */     try {
/*  106 */       this.loginListener = new TcpServer(getTCPPort());
/*  107 */       this.loginListener.registerAcceptCallback(this);
/*  108 */       this.loginListener.start();
/*      */     } catch (Exception e) {
/*  110 */       Log.exception("LoginPlugin.onActivate caught exception", e);
/*  111 */       System.exit(1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static String socketToString(SocketChannel channel)
/*      */   {
/*  117 */     Socket socket = channel.socket();
/*  118 */     return "remote=" + socket.getRemoteSocketAddress() + " local=" + socket.getLocalSocketAddress();
/*      */   }
/*      */ 
/*      */   public void onTcpAccept(SocketChannel clientSocket)
/*      */   {
/*      */     try {
/*  124 */       Log.info("LoginPlugin: CONNECTION " + socketToString(clientSocket));
/*  125 */       threadPool.execute(new SocketHandler(clientSocket));
/*      */     } catch (IOException e) {
/*  127 */       Log.exception("LoginListener: ", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected CharacterResponseMessage handleCharacterRequestMessage(CharacterRequestMessage message, SocketHandler clientSocket)
/*      */   {
/*  661 */     AOByteBuffer authToken = message.getAuthToken();
/*  662 */     SecureToken token = SecureTokenManager.getInstance().importToken(authToken);
/*  663 */     boolean valid = true;
/*      */ 
/*  665 */     if (SecureToken) {
/*  666 */       valid = token.getValid();
/*      */     }
/*  668 */     if (!token.getIssuerId().equals("master")) {
/*  669 */       valid = false;
/*      */     }
/*      */ 
/*  672 */     OID uid = null;
/*  673 */     Serializable uidObj = token.getProperty("account_id");
/*  674 */     if ((uidObj instanceof Integer)) {
/*  675 */       uid = OID.fromLong(((Integer)uidObj).intValue());
/*      */     }
/*  677 */     if ((uidObj instanceof Long)) {
/*  678 */       uid = OID.fromLong(((Long)uidObj).longValue());
/*      */     }
/*  680 */     if ((uidObj instanceof String)) {
/*  681 */       uid = OID.parseLong((String)uidObj);
/*      */     }
/*      */ 
/*  684 */     CharacterResponseMessage response = new CharacterResponseMessage();
/*  685 */     response.setServerVersion("2.5.0");
/*  686 */     response.setWorldFilesUrl(Engine.getProperty("atavism.world_files_url"));
/*      */ 
/*  688 */     if (valid) {
/*  689 */       clientSocket.setAccountId(uid);
/*  690 */       clientSocket.setCharacterInfo(response.getCharacters());
/*      */     }
/*      */     else {
/*  693 */       response.setErrorMessage("invalid master token");
/*      */     }
/*  695 */     return response;
/*      */   }
/*      */ 
/*      */   protected CharacterCreateResponseMessage handleCharacterCreateMessage(CharacterCreateMessage message, SocketHandler clientSocket)
/*      */   {
/*  766 */     CharacterCreateResponseMessage response = new CharacterCreateResponseMessage();
/*      */ 
/*  768 */     HashMap props = new HashMap();
/*  769 */     props.put("status", Boolean.FALSE);
/*  770 */     props.put("errorMessage", "character creation is not supported");
/*  771 */     response.setProperties(props);
/*  772 */     return response;
/*      */   }
/*      */ 
/*      */   protected CharacterDeleteResponseMessage handleCharacterDeleteMessage(CharacterDeleteMessage message, SocketHandler clientSocket)
/*      */   {
/*  790 */     CharacterDeleteResponseMessage response = new CharacterDeleteResponseMessage();
/*      */ 
/*  792 */     HashMap props = new HashMap();
/*  793 */     props.put("status", Boolean.FALSE);
/*  794 */     props.put("errorMessage", "character deletion is not supported");
/*  795 */     response.setProperties(props);
/*  796 */     return response;
/*      */   }
/*      */ 
/*      */   protected CharacterSelectResponseMessage handleCharacterSelectRequestMessage(CharacterSelectRequestMessage message, SocketHandler clientSocket)
/*      */   {
/*  862 */     boolean charAllowed = false;
/*  863 */     OID characterOid = (OID)message.getProperties().get("characterId");
/*  864 */     Log.debug("CharacterSelectResponse: characterOid: " + characterOid + " and data: " + characterOid.toLong());
/*  865 */     String characterName = null;
/*  866 */     for (Map charInfo : clientSocket.getCharacterInfo()) {
/*  867 */       Log.debug("CharacterSelectResponse: charInfo: " + charInfo.toString());
/*      */ 
/*  869 */       if ((charInfo.containsKey("characterId")) && ((charInfo.get("characterId") instanceof OID)) && (((OID)charInfo.get("characterId")).equals(characterOid)))
/*      */       {
/*  871 */         charAllowed = true;
/*  872 */         characterName = (String)charInfo.get("characterName");
/*  873 */         break;
/*      */       }
/*      */     }
/*      */ 
/*  877 */     Log.info("LoginPlugin: SELECT_CHARACTER oid=" + characterOid + " name=" + characterName + " allowed=" + charAllowed);
/*      */ 
/*  880 */     CharacterSelectResponseMessage response = new CharacterSelectResponseMessage();
/*  881 */     HashMap props = new HashMap();
/*  882 */     SecureTokenSpec tokenSpec = new SecureTokenSpec(2, Engine.getAgent().getName(), System.currentTimeMillis() + TokenValidTime);
/*      */ 
/*  885 */     tokenSpec.setProperty("character_oid", characterOid);
/*  886 */     if (charAllowed) {
/*  887 */       Map characterProps = new HashMap();
/*  888 */       PluginStatus proxyStatus = selectProxyPlugin(characterProps);
/*  889 */       if (proxyStatus == null) {
/*  890 */         props.put("errorMessage", "Server not ready for login");
/*  891 */         response.setProperties(props);
/*  892 */         return response;
/*      */       }
/*  894 */       tokenSpec.setProperty("proxy_server", proxyStatus.agent_name);
/*  895 */       byte[] token = SecureTokenManager.getInstance().generateToken(tokenSpec);
/*  896 */       setProxyProperties(props, proxyStatus);
/*  897 */       props.put("token", token);
/*      */     }
/*      */     else {
/*  900 */       props.put("errorMessage", "Character oid not allowed for this account");
/*      */     }
/*  902 */     response.setProperties(props);
/*  903 */     return response;
/*      */   }
/*      */ 
/*      */   protected boolean setProxyProperties(Map<String, Serializable> props, PluginStatus proxy)
/*      */   {
/*  915 */     if (proxy == null) {
/*  916 */       return false; } Map info = Engine.makeMapOfString(proxy.info);
/*  919 */     String hostname = (String)info.get("host");
/*      */     int port;
/*      */     try { hostname = (String)info.get("host");
/*  923 */       port = Integer.parseInt((String)info.get("port"));
/*      */     } catch (Exception e)
/*      */     {
/*  926 */       Log.exception("setProxyProperties: proxy " + proxy.plugin_name + " invalid port number: " + (String)info.get("port"), e);
/*      */ 
/*  928 */       return false;
/*      */     }
/*      */ 
/*  931 */     props.put("proxyHostname", hostname);
/*  932 */     props.put("proxyPort", Integer.valueOf(port));
/*      */ 
/*  934 */     if (Log.loggingDebug) {
/*  935 */       Log.debug("LoginPlugin: assigned proxy " + proxy.plugin_name + " host=" + proxy.host_name + " port=" + port);
/*      */     }
/*      */ 
/*  940 */     return true;
/*      */   }
/*      */ 
/*      */   public static CharacterGenerator getCharacterGenerator()
/*      */   {
/*  949 */     return characterGenerator;
/*      */   }
/*      */ 
/*      */   protected final PluginStatus selectProxyPlugin(Map<String, Serializable> characterProperties)
/*      */   {
/*  955 */     List plugins = Engine.getDatabase().getPluginStatus("Proxy");
/*      */ 
/*  957 */     Iterator iterator = plugins.iterator();
/*  958 */     while (iterator.hasNext()) {
/*  959 */       PluginStatus plugin = (PluginStatus)iterator.next();
/*  960 */       if (plugin.run_id != Engine.getAgent().getDomainStartTime()) {
/*  961 */         iterator.remove();
/*      */       }
/*      */     }
/*  964 */     if (plugins.size() == 0)
/*  965 */       return null;
/*  966 */     return selectBestProxy(plugins, characterProperties);
/*      */   }
/*      */ 
/*      */   protected PluginStatus selectBestProxy(List<PluginStatus> plugins, Map<String, Serializable> characterProperties)
/*      */   {
/*  972 */     PluginStatus selection = null;
/*  973 */     int selectionPlayerCount = 2147483647;
/*  974 */     for (PluginStatus plugin : plugins) { Map status = Engine.makeMapOfString(plugin.status);
/*      */       int playerCount;
/*      */       try { playerCount = Integer.parseInt((String)status.get("players"));
/*      */       } catch (Exception e)
/*      */       {
/*  981 */         Log.exception("selectBestProxy: proxy " + plugin.plugin_name + " invalid player count: " + (String)status.get("players"), e);
/*      */       }
/*  983 */       continue;
/*      */ 
/*  985 */       if (playerCount < selectionPlayerCount) {
/*  986 */         selection = plugin;
/*  987 */         selectionPlayerCount = playerCount;
/*      */       }
/*      */     }
/*  990 */     return selection;
/*      */   }
/*      */ 
/*      */   public static class CharacterSelectResponseMessage
/*      */   {
/*      */     private Map<String, Serializable> props;
/*      */ 
/*      */     public void setProperties(HashMap<String, Serializable> props)
/*      */     {
/*  821 */       this.props = props;
/*      */     }
/*      */ 
/*      */     public Map<String, Serializable> getProperties()
/*      */     {
/*  826 */       return this.props;
/*      */     }
/*      */ 
/*      */     ByteBuffer getEncodedMessage() {
/*  830 */       if (Log.loggingDebug) {
/*  831 */         Log.debug(new StringBuilder().append("LoginPlugin: select character response: nProps=").append(this.props == null ? 0 : this.props.size()).toString());
/*      */       }
/*      */ 
/*  834 */       AOByteBuffer buffer = new AOByteBuffer(1024);
/*  835 */       buffer.putInt(0);
/*  836 */       buffer.putInt(9);
/*  837 */       buffer.putPropertyMap(this.props);
/*      */ 
/*  840 */       int len = buffer.position();
/*  841 */       buffer.getNioBuf().rewind();
/*  842 */       buffer.putInt(len - 4);
/*  843 */       buffer.position(len);
/*      */ 
/*  845 */       return (ByteBuffer)buffer.getNioBuf().flip();
/*      */     }
/*      */ 
/*      */     public void decodeBuffer(AOByteBuffer buffer)
/*      */     {
/*  851 */       this.props = buffer.getPropertyMap();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CharacterSelectRequestMessage
/*      */   {
/*      */     private Map<String, Serializable> props;
/*      */ 
/*      */     public Map<String, Serializable> getProperties()
/*      */     {
/*  805 */       return this.props;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CharacterDeleteMessage
/*      */   {
/*      */     private Map<String, Serializable> props;
/*      */ 
/*      */     public Map<String, Serializable> getProperties()
/*      */     {
/*  781 */       return this.props;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CharacterDeleteResponseMessage
/*      */   {
/*      */     private Map<String, Serializable> props;
/*      */ 
/*      */     public void setProperties(Map<String, Serializable> props)
/*      */     {
/*  709 */       this.props = props;
/*      */     }
/*      */ 
/*      */     public Map<String, Serializable> getProperties()
/*      */     {
/*  714 */       return this.props;
/*      */     }
/*      */ 
/*      */     ByteBuffer getEncodedMessage() {
/*  718 */       if (Log.loggingDebug) {
/*  719 */         Log.debug(new StringBuilder().append("LoginPlugin: delete character response: nProps=").append(this.props == null ? 0 : this.props.size()).toString());
/*      */       }
/*      */ 
/*  722 */       AOByteBuffer buffer = new AOByteBuffer(1024);
/*  723 */       buffer.putInt(0);
/*  724 */       buffer.putInt(4);
/*  725 */       if (this.props == null) {
/*  726 */         buffer.putInt(0);
/*      */       }
/*      */       else {
/*  729 */         List propStrings = new ArrayList();
/*  730 */         int nProps = PropertyMessage.createPropertyString(propStrings, this.props, "");
/*      */ 
/*  732 */         buffer.putInt(nProps);
/*  733 */         for (String s : propStrings) {
/*  734 */           buffer.putString(s);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  739 */       int len = buffer.position();
/*  740 */       buffer.getNioBuf().rewind();
/*  741 */       buffer.putInt(len - 4);
/*  742 */       buffer.position(len);
/*      */ 
/*  744 */       return (ByteBuffer)buffer.getNioBuf().flip();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CharacterCreateResponseMessage
/*      */   {
/*      */     private Map<String, Serializable> props;
/*      */ 
/*      */     public void setProperties(Map<String, Serializable> props)
/*      */     {
/*  589 */       this.props = props;
/*      */     }
/*      */ 
/*      */     public Map<String, Serializable> getProperties()
/*      */     {
/*  594 */       return this.props;
/*      */     }
/*      */ 
/*      */     ByteBuffer getEncodedMessage() {
/*  598 */       if (Log.loggingDebug) {
/*  599 */         Log.debug(new StringBuilder().append("LoginPlugin: create character response: nProps=").append(this.props == null ? 0 : this.props.size()).toString());
/*      */       }
/*      */ 
/*  602 */       AOByteBuffer buffer = new AOByteBuffer(1024);
/*  603 */       buffer.putInt(0);
/*  604 */       buffer.putInt(6);
/*  605 */       if (this.props == null) {
/*  606 */         buffer.putInt(0);
/*      */       }
/*      */       else {
/*  609 */         List propStrings = new ArrayList();
/*  610 */         int nProps = PropertyMessage.createPropertyString(propStrings, this.props, "");
/*      */ 
/*  612 */         buffer.putInt(nProps);
/*  613 */         for (String s : propStrings) {
/*  614 */           buffer.putString(s);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  619 */       int len = buffer.position();
/*  620 */       buffer.getNioBuf().rewind();
/*  621 */       buffer.putInt(len - 4);
/*  622 */       buffer.position(len);
/*      */ 
/*  624 */       return (ByteBuffer)buffer.getNioBuf().flip();
/*      */     }
/*      */ 
/*      */     public void decodeBuffer(AOByteBuffer buffer)
/*      */     {
/*  630 */       this.props = PropertyMessage.unmarshallProperyMap(buffer);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CharacterCreateMessage
/*      */   {
/*      */     private Map<String, Serializable> props;
/*      */ 
/*      */     public Map<String, Serializable> getProperties()
/*      */     {
/*  572 */       return this.props;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CharacterResponseMessage
/*      */   {
/*  556 */     private String worldToken = "";
/*      */     private String serverVersion;
/*  558 */     private String errorMessage = "";
/*  559 */     private String worldFilesUrl = "";
/*  560 */     private OID account = null;
/*  561 */     private int characterSlots = 2;
/*  562 */     private LinkedList<Map<String, Serializable>> characters = new LinkedList();
/*      */ 
/*      */     public String getWorldToken()
/*      */     {
/*  427 */       return this.worldToken;
/*      */     }
/*      */ 
/*      */     public void setWorldToken(String worldToken)
/*      */     {
/*  433 */       this.worldToken = worldToken;
/*      */     }
/*      */ 
/*      */     public String getServerVersion()
/*      */     {
/*  438 */       return this.serverVersion;
/*      */     }
/*      */ 
/*      */     public void setServerVersion(String serverVersion)
/*      */     {
/*  443 */       this.serverVersion = serverVersion;
/*      */     }
/*      */ 
/*      */     public String getErrorMessage()
/*      */     {
/*  449 */       return this.errorMessage;
/*      */     }
/*      */ 
/*      */     public void setErrorMessage(String errorMessage)
/*      */     {
/*  454 */       this.errorMessage = errorMessage;
/*      */     }
/*      */ 
/*      */     public String getWorldFilesUrl()
/*      */     {
/*  460 */       return this.worldFilesUrl;
/*      */     }
/*      */ 
/*      */     public void setWorldFilesUrl(String worldFilesUrl)
/*      */     {
/*  465 */       this.worldFilesUrl = worldFilesUrl;
/*      */     }
/*      */ 
/*      */     public OID getAccount()
/*      */     {
/*  471 */       return this.account;
/*      */     }
/*      */ 
/*      */     public void setAccount(OID account)
/*      */     {
/*  476 */       this.account = account;
/*      */     }
/*      */ 
/*      */     public int getCharacterSlots()
/*      */     {
/*  481 */       return this.characterSlots;
/*      */     }
/*      */ 
/*      */     public void setCharacterSlots(int characterSlots)
/*      */     {
/*  486 */       this.characterSlots = characterSlots;
/*      */     }
/*      */ 
/*      */     public void addCharacter(Map<String, Serializable> characterInfo)
/*      */     {
/*  495 */       this.characters.add(characterInfo);
/*      */     }
/*      */     public List<Map<String, Serializable>> getCharacters() {
/*  498 */       return this.characters;
/*      */     }
/*      */ 
/*      */     ByteBuffer getEncodedMessage() {
/*  502 */       if (Log.loggingDebug) {
/*  503 */         Log.debug("LoginPlugin: returning characters: serverVersion=" + this.serverVersion + " worldToken=" + this.worldToken + " errorMessage=" + this.errorMessage + " worldFilesUrl=" + this.worldFilesUrl + " nChars=" + this.characters.size());
/*      */       }
/*      */ 
/*  510 */       AOByteBuffer buffer = new AOByteBuffer(1024);
/*  511 */       buffer.putInt(0);
/*  512 */       buffer.putInt(2);
/*  513 */       buffer.putString(this.serverVersion);
/*  514 */       buffer.putString(this.worldToken);
/*  515 */       buffer.putString(this.errorMessage);
/*  516 */       buffer.putString(this.worldFilesUrl);
/*  517 */       buffer.putOID(this.account);
/*  518 */       buffer.putInt(this.characterSlots);
/*  519 */       buffer.putInt(this.characters.size());
/*  520 */       for (Map properties : this.characters) {
/*  521 */         List propStrings = new ArrayList();
/*  522 */         int nProps = PropertyMessage.createPropertyString(propStrings, properties, "");
/*      */ 
/*  524 */         buffer.putInt(nProps);
/*  525 */         for (String s : propStrings) {
/*  526 */           buffer.putString(s);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  531 */       int len = buffer.position();
/*  532 */       buffer.getNioBuf().rewind();
/*  533 */       buffer.putInt(len - 4);
/*  534 */       buffer.position(len);
/*      */ 
/*  536 */       return (ByteBuffer)buffer.getNioBuf().flip();
/*      */     }
/*      */ 
/*      */     public void decodeBuffer(AOByteBuffer buffer)
/*      */     {
/*  542 */       this.serverVersion = buffer.getString();
/*  543 */       this.worldToken = buffer.getString();
/*  544 */       this.errorMessage = buffer.getString();
/*  545 */       this.worldFilesUrl = buffer.getString();
/*  546 */       this.account = buffer.getOID();
/*  547 */       this.characterSlots = buffer.getInt();
/*  548 */       int nChars = buffer.getInt();
/*  549 */       for (; nChars > 0; nChars--) {
/*  550 */         Map props = PropertyMessage.unmarshallProperyMap(buffer);
/*      */ 
/*  552 */         this.characters.add(props);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CharacterRequestMessage
/*      */   {
/*      */     private AOByteBuffer authToken;
/*      */     private String clientVersion;
/*      */ 
/*      */     public AOByteBuffer getAuthToken()
/*      */     {
/*  391 */       this.authToken.rewind();
/*  392 */       return this.authToken;
/*      */     }
/*      */ 
/*      */     public void setAuthToken(AOByteBuffer token) {
/*  396 */       this.authToken = token;
/*      */     }
/*      */ 
/*      */     public String getClientVersion()
/*      */     {
/*  402 */       return this.clientVersion;
/*      */     }
/*      */ 
/*      */     public void setClientVersion(String version) {
/*  406 */       this.clientVersion = version;
/*      */     }
/*      */ 
/*      */     public AOByteBuffer toBytes() {
/*  410 */       AOByteBuffer buf = new AOByteBuffer(200);
/*  411 */       buf.putInt(10);
/*  412 */       buf.putString(this.clientVersion);
/*  413 */       buf.putByteBuffer(this.authToken);
/*  414 */       return buf;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected class SocketHandler
/*      */     implements Runnable
/*      */   {
/*  140 */     private SocketChannel clientSocket = null;
/*  141 */     private Selector selector = null;
/*  142 */     private SelectionKey clientSelection = null;
/*  143 */     private OID accountId = null;
/*  144 */     private String accountName = null;
/*  145 */     private List<Map<String, Serializable>> characterInfo = null;
/*      */ 
/*      */     public SocketHandler(SocketChannel socket)
/*      */       throws IOException
/*      */     {
/*  135 */       this.clientSocket = socket;
/*  136 */       this.selector = Selector.open();
/*  137 */       this.clientSelection = this.clientSocket.register(this.selector, 1);
/*      */     }
/*      */ 
/*      */     public SocketAddress getRemoteSocketAddress()
/*      */     {
/*  148 */       return this.clientSocket.socket().getRemoteSocketAddress();
/*      */     }
/*      */ 
/*      */     public void setAccountId(OID accountId) {
/*  152 */       this.accountId = accountId;
/*      */     }
/*      */     public OID getAccountId() {
/*  155 */       return this.accountId;
/*      */     }
/*      */ 
/*      */     public void setAccountName(String accountName) {
/*  159 */       this.accountName = accountName;
/*      */     }
/*      */     public String getAccountName() {
/*  162 */       return this.accountName;
/*      */     }
/*      */ 
/*      */     public void setCharacterInfo(List<Map<String, Serializable>> charInfo) {
/*  166 */       this.characterInfo = charInfo;
/*      */     }
/*      */     public List<Map<String, Serializable>> getCharacterInfo() {
/*  169 */       return this.characterInfo;
/*      */     }
/*      */ 
/*      */     private int fillBuffer(SocketChannel socket, ByteBuffer buffer)
/*      */       throws IOException
/*      */     {
/*  175 */       this.clientSelection.interestOps(1);
/*  176 */       while (buffer.remaining() > 0) {
/*  177 */         int nReady = this.selector.select(2000000L);
/*  178 */         if (nReady == 1) {
/*  179 */           this.selector.selectedKeys().clear();
/*  180 */           int nBytes = socket.read(buffer);
/*  181 */           if (nBytes == -1)
/*      */             break;
/*      */         }
/*      */         else {
/*  185 */           Log.debug("Connection timeout while reading");
/*  186 */           break;
/*      */         }
/*      */       }
/*  189 */       buffer.flip();
/*  190 */       return buffer.limit();
/*      */     }
/*      */ 
/*      */     private boolean writeBuffer(ByteBuffer buffer)
/*      */       throws IOException
/*      */     {
/*  196 */       this.clientSelection.interestOps(4);
/*  197 */       while (buffer.hasRemaining()) {
/*  198 */         int nReady = this.selector.select(2000000L);
/*  199 */         if (nReady == 1) {
/*  200 */           this.selector.selectedKeys().clear();
/*  201 */           if (this.clientSocket.write(buffer) == 0)
/*  202 */             break;
/*      */         }
/*      */         else {
/*  205 */           Log.debug("Connection timeout while writing");
/*  206 */           break;
/*      */         }
/*      */       }
/*  209 */       return !buffer.hasRemaining();
/*      */     }
/*      */ 
/*      */     public void run() {
/*      */       try {
/*  214 */         ByteBuffer header = ByteBuffer.allocate(8);
/*      */         while (true) {
/*  216 */           int nBytes = fillBuffer(this.clientSocket, header);
/*  217 */           if (nBytes == 0) {
/*  218 */             Log.info("LoginPlugin: DISCONNECT " + LoginPlugin.access$000(this.clientSocket));
/*      */ 
/*  220 */             break;
/*      */           }
/*  222 */           if (nBytes < 8) {
/*  223 */             Log.error("LoginPlugin: reading header nBytes " + nBytes);
/*  224 */             break;
/*      */           }
/*  226 */           int messageLength = header.getInt();
/*  227 */           int messageCode = header.getInt();
/*  228 */           header.clear();
/*  229 */           if (Log.loggingDebug) {
/*  230 */             Log.debug("LoginPlugin: code " + messageCode + " (" + messageLength + " bytes)");
/*      */           }
/*  232 */           if (messageLength > 64000) {
/*  233 */             Log.error("LoginPlugin: max message length exceeded");
/*  234 */             break;
/*      */           }
/*  236 */           if (messageLength < 0) {
/*  237 */             Log.error("LoginPlugin: invalid message length");
/*  238 */             break;
/*      */           }
/*      */ 
/*  241 */           if (messageLength == 4) {
/*  242 */             Log.error("LoginPlugin: invalid message length (possibly an old client)");
/*  243 */             break;
/*      */           }
/*      */ 
/*  246 */           ByteBuffer message = null;
/*  247 */           if (messageLength > 4) {
/*  248 */             message = ByteBuffer.allocate(messageLength - 4);
/*  249 */             nBytes = fillBuffer(this.clientSocket, message);
/*  250 */             if ((nBytes == -1) || (nBytes != messageLength - 4)) {
/*  251 */               Log.error("LoginPlugin: error reading message body");
/*  252 */               break;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  257 */           ByteBuffer responseBuf = dispatchMessage(messageCode, message, this);
/*  258 */           if ((responseBuf == null) || 
/*  259 */             (!writeBuffer(responseBuf))) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (InterruptedIOException e)
/*      */       {
/*  266 */         Log.info("LoginPlugin: closed connection due to timeout");
/*      */       } catch (IOException e) {
/*  268 */         Log.exception("LoginPlugin.SocketHandler: ", e);
/*      */       } catch (AORuntimeException e) {
/*  270 */         Log.exception("LoginPlugin.SocketHandler: ", e);
/*      */       } catch (Exception e) {
/*  272 */         Log.exception("LoginPlugin.SocketHandler: ", e);
/*      */       }
/*      */       try
/*      */       {
/*  276 */         this.clientSelection.cancel();
/*  277 */         this.clientSocket.close();
/*  278 */         this.selector.close();
/*      */       }
/*      */       catch (Exception ignore)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     ByteBuffer dispatchMessage(int messageCode, ByteBuffer messageBuf, SocketHandler clientSocket) throws IOException {
/*  286 */       ByteBuffer responseBuf = null;
/*  287 */       if (messageCode == 10) {
/*  288 */         LoginPlugin.CharacterRequestMessage msg = new LoginPlugin.CharacterRequestMessage();
/*  289 */         AOByteBuffer buffer = new AOByteBuffer(messageBuf);
/*  290 */         LoginPlugin.CharacterRequestMessage.access$102(msg, buffer.getString());
/*  291 */         LoginPlugin.CharacterRequestMessage.access$202(msg, buffer.getByteBuffer());
/*  292 */         if (Log.loggingDebug) {
/*  293 */           Log.debug("LoginPlugin: SecureCharacterRequestMessage version=" + msg.clientVersion + " token=" + msg.authToken);
/*      */         }
/*      */ 
/*  297 */         int versionCompare = ServerVersion.compareVersionStrings(msg.clientVersion, "2.5.0");
/*      */         LoginPlugin.CharacterResponseMessage response;
/*  299 */         if ((versionCompare != 1) && (versionCompare != 0))
/*      */         {
/*  301 */           LoginPlugin.CharacterResponseMessage response = new LoginPlugin.CharacterResponseMessage();
/*  302 */           response.setErrorMessage("Unsupported client version");
/*      */         }
/*      */         else {
/*  305 */           response = LoginPlugin.this.handleCharacterRequestMessage(msg, clientSocket);
/*      */         }
/*  307 */         if ((response.getServerVersion() == null) || (response.getServerVersion().equals("")))
/*      */         {
/*  309 */           response.setServerVersion("2.5.0");
/*  310 */         }responseBuf = response.getEncodedMessage();
/*      */       }
/*  312 */       else if (messageCode == 7) {
/*  313 */         LoginPlugin.CharacterRequestMessage msg = new LoginPlugin.CharacterRequestMessage();
/*  314 */         AOByteBuffer buffer = new AOByteBuffer(messageBuf);
/*  315 */         LoginPlugin.CharacterRequestMessage.access$102(msg, buffer.getString());
/*  316 */         LoginPlugin.CharacterRequestMessage.access$202(msg, buffer.getByteBuffer());
/*  317 */         if (Log.loggingDebug) {
/*  318 */           Log.debug("LoginPlugin: CharacterRequestMessage version=" + msg.clientVersion + " token=" + msg.authToken);
/*      */         }
/*      */ 
/*  322 */         int versionCompare = ServerVersion.compareVersionStrings(msg.clientVersion, "2.5.0");
/*      */         LoginPlugin.CharacterResponseMessage response;
/*  324 */         if ((versionCompare != 1) && (versionCompare != 0))
/*      */         {
/*  326 */           LoginPlugin.CharacterResponseMessage response = new LoginPlugin.CharacterResponseMessage();
/*  327 */           response.setErrorMessage("Unsupported client version");
/*      */         }
/*      */         else {
/*  330 */           response = LoginPlugin.this.handleCharacterRequestMessage(msg, clientSocket);
/*      */         }
/*  332 */         if ((response.getServerVersion() == null) || (response.getServerVersion().equals("")))
/*      */         {
/*  334 */           response.setServerVersion("2.5.0");
/*  335 */         }responseBuf = response.getEncodedMessage();
/*      */       }
/*  337 */       else if (messageCode == 5) {
/*  338 */         synchronized (LoginPlugin.this.characterCreateLock) {
/*  339 */           LoginPlugin.CharacterCreateMessage msg = new LoginPlugin.CharacterCreateMessage();
/*  340 */           AOByteBuffer aoBuf = new AOByteBuffer(messageBuf);
/*  341 */           LoginPlugin.CharacterCreateMessage.access$402(msg, PropertyMessage.unmarshallProperyMap(aoBuf));
/*  342 */           if (Log.loggingDebug) {
/*  343 */             Log.debug("LoginPlugin: CharacterCreateMessage prop count=" + msg.props.size());
/*      */           }
/*      */ 
/*  348 */           LoginPlugin.CharacterCreateResponseMessage response = LoginPlugin.this.handleCharacterCreateMessage(msg, clientSocket);
/*  349 */           responseBuf = response.getEncodedMessage();
/*      */         }
/*      */       }
/*  352 */       else if (messageCode == 3) {
/*  353 */         LoginPlugin.CharacterDeleteMessage msg = new LoginPlugin.CharacterDeleteMessage();
/*  354 */         AOByteBuffer aoBuf = new AOByteBuffer(messageBuf);
/*  355 */         LoginPlugin.CharacterDeleteMessage.access$502(msg, PropertyMessage.unmarshallProperyMap(aoBuf));
/*  356 */         if (Log.loggingDebug) {
/*  357 */           Log.debug("LoginPlugin: CharacterDeleteMessage prop count=" + msg.props.size());
/*      */         }
/*      */ 
/*  360 */         LoginPlugin.CharacterDeleteResponseMessage response = LoginPlugin.this.handleCharacterDeleteMessage(msg, clientSocket);
/*  361 */         responseBuf = response.getEncodedMessage();
/*      */       }
/*  363 */       else if (messageCode == 8) {
/*  364 */         LoginPlugin.CharacterSelectRequestMessage msg = new LoginPlugin.CharacterSelectRequestMessage();
/*  365 */         AOByteBuffer aoBuf = new AOByteBuffer(messageBuf);
/*  366 */         LoginPlugin.CharacterSelectRequestMessage.access$602(msg, PropertyMessage.unmarshallProperyMap(aoBuf));
/*  367 */         if (Log.loggingDebug) {
/*  368 */           Log.debug("LoginPlugin: CharacterSelectRequestMessage prop count=" + msg.props.size());
/*      */         }
/*      */ 
/*  371 */         LoginPlugin.CharacterSelectResponseMessage response = LoginPlugin.this.handleCharacterSelectRequestMessage(msg, clientSocket);
/*  372 */         responseBuf = response.getEncodedMessage();
/*      */       }
/*      */       else {
/*  375 */         Log.error("Unknown message code " + messageCode);
/*      */       }
/*      */ 
/*  378 */       return responseBuf;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.worldmgr.LoginPlugin
 * JD-Core Version:    0.6.0
 */