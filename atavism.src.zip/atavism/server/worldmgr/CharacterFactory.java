/*    */ package atavism.server.worldmgr;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class CharacterFactory
/*    */ {
/*    */   public abstract OID createCharacter(String paramString, OID paramOID, Map paramMap);
/*    */ 
/*    */   public String deleteCharacter(String worldName, OID atavismID, OID oid, Map properties)
/*    */   {
/* 29 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.worldmgr.CharacterFactory
 * JD-Core Version:    0.6.0
 */