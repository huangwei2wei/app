package atavism.server.objects;

import atavism.server.events.ExtensionMessageEvent;
import atavism.server.plugins.ProxyPlugin;

public abstract interface ProxyExtensionHook
{
  public abstract void processExtensionEvent(ExtensionMessageEvent paramExtensionMessageEvent, Player paramPlayer, ProxyPlugin paramProxyPlugin);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ProxyExtensionHook
 * JD-Core Version:    0.6.0
 */