/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ 
/*     */ public class Color
/*     */   implements Cloneable, Externalizable
/*     */ {
/* 138 */   int r = 0;
/* 139 */   int g = 0;
/* 140 */   int b = 0;
/* 141 */   int a = 0;
/*     */ 
/* 143 */   public static Color White = new Color(255, 255, 255, 255);
/* 144 */   public static Color Black = new Color(0, 0, 0, 255);
/* 145 */   public static Color Red = new Color(255, 0, 0, 255);
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Color()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Color(int r, int g, int b)
/*     */   {
/*  11 */     setRed(r);
/*  12 */     setGreen(g);
/*  13 */     setBlue(b);
/*  14 */     setAlpha(255);
/*     */   }
/*     */ 
/*     */   public Color(int r, int g, int b, int a) {
/*  18 */     setRed(r);
/*  19 */     setGreen(g);
/*  20 */     setBlue(b);
/*  21 */     setAlpha(a);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  30 */     return "(" + this.r + "," + this.g + "," + this.b + "," + this.a + ")";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  38 */     Color otherColor = (Color)other;
/*  39 */     if (other == null) {
/*  40 */       return false;
/*     */     }
/*  42 */     return (getRed() == otherColor.getRed()) && (getGreen() == otherColor.getGreen()) && (getBlue() == otherColor.getBlue()) && (getAlpha() == otherColor.getAlpha());
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  49 */     return new Color(this.r, this.g, this.b, this.a);
/*     */   }
/*     */ 
/*     */   public byte[] toBytes() {
/*  53 */     if (Log.loggingDebug)
/*  54 */       Log.debug("color.toBytes: " + toString());
/*  55 */     byte[] colorBytes = new byte[4];
/*  56 */     colorBytes[0] = (byte)getAlpha();
/*  57 */     colorBytes[1] = (byte)getBlue();
/*  58 */     colorBytes[2] = (byte)getGreen();
/*  59 */     colorBytes[3] = (byte)getRed();
/*  60 */     return colorBytes;
/*     */   }
/*     */ 
/*     */   public void setRed(int val) {
/*  64 */     assertRange(val);
/*  65 */     this.r = val;
/*     */   }
/*     */   public int getRed() {
/*  68 */     return this.r;
/*     */   }
/*     */ 
/*     */   public void setGreen(int val) {
/*  72 */     assertRange(val);
/*  73 */     this.g = val;
/*     */   }
/*     */   public int getGreen() {
/*  76 */     return this.g;
/*     */   }
/*     */ 
/*     */   public void setBlue(int val) {
/*  80 */     assertRange(val);
/*  81 */     this.b = val;
/*     */   }
/*     */   public int getBlue() {
/*  84 */     return this.b;
/*     */   }
/*     */ 
/*     */   public void setAlpha(int val) {
/*  88 */     assertRange(val);
/*  89 */     this.a = val;
/*     */   }
/*     */   public int getAlpha() {
/*  92 */     return this.a;
/*     */   }
/*     */ 
/*     */   void assertRange(int val) {
/*  96 */     if ((val < 0) || (val > 255))
/*  97 */       throw new RuntimeException("color: color value is out of range: " + val);
/*     */   }
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 115 */     if (Log.loggingTrace)
/* 116 */       Log.trace("Color.writeExternal: writing out color: " + this);
/* 117 */     out.writeInt(getRed());
/* 118 */     out.writeInt(getGreen());
/* 119 */     out.writeInt(getBlue());
/* 120 */     out.writeInt(getAlpha());
/*     */   }
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 132 */     setRed(in.readInt());
/* 133 */     setGreen(in.readInt());
/* 134 */     setBlue(in.readInt());
/* 135 */     setAlpha(in.readInt());
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Color
 * JD-Core Version:    0.6.0
 */