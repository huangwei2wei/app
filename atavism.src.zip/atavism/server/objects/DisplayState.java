/*    */ package atavism.server.objects;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DisplayState
/*    */   implements Serializable
/*    */ {
/*  6 */   public static DisplayState IN_COMBAT = new DisplayState(1);
/*  7 */   public static DisplayState NON_COMBAT = new DisplayState(2);
/*    */ 
/* 35 */   int id = -1;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DisplayState()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DisplayState(int id)
/*    */   {
/* 13 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public void setId(int id) {
/* 17 */     this.id = id;
/*    */   }
/*    */   public int getId() {
/* 20 */     return this.id;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 24 */     return getId();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 28 */     return "[DisplayState id=" + getId() + "]";
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 32 */     DisplayState otherDS = (DisplayState)other;
/* 33 */     return this.id == otherDS.getId();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.DisplayState
 * JD-Core Version:    0.6.0
 */