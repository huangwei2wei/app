/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.plugins.ObjectManagerPlugin;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Template extends NamedPropertyClass
/*     */   implements Cloneable
/*     */ {
/* 224 */   protected int templateID = -1;
/* 225 */   protected String templateType = "Base";
/*     */ 
/* 227 */   private Map<Namespace, Map<String, Serializable>> propMap = new HashMap();
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Template()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Template(String name)
/*     */   {
/*  18 */     setName(name);
/*  19 */     setTemplateID(ObjectManagerPlugin.getNextFreeTemplateID());
/*  20 */     setTemplateType("BaseTemplate");
/*     */   }
/*     */ 
/*     */   public Template(String name, int id, String type) {
/*  24 */     setName(name);
/*  25 */     setTemplateID(id);
/*  26 */     setTemplateType(type);
/*     */   }
/*     */ 
/*     */   public String getType() {
/*  30 */     return "Template";
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  34 */     String s = "[Template: name=" + getName() + ", id=" + getTemplateID() + ", type=" + getTemplateType() + "] ";
/*  35 */     this.lock.lock();
/*     */     try {
/*  37 */       for (Map.Entry entry : this.propMap.entrySet()) {
/*  38 */         ns = (Namespace)entry.getKey();
/*  39 */         Map subMap = (Map)entry.getValue();
/*  40 */         for (Map.Entry sEntry : subMap.entrySet()) {
/*  41 */           String key = (String)sEntry.getKey();
/*  42 */           Serializable val = (Serializable)sEntry.getValue();
/*  43 */           s = s + "(ns=" + ns.getName() + ", key=" + key + ", val=" + val + ")";
/*     */         }
/*     */       }
/*  49 */       Namespace ns;
/*  46 */       ??? = s;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Object clone() throws CloneNotSupportedException
/*     */   {
/*  54 */     this.lock.lock();
/*     */     try {
/*  56 */       Template res = (Template)super.clone();
/*     */ 
/*  59 */       res.propMap = new HashMap();
/*  60 */       for (Map.Entry entry : this.propMap.entrySet())
/*     */       {
/*  62 */         res.propMap.put(entry.getKey(), new HashMap((Map)entry.getValue()));
/*     */       }
/*     */ 
/*  65 */       ??? = res;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void put(Namespace namespace, String key, Serializable value)
/*     */   {
/*  77 */     this.lock.lock();
/*     */     try {
/*  79 */       Map subMap = (Map)this.propMap.get(namespace);
/*  80 */       if (subMap == null)
/*     */       {
/*  82 */         subMap = new HashMap();
/*  83 */         this.propMap.put(namespace, subMap);
/*     */       }
/*  85 */       subMap.put(key, value);
/*     */     }
/*     */     finally {
/*  88 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void put(String namespaceString, String key, Serializable value)
/*     */   {
/*  96 */     put(Namespace.intern(namespaceString), key, value);
/*     */   }
/*     */ 
/*     */   public Serializable get(Namespace namespace, String key) {
/* 100 */     this.lock.lock();
/*     */     try {
/* 102 */       Map subMap = (Map)this.propMap.get(namespace);
/* 103 */       if (subMap == null) {
/* 104 */         localSerializable = null;
/*     */         return localSerializable;
/*     */       }
/* 106 */       Serializable localSerializable = (Serializable)subMap.get(key);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Set<Namespace> getNamespaces()
/*     */   {
/* 114 */     this.lock.lock();
/*     */     try {
/* 116 */       Set ns = new HashSet();
/* 117 */       for (Namespace namespace : this.propMap.keySet())
/* 118 */         ns.add(namespace);
/* 119 */       ??? = ns;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getSubMap(Namespace namespace)
/*     */   {
/* 130 */     this.lock.lock();
/*     */     try {
/* 132 */       Map subMap = (Map)this.propMap.get(namespace);
/* 133 */       if (subMap != null) {
/* 134 */         localHashMap = new HashMap(subMap);
/*     */         return localHashMap;
/*     */       }
/* 136 */       HashMap localHashMap = null;
/*     */       return localHashMap; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Template restrict(Namespace namespace)
/*     */   {
/* 147 */     this.lock.lock();
/*     */     try {
/* 149 */       Template t = new Template(getName(), getTemplateID(), getTemplateType());
/*     */ 
/* 152 */       Map subMap = getSubMap(namespace);
/*     */ 
/* 154 */       t.propMap.put(namespace, subMap);
/* 155 */       Template localTemplate1 = t;
/*     */       return localTemplate1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Template merge(Template overrideTemplate)
/*     */   {
/*     */     Template newTempl;
/*     */     try
/*     */     {
/* 169 */       newTempl = (Template)clone();
/*     */     } catch (CloneNotSupportedException e1) {
/* 171 */       throw new RuntimeException("merge", e1);
/*     */     }
/*     */ 
/* 174 */     for (Iterator i$ = overrideTemplate.getNamespaces().iterator(); i$.hasNext(); ) { namespace = (Namespace)i$.next();
/* 175 */       Map subMap = overrideTemplate.getSubMap(namespace);
/* 176 */       for (Map.Entry entry : subMap.entrySet()) {
/* 177 */         String key = (String)entry.getKey();
/* 178 */         Serializable val = (Serializable)entry.getValue();
/* 179 */         newTempl.put(namespace, key, val);
/*     */       }
/*     */     }
/*     */     Namespace namespace;
/* 182 */     return newTempl;
/*     */   }
/*     */ 
/*     */   public boolean equals(Serializable other)
/*     */   {
/* 190 */     if (!(other instanceof Template)) {
/* 191 */       return false;
/*     */     }
/* 193 */     Template oTempl = (Template)other;
/* 194 */     if (getName() == null) {
/* 195 */       return false;
/*     */     }
/* 197 */     return getName().equals(oTempl.getName());
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 201 */     if (getName() == null) {
/* 202 */       throw new RuntimeException("hashCode fails for null name");
/*     */     }
/* 204 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */   public Entity generate() {
/* 208 */     throw new AORuntimeException("generate not implemented");
/*     */   }
/*     */ 
/*     */   public int getTemplateID() {
/* 212 */     return this.templateID;
/*     */   }
/*     */   public void setTemplateID(int templateID) {
/* 215 */     this.templateID = templateID;
/*     */   }
/*     */   public String getTemplateType() {
/* 218 */     return this.templateType;
/*     */   }
/*     */   public void setTemplateType(String templateType) {
/* 221 */     this.templateType = templateType;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Template
 * JD-Core Version:    0.6.0
 */