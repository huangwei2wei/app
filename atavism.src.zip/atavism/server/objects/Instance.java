/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Matcher;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.engine.ScriptManager;
/*     */ import atavism.server.engine.SearchClause;
/*     */ import atavism.server.engine.SearchManager;
/*     */ import atavism.server.engine.SearchSelection;
/*     */ import atavism.server.engine.Searchable;
/*     */ import atavism.server.engine.TerrainConfig;
/*     */ import atavism.server.engine.WorldCollectionLoaderContext;
/*     */ import atavism.server.engine.WorldFileLoader;
/*     */ import atavism.server.engine.WorldLoaderOverride;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.pathing.PathInfo;
/*     */ import atavism.server.plugins.WorldManagerClient.NewRegionMessage;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Instance extends Entity
/*     */ {
/*     */   public static final int STATE_INIT = 0;
/*     */   public static final int STATE_GENERATE = 1;
/*     */   public static final int STATE_LOAD = 2;
/*     */   public static final int STATE_AVAILABLE = 3;
/*     */   public static final int STATE_UNLOAD = 4;
/*     */   public static final int STATE_DELETE = 5;
/* 440 */   private transient RegionSearch regionSearch = new RegionSearch();
/*     */ 
/* 442 */   private transient String globalSkybox = "";
/*     */   private transient Fog globalFog;
/*     */   private transient Color globalAmbientLight;
/*     */   private transient LightData globalDirLightData;
/*     */   private transient OceanData oceanData;
/*     */   private transient TerrainConfig terrainConfig;
/* 449 */   private transient Region globalRegion = new Region("Global Region");
/* 450 */   private transient RoadRegionConfig roadConfig = new RoadRegionConfig();
/*     */ 
/* 452 */   private transient LinkedList<Region> regionList = new LinkedList();
/* 453 */   private transient LinkedList<String> regionConfig = new LinkedList();
/* 454 */   private transient List<SpawnData> spawnGen = new LinkedList();
/*     */ 
/* 456 */   private transient PathInfo pathInfo = new PathInfo();
/*     */   private String name;
/*     */   private String worldFileName;
/*     */   private String initScriptFileName;
/*     */   private String loadScriptFileName;
/*     */   private String templateName;
/*     */   private String worldLoaderOverrideName;
/*     */   private WorldCollectionLoaderContext loaderContext;
/*     */   private InstanceTemplate template;
/* 466 */   private int populationLimit = -1;
/*     */ 
/* 468 */   private transient int state = 0;
/*     */   private transient WorldLoaderOverride worldLoaderOverride;
/*     */   private transient int playerPopulation;
/* 473 */   private static ThreadLocal<Instance> loadingInstance = new ThreadLocal();
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Instance()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Instance(OID oid)
/*     */   {
/*  31 */     super(oid);
/*  32 */     this.globalRegion.addConfig(this.roadConfig);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  37 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  42 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getTemplateName()
/*     */   {
/*  47 */     return this.templateName;
/*     */   }
/*     */ 
/*     */   public void setTemplateName(String templateName)
/*     */   {
/*  52 */     this.templateName = templateName;
/*     */   }
/*     */ 
/*     */   public String getWorldFileName()
/*     */   {
/*  57 */     return this.worldFileName;
/*     */   }
/*     */ 
/*     */   public void setWorldFileName(String fileName)
/*     */   {
/*  62 */     this.worldFileName = fileName;
/*     */   }
/*     */ 
/*     */   public String getInitScriptFileName()
/*     */   {
/*  67 */     return this.initScriptFileName;
/*     */   }
/*     */ 
/*     */   public void setInitScriptFileName(String fileName)
/*     */   {
/*  72 */     this.initScriptFileName = fileName;
/*     */   }
/*     */ 
/*     */   public String getLoadScriptFileName()
/*     */   {
/*  77 */     return this.loadScriptFileName;
/*     */   }
/*     */ 
/*     */   public void setLoadScriptFileName(String fileName)
/*     */   {
/*  82 */     this.loadScriptFileName = fileName;
/*     */   }
/*     */ 
/*     */   public int getState()
/*     */   {
/*  94 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(int state)
/*     */   {
/*  99 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public String getWorldLoaderOverrideName()
/*     */   {
/* 104 */     return this.worldLoaderOverrideName;
/*     */   }
/*     */ 
/*     */   public void setWorldLoaderOverrideName(String loaderName)
/*     */   {
/* 109 */     this.worldLoaderOverrideName = loaderName;
/*     */   }
/*     */ 
/*     */   public WorldLoaderOverride getWorldLoaderOverride()
/*     */   {
/* 114 */     return this.worldLoaderOverride;
/*     */   }
/*     */ 
/*     */   public void setWorldLoaderOverride(WorldLoaderOverride loaderOverride)
/*     */   {
/* 119 */     this.worldLoaderOverride = loaderOverride;
/*     */   }
/*     */ 
/*     */   public boolean loadWorldData()
/*     */   {
/* 129 */     setGlobalSkybox("");
/*     */ 
/* 131 */     Fog fog = new Fog("global fog");
/* 132 */     fog.setStart(50);
/* 133 */     fog.setEnd(100);
/* 134 */     fog.setColor(Color.White);
/* 135 */     setGlobalFog(fog);
/*     */ 
/* 137 */     Color lightColor = Color.White;
/* 138 */     setGlobalAmbientLight(lightColor);
/*     */ 
/* 145 */     setupGlobalRegion();
/*     */ 
/* 148 */     Message msg = new WorldManagerClient.NewRegionMessage(getOid(), getGlobalRegion());
/*     */ 
/* 150 */     Engine.getAgent().sendBroadcast(msg);
/* 151 */     return true;
/*     */   }
/*     */ 
/*     */   protected void setupGlobalRegion()
/*     */   {
/* 156 */     Boundary globalBoundary = new Boundary();
/* 157 */     globalBoundary.addPoint(new Point(-2000000.0F, 0.0F, 2000000.0F));
/* 158 */     globalBoundary.addPoint(new Point(2000000.0F, 0.0F, 2000000.0F));
/* 159 */     globalBoundary.addPoint(new Point(2000000.0F, 0.0F, -2000000.0F));
/* 160 */     globalBoundary.addPoint(new Point(-2000000.0F, 0.0F, -2000000.0F));
/* 161 */     getGlobalRegion().setBoundary(globalBoundary);
/*     */   }
/*     */ 
/*     */   public boolean loadWorldFile()
/*     */   {
/* 166 */     WorldFileLoader loader = new WorldFileLoader(this.worldFileName, this.worldLoaderOverride);
/*     */ 
/* 168 */     return loader.load(this);
/*     */   }
/*     */ 
/*     */   public boolean loadWorldCollections()
/*     */   {
/* 179 */     if (this.loaderContext == null)
/*     */     {
/* 181 */       return true;
/* 182 */     }return this.loaderContext.load(this);
/*     */   }
/*     */ 
/*     */   public boolean runInitScript()
/*     */   {
/* 187 */     if (this.initScriptFileName == null)
/* 188 */       return true;
/* 189 */     setCurrentInstance(this);
/*     */     try {
/* 191 */       ScriptManager scriptManager = new ScriptManager();
/* 192 */       scriptManager.init();
/* 193 */       scriptManager.runFileWithThrow(this.initScriptFileName);
/* 194 */       int i = 1;
/*     */       return i; } catch (Exception e) { } finally { setCurrentInstance(null);
/*     */     }
/* 202 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean runLoadScript()
/*     */   {
/* 207 */     if (this.loadScriptFileName == null)
/* 208 */       return true;
/* 209 */     setCurrentInstance(this);
/*     */     try {
/* 211 */       ScriptManager scriptManager = new ScriptManager();
/* 212 */       scriptManager.init();
/* 213 */       scriptManager.runFileWithThrow(this.loadScriptFileName);
/* 214 */       int i = 1;
/*     */       return i; } catch (Exception e) { } finally { setCurrentInstance(null);
/*     */     }
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */   public String getGlobalSkybox()
/*     */   {
/* 227 */     return this.globalSkybox;
/*     */   }
/*     */ 
/*     */   public void setGlobalSkybox(String skybox)
/*     */   {
/* 232 */     this.globalSkybox = skybox;
/*     */   }
/*     */ 
/*     */   public Fog getGlobalFog()
/*     */   {
/* 237 */     return this.globalFog;
/*     */   }
/*     */ 
/*     */   public void setGlobalFog(Fog fog)
/*     */   {
/* 242 */     this.globalFog = fog;
/*     */   }
/*     */ 
/*     */   public Color getGlobalAmbientLight()
/*     */   {
/* 247 */     return this.globalAmbientLight;
/*     */   }
/*     */ 
/*     */   public void setGlobalAmbientLight(Color lightColor) {
/* 251 */     this.globalAmbientLight = lightColor;
/*     */   }
/*     */ 
/*     */   public LightData getGlobalDirectionalLight()
/*     */   {
/* 256 */     return this.globalDirLightData;
/*     */   }
/*     */ 
/*     */   public void setGlobalDirectionalLight(LightData lightData) {
/* 260 */     this.globalDirLightData = lightData;
/*     */   }
/*     */ 
/*     */   public OceanData getOceanData()
/*     */   {
/* 265 */     return this.oceanData;
/*     */   }
/*     */ 
/*     */   public void setOceanData(OceanData od)
/*     */   {
/* 270 */     this.oceanData = od;
/*     */   }
/*     */ 
/*     */   public TerrainConfig getTerrainConfig()
/*     */   {
/* 275 */     return this.terrainConfig;
/*     */   }
/*     */ 
/*     */   public void setTerrainConfig(TerrainConfig terrainConfig)
/*     */   {
/* 280 */     this.terrainConfig = terrainConfig;
/*     */   }
/*     */ 
/*     */   public Region getGlobalRegion()
/*     */   {
/* 285 */     return this.globalRegion;
/*     */   }
/*     */ 
/*     */   public RoadRegionConfig getRoadConfig()
/*     */   {
/* 290 */     return this.roadConfig;
/*     */   }
/*     */ 
/*     */   public int getPopulationLimit()
/*     */   {
/* 295 */     return this.populationLimit;
/*     */   }
/*     */ 
/*     */   public void setPopulationLimit(int populationLimit)
/*     */   {
/* 300 */     this.populationLimit = populationLimit;
/*     */   }
/*     */ 
/*     */   public synchronized void addRegion(Region region)
/*     */   {
/* 305 */     this.regionList.add(region);
/*     */   }
/*     */ 
/*     */   public synchronized Region getRegion(String regionName)
/*     */   {
/* 310 */     for (Region region : this.regionList) {
/* 311 */       if (region.getName().equals(regionName))
/* 312 */         return region;
/*     */     }
/* 314 */     return null;
/*     */   }
/*     */ 
/*     */   public synchronized List<Region> getRegionList()
/*     */   {
/* 319 */     return new LinkedList(this.regionList);
/*     */   }
/*     */ 
/*     */   public synchronized void addRegionConfig(String region)
/*     */   {
/* 324 */     this.regionConfig.add(region);
/*     */   }
/*     */ 
/*     */   public synchronized List<String> getRegionConfig() {
/* 328 */     return new LinkedList(this.regionConfig);
/*     */   }
/*     */ 
/*     */   public synchronized void addSpawnData(SpawnData spawnData)
/*     */   {
/* 333 */     this.spawnGen.add(spawnData);
/*     */   }
/*     */ 
/*     */   public synchronized List<SpawnData> getSpawnData() {
/* 337 */     return this.spawnGen;
/*     */   }
/*     */ 
/*     */   public synchronized void setWorldCollectionLoaderContext(WorldCollectionLoaderContext context) {
/* 341 */     this.loaderContext = context;
/*     */   }
/*     */ 
/*     */   public synchronized WorldCollectionLoaderContext getWorldCollectionLoaderContext() {
/* 345 */     return this.loaderContext;
/*     */   }
/*     */ 
/*     */   public PathInfo getPathInfo()
/*     */   {
/* 350 */     return this.pathInfo;
/*     */   }
/*     */ 
/*     */   public synchronized int changePlayerPopulation(int delta)
/*     */   {
/* 355 */     Log.debug("POP: changePlayerPopulation by: " + delta + " with previous total: " + this.playerPopulation);
/* 356 */     this.playerPopulation += delta;
/* 357 */     return this.playerPopulation;
/*     */   }
/*     */ 
/*     */   public int getPlayerPopulation()
/*     */   {
/* 362 */     return this.playerPopulation;
/*     */   }
/*     */ 
/*     */   public static Instance current()
/*     */   {
/* 367 */     if (loadingInstance.get() == null)
/* 368 */       Log.error("Instance.current() called in the wrong context");
/* 369 */     return (Instance)loadingInstance.get();
/*     */   }
/*     */ 
/*     */   public static OID currentOid()
/*     */   {
/* 374 */     Instance instance = (Instance)loadingInstance.get();
/* 375 */     if (instance != null) {
/* 376 */       return instance.getOid();
/*     */     }
/* 378 */     Log.error("Instance.currentOid() called in the wrong context");
/* 379 */     return null;
/*     */   }
/*     */ 
/*     */   static void setCurrentInstance(Instance instance)
/*     */   {
/* 385 */     loadingInstance.set(instance);
/*     */   }
/*     */ 
/*     */   public Collection runRegionSearch(SearchClause search, SearchSelection selection)
/*     */   {
/* 391 */     return this.regionSearch.runSearch(search, selection);
/*     */   }
/*     */ 
/*     */   class RegionSearch implements Searchable {
/*     */     RegionSearch() {
/*     */     }
/*     */ 
/*     */     public Collection runSearch(SearchClause search, SearchSelection selection) {
/* 399 */       Matcher matcher = SearchManager.getMatcher(search, Region.class);
/* 400 */       if (matcher == null) {
/* 401 */         return null;
/*     */       }
/* 403 */       List resultList = new LinkedList();
/* 404 */       for (Region region : Instance.this.regionList) {
/* 405 */         boolean rc = matcher.match(region.getPropertyMapRef());
/* 406 */         if (rc) {
/* 407 */           selectProperties(region.getName(), region, selection, resultList);
/*     */         }
/*     */       }
/*     */ 
/* 411 */       return resultList;
/*     */     }
/*     */ 
/*     */     void selectProperties(String name, Region region, SearchSelection selection, List<Object> resultList)
/*     */     {
/* 417 */       if (selection.getResultOption() == 2)
/*     */       {
/* 419 */         resultList.add(name);
/* 420 */         return;
/*     */       }
/*     */ 
/* 423 */       long propFlags = selection.getPropFlags();
/* 424 */       Region result = new Region();
/* 425 */       result.setName(region.getName());
/* 426 */       result.setPriority(region.getPriority());
/* 427 */       if ((propFlags & 1L) != 0L)
/* 428 */         result.setBoundary(region.getBoundary());
/* 429 */       if ((propFlags & 0x2) != 0L) {
/* 430 */         result.setProperties(region.getPropertyMapRef());
/*     */       }
/* 432 */       if (selection.getResultOption() == 1)
/* 433 */         resultList.add(new SearchEntry(name, result));
/* 434 */       else if ((propFlags & 0x3) != 0L)
/* 435 */         resultList.add(result);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Instance
 * JD-Core Version:    0.6.0
 */