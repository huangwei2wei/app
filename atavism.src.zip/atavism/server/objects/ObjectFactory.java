/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.plugins.MobManagerPlugin;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ObjectFactory
/*     */ {
/* 120 */   protected int templateID = -1;
/* 121 */   protected String templateName = null;
/*     */ 
/* 123 */   private static Map<String, ObjectFactory> factories = new HashMap();
/*     */ 
/*     */   public ObjectFactory()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ObjectFactory(int templateID)
/*     */   {
/*  25 */     this.templateID = templateID;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ObjectStub makeObject(OID instanceOid, Point loc)
/*     */   {
/*  37 */     ObjectStub obj = MobManagerPlugin.createObject(this.templateID, instanceOid, loc, null);
/*  38 */     return obj;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ObjectStub makeObject(OID instanceOid, Template override)
/*     */   {
/*  45 */     ObjectStub obj = MobManagerPlugin.createObject(this.templateID, override, instanceOid);
/*  46 */     return obj;
/*     */   }
/*     */ 
/*     */   public ObjectStub makeObject(SpawnData spawnData, OID instanceOid, Point loc)
/*     */   {
/*  57 */     int tID = spawnData.getTemplateID();
/*  58 */     if (tID == -1)
/*  59 */       tID = this.templateID;
/*  60 */     Quaternion orient = spawnData.getOrientation();
/*  61 */     ObjectStub obj = MobManagerPlugin.createObject(tID, instanceOid, loc, orient);
/*     */ 
/*  63 */     return obj;
/*     */   }
/*     */ 
/*     */   public ObjectStub makeObject(SpawnData spawnData, OID instanceOid, Template override)
/*     */   {
/*  73 */     int tID = spawnData.getTemplateID();
/*  74 */     if (tID == -1)
/*  75 */       tID = this.templateID;
/*  76 */     ObjectStub obj = MobManagerPlugin.createObject(tID, override, instanceOid);
/*  77 */     return obj;
/*     */   }
/*     */ 
/*     */   public int getTemplateID()
/*     */   {
/*  83 */     return this.templateID;
/*     */   }
/*     */ 
/*     */   public void setTemplateID(int templateID)
/*     */   {
/*  89 */     this.templateID = templateID;
/*     */   }
/*     */ 
/*     */   public String getTemplateName()
/*     */   {
/*  95 */     return this.templateName;
/*     */   }
/*     */ 
/*     */   public void setTemplateName(String templateName)
/*     */   {
/* 101 */     this.templateName = templateName;
/*     */   }
/*     */ 
/*     */   public static void register(String factoryName, ObjectFactory factory)
/*     */   {
/* 110 */     factories.put(factoryName, factory);
/*     */   }
/*     */ 
/*     */   public static ObjectFactory getFactory(String factoryName)
/*     */   {
/* 117 */     return (ObjectFactory)factories.get(factoryName);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ObjectFactory
 * JD-Core Version:    0.6.0
 */