/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.util.Logger;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class PermissionCallback
/*    */   implements Serializable
/*    */ {
/* 83 */   protected AOObject thisObj = null;
/* 84 */   protected static final Logger log = new Logger("AgisPermissionCallback");
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PermissionCallback()
/*    */   {
/* 23 */     setupTransient();
/*    */   }
/*    */ 
/*    */   public PermissionCallback(AOObject obj) {
/* 27 */     this.thisObj = obj;
/* 28 */     setupTransient();
/*    */   }
/*    */ 
/*    */   private void setupTransient()
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean acquire(AOObject acquirer)
/*    */   {
/* 40 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean acquireFrom(AOObject acquirer, AOObject obj)
/*    */   {
/* 50 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean drop(AOObject dropInto)
/*    */   {
/* 57 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean use(OID activatorOid)
/*    */   {
/* 64 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean destroy(AOObject destroyer)
/*    */   {
/* 71 */     return true;
/*    */   }
/*    */ 
/*    */   private void readObject(ObjectInputStream in)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 79 */     in.defaultReadObject();
/* 80 */     setupTransient();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.PermissionCallback
 * JD-Core Version:    0.6.0
 */