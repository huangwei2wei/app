/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.math.Quaternion;
/*    */ 
/*    */ public class DirectionalLight extends Light
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DirectionalLight()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DirectionalLight(String name)
/*    */   {
/* 14 */     super(name);
/*    */   }
/*    */ 
/*    */   public DirectionalLight(String name, Color diffuse, Color specular, float attenuationRange, float attenuationConstant, float attenuationLinear, float attenuationQuadradic, Quaternion orientation)
/*    */   {
/* 28 */     super(name, diffuse, specular, attenuationRange, attenuationConstant, attenuationLinear, attenuationQuadradic);
/*    */ 
/* 30 */     getLightData().setOrientation(orientation);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 34 */     return "[DirectionalLight: " + super.toString() + "]";
/*    */   }
/*    */ 
/*    */   public Object clone() {
/* 38 */     DirectionalLight l = new DirectionalLight(getName(), getDiffuse(), getSpecular(), getAttenuationRange(), getAttenuationConstant(), getAttenuationLinear(), getAttenuationQuadradic(), getOrientation());
/*    */ 
/* 46 */     return l;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.DirectionalLight
 * JD-Core Version:    0.6.0
 */