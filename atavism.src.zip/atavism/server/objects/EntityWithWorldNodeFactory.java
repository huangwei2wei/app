package atavism.server.objects;

import atavism.server.engine.InterpolatedWorldNode;
import atavism.server.engine.OID;

public abstract interface EntityWithWorldNodeFactory
{
  public abstract EntityWithWorldNode createEntity(OID paramOID, InterpolatedWorldNode paramInterpolatedWorldNode, int paramInt);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.EntityWithWorldNodeFactory
 * JD-Core Version:    0.6.0
 */