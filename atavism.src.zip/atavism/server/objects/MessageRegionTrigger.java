/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageCatalog;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.messages.PropertyMessage;
/*     */ import atavism.server.plugins.WorldManagerClient.ExtensionMessage;
/*     */ import atavism.server.plugins.WorldManagerClient.TargetedExtensionMessage;
/*     */ import atavism.server.plugins.WorldManagerClient.TargetedPropertyMessage;
/*     */ import atavism.server.util.DebugUtils;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MessageRegionTrigger
/*     */   implements RegionTrigger
/*     */ {
/*     */   public static final int TARGET_MODE = 1;
/*     */   public static final int SUBJECT_MODE = 2;
/* 273 */   private int mode = 1;
/* 274 */   private Map<String, Serializable> messageProperties = new HashMap();
/*     */ 
/* 276 */   private Set<String> propertyExclusions = new HashSet();
/*     */ 
/*     */   public MessageRegionTrigger()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MessageRegionTrigger(int mode)
/*     */   {
/*  61 */     setMode(mode);
/*     */   }
/*     */ 
/*     */   public MessageRegionTrigger(int mode, Map<String, Serializable> messageProperties, Set<String> propertyExclusions)
/*     */   {
/*  68 */     setMode(mode);
/*  69 */     setMessageProperties(messageProperties);
/*  70 */     setPropertyExclusions(propertyExclusions);
/*     */   }
/*     */ 
/*     */   public int getMode()
/*     */   {
/*  78 */     return this.mode;
/*     */   }
/*     */ 
/*     */   public void setMode(int mode)
/*     */   {
/*  85 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getMessageProperties()
/*     */   {
/*  92 */     return this.messageProperties;
/*     */   }
/*     */ 
/*     */   public void setMessageProperties(Map<String, Serializable> messageProperties)
/*     */   {
/* 101 */     this.messageProperties = messageProperties;
/*     */   }
/*     */ 
/*     */   public Set<String> getPropertyExclusions()
/*     */   {
/* 108 */     return this.propertyExclusions;
/*     */   }
/*     */ 
/*     */   public void setPropertyExclusions(Set<String> propertyExclusions)
/*     */   {
/* 117 */     this.propertyExclusions = propertyExclusions;
/*     */   }
/*     */ 
/*     */   public void enter(AOObject obj, Region region)
/*     */   {
/* 125 */     Message message = makeMessage(obj, region);
/* 126 */     if (message == null) {
/* 127 */       Log.error("MessageRegionTrigger: can't build message for " + obj + " entering region " + region);
/*     */ 
/* 129 */       return;
/*     */     }
/*     */ 
/* 132 */     configureMessage(message, obj, region, "onEnter");
/*     */ 
/* 134 */     Engine.getAgent().sendBroadcast(message);
/*     */   }
/*     */ 
/*     */   public void leave(AOObject obj, Region region)
/*     */   {
/* 142 */     Message message = makeMessage(obj, region);
/* 143 */     if (message == null) {
/* 144 */       Log.error("MessageRegionTrigger: can't build message for " + obj + " leaving region " + region);
/*     */ 
/* 146 */       return;
/*     */     }
/*     */ 
/* 149 */     configureMessage(message, obj, region, "onLeave");
/*     */ 
/* 151 */     Engine.getAgent().sendBroadcast(message);
/*     */   }
/*     */ 
/*     */   protected Message makeMessage(AOObject obj, Region region)
/*     */   {
/* 156 */     MessageType type = null;
/* 157 */     String typeName = (String)region.getProperty("messageType");
/* 158 */     if ((typeName != null) && (!typeName.equals(""))) {
/* 159 */       type = MessageCatalog.getMessageType(typeName);
/* 160 */       if (type == null) {
/* 161 */         Log.error("MessageRegionTrigger: unknown messageType=" + typeName);
/* 162 */         return null;
/*     */       }
/*     */     }
/*     */ 
/* 166 */     String messageClass = (String)region.getProperty("messageClass");
/* 167 */     if ((messageClass == null) || (messageClass.equals(""))) {
/* 168 */       messageClass = "extension";
/*     */     }
/* 170 */     String extensionType = (String)region.getProperty("messageExtensionType");
/*     */ 
/* 172 */     Message message = null;
/* 173 */     if (messageClass.equals("extension")) {
/* 174 */       if (this.mode == 1) {
/* 175 */         WorldManagerClient.TargetedExtensionMessage extMessage = new WorldManagerClient.TargetedExtensionMessage(obj.getOid(), obj.getOid());
/*     */ 
/* 177 */         if (extensionType != null)
/* 178 */           extMessage.setExtensionType(extensionType);
/* 179 */         message = extMessage;
/*     */       }
/* 181 */       else if (this.mode == 2) {
/* 182 */         WorldManagerClient.ExtensionMessage extMessage = new WorldManagerClient.ExtensionMessage(obj.getOid());
/*     */ 
/* 184 */         if (extensionType != null)
/* 185 */           extMessage.setExtensionType(extensionType);
/* 186 */         message = extMessage;
/*     */       }
/*     */     }
/* 189 */     else if (messageClass.equals("property")) {
/* 190 */       if (this.mode == 1) {
/* 191 */         message = new WorldManagerClient.TargetedPropertyMessage(obj.getOid(), obj.getOid());
/*     */       }
/* 194 */       else if (this.mode == 2) {
/* 195 */         message = new PropertyMessage(type, obj.getOid());
/*     */       }
/*     */     }
/*     */ 
/* 199 */     if ((message != null) && (type != null)) {
/* 200 */       message.setMsgType(type);
/*     */     }
/* 202 */     return message;
/*     */   }
/*     */ 
/*     */   protected void configureMessage(Message message, AOObject obj, Region region, String action)
/*     */   {
/* 208 */     Map messageMap = null;
/* 209 */     if ((message instanceof PropertyMessage))
/* 210 */       messageMap = ((PropertyMessage)message).getPropertyMapRef();
/* 211 */     else if ((message instanceof WorldManagerClient.TargetedPropertyMessage)) {
/* 212 */       messageMap = ((WorldManagerClient.TargetedPropertyMessage)message).getPropertyMapRef();
/*     */     }
/* 214 */     if (messageMap != null) {
/* 215 */       if (action != null)
/* 216 */         messageMap.put("regionAction", action);
/* 217 */       if (this.messageProperties != null) {
/* 218 */         messageMap.putAll(this.messageProperties);
/*     */       }
/*     */     }
/* 221 */     String messageRegionProperties = (String)region.getProperty("messageRegionProperties");
/*     */ 
/* 223 */     if ((messageRegionProperties != null) && 
/* 224 */       (messageMap != null)) {
/* 225 */       copyProperties(messageRegionProperties, region.getPropertyMapRef(), messageMap);
/*     */     }
/*     */ 
/* 229 */     String objectProperties = (String)region.getProperty("messageObjectProperties");
/*     */ 
/* 231 */     if ((objectProperties != null) && 
/* 232 */       (messageMap != null)) {
/* 233 */       copyProperties(objectProperties, obj.getPropertyMap(), messageMap);
/*     */     }
/*     */ 
/* 237 */     if ((Log.loggingDebug) && (messageMap != null))
/* 238 */       Log.debug("MessageRegionTrigger: properties=" + DebugUtils.mapToString(messageMap));
/*     */   }
/*     */ 
/*     */   protected void copyProperties(String propertyNames, Map<String, Serializable> source, Map<String, Serializable> destination)
/*     */   {
/* 248 */     propertyNames = propertyNames.trim();
/* 249 */     if (propertyNames.equals("ALL")) {
/* 250 */       for (String prop : source.keySet()) {
/* 251 */         if (!this.propertyExclusions.contains(prop)) {
/* 252 */           Serializable value = (Serializable)source.get(prop);
/* 253 */           if (value != null)
/* 254 */             destination.put(prop, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 260 */       String[] props = propertyNames.split(",");
/* 261 */       for (String prop : props) {
/* 262 */         prop = prop.trim();
/* 263 */         if (!this.propertyExclusions.contains(prop)) {
/* 264 */           Serializable value = (Serializable)source.get(prop);
/* 265 */           if (value != null)
/* 266 */             destination.put(prop, value);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.MessageRegionTrigger
 * JD-Core Version:    0.6.0
 */