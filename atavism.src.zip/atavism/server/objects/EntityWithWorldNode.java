package atavism.server.objects;

import atavism.server.engine.BasicWorldNode;
import atavism.server.engine.InterpolatedWorldNode;
import atavism.server.engine.OID;

public abstract interface EntityWithWorldNode
{
  public abstract InterpolatedWorldNode getWorldNode();

  public abstract OID getOid();

  public abstract void setOid(OID paramOID);

  public abstract void setDirLocOrient(BasicWorldNode paramBasicWorldNode);

  public abstract void setWorldNode(InterpolatedWorldNode paramInterpolatedWorldNode);

  public abstract Entity getEntity();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.EntityWithWorldNode
 * JD-Core Version:    0.6.0
 */