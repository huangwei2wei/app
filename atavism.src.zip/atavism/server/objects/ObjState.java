/*    */ package atavism.server.objects;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public abstract class ObjState
/*    */   implements Serializable
/*    */ {
/*    */   public abstract Integer getIntValue();
/*    */ 
/*    */   public abstract String getStateName();
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 20 */     return getStateName().hashCode();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 24 */     if (!(other instanceof ObjState)) {
/* 25 */       return false;
/*    */     }
/* 27 */     return getStateName().equals(((ObjState)other).getStateName());
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ObjState
 * JD-Core Version:    0.6.0
 */