/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LightData
/*     */   implements Serializable
/*     */ {
/* 146 */   public static final String DirLightRegionType = (String)Entity.registerTransientPropertyKey("DirLight");
/*     */ 
/* 148 */   public static final String AmbientLightRegionType = (String)Entity.registerTransientPropertyKey("AmbientLight");
/*     */ 
/* 151 */   private String name = null;
/* 152 */   private Color diffuse = null;
/* 153 */   private Color specular = null;
/* 154 */   float attenuationRange = 0.0F;
/* 155 */   float attenuationConstant = 0.0F;
/* 156 */   float attenuationLinear = 0.0F;
/* 157 */   float attenuationQuadradic = 0.0F;
/*     */   Quaternion orient;
/*     */   Point loc;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public LightData()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LightData(String name, Color diffuse, Color specular, float attenuationRange, float attenuationConstant, float attenuationLinear, float attenuationQuadradic, Point initLoc, Quaternion orient)
/*     */   {
/*  38 */     setName(name);
/*  39 */     setDiffuse(diffuse);
/*  40 */     setSpecular(specular);
/*  41 */     setAttenuationRange(attenuationRange);
/*  42 */     setAttenuationConstant(attenuationConstant);
/*  43 */     setAttenuationLinear(attenuationLinear);
/*  44 */     setAttenuationQuadradic(attenuationQuadradic);
/*  45 */     setOrientation(orient);
/*  46 */     setInitLoc(this.loc);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  50 */     return "[LightData: name=" + getName() + ", diffuse=" + getDiffuse() + ", specular=" + getSpecular() + ", attenuationRange=" + getAttenuationRange() + ", attenuationConstant=" + getAttenuationConstant() + ", attenuationLinear=" + getAttenuationLinear() + ", attenuationQuadradic=" + getAttenuationQuadradic() + ", orient=" + getOrientation() + ", initLoc=" + getInitLoc() + "]";
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  64 */     this.name = name;
/*     */   }
/*     */   public String getName() {
/*  67 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setDiffuse(Color color) {
/*  71 */     this.diffuse = color;
/*     */   }
/*     */   public Color getDiffuse() {
/*  74 */     return this.diffuse;
/*     */   }
/*     */ 
/*     */   public void setSpecular(Color color) {
/*  78 */     this.specular = color;
/*     */   }
/*     */   public Color getSpecular() {
/*  81 */     return this.specular;
/*     */   }
/*     */ 
/*     */   public void setAttenuationRange(float val) {
/*  85 */     this.attenuationRange = val;
/*     */   }
/*     */   public float getAttenuationRange() {
/*  88 */     return this.attenuationRange;
/*     */   }
/*     */ 
/*     */   public void setAttenuationConstant(float val) {
/*  92 */     this.attenuationConstant = val;
/*     */   }
/*     */   public float getAttenuationConstant() {
/*  95 */     return this.attenuationConstant;
/*     */   }
/*     */ 
/*     */   public void setAttenuationLinear(float val) {
/*  99 */     this.attenuationLinear = val;
/*     */   }
/*     */   public float getAttenuationLinear() {
/* 102 */     return this.attenuationLinear;
/*     */   }
/*     */ 
/*     */   public void setAttenuationQuadradic(float val) {
/* 106 */     this.attenuationQuadradic = val;
/*     */   }
/*     */   public float getAttenuationQuadradic() {
/* 109 */     return this.attenuationQuadradic;
/*     */   }
/*     */ 
/*     */   public void setOrientation(Quaternion orient) {
/* 113 */     this.orient = orient;
/*     */   }
/*     */   public Quaternion getOrientation() {
/* 116 */     return this.orient;
/*     */   }
/*     */ 
/*     */   public void setInitLoc(Point loc)
/*     */   {
/* 125 */     this.loc = loc;
/*     */   }
/*     */ 
/*     */   public Point getInitLoc()
/*     */   {
/* 133 */     return this.loc;
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException
/*     */   {
/* 138 */     out.defaultWriteObject();
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 143 */     in.defaultReadObject();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.LightData
 * JD-Core Version:    0.6.0
 */