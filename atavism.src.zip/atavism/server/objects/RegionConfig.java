/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.util.LockFactory;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class RegionConfig
/*    */   implements Serializable
/*    */ {
/* 73 */   private Map<String, Object> propMap = new HashMap();
/*    */   private String type;
/*    */   protected transient Lock lock;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public RegionConfig()
/*    */   {
/* 19 */     setupTransient();
/*    */   }
/*    */ 
/*    */   public RegionConfig(String type) {
/* 23 */     setupTransient();
/* 24 */     setType(type);
/*    */   }
/*    */ 
/*    */   private void setupTransient()
/*    */   {
/* 29 */     this.lock = LockFactory.makeLock("RegionConfigLock");
/*    */   }
/*    */ 
/*    */   private void readObject(ObjectInputStream in)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 37 */     in.defaultReadObject();
/* 38 */     setupTransient();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 42 */     return "[RegionConfig type=" + this.type + "]";
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 46 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 50 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setProperty(String key, Object value) {
/* 54 */     this.lock.lock();
/*    */     try {
/* 56 */       this.propMap.put(key, value);
/*    */     }
/*    */     finally {
/* 59 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object getProperty(String key) {
/* 64 */     this.lock.lock();
/*    */     try {
/* 66 */       Object localObject1 = this.propMap.get(key);
/*    */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.RegionConfig
 * JD-Core Version:    0.6.0
 */