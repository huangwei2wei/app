/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ 
/*     */ public class SpawnData extends Entity
/*     */ {
/*     */   private int templateID;
/*     */   private String templateName;
/*     */   private int category;
/*     */   private String factoryName;
/*     */   private String className;
/*     */   private OID instanceOid;
/*     */   private Point loc;
/*     */   private Quaternion orient;
/*     */   private Integer spawnRadius;
/*     */   private Integer numSpawns;
/*     */   private Integer respawnTime;
/*     */   private Integer corpseDespawnTime;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public SpawnData()
/*     */   {
/*  14 */     setNamespace(Namespace.TRANSIENT);
/*     */   }
/*     */ 
/*     */   public SpawnData(String name, String templateName, int category, String factoryName, OID instanceOid, Point loc, Quaternion orient, Integer spawnRadius, Integer numSpawns, Integer respawnTime)
/*     */   {
/*  41 */     super(name);
/*  42 */     setNamespace(Namespace.TRANSIENT);
/*  43 */     setTemplateName(templateName);
/*  44 */     setCategory(category);
/*  45 */     setFactoryName(factoryName);
/*  46 */     setInstanceOid(instanceOid);
/*  47 */     setLoc(loc);
/*  48 */     setOrientation(orient);
/*  49 */     setSpawnRadius(spawnRadius);
/*  50 */     setNumSpawns(numSpawns);
/*  51 */     setRespawnTime(respawnTime);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  55 */     return "[SpawnData: oid=" + getOid() + ", name=" + getName() + ", templateName=" + getTemplateName() + ", factoryName=" + getFactoryName() + ", instanceOid=" + getInstanceOid() + ", loc=" + getLoc() + ", orient=" + getOrientation() + ", numSpawns=" + getNumSpawns() + ", respawnTime=" + getRespawnTime() + ", corpseDespawnTime=" + getCorpseDespawnTime() + "]";
/*     */   }
/*     */ 
/*     */   public void setClassName(String className)
/*     */   {
/*  80 */     this.className = className;
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  86 */     return this.className;
/*     */   }
/*     */ 
/*     */   public void setTemplateID(int templateID)
/*     */   {
/*  92 */     this.templateID = templateID;
/*     */   }
/*     */ 
/*     */   public int getTemplateID()
/*     */   {
/*  98 */     return this.templateID;
/*     */   }
/*     */ 
/*     */   public void setTemplateName(String templateName)
/*     */   {
/* 104 */     this.templateName = templateName;
/*     */   }
/*     */ 
/*     */   public String getTemplateName()
/*     */   {
/* 110 */     return this.templateName;
/*     */   }
/*     */ 
/*     */   public void setCategory(int category)
/*     */   {
/* 116 */     this.category = category;
/*     */   }
/*     */ 
/*     */   public int getCategory()
/*     */   {
/* 122 */     return this.category;
/*     */   }
/*     */ 
/*     */   public void setFactoryName(String factoryName)
/*     */   {
/* 130 */     this.factoryName = factoryName;
/*     */   }
/*     */ 
/*     */   public String getFactoryName()
/*     */   {
/* 136 */     return this.factoryName;
/*     */   }
/*     */ 
/*     */   public OID getInstanceOid()
/*     */   {
/* 143 */     return this.instanceOid;
/*     */   }
/*     */ 
/*     */   public void setInstanceOid(OID oid)
/*     */   {
/* 150 */     this.instanceOid = oid;
/*     */   }
/*     */ 
/*     */   public void setLoc(Point loc)
/*     */   {
/* 156 */     this.loc = loc;
/*     */   }
/*     */ 
/*     */   public Point getLoc()
/*     */   {
/* 162 */     return this.loc;
/*     */   }
/*     */ 
/*     */   public void setOrientation(Quaternion orient)
/*     */   {
/* 168 */     this.orient = orient;
/*     */   }
/*     */ 
/*     */   public Quaternion getOrientation()
/*     */   {
/* 174 */     return this.orient;
/*     */   }
/*     */ 
/*     */   public void setSpawnRadius(Integer spawnRadius)
/*     */   {
/* 180 */     this.spawnRadius = spawnRadius;
/*     */   }
/*     */ 
/*     */   public Integer getSpawnRadius()
/*     */   {
/* 186 */     return this.spawnRadius;
/*     */   }
/*     */ 
/*     */   public void setNumSpawns(Integer numSpawns)
/*     */   {
/* 192 */     this.numSpawns = numSpawns;
/*     */   }
/*     */ 
/*     */   public Integer getNumSpawns()
/*     */   {
/* 198 */     return this.numSpawns;
/*     */   }
/*     */ 
/*     */   public void setRespawnTime(Integer respawnTime)
/*     */   {
/* 205 */     this.respawnTime = respawnTime;
/*     */   }
/*     */ 
/*     */   public Integer getRespawnTime()
/*     */   {
/* 211 */     return this.respawnTime;
/*     */   }
/*     */ 
/*     */   public void setCorpseDespawnTime(Integer time)
/*     */   {
/* 218 */     this.corpseDespawnTime = time;
/*     */   }
/*     */ 
/*     */   public Integer getCorpseDespawnTime()
/*     */   {
/* 224 */     return this.corpseDespawnTime;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.SpawnData
 * JD-Core Version:    0.6.0
 */