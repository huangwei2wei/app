/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.msgsys.BooleanResponseMessage;
/*    */ import atavism.msgsys.MessageAgent;
/*    */ import atavism.msgsys.ResponseCallback;
/*    */ import atavism.msgsys.ResponseMessage;
/*    */ import atavism.server.engine.BasicWorldNode;
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.plugins.InstanceClient;
/*    */ import atavism.server.plugins.InstanceClient.InstanceEntryReqMessage;
/*    */ import atavism.server.util.Log;
/*    */ 
/*    */ public class InstanceEntryRegionTrigger
/*    */   implements RegionTrigger, ResponseCallback
/*    */ {
/*    */   public void enter(AOObject obj, Region region)
/*    */   {
/* 29 */     if (!obj.getType().isPlayer()) {
/* 30 */       return;
/*    */     }
/* 32 */     String instanceName = (String)region.getProperty("instanceName");
/* 33 */     if (instanceName == null) {
/* 34 */       Log.error("InstanceEntryRegionTrigger: missing instanceName property on region " + region);
/* 35 */       return;
/*    */     }
/*    */ 
/* 38 */     String markerName = (String)region.getProperty("locMarker");
/* 39 */     if (markerName == null) {
/* 40 */       Log.error("InstanceEntryRegionTrigger: missing locMarker property on region " + region);
/* 41 */       return;
/*    */     }
/*    */ 
/* 44 */     OID instanceOid = InstanceClient.getInstanceOid(instanceName);
/* 45 */     if (instanceOid == null) {
/* 46 */       Log.error("InstanceEntryRegionTrigger: unknown instanceName=" + instanceName);
/*    */ 
/* 48 */       return;
/*    */     }
/*    */ 
/* 51 */     Marker marker = InstanceClient.getMarker(instanceOid, markerName);
/* 52 */     if (marker == null) {
/* 53 */       Log.error("Instance entry event: unknown locMarker=" + markerName);
/*    */ 
/* 55 */       return;
/*    */     }
/*    */ 
/* 58 */     BasicWorldNode wnode = new BasicWorldNode();
/* 59 */     wnode.setInstanceOid(instanceOid);
/* 60 */     wnode.setLoc(marker.getPoint());
/* 61 */     wnode.setDir(new AOVector(0.0F, 0.0F, 0.0F));
/* 62 */     if (marker.getOrientation() != null) {
/* 63 */       wnode.setOrientation(marker.getOrientation());
/*    */     }
/* 65 */     InstanceClient.InstanceEntryReqMessage message = new InstanceClient.InstanceEntryReqMessage(obj.getOid(), wnode);
/*    */ 
/* 68 */     Engine.getAgent().sendRPC(message, this);
/*    */   }
/*    */ 
/*    */   public void leave(AOObject obj, Region region)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void handleResponse(ResponseMessage response)
/*    */   {
/* 80 */     if (Log.loggingDebug)
/* 81 */       Log.debug("InstanceEntryRegionTrigger: instance entry result=" + ((BooleanResponseMessage)response).getBooleanVal());
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.InstanceEntryRegionTrigger
 * JD-Core Version:    0.6.0
 */