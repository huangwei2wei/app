/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class World
/*     */ {
/*  16 */   public static OID DEBUG_OID = OID.fromLong(2221998L);
/*     */ 
/*  27 */   private static Geometry worldGeometry = null;
/*     */ 
/*  35 */   private static Geometry localGeo = null;
/*     */ 
/*  88 */   private static List<String> uiThemes = new LinkedList();
/*     */ 
/*  93 */   public static Boolean FollowsTerrainOverride = null;
/*     */ 
/* 110 */   public static int perceiverRadius = 100;
/*     */ 
/* 117 */   private static int locTolerance = 10;
/*     */ 
/* 125 */   private static PermissionFactory defaultPermissionFactory = null;
/*     */ 
/* 127 */   private static Lock staticLock = LockFactory.makeLock("StaticWorldLock");
/*     */ 
/*     */   public static void setGeometry(Geometry g)
/*     */   {
/*  22 */     worldGeometry = g;
/*     */   }
/*     */   public static Geometry getGeometry() {
/*  25 */     return worldGeometry;
/*     */   }
/*     */ 
/*     */   public static void setLocalGeometry(Geometry g)
/*     */   {
/*  30 */     localGeo = g;
/*     */   }
/*     */   public static Geometry getLocalGeometry() {
/*  33 */     return localGeo;
/*     */   }
/*     */ 
/*     */   public static void addTheme(String theme)
/*     */   {
/*  43 */     staticLock.lock();
/*     */     try {
/*  45 */       uiThemes.add(theme);
/*     */     }
/*     */     finally {
/*  48 */       staticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setTheme(String theme)
/*     */   {
/*  56 */     staticLock.lock();
/*     */     try {
/*  58 */       uiThemes.clear();
/*  59 */       uiThemes.add(theme);
/*     */     }
/*     */     finally {
/*  62 */       staticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void clearThemes()
/*     */   {
/*  70 */     staticLock.lock();
/*     */     try {
/*  72 */       uiThemes.clear();
/*     */     }
/*     */     finally {
/*  75 */       staticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static List<String> getThemes() {
/*  80 */     staticLock.lock();
/*     */     try {
/*  82 */       LinkedList localLinkedList = new LinkedList(uiThemes);
/*     */       return localLinkedList; } finally { staticLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public static void setLocTolerance(int dist)
/*     */   {
/* 100 */     locTolerance = dist;
/*     */   }
/*     */ 
/*     */   public static int getLocTolerance()
/*     */   {
/* 107 */     return locTolerance;
/*     */   }
/*     */ 
/*     */   public static void setDefaultPermission(PermissionFactory factory)
/*     */   {
/* 120 */     defaultPermissionFactory = factory;
/*     */   }
/*     */   public static PermissionFactory getDefaultPermission() {
/* 123 */     return defaultPermissionFactory;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.World
 * JD-Core Version:    0.6.0
 */