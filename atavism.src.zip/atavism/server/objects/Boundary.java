/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.math.Geometry;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Boundary
/*     */   implements Cloneable, Serializable
/*     */ {
/* 123 */   protected Geometry boundingBox = null;
/*     */ 
/* 253 */   List<Point> pointList = new LinkedList();
/*     */ 
/* 255 */   transient Lock lock = null;
/*     */ 
/* 257 */   String name = null;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Boundary()
/*     */   {
/*  15 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public Boundary(String name) {
/*  19 */     setupTransient();
/*  20 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public Boundary(List<Point> points) {
/*  24 */     setupTransient();
/*  25 */     setPoints(points);
/*     */   }
/*     */ 
/*     */   void setupTransient() {
/*  29 */     this.lock = LockFactory.makeLock("BoundaryLock");
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/*  34 */     in.defaultReadObject();
/*  35 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  39 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  43 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  47 */     String s = "[Boundary: name=" + this.name;
/*  48 */     this.lock.lock();
/*     */     try {
/*  50 */       for (Point p : this.pointList) {
/*  51 */         s = s + " p=" + p;
/*     */       }
/*  53 */       ??? = s + "]";
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  60 */     this.lock.lock();
/*     */     try {
/*  62 */       Boundary b = new Boundary(this.pointList);
/*  63 */       b.setName(getName());
/*  64 */       Boundary localBoundary1 = b;
/*     */       return localBoundary1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setPoints(List<Point> points)
/*     */   {
/*  71 */     this.lock.lock();
/*     */     try {
/*  73 */       this.pointList = new LinkedList(points);
/*  74 */       this.boundingBox = null;
/*     */     } finally {
/*  76 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Point> getPoints() {
/*  81 */     this.lock.lock();
/*     */     try {
/*  83 */       LinkedList localLinkedList = new LinkedList(this.pointList);
/*     */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void addPoint(Point p)
/*     */   {
/*  90 */     this.lock.lock();
/*     */     try {
/*  92 */       this.pointList.add(p);
/*  93 */       this.boundingBox = null;
/*     */     } finally {
/*  95 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Geometry getBoundingBox() {
/* 100 */     this.lock.lock();
/*     */     try {
/* 102 */       if (this.boundingBox != null) {
/* 103 */         Geometry localGeometry = this.boundingBox;
/*     */         return localGeometry;
/*     */       }
/* 105 */       float minX = 3.4028235E+38F; float maxX = 1.4E-45F; float minZ = 3.4028235E+38F; float maxZ = 1.4E-45F;
/* 106 */       for (Point p : this.pointList) {
/* 107 */         if (p.getX() < minX)
/* 108 */           minX = p.getX();
/* 109 */         if (p.getX() > maxX)
/* 110 */           maxX = p.getX();
/* 111 */         if (p.getZ() < minZ)
/* 112 */           minZ = p.getZ();
/* 113 */         if (p.getZ() > maxZ)
/* 114 */           maxZ = p.getZ();
/*     */       }
/* 116 */       this.boundingBox = new Geometry(minX, maxX, minZ, maxZ);
/* 117 */       ??? = this.boundingBox;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean contains(Point p)
/*     */   {
/* 136 */     int count = 0;
/*     */ 
/* 138 */     this.lock.lock();
/*     */     try
/*     */     {
/* 142 */       Float maxZ = null;
/* 143 */       Float maxX = null;
/* 144 */       for (Point tmpP : this.pointList) {
/* 145 */         if (maxZ == null) {
/* 146 */           maxZ = Float.valueOf(tmpP.getZ());
/* 147 */           maxX = Float.valueOf(tmpP.getX());
/* 148 */           continue;
/*     */         }
/* 150 */         if (tmpP.getZ() > maxZ.floatValue()) {
/* 151 */           maxZ = Float.valueOf(tmpP.getZ());
/*     */         }
/* 153 */         if (tmpP.getX() > maxX.floatValue()) {
/* 154 */           maxX = Float.valueOf(tmpP.getX());
/*     */         }
/*     */       }
/* 157 */       if ((maxZ == null) || (maxX == null)) {
/* 158 */         ??? = 0;
/*     */         return ???;
/*     */       }
/* 161 */       Point prevPoint = null;
/* 162 */       Point curPoint = null;
/* 163 */       Point firstPoint = null;
/* 164 */       Iterator iter = this.pointList.iterator();
/* 165 */       while (iter.hasNext())
/*     */       {
/* 167 */         if (curPoint == null) {
/* 168 */           curPoint = (Point)iter.next();
/* 169 */           firstPoint = curPoint;
/* 170 */           continue;
/*     */         }
/*     */ 
/* 175 */         prevPoint = curPoint;
/* 176 */         curPoint = (Point)iter.next();
/* 177 */         Vector2 p1 = new Vector2(prevPoint.getX(), prevPoint.getZ());
/* 178 */         p2 = new Vector2(curPoint.getX(), curPoint.getZ());
/*     */ 
/* 182 */         Vector2 p3 = new Vector2(p.getX(), p.getZ());
/* 183 */         Vector2 p4 = new Vector2(maxX.floatValue(), maxZ.floatValue() + 1.0F);
/*     */ 
/* 187 */         if (IntersectSegments(p1, p2, p3, p4)) {
/* 188 */           count++;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 195 */       if (IntersectSegments(new Vector2(firstPoint.getX(), firstPoint.getZ()), new Vector2(curPoint.getX(), curPoint.getZ()), new Vector2(p.getX(), p.getZ()), new Vector2(maxX.floatValue(), maxZ.floatValue() + 1.0F)))
/*     */       {
/* 199 */         count++;
/*     */       }
/*     */ 
/* 205 */       boolean rv = count % 2 != 0;
/*     */ 
/* 208 */       Vector2 p2 = rv;
/*     */       return p2; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   private static boolean IntersectSegments(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4)
/*     */   {
/* 217 */     double den = (p4.y - p3.y) * (p2.x - p1.x) - (p4.x - p3.x) * (p2.y - p1.y);
/*     */ 
/* 220 */     double t1num = (p4.x - p3.x) * (p1.y - p3.y) - (p4.y - p3.y) * (p1.x - p3.x);
/*     */ 
/* 223 */     double t2num = (p2.x - p1.x) * (p1.y - p3.y) - (p2.y - p1.y) * (p1.x - p3.x);
/*     */ 
/* 226 */     if (den == 0.0D) {
/* 227 */       return false;
/*     */     }
/*     */ 
/* 230 */     double t1 = t1num / den;
/* 231 */     double t2 = t2num / den;
/*     */ 
/* 238 */     return (t1 >= 0.0D) && (t1 < 1.0D) && (t2 >= 0.0D) && (t2 <= 1.0D);
/*     */   }
/*     */ 
/*     */   public static Boundary getMaxBoundary()
/*     */   {
/* 244 */     int min = -2147483648;
/* 245 */     int max = 2147483647;
/* 246 */     Boundary b = new Boundary();
/* 247 */     b.addPoint(new Point(min, 0.0F, max));
/* 248 */     b.addPoint(new Point(max, 0.0F, max));
/* 249 */     b.addPoint(new Point(max, 0.0F, min));
/* 250 */     b.addPoint(new Point(min, 0.0F, min));
/* 251 */     return b;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Boundary
 * JD-Core Version:    0.6.0
 */