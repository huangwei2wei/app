/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.plugins.InstanceClient;
/*    */ import atavism.server.util.Log;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class InstanceTimeout
/*    */ {
/* 97 */   private Map<OID, Long> emptyInstances = new HashMap();
/*    */   private int defaultTimeout;
/*    */ 
/*    */   public InstanceTimeout(int defaultTimeout)
/*    */   {
/* 15 */     this.defaultTimeout = defaultTimeout;
/*    */   }
/*    */ 
/*    */   public void start()
/*    */   {
/* 20 */     new Thread(new ThreadRun(null), "InstanceTimeout").start();
/*    */   }
/*    */ 
/*    */   public int getDefaultTimeout()
/*    */   {
/* 25 */     return this.defaultTimeout;
/*    */   }
/*    */ 
/*    */   public void setDefaultTimeout(int timeout)
/*    */   {
/* 30 */     this.defaultTimeout = timeout;
/*    */   }
/*    */ 
/*    */   private void scanInstances()
/*    */   {
/* 54 */     Entity[] entities = (Entity[])EntityManager.getAllEntitiesByNamespace(InstanceClient.NAMESPACE);
/*    */ 
/* 58 */     long now = System.currentTimeMillis();
/* 59 */     for (Entity entity : entities) {
/* 60 */       Instance instance = (Instance)entity;
/* 61 */       if (readyForTimeout(instance)) {
/* 62 */         Long emptyTime = (Long)this.emptyInstances.get(instance.getOid());
/* 63 */         if (emptyTime == null) {
/* 64 */           this.emptyInstances.put(instance.getOid(), Long.valueOf(now));
/*    */         }
/* 66 */         else if ((now - emptyTime.longValue()) / 1000L >= this.defaultTimeout) {
/* 67 */           unloadInstance(instance);
/* 68 */           now = System.currentTimeMillis();
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 73 */     Iterator iterator = this.emptyInstances.keySet().iterator();
/* 74 */     while (iterator.hasNext()) {
/* 75 */       Entity entity = EntityManager.getEntityByNamespace((OID)iterator.next(), InstanceClient.NAMESPACE);
/*    */ 
/* 77 */       if (entity == null)
/* 78 */         iterator.remove();
/*    */     }
/*    */   }
/*    */ 
/*    */   private void unloadInstance(Instance instance)
/*    */   {
/* 84 */     if (instance.getState() == 3) {
/* 85 */       Log.info("InstancePlugin: INSTANCE_TIMEOUT instanceOid=" + instance.getOid() + " name=" + instance.getName());
/*    */ 
/* 87 */       InstanceClient.unloadInstance(instance.getOid());
/* 88 */       this.emptyInstances.remove(instance.getOid());
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean readyForTimeout(Instance instance)
/*    */   {
/* 94 */     return instance.getPlayerPopulation() == 0;
/*    */   }
/*    */ 
/*    */   private class ThreadRun
/*    */     implements Runnable
/*    */   {
/*    */     private ThreadRun()
/*    */     {
/*    */     }
/*    */ 
/*    */     public void run()
/*    */     {
/*    */       while (true)
/*    */       {
/*    */         try
/*    */         {
/* 39 */           InstanceTimeout.this.scanInstances();
/*    */         }
/*    */         catch (Exception e) {
/* 42 */           Log.exception("InstanceTimeout", e);
/*    */         }
/*    */         try {
/* 45 */           Thread.sleep(InstanceTimeout.this.defaultTimeout * 1000 / 2);
/*    */         }
/*    */         catch (InterruptedException e)
/*    */         {
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.InstanceTimeout
 * JD-Core Version:    0.6.0
 */