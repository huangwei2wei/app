/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.beans.DefaultPersistenceDelegate;
/*     */ import java.beans.Encoder;
/*     */ import java.beans.ExceptionListener;
/*     */ import java.beans.Expression;
/*     */ import java.beans.XMLDecoder;
/*     */ import java.beans.XMLEncoder;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class AOObjectPersistenceDelegate extends DefaultPersistenceDelegate
/*     */ {
/*     */   protected void initialize(Class type, Object oldInstance, Object newInstance, Encoder out)
/*     */   {
/*  16 */     System.out.println("AOObjectPersistenceDelegate: start persisting obj: " + oldInstance);
/*  17 */     super.initialize(type, oldInstance, newInstance, out);
/*     */ 
/*  21 */     System.out.println("AOObjectPersistenceDelegate: super.initialize returned, obj: " + oldInstance);
/*     */   }
/*     */ 
/*     */   protected Expression instantiate(Object oldInstance, Encoder out)
/*     */   {
/*  31 */     ObjectType objectType = (ObjectType)oldInstance;
/*  32 */     System.out.println("instantiate: " + objectType);
/*  33 */     System.out.println("instantiate: " + objectType.getTypeId());
/*  34 */     return new Expression(ObjectType.class, "getObjectType", new Object[] { Short.valueOf(objectType.getTypeId()) });
/*     */   }
/*     */ 
/*     */   protected boolean mutatesTo(Object oldInstance, Object newInstance)
/*     */   {
/*  39 */     return oldInstance == newInstance;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  70 */     ObjectType.intern(33, "thirty");
/*     */ 
/*  72 */     Two two = new Two();
/*  73 */     two.setO1(ObjectType.intern(2, "two"));
/*  74 */     two.setO2(ObjectType.intern(2, "two"));
/*  75 */     two.setType(ObjectTypes.player);
/*     */ 
/*  77 */     Object object = two;
/*     */ 
/*  90 */     ByteArrayOutputStream xml = new ByteArrayOutputStream(1000);
/*  91 */     XMLEncoder encoder = new XMLEncoder(xml);
/*  92 */     encoder.setExceptionListener(new ExceptionListener() {
/*     */       public void exceptionThrown(Exception exception) {
/*  94 */         Log.exception("AOObjectPersistenceDelegate.main caught exception setting encoder exception listener", exception);
/*     */       }
/*     */     });
/* 145 */     encoder.setPersistenceDelegate(ObjectType.class, new AOObjectPersistenceDelegate());
/*     */ 
/* 149 */     encoder.writeObject(object);
/* 150 */     encoder.close();
/* 151 */     System.out.println(xml.toString());
/*     */ 
/* 153 */     XMLDecoder d = new XMLDecoder(new ByteArrayInputStream(xml.toByteArray()));
/*     */ 
/* 155 */     Two x2 = (Two)d.readObject();
/* 156 */     System.out.println("decode1: " + x2.getO1());
/* 157 */     System.out.println("decode2: " + x2.getO2());
/*     */   }
/*     */ 
/*     */   public static class Two extends AOObjectPersistenceDelegate.One
/*     */   {
/*     */     ObjectType o1;
/*     */     ObjectType o2;
/*     */ 
/*     */     public ObjectType getO1()
/*     */     {
/*  53 */       return this.o1; } 
/*  54 */     public ObjectType getO2() { return this.o2; } 
/*  55 */     public void setO1(ObjectType o) { this.o1 = o; } 
/*  56 */     public void setO2(ObjectType o) { this.o2 = o;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class One
/*     */   {
/*  47 */     ObjectType type = ObjectTypes.unknown;
/*     */ 
/*     */     public ObjectType getType()
/*     */     {
/*  45 */       return this.type; } 
/*  46 */     public void setType(ObjectType t) { this.type = t;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.AOObjectPersistenceDelegate
 * JD-Core Version:    0.6.0
 */