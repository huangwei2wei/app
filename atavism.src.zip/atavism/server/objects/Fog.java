/*    */ package atavism.server.objects;
/*    */ 
/*    */ public class Fog
/*    */ {
/* 57 */   Color color = null;
/* 58 */   int fogStart = -1;
/* 59 */   int fogEnd = -1;
/*    */ 
/* 93 */   protected String name = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Fog()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Fog(String name)
/*    */   {
/*  8 */     setName(name);
/*    */   }
/*    */ 
/*    */   public Fog(String name, Color c, int start, int end)
/*    */   {
/* 15 */     setName(name);
/* 16 */     setColor(c);
/* 17 */     setStart(start);
/* 18 */     setEnd(end);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 22 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 26 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 30 */     return "[Fog: color=" + this.color + ", start=" + this.fogStart + ", end=" + this.fogEnd + "]";
/*    */   }
/*    */ 
/*    */   public void setColor(Color c)
/*    */   {
/* 37 */     this.color = c;
/*    */   }
/*    */   public Color getColor() {
/* 40 */     return this.color;
/*    */   }
/*    */ 
/*    */   public void setStart(int start) {
/* 44 */     this.fogStart = start;
/*    */   }
/*    */   public int getStart() {
/* 47 */     return this.fogStart;
/*    */   }
/*    */ 
/*    */   public void setEnd(int end) {
/* 51 */     this.fogEnd = end;
/*    */   }
/*    */   public int getEnd() {
/* 54 */     return this.fogEnd;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Fog
 * JD-Core Version:    0.6.0
 */