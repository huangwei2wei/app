/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ 
/*    */ public class Light extends AOObject
/*    */   implements Cloneable
/*    */ {
/* 62 */   public static String LightDataPropertyKey = "lightData";
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Light()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Light(OID oid)
/*    */   {
/* 12 */     super(oid);
/*    */   }
/*    */ 
/*    */   public Light(String name) {
/* 16 */     super(name);
/*    */   }
/*    */ 
/*    */   public Light(String name, Color diffuse, Color specular, float attenuationRange, float attenuationConstant, float attenuationLinear, float attenuationQuadradic)
/*    */   {
/* 30 */     LightData ld = new LightData();
/* 31 */     ld.setName(name);
/* 32 */     ld.setDiffuse(diffuse);
/* 33 */     ld.setSpecular(specular);
/* 34 */     ld.setAttenuationRange(attenuationRange);
/* 35 */     ld.setAttenuationConstant(attenuationConstant);
/* 36 */     ld.setAttenuationLinear(attenuationLinear);
/* 37 */     ld.setAttenuationQuadradic(attenuationQuadradic);
/* 38 */     setLightData(ld);
/*    */   }
/*    */ 
/*    */   public ObjectType getType()
/*    */   {
/* 45 */     return ObjectTypes.light;
/*    */   }
/*    */ 
/*    */   public Object clone() throws CloneNotSupportedException {
/* 49 */     throw new CloneNotSupportedException("Light.clone: inherited class must implement clone");
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 53 */     return "[Light: " + super.toString() + "]";
/*    */   }
/*    */ 
/*    */   public LightData getLightData() {
/* 57 */     return (LightData)getProperty(LightDataPropertyKey);
/*    */   }
/*    */   public void setLightData(LightData ld) {
/* 60 */     setProperty(LightDataPropertyKey, ld);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 65 */     return getLightData().getName();
/*    */   }
/*    */   public Color getDiffuse() {
/* 68 */     return getLightData().getDiffuse();
/*    */   }
/*    */   public Color getSpecular() {
/* 71 */     return getLightData().getSpecular();
/*    */   }
/*    */   public float getAttenuationRange() {
/* 74 */     return getLightData().getAttenuationRange();
/*    */   }
/*    */   public float getAttenuationConstant() {
/* 77 */     return getLightData().getAttenuationConstant();
/*    */   }
/*    */   public float getAttenuationLinear() {
/* 80 */     return getLightData().getAttenuationLinear();
/*    */   }
/*    */   public float getAttenuationQuadradic() {
/* 83 */     return getLightData().getAttenuationQuadradic();
/*    */   }
/*    */ 
/*    */   public static enum LightType {
/* 87 */     Point, Directional;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Light
 * JD-Core Version:    0.6.0
 */