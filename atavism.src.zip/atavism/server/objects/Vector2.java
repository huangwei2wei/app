/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.math.Point;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Vector2
/*    */   implements Cloneable, Serializable
/*    */ {
/* 37 */   public double x = -1.0D;
/* 38 */   public double y = -1.0D;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Vector2()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Vector2(int x, int y)
/*    */   {
/* 15 */     this.x = x;
/* 16 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public Vector2(double x, double y) {
/* 20 */     this.x = x;
/* 21 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public Vector2(Point p) {
/* 25 */     this.x = p.getX();
/* 26 */     this.y = p.getZ();
/*    */   }
/*    */ 
/*    */   public Object clone() {
/* 30 */     return new Vector2(this.x, this.y);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 34 */     return "[Vector2 x=" + this.x + " y=" + this.y + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Vector2
 * JD-Core Version:    0.6.0
 */