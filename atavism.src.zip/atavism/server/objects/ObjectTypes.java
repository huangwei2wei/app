/*    */ package atavism.server.objects;
/*    */ 
/*    */ public class ObjectTypes
/*    */ {
/*  8 */   public static final ObjectType unknown = ObjectType.intern(-1, "Unknown");
/*    */ 
/* 13 */   public static final ObjectType structure = ObjectType.intern(0, "STRUCTURE", 1);
/*    */ 
/* 18 */   public static final ObjectType mob = ObjectType.intern(1, "MOB", 2);
/*    */ 
/* 24 */   public static final ObjectType player = ObjectType.intern(3, "PLAYER", 6);
/*    */ 
/* 29 */   public static final ObjectType light = ObjectType.intern(4, "LIGHT");
/*    */ 
/* 34 */   public static final ObjectType terrainDecal = ObjectType.intern(5, "TDECAL", 1);
/*    */ 
/* 39 */   public static final ObjectType pointSound = ObjectType.intern(6, "PTSOUND", 1);
/*    */ 
/* 43 */   public static final ObjectType item = ObjectType.intern(7, "ITEM");
/*    */ 
/* 47 */   public static final ObjectType road = ObjectType.intern(8, "aoRoad");
/*    */ 
/* 51 */   public static final ObjectType bag = ObjectType.intern(9, "Bag");
/*    */ 
/* 55 */   public static final ObjectType combatInfo = ObjectType.intern(10, "CombatInfo");
/*    */ 
/* 58 */   public static final ObjectType instance = ObjectType.intern(11, "Instance");
/*    */ 
/* 62 */   public static final ObjectType questStateInfo = ObjectType.intern(12, "QuestStateInfo");
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ObjectTypes
 * JD-Core Version:    0.6.0
 */