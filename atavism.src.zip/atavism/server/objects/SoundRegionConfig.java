/*    */ package atavism.server.objects;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SoundRegionConfig extends RegionConfig
/*    */   implements Serializable
/*    */ {
/* 40 */   public static String RegionType = "SoundRegion";
/*    */ 
/* 42 */   List<SoundData> soundData = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public SoundRegionConfig()
/*    */   {
/* 15 */     setType(RegionType);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 19 */     return "[SoundConfig: soundData=" + this.soundData + "]";
/*    */   }
/*    */ 
/*    */   public void setSoundData(List<SoundData> soundData) {
/* 23 */     this.soundData = soundData;
/*    */   }
/*    */ 
/*    */   public List<SoundData> getSoundData() {
/* 27 */     return this.soundData;
/*    */   }
/*    */ 
/*    */   public boolean containsSound(String fileName) {
/* 31 */     if (this.soundData == null)
/* 32 */       return false;
/* 33 */     for (SoundData data : this.soundData) {
/* 34 */       if (fileName.equals(data.getFileName()))
/* 35 */         return true;
/*    */     }
/* 37 */     return false;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.SoundRegionConfig
 * JD-Core Version:    0.6.0
 */