/*    */ package atavism.server.objects;
/*    */ 
/*    */ public class SearchEntry
/*    */ {
/*    */   public Object key;
/*    */   public Object value;
/*    */ 
/*    */   public SearchEntry()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SearchEntry(Object key, Object value)
/*    */   {
/* 15 */     this.key = key;
/* 16 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 27 */     return "[SearchEntry key=" + this.key + " value=" + this.value + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.SearchEntry
 * JD-Core Version:    0.6.0
 */