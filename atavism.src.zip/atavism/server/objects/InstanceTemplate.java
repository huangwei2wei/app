/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.agis.plugins.AgisMobPlugin;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.plugins.InstanceClient;
/*     */ import atavism.server.plugins.MobManagerClient;
/*     */ import atavism.server.plugins.ObjectManagerClient;
/*     */ import atavism.server.plugins.WorldManagerClient;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class InstanceTemplate
/*     */   implements Runnable
/*     */ {
/*     */   int id;
/*     */   int category;
/*     */   String name;
/*     */   OID administrator;
/*     */   boolean isPublic;
/*     */   String password;
/*     */   LinkedList<OID> developers;
/*     */   int islandType;
/*     */   boolean createOnStartup;
/*     */   int rating;
/*     */   String style;
/*     */   String description;
/*     */   int size;
/* 233 */   int populationLimit = -1;
/*     */   LinkedList<String> contentPacks;
/*     */   boolean subscriptionActive;
/*     */   HashMap<String, HashMap<String, Float>> portals;
/*     */   HashMap<Integer, SpawnData> spawns;
/* 239 */   ArrayList<OID> instanceOids = new ArrayList();
/* 240 */   HashMap<OID, ArrayList<SpawnData>> instanceSpawns = new HashMap();
/* 241 */   ArrayList<ScheduledFuture> spawnTasks = new ArrayList();
/*     */   public static final int ISLAND_TYPE_WORLD = 1;
/*     */   public static final int ISLAND_TYPE_DUNGEON = 2;
/*     */   public static final int ISLAND_TYPE_ARENA = 3;
/*     */   public static final int ISLAND_TYPE_HOUSE = 4;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public InstanceTemplate()
/*     */   {
/*  30 */     this.developers = new LinkedList();
/*  31 */     this.description = "";
/*  32 */     this.style = "";
/*  33 */     this.islandType = 0;
/*  34 */     this.password = "";
/*  35 */     this.rating = 0;
/*     */   }
/*     */ 
/*     */   public void scheduleSpawnLoading(OID instanceOid)
/*     */   {
/*  43 */     Log.debug("INSTANCE: scheduling spawn loading for instance: " + instanceOid);
/*     */ 
/*  45 */     for (String portalName : this.portals.keySet()) {
/*  46 */       HashMap portalProps = (HashMap)this.portals.get(portalName);
/*  47 */       Template markerTemplate = new Template();
/*  48 */       Point loc = new Point(((Float)portalProps.get("locX")).floatValue(), ((Float)portalProps.get("locY")).floatValue() + 0.0F, ((Float)portalProps.get("locZ")).floatValue());
/*  49 */       Quaternion orient = new Quaternion(((Float)portalProps.get("orientX")).floatValue(), ((Float)portalProps.get("orientY")).floatValue(), ((Float)portalProps.get("orientZ")).floatValue(), ((Float)portalProps.get("orientW")).floatValue());
/*  50 */       markerTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_NAME, portalName);
/*  51 */       markerTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_OBJECT_TYPE, WorldManagerClient.TEMPL_OBJECT_TYPE_MARKER);
/*  52 */       markerTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_INSTANCE, instanceOid);
/*  53 */       markerTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_LOC, loc);
/*  54 */       markerTemplate.put(Namespace.WORLD_MANAGER, WorldManagerClient.TEMPL_ORIENT, orient);
/*  55 */       OID objOid = ObjectManagerClient.generateObject(-1, "BaseTemplate", markerTemplate);
/*     */ 
/*  57 */       if (objOid != null) {
/*  58 */         WorldManagerClient.spawn(objOid);
/*  59 */         Log.debug("PORTAL: spawned portal " + portalName + " in instance " + this.name);
/*     */       }
/*     */     }
/*     */ 
/*  63 */     this.instanceOids.add(instanceOid);
/*  64 */     this.instanceSpawns.put(instanceOid, new ArrayList(this.spawns.values()));
/*     */ 
/*  66 */     this.spawnTasks.add(Engine.getExecutor().scheduleAtFixedRate(this, 10000L, 300L, TimeUnit.MILLISECONDS));
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  74 */     Log.debug("INSTANCE: spawning mobs for instance: " + this.instanceOids.get(0));
/*  75 */     OID instanceOid = (OID)this.instanceOids.get(0);
/*     */ 
/*  77 */     ArrayList instanceSpawnList = (ArrayList)this.instanceSpawns.get(instanceOid);
/*  78 */     loadSpawn((SpawnData)instanceSpawnList.remove(0), instanceOid);
/*     */ 
/*  80 */     if (instanceSpawnList.size() == 0) {
/*  81 */       this.instanceSpawns.remove(instanceOid);
/*  82 */       this.instanceOids.remove(0);
/*  83 */       ((ScheduledFuture)this.spawnTasks.remove(0)).cancel(true);
/*  84 */       Log.debug("INSTANCE: spawning task finished");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void loadSpawns(OID instanceOid)
/*     */   {
/*  93 */     for (SpawnData sd : this.spawns.values())
/*  94 */       loadSpawn(sd, instanceOid);
/*     */   }
/*     */ 
/*     */   protected void loadSpawn(SpawnData sd, OID instanceOid)
/*     */   {
/* 101 */     Log.debug("TEST: spawnData:" + sd);
/* 102 */     String location = sd.getStringProperty("markerName");
/* 103 */     Log.debug("TEST: location:" + location);
/* 104 */     if ((location != null) && (!location.equals("")))
/*     */     {
/* 106 */       Marker m = InstanceClient.getMarker(instanceOid, location);
/* 107 */       sd.setLoc(m.getPoint());
/* 108 */       sd.setOrientation(m.getOrientation());
/*     */     }
/* 110 */     Log.debug("MOB: finished location setting for spawn for mob: " + this.name);
/* 111 */     sd.setInstanceOid(instanceOid);
/*     */ 
/* 113 */     String factoryName = AgisMobPlugin.createMobFactory(sd);
/* 114 */     if (!factoryName.equals("")) {
/* 115 */       sd.setFactoryName(factoryName);
/* 116 */       MobManagerClient.createSpawnGenerator(sd);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updatePortal(String portalName, HashMap<String, Float> portalProps)
/*     */   {
/* 127 */     this.portals.put(portalName, portalProps);
/*     */   }
/*     */   public int getID() {
/* 130 */     return this.id;
/*     */   }
/* 132 */   public void setID(int id) { this.id = id; }
/*     */ 
/*     */   public int getCategory() {
/* 135 */     return this.category;
/*     */   }
/* 137 */   public void setCategory(int category) { this.category = category; }
/*     */ 
/*     */   public String getName() {
/* 140 */     return this.name;
/*     */   }
/* 142 */   public void setName(String name) { this.name = name; }
/*     */ 
/*     */   public OID getAdministrator() {
/* 145 */     return this.administrator;
/*     */   }
/* 147 */   public void setAdministrator(OID administrator) { this.administrator = administrator; }
/*     */ 
/*     */   public boolean getIsPublic() {
/* 150 */     return this.isPublic;
/*     */   }
/* 152 */   public void setIsPublic(boolean isPublic) { this.isPublic = isPublic; }
/*     */ 
/*     */   public String getPassword() {
/* 155 */     return this.password;
/*     */   }
/* 157 */   public void setPassword(String password) { this.password = password; }
/*     */ 
/*     */   public LinkedList<OID> getDevelopers() {
/* 160 */     return this.developers;
/*     */   }
/* 162 */   public void setDevelopers(LinkedList<OID> developers) { this.developers = developers; }
/*     */ 
/*     */   public int getIslandType() {
/* 165 */     return this.islandType;
/*     */   }
/* 167 */   public void setIslandType(int islandType) { this.islandType = islandType; }
/*     */ 
/*     */   public boolean getCreateOnStartup() {
/* 170 */     return this.createOnStartup;
/*     */   }
/* 172 */   public void setCreateOnStartup(boolean createOnStartup) { this.createOnStartup = createOnStartup; }
/*     */ 
/*     */   public int getRating() {
/* 175 */     return this.rating;
/*     */   }
/* 177 */   public void setRating(int rating) { this.rating = rating; }
/*     */ 
/*     */   public String getStyle() {
/* 180 */     return this.style;
/*     */   }
/* 182 */   public void setStyle(String style) { this.style = style; }
/*     */ 
/*     */   public String getDescription() {
/* 185 */     return this.description;
/*     */   }
/* 187 */   public void setDescription(String description) { this.description = description; }
/*     */ 
/*     */   public int getSize() {
/* 190 */     return this.size;
/*     */   }
/* 192 */   public void setSize(int size) { this.size = size; }
/*     */ 
/*     */   public int getPopulationLimit() {
/* 195 */     return this.populationLimit;
/*     */   }
/* 197 */   public void setPopulationLimit(int limit) { this.populationLimit = limit; }
/*     */ 
/*     */   public LinkedList<String> getContentPacks() {
/* 200 */     return this.contentPacks;
/*     */   }
/* 202 */   public void setContentPacks(LinkedList<String> contentPacks) { this.contentPacks = contentPacks; }
/*     */ 
/*     */   public boolean getSubscriptionActive() {
/* 205 */     return this.subscriptionActive;
/*     */   }
/* 207 */   public void setSubscriptionActive(boolean subscriptionActive) { this.subscriptionActive = subscriptionActive; }
/*     */ 
/*     */   public HashMap<String, HashMap<String, Float>> getPortals() {
/* 210 */     return this.portals;
/*     */   }
/* 212 */   public void setPortals(HashMap<String, HashMap<String, Float>> portals) { this.portals = portals; }
/*     */ 
/*     */   public HashMap<Integer, SpawnData> getSpawns() {
/* 215 */     return this.spawns;
/*     */   }
/* 217 */   public void setSpawns(HashMap<Integer, SpawnData> spawns) { this.spawns = spawns;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.InstanceTemplate
 * JD-Core Version:    0.6.0
 */