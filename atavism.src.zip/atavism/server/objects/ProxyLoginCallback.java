package atavism.server.objects;

import atavism.server.network.ClientConnection;
import atavism.server.plugins.ProxyPlugin.PlayerLoginStatus;

public abstract interface ProxyLoginCallback
{
  public abstract boolean duplicateLogin(ProxyPlugin.PlayerLoginStatus paramPlayerLoginStatus, ClientConnection paramClientConnection);

  public abstract String preLoad(Player paramPlayer, ClientConnection paramClientConnection);

  public abstract String postLoad(Player paramPlayer, ClientConnection paramClientConnection);

  public abstract void postSpawn(Player paramPlayer, ClientConnection paramClientConnection);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ProxyLoginCallback
 * JD-Core Version:    0.6.0
 */