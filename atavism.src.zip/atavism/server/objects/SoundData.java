/*    */ package atavism.server.objects;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class SoundData
/*    */   implements Serializable
/*    */ {
/* 73 */   private String fileName = null;
/* 74 */   private String type = null;
/* 75 */   private Map<String, String> properties = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public SoundData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SoundData(String fileName, String type, Map<String, String> properties)
/*    */   {
/* 25 */     setFileName(fileName);
/* 26 */     setType(type);
/* 27 */     setProperties(properties);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 31 */     return "[SoundData: FileName=" + getFileName() + ", Type=" + getType() + ", Properties=" + getProperties() + "]";
/*    */   }
/*    */ 
/*    */   public void setFileName(String fileName)
/*    */   {
/* 39 */     this.fileName = fileName;
/*    */   }
/*    */   public String getFileName() {
/* 42 */     return this.fileName;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 46 */     this.type = type;
/*    */   }
/*    */   public String getType() {
/* 49 */     return this.type;
/*    */   }
/*    */   public void setProperties(Map<String, String> properties) {
/* 52 */     this.properties = properties;
/*    */   }
/*    */   public Map<String, String> getProperties() {
/* 55 */     return this.properties;
/*    */   }
/*    */   public void addProperty(String key, String value) {
/* 58 */     if (this.properties == null)
/* 59 */       this.properties = new HashMap();
/* 60 */     this.properties.put(key, value);
/*    */   }
/*    */ 
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException
/*    */   {
/* 65 */     out.defaultWriteObject();
/*    */   }
/*    */ 
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*    */   {
/* 70 */     in.defaultReadObject();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.SoundData
 * JD-Core Version:    0.6.0
 */