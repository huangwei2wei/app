package atavism.server.objects;

public abstract interface RegionTrigger
{
  public abstract void enter(AOObject paramAOObject, Region paramRegion);

  public abstract void leave(AOObject paramAOObject, Region paramRegion);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.RegionTrigger
 * JD-Core Version:    0.6.0
 */