/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.Point;
/*    */ import atavism.server.math.Quaternion;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class InstanceRestorePoint
/*    */   implements Serializable
/*    */ {
/*    */   private OID instanceOid;
/*    */   private String instanceName;
/*    */   private Point loc;
/*    */   private Quaternion orient;
/*    */   private boolean fallback;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public InstanceRestorePoint()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InstanceRestorePoint(OID instanceOid, Point loc)
/*    */   {
/* 18 */     setInstanceOid(instanceOid);
/* 19 */     setLoc(loc);
/*    */   }
/*    */ 
/*    */   public InstanceRestorePoint(String instanceName, Point loc)
/*    */   {
/* 24 */     setInstanceName(instanceName);
/* 25 */     setLoc(loc);
/*    */   }
/*    */ 
/*    */   public InstanceRestorePoint(OID instanceOid, String instanceName, Point loc)
/*    */   {
/* 31 */     setInstanceOid(instanceOid);
/* 32 */     setInstanceName(instanceName);
/* 33 */     setLoc(loc);
/*    */   }
/*    */ 
/*    */   public OID getInstanceOid() {
/* 37 */     return this.instanceOid;
/*    */   }
/*    */ 
/*    */   public void setInstanceOid(OID oid) {
/* 41 */     this.instanceOid = oid;
/*    */   }
/*    */ 
/*    */   public String getInstanceName() {
/* 45 */     return this.instanceName;
/*    */   }
/*    */ 
/*    */   public void setInstanceName(String name) {
/* 49 */     this.instanceName = name;
/*    */   }
/*    */ 
/*    */   public Point getLoc() {
/* 53 */     return this.loc;
/*    */   }
/*    */ 
/*    */   public void setLoc(Point loc) {
/* 57 */     this.loc = loc;
/*    */   }
/*    */ 
/*    */   public Quaternion getOrientation() {
/* 61 */     return this.orient;
/*    */   }
/*    */ 
/*    */   public void setOrientation(Quaternion orient) {
/* 65 */     this.orient = orient;
/*    */   }
/*    */ 
/*    */   public boolean getFallbackFlag() {
/* 69 */     return this.fallback;
/*    */   }
/*    */   public void setFallbackFlag(boolean flag) {
/* 72 */     this.fallback = flag;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.InstanceRestorePoint
 * JD-Core Version:    0.6.0
 */