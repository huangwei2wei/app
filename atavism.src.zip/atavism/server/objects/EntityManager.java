/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class EntityManager
/*     */ {
/* 147 */   static Map<Namespace, Map<OID, Entity>> entitiesByNamespace = new HashMap();
/*     */ 
/*     */   public static Entity getEntityByNamespace(OID oid, Namespace namespace)
/*     */   {
/*  20 */     synchronized (entitiesByNamespace) {
/*  21 */       Map namespaceEntities = (Map)entitiesByNamespace.get(namespace);
/*     */ 
/*  28 */       if (namespaceEntities == null) {
/*  29 */         return null;
/*     */       }
/*  31 */       return (Entity)namespaceEntities.get(oid);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void registerEntityByNamespace(Entity entity, Namespace namespace)
/*     */   {
/*  41 */     entity.setNamespace(namespace);
/*  42 */     synchronized (entitiesByNamespace) {
/*  43 */       Map namespaceEntities = (Map)entitiesByNamespace.get(namespace);
/*  44 */       if (namespaceEntities == null) {
/*  45 */         namespaceEntities = new HashMap();
/*  46 */         entitiesByNamespace.put(namespace, namespaceEntities);
/*     */       }
/*  48 */       OID oid = entity.getOid();
/*  49 */       if (oid == null) {
/*  50 */         Log.error("Entity.registerEntityByNamespace: entity " + entity + ", namespace " + namespace + " oid is null");
/*     */       }
/*     */       else
/*     */       {
/*  58 */         namespaceEntities.put(oid, entity);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean removeEntityByNamespace(Entity entity, Namespace namespace)
/*     */   {
/*  67 */     OID oid = entity.getOid();
/*  68 */     return removeEntityByNamespace(oid, entity, namespace);
/*     */   }
/*     */ 
/*     */   public static boolean removeEntityByNamespace(OID oid, Namespace namespace)
/*     */   {
/*  75 */     return removeEntityByNamespace(oid, null, namespace);
/*     */   }
/*     */ 
/*     */   private static boolean removeEntityByNamespace(OID oid, Entity entity, Namespace namespace)
/*     */   {
/*  84 */     synchronized (entitiesByNamespace) {
/*  85 */       Map namespaceEntities = (Map)entitiesByNamespace.get(namespace);
/*  86 */       if (namespaceEntities == null) {
/*  87 */         Log.error("Entity.removeEntityByNamespace: there are no entities for namespace " + namespace + ", entity oid is " + oid);
/*     */ 
/*  89 */         return false;
/*     */       }
/*  91 */       if (oid == null) {
/*  92 */         Log.error("Entity.removeEntityByNamespace: entity " + entity + ", namespace " + namespace + " oid is null");
/*     */ 
/*  94 */         return false;
/*     */       }
/*     */ 
/*  97 */       Entity previousEntity = (Entity)namespaceEntities.get(oid);
/*  98 */       if (previousEntity == null) {
/*  99 */         Log.error("Entity.removeEntityByNamespace: entity " + oid + ", namespace " + namespace + " is not registered");
/*     */ 
/* 101 */         return false;
/*     */       }
/*     */ 
/* 104 */       if ((entity != null) && (previousEntity != entity)) {
/* 105 */         Log.error("Entity.removeEntityByNamespace: entity " + oid + ", namespace " + namespace + " is not the same as the registered entity");
/*     */ 
/* 107 */         return false;
/*     */       }
/*     */ 
/* 110 */       namespaceEntities.remove(oid);
/* 111 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Entity[] getAllEntitiesByNamespace(Namespace namespace)
/*     */   {
/* 123 */     synchronized (entitiesByNamespace) {
/* 124 */       Map namespaceEntities = (Map)entitiesByNamespace.get(namespace);
/* 125 */       if (namespaceEntities == null)
/*     */       {
/* 127 */         return new Entity[0];
/*     */       }
/* 129 */       Entity[] entities = new Entity[namespaceEntities.size()];
/* 130 */       int i = 0;
/* 131 */       for (Entity entity : namespaceEntities.values())
/* 132 */         entities[(i++)] = entity;
/* 133 */       return entities;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getEntityCount()
/*     */   {
/* 139 */     synchronized (entitiesByNamespace) {
/* 140 */       int size = 0;
/* 141 */       for (Map namespaceEntities : entitiesByNamespace.values())
/* 142 */         size += namespaceEntities.size();
/* 143 */       return size;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.EntityManager
 * JD-Core Version:    0.6.0
 */