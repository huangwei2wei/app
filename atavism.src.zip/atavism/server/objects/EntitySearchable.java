/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.Matcher;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.engine.SearchClause;
/*    */ import atavism.server.engine.SearchManager;
/*    */ import atavism.server.engine.SearchSelection;
/*    */ import atavism.server.engine.Searchable;
/*    */ import java.io.Serializable;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class EntitySearchable
/*    */   implements Searchable
/*    */ {
/*    */   private ObjectType objectType;
/*    */ 
/*    */   public EntitySearchable(ObjectType objectType)
/*    */   {
/* 29 */     this.objectType = objectType;
/*    */   }
/*    */ 
/*    */   public Collection runSearch(SearchClause search, SearchSelection selection)
/*    */   {
/* 35 */     Matcher matcher = SearchManager.getMatcher(search, Entity.class);
/* 36 */     if (matcher == null)
/* 37 */       return null;
/* 38 */     List resultList = new LinkedList();
/* 39 */     synchronized (EntityManager.entitiesByNamespace)
/*    */     {
/* 41 */       for (Map namespaceEntities : EntityManager.entitiesByNamespace.values()) {
/* 42 */         for (Map.Entry entry : namespaceEntities.entrySet()) {
/* 43 */           boolean rc = false;
/* 44 */           Entity entity = (Entity)entry.getValue();
/* 45 */           if (entity.getType() != this.objectType)
/*    */             continue;
/* 47 */           entity.lock();
/* 48 */           if (entity.getTransientDataRef() != null)
/* 49 */             rc = matcher.match(entity.getTransientDataRef());
/* 50 */           if (!rc)
/* 51 */             rc = matcher.match(entity.getPropertyMapRef());
/* 52 */           if (rc) {
/* 53 */             selectProperties((OID)entry.getKey(), entity, selection, resultList);
/*    */           }
/*    */ 
/* 56 */           entity.unlock();
/*    */         }
/*    */       }
/*    */     }
/* 60 */     return resultList;
/*    */   }
/*    */ 
/*    */   void selectProperties(OID oid, Entity entity, SearchSelection selection, List<Object> resultList)
/*    */   {
/* 66 */     if (selection.getResultOption() == 2)
/*    */     {
/* 68 */       resultList.add(oid);
/* 69 */       return;
/*    */     }
/*    */     Map result;
/* 73 */     if (selection.getAllProperties()) {
/* 74 */       Map result = new HashMap(entity.getPropertyMapRef());
/* 75 */       if (entity.getTransientDataRef() != null)
/* 76 */         result.putAll(entity.getTransientDataRef());
/*    */     }
/*    */     else {
/* 79 */       result = new HashMap();
/* 80 */       for (String key : selection.getProperties()) {
/* 81 */         Serializable value = entity.getProperty(key);
/* 82 */         if (value != null) {
/* 83 */           result.put(key, value);
/*    */         }
/*    */       }
/*    */     }
/* 87 */     if (selection.getResultOption() == 1)
/* 88 */       resultList.add(new SearchEntry(oid, result));
/* 89 */     else if (result.size() > 0)
/* 90 */       resultList.add(result);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.EntitySearchable
 * JD-Core Version:    0.6.0
 */