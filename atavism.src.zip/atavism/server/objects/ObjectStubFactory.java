/*   */ package atavism.server.objects;
/*   */ 
/*   */ import atavism.server.engine.InterpolatedWorldNode;
/*   */ import atavism.server.engine.OID;
/*   */ 
/*   */ public class ObjectStubFactory
/*   */   implements EntityWithWorldNodeFactory
/*   */ {
/*   */   public EntityWithWorldNode createEntity(OID oid, InterpolatedWorldNode node, int template)
/*   */   {
/* 8 */     return new ObjectStub(oid, node, template);
/*   */   }
/*   */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ObjectStubFactory
 * JD-Core Version:    0.6.0
 */