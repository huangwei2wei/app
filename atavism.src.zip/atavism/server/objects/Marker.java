/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Marker
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   public static final long PROP_POINT = 1L;
/*     */   public static final long PROP_ORIENTATION = 2L;
/*     */   public static final long PROP_PROPERTIES = 4L;
/*     */   public static final long PROP_ALL = 7L;
/* 166 */   public static final ObjectType OBJECT_TYPE = ObjectType.intern(21, "Marker");
/*     */   private Point point;
/*     */   private Quaternion orientation;
/*     */   private Map<String, Serializable> properties;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Marker()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Marker(Point point)
/*     */   {
/*  22 */     setPoint(point);
/*     */   }
/*     */ 
/*     */   public Marker(Point point, Quaternion orient)
/*     */   {
/*  31 */     setPoint(point);
/*  32 */     setOrientation(orient);
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/*  40 */     Marker copy = (Marker)super.clone();
/*  41 */     if (copy.point != null)
/*  42 */       copy.point = ((Point)copy.point.clone());
/*  43 */     if (copy.orientation != null)
/*  44 */       copy.orientation = ((Quaternion)copy.orientation.clone());
/*  45 */     if (copy.properties != null)
/*  46 */       copy.properties = new HashMap(copy.properties);
/*  47 */     return copy;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  52 */     return new StringBuilder().append("[Marker pt=").append(this.point).append(" ori=").append(this.orientation).append(" ").append(this.properties == null ? "0 props" : new StringBuilder().append(this.properties.size()).append(" props]").toString()).toString();
/*     */   }
/*     */ 
/*     */   public Point getPoint()
/*     */   {
/*  59 */     return this.point;
/*     */   }
/*     */ 
/*     */   public void setPoint(Point point)
/*     */   {
/*  65 */     this.point = point;
/*     */   }
/*     */ 
/*     */   public Quaternion getOrientation()
/*     */   {
/*  71 */     return this.orientation;
/*     */   }
/*     */ 
/*     */   public void setOrientation(Quaternion orient)
/*     */   {
/*  77 */     this.orientation = orient;
/*     */   }
/*     */ 
/*     */   public Serializable getProperty(String key)
/*     */   {
/*  87 */     if (this.properties == null)
/*  88 */       return null;
/*  89 */     return (Cloneable)this.properties.get(key);
/*     */   }
/*     */ 
/*     */   public Serializable setProperty(String key, Serializable value)
/*     */   {
/*  99 */     if (this.properties == null)
/* 100 */       this.properties = new HashMap();
/* 101 */     return (Cloneable)this.properties.put(key, value);
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getPropertyMapRef()
/*     */   {
/* 109 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public void setProperties(Map<String, Serializable> props)
/*     */   {
/* 115 */     if (props != null)
/* 116 */       this.properties = new HashMap(props);
/*     */     else
/* 118 */       this.properties = null;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Marker
 * JD-Core Version:    0.6.0
 */