/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.events.ExtensionMessageEvent;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.plugins.InstanceClient;
/*     */ import atavism.server.plugins.ProxyPlugin;
/*     */ import atavism.server.plugins.WorldManagerClient;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class InstanceEntryProxyHook
/*     */   implements ProxyExtensionHook
/*     */ {
/*     */   public void processExtensionEvent(ExtensionMessageEvent event, Player player, ProxyPlugin proxy)
/*     */   {
/*  20 */     Map props = event.getPropertyMap();
/*  21 */     int flags = 0;
/*  22 */     OID instanceOid = null;
/*     */ 
/*  24 */     if (Log.loggingDebug) {
/*  25 */       String propStr = "";
/*  26 */       for (Map.Entry entry : props.entrySet()) {
/*  27 */         propStr = propStr + (String)entry.getKey() + "=" + entry.getValue() + " ";
/*     */       }
/*  29 */       Log.debug("processInstanceEntryEvent: " + propStr);
/*     */     }
/*     */ 
/*  32 */     String flagStr = (String)props.get("flags");
/*  33 */     if (flagStr != null) {
/*  34 */       if (flagStr.equals("push"))
/*  35 */         flags |= 1;
/*  36 */       else if (flagStr.equals("pop")) {
/*  37 */         flags |= 2;
/*     */       }
/*     */     }
/*  40 */     if ((flags & 0x2) != 0)
/*     */     {
/*  42 */       InstanceClient.objectInstanceEntry(player.getOid(), null, flags);
/*     */ 
/*  44 */       return;
/*     */     }
/*     */ 
/*  47 */     String instanceName = (String)props.get("instanceName");
/*  48 */     if (instanceName == null) {
/*  49 */       instanceOid = (OID)props.get("instanceOid");
/*  50 */       if (instanceOid == null) {
/*  51 */         Log.error("Instance entry event: missing instanceName and instanceOid");
/*  52 */         return;
/*     */       }
/*     */     }
/*     */     else {
/*  56 */       instanceOid = InstanceClient.getInstanceOid(instanceName);
/*  57 */       if (instanceOid == null) {
/*  58 */         Log.error("Instance entry event: unknown instanceName=" + instanceName);
/*     */ 
/*  60 */         return;
/*     */       }
/*     */     }
/*     */ 
/*  64 */     Marker marker = null;
/*  65 */     String markerName = (String)props.get("locMarker");
/*  66 */     if (markerName == null) {
/*  67 */       marker = new Marker();
/*  68 */       marker.setPoint((Point)props.get("locPoint"));
/*  69 */       if (marker.getPoint() == null) {
/*  70 */         Log.error("Instance entry event: missing locMarker and locPoint");
/*  71 */         return;
/*     */       }
/*     */     }
/*     */     else {
/*  75 */       marker = InstanceClient.getMarker(instanceOid, markerName);
/*  76 */       if (marker == null) {
/*  77 */         Log.error("Instance entry event: unknown marker=" + markerName);
/*     */ 
/*  79 */         return;
/*     */       }
/*     */     }
/*     */ 
/*  83 */     Quaternion orient = (Quaternion)props.get("orientation");
/*  84 */     if ((orient != null) && (marker != null)) {
/*  85 */       marker.setOrientation(orient);
/*     */     }
/*  87 */     Marker restoreMarker = null;
/*  88 */     OID currentInstanceOid = null;
/*  89 */     if ((flags & 0x1) != 0) {
/*  90 */       String restoreMarkerName = (String)props.get("restoreMarker");
/*  91 */       if (restoreMarkerName == null) {
/*  92 */         restoreMarker = new Marker();
/*  93 */         restoreMarker.setPoint((Point)props.get("restorePoint"));
/*  94 */         if (restoreMarker.getPoint() == null) {
/*  95 */           restoreMarker = null;
/*     */         } else {
/*  97 */           BasicWorldNode currentLoc = WorldManagerClient.getWorldNode(player.getOid());
/*     */ 
/*  99 */           currentInstanceOid = currentLoc.getInstanceOid();
/*     */         }
/*     */       }
/*     */       else {
/* 103 */         BasicWorldNode currentLoc = WorldManagerClient.getWorldNode(player.getOid());
/*     */ 
/* 105 */         currentInstanceOid = currentLoc.getInstanceOid();
/* 106 */         restoreMarker = InstanceClient.getMarker(currentInstanceOid, restoreMarkerName);
/*     */ 
/* 108 */         if (restoreMarker == null) {
/* 109 */           Log.error("Instance entry event: unknown restore marker=" + restoreMarkerName);
/*     */ 
/* 111 */           return;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/* 116 */     else if ((props.get("restoreMarker") != null) || (props.get("restorePoint") != null))
/*     */     {
/* 118 */       Log.warn("processInstanceEntryEvent: ignoring restore marker because flag push is not set");
/*     */     }
/*     */ 
/* 121 */     Quaternion restoreOrient = (Quaternion)props.get("restoreOrientation");
/* 122 */     if ((restoreOrient != null) && (restoreMarker != null)) {
/* 123 */       restoreMarker.setOrientation(restoreOrient);
/*     */     }
/* 125 */     BasicWorldNode wnode = null;
/* 126 */     if (marker != null) {
/* 127 */       wnode = new BasicWorldNode();
/* 128 */       wnode.setInstanceOid(instanceOid);
/* 129 */       wnode.setLoc(marker.getPoint());
/* 130 */       wnode.setDir(new AOVector(0.0F, 0.0F, 0.0F));
/* 131 */       if (marker.getOrientation() != null) {
/* 132 */         wnode.setOrientation(marker.getOrientation());
/*     */       }
/*     */     }
/* 135 */     BasicWorldNode restoreWnode = null;
/* 136 */     if (restoreMarker != null) {
/* 137 */       restoreWnode = new BasicWorldNode();
/* 138 */       restoreWnode.setInstanceOid(currentInstanceOid);
/* 139 */       restoreWnode.setLoc(restoreMarker.getPoint());
/* 140 */       restoreWnode.setDir(new AOVector(0.0F, 0.0F, 0.0F));
/* 141 */       if (restoreMarker.getOrientation() != null) {
/* 142 */         restoreWnode.setOrientation(restoreMarker.getOrientation());
/*     */       }
/*     */     }
/* 145 */     InstanceClient.objectInstanceEntry(player.getOid(), wnode, flags, restoreWnode);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.InstanceEntryProxyHook
 * JD-Core Version:    0.6.0
 */