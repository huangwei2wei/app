/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.InterpolatedWorldNode;
/*     */ import atavism.server.engine.InterpolatedWorldNode.InterpolatedDirLocOrientTime;
/*     */ import atavism.server.engine.MobilePerceiver;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.engine.WMWorldNode;
/*     */ import atavism.server.engine.WorldNode;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class AOObject extends Entity
/*     */ {
/*     */   public static final String stateMapKey = "aoobj.statemap";
/*     */   public static final String wnodeKey = "aoobj.wnode";
/*     */   public static final String perceiverKey = "aoobj.perceiver";
/*     */   public static final String aoidKey = "aoobj.aoid";
/*     */   public static final String dcKey = "aoobj.dc";
/* 315 */   private String scaleKey = "aoobj.scale";
/*     */ 
/* 362 */   private String permCBKey = "aoobj.permCB";
/*     */ 
/* 365 */   private static AOObjectCreateHook createHook = null;
/*     */ 
/* 427 */   public static Lock transferLock = LockFactory.makeLock("objXferLock");
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public AOObject()
/*     */   {
/*  19 */     setNamespace(Namespace.WORLD_MANAGER);
/*  20 */     init();
/*     */   }
/*     */ 
/*     */   public AOObject(String name) {
/*  24 */     super(name);
/*  25 */     setNamespace(Namespace.WORLD_MANAGER);
/*  26 */     init();
/*     */   }
/*     */ 
/*     */   public AOObject(OID oid) {
/*  30 */     super(oid);
/*  31 */     setNamespace(Namespace.WORLD_MANAGER);
/*  32 */     init();
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/*  37 */     AOObjectCreateHook hook = getObjCreateHook();
/*  38 */     if (hook != null)
/*  39 */       hook.objectCreateHook(this);
/*     */   }
/*     */ 
/*     */   public OID getMasterOid()
/*     */   {
/*  50 */     return getOid();
/*     */   }
/*     */ 
/*     */   public boolean isMob() {
/*  54 */     return getType().isMob();
/*     */   }
/*     */ 
/*     */   public boolean isItem() {
/*  58 */     return getType() == ObjectTypes.item;
/*     */   }
/*     */ 
/*     */   public boolean isLight() {
/*  62 */     return getType() == ObjectTypes.light;
/*     */   }
/*     */ 
/*     */   public boolean isUser() {
/*  66 */     return getType().isPlayer();
/*     */   }
/*     */ 
/*     */   public boolean isStructure() {
/*  70 */     return getType().isStructure();
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  74 */     return "[AOObject: " + getName() + ":" + getOid() + ", type=" + getType() + "]";
/*     */   }
/*     */ 
/*     */   public ObjState setState(String state, ObjState obj)
/*     */   {
/*  82 */     this.lock.lock();
/*     */     try {
/*  84 */       StateMap stateMap = getStateMap();
/*  85 */       ObjState localObjState = stateMap.setState(state, obj);
/*     */       return localObjState; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public ObjState getState(String s)
/*     */   {
/*  92 */     this.lock.lock();
/*     */     try {
/*  94 */       StateMap stateMap = getStateMap();
/*  95 */       ObjState localObjState = stateMap.getState(s);
/*     */       return localObjState; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   private StateMap getStateMap()
/*     */   {
/* 106 */     this.lock.lock();
/*     */     try {
/* 108 */       StateMap stateMap = (StateMap)getProperty("aoobj.statemap");
/* 109 */       if (stateMap == null) {
/* 110 */         stateMap = new StateMap();
/* 111 */         setProperty("aoobj.statemap", stateMap);
/*     */       }
/* 113 */       StateMap localStateMap1 = stateMap;
/*     */       return localStateMap1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void sendEvent(Event event)
/*     */   {
/* 178 */     throw new AORuntimeException("legacy code");
/*     */   }
/*     */ 
/*     */   public WorldNode worldNode()
/*     */   {
/* 185 */     return (WorldNode)getProperty("aoobj.wnode");
/*     */   }
/*     */ 
/*     */   public void worldNode(WorldNode worldNode)
/*     */   {
/* 195 */     setProperty("aoobj.wnode", worldNode);
/*     */   }
/*     */ 
/*     */   public BasicWorldNode baseWorldNode()
/*     */   {
/* 203 */     return new BasicWorldNode((InterpolatedWorldNode)getProperty("aoobj.wnode"));
/*     */   }
/*     */ 
/*     */   public Point getLoc()
/*     */   {
/* 213 */     WorldNode node = worldNode();
/* 214 */     return node == null ? null : node.getLoc();
/*     */   }
/*     */ 
/*     */   public Point getCurrentLoc() {
/* 218 */     WorldNode node = worldNode();
/* 219 */     return node == null ? null : node.getCurrentLoc();
/*     */   }
/*     */ 
/*     */   public Quaternion getOrientation() {
/* 223 */     WorldNode node = worldNode();
/* 224 */     return node == null ? null : node.getOrientation();
/*     */   }
/*     */ 
/*     */   public AOVector getDirection() {
/* 228 */     InterpolatedWorldNode iwn = (InterpolatedWorldNode)getProperty("aoobj.wnode");
/* 229 */     return iwn.getDir();
/*     */   }
/*     */ 
/*     */   public InterpolatedWorldNode.InterpolatedDirLocOrientTime getDirLocOrientTime()
/*     */   {
/* 237 */     InterpolatedWorldNode iwn = (InterpolatedWorldNode)getProperty("aoobj.wnode");
/* 238 */     return iwn.getDirLocOrientTime();
/*     */   }
/*     */ 
/*     */   public MobilePerceiver<WMWorldNode> perceiver()
/*     */   {
/* 251 */     this.lock.lock();
/*     */     try {
/* 253 */       MobilePerceiver localMobilePerceiver = (MobilePerceiver)getProperty("aoobj.perceiver");
/*     */       return localMobilePerceiver; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void perceiver(MobilePerceiver<WMWorldNode> p)
/*     */   {
/* 260 */     this.lock.lock();
/*     */     try {
/* 262 */       MobilePerceiver perceiver = perceiver();
/* 263 */       if (perceiver == p) {
/* 264 */         Log.warn("AOObject.setPerceiver: new/cur perceiver same");
/*     */       }
/* 266 */       if (perceiver != null) {
/* 267 */         perceiver.setElement(null);
/* 268 */         Log.warn("AOObject.setPerceiver: perceiv is already not null");
/*     */       }
/* 270 */       if (Log.loggingDebug) {
/* 271 */         Log.debug("AOObject.setPerceiver: obj oid=" + getOid() + ", perceiver=" + p);
/*     */       }
/* 273 */       setProperty("aoobj.perceiver", p);
/* 274 */       if (p != null)
/* 275 */         p.setElement((WMWorldNode)worldNode());
/*     */     }
/*     */     finally {
/* 278 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public OID atavismID()
/*     */   {
/* 289 */     return (OID)getProperty("aoobj.aoid");
/*     */   }
/*     */ 
/*     */   public void atavismID(OID id)
/*     */   {
/* 296 */     setProperty("aoobj.aoid", id);
/*     */   }
/*     */ 
/*     */   public void displayContext(DisplayContext dc)
/*     */   {
/* 302 */     DisplayContext dcCopy = null;
/* 303 */     if (dc != null) {
/* 304 */       dcCopy = (DisplayContext)dc.clone();
/* 305 */       dcCopy.setObjRef(getOid());
/*     */     }
/* 307 */     setProperty("aoobj.dc", dcCopy);
/*     */   }
/*     */ 
/*     */   public DisplayContext displayContext() {
/* 311 */     DisplayContext dc = (DisplayContext)getProperty("aoobj.dc");
/* 312 */     return dc;
/*     */   }
/*     */ 
/*     */   public void scale(float scale)
/*     */   {
/* 318 */     scale(new AOVector(scale, scale, scale));
/*     */   }
/*     */ 
/*     */   public void scale(AOVector scale)
/*     */   {
/* 325 */     setProperty(this.scaleKey, (AOVector)scale.clone());
/*     */   }
/*     */ 
/*     */   public AOVector scale() {
/* 329 */     return (AOVector)getProperty(this.scaleKey);
/*     */   }
/*     */ 
/*     */   public static void registerObjCreateHook(AOObjectCreateHook hook)
/*     */   {
/* 335 */     createHook = hook;
/*     */   }
/*     */ 
/*     */   public static AOObjectCreateHook getObjCreateHook() {
/* 339 */     return createHook;
/*     */   }
/*     */ 
/*     */   public void permissionCallback(PermissionCallback cb)
/*     */   {
/* 355 */     setProperty(this.permCBKey, cb);
/*     */   }
/*     */ 
/*     */   public PermissionCallback permissionCallback() {
/* 359 */     return (PermissionCallback)getProperty(this.permCBKey);
/*     */   }
/*     */ 
/*     */   public static void writeObject(ObjectOutput out, Object obj)
/*     */     throws IOException
/*     */   {
/* 374 */     out.writeBoolean(obj == null);
/* 375 */     if (obj != null)
/* 376 */       out.writeObject(obj);
/*     */   }
/*     */ 
/*     */   public static Object readObject(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 382 */     boolean isNull = in.readBoolean();
/* 383 */     if (!isNull) {
/* 384 */       return in.readObject();
/*     */     }
/* 386 */     return null;
/*     */   }
/*     */ 
/*     */   public static void writeString(ObjectOutput out, String string)
/*     */     throws IOException
/*     */   {
/* 395 */     if (string == null)
/* 396 */       out.writeUTF("");
/*     */     else
/* 398 */       out.writeUTF(string);
/*     */   }
/*     */ 
/*     */   public static Collection<AOObject> getAllObjects()
/*     */   {
/* 406 */     Entity[] entities = EntityManager.getAllEntitiesByNamespace(Namespace.WORLD_MANAGER);
/* 407 */     Set objSet = new HashSet();
/* 408 */     for (Entity e : entities) {
/* 409 */       if ((e instanceof AOObject)) {
/* 410 */         objSet.add((AOObject)e);
/*     */       }
/*     */     }
/* 413 */     return objSet;
/*     */   }
/*     */ 
/*     */   public static AOObject getObject(OID oid) {
/* 417 */     return (AOObject)EntityManager.getEntityByNamespace(oid, Namespace.WORLD_MANAGER);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 431 */       BeanInfo info = Introspector.getBeanInfo(AOObject.class);
/* 432 */       PropertyDescriptor[] propertyDescriptors = info.getPropertyDescriptors();
/*     */ 
/* 434 */       for (int i = 0; i < propertyDescriptors.length; i++);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 441 */       Log.error("failed aoobject beans initalization");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class StateMap
/*     */     implements Serializable
/*     */   {
/* 171 */     Lock lock = null;
/* 172 */     Map<String, ObjState> map = new HashMap();
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public StateMap()
/*     */     {
/* 120 */       setupTransient();
/*     */     }
/*     */ 
/*     */     private void setupTransient() {
/* 124 */       this.lock = LockFactory.makeLock("StateMapLock");
/*     */     }
/*     */ 
/*     */     private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */     {
/* 129 */       in.defaultReadObject();
/* 130 */       setupTransient();
/*     */     }
/*     */ 
/*     */     public ObjState setState(String state, ObjState objState) {
/* 134 */       this.lock.lock();
/*     */       try {
/* 136 */         ObjState localObjState = (ObjState)this.map.put(state, objState);
/*     */         return localObjState; } finally { this.lock.unlock(); } throw localObject;
/*     */     }
/*     */ 
/*     */     public ObjState getState(String state) {
/* 143 */       this.lock.lock();
/*     */       try {
/* 145 */         ObjState localObjState = (ObjState)this.map.get(state);
/*     */         return localObjState; } finally { this.lock.unlock(); } throw localObject;
/*     */     }
/*     */ 
/*     */     public void setMap(Map<String, ObjState> map)
/*     */     {
/* 154 */       this.lock.lock();
/*     */       try {
/* 156 */         this.map = new HashMap(map);
/*     */       }
/*     */       finally {
/* 159 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public Map<String, ObjState> getMap() {
/* 163 */       this.lock.lock();
/*     */       try {
/* 165 */         HashMap localHashMap = new HashMap(this.map);
/*     */         return localHashMap; } finally { this.lock.unlock(); } throw localObject;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.AOObject
 * JD-Core Version:    0.6.0
 */