/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.events.AuthorizedLoginEvent;
/*     */ import atavism.server.events.DirLocOrientEvent;
/*     */ import atavism.server.messages.PerceptionMessage.ObjectNote;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.SquareQueue;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class PlayerManager
/*     */ {
/* 418 */   private Map<OID, Player> players = new HashMap();
/*     */ 
/* 420 */   private Map<ClientConnection, Player> conMap = new HashMap();
/*     */ 
/* 423 */   private Map<OID, List<Perceiver>> perception = new HashMap();
/*     */ 
/* 425 */   private int peakPlayerCount = 0;
/* 426 */   private int loginCount = 0;
/* 427 */   private int logoutCount = 0;
/*     */ 
/*     */   public synchronized boolean addPlayer(Player player)
/*     */   {
/*  27 */     if (this.players.containsKey(player.getOid()))
/*  28 */       return false;
/*  29 */     this.players.put(player.getOid(), player);
/*  30 */     this.conMap.put(player.getConnection(), player);
/*  31 */     if (this.players.size() > this.peakPlayerCount)
/*  32 */       this.peakPlayerCount = this.players.size();
/*  33 */     return true;
/*     */   }
/*     */ 
/*     */   public synchronized Player getPlayer(OID playerOid)
/*     */   {
/*  38 */     return (Player)this.players.get(playerOid);
/*     */   }
/*     */ 
/*     */   public synchronized Player getPlayer(ClientConnection conn)
/*     */   {
/*  43 */     return (Player)this.conMap.get(conn);
/*     */   }
/*     */ 
/*     */   public synchronized Player removePlayer(OID playerOid)
/*     */   {
/*  48 */     Player player = (Player)this.players.remove(playerOid);
/*  49 */     if (player == null) {
/*  50 */       return null;
/*     */     }
/*  52 */     this.conMap.remove(player.getConnection());
/*     */ 
/*  55 */     Iterator iterator = this.perception.entrySet().iterator();
/*  56 */     while (iterator.hasNext()) {
/*  57 */       Map.Entry entry = (Map.Entry)iterator.next();
/*  58 */       ((List)entry.getValue()).remove(new Perceiver(player));
/*  59 */       if (((List)entry.getValue()).size() == 0)
/*  60 */         iterator.remove();
/*     */     }
/*  62 */     Log.debug("removePlayer: playerOid=" + playerOid + " perception size=" + this.perception.size());
/*     */ 
/*  65 */     return player;
/*     */   }
/*     */ 
/*     */   public synchronized int getPlayerCount()
/*     */   {
/*  70 */     return this.players.size();
/*     */   }
/*     */ 
/*     */   public int getPeakPlayerCount()
/*     */   {
/*  75 */     return this.peakPlayerCount;
/*     */   }
/*     */ 
/*     */   public int getLoginCount()
/*     */   {
/*  80 */     return this.loginCount;
/*     */   }
/*     */ 
/*     */   public int getLogoutCount()
/*     */   {
/*  85 */     return this.logoutCount;
/*     */   }
/*     */ 
/*     */   public synchronized int getLoginSeconds()
/*     */   {
/*  90 */     int seconds = 0;
/*  91 */     long now = System.currentTimeMillis();
/*  92 */     for (Player player : this.players.values()) {
/*  93 */       if (player.getStatus() == 2)
/*  94 */         seconds = (int)(seconds + (now - player.getLoginTime()) / 1000L);
/*     */     }
/*  96 */     return seconds;
/*     */   }
/*     */ 
/*     */   public synchronized void getPlayers(Collection<Player> pp)
/*     */   {
/* 101 */     pp.addAll(this.players.values());
/*     */   }
/*     */ 
/*     */   public synchronized void addWorldPerception(Player player, Collection<PerceptionMessage.ObjectNote> objectNotes, List<OID> newSubjects)
/*     */   {
/* 115 */     Log.debug("PERCEP: adding world perceptions for player " + player.getName());
/* 116 */     for (PerceptionMessage.ObjectNote objectNote : objectNotes) {
/* 117 */       List perceivers = (List)this.perception.get(objectNote.getSubject());
/* 118 */       if (perceivers == null)
/*     */       {
/* 120 */         perceivers = new LinkedList();
/* 121 */         perceivers.add(new Perceiver(player));
/* 122 */         this.perception.put(objectNote.getSubject(), perceivers);
/* 123 */         Log.debug("PERCEP: added player to the list of players that can perceive: " + objectNote.getSubject());
/* 124 */         newSubjects.add(objectNote.getSubject());
/* 125 */         continue;
/*     */       }
/* 127 */       boolean newPerceiver = true;
/* 128 */       for (Perceiver perceiver : perceivers) {
/* 129 */         if (perceiver.player == player) {
/* 130 */           Log.debug("PERCEP: got an existing perceiver of this object for this player");
/* 131 */           if (perceiver.world) {
/* 132 */             Log.error("addWorldPerception: playerOid=" + player.getOid() + " already perceives oid=" + objectNote.getSubject());
/*     */           }
/*     */           else
/*     */           {
/* 139 */             perceiver.world = true;
/*     */           }
/* 141 */           newPerceiver = false;
/* 142 */           break;
/*     */         }
/*     */       }
/* 145 */       if (newPerceiver) {
/* 146 */         perceivers.add(new Perceiver(player));
/* 147 */         newSubjects.add(objectNote.getSubject());
/* 148 */         Log.debug("PERCEP: added player to the list of players that can perceive: " + objectNote.getSubject());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void removeWorldPerception(Player player, Collection<PerceptionMessage.ObjectNote> objectNotes, List<OID> deleteSubjects)
/*     */   {
/* 164 */     Log.debug("PERCEP: removing world perception of player " + player.getName());
/* 165 */     for (PerceptionMessage.ObjectNote objectNote : objectNotes) {
/* 166 */       List perceivers = (List)this.perception.get(objectNote.getSubject());
/* 167 */       if (perceivers == null) {
/* 168 */         Log.error("removePerception: playerOid=" + player.getOid() + " duplicate lost oid=" + objectNote.getSubject());
/*     */ 
/* 171 */         continue;
/*     */       }
/* 173 */       Iterator iterator = perceivers.iterator();
/* 174 */       while (iterator.hasNext()) {
/* 175 */         Perceiver perceiver = (Perceiver)iterator.next();
/* 176 */         if (perceiver.player != player)
/*     */           continue;
/* 178 */         if (!perceiver.world) {
/* 179 */           Log.error("removeWorldPerception: playerOid=" + player.getOid() + " does not perceive oid=" + objectNote.getSubject());
/*     */         }
/*     */         else
/*     */         {
/* 183 */           perceiver.world = false;
/* 184 */           if (perceiver.staticCount != 0) break;
/* 185 */           iterator.remove();
/* 186 */           deleteSubjects.add(objectNote.getSubject());
/* 187 */           Log.debug("PERCEP: player is no longer perceived by: " + objectNote.getSubject());
/* 188 */           if (perceivers.size() != 0) break;
/* 189 */           this.perception.remove(objectNote.getSubject());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized boolean addStaticPerception(Player player, OID subjectOid)
/*     */   {
/* 236 */     Log.debug("PERCEP: adding static perception of " + subjectOid + " to player " + player.getName());
/* 237 */     List perceivers = (List)this.perception.get(subjectOid);
/* 238 */     if (perceivers == null) {
/* 239 */       perceivers = new LinkedList();
/* 240 */       this.perception.put(subjectOid, perceivers);
/* 241 */       perceivers.add(new Perceiver(player, 1));
/* 242 */       return true;
/*     */     }
/*     */ 
/* 245 */     for (Perceiver perceiver : perceivers) {
/* 246 */       if (perceiver.player == player)
/*     */       {
/*     */         Perceiver tmp131_129 = perceiver; tmp131_129.staticCount = (short)(tmp131_129.staticCount + 1);
/* 248 */         return (tmp131_129.staticCount == 1) && (!tmp131_129.world);
/*     */       }
/*     */     }
/* 251 */     perceivers.add(new Perceiver(player, 1));
/* 252 */     return true;
/*     */   }
/*     */ 
/*     */   public synchronized boolean removeStaticPerception(Player player, OID playerOid)
/*     */   {
/* 264 */     Log.debug("PERCEP: removing static perception of " + playerOid + " from player " + player.getName());
/* 265 */     List perceivers = (List)this.perception.get(playerOid);
/* 266 */     if (perceivers == null) {
/* 267 */       Log.error("removeStaticPerception: playerOid=" + player.getOid() + " no perceivers for oid=" + playerOid);
/*     */ 
/* 269 */       return false;
/*     */     }
/* 271 */     Iterator iterator = perceivers.iterator();
/* 272 */     while (iterator.hasNext()) {
/* 273 */       Perceiver perceiver = (Perceiver)iterator.next();
/* 274 */       if (perceiver.player == player)
/*     */       {
/*     */         Perceiver tmp129_127 = perceiver; tmp129_127.staticCount = (short)(tmp129_127.staticCount - 1);
/* 276 */         if ((perceiver.staticCount == 0) && (!perceiver.world)) {
/* 277 */           iterator.remove();
/* 278 */           if (perceivers.size() == 0) {
/* 279 */             this.perception.remove(playerOid);
/*     */ 
/* 281 */             return true;
/*     */           }
/*     */         }
/* 284 */         return false;
/*     */       }
/*     */     }
/* 287 */     Log.error("removeStaticPerception: playerOid=" + player.getOid() + " does not perceive oid=" + playerOid);
/*     */ 
/* 289 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized List<Player> getPerceivers(OID subjectOid)
/*     */   {
/* 301 */     List perceivers = (List)this.perception.get(subjectOid);
/* 302 */     if (perceivers == null)
/* 303 */       return null;
/* 304 */     ArrayList players = new ArrayList(perceivers.size());
/* 305 */     for (Perceiver perceiver : perceivers) {
/* 306 */       players.add(perceiver.player);
/*     */     }
/* 308 */     return players;
/*     */   }
/*     */ 
/*     */   public void processEvent(Player player, Event event, SquareQueue<Player, Event> eventQQ)
/*     */   {
/* 314 */     long now = System.currentTimeMillis();
/* 315 */     event.setEnqueueTime(now);
/* 316 */     synchronized (this) {
/* 317 */       if (Log.loggingDebug) {
/* 318 */         Log.debug("processEvent player " + player + " " + event.getClass().getName());
/*     */       }
/*     */ 
/* 322 */       if (player == null) {
/* 323 */         Log.debug("PlayerManager.processEvent(): player is null");
/* 324 */         if (!(event instanceof AuthorizedLoginEvent)) {
/* 325 */           Log.warn("PlayerManager.processEvent(): event is not an instance of AuthorizedLoginEvent");
/* 326 */           return;
/*     */         }
/*     */       } else {
/* 329 */         if (player.getStatus() == 1) {
/* 330 */           if (player.getDeferredEvents() == null) {
/* 331 */             player.setDeferredEvents(new LinkedList());
/*     */           }
/* 333 */           Log.info("PlayerManager.processEvent(): Defering event=" + event + " because player.getStatus() is STATUS_LOGIN_PENDING");
/* 334 */           player.getDeferredEvents().add(event);
/* 335 */           return;
/*     */         }
/* 337 */         if (player.getStatus() == 3) {
/* 338 */           Log.warn("PlayerManager.processEvent(): Ignoring event=" + event + " because player.getStatus() is STATUS_LOGOUT");
/*     */ 
/* 340 */           return;
/*     */         }
/* 342 */         if ((event instanceof DirLocOrientEvent)) {
/* 343 */           DirLocOrientEvent dloEvent = (DirLocOrientEvent)event;
/* 344 */           BasicWorldNode wnode = new BasicWorldNode(null, dloEvent.getDir(), dloEvent.getLoc(), dloEvent.getQuaternion());
/*     */ 
/* 347 */           Log.debug("DLO " + wnode);
/* 348 */           if (!player.lastLocUpdate.equals(wnode)) {
/* 349 */             player.setLastActivityTime(now);
/* 350 */             player.lastLocUpdate = wnode;
/*     */           }
/*     */           else {
/* 353 */             player.setLastContactTime(now);
/*     */           }
/*     */         }
/*     */         else {
/* 357 */           player.setLastActivityTime(now);
/*     */         }
/*     */       }
/*     */     }
/* 360 */     eventQQ.insert(player, event);
/*     */   }
/*     */ 
/*     */   public synchronized void loginComplete(Player player, SquareQueue<Player, Event> eventQQ)
/*     */   {
/* 365 */     if (player.getStatus() == 3) {
/* 366 */       Log.error("PlayerManager.loginComplete: Aborting... player.getStatus() is STATUS_LOGOUT");
/* 367 */       return;
/*     */     }
/* 369 */     player.setStatus(2);
/* 370 */     player.setLoginTime(System.currentTimeMillis());
/* 371 */     player.setLastActivityTime(player.getLoginTime());
/* 372 */     if (player.getDeferredEvents() != null) {
/* 373 */       for (Event event : player.getDeferredEvents()) {
/* 374 */         eventQQ.insert(player, event);
/*     */       }
/* 376 */       player.setDeferredEvents(null);
/*     */     }
/* 378 */     this.loginCount += 1;
/*     */   }
/*     */ 
/*     */   public synchronized boolean logout(Player player)
/*     */   {
/* 383 */     Player existingPlayer = (Player)this.players.get(player.getOid());
/* 384 */     if (existingPlayer == null) {
/* 385 */       Log.error("PlayerManager.logout: player not found: player=" + player);
/* 386 */       return false;
/*     */     }
/*     */ 
/* 389 */     if (existingPlayer != player) {
/* 390 */       Log.error("PlayerManager.logout: player instance mis-match");
/* 391 */       return false;
/*     */     }
/*     */ 
/* 394 */     if (player.getStatus() == 3) {
/* 395 */       return false;
/*     */     }
/*     */ 
/* 398 */     player.setStatus(3);
/* 399 */     this.logoutCount += 1;
/*     */ 
/* 401 */     return true;
/*     */   }
/*     */ 
/*     */   public synchronized List<Player> getTimedoutPlayers(long activityTimeoutMS, long contactTimeoutMS)
/*     */   {
/* 407 */     long now = System.currentTimeMillis();
/* 408 */     List timedout = new ArrayList(10);
/* 409 */     for (Player player : this.players.values())
/* 410 */       if ((player.getStatus() == 2) && ((now - player.getLastContactTime() > contactTimeoutMS) || (now - player.getLastActivityTime() > activityTimeoutMS)))
/*     */       {
/* 413 */         timedout.add(player);
/*     */       }
/* 415 */     return timedout;
/*     */   }
/*     */ 
/*     */   private static class Perceiver
/*     */   {
/*     */     public Player player;
/*     */     public short staticCount;
/*     */     public boolean world;
/*     */ 
/*     */     public Perceiver(Player player)
/*     */     {
/* 205 */       this.player = player;
/* 206 */       this.staticCount = 0;
/* 207 */       this.world = true;
/*     */     }
/*     */ 
/*     */     public Perceiver(Player player, int initialCount)
/*     */     {
/* 212 */       this.player = player;
/* 213 */       this.staticCount = (short)initialCount;
/* 214 */       this.world = false;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 219 */       return this.player.getOid().compareTo(((Perceiver)other).player.getOid()) == 0;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 223 */       return this.player.getOid().hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.PlayerManager
 * JD-Core Version:    0.6.0
 */