package atavism.server.objects;

public abstract interface PermissionFactory
{
  public abstract PermissionCallback createPermission(AOObject paramAOObject);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.PermissionFactory
 * JD-Core Version:    0.6.0
 */