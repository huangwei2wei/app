/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.marshalling.Marshallable;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.util.Log;
/*     */ import java.beans.DefaultPersistenceDelegate;
/*     */ import java.beans.Encoder;
/*     */ import java.beans.Expression;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ObjectType
/*     */   implements Serializable, Marshallable
/*     */ {
/*     */   public static final int BASE_STRUCTURE = 1;
/*     */   public static final int BASE_MOB = 2;
/*     */   public static final int BASE_PLAYER = 4;
/*     */   transient short typeId;
/*     */   transient String typeName;
/*     */   transient int baseType;
/* 166 */   static Map<String, ObjectType> internedTypes = new HashMap();
/*     */ 
/* 168 */   static Map<Short, ObjectType> internedTypeIds = new HashMap();
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public ObjectType()
/*     */   {
/*     */   }
/*     */ 
/*     */   ObjectType(short type, String typeName, int baseType)
/*     */   {
/*  49 */     this.typeId = type;
/*  50 */     this.typeName = typeName;
/*  51 */     this.baseType = baseType;
/*     */   }
/*     */ 
/*     */   public static ObjectType intern(short typeId, String typeName)
/*     */   {
/*  61 */     return intern(typeId, typeName, 0);
/*     */   }
/*     */ 
/*     */   public static ObjectType intern(short typeId, String typeName, int baseType)
/*     */   {
/*  74 */     ObjectType objectType = (ObjectType)internedTypes.get(typeName);
/*  75 */     if (objectType == null) {
/*  76 */       objectType = new ObjectType(typeId, typeName, baseType);
/*  77 */       internedTypes.put(typeName, objectType);
/*  78 */       internedTypeIds.put(Short.valueOf(typeId), objectType);
/*     */     }
/*  80 */     else if (objectType.getTypeId() != typeId) {
/*  81 */       Log.error("ObjectType.intern: typeId mismatch for \"" + typeName + "\": existing=" + objectType.getTypeId() + " new=" + typeId);
/*     */     }
/*     */ 
/*  84 */     return objectType;
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectType(short typeId)
/*     */   {
/*  93 */     return (ObjectType)internedTypeIds.get(Short.valueOf(typeId));
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectType(String typeName)
/*     */   {
/* 102 */     return (ObjectType)internedTypes.get(typeName);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 106 */     return "[" + this.typeName + "," + this.typeId + "]";
/*     */   }
/*     */ 
/*     */   public short getTypeId()
/*     */   {
/* 111 */     return this.typeId;
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/* 116 */     return this.typeName;
/*     */   }
/*     */ 
/*     */   public boolean isStructure()
/*     */   {
/* 121 */     return (this.baseType & 0x1) > 0;
/*     */   }
/*     */ 
/*     */   public boolean isA(ObjectType objectType)
/*     */   {
/* 126 */     if (this.typeId == objectType.typeId)
/* 127 */       return true;
/* 128 */     return (this.baseType & objectType.baseType) > 0;
/*     */   }
/*     */ 
/*     */   public boolean isMob()
/*     */   {
/* 133 */     return (this.baseType & 0x2) > 0;
/*     */   }
/*     */ 
/*     */   public boolean isPlayer()
/*     */   {
/* 138 */     return (this.baseType & 0x4) > 0;
/*     */   }
/*     */ 
/*     */   public int getBaseType()
/*     */   {
/* 143 */     return this.baseType;
/*     */   }
/*     */ 
/*     */   public void marshalObject(AOByteBuffer buf)
/*     */   {
/* 148 */     buf.putShort(this.typeId);
/*     */   }
/*     */ 
/*     */   public Object unmarshalObject(AOByteBuffer buf)
/*     */   {
/* 153 */     this.typeId = buf.getShort();
/* 154 */     ObjectType type = getObjectType(this.typeId);
/* 155 */     if (type == null) {
/* 156 */       Log.info("ObjectType.unmarshalObject: no interned ObjectType for typeId=" + this.typeId);
/* 157 */       return new ObjectType(this.typeId, null, 0);
/*     */     }
/* 159 */     return type;
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 192 */     this.typeId = in.readShort();
/*     */   }
/*     */ 
/*     */   private Object readResolve()
/*     */     throws ObjectStreamException
/*     */   {
/* 198 */     return getObjectType(this.typeId);
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 204 */     out.writeShort(this.typeId);
/*     */   }
/*     */ 
/*     */   public static class PersistenceDelegate extends DefaultPersistenceDelegate
/*     */   {
/*     */     protected Expression instantiate(Object oldInstance, Encoder out)
/*     */     {
/* 179 */       ObjectType objectType = (ObjectType)oldInstance;
/* 180 */       return new Expression(ObjectType.class, "getObjectType", new Object[] { Short.valueOf(objectType.getTypeId()) });
/*     */     }
/*     */ 
/*     */     protected boolean mutatesTo(Object oldInstance, Object newInstance)
/*     */     {
/* 185 */       return oldInstance == newInstance;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ObjectType
 * JD-Core Version:    0.6.0
 */