/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.agis.objects.AgisAttachSocket;
/*     */ import atavism.agis.objects.AgisEquipSlot;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class DisplayContext
/*     */   implements Cloneable, Serializable
/*     */ {
/* 445 */   public String meshFile = null;
/*     */ 
/* 447 */   private Map<String, DisplayContext> childDCMap = new HashMap();
/*     */ 
/* 449 */   private OID objRef = null;
/*     */ 
/* 451 */   private Set<Submesh> submeshes = new HashSet();
/*     */ 
/* 455 */   private Map<DisplayState, Map<AgisEquipSlot, AgisAttachSocket>> displayInfoMap = new HashMap();
/*     */ 
/* 457 */   private boolean attachableFlag = false;
/* 458 */   private boolean castShadow = false;
/* 459 */   private boolean receiveShadow = false;
/* 460 */   private int displayID = -1;
/*     */   protected transient Lock lock;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public DisplayContext()
/*     */   {
/*  13 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public DisplayContext(OID oid) {
/*  17 */     setupTransient();
/*  18 */     this.objRef = oid;
/*     */   }
/*     */   public DisplayContext(String meshfile) {
/*  21 */     setupTransient();
/*  22 */     setMeshFile(meshfile);
/*     */   }
/*     */   public DisplayContext(String meshfile, boolean castShadow) {
/*  25 */     setupTransient();
/*  26 */     setMeshFile(meshfile);
/*  27 */     setCastShadow(castShadow);
/*     */   }
/*     */   public DisplayContext(OID oid, String meshfile) {
/*  30 */     setupTransient();
/*  31 */     this.objRef = oid;
/*  32 */     setMeshFile(meshfile);
/*     */   }
/*     */ 
/*     */   protected void setupTransient() {
/*  36 */     this.lock = LockFactory.makeLock("DisplayContextLock");
/*     */   }
/*     */ 
/*     */   public boolean subsetOf(DisplayContext other)
/*     */   {
/*  43 */     if (!getMeshFile().equals(other.getMeshFile())) {
/*  44 */       return false;
/*     */     }
/*     */ 
/*  47 */     Set otherSubmeshes = other.getSubmeshes();
/*  48 */     for (Submesh submesh : getSubmeshes()) {
/*  49 */       if (!otherSubmeshes.contains(submesh)) {
/*  50 */         return false;
/*     */       }
/*     */     }
/*  53 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  60 */     DisplayContext otherDC = (DisplayContext)other;
/*  61 */     if (!otherDC.getMeshFile().equals(getMeshFile())) {
/*  62 */       return false;
/*     */     }
/*  64 */     return (subsetOf(otherDC)) && (otherDC.subsetOf(this));
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/*  68 */     int hash = this.meshFile.hashCode();
/*  69 */     for (Submesh subMesh : getSubmeshes()) {
/*  70 */       hash ^= subMesh.hashCode();
/*     */     }
/*  72 */     return hash;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  76 */     Set subMeshes = getSubmeshes();
/*  77 */     String s = "[DisplayContext: meshFile=" + getMeshFile() + ", attachableFlag=" + getAttachableFlag() + ", castShadow=" + getCastShadow() + ", receiveShadow=" + getReceiveShadow() + ", numSubmeshes=" + subMeshes.size();
/*     */ 
/*  84 */     for (Submesh subMesh : subMeshes) {
/*  85 */       s = s + ", submesh=" + subMesh;
/*     */     }
/*  87 */     return s + "]";
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  92 */     this.lock.lock();
/*     */     try {
/*  94 */       DisplayContext dc = new DisplayContext(getObjRef());
/*  95 */       dc.setMeshFile(getMeshFile());
/*     */ 
/*  98 */       dc.setSubmeshes(this.submeshes);
/*     */ 
/* 100 */       dc.setAttachableFlag(getAttachableFlag());
/*     */ 
/* 102 */       dc.setDisplayInfo(getDisplayInfo());
/*     */ 
/* 104 */       dc.setChildDCMap(getChildDCMap());
/*     */ 
/* 106 */       dc.setCastShadow(getCastShadow());
/* 107 */       dc.setReceiveShadow(getReceiveShadow());
/* 108 */       dc.setDisplayID(getDisplayID());
/* 109 */       DisplayContext localDisplayContext1 = dc;
/*     */       return localDisplayContext1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setObjRef(OID oid)
/*     */   {
/* 121 */     this.objRef = oid;
/*     */   }
/*     */ 
/*     */   public OID getObjRef()
/*     */   {
/* 128 */     return this.objRef;
/*     */   }
/*     */ 
/*     */   public String getMeshFile() {
/* 132 */     return this.meshFile;
/*     */   }
/*     */   public void setMeshFile(String mesh) {
/* 135 */     this.meshFile = mesh;
/*     */   }
/*     */ 
/*     */   public void addSubmesh(Submesh submesh) {
/* 139 */     this.lock.lock();
/*     */     try {
/* 141 */       this.submeshes.add(submesh);
/*     */     }
/*     */     finally {
/* 144 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addSubmeshes(Collection<Submesh> submeshes) {
/* 148 */     this.lock.lock();
/*     */     try {
/* 150 */       this.submeshes.addAll(submeshes);
/*     */     }
/*     */     finally {
/* 153 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeSubmesh(Submesh submesh) {
/* 157 */     this.lock.lock();
/*     */     try {
/* 159 */       this.submeshes.remove(submesh);
/*     */     }
/*     */     finally {
/* 162 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeSubmeshes(Collection<Submesh> submeshes) {
/* 166 */     this.lock.lock();
/*     */     try {
/* 168 */       if (Log.loggingDebug) {
/* 169 */         Log.debug("DisplayContext.removeSubmeshes: removelist=" + submeshes + ", currentDC=" + this);
/*     */       }
/*     */ 
/* 172 */       this.submeshes.removeAll(submeshes);
/* 173 */       if (Log.loggingDebug)
/* 174 */         Log.debug("DisplayContext.removeSubmeshes: updated dc=" + this);
/*     */     }
/*     */     finally {
/* 177 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addChildDC(String handle, DisplayContext dc)
/*     */   {
/* 193 */     this.lock.lock();
/*     */     try {
/* 195 */       this.childDCMap.put(handle, (DisplayContext)dc.clone());
/*     */     }
/*     */     finally {
/* 198 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public DisplayContext getChildDC(String handle) {
/* 202 */     this.lock.lock();
/*     */     try {
/* 204 */       DisplayContext localDisplayContext = (DisplayContext)this.childDCMap.get(handle);
/*     */       return localDisplayContext; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public DisplayContext removeChildDC(String handle)
/*     */   {
/* 212 */     this.lock.lock();
/*     */     try {
/* 214 */       DisplayContext localDisplayContext = (DisplayContext)this.childDCMap.remove(handle);
/*     */       return localDisplayContext; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setChildDCMap(Map<String, DisplayContext> map)
/*     */   {
/* 225 */     this.lock.lock();
/*     */     try {
/* 227 */       this.childDCMap = new HashMap(map);
/*     */     }
/*     */     finally {
/* 230 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map<String, DisplayContext> getChildDCMap() {
/* 235 */     this.lock.lock();
/*     */     try {
/* 237 */       HashMap localHashMap = new HashMap(this.childDCMap);
/*     */       return localHashMap; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setSubmeshes(Set<Submesh> submeshes)
/*     */   {
/* 245 */     this.lock.lock();
/*     */     try {
/* 247 */       this.submeshes = new HashSet(submeshes);
/*     */     }
/*     */     finally {
/* 250 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<Submesh> getSubmeshes() {
/* 254 */     this.lock.lock();
/*     */     try {
/* 256 */       HashSet localHashSet = new HashSet(this.submeshes);
/*     */       return localHashSet; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean getAttachableFlag()
/*     */   {
/* 265 */     return this.attachableFlag;
/*     */   }
/*     */   public void setAttachableFlag(boolean b) {
/* 268 */     this.attachableFlag = b;
/*     */   }
/*     */ 
/*     */   public void setAttachInfo(DisplayState displayState, AgisEquipSlot equipSlot, AgisAttachSocket socket)
/*     */   {
/* 274 */     this.lock.lock();
/*     */     try {
/* 276 */       setAttachableFlag(true);
/* 277 */       Map attachMap = (Map)this.displayInfoMap.get(displayState);
/*     */ 
/* 280 */       if (attachMap == null)
/*     */       {
/* 282 */         attachMap = new HashMap();
/* 283 */         this.displayInfoMap.put(displayState, attachMap);
/*     */       }
/* 285 */       attachMap.put(equipSlot, socket);
/*     */     }
/*     */     finally {
/* 288 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public AgisAttachSocket getAttachInfo(DisplayState ds, AgisEquipSlot equipSlot) {
/* 293 */     this.lock.lock();
/*     */     try {
/* 295 */       if (!getAttachableFlag()) {
/* 296 */         Log.error("DisplayContext.getAttachInfo: not attachable");
/* 297 */         Object localObject1 = null;
/*     */         return localObject1;
/*     */       }
/* 299 */       Map attachMap = (Map)this.displayInfoMap.get(ds);
/*     */ 
/* 302 */       if (attachMap == null) {
/* 303 */         Log.warn("DisplayContext.getAttachInfo: could not find displayState " + ds);
/* 304 */         localAgisAttachSocket = null;
/*     */         return localAgisAttachSocket;
/*     */       }
/* 306 */       AgisAttachSocket localAgisAttachSocket = (AgisAttachSocket)attachMap.get(equipSlot);
/*     */       return localAgisAttachSocket; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public void setDisplayInfo(Map<DisplayState, Map<AgisEquipSlot, AgisAttachSocket>> map)
/*     */   {
/* 317 */     this.lock.lock();
/*     */     try {
/* 319 */       if (!this.displayInfoMap.isEmpty()) {
/* 320 */         throw new RuntimeException("displaycontext: setting display info on existing non empty map");
/*     */       }
/*     */ 
/* 323 */       for (Map.Entry entry : map.entrySet()) {
/* 324 */         DisplayState ds = (DisplayState)entry.getKey();
/* 325 */         Map attachMap = new HashMap((Map)entry.getValue());
/* 326 */         this.displayInfoMap.put(ds, attachMap);
/*     */       }
/*     */     }
/*     */     finally {
/* 330 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map<DisplayState, Map<AgisEquipSlot, AgisAttachSocket>> getDisplayInfo() {
/* 334 */     return this.displayInfoMap;
/*     */   }
/*     */ 
/*     */   public void printAttachInfo()
/*     */   {
/* 341 */     this.lock.lock();
/*     */     try {
/* 343 */       for (DisplayState ds : this.displayInfoMap.keySet()) {
/* 344 */         if (Log.loggingDebug)
/* 345 */           Log.debug("DisplayContext.printAttachInfo: state=" + ds);
/* 346 */         printAttachInfo((Map)this.displayInfoMap.get(ds));
/*     */       }
/*     */     }
/*     */     finally {
/* 350 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void printAttachInfo(Map<AgisEquipSlot, AgisAttachSocket> map) {
/* 354 */     this.lock.lock();
/*     */     try {
/* 356 */       Iterator keysIter = map.keySet().iterator();
/* 357 */       while (keysIter.hasNext()) {
/* 358 */         AgisEquipSlot slot = (AgisEquipSlot)keysIter.next();
/* 359 */         AgisAttachSocket socket = (AgisAttachSocket)map.get(slot);
/* 360 */         if (Log.loggingDebug)
/* 361 */           Log.debug("DisplayContext.printAttachInfo: slot=" + slot + ", socket=" + socket);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 366 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCastShadow(boolean cast)
/*     */   {
/* 414 */     this.castShadow = cast;
/*     */   }
/*     */   public boolean getCastShadow() {
/* 417 */     return this.castShadow;
/*     */   }
/*     */   public void setReceiveShadow(boolean receive) {
/* 420 */     this.receiveShadow = receive;
/*     */   }
/*     */   public boolean getReceiveShadow() {
/* 423 */     return this.receiveShadow;
/*     */   }
/*     */ 
/*     */   public void setDisplayID(int displayID)
/*     */   {
/* 428 */     this.displayID = displayID;
/*     */   }
/*     */   public int getDisplayID() {
/* 431 */     return this.displayID;
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException
/*     */   {
/* 436 */     out.defaultWriteObject();
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 441 */     setupTransient();
/* 442 */     in.defaultReadObject();
/*     */   }
/*     */ 
/*     */   public static class Submesh
/*     */     implements Serializable
/*     */   {
/* 399 */     public String name = null;
/*     */ 
/* 407 */     public String material = null;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public Submesh()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Submesh(String name, String material)
/*     */     {
/* 375 */       this.name = name;
/* 376 */       this.material = material;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 380 */       return "[Submesh: name=" + this.name + ", material=" + this.material + "]";
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/* 384 */       Submesh otherSub = (Submesh)other;
/* 385 */       return (this.name.equals(otherSub.getName())) && (this.material.equals(otherSub.getMaterial()));
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 389 */       return ((getName() == null) || (getName().equals("")) ? 0 : getName().hashCode()) ^ (getMaterial() == null ? 0 : getMaterial().hashCode());
/*     */     }
/*     */ 
/*     */     public void setName(String name)
/*     */     {
/* 394 */       this.name = name;
/*     */     }
/*     */     public String getName() {
/* 397 */       return this.name;
/*     */     }
/*     */ 
/*     */     public void setMaterial(String material)
/*     */     {
/* 402 */       this.material = material;
/*     */     }
/*     */     public String getMaterial() {
/* 405 */       return this.material;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.DisplayContext
 * JD-Core Version:    0.6.0
 */