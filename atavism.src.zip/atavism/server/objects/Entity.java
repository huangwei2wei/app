/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.engine.OIDManager;
/*     */ import atavism.server.util.DLock;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Entity extends NamedPropertyClass
/*     */   implements Serializable
/*     */ {
/* 359 */   protected static Set<Object> transientPropertyKeys = new HashSet();
/*     */ 
/* 393 */   protected Integer subObjectNamespacesInt = null;
/*     */ 
/* 398 */   protected static final Logger log = new Logger("Entity");
/*     */ 
/* 400 */   private byte namespaceByte = 1;
/* 401 */   private boolean persistEntity = false;
/* 402 */   private transient boolean deleted = false;
/*     */ 
/* 408 */   private OID oid = null;
/*     */ 
/* 410 */   protected ObjectType type = ObjectTypes.unknown;
/*     */ 
/* 412 */   private transient Map<String, Serializable> transientMap = null;
/*     */ 
/* 417 */   public static Lock staticLock = LockFactory.makeLock("EntityStaticLock");
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Entity()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Entity(String name)
/*     */   {
/*  37 */     super(name);
/*  38 */     setOid(Engine.getOIDManager().getNextOid());
/*     */   }
/*     */ 
/*     */   public Entity(OID oid)
/*     */   {
/*  49 */     setOid(oid);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  58 */     return "[Entity: " + getName() + ":" + getOid() + "]";
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  66 */     in.defaultReadObject();
/*  67 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  74 */     return getOid().hashCode();
/*     */   }
/*     */ 
/*     */   public OID getOid()
/*     */   {
/*  82 */     return this.oid;
/*     */   }
/*     */ 
/*     */   public void setOid(OID oid)
/*     */   {
/*  92 */     this.oid = oid;
/*  93 */     if ((this.lock instanceof DLock))
/*  94 */       ((DLock)this.lock).setName("EntityLock_" + oid);
/*     */   }
/*     */ 
/*     */   public ObjectType getType()
/*     */   {
/* 102 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(ObjectType type)
/*     */   {
/* 108 */     this.type = type;
/*     */   }
/*     */ 
/*     */   private Serializable setTransientData(String key, Serializable value)
/*     */   {
/* 118 */     this.lock.lock();
/*     */     try {
/* 120 */       if (this.transientMap == null)
/* 121 */         this.transientMap = new HashMap();
/* 122 */       Serializable localSerializable = (Serializable)this.transientMap.put(key, value);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   private Serializable removeTransientData(String key)
/*     */   {
/* 136 */     this.lock.lock();
/*     */     try {
/* 138 */       if (this.transientMap == null) {
/* 139 */         localSerializable = null;
/*     */         return localSerializable;
/*     */       }
/* 140 */       Serializable localSerializable = (Serializable)this.transientMap.remove(key);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   private Serializable getTransientData(Object key)
/*     */   {
/* 154 */     this.lock.lock();
/*     */     try {
/* 156 */       if (this.transientMap == null)
/* 157 */         this.transientMap = new HashMap();
/* 158 */       Serializable localSerializable = (Serializable)this.transientMap.get(key);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getTransientDataRef()
/*     */   {
/* 166 */     return this.transientMap;
/*     */   }
/*     */ 
/*     */   public static boolean equals(Entity obj1, Entity obj2)
/*     */   {
/* 175 */     if ((obj1 == null) || (obj2 == null)) {
/* 176 */       return false;
/*     */     }
/* 178 */     return (obj1.getOid().equals(obj2.getOid())) && (obj1.namespaceByte == obj2.namespaceByte);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 187 */     Entity otherObj = (Entity)other;
/* 188 */     return equals(this, otherObj);
/*     */   }
/*     */ 
/*     */   public void setPersistenceFlag(boolean flag)
/*     */   {
/* 196 */     this.persistEntity = flag;
/*     */   }
/*     */ 
/*     */   public boolean getPersistenceFlag()
/*     */   {
/* 204 */     return this.persistEntity;
/*     */   }
/*     */ 
/*     */   public Namespace getNamespace()
/*     */   {
/* 211 */     return Namespace.getNamespaceFromInt(Integer.valueOf(this.namespaceByte));
/*     */   }
/*     */ 
/*     */   public void setNamespace(Namespace namespace)
/*     */   {
/* 218 */     this.namespaceByte = (byte)namespace.getNumber();
/*     */   }
/*     */ 
/*     */   public List<Namespace> getSubObjectNamespaces()
/*     */   {
/* 226 */     this.lock.lock();
/*     */     try {
/* 228 */       List localList = Namespace.decompressNamespaceList(this.subObjectNamespacesInt);
/*     */       return localList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setSubObjectNamespaces(Set<Namespace> namespaces)
/*     */   {
/* 239 */     this.lock.lock();
/*     */     try {
/* 241 */       this.subObjectNamespacesInt = Namespace.compressNamespaceList(namespaces);
/*     */     } finally {
/* 243 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addSubObjectNamespace(Namespace namespace) {
/* 248 */     this.lock.lock();
/*     */     try {
/* 250 */       this.subObjectNamespacesInt = Integer.valueOf(this.subObjectNamespacesInt.intValue() | 1 << namespace.getNumber());
/*     */     } finally {
/* 252 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeSubObjectNamespace(Namespace namespace) {
/* 257 */     this.lock.lock();
/*     */     try {
/* 259 */       this.subObjectNamespacesInt = Integer.valueOf(this.subObjectNamespacesInt.intValue() & (1 << namespace.getNumber() ^ 0xFFFFFFFF));
/*     */     } finally {
/* 261 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean hasSubObjectNamespace(Namespace namespace) {
/* 266 */     this.lock.lock();
/*     */     try {
/* 268 */       int i = (this.subObjectNamespacesInt.intValue() & 1 << namespace.getNumber()) != 0 ? 1 : 0;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Lock getLock()
/*     */   {
/* 280 */     return this.lock;
/*     */   }
/*     */ 
/*     */   public byte[] toBytes()
/*     */   {
/*     */     try
/*     */     {
/* 289 */       ByteArrayOutputStream ba = new ByteArrayOutputStream();
/* 290 */       ObjectOutputStream os = new ObjectOutputStream(ba);
/* 291 */       os.writeObject(this);
/* 292 */       os.flush();
/* 293 */       ba.flush();
/* 294 */       return ba.toByteArray(); } catch (Exception e) {
/*     */     }
/* 296 */     throw new RuntimeException("Entity.toBytes", e);
/*     */   }
/*     */ 
/*     */   public Serializable setProperty(String key, Serializable value)
/*     */   {
/* 306 */     if (transientPropertyKeys.contains(key)) {
/* 307 */       return setTransientData(key, value);
/*     */     }
/* 309 */     return super.setProperty(key, value);
/*     */   }
/*     */ 
/*     */   public Serializable removeProperty(String key) {
/* 313 */     if (transientPropertyKeys.contains(key)) {
/* 314 */       return removeTransientData(key);
/*     */     }
/* 316 */     return super.removeProperty(key);
/*     */   }
/*     */ 
/*     */   public Serializable getProperty(String key)
/*     */   {
/* 324 */     if (transientPropertyKeys.contains(key)) {
/* 325 */       return getTransientData(key);
/*     */     }
/* 327 */     return super.getProperty(key);
/*     */   }
/*     */ 
/*     */   public boolean isDeleted()
/*     */   {
/* 332 */     return this.deleted;
/*     */   }
/*     */ 
/*     */   public void setDeleted()
/*     */   {
/* 337 */     this.deleted = true;
/*     */   }
/*     */ 
/*     */   public static Object registerTransientPropertyKey(Object key)
/*     */   {
/* 344 */     transientPropertyKeys.add(key);
/* 345 */     return key;
/*     */   }
/*     */ 
/*     */   public static void unregisterTransientPropertyKey(Object key)
/*     */   {
/* 352 */     transientPropertyKeys.remove(key);
/*     */   }
/*     */ 
/*     */   public Integer getSubObjectNamespacesInt()
/*     */   {
/* 367 */     this.lock.lock();
/*     */     try {
/* 369 */       Integer localInteger = this.subObjectNamespacesInt;
/*     */       return localInteger; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setSubObjectNamespacesInt(Integer value)
/*     */   {
/* 381 */     this.lock.lock();
/*     */     try {
/* 383 */       this.subObjectNamespacesInt = value;
/*     */     } finally {
/* 385 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Entity
 * JD-Core Version:    0.6.0
 */