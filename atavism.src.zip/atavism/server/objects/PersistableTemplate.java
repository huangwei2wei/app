/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.Namespace;
/*    */ import atavism.server.util.LockFactory;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class PersistableTemplate
/*    */   implements Serializable
/*    */ {
/* 65 */   private Map<String, Map<String, Serializable>> propMap = new HashMap();
/*    */   private String name;
/* 70 */   protected transient Lock lock = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PersistableTemplate()
/*    */   {
/* 13 */     setupTransient();
/*    */   }
/*    */   public PersistableTemplate(Template template) {
/* 16 */     setupTransient();
/* 17 */     fromTemplate(template);
/*    */   }
/*    */ 
/*    */   protected void setupTransient() {
/* 21 */     this.lock = LockFactory.makeLock("NamedPropertyLock");
/*    */   }
/*    */ 
/*    */   public void fromTemplate(Template template) {
/* 25 */     this.lock.lock();
/*    */     try {
/* 27 */       template.lock.lock();
/*    */       try {
/* 29 */         this.name = template.getName();
/* 30 */         this.propMap.clear();
/* 31 */         for (Namespace namespace : template.getNamespaces())
/* 32 */           this.propMap.put(namespace.getName(), template.getSubMap(namespace));
/*    */       }
/*    */       finally {
/* 35 */         template.lock.unlock();
/*    */       }
/*    */     } finally {
/* 38 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Template toTemplate() {
/* 42 */     Template rv = new Template(this.name);
/* 43 */     for (String namespaceString : this.propMap.keySet()) {
/* 44 */       namespace = Namespace.intern(namespaceString);
/* 45 */       Map val = (Map)this.propMap.get(namespaceString);
/* 46 */       for (Map.Entry entry : val.entrySet())
/* 47 */         rv.put(namespace, (String)entry.getKey(), (Serializable)entry.getValue());
/*    */     }
/*    */     Namespace namespace;
/* 50 */     return rv;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 54 */     return this.name;
/*    */   }
/*    */   public void SetName(String value) {
/* 57 */     this.name = value;
/*    */   }
/*    */   public Map<String, Map<String, Serializable>> getPropMap() {
/* 60 */     return this.propMap;
/*    */   }
/*    */   public void setPropMap(Map<String, Map<String, Serializable>> value) {
/* 63 */     this.propMap = value;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.PersistableTemplate
 * JD-Core Version:    0.6.0
 */