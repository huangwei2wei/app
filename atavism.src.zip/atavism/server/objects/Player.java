/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.EnginePlugin;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class Player
/*     */ {
/*     */   public static final int STATUS_UNKNOWN = 0;
/*     */   public static final int STATUS_LOGIN_PENDING = 1;
/*     */   public static final int STATUS_LOGIN_OK = 2;
/*     */   public static final int STATUS_LOGOUT = 3;
/*     */   public static final int LOAD_PENDING = 0;
/*     */   public static final int LOAD_COMPLETE = 1;
/* 234 */   private String name = "";
/*     */   private OID oid;
/*     */   private ClientConnection connection;
/*     */   private String version;
/*     */   private List<String> capabilities;
/*     */   private int status;
/* 240 */   private int loadingState = 0;
/*     */   private List<Event> deferredEvents;
/*     */   private long loginTime;
/*     */   private long lastActivityTime;
/*     */   private long lastContactTime;
/*     */   BasicWorldNode lastLocUpdate;
/*     */   private Set<OID> ignoredOids;
/*     */ 
/*     */   public Player(OID playerOid, ClientConnection conn)
/*     */   {
/*  25 */     this.oid = playerOid;
/*  26 */     this.connection = conn;
/*  27 */     this.lastLocUpdate = new BasicWorldNode();
/*  28 */     this.lastLocUpdate.setLoc(new Point(0.0F, 0.0F, 0.0F));
/*  29 */     this.lastLocUpdate.setDir(new AOVector(0.0F, 0.0F, 0.0F));
/*  30 */     this.lastLocUpdate.setOrientation(new Quaternion(0.0F, 0.0F, 0.0F, 0.0F));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  35 */     return "[oid=" + this.oid + " name=" + this.name + " status=" + statusToString(this.status) + "]";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  40 */     if ((other instanceof Player)) {
/*  41 */       return this.oid.compareTo(((Player)other).oid) == 0;
/*     */     }
/*  43 */     return false;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  48 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  53 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public OID getOid()
/*     */   {
/*  58 */     return this.oid;
/*     */   }
/*     */ 
/*     */   public ClientConnection getConnection()
/*     */   {
/*  63 */     return this.connection;
/*     */   }
/*     */ 
/*     */   public void clearConnection()
/*     */   {
/*  68 */     this.connection = null;
/*     */   }
/*     */ 
/*     */   public String getVersion()
/*     */   {
/*  73 */     return this.version;
/*     */   }
/*     */ 
/*     */   public boolean supportsLoadingState()
/*     */   {
/*  82 */     return (this.version.startsWith("1.")) && (!this.version.startsWith("1.0"));
/*     */   }
/*     */ 
/*     */   public void setVersion(String vers)
/*     */   {
/*  87 */     this.version = vers;
/*     */   }
/*     */ 
/*     */   public List<String> getCapabilities()
/*     */   {
/*  92 */     return this.capabilities;
/*     */   }
/*     */ 
/*     */   public boolean hasCapability(String cap)
/*     */   {
/*  97 */     if (this.capabilities == null)
/*  98 */       return false;
/*  99 */     return this.capabilities.contains(cap);
/*     */   }
/*     */ 
/*     */   public void setCapabilities(List<String> caps)
/*     */   {
/* 104 */     this.capabilities = caps;
/*     */   }
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 114 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(int s)
/*     */   {
/* 119 */     Log.debug("Player: oid=" + this.oid + ", setting status to " + s);
/* 120 */     this.status = s;
/*     */   }
/*     */ 
/*     */   public static String statusToString(int s)
/*     */   {
/* 125 */     switch (s) { case 0:
/* 126 */       return "UNKNOWN";
/*     */     case 1:
/* 127 */       return "LOGIN_PENDING";
/*     */     case 2:
/* 128 */       return "OK";
/*     */     case 3:
/* 129 */       return "LOGOUT"; }
/* 130 */     return s + " (??)";
/*     */   }
/*     */ 
/*     */   public int getLoadingState()
/*     */   {
/* 139 */     return this.loadingState;
/*     */   }
/*     */ 
/*     */   public void setLoadingState(int state)
/*     */   {
/* 144 */     Log.debug("Set player loading state to " + state);
/* 145 */     this.loadingState = state;
/*     */   }
/*     */ 
/*     */   public List<Event> getDeferredEvents()
/*     */   {
/* 150 */     return this.deferredEvents;
/*     */   }
/*     */ 
/*     */   public void setDeferredEvents(List<Event> events)
/*     */   {
/* 155 */     this.deferredEvents = events;
/*     */   }
/*     */ 
/*     */   public long getLoginTime()
/*     */   {
/* 160 */     return this.loginTime;
/*     */   }
/*     */ 
/*     */   public void setLoginTime(long time_ms)
/*     */   {
/* 165 */     this.loginTime = time_ms;
/*     */   }
/*     */ 
/*     */   public long getLastActivityTime()
/*     */   {
/* 170 */     return this.lastActivityTime;
/*     */   }
/*     */ 
/*     */   public void setLastActivityTime(long time_ms)
/*     */   {
/* 175 */     this.lastActivityTime = time_ms;
/* 176 */     this.lastContactTime = time_ms;
/*     */   }
/*     */ 
/*     */   public long getLastContactTime()
/*     */   {
/* 181 */     return this.lastContactTime;
/*     */   }
/*     */ 
/*     */   public void setLastContactTime(long time_ms)
/*     */   {
/* 186 */     this.lastContactTime = time_ms;
/*     */   }
/*     */ 
/*     */   public synchronized void updateIgnoredOids(List<OID> nowIgnored, List<OID> noLongerIgnored)
/*     */   {
/* 191 */     if (noLongerIgnored != null)
/* 192 */       this.ignoredOids.removeAll(noLongerIgnored);
/* 193 */     if (nowIgnored != null)
/* 194 */       this.ignoredOids.addAll(nowIgnored);
/* 195 */     setIgnoredOidsProperty();
/*     */   }
/*     */ 
/*     */   public synchronized void setIgnoredOids(Collection<OID> newIgnoredOids)
/*     */   {
/* 200 */     initializeIgnoredOids(newIgnoredOids);
/* 201 */     setIgnoredOidsProperty();
/*     */   }
/*     */ 
/*     */   public synchronized void setIgnoredOidsProperty() {
/* 205 */     EnginePlugin.setObjectProperty(this.oid, Namespace.WORLD_MANAGER, "ignored_oids", (HashSet)this.ignoredOids);
/*     */   }
/*     */ 
/*     */   public synchronized boolean oidIgnored(OID oid)
/*     */   {
/* 210 */     return (this.ignoredOids != null) && (this.ignoredOids.contains(oid));
/*     */   }
/*     */ 
/*     */   public synchronized int ignoredOidCount()
/*     */   {
/* 215 */     return this.ignoredOids == null ? 0 : this.ignoredOids.size();
/*     */   }
/*     */ 
/*     */   public void initializeIgnoredOids(Collection<OID> ignoredOids)
/*     */   {
/* 220 */     this.ignoredOids = new HashSet();
/* 221 */     if (ignoredOids != null)
/* 222 */       this.ignoredOids.addAll(ignoredOids);
/*     */   }
/*     */ 
/*     */   public synchronized List<OID> getIgnoredOids()
/*     */   {
/* 227 */     List oids = new LinkedList();
/* 228 */     if (this.ignoredOids == null)
/* 229 */       return oids;
/* 230 */     oids.addAll(this.ignoredOids);
/* 231 */     return oids;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Player
 * JD-Core Version:    0.6.0
 */