package atavism.server.objects;

import atavism.server.engine.OID;
import atavism.server.math.Point;

public abstract interface InstanceEntryCallback
{
  public abstract boolean instanceEntryAllowed(OID paramOID1, OID paramOID2, Point paramPoint);

  public abstract OID selectInstance(Player paramPlayer, String paramString);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.InstanceEntryCallback
 * JD-Core Version:    0.6.0
 */