/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.BasicWorldNode;
/*    */ import atavism.server.engine.Behavior;
/*    */ import atavism.server.engine.EnginePlugin;
/*    */ import atavism.server.engine.InterpolatedWorldNode;
/*    */ import atavism.server.engine.Namespace;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.plugins.MobManagerPlugin;
/*    */ import atavism.server.plugins.WorldManagerClient;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ObjectStub extends Entity
/*    */   implements EntityWithWorldNode
/*    */ {
/*    */   InterpolatedWorldNode node;
/*    */   int templateID;
/* 58 */   protected boolean spawned = false;
/*    */ 
/* 89 */   protected List<Behavior> behaviors = new ArrayList();
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ObjectStub()
/*    */   {
/* 12 */     setNamespace(Namespace.MOB);
/*    */   }
/*    */ 
/*    */   public ObjectStub(OID objId, InterpolatedWorldNode node, int template) {
/* 16 */     setOid(objId);
/* 17 */     setWorldNode(node);
/* 18 */     setTemplateID(template);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 22 */     return "[ObjectStub: oid=" + getOid() + " node=" + this.node + "]";
/*    */   }
/*    */ 
/*    */   public Entity getEntity() {
/* 26 */     return this;
/*    */   }
/*    */ 
/*    */   public OID getInstanceOid() {
/* 30 */     return this.node.getInstanceOid();
/*    */   }
/*    */   public InterpolatedWorldNode getWorldNode() {
/* 33 */     return this.node; } 
/* 34 */   public void setWorldNode(InterpolatedWorldNode node) { this.node = node; }
/*    */ 
/*    */   public void setDirLocOrient(BasicWorldNode bnode)
/*    */   {
/* 38 */     if (this.node != null)
/* 39 */       this.node.setDirLocOrient(bnode); 
/*    */   }
/*    */ 
/*    */   public int getTemplateID() {
/* 42 */     return this.templateID; } 
/* 43 */   public void setTemplateID(int template) { this.templateID = template; }
/*    */ 
/*    */   public void updateWorldNode()
/*    */   {
/* 47 */     WorldManagerClient.updateWorldNode(getOid(), new BasicWorldNode(this.node));
/*    */   }
/*    */ 
/*    */   public void spawn() {
/* 51 */     OID oid = getOid();
/* 52 */     MobManagerPlugin.getTracker(getInstanceOid()).addLocalObject(oid, (Integer)EnginePlugin.getObjectProperty(oid, Namespace.WORLD_MANAGER, "reactionRadius"));
/* 53 */     WorldManagerClient.spawn(oid);
/* 54 */     for (Behavior behav : this.behaviors)
/* 55 */       behav.activate();
/*    */   }
/*    */ 
/*    */   public void despawn()
/*    */   {
/* 61 */     unload();
/* 62 */     WorldManagerClient.despawn(getOid());
/*    */   }
/*    */ 
/*    */   public void unload() {
/* 66 */     for (Behavior behav : this.behaviors) {
/* 67 */       behav.deactivate();
/*    */     }
/* 69 */     OID oid = getOid();
/* 70 */     if (MobManagerPlugin.getTracker(getInstanceOid()) != null)
/* 71 */       MobManagerPlugin.getTracker(getInstanceOid()).removeLocalObject(oid);
/* 72 */     EntityManager.removeEntityByNamespace(oid, Namespace.MOB);
/*    */   }
/*    */ 
/*    */   public void addBehavior(Behavior behav) {
/* 76 */     behav.setObjectStub(this);
/* 77 */     this.behaviors.add(behav);
/* 78 */     behav.initialize();
/*    */   }
/*    */   public void removeBehavior(Behavior behav) {
/* 81 */     this.behaviors.remove(behav);
/*    */   }
/*    */   public List<Behavior> getBehaviors() {
/* 84 */     return new ArrayList(this.behaviors);
/*    */   }
/*    */   public void setBehaviors(List<Behavior> behavs) {
/* 87 */     this.behaviors = new ArrayList(behavs);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ObjectStub
 * JD-Core Version:    0.6.0
 */