/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Bag extends Entity
/*     */ {
/*     */   private int id;
/*     */   private int numSlots;
/* 183 */   private ArrayList<OID> items = new ArrayList();
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Bag()
/*     */   {
/*  13 */     setNamespace(Namespace.BAG);
/*  14 */     setName("Bag");
/*  15 */     setNumSlots(0);
/*     */   }
/*     */ 
/*     */   public Bag(OID oid) {
/*  19 */     super(oid);
/*  20 */     setNamespace(Namespace.BAG);
/*     */   }
/*     */ 
/*     */   public Bag(int numSlots)
/*     */   {
/*  25 */     setNamespace(Namespace.BAG);
/*  26 */     setName("Bag");
/*  27 */     setNumSlots(numSlots);
/*     */   }
/*     */ 
/*     */   public Bag(int id, int numSlots) {
/*  31 */     this(numSlots);
/*  32 */     setID(id);
/*     */   }
/*     */ 
/*     */   public ObjectType getType() {
/*  36 */     return ObjectTypes.bag;
/*     */   }
/*     */ 
/*     */   public int getNumSlots() {
/*  40 */     return this.numSlots;
/*     */   }
/*     */ 
/*     */   public void setNumSlots(int numSlots)
/*     */   {
/*  47 */     this.items = new ArrayList();
/*  48 */     for (int i = 0; i < numSlots; i++)
/*  49 */       this.items.add(null);
/*  50 */     this.numSlots = numSlots;
/*     */   }
/*     */ 
/*     */   public boolean putItem(int slotNum, OID itemOid)
/*     */   {
/*  58 */     this.lock.lock();
/*     */     try
/*     */     {
/*  61 */       if (slotNum >= this.numSlots) {
/*  62 */         i = 0;
/*     */         return i;
/*     */       }
/*  66 */       if (this.items.get(slotNum) != null) {
/*  67 */         i = 0;
/*     */         return i;
/*     */       }
/*  71 */       this.items.set(slotNum, itemOid);
/*  72 */       int i = 1;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public OID getItem(int slotNum)
/*     */   {
/*  79 */     this.lock.lock();
/*     */     try {
/*  81 */       if (slotNum >= this.numSlots) {
/*  82 */         localOID = null;
/*     */         return localOID;
/*     */       }
/*  84 */       OID localOID = (OID)this.items.get(slotNum);
/*     */       return localOID; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean addItem(OID oid)
/*     */   {
/*  94 */     this.lock.lock();
/*     */     try {
/*  96 */       for (int i = 0; i < this.numSlots; i++)
/*  97 */         if (getItem(i) == null) {
/*  98 */           putItem(i, oid);
/*  99 */           int i = 1;
/*     */           return i;
/*     */         }
/* 102 */       i = 0;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean removeItem(OID oid)
/*     */   {
/* 109 */     this.lock.lock();
/*     */     try {
/* 111 */       Integer slotNum = findItem(oid);
/* 112 */       if (slotNum == null) {
/* 113 */         i = 0;
/*     */         return i;
/*     */       }
/* 115 */       this.items.set(slotNum.intValue(), null);
/* 116 */       int i = 1;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setItemsList(OID[] items)
/*     */   {
/* 127 */     this.lock.lock();
/*     */     try {
/* 129 */       this.items = new ArrayList();
/* 130 */       for (OID oidVal : items)
/* 131 */         this.items.add(oidVal);
/* 132 */       this.numSlots = items.length;
/*     */     } finally {
/* 134 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public OID[] getItemsList() {
/* 139 */     this.lock.lock();
/*     */     try {
/* 141 */       OID[] copy = new OID[this.numSlots];
/* 142 */       for (int i = 0; i < this.numSlots; i++)
/* 143 */         copy[i] = ((OID)this.items.get(i));
/* 144 */       i = copy;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Integer findItem(OID itemOid)
/*     */   {
/* 157 */     this.lock.lock();
/*     */     try {
/* 159 */       for (int i = 0; i < getNumSlots(); i++)
/* 160 */         if (itemOid.equals(this.items.get(i))) {
/* 161 */           Integer localInteger = Integer.valueOf(i);
/*     */           return localInteger;
/*     */         }
/* 164 */       i = null;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public int getID()
/*     */   {
/* 172 */     return this.id;
/*     */   }
/*     */   public void setID(int id) {
/* 175 */     this.id = id;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Bag
 * JD-Core Version:    0.6.0
 */