/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.Namespace;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.util.LockFactory;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class EntityHandle
/*    */   implements Serializable
/*    */ {
/* 71 */   private OID oid = null;
/*    */ 
/* 73 */   private transient Entity entity = null;
/*    */ 
/* 75 */   private transient Lock lock = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public EntityHandle()
/*    */   {
/* 14 */     setupTransient();
/*    */   }
/*    */   public EntityHandle(OID currentTarget) {
/* 17 */     this.oid = currentTarget;
/* 18 */     setupTransient();
/*    */   }
/*    */ 
/*    */   public EntityHandle(Entity entity) {
/* 22 */     this.oid = entity.getOid();
/* 23 */     this.entity = entity;
/* 24 */     setupTransient();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 28 */     if ((other instanceof EntityHandle)) {
/* 29 */       return ((EntityHandle)other).getOid().equals(getOid());
/*    */     }
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 35 */     return "[EntityHandle: objOid=" + getOid() + "]";
/*    */   }
/*    */ 
/*    */   public Entity getEntity(Namespace namespace) {
/* 39 */     this.lock.lock();
/*    */     try {
/* 41 */       if (this.entity == null) {
/* 42 */         this.entity = EntityManager.getEntityByNamespace(this.oid, namespace);
/* 43 */         localEntity = this.entity;
/*    */         return localEntity;
/*    */       }
/* 45 */       Entity localEntity = this.entity;
/*    */       return localEntity; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public void setOid(OID oid)
/*    */   {
/* 54 */     this.oid = oid;
/*    */   }
/*    */ 
/*    */   public OID getOid() {
/* 58 */     return this.oid;
/*    */   }
/*    */ 
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*    */   {
/* 63 */     in.defaultReadObject();
/* 64 */     setupTransient();
/*    */   }
/*    */ 
/*    */   void setupTransient() {
/* 68 */     this.lock = LockFactory.makeLock("EntityHandle");
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.EntityHandle
 * JD-Core Version:    0.6.0
 */