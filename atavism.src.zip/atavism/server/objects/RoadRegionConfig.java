/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.util.LockFactory;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class RoadRegionConfig extends RegionConfig
/*    */   implements Serializable
/*    */ {
/* 36 */   transient Lock lock = LockFactory.makeLock("RoadRegionLock");
/* 37 */   Set<Road> roadSet = new HashSet();
/*    */ 
/* 39 */   public static String RegionType = (String)Entity.registerTransientPropertyKey("RoadRegion");
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public RoadRegionConfig()
/*    */   {
/* 10 */     setType(RegionType);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 14 */     return "[RoadConfig]";
/*    */   }
/*    */ 
/*    */   public void addRoad(Road road) {
/* 18 */     this.lock.lock();
/*    */     try {
/* 20 */       this.roadSet.add(road);
/*    */     }
/*    */     finally {
/* 23 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Set<Road> getRoads() {
/* 27 */     this.lock.lock();
/*    */     try {
/* 29 */       HashSet localHashSet = new HashSet(this.roadSet);
/*    */       return localHashSet; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.RoadRegionConfig
 * JD-Core Version:    0.6.0
 */