/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.math.Point;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Road extends Entity
/*     */ {
/*  31 */   Integer halfWidth = null;
/*     */ 
/* 106 */   protected LinkedList<Point> points = new LinkedList();
/*     */ 
/* 108 */   public static int maxSegmentLengthMillis = 10;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Road()
/*     */   {
/*   9 */     setNamespace(Namespace.WORLD_MANAGER);
/*     */   }
/*     */ 
/*     */   public Road(String name) {
/*  13 */     super(name);
/*  14 */     setNamespace(Namespace.WORLD_MANAGER);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  18 */     String s = "[Road: name=" + getName() + ", halfWidth=" + getHalfWidth();
/*  19 */     for (Point p : getPoints()) {
/*  20 */       s = s + " " + p;
/*     */     }
/*  22 */     return s + "]";
/*     */   }
/*     */ 
/*     */   public void setHalfWidth(Integer width) {
/*  26 */     this.halfWidth = width;
/*     */   }
/*     */   public Integer getHalfWidth() {
/*  29 */     return this.halfWidth;
/*     */   }
/*     */ 
/*     */   public void setPoints(List<Point> points)
/*     */   {
/*  34 */     this.lock.lock();
/*     */     try {
/*  36 */       this.points = new LinkedList(points);
/*     */     } finally {
/*  38 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Point> getPoints() {
/*  43 */     this.lock.lock();
/*     */     try {
/*  45 */       LinkedList localLinkedList = new LinkedList(this.points);
/*     */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void addPoint(Point point)
/*     */   {
/*  52 */     this.lock.lock();
/*     */     try
/*     */     {
/*  56 */       this.points.add(point);
/*     */     }
/*     */     finally
/*     */     {
/*  79 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<RoadSegment> generateRoadSegments() {
/*  84 */     this.lock.lock();
/*     */     try {
/*  86 */       List list = new LinkedList();
/*  87 */       Iterator iter = this.points.iterator();
/*  88 */       Point lastPoint = null;
/*  89 */       while (iter.hasNext()) {
/*  90 */         if (lastPoint == null) {
/*  91 */           lastPoint = (Point)iter.next();
/*  92 */           continue;
/*     */         }
/*  94 */         curPoint = (Point)iter.next();
/*  95 */         RoadSegment seg = new RoadSegment(getName(), lastPoint, curPoint);
/*     */ 
/*  97 */         list.add(seg);
/*  98 */         lastPoint = curPoint;
/*     */       }
/* 100 */       Point curPoint = list;
/*     */       return curPoint; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Road
 * JD-Core Version:    0.6.0
 */