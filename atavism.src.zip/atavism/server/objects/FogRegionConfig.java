/*    */ package atavism.server.objects;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class FogRegionConfig extends RegionConfig
/*    */   implements Serializable
/*    */ {
/*    */   private Color fogColor;
/*    */   private int near;
/*    */   private int far;
/* 45 */   public static String RegionType = (String)Entity.registerTransientPropertyKey("FogRegion");
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public FogRegionConfig()
/*    */   {
/*  7 */     setType(RegionType);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 11 */     FogRegionConfig otherConfig = (FogRegionConfig)other;
/* 12 */     return (getColor().equals(otherConfig.getColor())) && (getNear() == otherConfig.getNear()) && (getFar() == otherConfig.getFar());
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 17 */     return "[FogRegionConfig: color=" + this.fogColor + ", near=" + this.near + ", far=" + this.far + "]";
/*    */   }
/*    */ 
/*    */   public void setColor(Color c) {
/* 21 */     this.fogColor = c;
/*    */   }
/*    */   public Color getColor() {
/* 24 */     return this.fogColor;
/*    */   }
/*    */ 
/*    */   public void setNear(int near) {
/* 28 */     this.near = near;
/*    */   }
/*    */   public int getNear() {
/* 31 */     return this.near;
/*    */   }
/*    */ 
/*    */   public void setFar(int far) {
/* 35 */     this.far = far;
/*    */   }
/*    */   public int getFar() {
/* 38 */     return this.far;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.FogRegionConfig
 * JD-Core Version:    0.6.0
 */