/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageCallback;
/*     */ import atavism.msgsys.MessageDispatch;
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.InterpolatedWorldNode;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.messages.PerceptionMessage;
/*     */ import atavism.server.messages.PerceptionMessage.ObjectNote;
/*     */ import atavism.server.plugins.WorldManagerClient.UpdateWorldNodeMessage;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class ProximityTracker
/*     */   implements MessageDispatch
/*     */ {
/*     */   protected Namespace namespace;
/*     */   protected OID instanceOid;
/* 412 */   protected float hystericalMargin = 0.0F;
/*     */ 
/* 414 */   protected ObjectTracker.NotifyReactionRadiusCallback notifyCallback = null;
/*     */ 
/* 416 */   protected ObjectTracker.RemoteObjectFilter remoteObjectFilter = null;
/*     */ 
/* 418 */   protected Updater updater = null;
/*     */ 
/* 420 */   protected Thread updaterThread = null;
/*     */ 
/* 422 */   protected boolean running = true;
/*     */ 
/* 428 */   protected Map<OID, PerceiverData> perceiverDataMap = new HashMap();
/*     */ 
/* 459 */   protected Lock lock = LockFactory.makeLock("ProximityTrackerLock");
/*     */ 
/*     */   public ProximityTracker(Namespace namespace, OID instanceOid)
/*     */   {
/*  26 */     initialize(namespace, instanceOid);
/*     */   }
/*     */ 
/*     */   public ProximityTracker(Namespace namespace, OID instanceOid, float hystericalMargin, ObjectTracker.NotifyReactionRadiusCallback notifyCallback, ObjectTracker.RemoteObjectFilter remoteObjectFilter)
/*     */   {
/*  33 */     this.hystericalMargin = hystericalMargin;
/*  34 */     this.notifyCallback = notifyCallback;
/*  35 */     this.remoteObjectFilter = remoteObjectFilter;
/*  36 */     initialize(namespace, instanceOid);
/*     */   }
/*     */ 
/*     */   private void initialize(Namespace namespace, OID instanceOid) {
/*  40 */     this.namespace = namespace;
/*  41 */     this.instanceOid = instanceOid;
/*  42 */     this.updater = new Updater();
/*  43 */     Thread updaterThread = new Thread(this.updater);
/*  44 */     updaterThread.start();
/*     */   }
/*     */ 
/*     */   public OID getInstanceOid()
/*     */   {
/*  49 */     return this.instanceOid;
/*     */   }
/*     */ 
/*     */   public void addTrackedPerceiver(OID perceiverOid, InterpolatedWorldNode wnode, Integer reactionRadius) {
/*  53 */     this.lock.lock();
/*     */     try {
/*  55 */       if (this.perceiverDataMap.containsKey(perceiverOid)) {
/*  57 */         Log.error(new StringBuilder().append("ProximityTracker.addTrackedPerceiver: perceiverOid ").append(perceiverOid).append(" is already in the set of local objects, for ProximityTracker instance ").append(this).toString());
/*     */         return;
/*     */       }
/*  61 */       PerceiverData perceiverData = new PerceiverData(perceiverOid, reactionRadius, wnode);
/*  62 */       this.perceiverDataMap.put(perceiverOid, perceiverData);
/*     */     }
/*     */     finally {
/*  65 */       this.lock.unlock();
/*     */     }
/*  67 */     if (Log.loggingDebug)
/*  68 */       Log.debug(new StringBuilder().append("ProximityTracker.addTrackedPerceiver: perceiverOid=").append(perceiverOid).append(" reactionRadius=").append(reactionRadius).append(" instanceOid=").append(this.instanceOid).toString());
/*     */   }
/*     */ 
/*     */   public boolean hasTrackedPerceiver(OID oid)
/*     */   {
/*  74 */     this.lock.lock();
/*     */     try {
/*  76 */       boolean bool = this.perceiverDataMap.containsKey(oid);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void removeTrackedPerceiver(OID perceiverOid)
/*     */   {
/*  84 */     this.lock.lock();
/*     */     try
/*     */     {
/*  88 */       PerceiverData perceiverData = (PerceiverData)this.perceiverDataMap.get(perceiverOid);
/*  89 */       if (perceiverData != null) {
/*  90 */         if (Log.loggingDebug) {
/*  91 */           Log.debug(new StringBuilder().append("ProximityTracker.removeTrackedPerceiver: perceiverOid ").append(perceiverOid).append(", inRangeOids count ").append(perceiverData.inRangeOids.size()).toString());
/*     */         }
/*     */ 
/*  95 */         for (OID perceivedOid : perceiverData.perceivedOids) {
/*  96 */           PerceiverData perceivedData = (PerceiverData)this.perceiverDataMap.get(perceivedOid);
/*  97 */           if (perceivedData != null) {
/*  98 */             perceivedData.perceivedOids.remove(perceiverOid);
/*  99 */             if (perceivedData.inRangeOids.contains(perceiverOid)) {
/* 100 */               perceivedData.inRangeOids.remove(perceiverOid);
/* 101 */               performNotification(perceiverOid, perceivedOid, false, true);
/*     */             }
/*     */           }
/*     */         }
/* 105 */         perceiverData.perceivedOids.clear();
/* 106 */         perceiverData.inRangeOids.clear();
/* 107 */         this.perceiverDataMap.remove(perceiverOid);
/*     */       }
/*     */       else {
/* 110 */         Log.warn(new StringBuilder().append("ProximityTracker.removeTrackedPerceiver: For oid=").append(perceiverOid).append(", didn't find PerceiverData").toString());
/*     */       }
/*     */     } finally {
/* 113 */       this.lock.unlock();
/*     */     }
/* 115 */     if (Log.loggingDebug)
/* 116 */       Log.debug(new StringBuilder().append("ProximityTracker.removeTrackedPerceiver: oid=").append(perceiverOid).append(" instanceOid=").append(this.instanceOid).toString());
/*     */   }
/*     */ 
/*     */   public List<OID> getOidsInRadius(OID perceiverOid)
/*     */   {
/* 121 */     this.lock.lock();
/*     */     try {
/* 123 */       PerceiverData perceiverData = (PerceiverData)this.perceiverDataMap.get(perceiverOid);
/* 124 */       if (perceiverData == null) {
/* 125 */         Log.error(new StringBuilder().append("ProximityTracker.getOidsInRadius: perceptionData for oid ").append(perceiverOid).append(" is null").toString());
/* 126 */         localLinkedList = new LinkedList();
/*     */         return localLinkedList;
/*     */       }
/* 129 */       LinkedList localLinkedList = new LinkedList(perceiverData.inRangeOids);
/*     */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void dispatchMessage(Message message, int flags, MessageCallback callback)
/*     */   {
/* 137 */     Engine.defaultDispatchMessage(message, flags, callback);
/*     */   }
/*     */ 
/*     */   protected boolean maybeAddPerceivedObject(PerceptionMessage.ObjectNote objectNote)
/*     */   {
/* 143 */     ObjectType objType = objectNote.getObjectType();
/* 144 */     OID perceivedOid = objectNote.getSubject();
/* 145 */     OID perceiverOid = objectNote.getTarget();
/* 146 */     if (perceivedOid.equals(perceiverOid))
/* 147 */       return true;
/* 148 */     boolean callbackNixedIt = false;
/* 149 */     if (this.remoteObjectFilter != null)
/* 150 */       callbackNixedIt = !this.remoteObjectFilter.objectShouldBeTracked(perceivedOid, objectNote);
/* 151 */     if ((callbackNixedIt) || (!objType.isMob()))
/*     */     {
/* 157 */       return false;
/*     */     }
/*     */ 
/* 160 */     if (Log.loggingDebug) {
/* 161 */       Log.debug(new StringBuilder().append("ProximityTracker.maybeAddPerceivedObject: oid=").append(perceivedOid).append(" objType=").append(objType).append(" detected by ").append(perceiverOid).append(", instanceOid=").append(this.instanceOid).toString());
/*     */     }
/*     */ 
/* 164 */     this.lock.lock();
/*     */     try {
/* 166 */       PerceiverData perceiverData = (PerceiverData)this.perceiverDataMap.get(perceiverOid);
/* 167 */       if (perceiverData == null) {
/* 168 */         Log.error(new StringBuilder().append("ProximityTracker.maybeAddPerceivedObject: got perception msg with perceived obj oid=").append(perceivedOid).append(" for unknown perceiver=").append(perceiverOid).toString());
/*     */ 
/* 170 */         int i = 0;
/*     */         return i;
/*     */       }
/* 172 */       perceiverData.perceivedOids.add(perceivedOid);
/* 173 */       PerceiverData perceivedData = (PerceiverData)this.perceiverDataMap.get(perceivedOid);
/* 174 */       if (perceivedData != null)
/* 175 */         testProximity(perceiverData, perceivedData, true, false);
/*     */     }
/*     */     finally {
/* 178 */       this.lock.unlock();
/*     */     }
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */   protected void testProximity(PerceiverData perceiverData, PerceiverData perceivedData, boolean interpolatePerceiver, boolean interpolatePerceived)
/*     */   {
/* 190 */     Point perceiverLoc = interpolatePerceiver ? perceiverData.wnode.getLoc() : perceiverData.lastLoc;
/* 191 */     Point perceivedLoc = interpolatePerceived ? perceivedData.wnode.getLoc() : perceivedData.lastLoc;
/* 192 */     float distance = Point.distanceTo(perceiverLoc, perceivedLoc);
/* 193 */     float reactionRadius = perceiverData.reactionRadius.intValue();
/* 194 */     OID perceiverInstance = perceiverData.wnode.getInstanceOid();
/* 195 */     OID perceivedInstance = perceivedData.wnode.getInstanceOid();
/* 196 */     boolean sameInstance = perceiverInstance.equals(perceivedInstance);
/* 197 */     boolean inRadius = (sameInstance) && (distance < reactionRadius);
/* 198 */     boolean wasInRadius = perceiverData.inRangeOids.contains(perceivedData.perceiverOid);
/*     */ 
/* 204 */     if (inRadius == wasInRadius)
/* 205 */       return;
/* 206 */     if ((sameInstance) && (this.hystericalMargin != 0.0F)) {
/* 207 */       if (wasInRadius)
/* 208 */         inRadius = distance < reactionRadius + this.hystericalMargin;
/*     */       else {
/* 210 */         inRadius = distance < reactionRadius - this.hystericalMargin;
/*     */       }
/* 212 */       if (inRadius == wasInRadius)
/* 213 */         return;
/*     */     }
/* 215 */     if (inRadius) {
/* 216 */       perceiverData.inRangeOids.add(perceivedData.perceiverOid);
/* 217 */       perceivedData.inRangeOids.add(perceiverData.perceiverOid);
/*     */     }
/*     */     else {
/* 220 */       perceiverData.inRangeOids.remove(perceivedData.perceiverOid);
/* 221 */       perceivedData.inRangeOids.remove(perceiverData.perceiverOid);
/*     */     }
/* 223 */     performNotification(perceiverData.perceiverOid, perceivedData.perceiverOid, inRadius, wasInRadius);
/*     */   }
/*     */ 
/*     */   protected void performNotification(OID perceiverOid, OID perceivedOid, boolean inRadius, boolean wasInRadius) {
/* 227 */     if (Log.loggingDebug) {
/* 228 */       Log.debug(new StringBuilder().append("ProximityTracker.performNotification: perceiverOid ").append(perceiverOid).append(", perceivedOid ").append(perceivedOid).append(", inRadius ").append(inRadius).append(", wasInRadius ").append(wasInRadius).toString());
/*     */     }
/* 230 */     if (this.notifyCallback != null) {
/* 231 */       this.notifyCallback.notifyReactionRadius(perceivedOid, perceiverOid, inRadius, wasInRadius);
/* 232 */       this.notifyCallback.notifyReactionRadius(perceiverOid, perceivedOid, inRadius, wasInRadius);
/*     */     }
/*     */     else {
/* 235 */       ObjectTracker.NotifyReactionRadiusMessage nmsg = new ObjectTracker.NotifyReactionRadiusMessage(perceivedOid, perceiverOid, inRadius, wasInRadius);
/*     */ 
/* 237 */       Engine.getAgent().sendBroadcast(nmsg);
/* 238 */       nmsg = new ObjectTracker.NotifyReactionRadiusMessage(perceiverOid, perceivedOid, inRadius, wasInRadius);
/*     */ 
/* 240 */       Engine.getAgent().sendBroadcast(nmsg);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void updateEntity(PerceiverData perceiverData) {
/* 245 */     OID perceiverOid = perceiverData.perceiverOid;
/* 246 */     this.lock.lock();
/*     */     try {
/* 248 */       for (OID perceivedOid : perceiverData.perceivedOids) {
/* 249 */         if (perceiverOid.compareTo(perceivedOid) == 0)
/*     */           continue;
/* 251 */         PerceiverData perceivedData = (PerceiverData)this.perceiverDataMap.get(perceivedOid);
/* 252 */         if (perceivedData != null)
/* 253 */           testProximity(perceiverData, perceivedData, false, true);
/*     */       }
/*     */     }
/*     */     finally {
/* 257 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void handlePerception(PerceptionMessage perceptionMessage)
/*     */   {
/* 263 */     OID targetOid = perceptionMessage.getTarget();
/* 264 */     List gain = perceptionMessage.getGainObjects();
/*     */ 
/* 266 */     List lost = perceptionMessage.getLostObjects();
/*     */ 
/* 269 */     if (Log.loggingDebug) {
/* 270 */       Log.debug(new StringBuilder().append("ProximityTracker.handlePerception: targetOid + ").append(targetOid).append(", instanceOid=").append(this.instanceOid).append(" ").append(gain == null ? 0 : gain.size()).append(" gain and ").append(lost == null ? 0 : lost.size()).append(" lost").toString());
/*     */     }
/*     */ 
/* 274 */     if (gain != null) {
/* 275 */       for (PerceptionMessage.ObjectNote note : gain)
/* 276 */         maybeAddPerceivedObject(note);
/*     */     }
/* 278 */     if (lost != null)
/* 279 */       for (PerceptionMessage.ObjectNote note : lost)
/* 280 */         maybeRemovePerceivedObject(note.getSubject(), note, targetOid);
/*     */   }
/*     */ 
/*     */   public void handleUpdateWorldNode(long oid, WorldManagerClient.UpdateWorldNodeMessage wnodeMsg) {
/* 284 */     PerceiverData perceiverData = (PerceiverData)this.perceiverDataMap.get(Long.valueOf(oid));
/* 285 */     if (perceiverData == null) {
/* 286 */       if (Log.loggingDebug) {
/* 287 */         Log.debug(new StringBuilder().append("ProximityTracker.handleMessage: ignoring updateWNMsg for oid ").append(oid).append(" because PerceptionData for oid not found").toString());
/*     */       }
/* 289 */       return;
/*     */     }
/* 291 */     BasicWorldNode bwnode = wnodeMsg.getWorldNode();
/* 292 */     if (Log.loggingDebug)
/* 293 */       Log.debug(new StringBuilder().append("ProximityTracker.handleMessage: UpdateWnode for ").append(oid).append(", loc ").append(bwnode.getLoc()).append(", dir ").append(bwnode.getDir()).toString());
/* 294 */     if (perceiverData.wnode != null) {
/* 295 */       perceiverData.previousLoc = perceiverData.lastLoc;
/* 296 */       perceiverData.wnode.setDirLocOrient(bwnode);
/* 297 */       perceiverData.wnode.setInstanceOid(bwnode.getInstanceOid());
/* 298 */       perceiverData.lastLoc = perceiverData.wnode.getLoc();
/*     */     }
/*     */     else {
/* 301 */       Log.error(new StringBuilder().append("ProximityTracker.handleMessage: In UpdateWorldNodeMessage for oid ").append(oid).append(", perceiverData.wnode is null!").toString());
/*     */     }
/* 303 */     updateEntity(perceiverData);
/*     */   }
/*     */ 
/*     */   protected void maybeRemovePerceivedObject(OID oid, PerceptionMessage.ObjectNote objectNote, OID targetOid) {
/* 307 */     if ((this.remoteObjectFilter != null) && (this.remoteObjectFilter.objectShouldBeTracked(oid, objectNote))) {
/* 308 */       return;
/*     */     }
/* 310 */     removePerceivedObject(targetOid, oid);
/*     */   }
/*     */ 
/*     */   protected void removePerceivedObject(OID targetOid, OID oid) {
/* 314 */     this.lock.lock();
/*     */     try {
/* 316 */       PerceiverData perceiverData = (PerceiverData)this.perceiverDataMap.get(targetOid);
/* 317 */       if (perceiverData == null) {
/* 318 */         if (Log.loggingDebug)
/* 319 */           Log.debug(new StringBuilder().append("ProximityTracker.removePerceivedObject: No perceiverData for oid ").append(targetOid).toString()); return;
/*     */       }
/* 322 */       perceiverData.perceivedOids.remove(oid);
/* 323 */       if (perceiverData.inRangeOids.contains(oid)) {
/* 324 */         performNotification(targetOid, oid, true, false);
/* 325 */         perceiverData.inRangeOids.remove(oid);
/*     */       }
/*     */     }
/*     */     finally {
/* 329 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setRunning(boolean running)
/*     */   {
/* 406 */     this.running = running;
/*     */   }
/*     */ 
/*     */   protected class PerceiverData
/*     */   {
/*     */     OID perceiverOid;
/*     */     Integer reactionRadius;
/*     */     Entity perceiverEntity;
/*     */     InterpolatedWorldNode wnode;
/*     */     Point lastLoc;
/*     */     Point previousLoc;
/* 445 */     Set<OID> perceivedOids = new HashSet();
/*     */ 
/* 447 */     Set<OID> inRangeOids = new HashSet();
/*     */ 
/*     */     public PerceiverData(OID perceiverOid, Integer reactionRadius, InterpolatedWorldNode wnode) {
/* 450 */       this.perceiverOid = perceiverOid;
/* 451 */       this.reactionRadius = reactionRadius;
/* 452 */       this.wnode = wnode;
/* 453 */       this.lastLoc = wnode.getLoc();
/*     */     }
/*     */   }
/*     */ 
/*     */   class Updater
/*     */     implements Runnable
/*     */   {
/*     */     Updater()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 335 */       while (ProximityTracker.this.running) {
/*     */         try {
/* 337 */           update();
/*     */         } catch (AORuntimeException e) {
/* 339 */           Log.exception("ProximityTracker.Updater.run caught AORuntimeException", e);
/*     */         } catch (Exception e) {
/* 341 */           Log.exception("ProximityTracker.Updater.run caught exception", e);
/*     */         }
/*     */         try
/*     */         {
/* 345 */           Thread.sleep(1000L);
/*     */         } catch (InterruptedException e) {
/* 347 */           Log.warn("Updater: " + e);
/* 348 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void update() {
/* 354 */       Log.debug("Updater.update: in update");
/*     */ 
/* 356 */       List perceiverOids = null;
/* 357 */       ProximityTracker.this.lock.lock();
/*     */       try {
/* 359 */         perceiverOids = new ArrayList(ProximityTracker.this.perceiverDataMap.keySet());
/*     */       }
/*     */       finally {
/* 362 */         ProximityTracker.this.lock.unlock();
/*     */       }
/*     */ 
/* 369 */       for (OID perceiverOid : perceiverOids) {
/* 370 */         ProximityTracker.PerceiverData perceiverData = (ProximityTracker.PerceiverData)ProximityTracker.this.perceiverDataMap.get(perceiverOid);
/* 371 */         if (perceiverData != null) {
/* 372 */           perceiverData.previousLoc = perceiverData.lastLoc;
/*     */ 
/* 374 */           perceiverData.lastLoc = perceiverData.wnode.getLoc();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 382 */       for (OID perceiverOid : perceiverOids) {
/* 383 */         perceiverData = (ProximityTracker.PerceiverData)ProximityTracker.this.perceiverDataMap.get(perceiverOid);
/* 384 */         if ((perceiverData == null) || (
/* 388 */           (perceiverData.previousLoc != null) && (Point.distanceToSquared(perceiverData.previousLoc, perceiverData.lastLoc) < 100.0F))) {
/*     */           continue;
/*     */         }
/* 391 */         ArrayList perceivedOids = new ArrayList(perceiverData.perceivedOids);
/* 392 */         for (OID perceivedOid : perceivedOids) {
/* 393 */           ProximityTracker.PerceiverData perceivedData = (ProximityTracker.PerceiverData)ProximityTracker.this.perceiverDataMap.get(perceivedOid);
/* 394 */           if (perceivedData == null)
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 399 */           ProximityTracker.this.testProximity(perceiverData, perceivedData, false, false);
/*     */         }
/*     */       }
/*     */       ProximityTracker.PerceiverData perceiverData;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ProximityTracker
 * JD-Core Version:    0.6.0
 */