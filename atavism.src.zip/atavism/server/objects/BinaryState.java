/*    */ package atavism.server.objects;
/*    */ 
/*    */ public class BinaryState extends ObjState
/*    */ {
/* 45 */   private String name = null;
/* 46 */   private Boolean value = null;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public BinaryState()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BinaryState(String stateName, Boolean value)
/*    */   {
/* 19 */     setStateName(stateName);
/* 20 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Integer getIntValue() {
/* 24 */     return Integer.valueOf(this.value.booleanValue() ? 1 : 0);
/*    */   }
/*    */ 
/*    */   public String getStateName() {
/* 28 */     return this.name;
/*    */   }
/*    */   public void setStateName(String name) {
/* 31 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public Boolean getValue() {
/* 35 */     return this.value;
/*    */   }
/*    */   public void setValue(Boolean val) {
/* 38 */     this.value = val;
/*    */   }
/*    */ 
/*    */   public Boolean isSet() {
/* 42 */     return getValue();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.BinaryState
 * JD-Core Version:    0.6.0
 */