/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.Point;
/*    */ 
/*    */ public class RoadSegment extends AOObject
/*    */ {
/*    */   Point start;
/*    */   Point end;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public RoadSegment()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RoadSegment(OID oid)
/*    */   {
/* 17 */     super(oid);
/*    */   }
/*    */ 
/*    */   public RoadSegment(String name, Point start, Point end) {
/* 21 */     super(name);
/* 22 */     setStart(start);
/* 23 */     setEnd(end);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 27 */     return "[RoadSegment: " + super.toString() + " start=" + getStart() + ", end=" + getEnd() + "]";
/*    */   }
/*    */ 
/*    */   public ObjectType getType()
/*    */   {
/* 36 */     return ObjectTypes.road;
/*    */   }
/*    */ 
/*    */   public void setStart(Point start) {
/* 40 */     this.start = ((Point)start.clone());
/*    */   }
/*    */   public Point getStart() {
/* 43 */     return (Point)this.start.clone();
/*    */   }
/*    */ 
/*    */   public void setEnd(Point end) {
/* 47 */     this.end = ((Point)end.clone());
/*    */   }
/*    */   public Point getEnd() {
/* 50 */     return (Point)this.end.clone();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.RoadSegment
 * JD-Core Version:    0.6.0
 */