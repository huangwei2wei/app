/*    */ package atavism.server.objects;
/*    */ 
/*    */ import atavism.server.engine.Behavior;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.Point;
/*    */ import atavism.server.plugins.MobManagerPlugin;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ import atavism.server.util.Log;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WEObjFactory extends ObjectFactory
/*    */ {
/* 73 */   protected static Map<String, Class<Behavior>> behavClassMap = new HashMap();
/* 74 */   private static final Class[] constructorArgs = { SpawnData.class };
/* 75 */   protected SpawnData spawnData = null;
/*    */ 
/*    */   public ObjectStub makeObject(SpawnData spawnData, OID instanceOid, Point loc)
/*    */   {
/* 24 */     int templateID = spawnData.getTemplateID();
/* 25 */     String behavNames = (String)spawnData.getProperty("Behaviors");
/* 26 */     if (Log.loggingDebug) {
/* 27 */       Log.debug("WEObjFactory.makeObject: templateID=" + templateID + " instanceOid=" + instanceOid + " Behaviors=" + behavNames + " propsize=" + spawnData.getPropertyMap().size());
/*    */     }
/*    */ 
/* 30 */     ObjectStub obj = MobManagerPlugin.createObject(templateID, spawnData.getInstanceOid(), loc, spawnData.getOrientation());
/*    */ 
/* 32 */     if (behavNames != null) {
/* 33 */       for (String behavName : behavNames.split(",")) {
/*    */         try {
/* 35 */           behavName = behavName.trim();
/* 36 */           if (behavName.length() == 0)
/*    */             continue;
/* 38 */           Class behavClass = (Class)behavClassMap.get(behavName);
/* 39 */           if (behavClass == null) {
/* 40 */             Log.error("WEObjFactory.makeObject: unknown behavior=" + behavName + ", templateName=" + this.templateName + " instanceOid=" + instanceOid + " Behaviors=" + behavNames);
/*    */           }
/*    */           else
/*    */           {
/* 46 */             Constructor constructor = behavClass.getConstructor(constructorArgs);
/*    */ 
/* 48 */             if (constructor == null) {
/* 49 */               Log.error("WEObjFactory.makeObject: missing constructor with signature (SpawnData) on class " + behavClass);
/*    */             }
/*    */             else {
/* 52 */               Object[] args = { spawnData };
/* 53 */               Behavior behav = (Behavior)constructor.newInstance(args);
/* 54 */               obj.addBehavior(behav);
/*    */             }
/*    */           }
/*    */         } catch (Exception e) {
/* 56 */           throw new AORuntimeException("can't create behavior", e);
/*    */         }
/*    */       }
/*    */     }
/* 60 */     return obj;
/*    */   }
/*    */ 
/*    */   public static void registerBehaviorClass(String name, String className) {
/*    */     try {
/* 65 */       Class behavClass = Class.forName(className);
/* 66 */       behavClassMap.put(name, behavClass);
/*    */     }
/*    */     catch (ClassNotFoundException e) {
/* 69 */       throw new AORuntimeException("behavior class not found", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.WEObjFactory
 * JD-Core Version:    0.6.0
 */