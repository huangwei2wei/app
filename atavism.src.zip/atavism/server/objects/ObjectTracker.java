/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.msgsys.FilterUpdate;
/*     */ import atavism.msgsys.Message;
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.msgsys.MessageCallback;
/*     */ import atavism.msgsys.MessageDispatch;
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.msgsys.TargetMessage;
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.InterpolatedWorldNode;
/*     */ import atavism.server.engine.Namespace;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.messages.PerceptionFilter;
/*     */ import atavism.server.messages.PerceptionMessage;
/*     */ import atavism.server.messages.PerceptionMessage.ObjectNote;
/*     */ import atavism.server.messages.PerceptionTrigger;
/*     */ import atavism.server.plugins.WorldManagerClient;
/*     */ import atavism.server.plugins.WorldManagerClient.UpdateWorldNodeMessage;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class ObjectTracker
/*     */   implements MessageCallback, MessageDispatch
/*     */ {
/*     */   protected Namespace namespace;
/*     */   protected OID instanceOid;
/*     */   protected EntityWithWorldNodeFactory entityFactory;
/* 658 */   protected float hystericalMargin = 0.0F;
/*     */ 
/* 660 */   protected NotifyReactionRadiusCallback notifyCallback = null;
/*     */ 
/* 662 */   protected RemoteObjectFilter remoteObjectFilter = null;
/*     */ 
/* 668 */   protected Set<OID> localObjects = new HashSet();
/*     */ 
/* 670 */   protected Map<OID, Entry> trackMap = new HashMap();
/*     */ 
/* 672 */   protected Map<OID, NotifyData> reactionRadiusMap = new HashMap();
/*     */   protected TrackerFilter perceptionFilter;
/*     */   protected long perceptionSubId;
/* 677 */   protected Lock lock = LockFactory.makeLock("ObjectTrackerLock");
/*     */ 
/* 679 */   public static final MessageType MSG_TYPE_NOTIFY_REACTION_RADIUS = MessageType.intern("ao.NOTIFY_REACTION_RADIUS");
/*     */ 
/* 681 */   public static final MessageType MSG_TYPE_NOTIFY_AGGRO_RADIUS = MessageType.intern("ao.NOTIFY_AGGRO_RADIUS");
/*     */ 
/*     */   public ObjectTracker(Namespace namespace, OID oid, EntityWithWorldNodeFactory entityFactory, Collection<ObjectType> subjectTypes)
/*     */   {
/*  20 */     initialize(namespace, oid, entityFactory, subjectTypes);
/*     */   }
/*     */ 
/*     */   public ObjectTracker(Namespace namespace, OID instanceOid, EntityWithWorldNodeFactory entityFactory, float hystericalMargin, NotifyReactionRadiusCallback notifyCallback, RemoteObjectFilter remoteObjectFilter)
/*     */   {
/*  27 */     this.hystericalMargin = hystericalMargin;
/*  28 */     this.notifyCallback = notifyCallback;
/*  29 */     this.remoteObjectFilter = remoteObjectFilter;
/*  30 */     initialize(namespace, instanceOid, entityFactory, null);
/*     */   }
/*     */ 
/*     */   private void initialize(Namespace namespace, OID oid, EntityWithWorldNodeFactory entityFactory, Collection<ObjectType> subjectTypes)
/*     */   {
/*  36 */     this.namespace = namespace;
/*  37 */     this.instanceOid = oid;
/*  38 */     this.entityFactory = entityFactory;
/*  39 */     this.perceptionFilter = new TrackerFilter();
/*  40 */     this.perceptionFilter.setTrackedInstanceOid(oid);
/*  41 */     this.perceptionFilter.addType(WorldManagerClient.MSG_TYPE_PERCEPTION);
/*  42 */     this.perceptionFilter.addType(WorldManagerClient.MSG_TYPE_UPDATEWNODE);
/*  43 */     this.perceptionFilter.setMatchAllSubjects(true);
/*  44 */     this.perceptionFilter.setSubjectObjectTypes(subjectTypes);
/*  45 */     PerceptionTrigger perceptionTrigger = new PerceptionTrigger();
/*  46 */     this.perceptionSubId = Engine.getAgent().createSubscription(this.perceptionFilter, this, 0, perceptionTrigger);
/*     */ 
/*  49 */     Log.debug(new StringBuilder().append("ObjectTracker.init created perceptionFilter: ").append(this.perceptionFilter.toString()).toString());
/*     */   }
/*     */ 
/*     */   public OID getInstanceOid()
/*     */   {
/*  54 */     return this.instanceOid;
/*     */   }
/*     */ 
/*     */   public void addLocalObject(OID oid, Integer reactionRadius) {
/*  58 */     this.lock.lock();
/*     */     try
/*     */     {
/*  61 */       if (this.localObjects.contains(oid))
/*     */       {
/*  62 */         Log.error(new StringBuilder().append("ObjectTracker.addLocalObject: oid ").append(oid).append(" is already in the set of local objects, for ObjectTracker instance ").append(this).toString());
/*     */         return;
/*     */       }
/*  68 */       if (reactionRadius != null)
/*  69 */         this.reactionRadiusMap.put(oid, new NotifyData(reactionRadius));
/*  70 */       this.localObjects.add(oid);
/*  71 */       if (this.perceptionFilter.addTarget(oid)) {
/*  72 */         FilterUpdate filterUpdate = new FilterUpdate(1);
/*  73 */         filterUpdate.addFieldValue(1, oid);
/*  74 */         Engine.getAgent().applyFilterUpdate(this.perceptionSubId, filterUpdate);
/*     */       }
/*     */     }
/*     */     finally {
/*  78 */       this.lock.unlock();
/*     */     }
/*  80 */     if (Log.loggingDebug)
/*  81 */       Log.debug(new StringBuilder().append("ObjectTracker.addLocalObject: oid=").append(oid).append(" reactionRadius=").append(reactionRadius).append(" instanceOid=").append(this.instanceOid).toString());
/*     */   }
/*     */ 
/*     */   public boolean hasLocalObject(Long oid)
/*     */   {
/*  87 */     this.lock.lock();
/*     */     try {
/*  89 */       boolean bool = this.localObjects.contains(oid);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void addReactionRadius(OID oid, Integer reactionRadius)
/*     */   {
/*  96 */     if (Log.loggingDebug) {
/*  97 */       Log.debug(new StringBuilder().append("ObjectTracker.addReactionRadius: oid=").append(oid).append(" reactionRadius=").append(reactionRadius).append(" instanceOid=").append(this.instanceOid).toString());
/*     */     }
/*     */ 
/* 100 */     if (reactionRadius != null) {
/* 101 */       this.lock.lock();
/*     */       try {
/* 103 */         this.reactionRadiusMap.put(oid, new NotifyData(reactionRadius));
/*     */       } finally {
/* 105 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAggroRadius(OID oid, OID target, Integer reactionRadius) {
/* 111 */     Log.debug(new StringBuilder().append("ObjectTracker.addAggroRadius: oid=").append(oid).append(" reactionRadius=").append(reactionRadius).append(" instanceOid=").append(this.instanceOid).toString());
/*     */ 
/* 114 */     if (reactionRadius != null) {
/* 115 */       this.lock.lock();
/*     */       try {
/* 117 */         if (this.reactionRadiusMap.containsKey(oid)) {
/* 118 */           NotifyData nData = (NotifyData)this.reactionRadiusMap.get(oid);
/* 119 */           nData.addOidAggroRange(target, reactionRadius.intValue());
/* 120 */           this.reactionRadiusMap.put(oid, nData);
/* 121 */           Log.debug(new StringBuilder().append("Added target: ").append(target).append(" to existing reaction radius entry").toString());
/*     */         }
/*     */         else {
/* 124 */           NotifyData nData = new NotifyData(reactionRadius);
/* 125 */           nData.addOidAggroRange(target, reactionRadius.intValue());
/* 126 */           this.reactionRadiusMap.put(oid, nData);
/* 127 */           Log.debug(new StringBuilder().append("Added target: ").append(target).append(" to new reaction radius entry").toString());
/*     */         }
/*     */       }
/*     */       finally {
/* 131 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeReactionRadius(OID oid) {
/* 137 */     if (Log.loggingDebug) {
/* 138 */       Log.debug(new StringBuilder().append("ObjectTracker.removeReactionRadius: oid=").append(oid).append(" instanceOid=").append(this.instanceOid).toString());
/*     */     }
/* 140 */     this.lock.lock();
/*     */     try {
/* 142 */       this.reactionRadiusMap.remove(oid);
/*     */     } finally {
/* 144 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAggroRadius(OID oid, OID target) {
/* 149 */     Log.debug(new StringBuilder().append("ObjectTracker.removeAggroRadius: oid=").append(oid).append(" instanceOid=").append(this.instanceOid).toString());
/*     */ 
/* 151 */     this.lock.lock();
/*     */     try {
/* 153 */       if (this.reactionRadiusMap.containsKey(oid)) {
/* 154 */         NotifyData nData = (NotifyData)this.reactionRadiusMap.get(oid);
/* 155 */         nData.removeOidAggroRange(target);
/* 156 */         this.reactionRadiusMap.put(oid, nData);
/*     */       }
/*     */     } finally {
/* 159 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean removeLocalObject(OID oid) {
/* 164 */     if (Log.loggingDebug) {
/* 165 */       Log.debug(new StringBuilder().append("removeLocalObject: oid=").append(oid).append(" instanceOid=").append(this.instanceOid).toString());
/*     */     }
/* 167 */     this.lock.lock();
/*     */     try {
/* 169 */       this.localObjects.remove(oid);
/* 170 */       if (this.perceptionFilter.removeTarget(oid)) {
/* 171 */         FilterUpdate filterUpdate = new FilterUpdate(1);
/* 172 */         filterUpdate.removeFieldValue(1, oid);
/*     */ 
/* 174 */         Engine.getAgent().applyFilterUpdate(this.perceptionSubId, filterUpdate);
/*     */       }
/*     */ 
/* 178 */       this.reactionRadiusMap.remove(oid);
/*     */ 
/* 180 */       List trackersToRemove = new ArrayList();
/* 181 */       for (OID objOid : this.trackMap.keySet())
/*     */       {
/* 183 */         while (removeRemoteObject(objOid, oid, trackersToRemove));
/*     */       }
/* 186 */       for (OID objOid : trackersToRemove) {
/* 187 */         this.trackMap.remove(objOid);
/*     */       }
/*     */ 
/* 191 */       for (Map.Entry entry : this.reactionRadiusMap.entrySet()) {
/* 192 */         NotifyData notifyData = (NotifyData)entry.getValue();
/* 193 */         notifyData.removeOidInRadius(oid);
/* 194 */         if (notifyData.hasAggroRadius(oid)) {
/* 195 */           notifyData.removeOidInAggroRadius(oid);
/* 196 */           notifyData.removeOidAggroRange(oid);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 201 */       this.lock.unlock();
/*     */     }
/* 203 */     if (Log.loggingDebug) {
/* 204 */       Log.debug(new StringBuilder().append("ObjectTracker.removeLocalObject: oid=").append(oid).append(" instanceOid=").append(this.instanceOid).toString());
/*     */     }
/* 206 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean maybeAddRemoteObject(PerceptionMessage.ObjectNote objectNote)
/*     */   {
/* 211 */     ObjectType objType = objectNote.getObjectType();
/* 212 */     OID oid = objectNote.getSubject();
/* 213 */     OID trackerOid = objectNote.getTarget();
/* 214 */     boolean callbackNixedIt = false;
/* 215 */     if (this.remoteObjectFilter != null) {
/* 216 */       callbackNixedIt = !this.remoteObjectFilter.objectShouldBeTracked(oid, objectNote);
/*     */     }
/* 218 */     if ((callbackNixedIt) || (!objType.isMob())) {
/* 219 */       if (Log.loggingDebug) {
/* 220 */         Log.debug(new StringBuilder().append("ObjectTracker.maybeAddRemoteObject: ignoring oid=").append(oid).append(" objType=").append(objType).append(" detected by ").append(trackerOid).append(", instanceOid=").append(this.instanceOid).toString());
/*     */       }
/*     */ 
/* 223 */       return false;
/*     */     }
/*     */ 
/* 226 */     if (Log.loggingDebug) {
/* 227 */       Log.debug(new StringBuilder().append("ObjectTracker.maybeAddRemoteObject: oid=").append(oid).append(" objType=").append(objType).append(" detected by ").append(trackerOid).append(", instanceOid=").append(this.instanceOid).toString());
/*     */     }
/*     */ 
/* 230 */     this.lock.lock();
/*     */     try
/*     */     {
/* 233 */       if (this.localObjects.contains(oid)) {
/* 234 */         int i = 0;
/*     */         return i;
/*     */       }
/* 235 */       Entry tracker = (Entry)this.trackMap.get(oid);
/* 236 */       if (tracker == null) {
/* 237 */         tracker = new Entry(oid);
/* 238 */         this.trackMap.put(oid, tracker);
/* 239 */         tracker.activate(objType);
/*     */       }
/* 241 */       tracker.add(trackerOid);
/*     */     } finally {
/* 243 */       this.lock.unlock();
/*     */     }
/* 245 */     return true;
/*     */   }
/*     */ 
/*     */   public List<OID> getOidsInRadius(OID oid) {
/* 249 */     this.lock.lock();
/*     */     try {
/* 251 */       NotifyData nd = (NotifyData)this.reactionRadiusMap.get(oid);
/* 252 */       if (nd != null) {
/* 253 */         localObject1 = nd.getOidsInRadius();
/*     */         return localObject1;
/*     */       }
/* 255 */       Object localObject1 = new LinkedList();
/*     */       return localObject1; } finally { this.lock.unlock(); } throw localObject2;
/*     */   }
/*     */ 
/*     */   protected boolean removeRemoteObject(OID objOid, OID oid, List<OID> trackersToRemove)
/*     */   {
/* 262 */     this.lock.lock();
/*     */     try
/*     */     {
/* 266 */       if (this.localObjects.contains(objOid)) {
/* 267 */         int i = 0;
/*     */         return i;
/*     */       }
/* 268 */       Entry tracker = (Entry)this.trackMap.get(objOid);
/*     */ 
/* 270 */       if ((tracker == null) || ((trackersToRemove != null) && (trackersToRemove.contains(objOid)))) {
/* 271 */         int j = 0;
/*     */         return j;
/*     */       }
/* 273 */       boolean rv = tracker.remove(oid);
/*     */ 
/* 275 */       if (tracker.isEmpty()) {
/* 276 */         tracker.deactivate();
/* 277 */         if (trackersToRemove != null)
/*     */         {
/* 279 */           trackersToRemove.add(objOid);
/*     */         }
/* 281 */         else this.trackMap.remove(objOid);
/*     */ 
/*     */       }
/*     */ 
/* 285 */       boolean bool1 = rv;
/*     */       return bool1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */   public void updateEntity(EntityWithWorldNode ewwn) {
/* 300 */     this.lock.lock();
/*     */     Map mapCopy;
/*     */     try {
/* 303 */       mapCopy = new HashMap(this.reactionRadiusMap);
/*     */     } finally {
/* 305 */       this.lock.unlock();
/*     */     }
/*     */ 
/* 308 */     InterpolatedWorldNode wnode = ewwn.getWorldNode();
/* 309 */     Entity entity = ewwn.getEntity();
/* 310 */     OID oid = entity.getOid();
/* 311 */     if (entity.getType() == ObjectTypes.player) {
/* 312 */       Log.debug(new StringBuilder().append("Checking player perceiver for obj: ").append(oid).toString());
/*     */     }
/* 314 */     for (Map.Entry entry : mapCopy.entrySet()) {
/* 315 */       OID notifyOid = (OID)entry.getKey();
/*     */ 
/* 318 */       if (oid.equals(notifyOid))
/*     */         continue;
/* 320 */       NotifyData notifyData = (NotifyData)entry.getValue();
/* 321 */       EntityWithWorldNode perceiver = (EntityWithWorldNode)EntityManager.getEntityByNamespace(notifyOid, this.namespace);
/*     */ 
/* 323 */       if (perceiver != null)
/*     */       {
/* 325 */         InterpolatedWorldNode perceiverNode = perceiver.getWorldNode();
/* 326 */         if (perceiverNode == null) {
/* 327 */           Log.error(new StringBuilder().append("REACT: percieverNode is null for: ").append(perceiver.getOid()).toString());
/*     */ 
/* 329 */           continue;
/*     */         }
/* 331 */         Point perceiverLocation = perceiverNode.getLoc();
/* 332 */         float distance = Point.distanceTo(perceiverLocation, wnode.getLoc());
/*     */ 
/* 335 */         if (notifyData.hasAggroRadius(oid)) {
/* 336 */           float aggroRadius = notifyData.getAggroRadius(oid);
/*     */ 
/* 340 */           if (distance < aggroRadius) {
/* 341 */             if (!notifyData.isOidInAggroRadius(oid)) {
/* 342 */               notifyData.addOidInAggroRadius(oid);
/*     */ 
/* 345 */               NotifyAggroRadiusMessage nmsg = new NotifyAggroRadiusMessage(notifyOid, oid);
/*     */ 
/* 347 */               Engine.getAgent().sendBroadcast(nmsg);
/*     */             }
/*     */           }
/* 350 */           else notifyData.removeOidInAggroRadius(oid);
/*     */ 
/*     */         }
/*     */ 
/* 354 */         float reactionRadius = notifyData.getReactionRadius().intValue();
/* 355 */         boolean inRadius = distance < reactionRadius;
/* 356 */         boolean wasInRadius = notifyData.isOidInRadius(oid);
/*     */ 
/* 365 */         if (inRadius == wasInRadius)
/*     */           continue;
/* 367 */         if (this.hystericalMargin != 0.0F) {
/* 368 */           if (wasInRadius)
/* 369 */             inRadius = distance < reactionRadius + this.hystericalMargin;
/*     */           else {
/* 371 */             inRadius = distance < reactionRadius - this.hystericalMargin;
/*     */           }
/* 373 */           if (inRadius == wasInRadius)
/*     */             continue;
/*     */         }
/* 376 */         if (inRadius)
/* 377 */           notifyData.addOidInRadius(oid);
/*     */         else
/* 379 */           notifyData.removeOidInRadius(oid);
/* 380 */         if (this.notifyCallback != null) {
/* 381 */           this.notifyCallback.notifyReactionRadius(notifyOid, oid, inRadius, wasInRadius);
/*     */         }
/*     */         else {
/* 384 */           NotifyReactionRadiusMessage nmsg = new NotifyReactionRadiusMessage(notifyOid, oid, inRadius, wasInRadius);
/*     */ 
/* 386 */           Engine.getAgent().sendBroadcast(nmsg);
/*     */         }
/*     */       } else {
/* 389 */         Log.warn(new StringBuilder().append("ObjectTracker.updateEntity: No perceiver for oid ").append(notifyOid).append(" in namespace ").append(this.namespace).toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dispatchMessage(Message message, int flags, MessageCallback callback)
/*     */   {
/* 396 */     Engine.defaultDispatchMessage(message, flags, callback);
/*     */   }
/*     */ 
/*     */   protected void handlePerception(PerceptionMessage perceptionMessage) {
/* 400 */     OID targetOid = perceptionMessage.getTarget();
/* 401 */     List gain = perceptionMessage.getGainObjects();
/*     */ 
/* 403 */     List lost = perceptionMessage.getLostObjects();
/*     */ 
/* 406 */     if (Log.loggingDebug) {
/* 407 */       Log.debug(new StringBuilder().append("ObjectTracker.handlePerception: start instanceOid=").append(this.instanceOid).append(" ").append(gain == null ? 0 : gain.size()).append(" gain and ").append(lost == null ? 0 : lost.size()).append(" lost").toString());
/*     */     }
/*     */ 
/* 412 */     if (gain != null) {
/* 413 */       for (PerceptionMessage.ObjectNote note : gain)
/* 414 */         maybeAddRemoteObject(note);
/*     */     }
/* 416 */     if (lost != null)
/* 417 */       for (PerceptionMessage.ObjectNote note : lost)
/* 418 */         maybeRemoveRemoteObject(note.getSubject(), note, targetOid);
/*     */   }
/*     */ 
/*     */   protected void maybeRemoveRemoteObject(OID subjectOid, PerceptionMessage.ObjectNote objectNote, OID targetOid)
/*     */   {
/* 423 */     if ((this.remoteObjectFilter != null) && (this.remoteObjectFilter.objectShouldBeTracked(subjectOid, objectNote)))
/*     */     {
/* 426 */       return;
/*     */     }
/* 428 */     removeRemoteObject(subjectOid, targetOid, null);
/*     */   }
/*     */ 
/*     */   public void handleMessage(Message msg, int flags) {
/* 432 */     if ((msg instanceof PerceptionMessage)) {
/* 433 */       handlePerception((PerceptionMessage)msg);
/* 434 */     } else if ((msg instanceof WorldManagerClient.UpdateWorldNodeMessage)) {
/* 435 */       WorldManagerClient.UpdateWorldNodeMessage wnodeMsg = (WorldManagerClient.UpdateWorldNodeMessage)msg;
/* 436 */       OID oid = wnodeMsg.getSubject();
/* 437 */       EntityWithWorldNode obj = (EntityWithWorldNode)EntityManager.getEntityByNamespace(oid, this.namespace);
/*     */ 
/* 440 */       if (obj == null) {
/* 441 */         if (Log.loggingDebug) {
/* 442 */           Log.debug(new StringBuilder().append("ObjectTracker.handleMessage: ignoring updateWNMsg for oid ").append(oid).append(" because EntityWithWorldNode for oid not found").toString());
/*     */         }
/*     */ 
/* 445 */         return;
/*     */       }
/* 447 */       BasicWorldNode bwnode = wnodeMsg.getWorldNode();
/* 448 */       InterpolatedWorldNode iwnode = obj.getWorldNode();
/*     */ 
/* 453 */       if (iwnode != null) {
/* 454 */         obj.setDirLocOrient(bwnode);
/*     */       } else {
/* 456 */         iwnode = new InterpolatedWorldNode(bwnode);
/* 457 */         obj.setWorldNode(iwnode);
/*     */       }
/*     */ 
/* 462 */       updateEntity(obj);
/*     */     } else {
/* 464 */       Log.error(new StringBuilder().append("ObjectTracker.handleMessage: unknown message type=").append(msg.getMsgType()).append(" class=").append(msg.getClass().getName()).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class TrackerFilter extends PerceptionFilter
/*     */   {
/*     */     private OID trackedInstanceOid;
/*     */ 
/*     */     public boolean matchRemaining(Message msg)
/*     */     {
/* 628 */       Log.debug("TrackerFilter.match checking message with data: " + msg.toString());
/*     */ 
/* 630 */       if (!super.matchRemaining(msg))
/* 631 */         return false;
/* 632 */       if ((msg instanceof WorldManagerClient.UpdateWorldNodeMessage)) {
/* 633 */         WorldManagerClient.UpdateWorldNodeMessage message = (WorldManagerClient.UpdateWorldNodeMessage)msg;
/* 634 */         OID instanceOid = message.getWorldNode().getInstanceOid();
/* 635 */         Log.debug("TrackerFilter.match checking message with subject: " + message.getSubject() + " instanceOid: " + instanceOid);
/*     */ 
/* 637 */         return instanceOid.equals(this.trackedInstanceOid);
/*     */       }
/* 639 */       return true;
/*     */     }
/*     */ 
/*     */     public OID getTrackedInstanceOid() {
/* 643 */       return this.trackedInstanceOid;
/*     */     }
/*     */ 
/*     */     public void setTrackedInstanceOid(OID instanceOid) {
/* 647 */       this.trackedInstanceOid = instanceOid;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface RemoteObjectFilter
/*     */   {
/*     */     public abstract boolean objectShouldBeTracked(OID paramOID, PerceptionMessage.ObjectNote paramObjectNote);
/*     */   }
/*     */ 
/*     */   public static abstract interface NotifyReactionRadiusCallback
/*     */   {
/*     */     public abstract void notifyReactionRadius(OID paramOID1, OID paramOID2, boolean paramBoolean1, boolean paramBoolean2);
/*     */   }
/*     */ 
/*     */   protected class NotifyData
/*     */   {
/*     */     protected Integer reactionRadius;
/*     */     protected Set<OID> oidsInRadius;
/*     */     protected HashMap<OID, Integer> aggroRadii;
/*     */     protected Set<OID> oidsInAggroRadius;
/*     */ 
/*     */     NotifyData(Integer reactionRadius)
/*     */     {
/* 548 */       this.reactionRadius = reactionRadius;
/* 549 */       this.oidsInRadius = new HashSet();
/* 550 */       this.aggroRadii = new HashMap();
/* 551 */       this.oidsInAggroRadius = new HashSet();
/*     */     }
/*     */ 
/*     */     Integer getReactionRadius() {
/* 555 */       return this.reactionRadius;
/*     */     }
/*     */ 
/*     */     boolean isOidInRadius(OID oid)
/*     */     {
/* 560 */       return this.oidsInRadius.contains(oid);
/*     */     }
/*     */ 
/*     */     boolean addOidInRadius(OID oid)
/*     */     {
/* 565 */       return this.oidsInRadius.add(oid);
/*     */     }
/*     */ 
/*     */     boolean removeOidInRadius(OID oid)
/*     */     {
/* 570 */       return this.oidsInRadius.remove(oid);
/*     */     }
/*     */ 
/*     */     List<OID> getOidsInRadius() {
/* 574 */       return new LinkedList(this.oidsInRadius);
/*     */     }
/*     */ 
/*     */     void addOidAggroRange(OID oid, int aggroRange) {
/* 578 */       this.aggroRadii.put(oid, Integer.valueOf(aggroRange));
/*     */     }
/*     */ 
/*     */     void removeOidAggroRange(OID target) {
/* 582 */       this.aggroRadii.remove(target);
/*     */     }
/*     */ 
/*     */     int getAggroRadius(OID oid) {
/* 586 */       return ((Integer)this.aggroRadii.get(oid)).intValue();
/*     */     }
/*     */ 
/*     */     boolean hasAggroRadius(OID oid)
/*     */     {
/* 591 */       return this.aggroRadii.containsKey(oid);
/*     */     }
/*     */ 
/*     */     boolean isOidInAggroRadius(OID oid)
/*     */     {
/* 596 */       return this.oidsInAggroRadius.contains(oid);
/*     */     }
/*     */ 
/*     */     boolean addOidInAggroRadius(OID oid)
/*     */     {
/* 601 */       return this.oidsInAggroRadius.add(oid);
/*     */     }
/*     */ 
/*     */     boolean removeOidInAggroRadius(OID oid)
/*     */     {
/* 606 */       return this.oidsInAggroRadius.remove(oid);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class Entry extends LinkedList<OID>
/*     */   {
/*     */     protected OID oid;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public Entry(OID oid)
/*     */     {
/* 514 */       this.oid = oid;
/*     */     }
/*     */ 
/*     */     public void activate(ObjectType objType)
/*     */     {
/* 520 */       EntityWithWorldNode obj = ObjectTracker.this.entityFactory.createEntity(this.oid, null, -1);
/*     */ 
/* 522 */       Entity entity = obj.getEntity();
/* 523 */       entity.setType(objType);
/* 524 */       if (Log.loggingDebug) {
/* 525 */         Log.debug("ObjectTracker.Entry.activate: obj=" + obj + " objType=" + objType);
/*     */       }
/* 527 */       EntityManager.registerEntityByNamespace((Entity)obj, ObjectTracker.this.namespace);
/*     */     }
/*     */ 
/*     */     public void deactivate() {
/* 531 */       if (Log.loggingDebug) {
/* 532 */         Log.debug("ObjectTracker.Entry.deactivate: oid=" + this.oid + " instanceOid=" + ObjectTracker.this.instanceOid + " namespace=" + ObjectTracker.this.namespace.getName());
/*     */       }
/*     */ 
/* 535 */       EntityManager.removeEntityByNamespace(this.oid, ObjectTracker.this.namespace);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class NotifyAggroRadiusMessage extends TargetMessage
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public NotifyAggroRadiusMessage()
/*     */     {
/*     */     }
/*     */ 
/*     */     public NotifyAggroRadiusMessage(OID notifyOid, OID subjectOid)
/*     */     {
/* 506 */       super(notifyOid, subjectOid);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class NotifyReactionRadiusMessage extends TargetMessage
/*     */   {
/*     */     protected boolean inRadius;
/*     */     protected boolean wasInRadius;
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public NotifyReactionRadiusMessage()
/*     */     {
/*     */     }
/*     */ 
/*     */     public NotifyReactionRadiusMessage(OID notifyOid, OID subjectOid, boolean inRadius, boolean wasInRadius)
/*     */     {
/* 474 */       super(notifyOid, subjectOid);
/* 475 */       this.inRadius = inRadius;
/* 476 */       this.wasInRadius = wasInRadius;
/*     */     }
/*     */ 
/*     */     public void setInRadius(boolean value)
/*     */     {
/* 483 */       this.inRadius = value;
/*     */     }
/*     */ 
/*     */     public boolean getInRadius() {
/* 487 */       return this.inRadius;
/*     */     }
/*     */ 
/*     */     public void setWasInRadius(boolean value) {
/* 491 */       this.wasInRadius = value;
/*     */     }
/*     */ 
/*     */     public boolean getWasInRadius() {
/* 495 */       return this.wasInRadius;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.ObjectTracker
 * JD-Core Version:    0.6.0
 */