/*     */ package atavism.server.objects;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class TerrainDecalData
/*     */   implements Serializable
/*     */ {
/* 101 */   private String imageName = null;
/* 102 */   private int posX = 0;
/* 103 */   private int posZ = 0;
/* 104 */   private float sizeX = 0.0F;
/* 105 */   private float sizeZ = 0.0F;
/* 106 */   private float rotation = 0.0F;
/* 107 */   private int priority = 0;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public TerrainDecalData()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TerrainDecalData(String imageName, int posX, int posZ, float sizeX, float sizeZ, float rotation, int priority)
/*     */   {
/*  33 */     setImageName(imageName);
/*  34 */     setPosX(posX);
/*  35 */     setPosZ(posZ);
/*  36 */     setSizeX(sizeX);
/*  37 */     setSizeZ(sizeZ);
/*  38 */     setRotation(rotation);
/*  39 */     setPriority(priority);
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  43 */     return "[TerrainDecalData: ImageName=" + getImageName() + ", PosX=" + getPosX() + ", PosZ=" + getPosZ() + ", SizeX=" + getSizeX() + ", SizeZ=" + getSizeZ() + ", Rotation=" + getRotation() + ", Priority=" + getPriority() + "]";
/*     */   }
/*     */ 
/*     */   public void setImageName(String imageName)
/*     */   {
/*  55 */     this.imageName = imageName;
/*     */   }
/*     */   public String getImageName() {
/*  58 */     return this.imageName;
/*     */   }
/*     */ 
/*     */   public void setPosX(int val) {
/*  62 */     this.posX = val;
/*     */   }
/*     */   public int getPosX() {
/*  65 */     return this.posX;
/*     */   }
/*     */   public void setPosZ(int val) {
/*  68 */     this.posZ = val;
/*     */   }
/*     */   public int getPosZ() {
/*  71 */     return this.posZ;
/*     */   }
/*     */ 
/*     */   public void setSizeX(float val) {
/*  75 */     this.sizeX = val;
/*     */   }
/*     */   public float getSizeX() {
/*  78 */     return this.sizeX;
/*     */   }
/*     */   public void setSizeZ(float val) {
/*  81 */     this.sizeZ = val;
/*     */   }
/*     */   public float getSizeZ() {
/*  84 */     return this.sizeZ;
/*     */   }
/*     */ 
/*     */   public void setRotation(float val) {
/*  88 */     this.rotation = val;
/*     */   }
/*     */   public float getRotation() {
/*  91 */     return this.rotation;
/*     */   }
/*     */ 
/*     */   public void setPriority(int val) {
/*  95 */     this.priority = val;
/*     */   }
/*     */   public int getPriority() {
/*  98 */     return this.priority;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.TerrainDecalData
 * JD-Core Version:    0.6.0
 */