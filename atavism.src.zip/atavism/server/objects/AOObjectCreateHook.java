package atavism.server.objects;

public abstract interface AOObjectCreateHook
{
  public abstract void objectCreateHook(AOObject paramAOObject);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.AOObjectCreateHook
 * JD-Core Version:    0.6.0
 */