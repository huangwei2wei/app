/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.engine.PropertySearch;
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class Region
/*     */   implements Serializable
/*     */ {
/*  83 */   public static Integer DEFAULT_PRIORITY = Integer.valueOf(100);
/*     */   public static final long PROP_BOUNDARY = 1L;
/*     */   public static final long PROP_PROPERTIES = 2L;
/*     */   public static final long PROP_ALL = 3L;
/* 215 */   public static final ObjectType OBJECT_TYPE = ObjectType.intern(22, "Region");
/*     */ 
/* 218 */   private transient Lock lock = null;
/* 219 */   private String name = null;
/* 220 */   private Integer pri = DEFAULT_PRIORITY;
/* 221 */   private Boundary boundary = null;
/*     */ 
/* 223 */   private Map<String, RegionConfig> configMap = new HashMap();
/*     */   private Map<String, Serializable> properties;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public Region()
/*     */   {
/*  29 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public Region(String name) {
/*  33 */     setupTransient();
/*  34 */     setName(name);
/*     */   }
/*     */ 
/*     */   private void setupTransient() {
/*  38 */     this.lock = LockFactory.makeLock("RegionLock");
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/*  43 */     in.defaultReadObject();
/*  44 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  48 */     String s = "[Region: name=" + this.name + " ";
/*  49 */     s = s + getBoundary();
/*  50 */     for (RegionConfig regionConfig : getConfigs()) {
/*  51 */       s = s + " config=" + regionConfig;
/*     */     }
/*  53 */     if (this.properties != null)
/*  54 */       s = s + " property count=" + this.properties.size();
/*  55 */     s = s + "]";
/*  56 */     return s;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  61 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  66 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setPriority(Integer priority)
/*     */   {
/*  75 */     this.pri = priority;
/*     */   }
/*     */ 
/*     */   public Integer getPriority()
/*     */   {
/*  80 */     return this.pri == null ? DEFAULT_PRIORITY : this.pri;
/*     */   }
/*     */ 
/*     */   public void setBoundary(Boundary b)
/*     */   {
/*  89 */     this.boundary = ((Boundary)b.clone());
/*     */   }
/*     */ 
/*     */   public Boundary getBoundary()
/*     */   {
/*  95 */     return (Boundary)this.boundary.clone();
/*     */   }
/*     */ 
/*     */   public void addConfig(RegionConfig config)
/*     */   {
/* 102 */     this.lock.lock();
/*     */     try {
/* 104 */       this.configMap.put(config.getType(), config);
/*     */     } finally {
/* 106 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public RegionConfig getConfig(String type)
/*     */   {
/* 113 */     this.lock.lock();
/*     */     try {
/* 115 */       RegionConfig localRegionConfig = (RegionConfig)this.configMap.get(type);
/*     */       return localRegionConfig; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Collection<RegionConfig> getConfigs()
/*     */   {
/* 124 */     this.lock.lock();
/*     */     try {
/* 126 */       Collection localCollection = this.configMap.values();
/*     */       return localCollection; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Serializable getProperty(String key)
/*     */   {
/* 139 */     if (this.properties == null)
/* 140 */       return null;
/* 141 */     return (Serializable)this.properties.get(key);
/*     */   }
/*     */ 
/*     */   public Serializable setProperty(String key, Serializable value)
/*     */   {
/* 151 */     if (this.properties == null)
/* 152 */       this.properties = new HashMap();
/* 153 */     return (Serializable)this.properties.put(key, value);
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getPropertyMapRef()
/*     */   {
/* 161 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public void setProperties(Map<String, Serializable> props)
/*     */   {
/* 168 */     if (props != null)
/* 169 */       this.properties = new HashMap(props);
/*     */     else
/* 171 */       this.properties = null;
/*     */   }
/*     */ 
/*     */   public static class Search extends PropertySearch
/*     */   {
/*     */     private OID instanceOid;
/*     */ 
/*     */     public Search()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Search(OID instanceOid, Map queryProps)
/*     */     {
/* 199 */       super();
/* 200 */       setInstanceOid(instanceOid);
/*     */     }
/*     */ 
/*     */     public OID getInstanceOid()
/*     */     {
/* 205 */       return this.instanceOid;
/*     */     }
/*     */ 
/*     */     public void setInstanceOid(OID oid) {
/* 209 */       this.instanceOid = oid;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.Region
 * JD-Core Version:    0.6.0
 */