/*     */ package atavism.server.objects;
/*     */ 
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class NamedPropertyClass
/*     */   implements Serializable
/*     */ {
/* 180 */   protected transient Lock lock = null;
/*     */ 
/* 182 */   protected String name = null;
/*     */ 
/* 184 */   private Map<String, Serializable> propertyMap = new HashMap();
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public NamedPropertyClass()
/*     */   {
/*  15 */     setupTransient();
/*     */   }
/*     */ 
/*     */   public NamedPropertyClass(String name) {
/*  19 */     setupTransient();
/*  20 */     setName(name);
/*     */   }
/*     */ 
/*     */   protected void setupTransient()
/*     */   {
/*  25 */     this.lock = LockFactory.makeLock("NamedPropertyLock");
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  33 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  41 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public Serializable setProperty(String key, Serializable value)
/*     */   {
/*  61 */     this.lock.lock();
/*     */     try {
/*  63 */       Serializable localSerializable = (Serializable)this.propertyMap.put(key, value);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Serializable getProperty(String key)
/*     */   {
/*  76 */     this.lock.lock();
/*     */     try {
/*  78 */       Serializable localSerializable = (Serializable)this.propertyMap.get(key);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Serializable removeProperty(String key)
/*     */   {
/*  90 */     this.lock.lock();
/*     */     try {
/*  92 */       Serializable localSerializable = (Serializable)this.propertyMap.remove(key);
/*     */       return localSerializable; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public String getStringProperty(String key)
/*     */   {
/*  99 */     return (String)getProperty(key);
/*     */   }
/*     */ 
/*     */   public boolean getBooleanProperty(String key)
/*     */   {
/* 106 */     Boolean val = (Boolean)getProperty(key);
/* 107 */     if (val == null) {
/* 108 */       return false;
/*     */     }
/* 110 */     return val.booleanValue();
/*     */   }
/*     */ 
/*     */   public Integer getIntProperty(String key) {
/* 114 */     return (Integer)getProperty(key);
/*     */   }
/*     */ 
/*     */   public Integer modifyIntProperty(String key, int delta)
/*     */   {
/* 125 */     this.lock.lock();
/*     */     try {
/* 127 */       Integer val = (Integer)this.propertyMap.get(key);
/* 128 */       val = new Integer(delta + val.intValue());
/* 129 */       Integer localInteger1 = (Integer)this.propertyMap.put(key, val);
/*     */       return localInteger1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getPropertyMap()
/*     */   {
/* 139 */     this.lock.lock();
/*     */     try {
/* 141 */       HashMap newMap = new HashMap(this.propertyMap);
/* 142 */       HashMap localHashMap1 = newMap;
/*     */       return localHashMap1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setPropertyMap(Map<String, Serializable> propMap)
/*     */   {
/* 152 */     this.lock.lock();
/*     */     try {
/* 154 */       if (this.propertyMap == null) {
/* 155 */         throw new RuntimeException("NamedPropertyClass prop map is null: " + getName());
/*     */       }
/* 157 */       this.propertyMap = new HashMap(propMap);
/*     */     } finally {
/* 159 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getPropertyMapRef() {
/* 164 */     return this.propertyMap;
/*     */   }
/*     */ 
/*     */   public void lock()
/*     */   {
/* 169 */     this.lock.lock();
/*     */   }
/*     */ 
/*     */   public void unlock()
/*     */   {
/* 174 */     this.lock.unlock();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.NamedPropertyClass
 * JD-Core Version:    0.6.0
 */