/*    */ package atavism.server.objects;
/*    */ 
/*    */ public class PointLight extends Light
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public PointLight()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PointLight(String name)
/*    */   {
/* 12 */     super(name);
/*    */   }
/*    */ 
/*    */   public PointLight(String name, Color diffuse, Color specular, float attenuationRange, float attenuationConstant, float attenuationLinear, float attenuationQuadradic)
/*    */   {
/* 25 */     super(name, diffuse, specular, attenuationRange, attenuationConstant, attenuationLinear, attenuationQuadradic);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 36 */     return "[PointLight: " + super.toString() + "]";
/*    */   }
/*    */ 
/*    */   public Object clone() {
/* 40 */     PointLight l = new PointLight(getName(), getDiffuse(), getSpecular(), getAttenuationRange(), getAttenuationConstant(), getAttenuationLinear(), getAttenuationQuadradic());
/*    */ 
/* 47 */     return l;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.objects.PointLight
 * JD-Core Version:    0.6.0
 */