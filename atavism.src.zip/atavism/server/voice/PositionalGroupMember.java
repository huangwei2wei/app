/*    */ package atavism.server.voice;
/*    */ 
/*    */ import atavism.server.engine.InterpolatedWorldNode;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.Point;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class PositionalGroupMember extends GroupMember
/*    */ {
/*    */   public InterpolatedWorldNode wnode;
/*    */   public Point lastLoc;
/*    */   public Point previousLoc;
/* 79 */   public Set<OID> perceivedOids = new HashSet();
/*    */ 
/* 84 */   public Set<PositionalGroupMember> membersInRadius = new HashSet();
/*    */ 
/*    */   public PositionalGroupMember(VoiceGroup group, OID memberOid, int priority, boolean allowedSpeaker, boolean currentSpeaker, VoiceConnection memberCon, int maxVoiceChannels)
/*    */   {
/* 31 */     super(group, memberOid, priority, allowedSpeaker, currentSpeaker, memberCon, maxVoiceChannels);
/* 32 */     if (memberCon.listenToYourself)
/* 33 */       this.membersInRadius.add(this);
/*    */   }
/*    */ 
/*    */   public OID getInstanceOid()
/*    */   {
/* 41 */     if (this.wnode != null) {
/* 42 */       return this.wnode.getInstanceOid();
/*    */     }
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */   public Point getCurrentLoc()
/*    */   {
/* 52 */     if (this.wnode != null) {
/* 53 */       return this.wnode.getCurrentLoc();
/*    */     }
/* 55 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.PositionalGroupMember
 * JD-Core Version:    0.6.0
 */