/*     */ package atavism.server.voice;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.plugins.VoiceClient;
/*     */ import atavism.server.plugins.WorldManagerClient.ExtensionMessage;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public abstract class BasicVoiceGroup
/*     */   implements VoiceGroup
/*     */ {
/*     */   protected OID groupOid;
/*     */   protected Object association;
/* 623 */   protected VoiceSender voiceSender = null;
/*     */   protected int maxVoices;
/* 634 */   public int defaultPriority = 0;
/*     */ 
/* 641 */   protected Set<OID> allowedMembers = null;
/*     */   protected Map<OID, GroupMember> members;
/* 651 */   protected static boolean loggingRecomputeVoices = false;
/*     */ 
/* 656 */   protected transient Lock lock = LockFactory.makeLock("BasicVoiceGroup");
/*     */ 
/*     */   public BasicVoiceGroup(OID groupOid, Object association, VoiceSender voiceSender, int maxVoices)
/*     */   {
/*  31 */     this.groupOid = groupOid;
/*  32 */     this.association = association;
/*  33 */     this.voiceSender = voiceSender;
/*  34 */     this.maxVoices = maxVoices;
/*  35 */     this.members = new HashMap();
/*     */   }
/*     */ 
/*     */   public OID getGroupOid()
/*     */   {
/*  43 */     return this.groupOid;
/*     */   }
/*     */ 
/*     */   public boolean addMemberAllowed(OID memberOid)
/*     */   {
/*  56 */     if (memberOid == null) {
/*  57 */       if (Log.loggingDebug)
/*  58 */         Log.debug("BasicVoiceGroup.addMemberAllowed: memberOid is null, so member not allowed");
/*  59 */       return false;
/*     */     }
/*  61 */     if (this.allowedMembers != null) {
/*  62 */       boolean allowed = this.allowedMembers.contains(memberOid);
/*  63 */       if ((!allowed) && (Log.loggingDebug))
/*  64 */         Log.debug(new StringBuilder().append("BasicVoiceGroup.addMemberAllowed: allowedMembers does not contain memberOid ").append(memberOid).append(", so member not allowed").toString());
/*  65 */       return allowed;
/*     */     }
/*     */ 
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   public GroupMember addMember(OID memberOid, VoiceConnection memberCon)
/*     */   {
/*  79 */     return addMember(memberOid, memberCon, getDefaultPriority(), true);
/*     */   }
/*     */ 
/*     */   public void setAllowedMembers(Set<OID> allowedMembers)
/*     */   {
/*  87 */     this.allowedMembers = allowedMembers;
/*     */   }
/*     */ 
/*     */   public Set<OID> getAllowedMembers()
/*     */   {
/*  95 */     return this.allowedMembers;
/*     */   }
/*     */ 
/*     */   public abstract GroupMember addMember(OID paramOID, VoiceConnection paramVoiceConnection, int paramInt, boolean paramBoolean);
/*     */ 
/*     */   public void onAfterAddMember(OID memberOid, OID groupOid, boolean allowedSpeaker, byte micVoiceNumber, boolean listenToYourself)
/*     */   {
/* 125 */     WorldManagerClient.ExtensionMessage msg = new WorldManagerClient.ExtensionMessage();
/* 126 */     msg.setMsgType(VoiceClient.MSG_TYPE_VOICE_MEMBER_ADDED);
/* 127 */     msg.setProperty("memberOid", memberOid);
/* 128 */     msg.setProperty("groupOid", groupOid);
/* 129 */     msg.setProperty("allowedSpeaker", Boolean.valueOf(allowedSpeaker));
/* 130 */     msg.setProperty("micVoiceNumber", Integer.valueOf(micVoiceNumber));
/* 131 */     msg.setProperty("listenToYourself", Boolean.valueOf(listenToYourself));
/* 132 */     this.voiceSender.sendExtensionMessage(msg);
/*     */   }
/*     */ 
/*     */   public abstract boolean isPositional();
/*     */ 
/*     */   protected abstract void changeSpeaking(GroupMember paramGroupMember, boolean paramBoolean);
/*     */ 
/*     */   protected abstract void changeListening(GroupMember paramGroupMember, boolean paramBoolean);
/*     */ 
/*     */   protected abstract void recomputeListenerVoices(GroupMember paramGroupMember);
/*     */ 
/*     */   public boolean removeMember(OID memberOid)
/*     */   {
/* 175 */     if (Log.loggingDebug)
/* 176 */       Log.debug(new StringBuilder().append("BasicVoiceGroup.removeMember: For group ").append(this.groupOid).append(", called to remove member ").append(memberOid).toString());
/* 177 */     this.lock.lock();
/*     */     try {
/* 179 */       GroupMember member = isMember(memberOid);
/* 180 */       if (member != null) {
/* 181 */         if (member.allowedSpeaker)
/* 182 */           setAllowedSpeaker(member, false);
/* 183 */         if (member.listening) {
/* 184 */           setListener(member, false);
/*     */         }
/* 186 */         if (this.members.remove(memberOid) == null)
/* 187 */           Log.error(new StringBuilder().append("BasicVoiceGroup.removeMember: For group ").append(this.groupOid).append(", didn't find member ").append(memberOid).append(" in member map!").toString());
/* 188 */         else if (Log.loggingDebug)
/* 189 */           Log.debug(new StringBuilder().append("BasicVoiceGroup.removeMember: For group ").append(this.groupOid).append(", removed member ").append(memberOid).toString());
/*     */       }
/*     */       else {
/* 192 */         Log.info(new StringBuilder().append("BasicVoiceGroup.removeMember: For group ").append(this.groupOid).append(", member ").append(memberOid).append(" not found!").toString());
/* 193 */       }if (member != null)
/* 194 */         onAfterRemoveMember(memberOid, this.groupOid, member.allowedSpeaker);
/* 195 */       int i = member != null ? 1 : 0;
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void onAfterRemoveMember(OID memberOid, OID groupOid, boolean allowedSpeaker)
/*     */   {
/* 210 */     WorldManagerClient.ExtensionMessage msg = new WorldManagerClient.ExtensionMessage();
/* 211 */     msg.setMsgType(VoiceClient.MSG_TYPE_VOICE_MEMBER_REMOVED);
/* 212 */     msg.setProperty("memberOid", memberOid);
/* 213 */     msg.setProperty("groupOid", groupOid);
/* 214 */     msg.setProperty("allowedSpeaker", Boolean.valueOf(allowedSpeaker));
/* 215 */     this.voiceSender.sendExtensionMessage(msg);
/*     */   }
/*     */ 
/*     */   public GroupMember isMember(OID memberOid)
/*     */   {
/* 227 */     return (GroupMember)this.members.get(memberOid);
/*     */   }
/*     */ 
/*     */   public int getDefaultPriority()
/*     */   {
/* 235 */     return this.defaultPriority;
/*     */   }
/*     */ 
/*     */   public void setAllowedSpeaker(OID memberOid, boolean add)
/*     */   {
/* 245 */     this.lock.lock();
/*     */     try {
/* 247 */       GroupMember member = getMember(memberOid);
/* 248 */       if (member != null)
/* 249 */         setAllowedSpeaker(member, add);
/*     */     }
/*     */     finally {
/* 252 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setAllowedSpeaker(GroupMember member, boolean add)
/*     */   {
/* 265 */     this.lock.lock();
/*     */     try {
/* 267 */       if (member.allowedSpeaker == add) {
/* 268 */         Log.error(new StringBuilder().append("BasicVoiceGroup.setAllowedSpeaker: Group ").append(this.groupOid).append(" member ").append(member.memberOid).append(", add ").append(add).append(".  Condition already true!").toString());
/*     */       }
/* 273 */       else if (add) {
/* 274 */         member.allowedSpeaker = true;
/*     */       } else {
/* 276 */         if (member.currentSpeaker)
/* 277 */           changeSpeaking(member, false);
/* 278 */         member.allowedSpeaker = false;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 283 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isAllowedSpeaker(OID memberOid)
/*     */   {
/* 296 */     GroupMember member = getMember(memberOid);
/* 297 */     if (member == null) {
/* 298 */       return false;
/*     */     }
/* 300 */     return member.allowedSpeaker;
/*     */   }
/*     */ 
/*     */   public void setMemberSpeaking(OID memberOid, boolean add)
/*     */   {
/* 312 */     this.lock.lock();
/*     */     try {
/* 314 */       GroupMember member = getMember(memberOid);
/* 315 */       if (member == null)
/* 316 */         Log.error(new StringBuilder().append("BasicVoiceGroup.setMemberSpeaking: memberOid ").append(memberOid).append(", add ").append(add).append(" could not be found in group ").append(this.groupOid).toString());
/* 317 */       else if ((member.allowedSpeaker) && (member.currentSpeaker == add)) {
/* 318 */         Log.dumpStack(new StringBuilder().append("BasicVoiceGroup.setMemberSpeaking: Group ").append(this.groupOid).append(" member ").append(member.memberOid).append(", add ").append(add).append(".  Condition already true!").toString());
/*     */       }
/* 320 */       else if (add) {
/* 321 */         if (member.allowedSpeaker)
/* 322 */           changeSpeaking(member, true);
/*     */       }
/*     */       else
/* 325 */         changeSpeaking(member, false);
/*     */     }
/*     */     finally {
/* 328 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isMemberSpeaking(OID memberOid)
/*     */   {
/* 341 */     GroupMember member = getMember(memberOid);
/* 342 */     if (member == null) {
/* 343 */       return false;
/*     */     }
/* 345 */     return member.currentSpeaker;
/*     */   }
/*     */ 
/*     */   public boolean isListener(OID memberOid)
/*     */   {
/* 357 */     GroupMember member = getMember(memberOid);
/* 358 */     if (member == null) {
/* 359 */       return false;
/*     */     }
/* 361 */     return member.listening;
/*     */   }
/*     */ 
/*     */   public void setListener(OID memberOid, boolean add)
/*     */   {
/* 375 */     this.lock.lock();
/*     */     try {
/* 377 */       GroupMember member = getMember(memberOid);
/* 378 */       if (member != null)
/* 379 */         setListener(member, add);
/*     */       else
/* 381 */         Log.error(new StringBuilder().append("BasicVoiceGroup.setListener: Group ").append(this.groupOid).append(" member ").append(memberOid).append(", could not find member!").toString());
/*     */     }
/*     */     finally
/*     */     {
/* 385 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setListener(GroupMember member, boolean add)
/*     */   {
/* 400 */     this.lock.lock();
/*     */     try {
/* 402 */       if (member.listening == add) {
/* 403 */         Log.error(new StringBuilder().append("BasicVoiceGroup.setListener: Group ").append(this.groupOid).append(" member ").append(member.memberOid).append(", add ").append(add).append(".  Condition already true!").toString());
/*     */       }
/*     */       else {
/* 406 */         member.listening = add;
/* 407 */         changeListening(member, add);
/*     */       }
/*     */     }
/*     */     finally {
/* 411 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void endListeningToSpeaker(GroupMember speaker, GroupMember listener, byte voiceNumber)
/*     */   {
/* 425 */     listener.setSpeakerForVoiceNumber(voiceNumber, null);
/* 426 */     if (Log.loggingDebug) {
/* 427 */       Log.debug(new StringBuilder().append("BasicVoiceGroup.endListeningToSpeaker: Sending dealloc of speaker ").append(speaker).append(" to listener ").append(listener).append(", voiceNumber ").append(voiceNumber).toString());
/*     */     }
/* 429 */     this.voiceSender.sendDeallocateVoice(speaker.memberCon, listener.memberCon, voiceNumber);
/*     */   }
/*     */ 
/*     */   protected boolean eligibleSpeakerListenerPair(GroupMember speaker, GroupMember listener)
/*     */   {
/* 441 */     boolean sameMember = speaker == listener;
/* 442 */     boolean sameOid = speaker.getMemberOid() == listener.getMemberOid();
/* 443 */     if ((sameOid) && (!sameMember)) {
/* 444 */       Log.warn(new StringBuilder().append("BasicVoiceGroup.eligibleSpeakerListenerPair: Speaker and listener both have memberOid ").append(speaker.getMemberOid()).append(" but they are not the same object. speaker.expunged ").append(speaker.getExpunged()).append(", listener.expunged ").append(listener.getExpunged()).toString());
/*     */     }
/*     */ 
/* 447 */     return (!listener.speakerIgnored(speaker)) && ((!sameOid) || (speaker.memberCon.listenToYourself));
/*     */   }
/*     */ 
/*     */   protected GroupMember getMember(OID oid) {
/* 451 */     GroupMember member = (GroupMember)this.members.get(oid);
/* 452 */     if (member == null) {
/* 453 */       return null;
/*     */     }
/*     */ 
/* 456 */     return member;
/*     */   }
/*     */ 
/*     */   public void getAllMembers(List<GroupMember> memberList)
/*     */   {
/* 465 */     memberList.addAll(this.members.values());
/*     */   }
/*     */ 
/*     */   public void sendVoiceFrameToListeners(OID speakerOid, AOByteBuffer buf, byte opcode, int pktSize)
/*     */   {
/* 479 */     this.lock.lock();
/*     */     try {
/* 481 */       speaker = getMember(speakerOid);
/* 482 */       if ((speaker != null) && (speaker.allowedSpeaker)) {
/* 483 */         List listenersToSpeaker = speaker.membersListeningToSpeaker();
/* 484 */         for (GroupMember listener : listenersToSpeaker)
/* 485 */           if (eligibleSpeakerListenerPair(speaker, listener)) {
/* 486 */             Byte voiceNumber = listener.findVoiceNumberForSpeaker(speaker);
/* 487 */             if (voiceNumber == null) {
/* 488 */               Log.error(new StringBuilder().append("PositionalVoiceGroup.sendVoiceFrameToListeners: Voice number for speaker ").append(speaker).append(" and listener ").append(listener).append(" is null!").toString());
/*     */             }
/*     */             else
/* 491 */               this.voiceSender.sendVoiceFrame(speaker.memberCon, listener.memberCon, opcode, voiceNumber.byteValue(), buf, (short)pktSize);
/*     */           }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       GroupMember speaker;
/* 498 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void recomputeVoicesFromSpeakerIterator(GroupMember listener, Iterator<GroupMember> memberIterator, int count)
/*     */   {
/* 516 */     if (!listener.listening) {
/* 517 */       for (byte i = 0; i < this.maxVoices; i = (byte)(i + 1)) {
/* 518 */         GroupMember speaker = listener.getSpeakerForVoiceNumber(i);
/* 519 */         if ((speaker == null) || (!eligibleSpeakerListenerPair(speaker, listener)))
/*     */         {
/*     */           continue;
/*     */         }
/* 523 */         endListeningToSpeaker(speaker, listener, i);
/*     */       }
/* 525 */       if (Log.loggingDebug)
/* 526 */         Log.debug("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: Returning because !listener.listening");
/* 527 */       return;
/*     */     }
/* 529 */     GroupMember[] newVoiceNumberToMember = new GroupMember[this.maxVoices];
/*     */ 
/* 532 */     byte priorityCount = 0;
/* 533 */     while ((priorityCount < count) && (memberIterator.hasNext())) {
/* 534 */       GroupMember speaker = (GroupMember)memberIterator.next();
/* 535 */       if ((loggingRecomputeVoices) && (Log.loggingDebug)) {
/* 536 */         Log.debug(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: In while loop; priorityCount ").append(priorityCount).append(", speaker ").append(speaker).append(", listener ").append(listener).toString());
/*     */       }
/*     */ 
/* 539 */       if (eligibleSpeakerListenerPair(speaker, listener)) {
/* 540 */         if ((loggingRecomputeVoices) && (Log.loggingDebug))
/* 541 */           Log.debug(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: Eligible!: equal ").append(speaker == listener).append(", speaker listenToYourself ").append(speaker.memberCon.listenToYourself).toString());
/* 542 */         newVoiceNumberToMember[priorityCount] = speaker;
/* 543 */         speaker.priorityIndex = priorityCount;
/* 544 */         priorityCount = (byte)(priorityCount + 1);
/*     */       }
/*     */     }
/*     */ 
/* 548 */     int deallocCount = 0;
/* 549 */     for (byte voiceNumber = 0; voiceNumber < this.maxVoices; voiceNumber = (byte)(voiceNumber + 1)) {
/* 550 */       GroupMember speaker = listener.getSpeakerForVoiceNumber(voiceNumber);
/* 551 */       if (speaker == null)
/*     */       {
/*     */         continue;
/*     */       }
/* 555 */       if ((speaker.priorityIndex == -1) && (eligibleSpeakerListenerPair(speaker, listener))) {
/* 556 */         endListeningToSpeaker(speaker, listener, voiceNumber);
/* 557 */         deallocCount++;
/*     */       }
/*     */     }
/*     */ 
/* 561 */     if (Log.loggingDebug) {
/* 562 */       Log.debug(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: listener ").append(listener).append(", count ").append(count).append(", deallocCount ").append(deallocCount).append(", priorityCount ").append(priorityCount).toString());
/*     */     }
/*     */ 
/* 567 */     for (int i = 0; i < priorityCount; i++) {
/* 568 */       GroupMember speaker = newVoiceNumberToMember[i];
/* 569 */       if (speaker == null) {
/* 570 */         Log.error(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: speaker newVoiceNumberToMember[").append(i).append("] is null!").toString());
/*     */       }
/*     */       else
/*     */       {
/* 574 */         speaker.priorityIndex = -1;
/* 575 */         if ((loggingRecomputeVoices) && (Log.loggingDebug))
/* 576 */           Log.debug(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: listener ").append(listener).append(", speaker[").append(i).append("] ").append(speaker).toString());
/* 577 */         if (listener.findVoiceNumberForSpeaker(speaker) == null) {
/* 578 */           Byte voiceNumber = listener.findFreeVoiceNumber();
/* 579 */           if ((loggingRecomputeVoices) && (Log.loggingDebug)) {
/* 580 */             Log.debug(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: For speaker ").append(speaker).append(", found voiceNumber ").append(voiceNumber).toString());
/*     */           }
/* 582 */           if (voiceNumber != null) {
/* 583 */             listener.setSpeakerForVoiceNumber(voiceNumber.byteValue(), speaker);
/* 584 */             this.voiceSender.sendAllocateVoice(speaker.memberCon, listener.memberCon, voiceNumber.byteValue(), isPositional());
/*     */           }
/*     */           else {
/* 587 */             Log.error(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: In listener ").append(listener).append(", didn't find unused voiceNumber for speaker ").append(speaker.memberCon).toString());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 591 */     if ((loggingRecomputeVoices) && (Log.loggingDebug))
/* 592 */       Log.debug(new StringBuilder().append("BasicVoiceGroup.recomputeVoicesFromSpeakerIterator: Exiting for listener ").append(listener).toString());
/*     */   }
/*     */ 
/*     */   protected String addString(boolean add)
/*     */   {
/* 599 */     return add ? "start" : "stop";
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 606 */     return new StringBuilder().append("group[oid ").append(this.groupOid).append("]").toString();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.BasicVoiceGroup
 * JD-Core Version:    0.6.0
 */