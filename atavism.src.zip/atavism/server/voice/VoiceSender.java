package atavism.server.voice;

import atavism.server.network.AOByteBuffer;
import atavism.server.plugins.WorldManagerClient.ExtensionMessage;

public abstract interface VoiceSender
{
  public abstract void sendAllocateVoice(VoiceConnection paramVoiceConnection1, VoiceConnection paramVoiceConnection2, byte paramByte, boolean paramBoolean);

  public abstract void sendAllocateVoice(VoiceConnection paramVoiceConnection1, VoiceConnection paramVoiceConnection2, byte paramByte1, byte paramByte2);

  public abstract void sendDeallocateVoice(VoiceConnection paramVoiceConnection1, VoiceConnection paramVoiceConnection2, byte paramByte);

  public abstract void sendVoiceFrame(VoiceConnection paramVoiceConnection1, VoiceConnection paramVoiceConnection2, byte paramByte1, byte paramByte2, AOByteBuffer paramAOByteBuffer, short paramShort);

  public abstract void sendExtensionMessage(WorldManagerClient.ExtensionMessage paramExtensionMessage);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.VoiceSender
 * JD-Core Version:    0.6.0
 */