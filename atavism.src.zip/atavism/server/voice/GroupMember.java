/*     */ package atavism.server.voice;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.plugins.WorldManagerClient.ExtensionMessage;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class GroupMember
/*     */ {
/*     */   protected OID memberOid;
/*     */   protected int priority;
/*     */   protected boolean allowedSpeaker;
/*     */   protected boolean currentSpeaker;
/*     */   protected boolean listening;
/* 308 */   protected byte voiceNumber = -1;
/*     */   protected VoiceConnection memberCon;
/*     */   protected int index;
/* 324 */   protected int priorityIndex = -1;
/*     */   protected VoiceGroup group;
/* 335 */   protected static int indexCounter = 0;
/*     */ 
/* 340 */   private Set<GroupMember> listenersToMe = new HashSet();
/*     */ 
/* 345 */   private Map<GroupMember, Byte> listenerVoicesMap = new HashMap();
/*     */ 
/* 350 */   private Set<OID> ignoredSpeakerOids = null;
/*     */   private List<WorldManagerClient.ExtensionMessage> pendingIgnoreUpdateMessages;
/*     */   private GroupMember[] voiceNumberToSpeaker;
/* 368 */   protected boolean expunged = false;
/*     */ 
/*     */   public GroupMember(VoiceGroup group, OID memberOid2, int priority, boolean allowedSpeaker, boolean currentSpeaker, VoiceConnection memberCon, int maxVoiceChannels)
/*     */   {
/*  32 */     this.group = group;
/*  33 */     this.memberOid = memberOid2;
/*  34 */     this.priority = priority;
/*  35 */     this.allowedSpeaker = allowedSpeaker;
/*  36 */     this.currentSpeaker = currentSpeaker;
/*  37 */     this.listening = false;
/*  38 */     this.memberCon = memberCon;
/*  39 */     this.index = (indexCounter++);
/*  40 */     this.voiceNumberToSpeaker = new GroupMember[maxVoiceChannels];
/*  41 */     if (Log.loggingDebug)
/*  42 */       Log.debug(logString("GroupMember constructor"));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  51 */     return "GroupMember(oid " + this.memberOid + ", con " + this.memberCon + ")";
/*     */   }
/*     */ 
/*     */   public String logString(String intro)
/*     */   {
/*  60 */     return intro + ": oid " + this.memberOid + ", listenToYourself " + this.memberCon.listenToYourself + ", allowedSpeaker " + this.allowedSpeaker + ", currentSpeaker " + this.currentSpeaker;
/*     */   }
/*     */ 
/*     */   public void setSpeakerForVoiceNumber(byte voiceNumber, GroupMember speaker)
/*     */   {
/*  73 */     GroupMember listener = this;
/*  74 */     if (speaker == null) {
/*  75 */       GroupMember oldSpeaker = this.voiceNumberToSpeaker[voiceNumber];
/*  76 */       if (oldSpeaker == null) {
/*  77 */         Log.dumpStack("GroupMember.setSpeakerForVoiceNumber: Setting speaker to null for voiceNumber " + voiceNumber + ", but voiceNumberToSpeaker[voiceNumber] is already null!");
/*     */       }
/*  79 */       if (listener.listenerVoicesMap.remove(oldSpeaker) == null) {
/*  80 */         Log.dumpStack("GroupMember.setSpeakerForVoiceNumber: Setting speaker to null for listener " + listener + ", didn't find speaker " + oldSpeaker + " in listenerVoicesMap");
/*     */       }
/*  82 */       if (!oldSpeaker.listenersToMe.remove(listener))
/*  83 */         Log.dumpStack("GroupMember.setSpeakerForVoiceNumber: For  speaker " + oldSpeaker + ", didn't find listener " + listener + " in listenersToMe");
/*     */     }
/*     */     else {
/*  86 */       Byte oldVoiceNumber = (Byte)listener.listenerVoicesMap.put(speaker, Byte.valueOf(voiceNumber));
/*  87 */       if (oldVoiceNumber != null) {
/*  88 */         Log.dumpStack("GroupMember.setSpeakerForVoiceNumber: For listener " + listener + " and speaker, when adding voiceNumber " + voiceNumber + ", found " + oldVoiceNumber + " in listenerVoicesMap");
/*     */       }
/*  90 */       if (!speaker.listenersToMe.add(listener)) {
/*  91 */         Log.dumpStack("GroupMember.setSpeakerForVoiceNumber: listener " + listener + " was already in speaker " + speaker + " listenersToMe list!");
/*     */       }
/*  93 */       if (this.voiceNumberToSpeaker[voiceNumber] != null) {
/*  94 */         Log.dumpStack("GroupMember.setSpeakerForVoiceNumber: For  speaker " + speaker + ", voiceNumber " + voiceNumber + ", voiceNumberToSpeaker[voiceNumber] " + this.voiceNumberToSpeaker[voiceNumber] + " is non-null");
/*     */       }
/*     */     }
/*  97 */     this.voiceNumberToSpeaker[voiceNumber] = speaker;
/*     */   }
/*     */ 
/*     */   public VoiceGroup getGroup()
/*     */   {
/* 104 */     return this.group;
/*     */   }
/*     */ 
/*     */   public OID getGroupOid()
/*     */   {
/* 112 */     return this.group.getGroupOid();
/*     */   }
/*     */ 
/*     */   public GroupMember getSpeakerForVoiceNumber(byte voiceNumber)
/*     */   {
/* 122 */     return this.voiceNumberToSpeaker[voiceNumber];
/*     */   }
/*     */ 
/*     */   public Byte findFreeVoiceNumber()
/*     */   {
/* 131 */     for (byte i = 0; i < this.voiceNumberToSpeaker.length; i = (byte)(i + 1)) {
/* 132 */       if (this.voiceNumberToSpeaker[i] == null)
/* 133 */         return Byte.valueOf(i);
/*     */     }
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */   public Byte findVoiceNumberForSpeaker(GroupMember speaker)
/*     */   {
/* 146 */     return (Byte)this.listenerVoicesMap.get(speaker);
/*     */   }
/*     */ 
/*     */   public int voiceCount()
/*     */   {
/* 154 */     return this.listenerVoicesMap.size();
/*     */   }
/*     */ 
/*     */   public boolean nowListeningTo(GroupMember speaker)
/*     */   {
/* 164 */     return speaker.listenersToMe.contains(this);
/*     */   }
/*     */ 
/*     */   public List<GroupMember> membersListeningToSpeaker()
/*     */   {
/* 172 */     return new LinkedList(this.listenersToMe);
/*     */   }
/*     */ 
/*     */   public boolean speakerIgnored(GroupMember speaker)
/*     */   {
/* 181 */     return (this.ignoredSpeakerOids != null) && (this.ignoredSpeakerOids.contains(speaker.memberOid));
/*     */   }
/*     */ 
/*     */   public void initializeIgnoredSpeakers(List<OID> ignored)
/*     */   {
/* 191 */     if (this.ignoredSpeakerOids != null) {
/* 192 */       Log.error("GroupMember.initializeIgnoredSpeakers: ignoredSpeakerOids for member " + this.memberOid + " is already initialized!");
/*     */     } else {
/* 194 */       this.ignoredSpeakerOids = new HashSet();
/* 195 */       this.ignoredSpeakerOids.addAll(ignored);
/* 196 */       if (this.pendingIgnoreUpdateMessages != null) {
/* 197 */         for (WorldManagerClient.ExtensionMessage extMsg : this.pendingIgnoreUpdateMessages)
/* 198 */           applyIgnoreUpdateMessageInternal(extMsg);
/* 199 */         this.pendingIgnoreUpdateMessages = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void applyIgnoreUpdateMessage(WorldManagerClient.ExtensionMessage extMsg)
/*     */   {
/* 211 */     if (this.ignoredSpeakerOids != null) {
/* 212 */       applyIgnoreUpdateMessageInternal(extMsg);
/*     */     } else {
/* 214 */       if (this.pendingIgnoreUpdateMessages == null)
/* 215 */         this.pendingIgnoreUpdateMessages = new LinkedList();
/* 216 */       this.pendingIgnoreUpdateMessages.add(extMsg);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void applyIgnoreUpdateMessageInternal(WorldManagerClient.ExtensionMessage extMsg)
/*     */   {
/* 226 */     List nowIgnored = (LinkedList)extMsg.getProperty("now_ignored");
/* 227 */     List noLongerIgnored = (LinkedList)extMsg.getProperty("no_longer_ignored");
/* 228 */     if (noLongerIgnored != null)
/* 229 */       removeIgnoredSpeakerOids(noLongerIgnored);
/* 230 */     if (nowIgnored != null)
/* 231 */       addIgnoredSpeakerOids(nowIgnored);
/*     */   }
/*     */ 
/*     */   public void addIgnoredSpeakerOids(List<OID> addToIgnored)
/*     */   {
/* 239 */     if (this.ignoredSpeakerOids == null)
/* 240 */       Log.error("GroupMember.addIgnoredSpeakerOids: ignoredSpeakerOids for member " + this.memberOid + " is not yet initialized!");
/*     */     else
/* 242 */       this.ignoredSpeakerOids.addAll(addToIgnored);
/*     */   }
/*     */ 
/*     */   public void removeIgnoredSpeakerOids(List<OID> noLongerIgnored)
/*     */   {
/* 250 */     if (this.ignoredSpeakerOids == null)
/* 251 */       Log.error("GroupMember.removeIgnoredSpeakerOids: ignoredSpeakerOids for member " + this.memberOid + " is not yet initialized!");
/*     */     else
/* 253 */       this.ignoredSpeakerOids.removeAll(noLongerIgnored);
/*     */   }
/*     */ 
/*     */   public OID getMemberOid()
/*     */   {
/* 260 */     return this.memberOid;
/*     */   }
/*     */ 
/*     */   public void setExpunged()
/*     */   {
/* 267 */     this.expunged = true;
/*     */   }
/*     */ 
/*     */   public boolean getExpunged()
/*     */   {
/* 275 */     return this.expunged;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.GroupMember
 * JD-Core Version:    0.6.0
 */