/*    */ package atavism.server.voice;
/*    */ 
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.util.SecureToken;
/*    */ import java.io.BufferedOutputStream;
/*    */ 
/*    */ public class VoiceConnection
/*    */ {
/* 29 */   public ClientConnection con = null;
/*    */   public OID playerOid;
/*    */   public GroupMember groupMember;
/*    */   public OID groupOid;
/*    */   public VoiceGroup group;
/*    */   public byte micVoiceNumber;
/* 65 */   public SecureToken authToken = null;
/*    */ 
/* 70 */   public short seqNum = 0;
/*    */ 
/* 76 */   public boolean listenToYourself = false;
/*    */ 
/* 82 */   public BufferedOutputStream recordSpeexStream = null;
/*    */ 
/*    */   public VoiceConnection(ClientConnection con)
/*    */   {
/* 23 */     this.con = con;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 88 */     return "oid " + this.playerOid + " " + this.con.IPAndPort();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.VoiceConnection
 * JD-Core Version:    0.6.0
 */