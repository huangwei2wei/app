package atavism.server.voice;

import atavism.server.engine.OID;
import atavism.server.network.AOByteBuffer;
import java.util.List;
import java.util.Set;

public abstract interface VoiceGroup
{
  public abstract boolean isPositional();

  public abstract OID getGroupOid();

  public abstract boolean addMemberAllowed(OID paramOID);

  public abstract void setAllowedMembers(Set<OID> paramSet);

  public abstract Set<OID> getAllowedMembers();

  public abstract GroupMember addMember(OID paramOID, VoiceConnection paramVoiceConnection);

  public abstract void getAllMembers(List<GroupMember> paramList);

  public abstract GroupMember addMember(OID paramOID, VoiceConnection paramVoiceConnection, int paramInt, boolean paramBoolean);

  public abstract void onAfterAddMember(OID paramOID1, OID paramOID2, boolean paramBoolean1, byte paramByte, boolean paramBoolean2);

  public abstract GroupMember isMember(OID paramOID);

  public abstract boolean removeMember(OID paramOID);

  public abstract void onAfterRemoveMember(OID paramOID1, OID paramOID2, boolean paramBoolean);

  public abstract int getDefaultPriority();

  public abstract void setAllowedSpeaker(OID paramOID, boolean paramBoolean);

  public abstract void setMemberSpeaking(OID paramOID, boolean paramBoolean);

  public abstract void setListener(OID paramOID, boolean paramBoolean);

  public abstract void sendVoiceFrameToListeners(OID paramOID, AOByteBuffer paramAOByteBuffer, byte paramByte, int paramInt);

  public abstract boolean isAllowedSpeaker(OID paramOID);

  public abstract boolean isMemberSpeaking(OID paramOID);

  public abstract boolean isListener(OID paramOID);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.VoiceGroup
 * JD-Core Version:    0.6.0
 */