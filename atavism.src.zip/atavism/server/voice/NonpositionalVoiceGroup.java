/*     */ package atavism.server.voice;
/*     */ 
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class NonpositionalVoiceGroup extends BasicVoiceGroup
/*     */ {
/*     */   protected Set<GroupMember> listeners;
/*     */   private List<GroupMember> currentSpeakers;
/*     */   private Comparator<GroupMember> comparePriorities;
/*     */ 
/*     */   public NonpositionalVoiceGroup(OID groupOid, Object association, VoiceSender voiceSender, int maxVoices)
/*     */   {
/*  29 */     super(groupOid, association, voiceSender, maxVoices);
/*  30 */     this.listeners = new HashSet();
/*  31 */     this.comparePriorities = new ComparePriorities();
/*  32 */     this.currentSpeakers = new LinkedList();
/*     */   }
/*     */ 
/*     */   public GroupMember addMember(OID memberOid, VoiceConnection memberCon, int priority, boolean allowedSpeaker)
/*     */   {
/*  48 */     this.lock.lock();
/*     */     try {
/*  50 */       GroupMember member = (GroupMember)this.members.get(memberOid);
/*  51 */       if (member != null) {
/*  52 */         Log.dumpStack("NonpositionalVoiceGroup.addMember: Member " + memberOid + " is already a member of voice group " + this.groupOid);
/*     */       } else {
/*  54 */         member = new GroupMember(this, memberOid, priority, allowedSpeaker, false, memberCon, this.maxVoices);
/*  55 */         this.members.put(memberOid, member);
/*     */       }
/*  57 */       onAfterAddMember(memberOid, this.groupOid, allowedSpeaker, memberCon.micVoiceNumber, memberCon.listenToYourself);
/*  58 */       GroupMember localGroupMember1 = member;
/*     */       return localGroupMember1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean isPositional()
/*     */   {
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isAllowedSpeaker(OID memberOid)
/*     */   {
/* 104 */     GroupMember member = getMember(memberOid);
/* 105 */     if (member == null) {
/* 106 */       return false;
/*     */     }
/* 108 */     return member.allowedSpeaker;
/*     */   }
/*     */ 
/*     */   protected void changeSpeaking(GroupMember speaker, boolean add)
/*     */   {
/* 118 */     if (Log.loggingDebug) {
/* 119 */       Log.debug("NonpositionalVoiceGroup.changeSpeaking entering " + addString(add) + ": listeners.size() " + this.listeners.size() + ", speaker " + speaker + ", speaker.voiceNumber " + speaker.voiceNumber);
/*     */     }
/* 121 */     this.lock.lock();
/*     */     try {
/* 123 */       speaker.currentSpeaker = add;
/* 124 */       if (add) {
/* 125 */         if (!this.currentSpeakers.add(speaker)) {
/* 126 */           Log.error("NonpositionalVoiceGroup.changeSpeaking start: currentSpeakers already contains speaker " + speaker);
/*     */         }
/*     */       }
/* 129 */       else if (!this.currentSpeakers.remove(speaker)) {
/* 130 */         Log.error("NonpositionalVoiceGroup.changeSpeaking stop: currentSpeakers doesn't contain speaker " + speaker);
/*     */       }
/* 132 */       speakingStatusChanged();
/*     */     }
/*     */     finally {
/* 135 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void changeListening(GroupMember listener, boolean add)
/*     */   {
/* 146 */     if (Log.loggingDebug)
/* 147 */       Log.debug("NonpositionalVoiceGroup.changeListening " + addString(add) + ": listener " + listener);
/* 148 */     this.lock.lock();
/*     */     try {
/* 150 */       if (add) {
/* 151 */         if (!this.listeners.add(listener))
/* 152 */           Log.error("NonpositionalVoiceGroup.changeListening " + addString(add) + ": listener " + listener + " already in listeners");
/* 153 */         recomputeListenerVoices(listener);
/*     */       }
/*     */       else {
/* 156 */         if (!this.listeners.remove(listener))
/* 157 */           Log.error("NonpositionalVoiceGroup.changeListening " + addString(add) + ": listener " + listener + " not in listeners");
/* 158 */         for (byte voiceNumber = 0; voiceNumber < this.maxVoices; voiceNumber = (byte)(voiceNumber + 1)) {
/* 159 */           GroupMember speaker = listener.getSpeakerForVoiceNumber(voiceNumber);
/* 160 */           if (speaker != null)
/* 161 */             endListeningToSpeaker(speaker, listener, voiceNumber);
/*     */         }
/* 163 */         if (listener.voiceCount() > 0)
/* 164 */           Log.dumpStack("NonpositionalVoiceGroup.changeListening stop: After removing, listener.voiceCount() " + listener.voiceCount());
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 169 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void recomputeListenerVoices(GroupMember listener)
/*     */   {
/* 178 */     recomputeListenerVoices(listener, this.currentSpeakers);
/*     */   }
/*     */ 
/*     */   protected void recomputeListenerVoices(GroupMember listener, List<GroupMember> membersToConsider)
/*     */   {
/* 188 */     Iterator speakerIter = membersToConsider.iterator();
/* 189 */     int speakerCount = membersToConsider.size();
/* 190 */     int iterCount = Math.min(speakerCount, this.maxVoices);
/* 191 */     recomputeVoicesFromSpeakerIterator(listener, speakerIter, iterCount);
/*     */   }
/*     */ 
/*     */   protected void speakingStatusChanged()
/*     */   {
/* 200 */     this.lock.lock();
/*     */     try {
/* 202 */       Collections.sort(this.currentSpeakers, this.comparePriorities);
/*     */     }
/*     */     finally {
/* 205 */       this.lock.unlock();
/*     */     }
/* 207 */     for (GroupMember listener : this.listeners)
/* 208 */       recomputeListenerVoices(listener);
/*     */   }
/*     */ 
/*     */   public static class ComparePriorities
/*     */     implements Comparator<GroupMember>
/*     */   {
/*     */     public int compare(GroupMember m1, GroupMember m2)
/*     */     {
/*  71 */       if (m1 == m2)
/*  72 */         return 0;
/*  73 */       if (m1.priority < m2.priority)
/*  74 */         return -1;
/*  75 */       if (m1.priority > m2.priority) {
/*  76 */         return 1;
/*     */       }
/*     */ 
/*  80 */       return m1.index < m2.index ? -1 : 1;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/*  84 */       return this == other;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.NonpositionalVoiceGroup
 * JD-Core Version:    0.6.0
 */