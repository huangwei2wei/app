/*     */ package atavism.server.voice;
/*     */ 
/*     */ import atavism.server.engine.BasicWorldNode;
/*     */ import atavism.server.engine.InterpolatedWorldNode;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class PositionalVoiceGroup extends BasicVoiceGroup
/*     */ {
/*     */   protected float audibleRadius;
/*     */   protected float hystericalMargin;
/* 626 */   private Map<OID, Set<PositionalGroupMember>> instanceMembers = new HashMap();
/*     */ 
/*     */   public PositionalVoiceGroup(OID groupOid, Object association, VoiceSender voiceSender, int maxVoices, float audibleRadius, float hystericalMargin)
/*     */   {
/*  38 */     super(groupOid, association, voiceSender, maxVoices);
/*  39 */     this.audibleRadius = audibleRadius;
/*  40 */     this.hystericalMargin = hystericalMargin;
/*     */   }
/*     */ 
/*     */   public GroupMember addMember(OID memberOid, VoiceConnection memberCon, int priority, boolean allowedSpeaker)
/*     */   {
/*  56 */     this.lock.lock();
/*     */     try {
/*  58 */       GroupMember member = (GroupMember)this.members.get(memberOid);
/*  59 */       if (member != null) {
/*  60 */         Log.dumpStack(new StringBuilder().append("PositionalVoiceGroup.addMember: Member ").append(memberOid).append(" is already a member of voice group ").append(this.groupOid).toString());
/*     */       } else {
/*  62 */         member = new PositionalGroupMember(this, memberOid, priority, allowedSpeaker, false, memberCon, this.maxVoices);
/*  63 */         this.members.put(memberOid, member);
/*  64 */         if (Log.loggingDebug)
/*  65 */           Log.debug(new StringBuilder().append("PositionalVoiceGroup.addMember: For group ").append(this.groupOid).append(", adding member ").append(memberOid).toString());
/*     */       }
/*  67 */       onAfterAddMember(memberOid, this.groupOid, allowedSpeaker, memberCon.micVoiceNumber, memberCon.listenToYourself);
/*  68 */       GroupMember localGroupMember1 = member;
/*     */       return localGroupMember1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   protected void changeSpeaking(GroupMember gspeaker, boolean add)
/*     */   {
/*  82 */     PositionalGroupMember speaker = (PositionalGroupMember)gspeaker;
/*  83 */     if (Log.loggingDebug)
/*  84 */       Log.debug(new StringBuilder().append("PositionalVoiceGroup.changeSpeaking ").append(addString(add)).append(": speaker ").append(speaker).toString());
/*  85 */     this.lock.lock();
/*     */     try {
/*  87 */       speaker.currentSpeaker = add;
/*  88 */       if (add) {
/*  89 */         recomputeListenersInRadius(speaker);
/*     */       } else {
/*  91 */         listenersToSpeaker = speaker.membersListeningToSpeaker();
/*  92 */         for (GroupMember listener : listenersToSpeaker) {
/*  93 */           Byte voiceNumber = listener.findVoiceNumberForSpeaker(speaker);
/*  94 */           if (Log.loggingDebug) {
/*  95 */             Log.debug(new StringBuilder().append("PositionalVoiceGroup.changeSpeaking ").append(addString(add)).append(": listeners cnt ").append(listenersToSpeaker.size()).append(", speaker ").append(speaker).append(", voiceNumber ").append(voiceNumber).append(", listener ").append(listener).toString());
/*     */           }
/*  97 */           if (voiceNumber == null) {
/*  98 */             Log.error(new StringBuilder().append("PositionalVoiceGroup.changeSpeaking ").append(addString(add)).append(": Voice number for speaker ").append(speaker).append(" and listener ").append(listener).append(" is null!").toString());
/*     */           }
/*     */           else
/* 101 */             recomputeListenerVoices(listener);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       List listenersToSpeaker;
/* 106 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void changeListening(GroupMember listener, boolean add)
/*     */   {
/* 117 */     if (Log.loggingDebug)
/* 118 */       Log.debug(new StringBuilder().append("PositionalVoiceGroup.changeListening ").append(addString(add)).append(": listener ").append(listener).toString());
/* 119 */     this.lock.lock();
/*     */     try {
/* 121 */       if (add)
/* 122 */         recomputeListenerVoices(listener);
/*     */       else
/* 124 */         for (byte voiceNumber = 0; voiceNumber < this.maxVoices; voiceNumber = (byte)(voiceNumber + 1)) {
/* 125 */           GroupMember speaker = listener.getSpeakerForVoiceNumber(voiceNumber);
/* 126 */           if (speaker != null)
/* 127 */             endListeningToSpeaker(speaker, listener, voiceNumber);
/*     */         }
/*     */     }
/*     */     finally
/*     */     {
/* 132 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateWorldNode(PositionalGroupMember perceiverMember, BasicWorldNode bwnode)
/*     */   {
/* 143 */     if (perceiverMember.wnode != null) {
/* 144 */       perceiverMember.previousLoc = perceiverMember.lastLoc;
/* 145 */       perceiverMember.wnode.setDirLocOrient(bwnode);
/* 146 */       perceiverMember.wnode.setInstanceOid(bwnode.getInstanceOid());
/* 147 */       perceiverMember.lastLoc = perceiverMember.wnode.getLoc();
/* 148 */       for (OID perceivedOid : perceiverMember.perceivedOids) {
/* 149 */         if (perceiverMember.memberOid.equals(perceivedOid))
/*     */           continue;
/* 151 */         PositionalGroupMember perceivedMember = (PositionalGroupMember)getMember(perceivedOid);
/* 152 */         if ((perceivedMember != null) && (perceivedMember.wnode != null))
/* 153 */           testProximity(perceiverMember, perceivedMember, false, true);
/*     */       }
/*     */     }
/*     */     else {
/* 157 */       Log.error(new StringBuilder().append("PositionalVoiceGroup.updateWorldNode: In UpdateWorldNodeMessage for oid ").append(perceiverMember.memberOid).append(", perceiverMember.wnode is null!").toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void testProximity(PositionalGroupMember perceiverMember, PositionalGroupMember perceivedMember, boolean interpolatePerceiver, boolean interpolatePerceived)
/*     */   {
/* 174 */     Point perceiverLoc = interpolatePerceiver ? perceiverMember.wnode.getLoc() : perceiverMember.lastLoc;
/* 175 */     Point perceivedLoc = interpolatePerceived ? perceivedMember.wnode.getLoc() : perceivedMember.lastLoc;
/* 176 */     if (perceiverLoc == null) {
/* 177 */       Log.dumpStack(new StringBuilder().append("PositionalVoiceGroup.testProximity: perceiver ").append(perceiverMember.getMemberOid()).append(" loc is null!").toString());
/* 178 */       return;
/*     */     }
/* 180 */     if (perceivedLoc == null) {
/* 181 */       Log.dumpStack(new StringBuilder().append("PositionalVoiceGroup.testProximity: perceived ").append(perceivedMember.getMemberOid()).append(" loc is null!").toString());
/* 182 */       return;
/*     */     }
/* 184 */     float distance = Point.distanceTo(perceiverLoc, perceivedLoc);
/* 185 */     OID perceiverInstance = perceiverMember.wnode.getInstanceOid();
/* 186 */     OID perceivedInstance = perceivedMember.wnode.getInstanceOid();
/* 187 */     boolean sameInstance = perceiverInstance.equals(perceivedInstance);
/* 188 */     boolean inRadius = (sameInstance) && (distance < this.audibleRadius);
/* 189 */     boolean wasInRadius = perceiverMember.membersInRadius.contains(perceivedMember);
/* 190 */     if (Log.loggingDebug) {
/* 191 */       Log.debug(new StringBuilder().append("PositionalVoiceGroup.testProximity: perceiver ").append(perceiverMember.getMemberOid()).append(", perceiverLoc = ").append(perceiverLoc).append(", perceived ").append(perceivedMember.getMemberOid()).append(", perceivedLoc = ").append(perceivedLoc).append(", distance ").append(distance).append(", audibleRadius ").append(this.audibleRadius).append(", perceiverInstance ").append(perceiverInstance).append(", perceivedInstance ").append(perceivedInstance).append(", inRadius ").append(inRadius).append(", wasInRadius ").append(wasInRadius).toString());
/*     */     }
/*     */ 
/* 195 */     if (inRadius == wasInRadius)
/* 196 */       return;
/* 197 */     if ((sameInstance) && (this.hystericalMargin != 0.0F)) {
/* 198 */       if (wasInRadius)
/* 199 */         inRadius = distance < this.audibleRadius + this.hystericalMargin;
/*     */       else {
/* 201 */         inRadius = distance < this.audibleRadius - this.hystericalMargin;
/*     */       }
/* 203 */       if (inRadius == wasInRadius)
/* 204 */         return;
/*     */     }
/* 206 */     handlePositionalSpeakerChange(perceiverMember, perceivedMember, inRadius);
/* 207 */     handlePositionalSpeakerChange(perceivedMember, perceiverMember, inRadius);
/*     */   }
/*     */ 
/*     */   public void handlePositionalSpeakerChange(PositionalGroupMember speaker, PositionalGroupMember listener, boolean inRadius)
/*     */   {
/* 220 */     this.lock.lock();
/*     */     try
/*     */     {
/* 223 */       if (Log.loggingDebug) {
/* 224 */         Log.debug(new StringBuilder().append("PositionalVoiceGroup.handlePositionalSpeakerChange: speakerOid ").append(speaker.memberOid).append(", speaker ").append(speaker).append(", listenerOid ").append(listener.memberOid).append(", listeneer ").append(listener).append(", inRadius ").append(inRadius).toString());
/*     */       }
/* 226 */       if ((inRadius) && (!listener.speakerIgnored(speaker)))
/* 227 */         addSpeakerListenerPair(speaker, listener);
/*     */       else
/* 229 */         removeSpeakerListenerPair(speaker, listener);
/*     */     }
/*     */     finally {
/* 232 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isPositional()
/*     */   {
/* 240 */     return true;
/*     */   }
/*     */ 
/*     */   protected void addSpeakerListenerPair(PositionalGroupMember speaker, PositionalGroupMember listener)
/*     */   {
/* 249 */     Set membersInRadius = listener.membersInRadius;
/* 250 */     if (Log.loggingDebug) {
/* 251 */       Log.debug(new StringBuilder().append("PositionalVoiceGroup.addSpeakerListenerPair: speaker + ").append(speaker).append(", listener ").append(listener).append(", membersInRadius.size() ").append(membersInRadius.size()).toString());
/*     */     }
/* 253 */     if (speaker.getExpunged()) {
/* 254 */       Log.warn(new StringBuilder().append("PositionalVoiceGroup.addSpeakerListenerPair: For listener ").append(listener.getMemberOid()).append(", speaker ").append(speaker.getMemberOid()).append(" is expunged!").toString());
/*     */ 
/* 256 */       return;
/*     */     }
/* 258 */     if (listener.getExpunged()) {
/* 259 */       Log.warn(new StringBuilder().append("PositionalVoiceGroup.addSpeakerListenerPair: For speaker ").append(speaker.getMemberOid()).append(", listener ").append(listener.getMemberOid()).append(" is expunged!").toString());
/*     */ 
/* 261 */       return;
/*     */     }
/* 263 */     if (!membersInRadius.add(speaker)) {
/* 264 */       if (Log.loggingDebug) {
/* 265 */         Log.debug(new StringBuilder().append("PositionalVoiceGroup.addSpeakerListenerPair: listener ").append(listener).append(" already in membersInRadiusOfSpeakerMap for speaker ").append(speaker).toString());
/*     */       }
/*     */     }
/*     */     else
/* 269 */       recomputeListenerVoices(listener);
/*     */   }
/*     */ 
/*     */   protected void removeSpeakerListenerPair(PositionalGroupMember speaker, PositionalGroupMember listener)
/*     */   {
/* 278 */     Set membersInRadius = listener.membersInRadius;
/* 279 */     boolean found = false;
/* 280 */     if ((membersInRadius != null) && 
/* 281 */       (membersInRadius.remove(speaker))) {
/* 282 */       found = true;
/*     */     }
/* 284 */     if (!found) {
/* 285 */       if (Log.loggingDebug) {
/* 286 */         Log.debug(new StringBuilder().append("PositionalVoiceGroup.removeSpeakerListenerPair: listener ").append(listener).append(" is not in membersInRadiusOfSpeakerMap for speaker ").append(speaker).toString());
/*     */       }
/*     */     }
/* 289 */     else if (Log.loggingDebug)
/* 290 */       Log.debug(new StringBuilder().append("PositionalVoiceGroup.removeSpeakerListenerPair: listener ").append(listener).append(" removed from membersInRadius of speaker ").append(speaker).toString());
/* 291 */     recomputeListenerVoices(listener);
/*     */   }
/*     */ 
/*     */   protected void recomputeListenersInRadius(PositionalGroupMember speaker)
/*     */   {
/* 300 */     for (PositionalGroupMember listener : speaker.membersInRadius)
/* 301 */       if (listener.listening)
/* 302 */         recomputeListenerVoices(listener);
/*     */   }
/*     */ 
/*     */   protected void recomputeListenerVoices(GroupMember glistener)
/*     */   {
/* 311 */     PositionalGroupMember listener = (PositionalGroupMember)glistener;
/*     */ 
/* 313 */     List expungedMembers = null;
/* 314 */     for (PositionalGroupMember member : listener.membersInRadius) {
/* 315 */       if (member.getExpunged()) {
/* 316 */         if (expungedMembers == null)
/* 317 */           expungedMembers = new LinkedList();
/* 318 */         if (Log.loggingDebug) {
/* 319 */           Log.debug(new StringBuilder().append("PositionalVoiceGroup:recomputeListenerVoices: listener ").append(listener.getMemberOid()).append(" memberInRadius ").append(member.getMemberOid()).append(" is expunged; removing.").toString());
/*     */         }
/* 321 */         expungedMembers.add(member);
/*     */       }
/*     */     }
/* 324 */     if (expungedMembers != null)
/* 325 */       listener.membersInRadius.removeAll(expungedMembers);
/* 326 */     recomputeListenerVoices(listener, listener.membersInRadius);
/*     */   }
/*     */ 
/*     */   protected void recomputeListenerVoices(PositionalGroupMember listener, Set<PositionalGroupMember> membersToConsider)
/*     */   {
/* 336 */     if (Log.loggingDebug) {
/* 337 */       Log.debug(new StringBuilder().append("PositionalVoiceGroup.recomputeListenerVoices: listener ").append(listener).append(", membersToConsider.size() ").append(membersToConsider.size()).toString());
/*     */     }
/* 339 */     List currentSpeakersForListener = new LinkedList();
/* 340 */     for (PositionalGroupMember speaker : membersToConsider) {
/* 341 */       if (speaker.currentSpeaker)
/* 342 */         currentSpeakersForListener.add(speaker);
/*     */     }
/* 344 */     Collections.sort(currentSpeakersForListener, new CompareLocations(listener.getCurrentLoc()));
/* 345 */     Iterator speakerIter = currentSpeakersForListener.iterator();
/* 346 */     int speakerCount = currentSpeakersForListener.size();
/* 347 */     int iterCount = Math.min(speakerCount, this.maxVoices);
/* 348 */     recomputeVoicesFromSpeakerIterator(listener, speakerIter, iterCount);
/*     */   }
/*     */ 
/*     */   public byte addListenerVoice(PositionalGroupMember speaker, PositionalGroupMember listener)
/*     */   {
/* 361 */     if (Log.loggingDebug)
/* 362 */       Log.debug(new StringBuilder().append("PositionalGroupMember.addListenerVoice:  speaker ").append(speaker).append(", listener ").append(listener).toString());
/* 363 */     this.lock.lock();
/*     */     try {
/* 365 */       Byte voiceNumber = listener.findFreeVoiceNumber();
/* 366 */       if (voiceNumber == null) {
/* 367 */         Log.error(new StringBuilder().append("PositionalGroupMember.addListenerVoice: Too many voices allocating voice for member ").append(listener).toString());
/* 368 */         i = -1;
/*     */         return i;
/*     */       }
/* 370 */       listener.setSpeakerForVoiceNumber(voiceNumber.byteValue(), speaker);
/* 371 */       int i = voiceNumber.byteValue();
/*     */       return i; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public List<GroupMember> membersListeningToSpeaker(PositionalGroupMember speaker)
/*     */   {
/* 385 */     this.lock.lock();
/*     */     try {
/* 387 */       List localList = speaker.membersListeningToSpeaker();
/*     */       return localList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean nowListeningTo(PositionalGroupMember speaker, PositionalGroupMember listener)
/*     */   {
/* 403 */     this.lock.lock();
/*     */     try {
/* 405 */       boolean bool = listener.nowListeningTo(speaker);
/*     */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void unloadInstance(OID instanceOid)
/*     */   {
/* 418 */     this.lock.lock();
/*     */     try {
/* 420 */       Set members = (Set)this.instanceMembers.remove(instanceOid);
/* 421 */       if ((members != null) && (members.size() > 0)) {
/* 422 */         Log.warn(new StringBuilder().append("PositionalVoiceGroup.unloadInstance: Group ").append(this.groupOid).append(" in instance ").append(instanceOid).append(", has active members ").append(makeOidStringFromMembers(members)).toString());
/*     */ 
/* 424 */         for (PositionalGroupMember member : members)
/* 425 */           clearMembersPerceived(member);
/*     */       }
/*     */     }
/*     */     finally {
/* 429 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTrackedPerceiver(PositionalGroupMember perceiverMember, OID instanceOid)
/*     */   {
/* 440 */     this.lock.lock();
/*     */     try
/*     */     {
/* 443 */       Set members = (Set)this.instanceMembers.get(instanceOid);
/* 444 */       if (members == null) {
/* 445 */         members = new HashSet();
/* 446 */         this.instanceMembers.put(instanceOid, members);
/*     */       }
/* 448 */       if (!members.add(perceiverMember)) {
/* 449 */         Log.error(new StringBuilder().append("PositionalVoiceGroup.addTrackedPerceiver: Member ").append(perceiverMember.getMemberOid()).append(" is already a member of group ").append(this.groupOid).append(", instanceOid ").append(instanceOid).toString());
/*     */       }
/*     */       else
/* 452 */         clearMembersPerceived(perceiverMember);
/*     */     }
/*     */     finally {
/* 455 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String makeOidString(Collection<OID> oids)
/*     */   {
/* 466 */     String oidString = "";
/* 467 */     for (OID oid : oids) {
/* 468 */       if (oidString.length() > 0)
/* 469 */         oidString = new StringBuilder().append(oidString).append(", ").toString();
/* 470 */       oidString = new StringBuilder().append(oidString).append(oid).toString();
/*     */     }
/* 472 */     return oidString;
/*     */   }
/*     */ 
/*     */   protected String makeOidStringFromMembers(Collection<PositionalGroupMember> members)
/*     */   {
/* 482 */     String oidString = "";
/* 483 */     for (PositionalGroupMember member : members) {
/* 484 */       if (oidString.length() > 0)
/* 485 */         oidString = new StringBuilder().append(oidString).append(", ").toString();
/* 486 */       oidString = new StringBuilder().append(oidString).append(member.getMemberOid()).toString();
/*     */     }
/* 488 */     return oidString;
/*     */   }
/*     */ 
/*     */   protected void clearMembersPerceived(PositionalGroupMember perceiverMember)
/*     */   {
/* 499 */     boolean listeningToHimself = perceiverMember.membersInRadius.contains(perceiverMember);
/* 500 */     perceiverMember.perceivedOids.clear();
/* 501 */     perceiverMember.membersInRadius.clear();
/* 502 */     if (listeningToHimself)
/* 503 */       perceiverMember.membersInRadius.add(perceiverMember);
/* 504 */     recomputeListenerVoices(perceiverMember);
/*     */   }
/*     */ 
/*     */   public void removeTrackedPerceiver(OID playerOid)
/*     */   {
/* 514 */     PositionalGroupMember perceiverMember = (PositionalGroupMember)isMember(playerOid);
/* 515 */     if (perceiverMember != null)
/* 516 */       removeTrackedPerceiver(perceiverMember);
/*     */     else
/* 518 */       Log.error(new StringBuilder().append("PositionalVoiceGroup.removeTrackedPerceiver: Could not find member ").append(playerOid).toString());
/*     */   }
/*     */ 
/*     */   public void removeTrackedPerceiver(PositionalGroupMember perceiverMember)
/*     */   {
/* 528 */     this.lock.lock();
/*     */     try {
/* 530 */       OID instanceOid = perceiverMember.getInstanceOid();
/* 531 */       if (instanceOid != null) {
/* 532 */         perceiverMember.wnode = null;
/* 533 */         perceiverMember.lastLoc = null;
/* 534 */         perceiverMember.previousLoc = null;
/*     */ 
/* 536 */         Set members = (Set)this.instanceMembers.get(instanceOid);
/* 537 */         if (members == null) {
/* 538 */           Log.error(new StringBuilder().append("PositionalVoiceGroup.removeTrackedPerceiver: For perceiver ").append(perceiverMember.getMemberOid()).append(", instanceMembers.get(").append(instanceOid).append(") is null!").toString());
/*     */         }
/* 540 */         else if (!members.remove(perceiverMember)) {
/* 541 */           Log.error(new StringBuilder().append("PositionalVoiceGroup.removeTrackedPerceiver: Member ").append(perceiverMember.getMemberOid()).append(" is not a member of group ").append(this.groupOid).append(", instanceOid ").append(instanceOid).toString());
/*     */         }
/* 543 */         OID perceiverOid = perceiverMember.getMemberOid();
/*     */ 
/* 545 */         for (OID perceivedOid : perceiverMember.perceivedOids) {
/* 546 */           PositionalGroupMember perceivedMember = (PositionalGroupMember)isMember(perceivedOid);
/* 547 */           if (perceivedMember != null) {
/* 548 */             perceivedMember.membersInRadius.remove(perceiverOid);
/* 549 */             if ((!perceivedMember.perceivedOids.remove(perceiverOid)) && 
/* 550 */               (Log.loggingDebug)) {
/* 551 */               Log.debug(new StringBuilder().append("PositionalVoiceGroup.removeTrackedPerceiver: Member ").append(perceiverMember.getMemberOid()).append(" is not perceived by perceived member ").append(perceivedOid).toString());
/*     */             }
/*     */ 
/* 554 */             recomputeListenerVoices(perceivedMember);
/*     */           }
/* 556 */           else if (Log.loggingDebug) {
/* 557 */             Log.debug(new StringBuilder().append("PositionalVoiceGroup.removeTrackedPerceiver: Member ").append(perceivedOid).append(" could not be found!").toString());
/*     */           }
/*     */         }
/* 559 */         clearMembersPerceived(perceiverMember);
/*     */       }
/*     */     }
/*     */     finally {
/* 563 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void maybeChangePerceivedObject(PositionalGroupMember perceiverMember, OID perceivedOid, boolean added)
/*     */   {
/* 577 */     OID perceiverOid = perceiverMember.getMemberOid();
/* 578 */     if (Log.loggingDebug) {
/* 579 */       Log.debug(new StringBuilder().append("PositionalVoiceGroup.maybeChangePerceivedObject: ").append(added ? "gain" : "loss").append(", oid=").append(perceivedOid).append(" detected by ").append(perceiverOid).append(", instanceOid=").append(perceiverMember.getInstanceOid()).toString());
/*     */     }
/* 581 */     this.lock.lock();
/*     */     try {
/* 583 */       if (added) {
/* 584 */         if (!perceiverMember.perceivedOids.add(perceivedOid)) {
/* 585 */           Log.error(new StringBuilder().append("PositionalVoiceGroup.maybeChangePerceivedObject: Adding member ").append(perceivedOid).append(" for perceiver ").append(perceiverOid).append("; already in perceivedOids").toString());
/*     */         }
/*     */ 
/*     */       }
/* 589 */       else if (perceiverMember.perceivedOids.remove(perceivedOid));
/* 594 */       PositionalGroupMember perceivedMember = (PositionalGroupMember)this.members.get(perceivedOid);
/* 595 */       if ((perceiverMember.wnode != null) && (perceivedMember != null) && (perceivedMember.wnode != null)) {
/* 596 */         perceivedMember.previousLoc = perceivedMember.lastLoc;
/* 597 */         perceivedMember.lastLoc = perceivedMember.wnode.getLoc();
/* 598 */         testProximity(perceiverMember, perceivedMember, true, false);
/*     */       }
/*     */     }
/*     */     finally {
/* 602 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CompareLocations
/*     */     implements Comparator<GroupMember>
/*     */   {
/*     */     private Point center;
/*     */ 
/*     */     public CompareLocations(Point center)
/*     */     {
/* 636 */       this.center = center;
/*     */     }
/*     */ 
/*     */     public int compare(GroupMember m1, GroupMember m2)
/*     */     {
/* 647 */       if (m1 == m2)
/* 648 */         return 0;
/* 649 */       Point m1Loc = ((PositionalGroupMember)m1).getCurrentLoc();
/* 650 */       Point m2Loc = ((PositionalGroupMember)m2).getCurrentLoc();
/* 651 */       if (m1Loc == null) {
/* 652 */         if (Log.loggingDebug)
/* 653 */           Log.debug("PositionalVoiceGroup.CompareLocations.compare: For member " + m1.getMemberOid() + ", currentLoc is null");
/* 654 */         return -1;
/*     */       }
/* 656 */       if (m2Loc == null) {
/* 657 */         Log.debug("PositionalVoiceGroup.CompareLocations.compare: For member " + m2.getMemberOid() + ", currentLoc is null");
/* 658 */         return -1;
/*     */       }
/* 660 */       float d1Squared = Point.distanceToSquared(this.center, m1Loc);
/* 661 */       float d2Squared = Point.distanceToSquared(this.center, m2Loc);
/* 662 */       if (d1Squared < d2Squared)
/* 663 */         return -1;
/* 664 */       if (d1Squared > d2Squared) {
/* 665 */         return 1;
/*     */       }
/*     */ 
/* 669 */       return m1.index < m2.index ? -1 : 1;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/* 673 */       return this == other;
/*     */     }
/*     */ 
/*     */     public Point getCenter()
/*     */     {
/* 679 */       return this.center;
/*     */     }
/*     */ 
/*     */     public void setCenter(Point center) {
/* 683 */       this.center = center;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.voice.PositionalVoiceGroup
 * JD-Core Version:    0.6.0
 */