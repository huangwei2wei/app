package atavism.server.marshalling;

import atavism.server.network.AOByteBuffer;

public abstract interface Marshallable
{
  public abstract void marshalObject(AOByteBuffer paramAOByteBuffer);

  public abstract Object unmarshalObject(AOByteBuffer paramAOByteBuffer);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.marshalling.Marshallable
 * JD-Core Version:    0.6.0
 */