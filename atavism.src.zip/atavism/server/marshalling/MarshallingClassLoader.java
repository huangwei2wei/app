/*     */ package atavism.server.marshalling;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import org.apache.bcel.util.ClassPath;
/*     */ 
/*     */ public class MarshallingClassLoader extends ClassLoader
/*     */ {
/* 113 */   public static String[] ignoredPackages = { "java.", "javax.", "sun.", "apache.", "org.", "com.sun." };
/*     */ 
/* 120 */   private HashMap<String, Class> loadedClasses = new HashMap();
/*     */ 
/* 122 */   private Class marshallingRuntimeClass = null;
/*     */ 
/* 124 */   private ClassPath classPath = null;
/*     */ 
/* 126 */   private boolean injecting = false;
/*     */ 
/* 128 */   private Method maybeInjectMarshallingMethod = null;
/*     */ 
/* 130 */   private Method addMarshallingClassMethod = null;
/*     */ 
/*     */   public MarshallingClassLoader(ClassLoader parent)
/*     */   {
/*  17 */     super(parent);
/*  18 */     this.classPath = ClassPath.SYSTEM_CLASS_PATH;
/*     */   }
/*     */ 
/*     */   protected synchronized Class<?> loadClass(String className, boolean resolve)
/*     */     throws ClassNotFoundException
/*     */   {
/*  25 */     Class cl = (Class)this.loadedClasses.get(className);
/*  26 */     if (cl != null) {
/*  27 */       return cl;
/*     */     }
/*  29 */     for (int i = 0; i < ignoredPackages.length; i++) {
/*  30 */       if (className.startsWith(ignoredPackages[i])) {
/*  31 */         cl = getParent().loadClass(className);
/*  32 */         return cl;
/*     */       }
/*     */     }
/*  35 */     if ((!this.injecting) && 
/*  36 */       (this.marshallingRuntimeClass == null))
/*     */     {
/*  39 */       this.marshallingRuntimeClass = ((Class)this.loadedClasses.get("atavism.server.marshalling.MarshallingRuntime"));
/*  40 */       if (this.marshallingRuntimeClass != null) {
/*     */         try
/*     */         {
/*  43 */           this.maybeInjectMarshallingMethod = this.marshallingRuntimeClass.getMethod("maybeInjectMarshalling", new Class[] { className.getClass() });
/*  44 */           this.addMarshallingClassMethod = this.marshallingRuntimeClass.getMethod("addMarshallingClass", new Class[] { className.getClass(), getClass().getClass() });
/*  45 */           this.injecting = true;
/*     */         }
/*     */         catch (Exception e) {
/*  48 */           throw new RuntimeException("MarshallingClassLoader.loadClass: Could not find MarshallingRuntime.maybeInjectMarshalling method");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  53 */     boolean classInjected = false;
/*  54 */     if (this.injecting)
/*     */     {
/*     */       try
/*     */       {
/*  58 */         byte[] bytes = (byte[])(byte[])this.maybeInjectMarshallingMethod.invoke(null, new Object[] { className });
/*  59 */         if (bytes != null) {
/*  60 */           cl = defineClass(className, bytes, 0, bytes.length);
/*  61 */           classInjected = true;
/*     */         }
/*     */       } catch (Exception ex) {
/*  64 */         ex.printStackTrace();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  70 */     Class existingClass = (Class)this.loadedClasses.get(className);
/*  71 */     if (existingClass != null)
/*  72 */       return existingClass;
/*  73 */     if (cl == null)
/*  74 */       cl = loadClassWithoutInjection(className);
/*  75 */     if (resolve)
/*  76 */       resolveClass(cl);
/*  77 */     this.loadedClasses.put(className, cl);
/*  78 */     if (classInjected) {
/*     */       try {
/*  80 */         this.addMarshallingClassMethod.invoke(null, new Object[] { className, cl });
/*     */       }
/*     */       catch (Exception ex) {
/*  83 */         System.out.println("Exception while loading class " + className + ": " + ex);
/*  84 */         ex.printStackTrace();
/*  85 */         return null;
/*     */       }
/*     */     }
/*  88 */     return cl;
/*     */   }
/*     */ 
/*     */   protected Class loadClassWithoutInjection(String className) throws ClassNotFoundException
/*     */   {
/*     */     try {
/*  94 */       byte[] bytes = this.classPath.getBytes(className);
/*  95 */       Class cl = defineClass(className, bytes, 0, bytes.length);
/*  96 */       return cl; } catch (Exception e) {
/*     */     }
/*  98 */     throw new ClassNotFoundException("loadClassWithoutInjection: exception loading class '" + className + "': " + e.toString());
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.marshalling.MarshallingClassLoader
 * JD-Core Version:    0.6.0
 */