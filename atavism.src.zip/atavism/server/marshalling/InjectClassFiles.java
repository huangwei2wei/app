/*    */ package atavism.server.marshalling;
/*    */ 
/*    */ import atavism.server.util.Log;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class InjectClassFiles
/*    */ {
/*    */   public static void main(String[] argv)
/*    */     throws Throwable
/*    */   {
/* 22 */     Properties props = new Properties();
/* 23 */     props.put("log4j.appender.FILE", "org.apache.log4j.RollingFileAppender");
/* 24 */     props.put("log4j.appender.FILE.File", "${atavism.logs}/inject.out");
/* 25 */     props.put("log4j.appender.FILE.MaxFileSize", "50MB");
/* 26 */     props.put("log4j.appender.FILE.layout", "org.apache.log4j.PatternLayout");
/* 27 */     props.put("log4j.appender.FILE.layout.ConversionPattern", "%-5p %m%n");
/* 28 */     props.put("atavism.log_level", "0");
/* 29 */     props.put("log4j.rootLogger", "DEBUG, FILE");
/* 30 */     Log.init(props);
/*    */ 
/* 32 */     if ((argv.length < 6) || ((argv.length & 0x1) == 1)) {
/* 33 */       usage();
/* 34 */       System.exit(1);
/*    */     }
/* 36 */     List marshallersFiles = new LinkedList();
/* 37 */     String inputDir = "";
/* 38 */     String outputDir = "";
/* 39 */     String typeNumFileName = "";
/* 40 */     for (int i = 0; i < argv.length; i += 2) {
/* 41 */       String arg = argv[i];
/* 42 */       String value = argv[(i + 1)];
/* 43 */       if (arg.equals("-m")) {
/* 44 */         File marshallersFile = new File(value);
/* 45 */         if (marshallersFile.isFile()) {
/* 46 */           marshallersFiles.add(value);
/*    */         }
/*    */ 
/*    */       }
/* 50 */       else if (arg.equals("-i")) {
/* 51 */         File in = new File(value);
/* 52 */         if (in.isDirectory()) {
/* 53 */           inputDir = value;
/*    */         } else {
/* 55 */           System.err.println("Class file input directory '" + value + "' does not exist!");
/* 56 */           System.exit(1);
/*    */         }
/*    */       }
/* 59 */       else if (arg.equals("-o")) {
/* 60 */         File out = new File(value);
/* 61 */         if (out.isDirectory())
/* 62 */           out.mkdir();
/* 63 */         outputDir = value;
/*    */       }
/* 65 */       else if (arg.equals("-t")) {
/* 66 */         typeNumFileName = value;
/*    */       }
/*    */     }
/* 68 */     if (marshallersFiles.size() == 0) {
/* 69 */       System.err.println("No marshaller files were supplied!");
/* 70 */       System.exit(1);
/*    */     }
/* 72 */     if (inputDir == "") {
/* 73 */       System.err.println("The class file input directory was not supplied!");
/* 74 */       System.exit(1);
/*    */     }
/* 76 */     if (outputDir == "") {
/* 77 */       System.err.println("The class file output directory was not supplied!");
/* 78 */       System.exit(1);
/*    */     }
/* 80 */     if (typeNumFileName == "") {
/* 81 */       System.err.println("The typenumbers.txt file name to which type numbers are written was not supplied!");
/* 82 */       System.exit(1);
/*    */     }
/*    */ 
/* 86 */     String[] mr_argv = new String[argv.length + 1];
/* 87 */     System.arraycopy(argv, 0, mr_argv, 0, argv.length);
/* 88 */     mr_argv[argv.length] = "-r";
/*    */ 
/* 91 */     if (MarshallingRuntime.initialize(mr_argv)) {
/* 92 */       System.out.println("Exiting because MarshallingRuntime.initialize() found missing or incorrect classes");
/* 93 */       System.exit(1);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected static void usage() {
/* 98 */     System.out.println("Usage: java atavism.server.marshalling.InjectClassFiles [ -m marshallersfile.txt | -i input_directory | -o output_directory ]");
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.marshalling.InjectClassFiles
 * JD-Core Version:    0.6.0
 */