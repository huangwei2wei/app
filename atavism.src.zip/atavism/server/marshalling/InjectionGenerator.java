/*     */ package atavism.server.marshalling;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import java.io.File;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.bcel.Repository;
/*     */ import org.apache.bcel.classfile.Field;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.generic.ALOAD;
/*     */ import org.apache.bcel.generic.ArrayType;
/*     */ import org.apache.bcel.generic.BranchHandle;
/*     */ import org.apache.bcel.generic.CHECKCAST;
/*     */ import org.apache.bcel.generic.ClassGen;
/*     */ import org.apache.bcel.generic.ConstantPoolGen;
/*     */ import org.apache.bcel.generic.IF_ACMPEQ;
/*     */ import org.apache.bcel.generic.InstructionFactory;
/*     */ import org.apache.bcel.generic.InstructionHandle;
/*     */ import org.apache.bcel.generic.InstructionList;
/*     */ import org.apache.bcel.generic.InvokeInstruction;
/*     */ import org.apache.bcel.generic.LocalVariableGen;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.ObjectType;
/*     */ import org.apache.bcel.generic.Type;
/*     */ 
/*     */ public class InjectionGenerator
/*     */ {
/*     */   int currentStack;
/*     */   int maxStack;
/*     */   HashSet<MarshallingRuntime.ClassNameAndTypeNumber> classesToBeMarshalled;
/*     */   static String marshallingRuntimeClassName;
/*     */   static String marshallableClassName;
/*     */   static String aoByteBufferClassName;
/*     */   ObjectType aoByteBufferType;
/*     */   ObjectType OBJBOOLEAN;
/*     */   ObjectType OBJBYTE;
/*     */   ObjectType OBJCHAR;
/*     */   ObjectType OBJDOUBLE;
/*     */   ObjectType OBJFLOAT;
/*     */   ObjectType OBJINT;
/*     */   ObjectType OBJLONG;
/*     */   ObjectType OBJSHORT;
/* 899 */   protected boolean generateClassFiles = false;
/* 900 */   protected String outputDir = "";
/* 901 */   protected boolean listGeneratedCode = false;
/*     */   protected static PrimitiveTypeInfo[] primitiveTypes;
/* 920 */   protected static InjectionGenerator instance = null;
/*     */ 
/*     */   public InjectionGenerator(boolean generateClassFiles, String outputDir, boolean listGeneratedCode)
/*     */   {
/*  23 */     this.generateClassFiles = generateClassFiles;
/*  24 */     this.outputDir = outputDir;
/*  25 */     this.listGeneratedCode = listGeneratedCode;
/*     */   }
/*     */ 
/*     */   public static InjectionGenerator getInstance()
/*     */   {
/*  32 */     return instance;
/*     */   }
/*     */ 
/*     */   public JavaClass maybeInjectMarshalling(JavaClass clazz, Short typeNum)
/*     */   {
/*  43 */     String className = clazz.getClassName();
/*  44 */     int flagBitCount = 0;
/*  45 */     LinkedList fields = getValidClassFields(clazz);
/*  46 */     LinkedList nullTestedFields = new LinkedList();
/*     */ 
/*  48 */     int index = -1;
/*  49 */     for (Field f : fields) {
/*  50 */       index++;
/*  51 */       Type fieldType = f.getType();
/*     */ 
/*  53 */       if (!isPrimitiveType(fieldType)) {
/*  54 */         nullTestedFields.add(Integer.valueOf(index));
/*  55 */         flagBitCount++;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  60 */     JavaClass superclass = getValidSuperclass(clazz);
/*     */     try
/*     */     {
/*  64 */       clazz = injectMarshallingMethods(clazz, superclass, fields, nullTestedFields, flagBitCount);
/*  65 */       MarshallingRuntime.markInjected(className);
/*  66 */       Log.debug("Generated marshalling for '" + className + "', typeNum " + typeNum + "/0x" + Integer.toHexString(typeNum.shortValue()));
/*     */     }
/*     */     catch (Exception e) {
/*  69 */       Log.error("Injection into class '" + className + "' terminated due to exception: " + e.getMessage());
/*     */     }
/*  71 */     return clazz;
/*     */   }
/*     */ 
/*     */   protected JavaClass injectMarshallingMethods(JavaClass clazz, JavaClass superclass, LinkedList<Field> fields, LinkedList<Integer> nullTestedFields, int flagBitCount)
/*     */   {
/*  83 */     ClassGen classGen = new ClassGen(clazz);
/*  84 */     JavaClass updatedClass = classGen.getJavaClass();
/*  85 */     String className = updatedClass.getClassName();
/*  86 */     ConstantPoolGen cp = classGen.getConstantPool();
/*  87 */     InstructionFactory factory = new InstructionFactory(cp);
/*  88 */     initStack();
/*  89 */     MethodGen mmg = createMarshallingMethod(clazz, superclass, cp, factory, fields, nullTestedFields, flagBitCount);
/*     */ 
/*  91 */     mmg.setMaxStack(getFinalStack());
/*  92 */     initStack();
/*  93 */     MethodGen umg = createUnmarshallingMethod(clazz, superclass, cp, factory, fields, nullTestedFields, flagBitCount);
/*     */ 
/*  95 */     umg.setMaxStack(getFinalStack());
/*     */ 
/*  98 */     classGen.addInterface(marshallableClassName);
/*  99 */     classGen.addMethod(mmg.getMethod());
/* 100 */     classGen.addMethod(umg.getMethod());
/* 101 */     if (this.listGeneratedCode) {
/* 102 */       Log.debug("ConstantPool:\n" + cp.toString() + "\n");
/* 103 */       logGeneratedMethod(classGen, mmg);
/* 104 */       logGeneratedMethod(classGen, umg);
/*     */     }
/*     */ 
/* 108 */     mmg.getInstructionList().dispose();
/* 109 */     umg.getInstructionList().dispose();
/*     */ 
/* 111 */     if (this.generateClassFiles)
/*     */     {
/*     */       String pathname;
/*     */       String pathname;
/* 113 */       if (this.outputDir != "") {
/* 114 */         pathname = this.outputDir + className.replace(".", File.separator) + ".class";
/*     */       }
/*     */       else
/*     */       {
/* 121 */         pathname = "." + File.separator + "build" + File.separator + className.replace(".", File.separator) + ".class";
/*     */       }try {
/* 123 */         Log.debug("Replacing class file '" + className + "'");
/* 124 */         classGen.getJavaClass().dump(pathname);
/*     */       }
/*     */       catch (Exception e) {
/* 127 */         Log.error("Exception raised when writing class '" + updatedClass.getClassName() + "': " + e.getMessage());
/*     */       }
/*     */     }
/* 130 */     return classGen.getJavaClass();
/*     */   }
/*     */ 
/*     */   protected void logGeneratedMethod(ClassGen classGen, MethodGen method)
/*     */   {
/* 135 */     Log.debug("Method details:\n" + method.toString() + "\n" + "Method instructions:\n" + method.getInstructionList().toString());
/*     */   }
/*     */ 
/*     */   protected MethodGen createMarshallingMethod(JavaClass clazz, JavaClass superclass, ConstantPoolGen cp, InstructionFactory factory, LinkedList<Field> fields, LinkedList<Integer> nullTestedFields, int flagBitCount)
/*     */   {
/* 153 */     String className = clazz.getClassName();
/* 154 */     InstructionList il = new InstructionList();
/* 155 */     MethodGen mg = new MethodGen(1, Type.VOID, new Type[] { this.aoByteBufferType }, new String[] { "buf" }, "marshalObject", className, il, cp);
/*     */ 
/* 161 */     if (superclass != null) {
/* 162 */       il.append(new ALOAD(0));
/* 163 */       il.append(new ALOAD(1));
/* 164 */       addStack(2);
/* 165 */       il.append(factory.createInvoke(superclass.getClassName(), "marshalObject", Type.VOID, new Type[] { this.aoByteBufferType }, 183));
/*     */ 
/* 168 */       addStack(-2);
/*     */     }
/* 170 */     LocalVariableGen flagVar = null;
/* 171 */     int flagVarIndex = 0;
/* 172 */     if (flagBitCount > 0) {
/* 173 */       flagVar = mg.addLocalVariable("flag_bits", Type.BYTE, null, null);
/* 174 */       flagVarIndex = flagVar.getIndex();
/*     */     }
/* 176 */     int batches = (flagBitCount + 7) / 8;
/*     */ 
/* 178 */     for (int i = 0; i < batches; i++)
/*     */     {
/* 180 */       il.append(factory.createConstant(Integer.valueOf(0)));
/* 181 */       addStack(1);
/* 182 */       il.append(InstructionFactory.createStore(Type.BYTE, flagVarIndex));
/* 183 */       addStack(-1);
/* 184 */       int limit = Math.min(flagBitCount, (i + 1) * 8);
/* 185 */       int start = i * 8;
/* 186 */       for (int j = start; j < limit; j++)
/*     */       {
/* 190 */         boolean firstInBatch = (j & 0x7) == 0;
/* 191 */         Field f = (Field)fields.get(((Integer)nullTestedFields.get(j)).intValue());
/* 192 */         BranchFixup[] branchFixups = makeOmittedTest(clazz, f, factory, il);
/* 193 */         if (!firstInBatch) {
/* 194 */           il.append(InstructionFactory.createLoad(Type.BYTE, flagVarIndex));
/* 195 */           addStack(1);
/*     */         }
/* 197 */         il.append(factory.createConstant(Integer.valueOf(1 << j - start)));
/* 198 */         addStack(1);
/* 199 */         if (!firstInBatch) {
/* 200 */           il.append(InstructionFactory.createBinaryOperation("|", Type.BYTE));
/* 201 */           il.append(factory.createCast(Type.INT, Type.BYTE));
/* 202 */           addStack(-1);
/*     */         }
/* 204 */         il.append(InstructionFactory.createStore(Type.BYTE, flagVarIndex));
/* 205 */         addStack(-1);
/* 206 */         noteBranchTargets(branchFixups, il);
/*     */       }
/*     */ 
/* 209 */       il.append(new ALOAD(1));
/* 210 */       il.append(InstructionFactory.createLoad(Type.BYTE, flagVarIndex));
/* 211 */       addStack(2);
/* 212 */       il.append(factory.createInvoke(aoByteBufferClassName, "putByte", this.aoByteBufferType, new Type[] { Type.BYTE }, 182));
/*     */ 
/* 215 */       il.append(InstructionFactory.createPop(1));
/* 216 */       addStack(-2);
/*     */     }
/*     */ 
/* 219 */     int index = -1;
/* 220 */     for (Field f : fields) {
/* 221 */       index++;
/* 222 */       boolean tested = nullTestedFields.contains(Integer.valueOf(index));
/* 223 */       BranchFixup[] branchFixups = null;
/* 224 */       if (tested)
/* 225 */         branchFixups = makeOmittedTest(clazz, f, factory, il);
/* 226 */       addMarshallingForField(clazz, f, factory, il);
/* 227 */       if (tested)
/* 228 */         noteBranchTargets(branchFixups, il);
/*     */     }
/* 230 */     il.append(InstructionFactory.createReturn(Type.VOID));
/* 231 */     BranchFixup.fixAllFixups(il);
/* 232 */     return mg;
/*     */   }
/*     */ 
/*     */   protected void addMarshallingForField(JavaClass clazz, Field f, InstructionFactory factory, InstructionList il)
/*     */   {
/* 237 */     Type fieldType = f.getType();
/* 238 */     PrimitiveTypeInfo info = getPrimitiveTypeInfo(fieldType);
/* 239 */     if ((info != null) || (isStringType(fieldType)))
/*     */     {
/* 241 */       addAOByteBufferFieldPut(clazz, f, fieldType, info, factory, il);
/* 242 */     } else if ((fieldType instanceof ObjectType)) {
/* 243 */       ObjectType fieldObjectType = (ObjectType)fieldType;
/* 244 */       if (marshalledByMarshallingRuntimeMarshalObject(fieldObjectType))
/*     */       {
/* 247 */         il.append(new ALOAD(1));
/* 248 */         addStack(1);
/* 249 */         addFieldFetch(clazz, factory, f, il);
/* 250 */         il.append(factory.createInvoke(marshallingRuntimeClassName, "marshalObject", Type.VOID, new Type[] { this.aoByteBufferType, Type.OBJECT }, 184));
/*     */ 
/* 253 */         addStack(-(1 + fieldType.getSize()));
/*     */       }
/*     */       else {
/* 256 */         Short aggregateTypeNum = getAggregateTypeNum(fieldObjectType);
/* 257 */         if (aggregateTypeNum != null) {
/* 258 */           String s = aggregateTypeString(fieldObjectType);
/* 259 */           il.append(new ALOAD(1));
/* 260 */           addStack(1);
/* 261 */           addFieldFetch(clazz, factory, f, il);
/* 262 */           il.append(factory.createInvoke(marshallingRuntimeClassName, "marshal" + s, Type.VOID, new Type[] { this.aoByteBufferType, Type.OBJECT }, 184));
/*     */ 
/* 265 */           addStack(-(1 + fieldType.getSize()));
/*     */         }
/*     */         else
/*     */         {
/* 269 */           il.append(new ALOAD(1));
/* 270 */           addStack(1);
/* 271 */           addFieldFetch(clazz, factory, f, il);
/* 272 */           il.append(factory.createInvoke(marshallingRuntimeClassName, "marshalSerializable", Type.VOID, new Type[] { this.aoByteBufferType, fieldType }, 184));
/*     */ 
/* 275 */           addStack(-(1 + fieldType.getSize()));
/*     */         }
/*     */       }
/*     */     }
/* 279 */     else if ((fieldType instanceof ArrayType))
/*     */     {
/* 281 */       il.append(new ALOAD(1));
/* 282 */       addStack(1);
/* 283 */       addFieldFetch(clazz, factory, f, il);
/* 284 */       il.append(factory.createInvoke(marshallingRuntimeClassName, "marshalArray", Type.VOID, new Type[] { this.aoByteBufferType, fieldType }, 184));
/*     */ 
/* 287 */       addStack(-2);
/*     */     }
/*     */     else
/*     */     {
/* 292 */       throwError("In addtoBytesForField, unknown type '" + fieldType + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addAOByteBufferFieldPut(JavaClass clazz, Field f, Type fieldType, PrimitiveTypeInfo info, InstructionFactory factory, InstructionList il)
/*     */   {
/* 300 */     il.append(new ALOAD(1));
/* 301 */     addStack(1);
/* 302 */     addFieldFetch(clazz, factory, f, il);
/*     */ 
/* 304 */     if (isStringType(fieldType)) {
/* 305 */       il.append(factory.createInvoke(aoByteBufferClassName, "putString", this.aoByteBufferType, new Type[] { Type.STRING }, 182));
/*     */ 
/* 308 */       il.append(InstructionFactory.createPop(1));
/* 309 */       addStack(-(1 + fieldType.getSize()));
/* 310 */       return;
/*     */     }
/*     */ 
/* 313 */     if ((fieldType instanceof ObjectType)) {
/* 314 */       String className = info.objectType.getClassName();
/* 315 */       il.append(factory.createInvoke(className, info.valueString + "Value", info.type, new Type[0], 182));
/*     */ 
/* 318 */       addStack(-1 + info.type.getSize());
/*     */     }
/*     */ 
/* 321 */     if (info.type == Type.BOOLEAN)
/*     */     {
/* 323 */       BranchHandle branch1 = il.append(InstructionFactory.createBranchInstruction(153, il.getStart()));
/* 324 */       addStack(-1);
/* 325 */       BranchFixup branchFixup1 = new BranchFixup(branch1, il);
/* 326 */       il.append(factory.createConstant(Integer.valueOf(1)));
/* 327 */       addStack(1);
/* 328 */       BranchHandle branch2 = il.append(InstructionFactory.createBranchInstruction(167, il.getStart()));
/* 329 */       BranchFixup branchFixup2 = new BranchFixup(branch2, il);
/* 330 */       branchFixup1.atTarget(il);
/* 331 */       il.append(factory.createConstant(Integer.valueOf(0)));
/* 332 */       branchFixup2.atTarget(il);
/* 333 */       il.append(factory.createCast(Type.INT, Type.BYTE));
/*     */     }
/*     */ 
/* 336 */     il.append(factory.createInvoke(aoByteBufferClassName, "put" + info.aoByteBufferSuffix, this.aoByteBufferType, new Type[] { storageType(info.type) }, 182));
/*     */ 
/* 339 */     il.append(InstructionFactory.createPop(1));
/* 340 */     addStack(-(1 + info.type.getSize()));
/*     */   }
/*     */ 
/*     */   protected BranchFixup[] makeOmittedTest(JavaClass clazz, Field f, InstructionFactory factory, InstructionList il)
/*     */   {
/* 349 */     addFieldFetch(clazz, factory, f, il);
/*     */ 
/* 351 */     BranchHandle branch1 = il.append(InstructionFactory.createBranchInstruction(198, il.getStart()));
/* 352 */     addStack(-1);
/* 353 */     BranchFixup branchFixup1 = new BranchFixup(branch1, il);
/* 354 */     BranchFixup branchFixup2 = null;
/* 355 */     if (isStringType(f.getType())) {
/* 356 */       addFieldFetch(clazz, factory, f, il);
/* 357 */       il.append(factory.createConstant(""));
/* 358 */       addStack(1);
/* 359 */       BranchHandle branch2 = il.append(new IF_ACMPEQ(il.getStart()));
/* 360 */       addStack(-2);
/* 361 */       branchFixup2 = new BranchFixup(branch2, il);
/*     */     }
/* 363 */     if (branchFixup2 != null) {
/* 364 */       return new BranchFixup[] { branchFixup1, branchFixup2 };
/*     */     }
/* 366 */     return new BranchFixup[] { branchFixup1 };
/*     */   }
/*     */ 
/*     */   protected MethodGen createUnmarshallingMethod(JavaClass clazz, JavaClass superclass, ConstantPoolGen cp, InstructionFactory factory, LinkedList<Field> fields, LinkedList<Integer> nullTestedFields, int flagBitCount)
/*     */   {
/* 383 */     String className = clazz.getClassName();
/* 384 */     InstructionList il = new InstructionList();
/* 385 */     MethodGen mg = new MethodGen(1, Type.OBJECT, new Type[] { this.aoByteBufferType }, new String[] { "buf" }, "unmarshalObject", className, il, cp);
/*     */ 
/* 391 */     if (superclass != null) {
/* 392 */       il.append(new ALOAD(0));
/* 393 */       il.append(new ALOAD(1));
/* 394 */       addStack(2);
/* 395 */       il.append(factory.createInvoke(superclass.getClassName(), "unmarshalObject", Type.OBJECT, new Type[] { this.aoByteBufferType }, 183));
/*     */ 
/* 399 */       il.append(InstructionFactory.createPop(1));
/* 400 */       addStack(-2);
/*     */     }
/* 402 */     int batches = (flagBitCount + 7) / 8;
/* 403 */     LocalVariableGen[] flagVars = null;
/* 404 */     Integer[] flagVarIndices = null;
/*     */ 
/* 406 */     if (flagBitCount > 0) {
/* 407 */       flagVars = new LocalVariableGen[batches];
/* 408 */       flagVarIndices = new Integer[batches];
/* 409 */       for (int i = 0; i < batches; i++)
/*     */       {
/* 411 */         flagVars[i] = mg.addLocalVariable("flag_bits" + i, Type.BYTE, null, null);
/* 412 */         flagVarIndices[i] = Integer.valueOf(flagVars[i].getIndex());
/*     */ 
/* 414 */         il.append(new ALOAD(1));
/* 415 */         addStack(1);
/* 416 */         il.append(factory.createInvoke(aoByteBufferClassName, "getByte", Type.BYTE, new Type[0], 182));
/*     */ 
/* 419 */         il.append(InstructionFactory.createStore(Type.BYTE, flagVarIndices[i].intValue()));
/* 420 */         addStack(-1);
/*     */       }
/*     */     }
/*     */ 
/* 424 */     int flagBitIndex = -1;
/* 425 */     int fieldIndex = -1;
/* 426 */     for (Field f : fields) {
/* 427 */       fieldIndex++;
/* 428 */       Type fieldType = f.getType();
/* 429 */       boolean tested = nullTestedFields.contains(Integer.valueOf(fieldIndex));
/* 430 */       BranchHandle branch = null;
/* 431 */       BranchFixup branchFixup = null;
/* 432 */       if (tested) {
/* 433 */         flagBitIndex++;
/* 434 */         int flagVarNumber = flagBitIndex >> 3;
/* 435 */         int flagBitNumber = flagBitIndex & 0x7;
/* 436 */         il.append(InstructionFactory.createLoad(Type.BYTE, flagVars[flagVarNumber].getIndex()));
/* 437 */         il.append(factory.createConstant(Integer.valueOf(1 << flagBitNumber)));
/* 438 */         addStack(2);
/* 439 */         il.append(InstructionFactory.createBinaryOperation("&", Type.BYTE));
/* 440 */         addStack(-1);
/* 441 */         branch = il.append(InstructionFactory.createBranchInstruction(153, null));
/* 442 */         addStack(-1);
/* 443 */         branchFixup = new BranchFixup(branch, il);
/*     */       }
/*     */ 
/* 446 */       addUnmarshallingForField(clazz, f, factory, cp, il);
/*     */ 
/* 448 */       il.append(factory.createPutField(clazz.getClassName(), f.getName(), fieldType));
/* 449 */       addStack(-(1 + fieldType.getSize()));
/*     */ 
/* 451 */       if (branch != null) {
/* 452 */         branchFixup.atTarget(il);
/*     */       }
/*     */     }
/* 455 */     il.append(new ALOAD(0));
/* 456 */     addStack(1);
/* 457 */     il.append(InstructionFactory.createReturn(Type.OBJECT));
/* 458 */     addStack(-1);
/* 459 */     BranchFixup.fixAllFixups(il);
/*     */ 
/* 461 */     return mg;
/*     */   }
/*     */ 
/*     */   protected void addUnmarshallingForField(JavaClass clazz, Field f, InstructionFactory factory, ConstantPoolGen cp, InstructionList il)
/*     */   {
/* 466 */     Type fieldType = f.getType();
/* 467 */     PrimitiveTypeInfo info = getPrimitiveTypeInfo(fieldType);
/*     */ 
/* 469 */     il.append(new ALOAD(0));
/* 470 */     addStack(1);
/* 471 */     if ((info != null) || (isStringType(fieldType)))
/*     */     {
/* 473 */       addAOByteBufferFieldGet(clazz, f, fieldType, info, factory, il);
/*     */     }
/* 475 */     else if ((fieldType instanceof ObjectType)) {
/* 476 */       ObjectType fieldObjectType = (ObjectType)fieldType;
/* 477 */       il.append(new ALOAD(1));
/* 478 */       addStack(1);
/* 479 */       if (marshalledByMarshallingRuntimeMarshalObject(fieldObjectType))
/*     */       {
/* 481 */         il.append(factory.createInvoke(marshallingRuntimeClassName, "unmarshalObject", Type.OBJECT, new Type[] { this.aoByteBufferType }, 184));
/*     */       }
/*     */       else
/*     */       {
/* 486 */         Short aggregateTypeNum = getAggregateTypeNum(fieldObjectType);
/* 487 */         if (aggregateTypeNum != null) {
/* 488 */           String s = aggregateTypeString(fieldObjectType);
/* 489 */           il.append(factory.createInvoke(marshallingRuntimeClassName, "unmarshal" + s, Type.OBJECT, new Type[] { this.aoByteBufferType }, 184));
/*     */         }
/*     */         else
/*     */         {
/* 496 */           il.append(factory.createInvoke(marshallingRuntimeClassName, "unmarshalSerializable", Type.OBJECT, new Type[] { this.aoByteBufferType }, 184));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 503 */       if (!fieldObjectType.getClassName().equals("java.lang.Object"))
/* 504 */         il.append(new CHECKCAST(cp.addClass(fieldObjectType.getClassName())));
/*     */     }
/* 506 */     else if ((fieldType instanceof ArrayType))
/*     */     {
/* 508 */       il.append(factory.createInvoke(marshallingRuntimeClassName, "unmarshalArray", Type.OBJECT, new Type[] { this.aoByteBufferType }, 184));
/*     */     }
/*     */     else
/*     */     {
/* 515 */       throwError("In addtoBytesForField, unknown type '" + fieldType + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addAOByteBufferFieldGet(JavaClass clazz, Field f, Type fieldType, PrimitiveTypeInfo info, InstructionFactory factory, InstructionList il)
/*     */   {
/* 523 */     il.append(new ALOAD(1));
/* 524 */     addStack(1);
/* 525 */     if (isStringType(fieldType)) {
/* 526 */       il.append(factory.createInvoke(aoByteBufferClassName, "getString", Type.STRING, new Type[0], 182));
/*     */ 
/* 530 */       return;
/*     */     }
/*     */ 
/* 533 */     il.append(factory.createInvoke(aoByteBufferClassName, "get" + info.aoByteBufferSuffix, storageType(info.type), new Type[0], 182));
/*     */ 
/* 536 */     addStack(-1 + info.type.getSize());
/*     */ 
/* 538 */     if (info.type == Type.BOOLEAN)
/*     */     {
/* 540 */       BranchHandle branch1 = il.append(InstructionFactory.createBranchInstruction(153, il.getStart()));
/* 541 */       addStack(-1);
/* 542 */       BranchFixup branchFixup1 = new BranchFixup(branch1, il);
/* 543 */       il.append(factory.createConstant(Integer.valueOf(1)));
/* 544 */       addStack(1);
/* 545 */       BranchHandle branch2 = il.append(InstructionFactory.createBranchInstruction(167, il.getStart()));
/* 546 */       BranchFixup branchFixup2 = new BranchFixup(branch2, il);
/* 547 */       branchFixup1.atTarget(il);
/* 548 */       il.append(factory.createConstant(Integer.valueOf(0)));
/* 549 */       branchFixup2.atTarget(il);
/*     */     }
/* 551 */     if ((fieldType instanceof ObjectType)) {
/* 552 */       String className = info.objectType.getClassName();
/* 553 */       il.append(factory.createInvoke(className, "valueOf", info.objectType, new Type[] { info.type }, 184));
/*     */ 
/* 556 */       addStack(1 - info.type.getSize());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addFieldFetch(JavaClass clazz, InstructionFactory factory, Field f, InstructionList il)
/*     */   {
/* 565 */     il.append(new ALOAD(0));
/* 566 */     addStack(1);
/* 567 */     Type fieldType = f.getType();
/* 568 */     il.append(factory.createGetField(clazz.getClassName(), f.getName(), fieldType));
/* 569 */     int size = fieldType.getSize();
/* 570 */     addStack(-1 + size);
/*     */   }
/*     */ 
/*     */   protected static JavaClass lookupClass(String className) {
/*     */     try {
/* 575 */       return Repository.lookupClass(className);
/*     */     }
/*     */     catch (Exception e) {
/* 578 */       throwError("Could not find class '" + className + "'");
/* 579 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static PrimitiveTypeInfo getPrimitiveTypeInfo(Type type)
/*     */   {
/* 584 */     if ((type instanceof ObjectType)) {
/* 585 */       ObjectType ot = (ObjectType)type;
/* 586 */       String otName = ot.getClassName();
/* 587 */       for (PrimitiveTypeInfo info : primitiveTypes)
/* 588 */         if (otName.equals(info.objectType.getClassName()))
/* 589 */           return info;
/*     */     }
/*     */     else
/*     */     {
/* 593 */       for (PrimitiveTypeInfo info : primitiveTypes) {
/* 594 */         if (type == info.type)
/* 595 */           return info;
/*     */       }
/*     */     }
/* 598 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean isStringType(Type type) {
/* 602 */     if (!(type instanceof ObjectType))
/* 603 */       return false;
/* 604 */     ObjectType objectType = (ObjectType)type;
/* 605 */     return objectType.getClassName().equals("java.lang.String");
/*     */   }
/*     */ 
/*     */   protected static boolean isPrimitiveObjectType(Type type)
/*     */   {
/* 610 */     if ((type instanceof ObjectType)) {
/* 611 */       ObjectType ot = (ObjectType)type;
/* 612 */       String otName = ot.getClassName();
/* 613 */       for (PrimitiveTypeInfo info : primitiveTypes) {
/* 614 */         if (otName.equals(info.objectType.getClassName()))
/* 615 */           return true;
/*     */       }
/*     */     }
/* 618 */     return false;
/*     */   }
/*     */ 
/*     */   protected static boolean isPrimitiveType(Type type)
/*     */   {
/* 623 */     for (PrimitiveTypeInfo info : primitiveTypes) {
/* 624 */       if (type == info.type)
/* 625 */         return true;
/*     */     }
/* 627 */     return false;
/*     */   }
/*     */ 
/*     */   protected static String nonPrimitiveObjectTypeName(Type type)
/*     */   {
/* 632 */     if ((!isPrimitiveType(type)) && 
/* 633 */       ((type instanceof ObjectType))) {
/* 634 */       ObjectType ot = (ObjectType)type;
/* 635 */       String typeName = ot.getClassName();
/* 636 */       return typeName;
/*     */     }
/*     */ 
/* 639 */     return null;
/*     */   }
/*     */ 
/*     */   protected Type underlyingPrimitiveType(Type type)
/*     */   {
/* 644 */     if ((type instanceof ObjectType)) {
/* 645 */       ObjectType ot = (ObjectType)type;
/* 646 */       String typeName = ot.getClassName();
/* 647 */       for (PrimitiveTypeInfo info : primitiveTypes)
/* 648 */         if (typeName.equals(info.objectType.getClassName()))
/* 649 */           return info.type;
/*     */     }
/*     */     else
/*     */     {
/* 653 */       for (PrimitiveTypeInfo info : primitiveTypes) {
/* 654 */         if (type == info.type)
/* 655 */           return type;
/*     */       }
/*     */     }
/* 658 */     return null;
/*     */   }
/*     */ 
/*     */   protected Type storageType(Type type) {
/* 662 */     Type underlying = underlyingPrimitiveType(type);
/* 663 */     if (underlying == null) {
/* 664 */       throwError("In storageType, unknown type '" + type + "'");
/* 665 */       return null;
/*     */     }
/* 667 */     if (underlying == Type.BOOLEAN) {
/* 668 */       return Type.BYTE;
/*     */     }
/* 670 */     return underlying;
/*     */   }
/*     */ 
/*     */   protected Short getAggregateTypeNum(ObjectType fieldObjectType) {
/* 674 */     String s = fieldObjectType.getClassName();
/* 675 */     Short typeNum = MarshallingRuntime.builtinAggregateTypeNum(s);
/* 676 */     if (typeNum != null)
/* 677 */       return typeNum;
/* 678 */     if (s.equals("java.util.List"))
/* 679 */       return Short.valueOf(9);
/* 680 */     if (s.equals("java.util.Map"))
/* 681 */       return Short.valueOf(11);
/* 682 */     if (s.equals("java.util.Set")) {
/* 683 */       return Short.valueOf(14);
/*     */     }
/* 685 */     return null;
/*     */   }
/*     */ 
/*     */   protected String aggregateTypeString(ObjectType fieldObjectType) {
/* 689 */     String s = fieldObjectType.getClassName();
/* 690 */     if (MarshallingRuntime.builtinAggregateTypeNum(s) != null) {
/* 691 */       int indexOfDot = s.lastIndexOf(46);
/* 692 */       if (indexOfDot >= 0)
/* 693 */         return s.substring(indexOfDot + 1);
/*     */     }
/* 695 */     throwError("InjectionGenerator:addMarshallingForField: unrecognized aggregate type " + s);
/* 696 */     return "";
/*     */   }
/*     */ 
/*     */   protected boolean marshalledByMarshallingRuntimeMarshalObject(ObjectType fieldObjectType) {
/* 700 */     return (doesOrWillHandleMarshallable(fieldObjectType)) || (referencesInterface(fieldObjectType)) || (fieldObjectType.getClassName().equals("java.lang.Object"));
/*     */   }
/*     */ 
/*     */   protected boolean referencesInterface(ObjectType type)
/*     */   {
/*     */     try
/*     */     {
/* 707 */       return type.referencesInterfaceExact(); } catch (ClassNotFoundException e) {
/*     */     }
/* 709 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean doesOrWillHandleMarshallable(ObjectType type)
/*     */   {
/* 714 */     String className = type.getClassName();
/* 715 */     if (MarshallingRuntime.hasMarshallingProperties(className)) {
/* 716 */       return MarshallingRuntime.injectedClass(className);
/*     */     }
/* 718 */     return handlesMarshallable(type);
/*     */   }
/*     */ 
/*     */   protected boolean handlesMarshallable(ObjectType type) {
/* 722 */     String typeName = type.getClassName();
/* 723 */     return handlesMarshallable(typeName);
/*     */   }
/*     */ 
/*     */   public static boolean handlesMarshallable(String typeName) {
/* 727 */     JavaClass clazz = lookupClass(typeName);
/* 728 */     if (clazz == null)
/* 729 */       throwError("InjectionGenerator.handlesMarshallable: Could not find class '" + typeName + "'");
/* 730 */     return handlesMarshallable(clazz);
/*     */   }
/*     */ 
/*     */   public static boolean handlesMarshallable(JavaClass clazz) {
/* 734 */     String[] names = clazz.getInterfaceNames();
/* 735 */     for (String name : names) {
/* 736 */       if (marshallableClassName.equals(name))
/* 737 */         return true;
/*     */     }
/* 739 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean objectTypeIsInterface(ObjectType type) {
/* 743 */     return interfaceClass(type.getClassName());
/*     */   }
/*     */ 
/*     */   public static boolean interfaceClass(String s) {
/*     */     try {
/* 748 */       JavaClass jc = Repository.lookupClass(s);
/* 749 */       return !jc.isClass(); } catch (ClassNotFoundException e) {
/*     */     }
/* 751 */     return false;
/*     */   }
/*     */ 
/*     */   protected static LinkedList<Field> getValidClassFields(JavaClass c)
/*     */   {
/* 756 */     LinkedList validFields = new LinkedList();
/* 757 */     Field[] fields = c.getFields();
/* 758 */     for (Field f : fields) {
/* 759 */       if ((!f.isStatic()) && (!f.isTransient()))
/* 760 */         validFields.add(f);
/*     */     }
/* 762 */     return validFields;
/*     */   }
/*     */ 
/*     */   public static JavaClass getValidSuperclass(JavaClass c) {
/* 766 */     String superclassName = c.getSuperclassName();
/* 767 */     if (superclassName == null)
/* 768 */       return null;
/* 769 */     JavaClass superclass = lookupClass(superclassName);
/* 770 */     if ((superclass != null) && (!superclass.getClassName().equals("java.lang.Object")) && (!superclass.isInterface()))
/*     */     {
/* 773 */       return superclass;
/*     */     }
/* 775 */     return null;
/*     */   }
/*     */ 
/*     */   protected void noteBranchTargets(BranchFixup[] branchFixups, InstructionList il) {
/* 779 */     for (BranchFixup branchFixup : branchFixups)
/* 780 */       branchFixup.atTarget(il);
/*     */   }
/*     */ 
/*     */   protected void initStack() {
/* 784 */     this.currentStack = 0;
/* 785 */     this.maxStack = 0;
/*     */   }
/*     */ 
/*     */   protected void addStack(int count) {
/* 789 */     int newCurrent = this.currentStack + count;
/* 790 */     if (newCurrent < 0)
/* 791 */       throwError("InjectionGenerator.addStack: Stack depth below zero!");
/* 792 */     this.currentStack = newCurrent;
/* 793 */     if (newCurrent > this.maxStack)
/* 794 */       this.maxStack = newCurrent;
/*     */   }
/*     */ 
/*     */   protected int getFinalStack() {
/* 798 */     if (this.currentStack != 0)
/* 799 */       throwError("InjectionGenerator.getFinalStack: Final stack depth should be zero, but is " + this.currentStack);
/* 800 */     return this.maxStack;
/*     */   }
/*     */ 
/*     */   protected static void logInvoke(String s, InvokeInstruction iv, ConstantPoolGen cp) {
/* 804 */     Log.debug(s + " signature is '" + iv.getSignature(cp) + "', return type is " + iv.getReturnType(cp));
/*     */   }
/*     */ 
/*     */   protected static void throwError(String msg) {
/* 808 */     Log.error(msg);
/* 809 */     throw new RuntimeException(msg);
/*     */   }
/*     */ 
/*     */   protected void initializeGlobals()
/*     */   {
/* 854 */     marshallingRuntimeClassName = "atavism.server.marshalling.MarshallingRuntime";
/* 855 */     marshallableClassName = "atavism.server.marshalling.Marshallable";
/* 856 */     aoByteBufferClassName = "atavism.server.network.AOByteBuffer";
/*     */ 
/* 858 */     this.aoByteBufferType = new ObjectType(aoByteBufferClassName);
/*     */ 
/* 860 */     this.OBJBOOLEAN = new ObjectType("java.lang.Boolean");
/* 861 */     this.OBJBYTE = new ObjectType("java.lang.Byte");
/* 862 */     this.OBJCHAR = new ObjectType("java.lang.Character");
/* 863 */     this.OBJDOUBLE = new ObjectType("java.lang.Double");
/* 864 */     this.OBJFLOAT = new ObjectType("java.lang.Float");
/* 865 */     this.OBJINT = new ObjectType("java.lang.Integer");
/* 866 */     this.OBJLONG = new ObjectType("java.lang.Long");
/* 867 */     this.OBJSHORT = new ObjectType("java.lang.Short");
/*     */ 
/* 869 */     primitiveTypes = new PrimitiveTypeInfo[] { new PrimitiveTypeInfo(Type.BOOLEAN, this.OBJBOOLEAN, "Byte", "boolean"), new PrimitiveTypeInfo(Type.BYTE, this.OBJBYTE, "Byte", "byte"), new PrimitiveTypeInfo(Type.CHAR, this.OBJCHAR, "Char", "char"), new PrimitiveTypeInfo(Type.DOUBLE, this.OBJDOUBLE, "Double", "double"), new PrimitiveTypeInfo(Type.FLOAT, this.OBJFLOAT, "Float", "float"), new PrimitiveTypeInfo(Type.INT, this.OBJINT, "Int", "int"), new PrimitiveTypeInfo(Type.LONG, this.OBJLONG, "Long", "long"), new PrimitiveTypeInfo(Type.SHORT, this.OBJSHORT, "Short", "short") };
/*     */   }
/*     */ 
/*     */   public static void initialize(boolean generateClassFiles, String outputDir, boolean listGeneratedCode)
/*     */   {
/* 923 */     instance = new InjectionGenerator(generateClassFiles, outputDir, listGeneratedCode);
/* 924 */     instance.initializeGlobals();
/*     */   }
/*     */ 
/*     */   public static class PrimitiveTypeInfo
/*     */   {
/*     */     public Type type;
/*     */     public ObjectType objectType;
/*     */     public String aoByteBufferSuffix;
/*     */     public String valueString;
/*     */ 
/*     */     public PrimitiveTypeInfo(Type type, ObjectType objectType, String aoByteBufferSuffix, String valueString)
/*     */     {
/* 906 */       this.type = type;
/* 907 */       this.objectType = objectType;
/* 908 */       this.aoByteBufferSuffix = aoByteBufferSuffix;
/* 909 */       this.valueString = valueString;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class BranchFixup
/*     */   {
/*     */     public BranchHandle branch;
/*     */     public int lengthAtBranch;
/*     */     public int lengthAtTarget;
/* 850 */     public static LinkedList<BranchFixup> allBranchFixups = new LinkedList();
/*     */ 
/*     */     public BranchFixup(BranchHandle branch, InstructionList il)
/*     */     {
/* 819 */       this.branch = branch;
/* 820 */       this.lengthAtBranch = il.getLength();
/* 821 */       allBranchFixups.add(this);
/*     */     }
/*     */ 
/*     */     public void atTarget(InstructionList il) {
/* 825 */       this.lengthAtTarget = il.getLength();
/*     */     }
/*     */ 
/*     */     public static void fixAllFixups(InstructionList il) {
/* 829 */       for (BranchFixup branchFixup : allBranchFixups) {
/* 830 */         int delta = branchFixup.lengthAtTarget - branchFixup.lengthAtBranch + 1;
/* 831 */         BranchHandle branch = branchFixup.branch;
/* 832 */         InstructionHandle handle = branch;
/* 833 */         if (delta > 0) {
/* 834 */           for (int i = 0; i < delta; i++)
/* 835 */             handle = handle.getNext();
/*     */         }
/*     */         else {
/* 838 */           for (int i = 0; i < -delta; i++)
/* 839 */             handle = handle.getPrev();
/*     */         }
/* 841 */         branch.setTarget(handle);
/*     */       }
/* 843 */       allBranchFixups.clear();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.marshalling.InjectionGenerator
 * JD-Core Version:    0.6.0
 */