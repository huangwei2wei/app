/*     */ package atavism.server.marshalling;
/*     */ 
/*     */ import atavism.server.engine.PropertyFileReader;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.RuntimeMXBean;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class Trampoline
/*     */ {
/* 217 */   private static Properties properties = null;
/*     */ 
/*     */   protected static Class getClassForClassName(String className)
/*     */   {
/*     */     try
/*     */     {
/*  21 */       Class c = Class.forName(className);
/*  22 */       return c;
/*     */     } catch (Exception e) {
/*     */     }
/*  25 */     return null;
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */     throws Throwable
/*     */   {
/*  48 */     if (argv.length < 1) {
/*  49 */       System.out.println("Usage: java atavism.server.marshalling.Trampoline <main_class> [args]");
/*  50 */       return;
/*     */     }
/*  52 */     String mainClassName = argv[0];
/*  53 */     String[] new_argv = new String[argv.length - 1];
/*  54 */     System.arraycopy(argv, 1, new_argv, 0, new_argv.length);
/*     */ 
/*  58 */     boolean disableLogs = System.getProperty("atavism.disable_logs", "false").equals("true");
/*     */ 
/*  60 */     Log.init();
/*     */ 
/*  62 */     String pid = "?";
/*  63 */     RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
/*     */ 
/*  65 */     pid = runtimeBean.getName();
/*     */ 
/*  68 */     PropertyFileReader pfr = new PropertyFileReader();
/*  69 */     if (PropertyFileReader.usePropFile) {
/*  70 */       properties = pfr.readPropFile();
/*     */     }
/*     */ 
/*  73 */     properties = parsePropertyArgs(argv, properties);
/*     */ 
/*  80 */     String logLevelString = properties.getProperty("atavism.log_level");
/*     */ 
/*  82 */     Integer logLevel = null;
/*  83 */     if (logLevelString != null)
/*     */       try {
/*  85 */         logLevel = Integer.valueOf(Integer.parseInt(logLevelString.trim()));
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*  90 */     if (!disableLogs)
/*  91 */       Log.init(properties);
/*  92 */     else if (logLevel != null) {
/*  93 */       Log.setLogLevel(logLevel.intValue());
/*     */     }
/*  95 */     Log.info("pid " + pid);
/*  96 */     writePidFile(argv, pid);
/*     */ 
/*  98 */     Log.debug("Using property file " + PropertyFileReader.propFile);
/*  99 */     Log.debug("Properties are:");
/*     */ 
/* 101 */     Enumeration en = properties.propertyNames();
/* 102 */     while (en.hasMoreElements()) {
/* 103 */       String sKey = (String)en.nextElement();
/* 104 */       Log.debug("    " + sKey + " = " + properties.getProperty(sKey));
/*     */     }
/*     */ 
/* 107 */     if (logLevel != null) {
/* 108 */       Log.setLogLevel(logLevel.intValue());
/*     */     }
/* 110 */     Log.info("The log level is " + Log.getLogLevel());
/*     */ 
/* 112 */     String build = properties.getProperty("atavism.build");
/* 113 */     if (build != null) {
/* 114 */       Log.info("Atavism Server Build " + build);
/*     */     }
/*     */ 
/* 118 */     String[] mr_argv = new String[new_argv.length];
/* 119 */     System.arraycopy(new_argv, 0, mr_argv, 0, mr_argv.length);
/*     */ 
/* 122 */     if (MarshallingRuntime.initialize(mr_argv)) {
/* 123 */       System.out.println("Exiting because MarshallingRuntime.initialize() found missing or incorrect classes");
/* 124 */       System.exit(1);
/*     */     }
/*     */ 
/* 127 */     Class cl = getClassForClassName(mainClassName);
/* 128 */     if (cl == null) {
/* 129 */       System.out.println("Loading of class '" + mainClassName + "' returned null!");
/* 130 */       return;
/*     */     }
/* 132 */     Method method = null;
/*     */     try {
/* 134 */       method = cl.getMethod("main", new Class[] { argv.getClass() });
/*     */ 
/* 139 */       int m = method.getModifiers();
/* 140 */       Class r = method.getReturnType();
/* 141 */       if ((!Modifier.isPublic(m)) || (!Modifier.isStatic(m)) || (Modifier.isAbstract(m)) || (r != Void.TYPE))
/*     */       {
/* 143 */         throw new NoSuchMethodException();
/*     */       }
/*     */     } catch (NoSuchMethodException no) {
/* 146 */       System.out.println("In class " + mainClassName + ": public static void main(String[] argv) is not defined");
/*     */ 
/* 148 */       return;
/*     */     }
/*     */     try {
/* 151 */       method.invoke(null, new Object[] { new_argv });
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 156 */       throw ex.getCause();
/*     */     }
/*     */     catch (Exception ex) {
/* 159 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Properties getProperties()
/*     */   {
/* 167 */     return properties;
/*     */   }
/*     */ 
/*     */   private static Properties parsePropertyArgs(String[] args, Properties defaults)
/*     */   {
/* 173 */     Properties props = new Properties(defaults);
/* 174 */     for (int ii = 0; ii < args.length; ii++) {
/* 175 */       if ((args[ii].startsWith("-P")) && (args[ii].indexOf(61) != -1)) {
/* 176 */         int equal = args[ii].indexOf(61);
/* 177 */         String key = args[ii].substring(2, equal);
/* 178 */         String value = args[ii].substring(equal + 1);
/* 179 */         props.put(key, value);
/*     */       }
/*     */     }
/* 182 */     return props;
/*     */   }
/*     */ 
/*     */   private static void writePidFile(String[] argv, String pid)
/*     */   {
/* 187 */     String pidFileName = null;
/* 188 */     for (int ii = 0; ii < argv.length; ii++) {
/* 189 */       if (argv[ii].equals("--pid")) {
/* 190 */         pidFileName = argv[(ii + 1)];
/* 191 */         break;
/*     */       }
/*     */     }
/* 194 */     if (pidFileName == null) {
/* 195 */       return;
/*     */     }
/* 197 */     int nDigits = 0;
/* 198 */     for (int ii = 0; (ii < pid.length()) && 
/* 199 */       (Character.isDigit(pid.charAt(ii))); ii++)
/*     */     {
/* 200 */       nDigits++;
/*     */     }
/*     */ 
/* 204 */     if (nDigits == 0)
/* 205 */       return;
/*     */     try
/*     */     {
/* 208 */       FileOutputStream pidFile = new FileOutputStream(pidFileName);
/* 209 */       pidFile.write((pid.substring(0, nDigits) + "\n").getBytes());
/* 210 */       pidFile.close();
/*     */     }
/*     */     catch (IOException e) {
/* 213 */       Log.exception(pidFileName, e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.marshalling.Trampoline
 * JD-Core Version:    0.6.0
 */