/*      */ package atavism.server.marshalling;
/*      */ 
/*      */ import atavism.server.engine.OID;
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.util.Log;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileReader;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ import org.apache.bcel.Repository;
/*      */ import org.apache.bcel.classfile.Field;
/*      */ import org.apache.bcel.classfile.JavaClass;
/*      */ import org.apache.bcel.classfile.Method;
/*      */ import org.apache.bcel.generic.Type;
/*      */ 
/*      */ public class MarshallingRuntime
/*      */ {
/*  993 */   protected static HashMap<String, ClassProperties> classToClassProperties = new HashMap();
/*      */   protected static Class[] marshallers;
/* 1020 */   protected static boolean predefinedTypesInstalled = false;
/*      */ 
/* 1308 */   public static boolean initialized = false;
/*      */ 
/* 1498 */   static final byte[] HEX_CHAR_TABLE = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
/*      */   protected static final short nonStoredStart = -10;
/*      */   protected static final short typeNumPrimitiveBoolean = -9;
/*      */   protected static final short firstAtomicTypeNum = -9;
/*      */   protected static final short firstPrimitiveAtomicTypeNum = -9;
/*      */   protected static final short typeNumPrimitiveByte = -8;
/*      */   protected static final short typeNumPrimitiveDouble = -7;
/*      */   protected static final short typeNumPrimitiveFloat = -6;
/*      */   protected static final short typeNumPrimitiveInteger = -5;
/*      */   protected static final short typeNumPrimitiveLong = -4;
/*      */   protected static final short typeNumPrimitiveShort = -3;
/*      */   protected static final short lastPrimitiveAtomicTypeNum = -3;
/*      */   protected static final short builtinStart = 0;
/*      */   protected static final short typeNumBoolean = 1;
/*      */   protected static final short firstNonPrimitiveAtomicTypeNum = 1;
/*      */   protected static final short typeNumByte = 2;
/*      */   protected static final short typeNumDouble = 3;
/*      */   protected static final short typeNumFloat = 4;
/*      */   protected static final short typeNumInteger = 5;
/*      */   protected static final short typeNumLong = 6;
/*      */   protected static final short typeNumShort = 7;
/*      */   protected static final short typeNumString = 8;
/*      */   protected static final short lastNonPrimitiveAtomicTypeNum = 8;
/*      */   protected static final short lastAtomicTypeNum = 8;
/*      */   protected static final short typeNumLinkedList = 9;
/*      */   protected static final short typeNumArrayList = 10;
/*      */   protected static final short typeNumHashMap = 11;
/*      */   protected static final short typeNumLinkedHashMap = 12;
/*      */   protected static final short typeNumTreeMap = 13;
/*      */   protected static final short typeNumHashSet = 14;
/*      */   protected static final short typeNumLinkedHashSet = 15;
/*      */   protected static final short typeNumTreeSet = 16;
/*      */   protected static final short typeNumByteArray = 17;
/*      */   protected static final short registeredBuiltTypeCount = 17;
/*      */   protected static final short firstAggregateTypeNum = 9;
/*      */   protected static final short lastAggregateTypeNum = 17;
/*      */   protected static final short typeNumJavaSerializable = 18;
/*      */   protected static final short typeNumBooleanFalse = 19;
/*      */   protected static final short typeNumBooleanTrue = 20;
/*      */   protected static final short typeNumNull = 21;
/*      */   protected static final short firstExpansionTypeNum = 23;
/*      */   protected static final short lastExpansionTypeNum = 26;
/*      */   protected static final short lastBuiltinTypeNum = 26;
/* 1589 */   protected static short firstGeneratedValueType = 27;
/* 1590 */   protected static short nextGeneratedValueType = firstGeneratedValueType;
/*      */ 
/*      */   public static void registerMarshallingClass(String className, Short typeNum)
/*      */   {
/*   29 */     if (builtinType(typeNum)) {
/*   30 */       Log.error("For class " + className + ", the explicit type number " + typeNum + " is illegal, because " + " it conflicts with the builtin type numbers");
/*      */ 
/*   32 */       return;
/*      */     }
/*   34 */     Short n = getTypeNumForClassName(className);
/*   35 */     if (n != null) {
/*   36 */       Log.error("The type number for class '" + className + "' has already been defined as " + n);
/*   37 */       return;
/*      */     }
/*   39 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/*   40 */       n = ((ClassProperties)entry.getValue()).typeNum;
/*   41 */       if (n.equals(typeNum)) {
/*   42 */         Log.error("For class '" + className + "', the explicit type number " + typeNum + " is already used by class '" + (String)entry.getKey() + "'");
/*      */ 
/*   44 */         return;
/*      */       }
/*      */     }
/*   47 */     ClassProperties props = new ClassProperties(className, typeNum, false);
/*   48 */     classToClassProperties.put(className, props);
/*      */   }
/*      */ 
/*      */   public static void registerMarshallingClass(String className)
/*      */   {
/*   57 */     registerMarshallingClass(className, Short.valueOf(getNextGeneratedValueType()));
/*      */   }
/*      */ 
/*      */   protected static short getNextGeneratedValueType()
/*      */   {
/*   62 */     while (getClassForTypeNum(Short.valueOf(nextGeneratedValueType)) != null) {
/*   63 */       nextGeneratedValueType = (short)(nextGeneratedValueType + 1);
/*      */     }
/*   65 */     return nextGeneratedValueType;
/*      */   }
/*      */ 
/*      */   public static void addMarshallingClass(String className, Class c)
/*      */   {
/*   73 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*   74 */     if (props == null) {
/*   75 */       throwError("MarshallingRuntime.addMarshallingClass: could not look up class '" + className + "'");
/*      */     } else {
/*   77 */       Short typeNum = props.typeNum;
/*   78 */       if ((marshallers.length > typeNum.shortValue()) && (marshallers[typeNum.shortValue()] != null)) {
/*   79 */         throwError("MarshallingRuntime.addMarshallingClass: a marshaller for class '" + className + "' has already been inserted");
/*      */       }
/*      */       else
/*   82 */         addMarshaller(c, typeNum);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean hasMarshallingProperties(String className)
/*      */   {
/*   92 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*   93 */     return props != null;
/*      */   }
/*      */ 
/*      */   public static boolean injectedClass(String className)
/*      */   {
/*  104 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*  105 */     if (props == null) {
/*  106 */       return false;
/*      */     }
/*  108 */     return !props.builtin;
/*      */   }
/*      */ 
/*      */   public static byte[] maybeInjectMarshalling(String className)
/*      */     throws ClassNotFoundException
/*      */   {
/*  121 */     Short typeNum = classRequiresInjection(className);
/*      */ 
/*  123 */     if (typeNum != null) {
/*  124 */       JavaClass clazz = Repository.lookupClass(className);
/*  125 */       if (clazz != null) {
/*  126 */         if (!InjectionGenerator.handlesMarshallable(clazz)) {
/*  127 */           clazz = InjectionGenerator.instance.maybeInjectMarshalling(clazz, typeNum);
/*  128 */           byte[] bytes = clazz.getBytes();
/*  129 */           return bytes;
/*      */         }
/*      */       }
/*      */       else
/*  133 */         Log.error("MarshallingRuntime.classRequiresInjection: Could not look up class '" + className + "'");
/*      */     }
/*  135 */     return null;
/*      */   }
/*      */ 
/*      */   public static void marshalObject(AOByteBuffer buf, Object object)
/*      */   {
/*  153 */     if (object == null) {
/*  154 */       writeTypeNum(buf, Short.valueOf(21));
/*      */     } else {
/*  156 */       Class c = object.getClass();
/*  157 */       Short typeNum = getTypeNumForClass(c);
/*  158 */       if (typeNum == null)
/*      */       {
/*  160 */         writeTypeNum(buf, Short.valueOf(18));
/*  161 */         marshalSerializable(buf, object);
/*      */       }
/*  163 */       else if (typeNum.shortValue() > 26) {
/*  164 */         if (!(object instanceof Marshallable)) {
/*  165 */           Log.dumpStack("MarshallingRuntime:marshalObject: class '" + c.getName() + "' has typeNum " + typeNum + " but does not support interface Marshallable");
/*      */ 
/*  167 */           writeTypeNum(buf, Short.valueOf(21));
/*      */         }
/*      */         else {
/*  170 */           Marshallable marshallingObject = (Marshallable)object;
/*      */ 
/*  174 */           writeTypeNum(buf, typeNum);
/*  175 */           marshallingObject.marshalObject(buf);
/*      */         }
/*      */       }
/*  178 */       else if (typeNum.equals(Short.valueOf(1))) {
/*  179 */         Short booleanLiteral = Short.valueOf(((Boolean)object).booleanValue() ? 20 : 19);
/*  180 */         writeTypeNum(buf, booleanLiteral);
/*      */       }
/*      */       else
/*      */       {
/*  184 */         writeTypeNum(buf, typeNum);
/*  185 */         switch (typeNum.shortValue())
/*      */         {
/*      */         case 2:
/*  188 */           Byte byteVal = (Byte)object;
/*  189 */           buf.putByte(byteVal.byteValue());
/*  190 */           break;
/*      */         case 3:
/*  193 */           Double doubleVal = (Double)object;
/*  194 */           buf.putDouble(doubleVal.doubleValue());
/*  195 */           break;
/*      */         case 4:
/*  198 */           Float floatVal = (Float)object;
/*  199 */           buf.putFloat(floatVal.floatValue());
/*  200 */           break;
/*      */         case 5:
/*  203 */           Integer integerVal = (Integer)object;
/*  204 */           buf.putInt(integerVal.intValue());
/*  205 */           break;
/*      */         case 6:
/*  208 */           Long longVal = (Long)object;
/*  209 */           buf.putLong(longVal);
/*  210 */           break;
/*      */         case 7:
/*  213 */           Short shortVal = (Short)object;
/*  214 */           buf.putShort(shortVal.shortValue());
/*  215 */           break;
/*      */         case 8:
/*  218 */           buf.putString((String)object);
/*  219 */           break;
/*      */         case 9:
/*  222 */           marshalLinkedList(buf, object);
/*  223 */           break;
/*      */         case 10:
/*  226 */           marshalArrayList(buf, object);
/*  227 */           break;
/*      */         case 11:
/*  230 */           marshalHashMap(buf, object);
/*  231 */           break;
/*      */         case 12:
/*  234 */           marshalLinkedHashMap(buf, object);
/*  235 */           break;
/*      */         case 13:
/*  238 */           marshalTreeMap(buf, object);
/*  239 */           break;
/*      */         case 14:
/*  242 */           marshalHashSet(buf, object);
/*  243 */           break;
/*      */         case 15:
/*  246 */           marshalLinkedHashSet(buf, object);
/*  247 */           break;
/*      */         case 16:
/*  250 */           marshalTreeSet(buf, object);
/*  251 */           break;
/*      */         case 17:
/*  254 */           marshalByteArray(buf, object);
/*  255 */           break;
/*      */         default:
/*  258 */           throwError("In MarshallingRuntime.marshalObject: unknown typeNum '" + typeNum + "'");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Object unmarshalObject(AOByteBuffer buf)
/*      */   {
/*  278 */     Short typeNum = readTypeNum(buf);
/*      */ 
/*  280 */     if (typeNum.shortValue() > 26) {
/*  281 */       Class marshallingClass = marshallers[typeNum.shortValue()];
/*  282 */       if (marshallingClass == null) {
/*  283 */         throwError("MarshallingRuntime.unmarshalObject: no marshalling class for typeNum '" + typeNum + "'");
/*  284 */         return null;
/*      */       }
/*      */       try
/*      */       {
/*  288 */         Object object = marshallingClass.newInstance();
/*  289 */         Marshallable marshallingObject = (Marshallable)object;
/*  290 */         return marshallingObject.unmarshalObject(buf);
/*      */       }
/*      */       catch (Exception e) {
/*  293 */         throwError("MarshallingRuntime.unmarshalObject, exception running unmarshaller: " + e);
/*  294 */         return null;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  299 */     switch (typeNum.shortValue())
/*      */     {
/*      */     case 21:
/*  302 */       return null;
/*      */     case 19:
/*  305 */       return Boolean.valueOf(false);
/*      */     case 20:
/*  308 */       return Boolean.valueOf(true);
/*      */     case 1:
/*  311 */       return Boolean.valueOf(buf.getByte() != 0);
/*      */     case 2:
/*  314 */       return Byte.valueOf(buf.getByte());
/*      */     case 3:
/*  317 */       return Double.valueOf(buf.getDouble());
/*      */     case 4:
/*  320 */       return Float.valueOf(buf.getFloat());
/*      */     case 5:
/*  323 */       return Integer.valueOf(buf.getInt());
/*      */     case 6:
/*  326 */       return Long.valueOf(buf.getLong());
/*      */     case 7:
/*  329 */       return Short.valueOf(buf.getShort());
/*      */     case 8:
/*  332 */       return buf.getString();
/*      */     case 9:
/*  335 */       return unmarshalLinkedList(buf);
/*      */     case 10:
/*  338 */       return unmarshalArrayList(buf);
/*      */     case 11:
/*  341 */       return unmarshalHashMap(buf);
/*      */     case 12:
/*  344 */       return unmarshalLinkedHashMap(buf);
/*      */     case 13:
/*  347 */       return unmarshalTreeMap(buf);
/*      */     case 14:
/*  350 */       return unmarshalHashSet(buf);
/*      */     case 15:
/*  353 */       return unmarshalLinkedHashSet(buf);
/*      */     case 16:
/*  356 */       return unmarshalTreeSet(buf);
/*      */     case 17:
/*  359 */       return unmarshalByteArray(buf);
/*      */     case 18:
/*  362 */       return unmarshalSerializable(buf);
/*      */     }
/*      */ 
/*  365 */     throwError("In MarshallingRuntime.unmarshalObject: unknown typeNum '" + typeNum + "'");
/*  366 */     return null;
/*      */   }
/*      */ 
/*      */   public static void marshalMarshallingObject(AOByteBuffer buf, Object object)
/*      */   {
/*  385 */     Marshallable marshallingObject = (Marshallable)object;
/*  386 */     marshallingObject.marshalObject(buf);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalMarshallingObject(AOByteBuffer buf, Object object)
/*      */   {
/*  403 */     Marshallable marshallingObject = (Marshallable)object;
/*  404 */     Object result = marshallingObject.unmarshalObject(buf);
/*  405 */     return result;
/*      */   }
/*      */ 
/*      */   public static String getClassForTypeNum(Short typeNum)
/*      */   {
/*  414 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/*  415 */       Short entryTypeNum = ((ClassProperties)entry.getValue()).typeNum;
/*  416 */       if (entryTypeNum.equals(typeNum))
/*  417 */         return (String)entry.getKey();
/*      */     }
/*  419 */     return null;
/*      */   }
/*      */ 
/*      */   public static String registeredClassesAndTypes()
/*      */   {
/*  428 */     String s = "";
/*  429 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/*  430 */       Short typeNum = ((ClassProperties)entry.getValue()).typeNum;
/*  431 */       if (builtinType(typeNum))
/*      */         continue;
/*  433 */       if (s == "")
/*  434 */         s = s + ", ";
/*  435 */       s = s + "Class '" + (String)entry.getKey() + "': " + typeNum;
/*      */     }
/*  437 */     return s;
/*      */   }
/*      */ 
/*      */   protected static void writeTypeNum(AOByteBuffer buf, Short typeNum) {
/*  441 */     if (typeNum.shortValue() <= 255) {
/*  442 */       short b = typeNum.shortValue();
/*  443 */       buf.putByte((byte)b);
/*      */     }
/*      */     else {
/*  446 */       int firstByte = (typeNum.shortValue() >> 8) - 1 + 23;
/*  447 */       int secondByte = typeNum.shortValue() & 0xFF;
/*      */ 
/*  450 */       buf.putByte((byte)firstByte);
/*  451 */       buf.putByte((byte)secondByte);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static Short readTypeNum(AOByteBuffer buf) {
/*  456 */     int firstByte = byteToIntNoSignExtend(buf.getByte());
/*  457 */     if ((firstByte >= 23) && (firstByte <= 26)) {
/*  458 */       int secondByte = byteToIntNoSignExtend(buf.getByte());
/*  459 */       short typeNum = (short)(firstByte - 23 + 1 << 8 | secondByte);
/*      */ 
/*  462 */       return Short.valueOf(typeNum);
/*      */     }
/*      */ 
/*  465 */     return Short.valueOf((short)firstByte);
/*      */   }
/*      */ 
/*      */   protected static int byteToIntNoSignExtend(byte b) {
/*  469 */     return b & 0xFF;
/*      */   }
/*      */ 
/*      */   protected static boolean valueTypeNum(Short typeNum)
/*      */   {
/*  476 */     return (typeNum.equals(Short.valueOf(19))) || (typeNum.equals(Short.valueOf(20))) || (typeNum.equals(Short.valueOf(21)));
/*      */   }
/*      */ 
/*      */   public static boolean builtinType(Short typeNum)
/*      */   {
/*  487 */     return typeNum.shortValue() < 26;
/*      */   }
/*      */ 
/*      */   public static boolean builtinType(String className)
/*      */   {
/*  496 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*  497 */     return (props != null) && (props.builtin);
/*      */   }
/*      */ 
/*      */   public static Short builtinAggregateTypeNum(String className)
/*      */   {
/*  507 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*  508 */     if ((props == null) || (!props.builtin))
/*  509 */       return null;
/*  510 */     short typeNum = props.typeNum.shortValue();
/*  511 */     if ((typeNum >= 9) && (typeNum <= 17)) {
/*  512 */       return Short.valueOf(typeNum);
/*      */     }
/*  514 */     return null;
/*      */   }
/*      */ 
/*      */   protected static boolean marshalledTypeNum(Short typeNum) {
/*  518 */     return typeNum.shortValue() > 26;
/*      */   }
/*      */ 
/*      */   public static Short getTypeNumForClassOrBarf(Class c)
/*      */   {
/*  527 */     Short typeNum = getTypeNumForClass(c);
/*  528 */     if (typeNum == null) {
/*  529 */       Log.dumpStack("Did not find class '" + c.getName() + "' in the type num map");
/*  530 */       return Short.valueOf(21);
/*      */     }
/*      */ 
/*  533 */     return typeNum;
/*      */   }
/*      */ 
/*      */   protected static Short getTypeNumForClass(Class c)
/*      */   {
/*  538 */     return getTypeNumForClassName(c.getName());
/*      */   }
/*      */ 
/*      */   protected static Short getTypeNumForClassName(String className) {
/*  542 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*  543 */     if (props != null) {
/*  544 */       return props.typeNum;
/*      */     }
/*  546 */     return null;
/*      */   }
/*      */ 
/*      */   protected static Class getClassForClassName(String className)
/*      */   {
/*      */     try {
/*  552 */       Class c = Class.forName(className);
/*  553 */       if (c == null)
/*  554 */         Log.error("MarshallingRuntime.getClassForClassName: could not find class '" + className + "'");
/*  555 */       return c;
/*      */     }
/*      */     catch (Exception e) {
/*  558 */       Log.exception("MarshallingRuntime.getClassForClassName: could not find class", e);
/*  559 */     }return null;
/*      */   }
/*      */ 
/*      */   protected static String getClassNameForObject(Object object)
/*      */   {
/*  564 */     Class c = object.getClass();
/*  565 */     if (c != null) {
/*  566 */       return c.getName();
/*      */     }
/*  568 */     return "<Unknown>";
/*      */   }
/*      */ 
/*      */   protected static Short classRequiresInjection(String className) {
/*  572 */     if (classToClassProperties == null)
/*  573 */       return null;
/*  574 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*  575 */     if ((props != null) && (!props.injected)) {
/*  576 */       return props.typeNum;
/*      */     }
/*  578 */     return null;
/*      */   }
/*      */ 
/*      */   public static void markInjected(String className)
/*      */   {
/*  586 */     ClassProperties props = (ClassProperties)classToClassProperties.get(className);
/*  587 */     if (props == null)
/*  588 */       Log.error("MarshallingRuntime.markInjected: Didn't find class '" + className + "' in map");
/*  589 */     else if (props.injected)
/*  590 */       Log.error("MarshallingRuntime.markInjected: Class '" + className + "' is already injected");
/*      */     else
/*  592 */       props.injected = true;
/*      */   }
/*      */ 
/*      */   protected static void addMarshaller(Class c, Short typeNum)
/*      */   {
/*  600 */     if (marshallers.length <= typeNum.shortValue()) {
/*  601 */       int newSize = typeNum.shortValue() + 256;
/*  602 */       Class[] newMarshallers = new Class[newSize];
/*  603 */       for (int i = 0; i < marshallers.length; i++)
/*  604 */         newMarshallers[i] = marshallers[i];
/*  605 */       marshallers = newMarshallers;
/*      */     }
/*  607 */     Log.info("Added marshaller for class :" + c + " with typeNum: " + typeNum);
/*  608 */     marshallers[typeNum.shortValue()] = c;
/*      */   }
/*      */ 
/*      */   public static void marshalSerializable(AOByteBuffer buf, Object object)
/*      */   {
/*  620 */     Log.info("MarshallingRuntime.marshalSerializable: object " + object + ", class " + getClassNameForObject(object));
/*  621 */     ByteArrayOutputStream ba = null;
/*  622 */     if (!(object instanceof Serializable)) {
/*  623 */       Log.error("marshalSerializable: " + objectDescription(object) + " is not Serializable");
/*  624 */       Log.dumpStack();
/*      */     }
/*      */     else {
/*  627 */       ba = serialHelper(object);
/*  628 */     }if (ba == null)
/*  629 */       ba = serialHelper(null);
/*  630 */     byte[] cereal = ba.toByteArray();
/*  631 */     buf.putInt(cereal.length);
/*  632 */     buf.putBytes(cereal, 0, cereal.length);
/*      */   }
/*      */ 
/*      */   private static ByteArrayOutputStream serialHelper(Object object) {
/*      */     try {
/*  637 */       ByteArrayOutputStream ba = new ByteArrayOutputStream();
/*  638 */       ObjectOutputStream os = new ObjectOutputStream(ba);
/*  639 */       if (!(object instanceof Serializable))
/*  640 */         throw new RuntimeException("MarshallingRuntime.serialHelper: " + objectDescription(object) + " is not Serializable");
/*  641 */       os.writeObject(object);
/*  642 */       os.flush();
/*  643 */       ba.flush();
/*  644 */       return ba;
/*      */     }
/*      */     catch (Exception e) {
/*  647 */       Log.exception("Exception during marshalSerializable of " + objectDescription(object) + "; writing null value", e);
/*  648 */     }return null;
/*      */   }
/*      */ 
/*      */   private static String objectDescription(Object object)
/*      */   {
/*  653 */     if (object == null) {
/*  654 */       return "null";
/*      */     }
/*  656 */     return " object " + object + " of class " + getClassNameForObject(object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalSerializable(AOByteBuffer buf)
/*      */   {
/*  666 */     int length = 0;
/*      */     try {
/*  668 */       length = buf.getInt();
/*  669 */       byte[] cereal = new byte[length];
/*  670 */       buf.getBytes(cereal, 0, length);
/*  671 */       ByteArrayInputStream bs = new ByteArrayInputStream(cereal);
/*  672 */       ObjectInputStream ois = new ObjectInputStream(bs);
/*  673 */       Object object = ois.readObject();
/*      */ 
/*  675 */       Log.info("MarshallingRuntime.unmarshalSerializable: " + objectDescription(object));
/*  676 */       return object;
/*      */     }
/*      */     catch (Exception e) {
/*  679 */       Log.exception("MarshallingRuntime.unmarshalSerializable", e);
/*  680 */     }return null;
/*      */   }
/*      */ 
/*      */   protected static void throwError(String msg)
/*      */   {
/*  685 */     Log.error(msg);
/*  686 */     throw new RuntimeException(msg);
/*      */   }
/*      */ 
/*      */   private static void marshalListInternal(AOByteBuffer buf, Object object)
/*      */   {
/*  695 */     List list = (List)object;
/*  696 */     buf.putInt(list.size());
/*  697 */     for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object elt = i$.next();
/*  698 */       marshalObject(buf, elt); }
/*      */   }
/*      */ 
/*      */   private static Object unmarshalListInternal(AOByteBuffer buf, List<Object> list, int count) {
/*  702 */     for (int i = 0; i < count; i++)
/*  703 */       list.add(unmarshalObject(buf));
/*  704 */     return list;
/*      */   }
/*      */ 
/*      */   private static void marshalMapInternal(AOByteBuffer buf, Object object) {
/*  708 */     Map map = (Map)object;
/*  709 */     buf.putInt(map.size());
/*  710 */     for (Map.Entry entry : map.entrySet()) {
/*  711 */       marshalObject(buf, entry.getKey());
/*  712 */       marshalObject(buf, entry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Object unmarshalMapInternal(AOByteBuffer buf, Map<Object, Object> map) {
/*  717 */     int count = buf.getInt();
/*  718 */     for (int i = 0; i < count; i++)
/*  719 */       map.put(unmarshalObject(buf), unmarshalObject(buf));
/*  720 */     return map;
/*      */   }
/*      */ 
/*      */   private static void marshalSetInternal(AOByteBuffer buf, Object object) {
/*  724 */     Set set = (Set)object;
/*  725 */     buf.putInt(set.size());
/*  726 */     for (Iterator i$ = set.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/*  727 */       marshalObject(buf, obj); }
/*      */   }
/*      */ 
/*      */   private static Object unmarshalSetInternal(AOByteBuffer buf, Set<Object> set)
/*      */   {
/*  732 */     int count = buf.getInt();
/*  733 */     for (int i = 0; i < count; i++)
/*  734 */       set.add(unmarshalObject(buf));
/*  735 */     return set;
/*      */   }
/*      */ 
/*      */   public static void marshalLinkedList(AOByteBuffer buf, Object object)
/*      */   {
/*  750 */     marshalListInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalLinkedList(AOByteBuffer buf)
/*      */   {
/*  761 */     int count = buf.getInt();
/*  762 */     LinkedList list = new LinkedList();
/*  763 */     return unmarshalListInternal(buf, list, count);
/*      */   }
/*      */ 
/*      */   public static void marshalArrayList(AOByteBuffer buf, Object object)
/*      */   {
/*  774 */     marshalListInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalArrayList(AOByteBuffer buf)
/*      */   {
/*  785 */     int count = buf.getInt();
/*  786 */     ArrayList arrayList = new ArrayList(count);
/*  787 */     return unmarshalListInternal(buf, arrayList, count);
/*      */   }
/*      */ 
/*      */   public static void marshalHashMap(AOByteBuffer buf, Object object)
/*      */   {
/*  798 */     marshalMapInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalHashMap(AOByteBuffer buf)
/*      */   {
/*  809 */     HashMap map = new HashMap();
/*  810 */     return unmarshalMapInternal(buf, map);
/*      */   }
/*      */ 
/*      */   public static void marshalLinkedHashMap(AOByteBuffer buf, Object object)
/*      */   {
/*  821 */     marshalMapInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalLinkedHashMap(AOByteBuffer buf)
/*      */   {
/*  832 */     LinkedHashMap map = new LinkedHashMap();
/*  833 */     return unmarshalMapInternal(buf, map);
/*      */   }
/*      */ 
/*      */   public static void marshalTreeMap(AOByteBuffer buf, Object object)
/*      */   {
/*  844 */     marshalMapInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalTreeMap(AOByteBuffer buf)
/*      */   {
/*  855 */     TreeMap map = new TreeMap();
/*  856 */     return unmarshalMapInternal(buf, map);
/*      */   }
/*      */ 
/*      */   public static void marshalHashSet(AOByteBuffer buf, Object object)
/*      */   {
/*  867 */     marshalSetInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalHashSet(AOByteBuffer buf)
/*      */   {
/*  878 */     HashSet set = new HashSet();
/*  879 */     return unmarshalSetInternal(buf, set);
/*      */   }
/*      */ 
/*      */   public static void marshalLinkedHashSet(AOByteBuffer buf, Object object)
/*      */   {
/*  890 */     marshalSetInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalLinkedHashSet(AOByteBuffer buf)
/*      */   {
/*  901 */     LinkedHashSet set = new LinkedHashSet();
/*  902 */     return unmarshalSetInternal(buf, set);
/*      */   }
/*      */ 
/*      */   public static void marshalTreeSet(AOByteBuffer buf, Object object)
/*      */   {
/*  913 */     marshalSetInternal(buf, object);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalTreeSet(AOByteBuffer buf)
/*      */   {
/*  924 */     TreeSet set = new TreeSet();
/*  925 */     return unmarshalSetInternal(buf, set);
/*      */   }
/*      */ 
/*      */   public static void marshalByteArray(AOByteBuffer buf, Object object)
/*      */   {
/*  935 */     byte[] bytes = (byte[])(byte[])object;
/*  936 */     buf.putInt(bytes.length);
/*  937 */     for (byte b : bytes)
/*  938 */       buf.putByte(b);
/*      */   }
/*      */ 
/*      */   public static Object unmarshalByteArray(AOByteBuffer buf)
/*      */   {
/*  949 */     int count = buf.getInt();
/*  950 */     byte[] bytes = new byte[count];
/*  951 */     for (int i = 0; i < count; i++)
/*  952 */       bytes[i] = buf.getByte();
/*  953 */     return bytes;
/*      */   }
/*      */ 
/*      */   public static HashSet<ClassNameAndTypeNumber> getClassesToBeMarshalled()
/*      */   {
/*  978 */     HashSet pairs = new HashSet();
/*  979 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/*  980 */       Short typeNum = ((ClassProperties)entry.getValue()).typeNum;
/*  981 */       if (typeNum.shortValue() <= 26) {
/*      */         continue;
/*      */       }
/*  984 */       pairs.add(new ClassNameAndTypeNumber((String)entry.getKey(), typeNum));
/*      */     }
/*  986 */     return pairs;
/*      */   }
/*      */ 
/*      */   protected static void addPrimitiveToTypeMap(Object object, Short typeNum)
/*      */   {
/* 1023 */     String className = object.getClass().getName();
/* 1024 */     ClassProperties props = new ClassProperties(className, typeNum, true);
/* 1025 */     classToClassProperties.put(className, props);
/*      */   }
/*      */ 
/*      */   protected static boolean checkTypeReferences()
/*      */   {
/* 1037 */     boolean someMissing = false;
/* 1038 */     Map missingTypes = new HashMap();
/* 1039 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/* 1040 */       className = (String)entry.getKey();
/* 1041 */       ClassProperties props = (ClassProperties)entry.getValue();
/* 1042 */       if (props.builtin)
/*      */         continue;
/* 1044 */       c = javaClassOrNull(className);
/* 1045 */       if (c == null) {
/* 1046 */         Log.error("Could not find registered class '" + className + "'");
/* 1047 */         someMissing = true;
/* 1048 */         continue;
/*      */       }
/* 1050 */       if (!c.isPublic()) {
/* 1051 */         Log.error("Class '" + className + "' is not a public class");
/* 1052 */         someMissing = true;
/*      */       }
/*      */ 
/* 1065 */       Short n = props.typeNum;
/* 1066 */       if (marshalledTypeNum(n)) {
/* 1067 */         if (!c.isClass()) {
/* 1068 */           Log.error("Class '" + className + "' is an interface, not an instantiable class");
/* 1069 */           someMissing = true;
/* 1070 */           continue;
/*      */         }
/*      */ 
/* 1073 */         if (!hasNoArgConstructor(c)) {
/* 1074 */           Log.error("Class '" + className + "' does not have a public, no-args constructor");
/* 1075 */           someMissing = true;
/* 1076 */           continue;
/*      */         }
/* 1078 */         JavaClass superclass = InjectionGenerator.getValidSuperclass(c);
/* 1079 */         if (superclass != null)
/* 1080 */           checkClassPresent(c, superclass, missingTypes);
/* 1081 */         LinkedList fields = InjectionGenerator.getValidClassFields(c);
/* 1082 */         for (Field f : fields) {
/* 1083 */           Type fieldType = f.getType();
/* 1084 */           if (fieldType.getType() == 13) {
/* 1085 */             Log.error("For class '" + className + "', field '" + f.getName() + "' is an array, and arrays are not supported");
/* 1086 */             someMissing = true;
/*      */           }
/*      */ 
/* 1089 */           String rawName = InjectionGenerator.nonPrimitiveObjectTypeName(fieldType);
/* 1090 */           if (rawName != null) {
/* 1091 */             String name = translateFieldTypeName(rawName);
/* 1092 */             if (name.equals("java.lang.Object"))
/*      */               continue;
/* 1094 */             JavaClass fieldClass = javaClassOrNull(name);
/* 1095 */             if (fieldClass.isEnum()) {
/* 1096 */               Log.error("For class '" + className + "', field '" + f.getName() + "' is an enum, and enums are not supported");
/* 1097 */               someMissing = true;
/*      */             }
/* 1099 */             if (fieldClass == null) {
/* 1100 */               Log.error("For class '" + className + "', could not find field '" + f.getName() + "' class '" + name + "'");
/* 1101 */               someMissing = true;
/* 1102 */               continue;
/*      */             }
/* 1104 */             checkClassPresent(c, fieldClass, missingTypes);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     String className;
/*      */     JavaClass c;
/* 1109 */     if (missingTypes.size() > 0) {
/* 1110 */       for (Map.Entry entry : missingTypes.entrySet()) {
/* 1111 */         JavaClass c = (JavaClass)entry.getKey();
/* 1112 */         LinkedList refs = (LinkedList)entry.getValue();
/* 1113 */         String s = "";
/* 1114 */         for (JavaClass ref : refs) {
/* 1115 */           if (s != "")
/* 1116 */             s = s + ", ";
/* 1117 */           s = s + "'" + getSimpleClassName(ref) + "'";
/*      */         }
/* 1119 */         someMissing = true;
/* 1120 */         Log.error("Missing type '" + getSimpleClassName(c) + "' is referred to by type(s) " + s);
/*      */       }
/*      */     }
/* 1123 */     if (someMissing)
/* 1124 */       Log.error("Aborting code generation due to missing or incorrect types");
/* 1125 */     return someMissing;
/*      */   }
/*      */ 
/*      */   protected static boolean hasNoArgConstructor(JavaClass c)
/*      */   {
/* 1132 */     Method[] methods = c.getMethods();
/* 1133 */     boolean sawConstructor = false;
/* 1134 */     for (int i = 0; i < methods.length; i++) {
/* 1135 */       Method method = methods[i];
/* 1136 */       String methodName = method.getName();
/* 1137 */       if (methodName.equals("<init>")) {
/* 1138 */         sawConstructor = true;
/* 1139 */         if ((method.getArgumentTypes().length == 0) && (method.isPublic()) && (!method.isStatic()))
/*      */         {
/* 1141 */           return true;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1147 */     return !sawConstructor;
/*      */   }
/*      */ 
/*      */   protected static void checkClassPresent(JavaClass referringClass, JavaClass referredClass, Map<JavaClass, LinkedList<JavaClass>> missingTypes)
/*      */   {
/* 1152 */     Short s = getTypeNumFromJavaClass(referredClass);
/* 1153 */     if (s == null) {
/* 1154 */       LinkedList references = (LinkedList)missingTypes.get(referredClass);
/* 1155 */       if (references == null) {
/* 1156 */         references = new LinkedList();
/* 1157 */         missingTypes.put(referredClass, references);
/*      */       }
/* 1159 */       if (!references.contains(referringClass))
/* 1160 */         references.add(referringClass);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static Short getTypeNumFromJavaClass(JavaClass c) {
/* 1165 */     String className = c.getClassName();
/* 1166 */     Short typeNum = getTypeNumForClassName(className);
/* 1167 */     return typeNum;
/*      */   }
/*      */ 
/*      */   protected static String getSimpleClassName(JavaClass c) {
/* 1171 */     String name = c.getClassName();
/* 1172 */     int lastIndex = name.lastIndexOf(".");
/* 1173 */     return name.substring(lastIndex + 1);
/*      */   }
/*      */ 
/*      */   protected static String translateFieldTypeName(String s) {
/* 1177 */     if (InjectionGenerator.interfaceClass(s))
/* 1178 */       return "java.lang.Object";
/* 1179 */     if (builtinType(s))
/* 1180 */       return s;
/* 1181 */     if (s.equals("java.util.List"))
/* 1182 */       return "java.util.LinkedList";
/* 1183 */     if (s.equals("java.util.Map"))
/* 1184 */       return "java.util.HashMap";
/* 1185 */     if (s.equals("java.util.Set"))
/* 1186 */       return "java.util.HashSet";
/* 1187 */     if (s.equals("java.io.Serializable")) {
/* 1188 */       return "java.lang.Object";
/*      */     }
/* 1190 */     return s;
/*      */   }
/*      */ 
/*      */   protected static JavaClass javaClassOrNull(String className) {
/*      */     try {
/* 1195 */       return Repository.lookupClass(className);
/*      */     } catch (Exception e) {
/*      */     }
/* 1198 */     return null;
/*      */   }
/*      */ 
/*      */   public static void installPredefinedTypes()
/*      */   {
/* 1208 */     if (predefinedTypesInstalled) {
/* 1209 */       return;
/*      */     }
/* 1211 */     marshallers = new Class[256];
/*      */ 
/* 1215 */     Boolean booleanVal = Boolean.valueOf(true);
/* 1216 */     Byte byteVal = Byte.valueOf(3);
/* 1217 */     Short shortVal = Short.valueOf(3);
/* 1218 */     Integer integerVal = Integer.valueOf(3);
/* 1219 */     Long longVal = Long.valueOf(3L);
/* 1220 */     Float floatVal = Float.valueOf(3.0F);
/* 1221 */     Double doubleVal = Double.valueOf(3.0D);
/* 1222 */     String stringVal = "3";
/* 1223 */     LinkedList listVal = new LinkedList();
/* 1224 */     ArrayList arrayListVal = new ArrayList();
/* 1225 */     HashMap hashMapVal = new HashMap();
/* 1226 */     LinkedHashMap linkedHashMapVal = new LinkedHashMap();
/* 1227 */     TreeMap treeMapVal = new TreeMap();
/* 1228 */     HashSet hashSetVal = new HashSet();
/* 1229 */     LinkedHashSet linkedHashSetVal = new LinkedHashSet();
/* 1230 */     TreeSet treeSetVal = new TreeSet();
/* 1231 */     byte[] byteArrayVal = new byte[2];
/* 1232 */     OID oidVal = OID.fromLong(3L);
/*      */ 
/* 1234 */     addPrimitiveToTypeMap(booleanVal, Short.valueOf(1));
/* 1235 */     addPrimitiveToTypeMap(byteVal, Short.valueOf(2));
/* 1236 */     addPrimitiveToTypeMap(doubleVal, Short.valueOf(3));
/* 1237 */     addPrimitiveToTypeMap(floatVal, Short.valueOf(4));
/* 1238 */     addPrimitiveToTypeMap(integerVal, Short.valueOf(5));
/* 1239 */     addPrimitiveToTypeMap(longVal, Short.valueOf(6));
/* 1240 */     addPrimitiveToTypeMap(shortVal, Short.valueOf(7));
/* 1241 */     addPrimitiveToTypeMap(stringVal, Short.valueOf(8));
/* 1242 */     addPrimitiveToTypeMap(listVal, Short.valueOf(9));
/* 1243 */     addPrimitiveToTypeMap(arrayListVal, Short.valueOf(10));
/* 1244 */     addPrimitiveToTypeMap(hashMapVal, Short.valueOf(11));
/* 1245 */     addPrimitiveToTypeMap(linkedHashMapVal, Short.valueOf(12));
/* 1246 */     addPrimitiveToTypeMap(treeMapVal, Short.valueOf(13));
/* 1247 */     addPrimitiveToTypeMap(hashSetVal, Short.valueOf(14));
/* 1248 */     addPrimitiveToTypeMap(linkedHashSetVal, Short.valueOf(15));
/* 1249 */     addPrimitiveToTypeMap(treeSetVal, Short.valueOf(16));
/* 1250 */     addPrimitiveToTypeMap(byteArrayVal, Short.valueOf(17));
/* 1251 */     predefinedTypesInstalled = true;
/*      */   }
/*      */ 
/*      */   protected static void processMarshallers(String marshallerFile) {
/*      */     try {
/* 1256 */       if (Log.loggingDebug)
/* 1257 */         Log.debug("Processing marshaller file '" + marshallerFile + "'");
/* 1258 */       File f = new File(marshallerFile);
/* 1259 */       if (f.exists()) {
/* 1260 */         FileReader fReader = new FileReader(f);
/* 1261 */         BufferedReader in = new BufferedReader(fReader);
/* 1262 */         String originalLine = null;
/* 1263 */         while ((originalLine = in.readLine()) != null) {
/* 1264 */           String line = originalLine.trim();
/* 1265 */           int pos = line.indexOf("#");
/* 1266 */           if (pos >= 0)
/* 1267 */             line = line.substring(0, pos).trim();
/* 1268 */           if (line.length() == 0)
/*      */             continue;
/* 1270 */           if (line.indexOf(" ") > 0) {
/* 1271 */             Log.error("In marshallers file '" + marshallerFile + "', illegal line '" + originalLine + "'");
/* 1272 */             continue;
/*      */           }
/* 1274 */           String[] args = line.split(",", 2);
/* 1275 */           if (args.length == 2) {
/*      */             Short typeNum;
/*      */             try { typeNum = Short.decode(args[1]);
/*      */             } catch (NumberFormatException e) {
/* 1280 */               Log.error("In marshallers file '" + marshallerFile + "', illegal type number format in line '" + originalLine + "'");
/* 1281 */             }continue;
/*      */ 
/* 1283 */             registerMarshallingClass(args[0], typeNum);
/*      */           }
/*      */           else {
/* 1286 */             registerMarshallingClass(args[0]);
/*      */           }
/*      */         }
/* 1288 */         in.close();
/* 1289 */         Log.debug("Processing of marshallers file '" + marshallerFile + "' completed");
/*      */       } else {
/* 1291 */         Log.warn("Didn't find marshallers file '" + marshallerFile + "'");
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1295 */       Log.exception("MarshallingRuntime.processMarshallers", e);
/* 1296 */       System.exit(1);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static void registerMarshallingClasses(LinkedList<String> scripts) {
/* 1301 */     for (String script : scripts)
/* 1302 */       processMarshallers(script);
/*      */   }
/*      */ 
/*      */   public static boolean initialize(String[] argv)
/*      */   {
/* 1340 */     if (initialized)
/* 1341 */       Log.dumpStack("MarshallingRuntime.initialize() called twice!");
/* 1342 */     Log.info("Entered MarshallingRuntime.initialize()");
/* 1343 */     LinkedList scripts = new LinkedList();
/* 1344 */     boolean generateClassFiles = false;
/* 1345 */     String outputDir = "";
/* 1346 */     String typeNumFileName = "";
/* 1347 */     boolean listGeneratedCode = false;
/*      */ 
/* 1350 */     for (int i = 0; i < argv.length; i++) {
/* 1351 */       String flag = argv[i];
/* 1352 */       if (flag.equals("-m")) {
/* 1353 */         i++;
/* 1354 */         String arg = argv[i];
/* 1355 */         scripts.add(arg);
/*      */       }
/* 1357 */       else if (flag.equals("-r")) {
/* 1358 */         generateClassFiles = true;
/* 1359 */       } else if (flag.equals("-o")) {
/* 1360 */         i++;
/* 1361 */         outputDir = argv[i];
/*      */       }
/* 1363 */       else if (flag.equals("-t")) {
/* 1364 */         i++;
/* 1365 */         typeNumFileName = argv[i];
/*      */       }
/* 1367 */       else if (flag.equals("-g")) {
/* 1368 */         listGeneratedCode = true;
/*      */       }
/*      */     }
/* 1370 */     Log.debug("MarshallingRuntime.initialize: Installing primitive types");
/* 1371 */     installPredefinedTypes();
/* 1372 */     Log.debug("MarshallingRuntime.initialize: Initializing InjectionGenerator");
/* 1373 */     InjectionGenerator.initialize(generateClassFiles, outputDir, listGeneratedCode);
/* 1374 */     Log.debug("MarshallingRuntime.initialize: Registering Marshalling Classes");
/* 1375 */     registerMarshallingClasses(scripts);
/* 1376 */     int countRegistered = classToClassProperties.size() - 17;
/* 1377 */     Log.info("MarshallingRuntime.initialize: Registered " + countRegistered + " marshalling classes");
/* 1378 */     boolean broken = checkTypeReferences();
/* 1379 */     Log.debug("MarshallingRuntime.initialize: Finished checking type references");
/* 1380 */     if (!broken) {
/* 1381 */       injectAllClasses(outputDir, typeNumFileName);
/*      */     }
/*      */ 
/* 1384 */     Repository.clearCache();
/* 1385 */     initialized = true;
/* 1386 */     return broken;
/*      */   }
/*      */ 
/*      */   public static void initializeBatch(String typeNumFileName) {
/* 1390 */     Log.info("Entered MarshallingRuntime.initializeBatch: reading type nums from '" + typeNumFileName + "'");
/* 1391 */     installPredefinedTypes();
/* 1392 */     File typeNumFile = new File(typeNumFileName);
/* 1393 */     if (!typeNumFile.exists()) {
/* 1394 */       Log.error("MarshallingRuntime.initializeBatch: type num file '" + typeNumFileName + "' does not exist!");
/* 1395 */       return;
/*      */     }
/*      */     try {
/* 1398 */       FileReader reader = new FileReader(typeNumFile);
/* 1399 */       BufferedReader in = new BufferedReader(reader);
/*      */ 
/* 1401 */       int i = 0;
/*      */       String line;
/* 1402 */       while ((line = in.readLine()) != null)
/*      */       {
/* 1404 */         if (line.startsWith("#"))
/*      */           continue;
/* 1406 */         String[] fields = line.split(",");
/* 1407 */         String className = fields[0];
/* 1408 */         short typeNum = (short)Integer.parseInt(fields[1]);
/* 1409 */         ClassProperties props = new ClassProperties(className, Short.valueOf(typeNum), false);
/* 1410 */         classToClassProperties.put(className, props);
/* 1411 */         Class c = Class.forName(className);
/* 1412 */         addMarshaller(c, Short.valueOf(typeNum));
/* 1413 */         i++;
/*      */       }
/* 1415 */       Log.info("Entered MarshallingRuntime.initializeBatch: Registered " + i + " classes");
/* 1416 */       in.close();
/*      */     }
/*      */     catch (Exception e) {
/* 1419 */       Log.exception("MarshallingRuntime.initializeBatch: Exception reading type num file", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void injectAllClasses(String outputDir, String typeNumFileName)
/*      */   {
/* 1427 */     BufferedWriter out = null;
/* 1428 */     if (outputDir != "") {
/*      */       try {
/* 1430 */         File typeNumFile = new File(typeNumFileName);
/* 1431 */         Log.info("Writing type num files to '" + typeNumFile.getName() + "'");
/* 1432 */         FileWriter writer = new FileWriter(typeNumFile);
/* 1433 */         out = new BufferedWriter(writer);
/*      */       }
/*      */       catch (Exception e) {
/* 1436 */         Log.exception("MarshallingRuntime.injectAllClasses: Exception opening typenum file", e);
/*      */       }
/*      */     }
/* 1439 */     DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
/* 1440 */     Date date = new Date();
/* 1441 */     String dateString = dateFormat.format(date);
/*      */     try {
/* 1443 */       out.write("# This is a generated file - - do not edit!  Written at " + dateString + "\n");
/*      */     }
/*      */     catch (IOException e) {
/* 1446 */       Log.exception("MarshallingRuntime.injectAllClasses: Exception writing typenum file", e);
/*      */     }
/* 1448 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/* 1449 */       String className = (String)entry.getKey();
/* 1450 */       ClassProperties props = (ClassProperties)entry.getValue();
/* 1451 */       Short typeNum = props.typeNum;
/* 1452 */       if (props.builtin)
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/* 1458 */       if (outputDir != "")
/*      */       {
/* 1460 */         if (!InjectionGenerator.handlesMarshallable(className))
/*      */           try {
/* 1462 */             maybeInjectMarshalling(className);
/*      */           }
/*      */           catch (ClassNotFoundException e) {
/* 1465 */             Log.error("MarshallingRuntime.injectAllClasses: Could not load class '" + className + "'");
/*      */           }
/*      */         try
/*      */         {
/* 1469 */           out.write(className + "," + typeNum + "\n");
/*      */         }
/*      */         catch (IOException e) {
/* 1472 */           Log.exception("MarshallingRuntime.injectAllClasses: Exception writing typenum file", e);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1477 */         Class c = getClassForClassName(className);
/* 1478 */         if (InjectionGenerator.handlesMarshallable(className)) {
/* 1479 */           addMarshaller(c, typeNum);
/* 1480 */           Log.debug("Recorded by-hand marshaller '" + className + "', typeNum " + typeNum + "/0x" + Integer.toHexString(typeNum.shortValue()));
/* 1481 */           continue;
/*      */         }
/* 1483 */         if (c == null)
/* 1484 */           Log.error("MarshallingRuntime.injectAllClasses: Class.forName('" + className + "' did not return the Class object");
/*      */       }
/*      */     }
/* 1487 */     if (outputDir != "")
/*      */       try {
/* 1489 */         out.close();
/*      */       }
/*      */       catch (IOException e) {
/* 1492 */         Log.exception("MarshallingRuntime.injectAllClasses: Exception closing typenum file", e);
/*      */       }
/*      */   }
/*      */ 
/*      */   public static String getHexString(byte[] raw)
/*      */   {
/* 1508 */     byte[] hex = new byte[2 * raw.length];
/* 1509 */     int index = 0;
/*      */ 
/* 1511 */     for (byte b : raw) {
/* 1512 */       int v = b & 0xFF;
/* 1513 */       hex[(index++)] = HEX_CHAR_TABLE[(v >>> 4)];
/* 1514 */       hex[(index++)] = HEX_CHAR_TABLE[(v & 0xF)];
/*      */     }
/*      */     try {
/* 1517 */       return new String(hex, "ASCII"); } catch (UnsupportedEncodingException e) {
/*      */     }
/* 1519 */     return null;
/*      */   }
/*      */ 
/*      */   public static class ClassProperties
/*      */   {
/*      */     String className;
/*      */     Short typeNum;
/*      */     boolean builtin;
/*      */     boolean injected;
/*      */ 
/*      */     public ClassProperties(String className, Short typeNum, boolean builtin)
/*      */     {
/* 1003 */       this.className = className;
/* 1004 */       this.typeNum = typeNum;
/* 1005 */       this.builtin = builtin;
/* 1006 */       this.injected = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ClassNameAndTypeNumber
/*      */   {
/*      */     public String className;
/*      */     public Short typeNum;
/*      */ 
/*      */     public ClassNameAndTypeNumber(String className, Short typeNum)
/*      */     {
/*  963 */       this.className = className;
/*  964 */       this.typeNum = typeNum;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.marshalling.MarshallingRuntime
 * JD-Core Version:    0.6.0
 */