/*     */ package atavism.server.marshalling;
/*     */ 
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.FileWriter;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MarshallingGenerator extends MarshallingRuntime
/*     */ {
/* 452 */   private static String indentString = "                                                                ";
/*     */ 
/* 564 */   protected static String generatedMarshallingClass = "AOMarshalling";
/*     */ 
/* 567 */   protected static HashMap<Short, String> readOps = null;
/* 568 */   protected static HashMap<Short, String> writeOps = null;
/*     */ 
/* 571 */   protected static Class linkedListClass = null;
/* 572 */   protected static Class hashMapClass = null;
/* 573 */   protected static Class hashSetClass = null;
/*     */ 
/*     */   public static void setGeneratedMarshallingClass(String className)
/*     */   {
/*  64 */     generatedMarshallingClass = className;
/*     */   }
/*     */ 
/*     */   public static void generateMarshalling(String codeFile)
/*     */   {
/*  73 */     installPredefinedTypes();
/*  74 */     initializeCodeGenerator();
/*     */ 
/*  77 */     if (!checkTypeReferences()) {
/*  78 */       return;
/*     */     }
/*     */ 
/*  81 */     FileWriter str = null;
/*     */     try {
/*  83 */       str = new FileWriter(codeFile);
/*     */     }
/*     */     catch (Exception e) {
/*  86 */       Log.error("Exception opening generated file: " + e.getMessage());
/*     */     }
/*  88 */     int indent = 0;
/*     */ 
/*  90 */     writeLine(str, indent, "package atavism.server.marshalling;");
/*  91 */     writeLine(str, 0, "");
/*  92 */     writeLine(str, indent, "import java.io.*;");
/*  93 */     writeLine(str, indent, "import java.util.*;");
/*  94 */     writeLine(str, indent, "import atavism.server.util.*;");
/*  95 */     writeLine(str, indent, "import atavism.server.network.*;");
/*  96 */     writeLine(str, indent, "import atavism.msgsys.*;");
/*  97 */     writeLine(str, indent, "import atavism.server.plugins.*;");
/*  98 */     writeLine(str, indent, "import atavism.server.objects.*;");
/*  99 */     writeLine(str, indent, "import atavism.server.math.*;");
/* 100 */     writeLine(str, indent, "import atavism.server.plugins.WorldManagerClient.ObjectInfo;");
/*     */ 
/* 102 */     writeLine(str, 0, "");
/*     */ 
/* 104 */     writeLine(str, indent, "public class " + generatedMarshallingClass + " extends MarshallingRuntime {");
/* 105 */     indent++;
/*     */ 
/* 108 */     ArrayList sortedList = new ArrayList();
/* 109 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/* 110 */       String className = (String)entry.getKey();
/* 111 */       Short n = ((MarshallingRuntime.ClassProperties)entry.getValue()).typeNum;
/* 112 */       if ((n.shortValue() <= 26) || 
/* 114 */         (supportsMarshallable(className)))
/*     */         continue;
/* 116 */       sortedList.add(new MarshallingPair(className, n));
/*     */     }
/*     */ 
/* 123 */     for (MarshallingPair entry : sortedList) {
/* 124 */       String name = entry.getClassKey();
/* 125 */       Class c = lookupClass(name);
/* 126 */       Short n = entry.getTypeNum();
/* 127 */       int flagBitCount = 0;
/* 128 */       LinkedList fields = getValidClassFields(c);
/*     */ 
/* 130 */       LinkedList nullTestedFields = new LinkedList();
/* 131 */       int index = -1;
/* 132 */       for (Field f : fields) {
/* 133 */         index++;
/* 134 */         Class fieldType = getFieldType(f);
/*     */ 
/* 136 */         if (typeIsPrimitive(fieldType))
/*     */           continue;
/* 138 */         String fieldName = f.getName();
/* 139 */         Short fieldTypeNum = getTypeNumForClass(fieldType);
/* 140 */         if (fieldTypeNum == null) {
/* 141 */           Log.error("Field " + fieldName + " of type " + c + " has a type for which there is no encode/decode support");
/*     */         }
/* 147 */         else if ((fieldTypeNum.shortValue() < -9) || (fieldTypeNum.shortValue() > -3)) {
/* 148 */           nullTestedFields.add(Integer.valueOf(index));
/* 149 */           flagBitCount++;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 155 */       String className = getSimpleClassName(c);
/* 156 */       writeLine(str, indent, "public static class " + className + "Marshaller implements Marshallable {");
/* 157 */       indent++;
/* 158 */       generateToBytesMarshalling(c, n.shortValue(), str, indent, fields, nullTestedFields, flagBitCount);
/* 159 */       generateParseBytesMarshalling(c, n.shortValue(), str, indent);
/* 160 */       generateAssignBytesMarshalling(c, n.shortValue(), str, indent, fields, nullTestedFields, flagBitCount);
/* 161 */       indent--;
/* 162 */       writeLine(str, indent, "}");
/* 163 */       writeLine(str, 0, "");
/*     */       try {
/* 165 */         str.flush();
/*     */       }
/*     */       catch (Exception e) {
/* 168 */         Log.info("Could not flush output file!");
/*     */       }
/*     */     }
/* 171 */     writeLine(str, indent, "public static void initialize() {");
/* 172 */     indent++;
/* 173 */     for (MarshallingPair entry : sortedList) {
/* 174 */       String className = entry.getClassKey();
/* 175 */       Short n = entry.getTypeNum();
/* 176 */       writeLine(str, indent, "addMarshaller((short)" + n + ", new " + className + "Marshaller());");
/*     */     }
/* 178 */     indent--;
/* 179 */     writeLine(str, indent, "}");
/* 180 */     indent--;
/* 181 */     writeLine(str, indent, "}");
/*     */     try {
/* 183 */       str.close();
/*     */     }
/*     */     catch (Exception e) {
/* 186 */       Log.info("Could not close output file!");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static boolean checkTypeReferences()
/*     */   {
/* 223 */     Map missingTypes = new HashMap();
/* 224 */     for (Map.Entry entry : classToClassProperties.entrySet()) {
/* 225 */       String className = (String)entry.getKey();
/* 226 */       c = lookupClass(className);
/* 227 */       Short n = ((MarshallingRuntime.ClassProperties)entry.getValue()).typeNum;
/* 228 */       if (marshalledTypeNum(n)) {
/* 229 */         Class superclass = getValidSuperclass(c);
/* 230 */         if (superclass != null)
/* 231 */           checkClassPresent(c, superclass, missingTypes);
/* 232 */         LinkedList fields = getValidClassFields(c);
/* 233 */         for (Field f : fields) {
/* 234 */           Class fieldType = getFieldType(f);
/* 235 */           checkClassPresent(c, fieldType, missingTypes);
/*     */         }
/*     */       }
/*     */     }
/*     */     Class c;
/* 239 */     if (missingTypes.size() > 0) {
/* 240 */       for (Map.Entry entry : missingTypes.entrySet()) {
/* 241 */         Class c = (Class)entry.getKey();
/* 242 */         LinkedList refs = (LinkedList)entry.getValue();
/* 243 */         String s = "";
/* 244 */         for (Class ref : refs) {
/* 245 */           if (s != "")
/* 246 */             s = s + ", ";
/* 247 */           s = s + "'" + getSimpleClassName(ref) + "'";
/*     */         }
/* 249 */         Log.error("Missing type '" + getSimpleClassName(c) + "' is referred to by type(s) " + s);
/*     */       }
/* 251 */       Log.error("Aborting code generation due to missing types");
/* 252 */       return false;
/*     */     }
/*     */ 
/* 255 */     return true;
/*     */   }
/*     */ 
/*     */   protected static boolean supportsMarshallable(String className) {
/* 259 */     Class c = lookupClass(className);
/* 260 */     for (Class iface : c.getInterfaces()) {
/* 261 */       if (iface.getSimpleName().equals("Marshallable"))
/* 262 */         return true;
/*     */     }
/* 264 */     return false;
/*     */   }
/*     */ 
/*     */   protected static void generateToBytesMarshalling(Class c, int n, FileWriter str, int indent, LinkedList<Field> fields, LinkedList<Integer> nullTestedFields, int flagBitCount)
/*     */   {
/* 269 */     String className = getSimpleClassName(c);
/* 270 */     writeLine(str, indent, "public void toBytes(AOByteBuffer buf, Object object) {");
/* 271 */     indent++;
/* 272 */     writeLine(str, indent, className + " me = (" + className + ")object;");
/*     */ 
/* 274 */     Class superclass = getValidSuperclass(c);
/* 275 */     if (superclass != null) {
/* 276 */       Short typeNum = getTypeNumForClass(superclass);
/* 277 */       writeLine(str, indent, "MarshallingRuntime.marshallers[" + typeNum + "].toBytes(buf, object);");
/*     */     }
/*     */ 
/* 281 */     int batches = (flagBitCount + 7) / 8;
/* 282 */     for (int i = 0; i < batches; i++) {
/* 283 */       int limit = Math.min(flagBitCount, (i + 1) * 8);
/* 284 */       String s = "buf.writeByte(";
/* 285 */       int start = i * 8;
/* 286 */       for (int j = start; j < limit; j++) {
/* 287 */         int index = j - i * 8;
/* 288 */         Field f = (Field)fields.get(((Integer)nullTestedFields.get(j)).intValue());
/* 289 */         String test = "(" + makeOmittedTest(f) + " ? " + (1 << index) + " : 0)";
/* 290 */         s = s + test;
/* 291 */         if (j < limit - 1) {
/* 292 */           s = s + " |";
/* 293 */           if (j == start)
/* 294 */             writeLine(str, indent, s);
/*     */           else
/* 296 */             writeLine(str, indent + 2, s);
/*     */         }
/*     */         else {
/* 299 */           s = s + ");";
/* 300 */           writeLine(str, j == start ? indent : indent + 2, s);
/*     */         }
/* 302 */         s = "";
/*     */       }
/*     */     }
/*     */ 
/* 306 */     int index = -1;
/* 307 */     for (Field f : fields) {
/* 308 */       index++;
/* 309 */       String fieldName = f.getName();
/* 310 */       Class fieldType = getFieldType(f);
/* 311 */       Short fieldTypeNum = getTypeNumForClass(fieldType);
/* 312 */       boolean tested = nullTestedFields.contains(Integer.valueOf(index));
/* 313 */       if (tested) {
/* 314 */         writeLine(str, indent, "if " + makeOmittedTest(f));
/* 315 */         indent++;
/*     */       }
/* 317 */       writeLine(str, indent, createWriteOp(fieldType, new StringBuilder().append("me.").append(fieldName).toString(), fieldTypeNum) + ";");
/* 318 */       if (tested)
/* 319 */         indent--;
/*     */     }
/* 321 */     indent--;
/* 322 */     writeLine(str, indent, "}");
/* 323 */     writeLine(str, 0, "");
/*     */   }
/*     */ 
/*     */   protected static void generateParseBytesMarshalling(Class c, int n, FileWriter str, int indent) {
/* 327 */     String className = getSimpleClassName(c);
/* 328 */     writeLine(str, indent, "public Object parseBytes(AOByteBuffer buf) {");
/* 329 */     indent++;
/* 330 */     writeLine(str, indent, className + " me = new " + className + "();");
/* 331 */     writeLine(str, indent, "assignBytes(buf, me);");
/* 332 */     writeLine(str, indent, "return me;");
/* 333 */     indent--;
/* 334 */     writeLine(str, indent, "}");
/* 335 */     writeLine(str, 0, "");
/*     */   }
/*     */ 
/*     */   protected static void generateAssignBytesMarshalling(Class c, int n, FileWriter str, int indent, LinkedList<Field> fields, LinkedList<Integer> nullTestedFields, int flagBitCount)
/*     */   {
/* 342 */     String className = getSimpleClassName(c);
/* 343 */     writeLine(str, indent, "public void assignBytes(AOByteBuffer buf, Object object) {");
/* 344 */     indent++;
/* 345 */     writeLine(str, indent, className + " me = (" + className + ")object;");
/*     */ 
/* 347 */     Class superclass = getValidSuperclass(c);
/* 348 */     if (superclass != null) {
/* 349 */       Short typeNum = getTypeNumForClass(superclass);
/* 350 */       writeLine(str, indent, "MarshallingRuntime.marshallers[" + typeNum + "].Marshaller.assignBytes(buf, object);");
/*     */     }
/* 352 */     if (flagBitCount > 0)
/*     */     {
/* 355 */       int batches = (flagBitCount + 7) / 8;
/* 356 */       if (batches > 1) {
/* 357 */         for (int i = 0; i < batches; i++)
/* 358 */           writeLine(str, indent, "byte flags" + i + " = buf.getByte();");
/*     */       }
/*     */       else {
/* 361 */         writeLine(str, indent, "byte flags = buf.getByte();");
/*     */       }
/*     */     }
/* 364 */     int index = -1;
/* 365 */     int testIndex = -1;
/* 366 */     for (Field f : fields) {
/* 367 */       index++;
/* 368 */       String fieldName = f.getName();
/* 369 */       Class fieldType = getFieldType(f);
/* 370 */       Short fieldTypeNum = getTypeNumForClass(fieldType);
/* 371 */       boolean tested = nullTestedFields.contains(Integer.valueOf(index));
/* 372 */       if (tested) {
/* 373 */         testIndex++;
/* 374 */         writeLine(str, indent, "if " + formatFlagBitReference(testIndex, flagBitCount));
/* 375 */         indent++;
/*     */       }
/* 377 */       String op = createReadOp(fieldType, fieldName, fieldTypeNum.shortValue());
/* 378 */       writeLine(str, indent, op + ";");
/* 379 */       if (tested)
/* 380 */         indent--;
/*     */     }
/* 382 */     indent--;
/* 383 */     writeLine(str, indent, "}");
/*     */   }
/*     */ 
/*     */   protected static String makeOmittedTest(Field f) {
/* 387 */     Class fieldType = getFieldType(f);
/* 388 */     String test = "(me." + f.getName() + " != null)";
/* 389 */     if (isStringType(fieldType))
/* 390 */       test = "(" + test + " && !(me." + f.getName() + ".equals(\"\")))";
/* 391 */     return test;
/*     */   }
/*     */ 
/*     */   protected static String createWriteOp(Class c, String getter, Short fieldTypeNum) {
/* 395 */     if ((fieldTypeNum.shortValue() >= -9) && (fieldTypeNum.shortValue() <= 8)) {
/* 396 */       String s = (String)writeOps.get(fieldTypeNum);
/* 397 */       if (s == null) {
/* 398 */         Log.error("Could not find the writeOp for fieldTypeNum " + fieldTypeNum);
/* 399 */         return "<Didn't get writeOp for typeNum" + fieldTypeNum + ">";
/*     */       }
/*     */ 
/* 403 */       return s.replaceAll("\\#", getter);
/*     */     }
/*     */ 
/* 407 */     return "MarshallingRuntime.marshallers[" + fieldTypeNum + "].toBytes(buf, " + getter + ")";
/*     */   }
/*     */ 
/*     */   protected static String createReadOp(Class c, String fieldName, short fieldTypeNum) {
/* 411 */     if ((fieldTypeNum >= -9) && (fieldTypeNum <= 8)) {
/* 412 */       String s = (String)readOps.get(Short.valueOf(fieldTypeNum));
/* 413 */       if (s == null) {
/* 414 */         Log.error("Could not find the readOp for fieldTypeNum " + fieldTypeNum);
/* 415 */         return "";
/*     */       }
/*     */ 
/* 418 */       return "me." + fieldName + " = " + s;
/*     */     }
/*     */ 
/* 422 */     return "me." + fieldName + " = MarshallingRuntime.marshallers[" + fieldTypeNum + "].parseBytes(buf)";
/*     */   }
/*     */ 
/*     */   protected static void checkClassPresent(Class referringClass, Class referredClass, Map<Class, LinkedList<Class>> missingTypes)
/*     */   {
/* 427 */     Short s = getTypeNumForClass(referredClass);
/* 428 */     if (s == null) {
/* 429 */       LinkedList references = (LinkedList)missingTypes.get(referredClass);
/* 430 */       if (references == null) {
/* 431 */         references = new LinkedList();
/* 432 */         missingTypes.put(referredClass, references);
/*     */       }
/* 434 */       if (!references.contains(referringClass))
/* 435 */         references.add(referringClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static String formatFlagBitReference(int index, int flagBitCount) {
/* 440 */     if (flagBitCount > 8) {
/* 441 */       return "((flags" + (index >> 3) + " & " + (1 << (index & 0x7)) + ") != 0)";
/*     */     }
/* 443 */     return "((flags & " + (1 << index) + ") != 0)";
/*     */   }
/*     */ 
/*     */   protected static String formatTitle(String n) {
/* 447 */     String[] parts = n.split("\\.");
/* 448 */     return parts[(parts.length - 1)];
/*     */   }
/*     */ 
/*     */   protected static void writeLine(FileWriter str, int indent, String s)
/*     */   {
/*     */     try
/*     */     {
/* 456 */       str.write(indentString.substring(0, indent * 4) + s + "\r\n");
/*     */     }
/*     */     catch (Exception e) {
/* 459 */       Log.error("Error writing generated file: " + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static boolean isStaticOrTransient(Field f) {
/* 464 */     return (f.getModifiers() & 0x88) != 0;
/*     */   }
/*     */ 
/*     */   protected static Class getValidSuperclass(Class c) {
/* 468 */     Class superclass = c.getSuperclass();
/* 469 */     if ((superclass != null) && ((superclass.getModifiers() & 0x200) == 0) && (!getSimpleClassName(superclass).equals("Object")))
/*     */     {
/* 472 */       return superclass;
/*     */     }
/* 474 */     return null;
/*     */   }
/*     */ 
/*     */   protected static LinkedList<Field> getValidClassFields(Class c) {
/* 478 */     LinkedList validFields = new LinkedList();
/* 479 */     Field[] fields = c.getDeclaredFields();
/* 480 */     for (Field f : fields) {
/* 481 */       if (!isStaticOrTransient(f))
/* 482 */         validFields.add(f);
/*     */     }
/* 484 */     return validFields;
/*     */   }
/*     */ 
/*     */   protected static Class getFieldType(Field f) {
/* 488 */     return canonicalType(f.getType());
/*     */   }
/*     */ 
/*     */   protected static Class canonicalType(Class c) {
/* 492 */     String s = c.getSimpleName();
/* 493 */     if (s.equals("List"))
/* 494 */       return linkedListClass;
/* 495 */     if (s.equals("Map"))
/* 496 */       return hashMapClass;
/* 497 */     if (s.equals("Set")) {
/* 498 */       return hashSetClass;
/*     */     }
/* 500 */     return c;
/*     */   }
/*     */ 
/*     */   protected static boolean typeIsPrimitive(Class c) {
/* 504 */     return c.isPrimitive();
/*     */   }
/*     */ 
/*     */   protected static boolean isStringType(Class c) {
/* 508 */     return c.getSimpleName().equals("String");
/*     */   }
/*     */ 
/*     */   protected static String getSimpleClassName(Class c) {
/* 512 */     return c.getSimpleName();
/*     */   }
/*     */ 
/*     */   protected static Class lookupClass(String className) {
/*     */     try {
/* 517 */       return Class.forName(className);
/*     */     }
/*     */     catch (Exception e) {
/* 520 */       Log.error("MarshallingGenerator.lookupClass: could not find class '" + className + "'");
/* 521 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static void initializeCodeGenerator()
/*     */   {
/* 527 */     linkedListClass = lookupClass(getClassForTypeNum(Short.valueOf(9)));
/* 528 */     hashMapClass = lookupClass(getClassForTypeNum(Short.valueOf(11)));
/* 529 */     hashSetClass = lookupClass(getClassForTypeNum(Short.valueOf(14)));
/*     */ 
/* 532 */     readOps = new HashMap();
/* 533 */     writeOps = new HashMap();
/*     */ 
/* 536 */     defineRWCode(Short.valueOf(-9), Short.valueOf(1), "buf.getByte() != 0", "buf.putByte(# ? 1 : 0)");
/* 537 */     defineRWCode(Short.valueOf(-8), Short.valueOf(2), "buf.getByte()", "buf.putByte(#)");
/* 538 */     defineRWCode(Short.valueOf(-3), Short.valueOf(7), "buf.getShort()", "buf.putShort(#)");
/* 539 */     defineRWCode(Short.valueOf(-5), Short.valueOf(5), "buf.getInt()", "buf.putInt(#)");
/* 540 */     defineRWCode(Short.valueOf(-4), Short.valueOf(6), "buf.getLong()", "buf.putLong(#)");
/* 541 */     defineRWCode(Short.valueOf(-6), Short.valueOf(4), "buf.getFloat()", "buf.putFloat(#)");
/* 542 */     defineRWCode(Short.valueOf(-7), Short.valueOf(3), "buf.getDouble()", "buf.putDouble(#)");
/* 543 */     defineRWCode(Short.valueOf(8), "buf.getString()", "buf.putString(#)");
/*     */   }
/*     */ 
/*     */   protected static void defineRWCode(Short typeNumPrimitive, Short typeNumNonPrimitive, String readOp, String writeOp) {
/* 547 */     defineRWCode(typeNumPrimitive, readOp, writeOp);
/* 548 */     defineRWCode(typeNumNonPrimitive, readOp, writeOp);
/*     */   }
/*     */ 
/*     */   protected static void defineRWCode(Short typeNum, String readOp, String writeOp) {
/* 552 */     readOps.put(typeNum, readOp);
/* 553 */     writeOps.put(typeNum, writeOp);
/*     */   }
/*     */ 
/*     */   protected static void logGenericClassInfo(Object object, String what)
/*     */   {
/* 612 */     Class c = object.getClass();
/* 613 */     Type genSuper = c.getGenericSuperclass();
/* 614 */     Type[] interfaces = c.getGenericInterfaces();
/* 615 */     String s = "";
/* 616 */     for (Type iface : interfaces) {
/* 617 */       if (s != "")
/* 618 */         s = s + ", ";
/* 619 */       s = s + iface;
/*     */     }
/* 621 */     Log.info("logGenericClassInfo " + what + " Class " + c + ", genSuper " + genSuper + ", interfaces " + s);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 625 */     Log.init();
/*     */ 
/* 628 */     registerMarshallingClass("atavism.server.math.Point");
/* 629 */     registerMarshallingClass("atavism.server.math.AOVector");
/* 630 */     registerMarshallingClass("atavism.server.math.Quaternion");
/* 631 */     registerMarshallingClass("atavism.server.objects.DisplayContext");
/* 632 */     registerMarshallingClass("atavism.server.objects.SoundData");
/* 633 */     registerMarshallingClass("atavism.server.plugins.WorldManagerClient.ObjectInfo");
/* 634 */     registerMarshallingClass("atavism.msgsys.MessageTypeFilter");
/* 635 */     registerMarshallingClass("atavism.server.objects.LightData");
/* 636 */     registerMarshallingClass("atavism.server.objects.Color");
/* 637 */     registerMarshallingClass("atavism.server.marshalling.MarshalTestClass1");
/* 638 */     registerMarshallingClass("atavism.server.marshalling.MarshalTestClass2");
/*     */   }
/*     */ 
/*     */   public static class MarshalTestClass2 extends MarshallingGenerator.MarshalTestClass1
/*     */   {
/*     */     public MarshallingGenerator.MarshalTestClass1 myFirstClass1;
/*     */     public MarshallingGenerator.MarshalTestClass1 mySecondClass1;
/*     */   }
/*     */ 
/*     */   public static class MarshalTestClass1
/*     */   {
/* 579 */     public Boolean BooleanVal = Boolean.valueOf(true);
/* 580 */     public Byte ByteVal = Byte.valueOf(3);
/* 581 */     public Short ShortVal = Short.valueOf(3);
/* 582 */     public Integer IntegerVal = Integer.valueOf(3);
/* 583 */     public Long LongVal = Long.valueOf(3L);
/* 584 */     public Float FloatVal = Float.valueOf(3.0F);
/* 585 */     public Double DoubleVal = Double.valueOf(3.0D);
/*     */ 
/* 587 */     public boolean booleanVal = true;
/* 588 */     public byte byteVal = 3;
/* 589 */     public short shortVal = 3;
/* 590 */     public int integerVal = 3;
/* 591 */     public long longVal = 3L;
/* 592 */     public float floatVal = 3.0F;
/* 593 */     public double doubleVal = 3.0D;
/*     */ 
/* 595 */     public String stringVal = "3";
/*     */ 
/* 597 */     public LinkedList<String> stringList = new LinkedList();
/* 598 */     public HashMap<String, Object> stringMap = new HashMap();
/* 599 */     public HashSet<Point> points = new HashSet();
/*     */ 
/* 601 */     public List gstringList = new LinkedList();
/* 602 */     public Map gstringMap = new HashMap();
/* 603 */     public Set gpoints = new HashSet();
/*     */   }
/*     */ 
/*     */   public static class MarshallingPair
/*     */     implements Comparator
/*     */   {
/*     */     String className;
/*     */     Short typeNum;
/*     */ 
/*     */     public MarshallingPair(String className, Short typeNum)
/*     */     {
/* 192 */       this.className = className;
/* 193 */       this.typeNum = typeNum;
/*     */     }
/*     */ 
/*     */     public int compare(Object o1, Object o2) {
/* 197 */       MarshallingPair p1 = (MarshallingPair)o1;
/* 198 */       MarshallingPair p2 = (MarshallingPair)o2;
/* 199 */       if (p1.typeNum.shortValue() < p2.typeNum.shortValue())
/* 200 */         return -1;
/* 201 */       if (p1.typeNum.shortValue() > p2.typeNum.shortValue()) {
/* 202 */         return 1;
/*     */       }
/* 204 */       return 0;
/*     */     }
/*     */ 
/*     */     public String getClassKey() {
/* 208 */       return this.className;
/*     */     }
/*     */ 
/*     */     public Short getTypeNum() {
/* 212 */       return this.typeNum;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.marshalling.MarshallingGenerator
 * JD-Core Version:    0.6.0
 */