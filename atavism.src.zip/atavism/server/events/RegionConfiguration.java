/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class RegionConfiguration extends Event
/*    */ {
/* 54 */   private String regionConfig = null;
/*    */ 
/*    */   public RegionConfiguration()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RegionConfiguration(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 16 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public RegionConfiguration(String regionConfig)
/*    */   {
/* 21 */     setRegionConfig(regionConfig);
/*    */   }
/*    */ 
/*    */   public void setRegionConfig(String regionConfig) {
/* 25 */     this.regionConfig = regionConfig;
/*    */   }
/*    */   public String getRegionConfig() {
/* 28 */     return this.regionConfig;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 32 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 34 */     String regionConfig = getRegionConfig();
/* 35 */     AOByteBuffer buf = new AOByteBuffer(regionConfig.length() * 2 + 20);
/* 36 */     buf.putOID(null);
/* 37 */     buf.putInt(msgId);
/* 38 */     buf.putString(regionConfig);
/* 39 */     buf.flip();
/* 40 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 44 */     buf.rewind();
/* 45 */     buf.getOID();
/* 46 */     buf.getInt();
/* 47 */     setRegionConfig(buf.getString());
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 51 */     return "RegionConfiguration";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.RegionConfiguration
 * JD-Core Version:    0.6.0
 */