/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class IslandManifestEvent extends Event
/*    */ {
/* 78 */   private String worldName = null;
/* 79 */   private String worldFilesDirectory = null;
/* 80 */   private HashMap<String, String> worldFiles = null;
/*    */ 
/*    */   public IslandManifestEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public IslandManifestEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 20 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public IslandManifestEvent(String worldName)
/*    */   {
/* 25 */     setWorldName(worldName);
/*    */   }
/*    */ 
/*    */   public void setWorldName(String worldName) {
/* 29 */     this.worldName = worldName;
/*    */   }
/*    */   public String getWorldName() {
/* 32 */     return this.worldName;
/*    */   }
/*    */ 
/*    */   public void setWorldFilesDirectory(String worldFilesDirectory) {
/* 36 */     this.worldFilesDirectory = worldFilesDirectory;
/*    */   }
/*    */   public String getWorldFilesDirectory() {
/* 39 */     return this.worldFilesDirectory;
/*    */   }
/*    */ 
/*    */   public void setWorldFiles(HashMap<String, String> worldFiles) {
/* 43 */     this.worldFiles = worldFiles;
/*    */   }
/*    */   public HashMap<String, String> getWorldFiles() {
/* 46 */     return this.worldFiles;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 50 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 52 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 53 */     buf.putOID(null);
/* 54 */     buf.putInt(msgId);
/* 55 */     buf.putString(getWorldName());
/* 56 */     buf.putString(getWorldFilesDirectory());
/* 57 */     buf.putInt(this.worldFiles.size());
/* 58 */     for (String worldFile : this.worldFiles.keySet())
/*    */     {
/* 60 */       buf.putString(worldFile);
/* 61 */       buf.putString((String)this.worldFiles.get(worldFile));
/*    */     }
/* 63 */     buf.flip();
/* 64 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 68 */     buf.rewind();
/* 69 */     buf.getOID();
/* 70 */     buf.getInt();
/* 71 */     setWorldName(buf.getString());
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 75 */     return "IslandManifestEvent";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.IslandManifestEvent
 * JD-Core Version:    0.6.0
 */