/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.util.LockFactory;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class LoadingStateEvent extends Event
/*    */ {
/* 64 */   private Lock lock = LockFactory.makeLock("LoadingStateEventLock");
/* 65 */   private boolean loading = false;
/*    */ 
/*    */   public LoadingStateEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LoadingStateEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 17 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public LoadingStateEvent(boolean loading)
/*    */   {
/* 22 */     setLoading(loading);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 26 */     return "LoadingStateEvent";
/*    */   }
/*    */ 
/*    */   public void setLoading(boolean loading) {
/* 30 */     this.loading = loading;
/*    */   }
/*    */ 
/*    */   public boolean getLoading() {
/* 34 */     return this.loading;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 38 */     int msgId = Engine.getEventServer().getEventID(getClass());
/* 39 */     AOByteBuffer buf = new AOByteBuffer(40);
/* 40 */     this.lock.lock();
/*    */     try {
/* 42 */       buf.putOID(null);
/* 43 */       buf.putInt(msgId);
/* 44 */       buf.putBoolean(this.loading);
/* 45 */       buf.flip();
/* 46 */       AOByteBuffer localAOByteBuffer1 = buf;
/*    */       return localAOByteBuffer1; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf)
/*    */   {
/* 53 */     buf.rewind();
/* 54 */     buf.getOID();
/* 55 */     buf.getInt();
/* 56 */     this.lock.lock();
/*    */     try {
/* 58 */       setLoading(buf.getBoolean());
/*    */     } finally {
/* 60 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.LoadingStateEvent
 * JD-Core Version:    0.6.0
 */