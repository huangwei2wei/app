/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.objects.AOObject;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class DirectedEvent extends Event
/*     */ {
/*  38 */   private Event containedEvent = null;
/*     */ 
/*  46 */   private Collection<AOObject> recipientCol = null;
/*     */ 
/* 117 */   private String mMessage = null;
/*     */ 
/* 119 */   static final Logger log = new Logger("ComEvent");
/*     */ 
/*     */   public DirectedEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DirectedEvent(Collection<AOObject> recipients, Event event)
/*     */   {
/*  24 */     setRecipients(recipients);
/*  25 */     setContainedEvent(event);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  29 */     return "DirectedEvent";
/*     */   }
/*     */ 
/*     */   public void setContainedEvent(Event e) {
/*  33 */     this.containedEvent = e;
/*     */   }
/*     */   public Event getContainedEvent() {
/*  36 */     return this.containedEvent;
/*     */   }
/*     */ 
/*     */   public void setRecipients(Collection<AOObject> c)
/*     */   {
/*  41 */     this.recipientCol = c;
/*     */   }
/*     */   public Collection<AOObject> getRecipients() {
/*  44 */     return this.recipientCol;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes()
/*     */   {
/*  49 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/*  51 */     AOByteBuffer buf = new AOByteBuffer(1000);
/*  52 */     buf.putOID(null);
/*  53 */     buf.putInt(msgId);
/*     */ 
/*  56 */     if (this.recipientCol == null) {
/*  57 */       throw new AORuntimeException("DirectedEvent: recipient list size is 0");
/*     */     }
/*  59 */     buf.putInt(this.recipientCol.size());
/*     */ 
/*  61 */     Iterator iter = this.recipientCol.iterator();
/*  62 */     while (iter.hasNext()) {
/*  63 */       AOObject e = (AOObject)iter.next();
/*  64 */       buf.putOID(e.getOid());
/*     */     }
/*     */ 
/*  69 */     AOByteBuffer subEventBuf = getContainedEvent().toBytes();
/*  70 */     buf.putByteBuffer(subEventBuf);
/*  71 */     buf.flip();
/*  72 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/*  76 */     buf.rewind();
/*     */ 
/*  79 */     buf.getOID();
/*  80 */     buf.getInt();
/*     */ 
/*  85 */     Collection col = new HashSet();
/*  86 */     int len = buf.getInt();
/*     */ 
/*  88 */     for (int i = 0; i < len; i++) {
/*  89 */       OID oid = buf.getOID();
/*     */ 
/*  91 */       AOObject e = AOObject.getObject(oid);
/*  92 */       if (e == null) {
/*  93 */         log.warn("could not find entity with oid " + oid);
/*     */       }
/*     */       else
/*     */       {
/*  97 */         col.add(e);
/*     */       }
/*     */     }
/*  99 */     setRecipients(col);
/*     */ 
/* 103 */     AOByteBuffer subBuf = buf.getByteBuffer();
/* 104 */     Event subEvent = Engine.getEventServer().parseBytes(subBuf, getConnection());
/*     */ 
/* 107 */     setContainedEvent(subEvent);
/*     */   }
/*     */ 
/*     */   public void setMessage(String msg) {
/* 111 */     this.mMessage = msg;
/*     */   }
/*     */   public String getMessage() {
/* 114 */     return this.mMessage;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.DirectedEvent
 * JD-Core Version:    0.6.0
 */