/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class LogoutEvent extends Event
/*    */ {
/*    */   public LogoutEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LogoutEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 16 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public LogoutEvent(AOObject obj) {
/* 20 */     super(obj);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 24 */     return "LogoutEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes()
/*    */   {
/* 29 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 31 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 32 */     buf.putOID(getObjectOid());
/* 33 */     buf.putInt(msgId);
/* 34 */     buf.flip();
/* 35 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 39 */     buf.rewind();
/*    */ 
/* 41 */     setObjectOid(buf.getOID());
/* 42 */     buf.getInt();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.LogoutEvent
 * JD-Core Version:    0.6.0
 */