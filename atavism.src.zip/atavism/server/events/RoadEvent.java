/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.objects.Road;
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class RoadEvent extends Event
/*     */ {
/* 101 */   private String roadName = null;
/* 102 */   private Lock lock = LockFactory.makeLock("RoadEventLock");
/* 103 */   private List<Point> points = null;
/*     */ 
/*     */   public RoadEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RoadEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  20 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public RoadEvent(Road road) {
/*  24 */     super(road);
/*  25 */     setPoints(road.getPoints());
/*  26 */     setRoadName(road.getName());
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  30 */     return "RoadEvent";
/*     */   }
/*     */ 
/*     */   public void setRoadName(String name) {
/*  34 */     this.roadName = name;
/*     */   }
/*     */   public String getRoadName() {
/*  37 */     return this.roadName;
/*     */   }
/*     */ 
/*     */   public void setPoints(List<Point> points) {
/*  41 */     this.lock.lock();
/*     */     try {
/*  43 */       this.points = new LinkedList(points);
/*     */     }
/*     */     finally {
/*  46 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Point> getPoints() {
/*  51 */     this.lock.lock();
/*     */     try {
/*  53 */       LinkedList localLinkedList = new LinkedList(this.points);
/*     */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes()
/*     */   {
/*  61 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*  62 */     AOByteBuffer buf = new AOByteBuffer(400);
/*     */ 
/*  64 */     this.lock.lock();
/*     */     try {
/*  66 */       buf.putOID(getObjectOid());
/*  67 */       buf.putInt(msgId);
/*  68 */       buf.putString(getRoadName());
/*  69 */       buf.putInt(this.points.size());
/*  70 */       for (Point p : this.points) {
/*  71 */         buf.putPoint(p);
/*     */       }
/*  73 */       buf.flip();
/*  74 */       ??? = buf;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf)
/*     */   {
/*  82 */     buf.rewind();
/*  83 */     setObjectOid(buf.getOID());
/*  84 */     buf.getInt();
/*     */ 
/*  86 */     setRoadName(buf.getString());
/*  87 */     this.lock.lock();
/*     */     try {
/*  89 */       this.points = new LinkedList();
/*  90 */       int numPoints = buf.getInt();
/*  91 */       for (int i = 0; i < numPoints; i++) {
/*  92 */         Point p = buf.getPoint();
/*  93 */         this.points.add(p);
/*     */       }
/*     */     }
/*     */     finally {
/*  97 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.RoadEvent
 * JD-Core Version:    0.6.0
 */