/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ExtensionMessageEvent extends Event
/*    */ {
/* 79 */   private Map<String, Serializable> propertyMap = null;
/* 80 */   private OID targetOid = null;
/* 81 */   private Boolean clientTargeted = null;
/*    */ 
/*    */   public ExtensionMessageEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 12 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public ExtensionMessageEvent() {
/*    */   }
/*    */ 
/*    */   public ExtensionMessageEvent(OID objOid) {
/* 19 */     super(objOid);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 23 */     return "ExtensionMessageEvent";
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 27 */     return "[ExtensionMessageEvent: subType=" + getExtensionType() + ", oid=" + getObjectOid() + ", targetOid=" + getTargetOid() + ", clientTargeted=" + getClientTargeted() + "]";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes()
/*    */   {
/* 32 */     throw new AORuntimeException("ExtensionMessageEvent.toBytes not implemented");
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 36 */     buf.rewind();
/*    */ 
/* 38 */     OID oid = buf.getOID();
/* 39 */     setObjectOid(oid);
/* 40 */     buf.getInt();
/* 41 */     byte flags = buf.getByte();
/* 42 */     if ((flags & 0x1) != 0)
/* 43 */       this.targetOid = buf.getOID();
/* 44 */     this.clientTargeted = Boolean.valueOf((flags & 0x2) != 0);
/* 45 */     this.propertyMap = buf.getPropertyMap();
/*    */   }
/*    */ 
/*    */   public void setExtensionType(String type) {
/* 49 */     this.propertyMap.put("ext_msg_subtype", type);
/*    */   }
/*    */ 
/*    */   public String getExtensionType() {
/* 53 */     return (String)this.propertyMap.get("ext_msg_subtype");
/*    */   }
/*    */ 
/*    */   public void setPropertyMap(Map<String, Serializable> v) {
/* 57 */     this.propertyMap = v;
/*    */   }
/*    */ 
/*    */   public Map<String, Serializable> getPropertyMap() {
/* 61 */     return this.propertyMap;
/*    */   }
/*    */ 
/*    */   public void setTargetOid(OID v) {
/* 65 */     this.targetOid = v;
/*    */   }
/*    */ 
/*    */   public OID getTargetOid() {
/* 69 */     return this.targetOid;
/*    */   }
/*    */ 
/*    */   public void setClientTargeted(Boolean v) {
/* 73 */     this.clientTargeted = v;
/*    */   }
/*    */   public Boolean getClientTargeted() {
/* 76 */     return this.clientTargeted;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.ExtensionMessageEvent
 * JD-Core Version:    0.6.0
 */