/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ 
/*    */ public class FreeTerrainDecalEvent extends Event
/*    */ {
/*    */   private OID decalOid;
/*    */ 
/*    */   public FreeTerrainDecalEvent(OID decalOid)
/*    */   {
/* 10 */     this.decalOid = decalOid;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 14 */     return "FreeTerrainDecalEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 18 */     int msgId = Engine.getEventServer().getEventID(getClass());
/* 19 */     AOByteBuffer buf = new AOByteBuffer(64);
/*    */ 
/* 21 */     buf.putOID(this.decalOid);
/* 22 */     buf.putInt(msgId);
/* 23 */     buf.flip();
/* 24 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 28 */     buf.rewind();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.FreeTerrainDecalEvent
 * JD-Core Version:    0.6.0
 */