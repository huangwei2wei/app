/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.util.LockFactory;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ public class UITheme extends Event
/*    */ {
/* 55 */   List<String> uiThemes = new LinkedList();
/*    */ 
/* 97 */   transient Lock lock = LockFactory.makeLock("UIThemeEventLock");
/*    */ 
/*    */   public UITheme()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UITheme(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 16 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public UITheme(List<String> uiThemes)
/*    */   {
/* 21 */     setThemes(uiThemes);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 25 */     return "UITheme";
/*    */   }
/*    */ 
/*    */   public void setThemes(List<String> uiThemes) {
/* 29 */     this.lock.lock();
/*    */     try {
/* 31 */       this.uiThemes = new LinkedList(uiThemes);
/*    */     }
/*    */     finally {
/* 34 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void addTheme(String theme) {
/* 38 */     this.lock.lock();
/*    */     try {
/* 40 */       this.uiThemes.add(theme);
/*    */     }
/*    */     finally {
/* 43 */       this.lock.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   public List<String> getThemes() {
/* 47 */     this.lock.lock();
/*    */     try {
/* 49 */       LinkedList localLinkedList = new LinkedList(this.uiThemes);
/*    */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes()
/*    */   {
/* 58 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 60 */     int themeCount = this.uiThemes.size();
/* 61 */     AOByteBuffer buf = new AOByteBuffer(200 * themeCount + 20);
/* 62 */     buf.putOID(null);
/* 63 */     buf.putInt(msgId);
/*    */ 
/* 66 */     this.lock.lock();
/*    */     try {
/* 68 */       buf.putInt(themeCount);
/* 69 */       Iterator iter = this.uiThemes.iterator();
/* 70 */       while (iter.hasNext()) {
/* 71 */         theme = (String)iter.next();
/* 72 */         buf.putString(theme);
/*    */       }
/* 74 */       buf.flip();
/* 75 */       String theme = buf;
/*    */       return theme; } finally { this.lock.unlock(); } throw localObject;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf)
/*    */   {
/* 83 */     buf.rewind();
/* 84 */     buf.getOID();
/* 85 */     buf.getInt();
/*    */ 
/* 87 */     List uiThemes = new LinkedList();
/* 88 */     int numThemes = buf.getInt();
/* 89 */     while (numThemes > 0) {
/* 90 */       String theme = buf.getString();
/* 91 */       uiThemes.add(theme);
/* 92 */       numThemes--;
/*    */     }
/* 94 */     setThemes(uiThemes);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.UITheme
 * JD-Core Version:    0.6.0
 */