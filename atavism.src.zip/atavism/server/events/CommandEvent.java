/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class CommandEvent extends Event
/*    */ {
/* 67 */   private String command = null;
/* 68 */   private OID targetOid = null;
/*    */ 
/*    */   public CommandEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CommandEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 14 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public CommandEvent(AOObject obj, AOObject target, String command) {
/* 18 */     super(obj);
/* 19 */     setTarget(target.getOid());
/* 20 */     setCommand(command);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 24 */     return "CommandEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 28 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 29 */     buf.putOID(getObjectOid());
/* 30 */     buf.putInt(13);
/* 31 */     buf.putOID(getTarget());
/* 32 */     buf.putString(getCommand());
/* 33 */     buf.flip();
/* 34 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 38 */     buf.rewind();
/*    */ 
/* 40 */     setObjectOid(buf.getOID());
/* 41 */     buf.getInt();
/* 42 */     setTarget(buf.getOID());
/* 43 */     setCommand(buf.getString());
/*    */   }
/*    */ 
/*    */   public void setCommand(String command)
/*    */   {
/* 55 */     this.command = command;
/*    */   }
/*    */   public String getCommand() {
/* 58 */     return this.command;
/*    */   }
/*    */   public void setTarget(OID oid) {
/* 61 */     this.targetOid = oid;
/*    */   }
/*    */   public OID getTarget() {
/* 64 */     return this.targetOid;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.CommandEvent
 * JD-Core Version:    0.6.0
 */