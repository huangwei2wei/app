/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class StateEvent extends Event
/*     */ {
/* 126 */   Map<String, Integer> stateMap = new HashMap();
/* 127 */   transient Lock lock = LockFactory.makeLock("StateEvent");
/*     */ 
/*     */   public StateEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public StateEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  18 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  28 */     return "StateEvent";
/*     */   }
/*     */ 
/*     */   public void addState(String stateName, int val) {
/*  32 */     this.lock.lock();
/*     */     try {
/*  34 */       this.stateMap.put(stateName.intern(), Integer.valueOf(val));
/*     */     }
/*     */     finally {
/*  37 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Integer getState(String stateName) {
/*  42 */     this.lock.lock();
/*     */     try {
/*  44 */       Integer localInteger = (Integer)this.stateMap.get(stateName.intern());
/*     */       return localInteger; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Map<String, Integer> getStateMap()
/*     */   {
/*  55 */     this.lock.lock();
/*     */     try {
/*  57 */       HashMap localHashMap = new HashMap(this.stateMap);
/*     */       return localHashMap; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf)
/*     */   {
/*  65 */     this.lock.lock();
/*     */     try {
/*  67 */       buf.rewind();
/*     */ 
/*  70 */       OID playerId = buf.getOID();
/*     */ 
/*  76 */       setObjectOid(playerId);
/*     */ 
/*  78 */       buf.getInt();
/*     */ 
/*  81 */       int len = buf.getInt();
/*  82 */       while (len > 0) {
/*  83 */         String stateName = buf.getString();
/*  84 */         int val = buf.getInt();
/*  85 */         if (Log.loggingDebug) {
/*  86 */           Log.debug("StateEvent.parseBytes: got state " + stateName + "=" + val);
/*     */         }
/*  88 */         addState(stateName.intern(), val);
/*  89 */         len--;
/*     */       }
/*     */     }
/*     */     finally {
/*  93 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  98 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/* 100 */     this.lock.lock();
/*     */     try {
/* 102 */       AOByteBuffer buf = new AOByteBuffer(400);
/* 103 */       buf.putOID(getObjectOid());
/* 104 */       buf.putInt(msgId);
/*     */ 
/* 106 */       buf.putInt(this.stateMap.size());
/* 107 */       Iterator iter = this.stateMap.entrySet().iterator();
/* 108 */       while (iter.hasNext()) {
/* 109 */         entry = (Map.Entry)iter.next();
/* 110 */         String state = (String)entry.getKey();
/* 111 */         Integer val = (Integer)entry.getValue();
/* 112 */         buf.putString(state);
/* 113 */         buf.putInt(val.intValue());
/* 114 */         if (Log.loggingDebug) {
/* 115 */           Log.debug("StateEvent.toBytes: state=" + state + ", val=" + val);
/*     */         }
/*     */       }
/* 118 */       buf.flip();
/* 119 */       Map.Entry entry = buf;
/*     */       return entry; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.StateEvent
 * JD-Core Version:    0.6.0
 */