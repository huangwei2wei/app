/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.objects.AOObject;
/*     */ import atavism.server.util.AnimationCommand;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class NotifyPlayAnimationEvent extends Event
/*     */ {
/* 168 */   private List<AnimationCommand> animList = new LinkedList();
/*     */ 
/* 170 */   private transient Lock lock = LockFactory.makeLock("NotifyPlayAnimationEventLock");
/*     */ 
/*     */   public NotifyPlayAnimationEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public NotifyPlayAnimationEvent(OID oid)
/*     */   {
/*  23 */     super(oid);
/*     */   }
/*     */ 
/*     */   public NotifyPlayAnimationEvent(AOByteBuffer buf, ClientConnection con) {
/*  27 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public NotifyPlayAnimationEvent(AOObject object)
/*     */   {
/*  34 */     super(object);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  38 */     return "NotifyPlayAnimationEvent";
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  42 */     this.lock.lock();
/*     */     try {
/*  44 */       String s = "[NotifyPlayAnimationEvent obj=" + getObjectOid() + ", size=" + this.animList.size();
/*     */ 
/*  46 */       for (AnimationCommand ac : this.animList) {
/*  47 */         s = s + ", [command=" + ac.getCommand() + ", animName=" + ac.getAnimName() + ", looping=" + ac.isLoop() + "]";
/*     */       }
/*     */ 
/*  50 */       ??? = s;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes()
/*     */   {
/*  57 */     this.lock.lock();
/*     */     try {
/*  59 */       int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/*  61 */       AOByteBuffer buf = new AOByteBuffer(200);
/*  62 */       buf.putOID(getObjectOid());
/*  63 */       buf.putInt(msgId);
/*     */ 
/*  66 */       if (this.animList == null) {
/*  67 */         if (Log.loggingDebug) {
/*  68 */           Log.debug("PlayAnimation.toBytes: animList is empty for obj " + getObjectOid());
/*     */         }
/*  70 */         buf.putInt(0);
/*     */       }
/*     */       else
/*     */       {
/*  74 */         buf.putInt(this.animList.size());
/*  75 */         iter = this.animList.iterator();
/*  76 */         while (iter.hasNext()) {
/*  77 */           AnimationCommand ac = (AnimationCommand)iter.next();
/*  78 */           buf.putString(ac.getCommand());
/*     */ 
/*  81 */           if (!ac.getCommand().equals("clear")) {
/*  82 */             buf.putString(ac.getAnimName());
/*     */ 
/*  86 */             buf.putInt(ac.isLoop() ? 1 : 0);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  94 */       buf.flip();
/*  95 */       Iterator iter = buf;
/*     */       return iter; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf)
/*     */   {
/* 102 */     this.lock.lock();
/*     */     try {
/* 104 */       buf.rewind();
/* 105 */       OID oid = buf.getOID();
/* 106 */       if (Log.loggingDebug)
/* 107 */         Log.debug("PlayAnimation.parseBytes: oid=" + oid);
/* 108 */       setObjectOid(oid);
/* 109 */       buf.getInt();
/*     */ 
/* 111 */       List list = new LinkedList();
/* 112 */       int len = buf.getInt();
/* 113 */       if (Log.loggingDebug) {
/* 114 */         Log.debug("PlayAnimation.parseBytes: obj=" + getObjectOid() + ", listsize=" + len);
/*     */       }
/* 116 */       while (len > 0) {
/* 117 */         String command = buf.getString();
/* 118 */         String animName = buf.getString();
/* 119 */         boolean isLoop = buf.getInt() == 1;
/* 120 */         AnimationCommand ac = new AnimationCommand();
/* 121 */         if (command.equals("add")) {
/* 122 */           ac.setCommand("add");
/* 123 */           ac.setAnimName(animName);
/* 124 */           ac.isLoop(isLoop);
/* 125 */         } else if (command.equals("clear")) {
/* 126 */           ac.setCommand("clear");
/*     */         }
/* 128 */         list.add(ac);
/* 129 */         len--;
/*     */       }
/* 131 */       setAnimList(list);
/*     */     } finally {
/* 133 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAnim(AnimationCommand ac) {
/* 138 */     this.lock.lock();
/*     */     try {
/* 140 */       if (this.animList == null) {
/* 141 */         this.animList = new LinkedList();
/*     */       }
/* 143 */       this.animList.add(ac);
/*     */     } finally {
/* 145 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAnimList(List<AnimationCommand> animList) {
/* 150 */     this.lock.lock();
/*     */     try {
/* 152 */       this.animList = new LinkedList(animList);
/*     */     } finally {
/* 154 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getAnimList() {
/* 159 */     this.lock.lock();
/*     */     try {
/* 161 */       LinkedList localLinkedList = new LinkedList(this.animList);
/*     */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.NotifyPlayAnimationEvent
 * JD-Core Version:    0.6.0
 */