/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class ActivateItemEvent extends Event
/*    */ {
/* 47 */   private OID targetOid = null;
/* 48 */   private OID itemOid = null;
/*    */ 
/*    */   public ActivateItemEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ActivateItemEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 13 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 17 */     return "ActivateItemEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 21 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 23 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 24 */     buf.putOID(getObjectOid());
/* 25 */     buf.putInt(msgId);
/* 26 */     buf.putOID(getTargetOid());
/* 27 */     buf.putOID(getItemOid());
/* 28 */     buf.flip();
/* 29 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 33 */     buf.rewind();
/*    */ 
/* 35 */     setObjectOid(buf.getOID());
/* 36 */     buf.getInt();
/* 37 */     setTargetOid(buf.getOID());
/* 38 */     setItemOid(buf.getOID());
/*    */   }
/*    */   public void setTargetOid(OID oid) {
/* 41 */     this.targetOid = oid; } 
/* 42 */   public OID getTargetOid() { return this.targetOid; } 
/*    */   public void setItemOid(OID oid) {
/* 44 */     this.itemOid = oid; } 
/* 45 */   public OID getItemOid() { return this.itemOid;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.ActivateItemEvent
 * JD-Core Version:    0.6.0
 */