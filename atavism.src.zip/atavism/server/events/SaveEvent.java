/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class SaveEvent extends Event
/*    */ {
/*    */   public SaveEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SaveEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 15 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 19 */     return "SaveEvent";
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf)
/*    */   {
/* 24 */     buf.rewind();
/*    */ 
/* 27 */     buf.getOID();
/* 28 */     buf.getInt();
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 32 */     int msgId = Engine.getEventServer().getEventID(getClass());
/* 33 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 34 */     buf.putOID(null);
/* 35 */     buf.putInt(msgId);
/* 36 */     buf.flip();
/* 37 */     return buf;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.SaveEvent
 * JD-Core Version:    0.6.0
 */