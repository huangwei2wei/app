/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class DetachEvent extends Event
/*    */ {
/* 68 */   private OID objToDetach = null;
/* 69 */   private String socketName = null;
/*    */ 
/*    */   public DetachEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DetachEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 13 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public DetachEvent(OID detacherOid, OID detachObjOid, String socketName) {
/* 17 */     super.setObjectOid(detacherOid);
/* 18 */     setObjToDetach(detachObjOid);
/* 19 */     setSocketName(socketName);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 23 */     return "DetachEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 27 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 29 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 30 */     buf.putOID(getDetacher());
/* 31 */     buf.putInt(msgId);
/*    */ 
/* 33 */     buf.putOID(getObjToDetach());
/* 34 */     buf.putString(getSocketName());
/* 35 */     buf.flip();
/* 36 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 40 */     buf.rewind();
/* 41 */     setDetacher(buf.getOID());
/* 42 */     buf.getInt();
/* 43 */     setObjToDetach(buf.getOID());
/* 44 */     setSocketName(buf.getString());
/*    */   }
/*    */ 
/*    */   public void setDetacher(OID detacher) {
/* 48 */     setObjectOid(detacher);
/*    */   }
/*    */   public OID getDetacher() {
/* 51 */     return getObjectOid();
/*    */   }
/*    */ 
/*    */   public void setObjToDetach(OID oid) {
/* 55 */     this.objToDetach = oid;
/*    */   }
/*    */   public OID getObjToDetach() {
/* 58 */     return this.objToDetach;
/*    */   }
/*    */ 
/*    */   public void setSocketName(String socketName) {
/* 62 */     this.socketName = socketName;
/*    */   }
/*    */   public String getSocketName() {
/* 65 */     return this.socketName;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.DetachEvent
 * JD-Core Version:    0.6.0
 */