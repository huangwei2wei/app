/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class DropEvent extends Event
/*    */ {
/* 61 */   private AOObject objToDrop = null;
/*    */ 
/*    */   public DropEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DropEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 16 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public DropEvent(AOObject dropper, AOObject obj) {
/* 20 */     super(dropper);
/* 21 */     setObjToDrop(obj);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 25 */     return "DropEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 29 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 31 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 32 */     buf.putOID(getObjectOid());
/* 33 */     buf.putInt(msgId);
/* 34 */     buf.putOID(getObjToDrop().getOid());
/* 35 */     buf.flip();
/* 36 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 40 */     buf.rewind();
/*    */ 
/* 43 */     setDropper(AOObject.getObject(buf.getOID()));
/*    */ 
/* 45 */     buf.getInt();
/*    */ 
/* 47 */     setObjToDrop(AOObject.getObject(buf.getOID()));
/*    */   }
/*    */ 
/*    */   public void setDropper(AOObject dropper) {
/* 51 */     setObject(dropper);
/*    */   }
/*    */ 
/*    */   public void setObjToDrop(AOObject obj) {
/* 55 */     this.objToDrop = obj;
/*    */   }
/*    */   public AOObject getObjToDrop() {
/* 58 */     return this.objToDrop;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.DropEvent
 * JD-Core Version:    0.6.0
 */