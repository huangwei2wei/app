/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.objects.Light.LightType;
/*     */ import atavism.server.objects.LightData;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ 
/*     */ public class NewLightEvent extends Event
/*     */ {
/*  49 */   LightData lightData = null;
/*     */ 
/*  51 */   OID lightOid = null;
/*     */ 
/*     */   public NewLightEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public NewLightEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  23 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public NewLightEvent(OID notifyOid, OID lightOid, LightData lightData) {
/*  27 */     super(notifyOid);
/*  28 */     setLightOid(lightOid);
/*  29 */     setLightData(lightData);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  40 */     return "NewLightEvent";
/*     */   }
/*     */ 
/*     */   public void setLightData(LightData lightData) {
/*  44 */     this.lightData = lightData;
/*     */   }
/*     */   public LightData getLightData() {
/*  47 */     return this.lightData;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes()
/*     */   {
/*  73 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/*  75 */     OID notifyObjOid = getObjectOid();
/*  76 */     LightData lightData = getLightData();
/*     */ 
/*  79 */     AOByteBuffer buf = new AOByteBuffer(200);
/*  80 */     buf.putOID(notifyObjOid);
/*  81 */     buf.putInt(msgId);
/*  82 */     buf.putOID(getLightOid());
/*  83 */     boolean isPoint = false;
/*  84 */     boolean isDir = false;
/*     */ 
/*  86 */     Log.debug("NewLightEvent: lightName=" + lightData.getName());
/*  87 */     if (lightData.getInitLoc() != null) {
/*  88 */       Log.debug("NewLightEvent: got lightType=" + Light.LightType.Point.ordinal());
/*  89 */       isPoint = true;
/*  90 */       buf.putInt(Light.LightType.Point.ordinal());
/*     */     }
/*  92 */     else if (lightData.getOrientation() != null) {
/*  93 */       Log.debug("NewLightEvent: lightType=" + Light.LightType.Directional.ordinal());
/*  94 */       isDir = true;
/*  95 */       buf.putInt(Light.LightType.Directional.ordinal());
/*     */     }
/*     */     else {
/*  98 */       throw new AORuntimeException("NewLightEvent.toBytes: unknown light type");
/*     */     }
/*     */ 
/* 101 */     buf.putString(lightData.getName());
/* 102 */     buf.putColor(lightData.getDiffuse());
/* 103 */     buf.putColor(lightData.getSpecular());
/* 104 */     buf.putFloat(lightData.getAttenuationRange());
/* 105 */     buf.putFloat(lightData.getAttenuationConstant());
/* 106 */     buf.putFloat(lightData.getAttenuationLinear());
/* 107 */     buf.putFloat(lightData.getAttenuationQuadradic());
/*     */ 
/* 110 */     if (isPoint)
/*     */     {
/* 112 */       Point loc = lightData.getInitLoc();
/* 113 */       buf.putPoint(loc == null ? new Point() : loc);
/*     */     }
/* 115 */     else if (isDir)
/*     */     {
/* 117 */       Quaternion orient = lightData.getOrientation();
/* 118 */       buf.putQuaternion(orient == null ? new Quaternion() : orient);
/*     */     }
/* 120 */     buf.flip();
/* 121 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/* 125 */     buf.rewind();
/* 126 */     setObjectOid(buf.getOID());
/* 127 */     buf.getInt();
/* 128 */     OID lightOid = buf.getOID();
/* 129 */     int lightType = buf.getInt();
/*     */ 
/* 134 */     LightData ld = new LightData();
/* 135 */     ld.setName(buf.getString());
/* 136 */     ld.setDiffuse(buf.getColor());
/* 137 */     ld.setSpecular(buf.getColor());
/* 138 */     ld.setAttenuationRange(buf.getFloat());
/* 139 */     ld.setAttenuationConstant(buf.getFloat());
/* 140 */     ld.setAttenuationLinear(buf.getFloat());
/* 141 */     ld.setAttenuationQuadradic(buf.getFloat());
/* 142 */     if (lightType == Light.LightType.Point.ordinal()) {
/* 143 */       ld.setInitLoc(buf.getPoint());
/*     */     }
/* 154 */     else if (lightType == Light.LightType.Directional.ordinal()) {
/* 155 */       ld.setOrientation(buf.getQuaternion());
/*     */     }
/*     */     else
/*     */     {
/* 167 */       throw new AORuntimeException("NewLightEvent.parseBytes: only point light supported at the moment");
/*     */     }
/* 169 */     setLightOid(lightOid);
/* 170 */     setLightData(ld);
/*     */   }
/*     */ 
/*     */   public OID getLightOid() {
/* 174 */     return this.lightOid;
/*     */   }
/*     */ 
/*     */   public void setLightOid(OID lightOid) {
/* 178 */     this.lightOid = lightOid;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.NewLightEvent
 * JD-Core Version:    0.6.0
 */