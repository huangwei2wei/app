/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.math.Point;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class WorldFileEvent extends Event
/*    */ {
/* 76 */   private String worldFile = null;
/* 77 */   private Point loc = null;
/*    */ 
/*    */   public WorldFileEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public WorldFileEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 20 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public WorldFileEvent(String worldFileName)
/*    */   {
/* 25 */     setWorldFile(worldFileName);
/*    */   }
/*    */ 
/*    */   public WorldFileEvent(String worldFileName, Point loc)
/*    */   {
/* 30 */     setWorldFile(worldFileName);
/* 31 */     setLoc(loc);
/*    */   }
/*    */ 
/*    */   public void setWorldFile(String worldFileName) {
/* 35 */     this.worldFile = worldFileName;
/*    */   }
/*    */   public String getWorldFile() {
/* 38 */     return this.worldFile;
/*    */   }
/*    */ 
/*    */   public void setLoc(Point loc) {
/* 42 */     this.loc = loc;
/*    */   }
/*    */   public Point getLoc() {
/* 45 */     return this.loc;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 49 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 51 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 52 */     buf.putOID(null);
/* 53 */     buf.putInt(msgId);
/* 54 */     buf.putString(getWorldFile());
/* 55 */     if (this.loc != null) {
/* 56 */       buf.putBoolean(true);
/* 57 */       buf.putPoint(this.loc);
/*    */     } else {
/* 59 */       buf.putBoolean(false);
/*    */     }
/* 61 */     buf.flip();
/* 62 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 66 */     buf.rewind();
/* 67 */     buf.getOID();
/* 68 */     buf.getInt();
/* 69 */     setWorldFile(buf.getString());
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 73 */     return "WorldFileEvent";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.WorldFileEvent
 * JD-Core Version:    0.6.0
 */