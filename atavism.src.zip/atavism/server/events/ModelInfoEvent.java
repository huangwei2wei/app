/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.objects.AOObject;
/*     */ import atavism.server.objects.DisplayContext;
/*     */ import atavism.server.objects.DisplayContext.Submesh;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ModelInfoEvent extends Event
/*     */ {
/* 126 */   protected DisplayContext dc = null;
/* 127 */   protected boolean forceInstantLoad = false;
/* 128 */   protected static final Logger log = new Logger("ModelInfoEvent");
/*     */ 
/*     */   public ModelInfoEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ModelInfoEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  21 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public ModelInfoEvent(AOObject obj) {
/*  25 */     super(obj);
/*  26 */     setDisplayContext((DisplayContext)obj.displayContext().clone());
/*     */   }
/*     */ 
/*     */   public ModelInfoEvent(OID objOid) {
/*  30 */     super(objOid);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  34 */     return "ModelInfoEvent";
/*     */   }
/*     */ 
/*     */   public void setDisplayContext(DisplayContext dc) {
/*  38 */     this.dc = dc;
/*     */   }
/*     */   public DisplayContext getDisplayContext() {
/*  41 */     return this.dc;
/*     */   }
/*     */ 
/*     */   public void setForceInstantLoad(boolean forceInstantLoad) {
/*  45 */     this.forceInstantLoad = forceInstantLoad;
/*     */   }
/*     */   public boolean getForceInstantLoad() {
/*  48 */     return this.forceInstantLoad;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  52 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*  53 */     AOByteBuffer buf = new AOByteBuffer(400);
/*  54 */     buf.putOID(getObjectOid());
/*  55 */     buf.putInt(msgId);
/*  56 */     buf.putInt(1);
/*     */ 
/*  59 */     DisplayContext dc = getDisplayContext();
/*  60 */     buf.putString(dc.getMeshFile());
/*  61 */     if (Log.loggingDebug) {
/*  62 */       log.debug("ModelInfoEvent.toBytes: meshfile=" + dc.getMeshFile());
/*     */     }
/*  64 */     Set submeshes = dc.getSubmeshes();
/*  65 */     int submeshLen = submeshes.size();
/*  66 */     buf.putInt(submeshLen);
/*  67 */     if (Log.loggingDebug) {
/*  68 */       log.debug("ModelInfoEvent.toBytes: submeshLen=" + submeshLen);
/*     */     }
/*  70 */     int castShadow = dc.getCastShadow() ? 1 : 0;
/*  71 */     int receiveShadow = dc.getReceiveShadow() ? 1 : 0;
/*  72 */     Iterator sIter = submeshes.iterator();
/*  73 */     while (sIter.hasNext()) {
/*  74 */       DisplayContext.Submesh submesh = (DisplayContext.Submesh)sIter.next();
/*  75 */       buf.putString(submesh.name);
/*  76 */       buf.putString(submesh.material);
/*  77 */       buf.putInt(castShadow);
/*  78 */       buf.putInt(receiveShadow);
/*  79 */       if (Log.loggingDebug) {
/*  80 */         log.debug("ModelInfoEvent.toBytes: submeshName=" + submesh.name + ", material=" + submesh.material + ", castShadow=" + castShadow + ", receiveShadow=" + receiveShadow);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  86 */     buf.putInt(dc.getDisplayID());
/*  87 */     Log.debug("DISPLAY: set display ID to: " + dc.getDisplayID());
/*  88 */     buf.putBoolean(this.forceInstantLoad);
/*  89 */     buf.flip();
/*  90 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/*  94 */     buf.rewind();
/*  95 */     setObjectOid(buf.getOID());
/*  96 */     buf.getInt();
/*  97 */     int meshFiles = buf.getInt();
/*  98 */     if (meshFiles != 1) {
/*  99 */       throw new AORuntimeException("more than 1 meshfile is not supported");
/*     */     }
/*     */ 
/* 102 */     DisplayContext dc = new DisplayContext();
/* 103 */     dc.setMeshFile(buf.getString());
/* 104 */     if (Log.loggingDebug) {
/* 105 */       log.debug("parseBytes: objOid=" + getObjectOid() + ", meshfile=" + dc.getMeshFile());
/*     */     }
/* 107 */     Set submeshes = new HashSet();
/*     */ 
/* 109 */     int numSubmeshes = buf.getInt();
/* 110 */     while (numSubmeshes > 0) {
/* 111 */       String name = buf.getString();
/* 112 */       String material = buf.getString();
/* 113 */       DisplayContext.Submesh submesh = new DisplayContext.Submesh(name, material);
/* 114 */       submeshes.add(submesh);
/* 115 */       numSubmeshes--;
/* 116 */       int castShadow = buf.getInt();
/* 117 */       int receiveShadow = buf.getInt();
/* 118 */       dc.setCastShadow(castShadow == 1);
/* 119 */       dc.setReceiveShadow(receiveShadow == 1);
/*     */     }
/* 121 */     dc.setSubmeshes(submeshes);
/* 122 */     dc.setDisplayID(buf.getInt());
/* 123 */     this.forceInstantLoad = buf.getBoolean();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.ModelInfoEvent
 * JD-Core Version:    0.6.0
 */