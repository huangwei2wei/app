/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.objects.AOObject;
/*     */ import atavism.server.util.Log;
/*     */ 
/*     */ public class RegisterEntityResponseEvent extends Event
/*     */ {
/* 101 */   private boolean isPortalFlag = false;
/* 102 */   private boolean responseStatus = false;
/* 103 */   private byte[] data = null;
/*     */ 
/*     */   public RegisterEntityResponseEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RegisterEntityResponseEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  20 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public RegisterEntityResponseEvent(AOObject obj, boolean status, boolean portalRequest)
/*     */   {
/*  27 */     super(obj);
/*  28 */     if (Log.loggingDebug) {
/*  29 */       Log.debug("RegisterEntityResponseEvent: in constructor, obj=" + obj + ", status=" + status + ", portal=" + portalRequest + ", calling toBytes");
/*     */     }
/*     */ 
/*  33 */     this.data = obj.toBytes();
/*  34 */     Log.debug("RegisterEntityResponseEvent: created data");
/*  35 */     setStatus(status);
/*  36 */     isPortal(portalRequest);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  40 */     return "RegisterEntityResponse";
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  44 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/*  47 */     byte[] d = getData();
/*  48 */     AOByteBuffer buf = new AOByteBuffer(d.length + 32);
/*  49 */     buf.putOID(getObjectOid());
/*  50 */     buf.putInt(msgId);
/*  51 */     buf.putInt(getStatus() ? 1 : 0);
/*     */ 
/*  54 */     buf.putInt(getData().length);
/*  55 */     buf.putBytes(d, 0, d.length);
/*  56 */     buf.putBoolean(isPortal());
/*     */ 
/*  58 */     buf.flip();
/*  59 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/*  63 */     buf.rewind();
/*  64 */     setObjectOid(buf.getOID());
/*  65 */     buf.getInt();
/*     */ 
/*  67 */     setStatus(buf.getInt() == 1);
/*     */ 
/*  69 */     int dataLen = buf.getInt();
/*  70 */     byte[] data = new byte[dataLen];
/*  71 */     buf.getBytes(data, 0, dataLen);
/*  72 */     setData(data);
/*     */ 
/*  74 */     isPortal(buf.getBoolean());
/*     */   }
/*     */ 
/*     */   public byte[] getData() {
/*  78 */     return this.data;
/*     */   }
/*     */   public void setData(byte[] data) {
/*  81 */     this.data = data;
/*     */   }
/*     */ 
/*     */   public boolean getStatus()
/*     */   {
/*  88 */     return this.responseStatus;
/*     */   }
/*     */   public void setStatus(boolean status) {
/*  91 */     this.responseStatus = status;
/*     */   }
/*     */ 
/*     */   public void isPortal(boolean flag) {
/*  95 */     this.isPortalFlag = flag;
/*     */   }
/*     */   public boolean isPortal() {
/*  98 */     return this.isPortalFlag;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.RegisterEntityResponseEvent
 * JD-Core Version:    0.6.0
 */