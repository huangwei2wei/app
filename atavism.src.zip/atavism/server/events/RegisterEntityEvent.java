/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ 
/*     */ public class RegisterEntityEvent extends Event
/*     */ {
/* 101 */   boolean isPortalFlag = false;
/* 102 */   private byte[] data = null;
/*     */ 
/*     */   public RegisterEntityEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RegisterEntityEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  18 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public RegisterEntityEvent(byte[] data, boolean isPortaling)
/*     */   {
/*  33 */     setData(data);
/*  34 */     isPortal(isPortaling);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  38 */     return "RegisterEntityEvent";
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  42 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/*  45 */     byte[] entityData = getData();
/*  46 */     AOByteBuffer buf = new AOByteBuffer(entityData.length + 32);
/*  47 */     buf.putLong(-1L);
/*  48 */     buf.putInt(msgId);
/*     */ 
/*  51 */     if (entityData == null) {
/*  52 */       throw new AORuntimeException("RegisterEntityEvent.toBytes: data is null");
/*     */     }
/*  54 */     buf.putInt(entityData.length);
/*  55 */     buf.putBytes(entityData, 0, entityData.length);
/*  56 */     buf.putBoolean(isPortal());
/*  57 */     buf.flip();
/*  58 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/*  62 */     buf.rewind();
/*  63 */     buf.getLong();
/*  64 */     buf.getInt();
/*     */ 
/*  67 */     int dataLen = buf.getInt();
/*     */ 
/*  70 */     byte[] entityData = new byte[dataLen];
/*  71 */     buf.getBytes(entityData, 0, dataLen);
/*  72 */     setData(entityData);
/*     */ 
/*  74 */     isPortal(buf.getBoolean());
/*     */   }
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  81 */     if (this.data == null) {
/*  82 */       Log.warn("RegisterEntityEvent: data is null");
/*  83 */       return null;
/*     */     }
/*  85 */     return this.data;
/*     */   }
/*     */ 
/*     */   public void setData(byte[] bytes) {
/*  89 */     this.data = bytes;
/*     */   }
/*     */ 
/*     */   public void isPortal(boolean b)
/*     */   {
/*  94 */     this.isPortalFlag = b;
/*     */   }
/*     */ 
/*     */   public boolean isPortal() {
/*  98 */     return this.isPortalFlag;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.RegisterEntityEvent
 * JD-Core Version:    0.6.0
 */