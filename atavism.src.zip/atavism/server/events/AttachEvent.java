/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.objects.AOObject;
/*     */ import atavism.server.objects.DisplayContext;
/*     */ import atavism.server.objects.DisplayContext.Submesh;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class AttachEvent extends Event
/*     */ {
/* 122 */   private OID objToAttachID = null;
/* 123 */   private String socketName = null;
/* 124 */   private DisplayContext displayContext = null;
/*     */ 
/*     */   public AttachEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AttachEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  15 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public AttachEvent(AOObject attacher, AOObject objToAttach, String socketName)
/*     */   {
/*  21 */     super(attacher);
/*  22 */     setObjToAttachID(objToAttach.getOid());
/*  23 */     setSocketName(socketName);
/*  24 */     setDisplayContext(objToAttach.displayContext());
/*     */   }
/*     */ 
/*     */   public AttachEvent(OID attacherOid, OID attacheeOid, String socketName, DisplayContext dc)
/*     */   {
/*  29 */     super(attacherOid);
/*  30 */     setObjToAttachID(attacheeOid);
/*  31 */     setSocketName(socketName);
/*  32 */     setDisplayContext(dc);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  36 */     return "AttachEvent";
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  40 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/*  42 */     AOByteBuffer buf = new AOByteBuffer(200);
/*  43 */     buf.putOID(getAttacherOid());
/*  44 */     buf.putInt(msgId);
/*     */ 
/*  47 */     buf.putOID(getObjToAttachID());
/*  48 */     buf.putString(this.socketName);
/*     */ 
/*  51 */     buf.putString(this.displayContext.getMeshFile());
/*  52 */     Set submeshes = this.displayContext.getSubmeshes();
/*  53 */     buf.putInt(submeshes.size());
/*  54 */     Iterator sIter = submeshes.iterator();
/*  55 */     while (sIter.hasNext()) {
/*  56 */       DisplayContext.Submesh submesh = (DisplayContext.Submesh)sIter.next();
/*  57 */       buf.putString(submesh.name);
/*  58 */       buf.putString(submesh.material);
/*     */     }
/*  60 */     buf.flip();
/*  61 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/*  65 */     buf.rewind();
/*  66 */     setAttacherOid(buf.getOID());
/*  67 */     buf.getInt();
/*     */ 
/*  69 */     setObjToAttachID(buf.getOID());
/*  70 */     setSocketName(buf.getString());
/*     */ 
/*  73 */     DisplayContext dc = new DisplayContext();
/*  74 */     dc.setMeshFile(buf.getString());
/*  75 */     Set submeshes = new HashSet();
/*     */ 
/*  77 */     int numSubmeshes = buf.getInt();
/*  78 */     while (numSubmeshes > 0) {
/*  79 */       String name = buf.getString();
/*  80 */       String material = buf.getString();
/*  81 */       DisplayContext.Submesh submesh = new DisplayContext.Submesh(name, material);
/*     */ 
/*  83 */       submeshes.add(submesh);
/*  84 */       numSubmeshes--;
/*     */     }
/*  86 */     dc.setSubmeshes(submeshes);
/*  87 */     setDisplayContext(dc);
/*     */   }
/*     */ 
/*     */   public void setAttacherOid(OID oid)
/*     */   {
/*  92 */     setObjectOid(oid);
/*     */   }
/*     */   public OID getAttacherOid() {
/*  95 */     return getObjectOid();
/*     */   }
/*     */ 
/*     */   public void setObjToAttachID(OID objID)
/*     */   {
/* 102 */     this.objToAttachID = objID;
/*     */   }
/*     */   public OID getObjToAttachID() {
/* 105 */     return this.objToAttachID;
/*     */   }
/*     */ 
/*     */   public void setSocketName(String socketName) {
/* 109 */     this.socketName = socketName;
/*     */   }
/*     */   public String getSocketName() {
/* 112 */     return this.socketName;
/*     */   }
/*     */ 
/*     */   public void setDisplayContext(DisplayContext dc) {
/* 116 */     this.displayContext = dc;
/*     */   }
/*     */   public DisplayContext getDisplayContext() {
/* 119 */     return this.displayContext;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.AttachEvent
 * JD-Core Version:    0.6.0
 */