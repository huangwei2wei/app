/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.Log;
/*    */ 
/*    */ public class AuthorizedLoginEvent extends Event
/*    */ {
/* 79 */   private AOByteBuffer worldToken = null;
/*    */ 
/* 81 */   private String version = null;
/*    */ 
/* 83 */   private OID oid = null;
/*    */ 
/*    */   public AuthorizedLoginEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AuthorizedLoginEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 17 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public AuthorizedLoginEvent(AOObject obj) {
/* 21 */     super(obj);
/* 22 */     this.oid = obj.getOid();
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 26 */     return "AuthorizedLoginEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 30 */     int msgId = 80;
/* 31 */     AOByteBuffer buf = new AOByteBuffer(256);
/* 32 */     buf.putOID(null);
/* 33 */     buf.putInt(msgId);
/* 34 */     buf.putOID(this.oid);
/* 35 */     buf.putString(getVersion());
/* 36 */     buf.putByteBuffer(this.worldToken);
/* 37 */     buf.flip();
/* 38 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 42 */     buf.rewind();
/* 43 */     OID dummyId = buf.getOID();
/* 44 */     int msgId = buf.getInt();
/* 45 */     Log.debug("AuthorizedLoginEvent, dummyId: " + dummyId + " msgId: " + msgId);
/* 46 */     OID oid = buf.getOID();
/* 47 */     String version = buf.getString();
/* 48 */     Log.debug("AuthorizedLoginEvent, oid: " + oid + " version: " + version);
/* 49 */     AOByteBuffer worldToken = buf.getByteBuffer();
/* 50 */     setOid(oid);
/* 51 */     setVersion(version);
/* 52 */     setWorldToken(worldToken);
/*    */   }
/*    */ 
/*    */   public void setOid(OID id) {
/* 56 */     this.oid = id;
/*    */   }
/*    */ 
/*    */   public OID getOid() {
/* 60 */     return this.oid;
/*    */   }
/*    */ 
/*    */   public void setVersion(String version) {
/* 64 */     this.version = version;
/*    */   }
/*    */ 
/*    */   public String getVersion() {
/* 68 */     return this.version;
/*    */   }
/*    */ 
/*    */   public void setWorldToken(AOByteBuffer worldToken) {
/* 72 */     this.worldToken = worldToken;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer getWorldToken() {
/* 76 */     return this.worldToken;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.AuthorizedLoginEvent
 * JD-Core Version:    0.6.0
 */