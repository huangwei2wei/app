/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class ConResetEvent extends Event
/*    */ {
/*    */   public ConResetEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConResetEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 21 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public ConResetEvent(AOObject user) {
/* 25 */     super(user);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 29 */     return "ConReset";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 33 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 36 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 37 */     buf.putOID(getObjectOid());
/* 38 */     buf.putInt(msgId);
/* 39 */     buf.flip();
/* 40 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf)
/*    */   {
/* 45 */     buf.rewind();
/*    */ 
/* 47 */     AOObject obj = AOObject.getObject(buf.getOID());
/* 48 */     if (!obj.isUser()) {
/* 49 */       throw new AORuntimeException("ConResetEvent.parseBytes: not a user");
/*    */     }
/* 51 */     setUser(obj);
/* 52 */     buf.getInt();
/*    */   }
/*    */ 
/*    */   public void setUser(AOObject user) {
/* 56 */     setObject(user);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.ConResetEvent
 * JD-Core Version:    0.6.0
 */