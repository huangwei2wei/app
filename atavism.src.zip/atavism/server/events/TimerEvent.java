/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class TimerEvent extends Event
/*    */ {
/*    */   public TimerEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TimerEvent(AOObject obj)
/*    */   {
/* 16 */     super(obj);
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 20 */     throw new AORuntimeException("TimerEvent: tobytes not implemented");
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 24 */     throw new AORuntimeException("TimerEvent: parsebytes not implemented");
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 28 */     return "TimerEvent";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.TimerEvent
 * JD-Core Version:    0.6.0
 */