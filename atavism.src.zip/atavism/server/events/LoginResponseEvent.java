/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class LoginResponseEvent extends Event
/*    */ {
/* 88 */   private long time = 0L;
/*    */ 
/* 90 */   private boolean successStatus = false;
/*    */ 
/* 92 */   private String message = null;
/*    */ 
/*    */   public LoginResponseEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LoginResponseEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 15 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public LoginResponseEvent(OID oid, boolean successStatus, String msg)
/*    */   {
/* 20 */     setOid(oid);
/* 21 */     setSuccessStatus(successStatus);
/* 22 */     setTime(System.currentTimeMillis());
/* 23 */     setMessage(msg);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 27 */     return "LoginResponseEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 31 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 33 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 34 */     buf.putOID(getOid());
/* 35 */     buf.putInt(msgId);
/* 36 */     buf.putLong(getTime());
/* 37 */     buf.putInt(getSuccessStatus() ? 1 : 0);
/* 38 */     buf.putString(getMessage());
/* 39 */     buf.flip();
/* 40 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 44 */     buf.rewind();
/* 45 */     setOid(buf.getOID());
/*    */ 
/* 48 */     buf.getInt();
/*    */ 
/* 50 */     setTime(buf.getLong());
/* 51 */     setSuccessStatus(buf.getInt() == 1);
/* 52 */     setMessage(buf.getString());
/*    */   }
/*    */ 
/*    */   public void setSuccessStatus(boolean status) {
/* 56 */     this.successStatus = status;
/*    */   }
/*    */ 
/*    */   public boolean getSuccessStatus() {
/* 60 */     return this.successStatus;
/*    */   }
/*    */ 
/*    */   public void setTime(long time) {
/* 64 */     this.time = time;
/*    */   }
/*    */ 
/*    */   public long getTime() {
/* 68 */     return this.time;
/*    */   }
/*    */ 
/*    */   public void setOid(OID id) {
/* 72 */     setObjectOid(id);
/*    */   }
/*    */ 
/*    */   public OID getOid() {
/* 76 */     return getObjectOid();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 80 */     return this.message;
/*    */   }
/*    */ 
/*    */   public void setMessage(String msg) {
/* 84 */     this.message = msg;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.LoginResponseEvent
 * JD-Core Version:    0.6.0
 */