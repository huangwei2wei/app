/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class ClientParameterEvent extends Event
/*    */ {
/* 57 */   private String parameterName = null;
/* 58 */   private String parameterValue = null;
/*    */ 
/*    */   public ClientParameterEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ClientParameterEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 13 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public ClientParameterEvent(String parameterName, String parameterValue)
/*    */   {
/* 18 */     setParameterName(parameterName);
/* 19 */     setParameterValue(parameterValue);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 23 */     return "ClientParameterEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 27 */     Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 29 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 30 */     buf.putString(getParameterName());
/* 31 */     buf.putString(getParameterValue());
/*    */ 
/* 33 */     buf.flip();
/* 34 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 38 */     buf.rewind();
/* 39 */     setParameterName(buf.getString());
/* 40 */     setParameterValue(buf.getString());
/*    */   }
/*    */ 
/*    */   public void setParameterName(String parameterName) {
/* 44 */     this.parameterName = parameterName;
/*    */   }
/*    */   public String getParameterName() {
/* 47 */     return this.parameterName;
/*    */   }
/*    */ 
/*    */   public void setParameterValue(String parameterValue) {
/* 51 */     this.parameterValue = parameterValue;
/*    */   }
/*    */   public String getParameterValue() {
/* 54 */     return this.parameterValue;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.ClientParameterEvent
 * JD-Core Version:    0.6.0
 */