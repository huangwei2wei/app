/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class ScriptEvent extends Event
/*    */ {
/* 46 */   private Object data = null;
/*    */ 
/*    */   public ScriptEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ScriptEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 17 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public ScriptEvent(AOObject target) {
/* 21 */     super(target);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 25 */     return "ScriptEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 29 */     throw new AORuntimeException("ScriptEvent: not implemented");
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 33 */     throw new AORuntimeException("ScriptEvent: not implemented");
/*    */   }
/*    */ 
/*    */   public Object getData()
/*    */   {
/* 39 */     return this.data;
/*    */   }
/*    */ 
/*    */   public void setData(Object o) {
/* 43 */     this.data = o;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.ScriptEvent
 * JD-Core Version:    0.6.0
 */