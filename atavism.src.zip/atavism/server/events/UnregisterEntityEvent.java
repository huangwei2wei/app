/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class UnregisterEntityEvent extends Event
/*    */ {
/* 46 */   private OID oid = null;
/*    */ 
/*    */   public UnregisterEntityEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UnregisterEntityEvent(AOObject obj)
/*    */   {
/* 14 */     setOid(obj.getOid());
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 18 */     return "UnregisterEntityEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 22 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 25 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 26 */     buf.putOID(null);
/* 27 */     buf.putInt(msgId);
/* 28 */     buf.putOID(this.oid);
/* 29 */     buf.flip();
/* 30 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 34 */     buf.rewind();
/* 35 */     buf.getOID();
/* 36 */     buf.getInt();
/* 37 */     setOid(buf.getOID());
/*    */   }
/*    */ 
/*    */   public OID getOid() {
/* 41 */     return this.oid;
/*    */   }
/*    */   public void setOid(OID oid2) {
/* 44 */     this.oid = oid2;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.UnregisterEntityEvent
 * JD-Core Version:    0.6.0
 */