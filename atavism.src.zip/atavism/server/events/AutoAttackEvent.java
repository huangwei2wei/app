/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class AutoAttackEvent extends Event
/*    */ {
/* 85 */   private boolean attackStatus = false;
/* 86 */   private OID targetOid = null;
/* 87 */   private String attackType = null;
/*    */ 
/*    */   public AutoAttackEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AutoAttackEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 14 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public AutoAttackEvent(AOObject attacker, AOObject target, String attackType, boolean attackStatus)
/*    */   {
/* 21 */     super(attacker);
/* 22 */     setTargetOid(target.getOid());
/* 23 */     setAttackType(attackType);
/* 24 */     setAttackStatus(attackStatus);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 28 */     return "AutoAttackEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 32 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 34 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 35 */     buf.putOID(getAttackerOid());
/* 36 */     buf.putInt(msgId);
/* 37 */     buf.putOID(getTargetOid());
/* 38 */     buf.putString(getAttackType());
/* 39 */     buf.putInt(getAttackStatus() ? 1 : 0);
/* 40 */     buf.flip();
/* 41 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 45 */     buf.rewind();
/*    */ 
/* 48 */     setAttackerOid(buf.getOID());
/*    */ 
/* 50 */     buf.getInt();
/*    */ 
/* 52 */     setTargetOid(buf.getOID());
/* 53 */     setAttackType(buf.getString());
/* 54 */     setAttackStatus(buf.getInt() == 1);
/*    */   }
/*    */ 
/*    */   public void setAttackerOid(OID id) {
/* 58 */     setObjectOid(id);
/*    */   }
/*    */   public OID getAttackerOid() {
/* 61 */     return getObjectOid();
/*    */   }
/*    */ 
/*    */   public void setTargetOid(OID oid) {
/* 65 */     this.targetOid = oid;
/*    */   }
/*    */   public OID getTargetOid() {
/* 68 */     return this.targetOid;
/*    */   }
/*    */ 
/*    */   public void setAttackType(String s) {
/* 72 */     this.attackType = s;
/*    */   }
/*    */   public String getAttackType() {
/* 75 */     return this.attackType;
/*    */   }
/*    */ 
/*    */   public void setAttackStatus(boolean s) {
/* 79 */     this.attackStatus = s;
/*    */   }
/*    */   public boolean getAttackStatus() {
/* 82 */     return this.attackStatus;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.AutoAttackEvent
 * JD-Core Version:    0.6.0
 */