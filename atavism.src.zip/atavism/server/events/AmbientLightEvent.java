/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.Color;
/*    */ 
/*    */ public class AmbientLightEvent extends Event
/*    */ {
/* 56 */   private Color color = null;
/*    */ 
/*    */   public AmbientLightEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AmbientLightEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 20 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public AmbientLightEvent(Color color)
/*    */   {
/* 25 */     setAmbientLight(color);
/*    */   }
/*    */ 
/*    */   public void setAmbientLight(Color color) {
/* 29 */     this.color = color;
/*    */   }
/*    */   public Color getAmbientLight() {
/* 32 */     return this.color;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 36 */     int msgId = Engine.getEventServer().getEventID(getClass());
/* 37 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 38 */     buf.putOID(null);
/* 39 */     buf.putInt(msgId);
/* 40 */     buf.putColor(getAmbientLight());
/* 41 */     buf.flip();
/* 42 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 46 */     buf.rewind();
/* 47 */     buf.getOID();
/* 48 */     buf.getInt();
/* 49 */     setAmbientLight(buf.getColor());
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 53 */     return "AmbientLightEvent";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.AmbientLightEvent
 * JD-Core Version:    0.6.0
 */