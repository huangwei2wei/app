/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.BasicWorldNode;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.math.Point;
/*    */ import atavism.server.math.Quaternion;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class DirLocOrientEvent extends Event
/*    */ {
/* 86 */   private AOVector dir = null;
/* 87 */   private Point loc = null;
/* 88 */   private Quaternion q = null;
/*    */ 
/*    */   public DirLocOrientEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DirLocOrientEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 14 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public DirLocOrientEvent(AOObject obj, AOVector dir, Point loc, Quaternion q, long time) {
/* 18 */     super(obj);
/* 19 */     setDir(dir);
/* 20 */     setLoc(loc);
/* 21 */     setQuaternion(q);
/*    */   }
/*    */ 
/*    */   public DirLocOrientEvent(OID objOid, BasicWorldNode wnode) {
/* 25 */     super(objOid);
/* 26 */     setDir(wnode.getDir());
/* 27 */     setLoc(wnode.getLoc());
/* 28 */     setQuaternion(wnode.getOrientation());
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 32 */     return "DirLocOrientEvent";
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 36 */     return "[DirLocOrientEvent: oid=" + getObjectOid() + ", dir=" + getDir() + ", loc=" + getLoc() + ", orient=" + this.q + "]";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes()
/*    */   {
/* 41 */     AOByteBuffer buf = new AOByteBuffer(80);
/* 42 */     buf.putOID(getObjectOid());
/* 43 */     buf.putInt(79);
/*    */ 
/* 45 */     buf.putLong(System.currentTimeMillis());
/* 46 */     buf.putAOVector(getDir());
/* 47 */     buf.putPoint(getLoc());
/* 48 */     buf.putQuaternion(getQuaternion());
/* 49 */     buf.flip();
/* 50 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 54 */     buf.rewind();
/*    */ 
/* 56 */     OID oid = buf.getOID();
/* 57 */     setObjectOid(oid);
/* 58 */     buf.getInt();
/* 59 */     buf.getLong();
/* 60 */     setDir(buf.getAOVector());
/* 61 */     setLoc(buf.getPoint());
/* 62 */     setQuaternion(buf.getQuaternion());
/*    */   }
/*    */ 
/*    */   public void setDir(AOVector v) {
/* 66 */     this.dir = v;
/*    */   }
/*    */   public AOVector getDir() {
/* 69 */     return this.dir;
/*    */   }
/*    */ 
/*    */   public void setLoc(Point p) {
/* 73 */     this.loc = p;
/*    */   }
/*    */   public Point getLoc() {
/* 76 */     return this.loc;
/*    */   }
/*    */ 
/*    */   public void setQuaternion(Quaternion q) {
/* 80 */     this.q = q;
/*    */   }
/*    */   public Quaternion getQuaternion() {
/* 83 */     return this.q;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.DirLocOrientEvent
 * JD-Core Version:    0.6.0
 */