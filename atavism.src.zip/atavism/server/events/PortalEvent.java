/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class PortalEvent extends Event
/*    */ {
/* 51 */   private String worldID = null;
/*    */ 
/*    */   public PortalEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PortalEvent(AOObject obj, String worldID)
/*    */   {
/* 18 */     super(obj);
/* 19 */     setWorldID(worldID);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 23 */     return "PortalEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 27 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 29 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 30 */     buf.putOID(getObjectOid());
/* 31 */     buf.putInt(msgId);
/* 32 */     buf.putString(getWorldID());
/* 33 */     buf.flip();
/* 34 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 38 */     buf.rewind();
/* 39 */     setObjectOid(buf.getOID());
/* 40 */     buf.getInt();
/* 41 */     setWorldID(buf.getString());
/*    */   }
/*    */ 
/*    */   public void setWorldID(String worldID) {
/* 45 */     this.worldID = worldID;
/*    */   }
/*    */   public String getWorldID() {
/* 48 */     return this.worldID;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.PortalEvent
 * JD-Core Version:    0.6.0
 */