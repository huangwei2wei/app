/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.Log;
/*    */ 
/*    */ public class NotifyNewObjectEvent extends Event
/*    */ {
/* 75 */   private OID newObjOid = null;
/*    */ 
/*    */   public NotifyNewObjectEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NotifyNewObjectEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 18 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public NotifyNewObjectEvent(AOObject notifyObj, AOObject newObj)
/*    */   {
/* 23 */     super(notifyObj);
/* 24 */     setNewObjectOid(newObj.getOid());
/*    */ 
/* 26 */     Log.debug("NotifyNewObjectEvent: checking obj to notify");
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 31 */     return "NotifyNewObjectEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 35 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 37 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 38 */     buf.putOID(getObjectOid());
/* 39 */     buf.putInt(msgId);
/* 40 */     buf.putOID(getNewObjectOid());
/* 41 */     buf.flip();
/* 42 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 46 */     buf.rewind();
/* 47 */     setObjectOid(buf.getOID());
/* 48 */     buf.getInt();
/* 49 */     setNewObjectOid(buf.getOID());
/*    */   }
/*    */ 
/*    */   public void setObjToNotify(AOObject obj)
/*    */   {
/* 55 */     setObjectOid(obj.getOid());
/*    */   }
/*    */ 
/*    */   public void setObjToNotifyOid(OID oid) {
/* 59 */     setObjectOid(oid);
/*    */   }
/*    */ 
/*    */   public OID getObjToNotifyOid()
/*    */   {
/* 64 */     return getObjectOid();
/*    */   }
/*    */ 
/*    */   public void setNewObjectOid(OID oid) {
/* 68 */     this.newObjOid = oid;
/*    */   }
/*    */   public OID getNewObjectOid() {
/* 71 */     return this.newObjOid;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.NotifyNewObjectEvent
 * JD-Core Version:    0.6.0
 */