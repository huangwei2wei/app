/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.msgsys.MessageAgent;
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.PrintStream;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class FragmentedMessage extends Event
/*     */ {
/* 157 */   public byte[] data = null;
/* 158 */   private int id = -1;
/* 159 */   private int seqNum = -1;
/* 160 */   private int totalSeq = -1;
/*     */ 
/* 163 */   protected static final Logger log = new Logger("FragmentedMessage");
/*     */ 
/* 178 */   private static Lock nextIdLock = LockFactory.makeLock("NextFragIDLock");
/* 179 */   private static int nextId = 1;
/*     */ 
/*     */   public FragmentedMessage()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FragmentedMessage(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  21 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public FragmentedMessage(byte[] data, int start, int end, int msgId, int seqNum)
/*     */   {
/*  34 */     int len = end - start + 1;
/*  35 */     this.data = new byte[len];
/*  36 */     System.arraycopy(data, start, this.data, 0, len);
/*     */ 
/*  38 */     this.id = msgId;
/*  39 */     this.seqNum = seqNum;
/*  40 */     this.totalSeq = -1;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  44 */     return "FragmentedMessage";
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  48 */     return "[FragmentedMessage: fragid=" + this.id + ", seqNum=" + this.seqNum + ", totalSeq=" + this.totalSeq + ", dataSize=" + this.data.length + "]";
/*     */   }
/*     */ 
/*     */   public static int fragmentCount(int bufLen, int maxBytes)
/*     */   {
/*  61 */     return (bufLen + maxBytes - 1) / maxBytes;
/*     */   }
/*     */ 
/*     */   public static List<FragmentedMessage> fragment(AOByteBuffer byteBuf, int maxBytes) {
/*  65 */     return fragment(byteBuf.copyBytes(), maxBytes);
/*     */   }
/*     */ 
/*     */   public static List<FragmentedMessage> fragment(byte[] buf, int maxBytes)
/*     */   {
/*  73 */     if (maxBytes < 1) {
/*  74 */       throw new AORuntimeException("maxBytes is too small");
/*     */     }
/*  76 */     int bufLen = buf.length;
/*  77 */     if (bufLen < 1) {
/*  78 */       throw new AORuntimeException("buf len is < 1");
/*     */     }
/*  80 */     int startPos = 0;
/*  81 */     int endPos = -1;
/*  82 */     int finalPos = bufLen - 1;
/*     */ 
/*  84 */     Integer serverID = Engine.getAgent().getAgentId();
/*  85 */     int nextID = getNextId();
/*  86 */     int msgId = serverID.intValue() ^ nextID;
/*  87 */     int seqNum = 0;
/*  88 */     LinkedList fragList = new LinkedList();
/*     */ 
/*  90 */     while (endPos < finalPos) {
/*  91 */       startPos = endPos + 1;
/*  92 */       endPos += maxBytes;
/*  93 */       if (endPos >= finalPos) {
/*  94 */         endPos = finalPos;
/*     */       }
/*  96 */       if (Log.loggingDebug) {
/*  97 */         Log.debug("FragmentedMessage.fragmentEvent: bufLen = " + bufLen + ", finalPos=" + finalPos + ", maxBytes=" + maxBytes + ", startPos=" + startPos + ", endPos=" + endPos + ", seqNum=" + seqNum + ", serverID=" + serverID + ", msgID=" + msgId);
/*     */       }
/*     */ 
/* 105 */       FragmentedMessage frag = new FragmentedMessage(buf, startPos, endPos, msgId, seqNum);
/*     */ 
/* 110 */       fragList.add(frag);
/* 111 */       seqNum++;
/*     */     }
/* 113 */     ((FragmentedMessage)fragList.getFirst()).totalSeq = seqNum;
/* 114 */     return fragList;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/* 118 */     buf.rewind();
/*     */ 
/* 121 */     buf.getOID();
/* 122 */     buf.getInt();
/*     */ 
/* 125 */     this.id = buf.getInt();
/*     */ 
/* 128 */     this.seqNum = buf.getInt();
/* 129 */     if (this.seqNum == 0) {
/* 130 */       this.totalSeq = buf.getInt();
/*     */     }
/*     */ 
/* 134 */     AOByteBuffer subBuf = buf.getByteBuffer();
/* 135 */     this.data = subBuf.copyBytes();
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/* 139 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/* 141 */     AOByteBuffer buf = new AOByteBuffer(this.data.length + 32);
/* 142 */     buf.putOID(null);
/* 143 */     buf.putInt(msgId);
/*     */ 
/* 145 */     buf.putInt(this.id);
/* 146 */     buf.putInt(this.seqNum);
/* 147 */     if (this.seqNum == 0) {
/* 148 */       buf.putInt(this.totalSeq);
/*     */     }
/*     */ 
/* 151 */     buf.putByteBuffer(new AOByteBuffer(this.data));
/*     */ 
/* 153 */     buf.flip();
/* 154 */     return buf;
/*     */   }
/*     */ 
/*     */   public static int getNextId()
/*     */   {
/* 170 */     nextIdLock.lock();
/*     */     try {
/* 172 */       int i = nextId++;
/*     */       return i; } finally { nextIdLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 183 */       Engine.getEventServer().registerEventId(1, "atavism.server.events.TerrainEvent");
/* 184 */       String s = new String("11");
/* 185 */       Event e = new TerrainEvent(s);
/* 186 */       fragment(e.toBytes(), 2);
/* 187 */       System.out.println("done");
/*     */     }
/*     */     catch (Exception e) {
/* 190 */       Log.exception("FragmentedMessage.main caught exception", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.FragmentedMessage
 * JD-Core Version:    0.6.0
 */