/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.Log;
/*    */ 
/*    */ public class ComEvent extends Event
/*    */ {
/*    */   public static final int SAY = 1;
/*    */   public static final int SERVER_INFO = 2;
/*    */   public static final int COMBAT_INFO = 5;
/*    */   public static final int GROUP = 4;
/* 78 */   private String senderName = null;
/* 79 */   private String mMessage = null;
/* 80 */   private int channelId = 0;
/*    */ 
/*    */   public ComEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ComEvent(AOObject comSrc, String senderName, int channel, String msg)
/*    */   {
/* 24 */     super(comSrc);
/* 25 */     setSenderName(senderName);
/* 26 */     setChannelId(channel);
/* 27 */     setMessage(msg);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 31 */     return "ComEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 35 */     AOByteBuffer buf = new AOByteBuffer(200);
/* 36 */     buf.putOID(getObjectOid());
/* 37 */     buf.putInt(3);
/* 38 */     buf.putString(getSenderName());
/* 39 */     buf.putInt(getChannelId());
/* 40 */     buf.putString(getMessage());
/* 41 */     buf.flip();
/* 42 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf)
/*    */   {
/* 47 */     buf.rewind();
/* 48 */     setObjectOid(buf.getOID());
/* 49 */     buf.getInt();
/* 50 */     setSenderName(buf.getString());
/* 51 */     setChannelId(buf.getInt());
/* 52 */     setMessage(buf.getString());
/*    */ 
/* 54 */     if (Log.loggingDebug)
/* 55 */       Log.debug("ComEvent.parseBytes: playerId=" + getObjectOid() + ", msg=" + getMessage());
/*    */   }
/*    */ 
/*    */   public void setSenderName(String name)
/*    */   {
/* 60 */     this.senderName = name;
/*    */   }
/*    */   public String getSenderName() {
/* 63 */     return this.senderName;
/*    */   }
/*    */   public void setMessage(String msg) {
/* 66 */     this.mMessage = msg;
/*    */   }
/*    */   public String getMessage() {
/* 69 */     return this.mMessage;
/*    */   }
/*    */   public void setChannelId(int channelId) {
/* 72 */     this.channelId = channelId;
/*    */   }
/*    */   public int getChannelId() {
/* 75 */     return this.channelId;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.ComEvent
 * JD-Core Version:    0.6.0
 */