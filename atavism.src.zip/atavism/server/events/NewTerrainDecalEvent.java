/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.objects.TerrainDecalData;
/*    */ 
/*    */ public class NewTerrainDecalEvent extends Event
/*    */ {
/*    */   private OID decalOid;
/*    */   private TerrainDecalData decalData;
/*    */ 
/*    */   public NewTerrainDecalEvent(OID decalOid, TerrainDecalData decalData)
/*    */   {
/* 12 */     this.decalOid = decalOid;
/* 13 */     this.decalData = decalData;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 17 */     return "NewTerrainDecalEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 21 */     int msgId = Engine.getEventServer().getEventID(getClass());
/* 22 */     AOByteBuffer buf = new AOByteBuffer(64);
/*    */ 
/* 24 */     buf.putOID(this.decalOid);
/* 25 */     buf.putInt(msgId);
/* 26 */     buf.putString(this.decalData.getImageName());
/* 27 */     buf.putInt(this.decalData.getPosX());
/* 28 */     buf.putInt(this.decalData.getPosZ());
/* 29 */     buf.putFloat(this.decalData.getSizeX());
/* 30 */     buf.putFloat(this.decalData.getSizeZ());
/* 31 */     buf.putFloat(this.decalData.getRotation());
/* 32 */     buf.putInt(this.decalData.getPriority());
/* 33 */     buf.putLong(0L);
/* 34 */     buf.flip();
/* 35 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 39 */     buf.rewind();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.NewTerrainDecalEvent
 * JD-Core Version:    0.6.0
 */