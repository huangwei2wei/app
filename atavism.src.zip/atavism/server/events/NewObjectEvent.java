/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.objects.AOObject;
/*     */ 
/*     */ public class NewObjectEvent extends Event
/*     */ {
/*     */   public OID objOid;
/*     */   public String objName;
/*     */   public Point objLoc;
/*     */   public Quaternion objOrient;
/*     */   public AOVector objScale;
/*     */   public int objType;
/*     */   public boolean objFollowsTerrain;
/*     */ 
/*     */   public NewObjectEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public NewObjectEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  20 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public NewObjectEvent(AOObject notifyObj, AOObject obj) {
/*  24 */     super(notifyObj);
/*  25 */     this.objOid = obj.getOid();
/*  26 */     this.objName = obj.getName();
/*  27 */     this.objLoc = obj.getLoc();
/*  28 */     this.objOrient = obj.getOrientation();
/*  29 */     this.objScale = obj.scale();
/*     */ 
/*  31 */     this.objType = getObjectType(obj);
/*     */ 
/*  37 */     if ((obj.isMob()) || (obj.isItem())) {
/*  38 */       this.objFollowsTerrain = true;
/*     */     }
/*     */     else
/*  41 */       this.objFollowsTerrain = false;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  47 */     return "NewObjectEvent";
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  51 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*  52 */     AOByteBuffer buf = new AOByteBuffer(200);
/*  53 */     buf.putOID(getObjectOid());
/*  54 */     buf.putInt(msgId);
/*  55 */     buf.putOID(this.objOid);
/*     */ 
/*  58 */     buf.putString(this.objName == null ? "unknown" : this.objName);
/*     */ 
/*  61 */     Point loc = this.objLoc;
/*  62 */     buf.putPoint(loc == null ? new Point() : loc);
/*     */ 
/*  65 */     Quaternion orient = this.objOrient;
/*  66 */     buf.putQuaternion(orient == null ? new Quaternion() : orient);
/*     */ 
/*  69 */     buf.putAOVector(this.objScale);
/*  70 */     buf.putInt(this.objType);
/*  71 */     buf.putInt(this.objFollowsTerrain ? 1 : 0);
/*     */ 
/*  87 */     buf.flip();
/*  88 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/*  92 */     buf.rewind();
/*  93 */     setObjectOid(buf.getOID());
/*     */ 
/*  95 */     buf.getInt();
/*     */ 
/*  97 */     this.objOid = buf.getOID();
/*  98 */     this.objName = buf.getString();
/*  99 */     this.objLoc = buf.getPoint();
/* 100 */     this.objOrient = buf.getQuaternion();
/* 101 */     this.objScale = buf.getAOVector();
/*     */ 
/* 103 */     this.objType = buf.getInt();
/* 104 */     this.objFollowsTerrain = (buf.getInt() == 1);
/*     */   }
/*     */ 
/*     */   public static int getObjectType(AOObject obj)
/*     */   {
/* 138 */     if (obj.isUser()) {
/* 139 */       return 3;
/*     */     }
/*     */ 
/* 142 */     if (obj.isMob()) {
/* 143 */       return 1;
/*     */     }
/* 145 */     if (obj.isItem()) {
/* 146 */       return 2;
/*     */     }
/* 148 */     if (obj.isStructure()) {
/* 149 */       return 0;
/*     */     }
/* 151 */     throw new RuntimeException("NewObjectEvent: unknown obj type: " + obj);
/*     */   }
/*     */ 
/*     */   public static String objectTypeToName(int id)
/*     */   {
/* 156 */     switch (id) {
/*     */     case 0:
/* 158 */       return "Structure";
/*     */     case 1:
/* 160 */       return "Mob";
/*     */     case 2:
/* 162 */       return "Item";
/*     */     case 3:
/* 164 */       return "User";
/*     */     }
/* 166 */     return "Unknown";
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.NewObjectEvent
 * JD-Core Version:    0.6.0
 */