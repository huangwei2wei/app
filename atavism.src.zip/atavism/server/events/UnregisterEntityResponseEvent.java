/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class UnregisterEntityResponseEvent extends Event
/*    */ {
/* 57 */   private boolean responseStatus = false;
/*    */ 
/*    */   public UnregisterEntityResponseEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UnregisterEntityResponseEvent(AOObject obj, boolean status)
/*    */   {
/* 19 */     super(obj);
/* 20 */     setStatus(status);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 24 */     return "UnregisterEntityResponse";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 28 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 31 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 32 */     buf.putOID(getObjectOid());
/* 33 */     buf.putInt(msgId);
/* 34 */     buf.putInt(getStatus() ? 1 : 0);
/* 35 */     buf.flip();
/* 36 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 40 */     buf.rewind();
/* 41 */     setObjectOid(buf.getOID());
/* 42 */     buf.getInt();
/*    */ 
/* 44 */     setStatus(buf.getInt() == 1);
/*    */   }
/*    */ 
/*    */   public boolean getStatus()
/*    */   {
/* 51 */     return this.responseStatus;
/*    */   }
/*    */   public void setStatus(boolean status) {
/* 54 */     this.responseStatus = status;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.UnregisterEntityResponseEvent
 * JD-Core Version:    0.6.0
 */