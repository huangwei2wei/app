/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ 
/*     */ public class AuthorizedLoginResponseEvent extends Event
/*     */ {
/*  99 */   private long time = 0L;
/*     */ 
/* 101 */   private boolean successStatus = false;
/*     */ 
/* 103 */   private String message = null;
/*     */ 
/* 105 */   private String version = null;
/*     */ 
/*     */   public AuthorizedLoginResponseEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AuthorizedLoginResponseEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  15 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public AuthorizedLoginResponseEvent(OID playerOid, boolean successStatus, String msg, String version)
/*     */   {
/*  21 */     setOid(playerOid);
/*  22 */     setSuccessStatus(successStatus);
/*  23 */     setTime(System.currentTimeMillis());
/*  24 */     setMessage(msg);
/*  25 */     setVersion(version);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  29 */     return "AuthorizedLoginResponseEvent";
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  33 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*     */ 
/*  35 */     AOByteBuffer buf = new AOByteBuffer(200);
/*  36 */     buf.putOID(getOid());
/*  37 */     buf.putInt(msgId);
/*  38 */     buf.putLong(getTime());
/*  39 */     buf.putInt(getSuccessStatus() ? 1 : 0);
/*  40 */     buf.putString(getMessage());
/*  41 */     buf.putString(getVersion());
/*  42 */     buf.flip();
/*  43 */     return buf;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf) {
/*  47 */     buf.rewind();
/*  48 */     setOid(buf.getOID());
/*     */ 
/*  50 */     buf.getInt();
/*     */ 
/*  52 */     setTime(buf.getLong());
/*  53 */     setSuccessStatus(buf.getInt() == 1);
/*  54 */     setMessage(buf.getString());
/*  55 */     setVersion(buf.getString());
/*     */   }
/*     */ 
/*     */   public void setSuccessStatus(boolean status) {
/*  59 */     this.successStatus = status;
/*     */   }
/*     */ 
/*     */   public boolean getSuccessStatus() {
/*  63 */     return this.successStatus;
/*     */   }
/*     */ 
/*     */   public void setTime(long time) {
/*  67 */     this.time = time;
/*     */   }
/*     */ 
/*     */   public long getTime() {
/*  71 */     return this.time;
/*     */   }
/*     */ 
/*     */   public void setOid(OID playerOid) {
/*  75 */     setObjectOid(playerOid);
/*     */   }
/*     */ 
/*     */   public OID getOid() {
/*  79 */     return getObjectOid();
/*     */   }
/*     */ 
/*     */   public String getMessage() {
/*  83 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void setMessage(String msg) {
/*  87 */     this.message = msg;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/*  91 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String ver) {
/*  95 */     this.version = ver;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.AuthorizedLoginResponseEvent
 * JD-Core Version:    0.6.0
 */