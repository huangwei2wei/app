/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class JScriptEvent extends Event
/*    */ {
/* 59 */   private String script = null;
/*    */ 
/*    */   public JScriptEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public JScriptEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 17 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public JScriptEvent(AOObject scripter, String script) {
/* 21 */     super(scripter);
/* 22 */     this.script = script;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 26 */     return "JScriptEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 30 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 32 */     String script = getScript();
/* 33 */     if (script.length() > 6000) {
/* 34 */       throw new AORuntimeException("JScriptEvent: script is too long");
/*    */     }
/* 36 */     AOByteBuffer buf = new AOByteBuffer(script.length() * 2 + 20);
/* 37 */     buf.putOID(getObjectOid());
/* 38 */     buf.putInt(msgId);
/*    */ 
/* 40 */     buf.putString(script);
/* 41 */     buf.flip();
/* 42 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 46 */     buf.rewind();
/* 47 */     setObjectOid(buf.getOID());
/* 48 */     buf.getInt();
/* 49 */     setScript(buf.getString());
/*    */   }
/*    */ 
/*    */   public String getScript() {
/* 53 */     return this.script;
/*    */   }
/*    */   public void setScript(String script) {
/* 56 */     this.script = script;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.JScriptEvent
 * JD-Core Version:    0.6.0
 */