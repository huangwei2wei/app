/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class LogoutResponseEvent extends Event
/*    */ {
/* 54 */   private boolean successStatus = false;
/*    */ 
/*    */   public LogoutResponseEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LogoutResponseEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 16 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public LogoutResponseEvent(AOObject obj, boolean successStatus) {
/* 20 */     super(obj);
/* 21 */     setSuccessStatus(successStatus);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 25 */     return "LogoutResponseEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 29 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 31 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 32 */     buf.putOID(getObjectOid());
/* 33 */     buf.putInt(msgId);
/* 34 */     buf.putInt(getSuccessStatus() ? 1 : 0);
/* 35 */     buf.flip();
/* 36 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 40 */     buf.rewind();
/* 41 */     setObjectOid(buf.getOID());
/*    */ 
/* 43 */     buf.getInt();
/* 44 */     setSuccessStatus(buf.getInt() == 1);
/*    */   }
/*    */ 
/*    */   public void setSuccessStatus(boolean status) {
/* 48 */     this.successStatus = status;
/*    */   }
/*    */   public boolean getSuccessStatus() {
/* 51 */     return this.successStatus;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.LogoutResponseEvent
 * JD-Core Version:    0.6.0
 */