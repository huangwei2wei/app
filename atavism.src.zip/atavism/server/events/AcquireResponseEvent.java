/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class AcquireResponseEvent extends Event
/*    */ {
/* 72 */   private boolean success = false;
/* 73 */   private AOObject targetObject = null;
/*    */ 
/*    */   public AcquireResponseEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AcquireResponseEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 14 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public AcquireResponseEvent(AOObject targetOwner, AOObject objToAcquire, boolean success)
/*    */   {
/* 20 */     super(targetOwner);
/* 21 */     setTargetObject(objToAcquire);
/* 22 */     setSuccessStatus(success);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 26 */     return "AcquireResponse";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 30 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 32 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 33 */     buf.putOID(getObjectOid());
/* 34 */     buf.putInt(msgId);
/*    */ 
/* 36 */     buf.putOID(getTargetObject().getOid());
/* 37 */     buf.putInt(getSuccessStatus() ? 1 : 0);
/* 38 */     buf.flip();
/* 39 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 43 */     buf.rewind();
/* 44 */     setTargetOwner(AOObject.getObject(buf.getOID()));
/* 45 */     buf.getInt();
/*    */ 
/* 47 */     setTargetObject(AOObject.getObject(buf.getOID()));
/* 48 */     setSuccessStatus(buf.getInt() == 1);
/*    */   }
/*    */ 
/*    */   public void setTargetOwner(AOObject targetOwner)
/*    */   {
/* 55 */     setObject(targetOwner);
/*    */   }
/*    */ 
/*    */   public void setTargetObject(AOObject obj) {
/* 59 */     this.targetObject = obj;
/*    */   }
/*    */   public AOObject getTargetObject() {
/* 62 */     return this.targetObject;
/*    */   }
/*    */ 
/*    */   public void setSuccessStatus(boolean val) {
/* 66 */     this.success = val;
/*    */   }
/*    */   public boolean getSuccessStatus() {
/* 69 */     return this.success;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.AcquireResponseEvent
 * JD-Core Version:    0.6.0
 */