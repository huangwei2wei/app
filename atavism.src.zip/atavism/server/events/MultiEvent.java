/*     */ package atavism.server.events;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.engine.Event;
/*     */ import atavism.server.engine.EventServer;
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.network.ClientConnection;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class MultiEvent extends Event
/*     */ {
/* 111 */   private List<Event> events = new LinkedList();
/* 112 */   private transient Lock lock = LockFactory.makeLock("MultiEventLock");
/* 113 */   protected static final Logger log = new Logger("MultiEvent");
/*     */ 
/*     */   public MultiEvent()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MultiEvent(AOByteBuffer buf, ClientConnection con)
/*     */   {
/*  18 */     super(buf, con);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  22 */     return "MultiEvent";
/*     */   }
/*     */ 
/*     */   public void add(Event event) {
/*  26 */     this.lock.lock();
/*     */     try {
/*  28 */       this.events.add(event);
/*     */     }
/*     */     finally {
/*  31 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setEvents(List<Event> events)
/*     */   {
/*  40 */     this.lock.lock();
/*     */     try {
/*  42 */       this.events = new LinkedList(events);
/*     */     }
/*     */     finally {
/*  45 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Event> getEvents()
/*     */   {
/*  52 */     this.lock.lock();
/*     */     try {
/*  54 */       LinkedList localLinkedList = new LinkedList(this.events);
/*     */       return localLinkedList; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void parseBytes(AOByteBuffer buf)
/*     */   {
/*  62 */     buf.rewind();
/*     */ 
/*  65 */     buf.getOID();
/*  66 */     buf.getInt();
/*     */ 
/*  69 */     buf.getOID();
/*  70 */     int size = buf.getInt();
/*  71 */     List events = new LinkedList();
/*  72 */     while (size > 0) {
/*  73 */       buf.getByteBuffer();
/*     */ 
/*  75 */       size--;
/*     */     }
/*  77 */     setEvents(events);
/*     */   }
/*     */ 
/*     */   public AOByteBuffer toBytes() {
/*  81 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*  82 */     List bufList = new LinkedList();
/*  83 */     int payloadSize = 2000;
/*  84 */     this.lock.lock();
/*     */     try
/*     */     {
/*  87 */       for (Event event : this.events) {
/*  88 */         AOByteBuffer buf = event.toBytes();
/*  89 */         bufList.add(buf);
/*  90 */         payloadSize += buf.limit();
/*     */       }
/*     */ 
/*  94 */       if (Log.loggingDebug)
/*  95 */         log.debug("tobytes: making new buffer size " + payloadSize);
/*  96 */       AOByteBuffer multiBuf = new AOByteBuffer(payloadSize);
/*  97 */       multiBuf.putOID(null);
/*  98 */       multiBuf.putInt(msgId);
/*  99 */       multiBuf.putInt(bufList.size());
/* 100 */       for (AOByteBuffer buf : bufList) {
/* 101 */         multiBuf.putByteBuffer(buf);
/*     */       }
/* 103 */       multiBuf.flip();
/* 104 */       ??? = multiBuf;
/*     */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.MultiEvent
 * JD-Core Version:    0.6.0
 */