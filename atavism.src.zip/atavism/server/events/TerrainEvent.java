/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ 
/*    */ public class TerrainEvent extends Event
/*    */ {
/* 57 */   private String terrainInfo = null;
/*    */ 
/*    */   public TerrainEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TerrainEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 19 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public TerrainEvent(String terrainInfo)
/*    */   {
/* 24 */     setTerrain(terrainInfo);
/*    */   }
/*    */ 
/*    */   public void setTerrain(String terrainInfo) {
/* 28 */     this.terrainInfo = terrainInfo;
/*    */   }
/*    */   public String getTerrain() {
/* 31 */     return this.terrainInfo;
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 35 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 37 */     String t = getTerrain();
/* 38 */     AOByteBuffer buf = new AOByteBuffer(t.length() * 2 + 20);
/* 39 */     buf.putOID(null);
/* 40 */     buf.putInt(msgId);
/* 41 */     buf.putString(getTerrain());
/* 42 */     buf.flip();
/* 43 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 47 */     buf.rewind();
/* 48 */     buf.getOID();
/* 49 */     buf.getInt();
/* 50 */     setTerrain(buf.getString());
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 54 */     return "TerrainEvent";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.TerrainEvent
 * JD-Core Version:    0.6.0
 */