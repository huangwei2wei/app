/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ import atavism.server.util.Log;
/*    */ 
/*    */ public class AcquireEvent extends Event
/*    */ {
/* 78 */   private AOObject targetOwner = null;
/* 79 */   private AOObject targetObject = null;
/*    */ 
/*    */   public AcquireEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AcquireEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 17 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public AcquireEvent(AOObject targetOwner, AOObject objToAcquire)
/*    */   {
/* 22 */     setTargetOwner(targetOwner);
/* 23 */     setTargetObject(objToAcquire);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 27 */     return "AcquireEvent";
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf)
/*    */   {
/* 32 */     buf.rewind();
/*    */ 
/* 35 */     OID playerId = buf.getOID();
/* 36 */     setTargetOwner(AOObject.getObject(playerId));
/* 37 */     buf.getInt();
/*    */ 
/* 40 */     OID objId = buf.getOID();
/* 41 */     setTargetObject(AOObject.getObject(objId));
/* 42 */     if ((getTargetObject() == null) && 
/* 43 */       (Log.loggingDebug))
/* 44 */       Log.debug("AcquireEvent.parseBytes: targetobject is null, oid=" + objId);
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes()
/*    */   {
/* 50 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 52 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 53 */     buf.putOID(getTargetOwner().getOid());
/* 54 */     buf.putInt(msgId);
/* 55 */     buf.putOID(getTargetObject().getOid());
/* 56 */     buf.flip();
/* 57 */     return buf;
/*    */   }
/*    */ 
/*    */   public void setTargetOwner(AOObject targetOwner)
/*    */   {
/* 64 */     this.targetOwner = targetOwner;
/*    */   }
/*    */ 
/*    */   public AOObject getTargetOwner() {
/* 68 */     return this.targetOwner;
/*    */   }
/*    */ 
/*    */   public void setTargetObject(AOObject targetObject) {
/* 72 */     this.targetObject = targetObject;
/*    */   }
/*    */   public AOObject getTargetObject() {
/* 75 */     return this.targetObject;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.AcquireEvent
 * JD-Core Version:    0.6.0
 */