/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.objects.AOObject;
/*    */ 
/*    */ public class LoginEvent extends Event
/*    */ {
/* 65 */   private String version = null;
/* 66 */   private OID oid = null;
/*    */ 
/*    */   public LoginEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LoginEvent(AOByteBuffer buf, ClientConnection con)
/*    */   {
/* 16 */     super(buf, con);
/*    */   }
/*    */ 
/*    */   public LoginEvent(AOObject obj) {
/* 20 */     super(obj);
/* 21 */     this.oid = obj.getOid();
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 25 */     return "LoginEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 29 */     int msgId = 1;
/* 30 */     AOByteBuffer buf = new AOByteBuffer(20);
/* 31 */     buf.putOID(null);
/* 32 */     buf.putInt(msgId);
/* 33 */     buf.putOID(this.oid);
/* 34 */     buf.putString(getVersion());
/* 35 */     buf.flip();
/* 36 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 40 */     buf.rewind();
/* 41 */     buf.getOID();
/* 42 */     buf.getInt();
/* 43 */     OID oid = buf.getOID();
/* 44 */     String version = null;
/* 45 */     if (buf.remaining() != 0) {
/* 46 */       version = buf.getString();
/*    */     }
/* 48 */     setOid(oid);
/* 49 */     setVersion(version);
/*    */   }
/*    */ 
/*    */   public void setOid(OID id) {
/* 53 */     this.oid = id;
/*    */   }
/*    */   public OID getOid() {
/* 56 */     return this.oid;
/*    */   }
/*    */ 
/*    */   public void setVersion(String version) {
/* 60 */     this.version = version;
/*    */   }
/*    */   public String getVersion() {
/* 63 */     return this.version;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.LoginEvent
 * JD-Core Version:    0.6.0
 */