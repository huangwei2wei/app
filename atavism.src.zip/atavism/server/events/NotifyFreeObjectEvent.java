/*    */ package atavism.server.events;
/*    */ 
/*    */ import atavism.server.engine.Engine;
/*    */ import atavism.server.engine.Event;
/*    */ import atavism.server.engine.EventServer;
/*    */ import atavism.server.engine.OID;
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.util.AORuntimeException;
/*    */ 
/*    */ public class NotifyFreeObjectEvent extends Event
/*    */ {
/*    */   private OID target;
/*    */   private OID subject;
/*    */ 
/*    */   public NotifyFreeObjectEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NotifyFreeObjectEvent(OID targetOid, OID subjectOid)
/*    */   {
/* 16 */     this.target = targetOid;
/* 17 */     this.subject = subjectOid;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 21 */     return "NotifyFreeObjectEvent";
/*    */   }
/*    */ 
/*    */   public AOByteBuffer toBytes() {
/* 25 */     int msgId = Engine.getEventServer().getEventID(getClass());
/*    */ 
/* 27 */     AOByteBuffer buf = new AOByteBuffer(24);
/* 28 */     buf.putOID(this.target);
/* 29 */     buf.putInt(msgId);
/* 30 */     buf.putOID(this.subject);
/* 31 */     buf.flip();
/* 32 */     return buf;
/*    */   }
/*    */ 
/*    */   public void parseBytes(AOByteBuffer buf) {
/* 36 */     throw new AORuntimeException("Not implemented");
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.events.NotifyFreeObjectEvent
 * JD-Core Version:    0.6.0
 */