package atavism.server.physics;

import atavism.server.math.Matrix4;

public abstract interface Transform
{
  public abstract Matrix4 getTransform();
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.physics.Transform
 * JD-Core Version:    0.6.0
 */