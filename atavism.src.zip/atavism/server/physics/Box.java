/*    */ package atavism.server.physics;
/*    */ 
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.math.Plane;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class Box
/*    */   implements Geometry
/*    */ {
/* 11 */   private static Logger logger = Logger.getLogger(Box.class);
/*    */ 
/* 13 */   private AOVector halfExtents = new AOVector(0.0F, 0.0F, 0.0F);
/*    */ 
/*    */   public Box() {
/*    */   }
/*    */   public Box(AOVector _halfExtents) {
/* 18 */     this.halfExtents.assign(_halfExtents);
/*    */   }
/*    */ 
/*    */   private AOVector getPoint(int i) {
/* 22 */     AOVector pt = new AOVector();
/* 23 */     if (i % 2 != 0)
/* 24 */       pt.setX(this.halfExtents.getX());
/*    */     else {
/* 26 */       pt.setX(-1.0F * this.halfExtents.getX());
/*    */     }
/* 28 */     if (i / 2 % 2 != 0)
/* 29 */       pt.setY(this.halfExtents.getY());
/*    */     else {
/* 31 */       pt.setY(-1.0F * this.halfExtents.getY());
/*    */     }
/* 33 */     if (i / 4 % 2 != 0)
/* 34 */       pt.setZ(this.halfExtents.getZ());
/*    */     else {
/* 36 */       pt.setZ(-1.0F * this.halfExtents.getZ());
/*    */     }
/* 38 */     return pt;
/*    */   }
/*    */ 
/*    */   public List<AOVector> computeIntersection(Plane plane) {
/* 42 */     List rv = new LinkedList();
/* 43 */     List lineSegments = new LinkedList();
/* 44 */     for (int i = 0; i < 7; i++) {
/* 45 */       if (i % 2 == 0) {
/* 46 */         AOVector[] arr = new AOVector[2];
/* 47 */         arr[0] = getPoint(i);
/* 48 */         arr[1] = getPoint(i + 1);
/* 49 */         lineSegments.add(arr);
/*    */       }
/* 51 */       if (i / 2 % 2 == 0) {
/* 52 */         AOVector[] arr = new AOVector[2];
/* 53 */         arr[0] = getPoint(i);
/* 54 */         arr[1] = getPoint(i + 2);
/* 55 */         lineSegments.add(arr);
/*    */       }
/* 57 */       if (i / 4 % 2 == 0) {
/* 58 */         AOVector[] arr = new AOVector[2];
/* 59 */         arr[0] = getPoint(i);
/* 60 */         arr[1] = getPoint(i + 4);
/* 61 */         lineSegments.add(arr);
/*    */       }
/*    */     }
/* 64 */     if (logger.isDebugEnabled()) {
/* 65 */       for (int i = 0; i < lineSegments.size(); i++) {
/* 66 */         logger.debug("Got box line from " + ((AOVector[])lineSegments.get(i))[0] + " to " + ((AOVector[])lineSegments.get(i))[1]);
/*    */       }
/*    */     }
/* 69 */     for (int i = 0; i < lineSegments.size(); i++) {
/* 70 */       AOVector pt0 = ((AOVector[])lineSegments.get(i))[0];
/* 71 */       AOVector pt1 = ((AOVector[])lineSegments.get(i))[1];
/* 72 */       float d0 = plane.getDistance(pt0);
/* 73 */       float d1 = plane.getDistance(pt1);
/* 74 */       AOVector point = null;
/* 75 */       if (d1 == 0.0F) {
/* 76 */         logger.debug("Added point: " + pt1 + " with distance: " + d1);
/* 77 */         point = pt1;
/* 78 */       } else if (d0 == 0.0F) {
/* 79 */         logger.debug("Added point: " + pt0 + " with distance: " + d0);
/* 80 */         point = pt0; } else {
/* 81 */         if (((d0 <= 0.0F) || (d1 >= 0.0F)) && ((d0 >= 0.0F) || (d1 <= 0.0F))) continue;
/* 82 */         AOVector portion0 = AOVector.multiply(pt0, -d1 / (d0 - d1));
/* 83 */         AOVector portion1 = AOVector.multiply(pt1, d0 / (d0 - d1));
/* 84 */         logger.debug("Added point: " + AOVector.add(portion0, portion1) + " with distances " + d0 + " and " + d1);
/* 85 */         point = AOVector.add(portion0, portion1);
/*    */       }
/*    */ 
/* 89 */       if (!rv.contains(point)) {
/* 90 */         rv.add(point);
/*    */       }
/*    */     }
/* 93 */     return rv;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 97 */     return "[Box: halfExtents = " + this.halfExtents.toString() + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.physics.Box
 * JD-Core Version:    0.6.0
 */