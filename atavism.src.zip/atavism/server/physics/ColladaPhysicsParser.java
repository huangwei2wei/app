/*     */ package atavism.server.physics;
/*     */ 
/*     */ import atavism.server.math.AOVector;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ public class ColladaPhysicsParser
/*     */ {
/*  21 */   private static Logger logger = Logger.getLogger(ColladaPhysicsParser.class);
/*     */ 
/*  23 */   public static float UNITS_PER_METER = 1.0F;
/*     */ 
/*     */   public static Shape<? extends Geometry> processShape(Element shapeElement) throws SAXException {
/*  26 */     NodeList shapeElementChildren = shapeElement.getChildNodes();
/*  27 */     List transformChain = new ArrayList();
/*  28 */     Shape rv = null;
/*  29 */     for (int i = 0; i < shapeElementChildren.getLength(); i++) {
/*  30 */       Node childNode = shapeElementChildren.item(i);
/*  31 */       if (childNode.getNodeType() != 1) {
/*     */         continue;
/*     */       }
/*  34 */       String nodeName = childNode.getNodeName();
/*  35 */       if (nodeName.equals("translate")) {
/*  36 */         String translateText = childNode.getTextContent();
/*  37 */         String[] data = translateText.split("\\s+");
/*  38 */         if (data.length != 3) {
/*  39 */           logger.warn(new StringBuilder().append("Invalid translate text: ").append(translateText).toString());
/*  40 */           return null;
/*     */         }
/*  42 */         TranslateTransform t = new TranslateTransform();
/*  43 */         t.setX(UNITS_PER_METER * Float.valueOf(data[0]).floatValue());
/*  44 */         t.setY(UNITS_PER_METER * Float.valueOf(data[1]).floatValue());
/*  45 */         t.setZ(UNITS_PER_METER * Float.valueOf(data[2]).floatValue());
/*  46 */         transformChain.add(t);
/*  47 */       } else if (nodeName.equals("rotate")) {
/*  48 */         String rotateText = childNode.getTextContent();
/*  49 */         String[] data = rotateText.split("\\s+");
/*  50 */         if (data.length != 4) {
/*  51 */           logger.warn(new StringBuilder().append("Invalid rotate text: ").append(rotateText).toString());
/*  52 */           return null;
/*     */         }
/*  54 */         RotateTransform t = new RotateTransform();
/*  55 */         AOVector axis = new AOVector(Float.valueOf(data[0]).floatValue(), Float.valueOf(data[1]).floatValue(), Float.valueOf(data[2]).floatValue());
/*  56 */         float halfAngle = 0.5F * (float)Math.toRadians(Float.valueOf(data[3]).floatValue());
/*  57 */         float cos = (float)Math.cos(halfAngle);
/*  58 */         float sin = (float)Math.sin(halfAngle);
/*  59 */         AOVector normAxis = axis.normalize();
/*  60 */         t.setW(cos);
/*  61 */         t.setX(sin * normAxis.getX());
/*  62 */         t.setY(sin * normAxis.getY());
/*  63 */         t.setZ(sin * normAxis.getZ());
/*  64 */         transformChain.add(t);
/*  65 */       } else if (nodeName.equals("box")) {
/*  66 */         NodeList halfExtentsList = ((Element)childNode).getElementsByTagName("half_extents");
/*  67 */         Node halfExtentsNode = halfExtentsList.item(0);
/*  68 */         String halfExtentsText = halfExtentsNode.getTextContent();
/*  69 */         String[] data = halfExtentsText.split("\\s+");
/*  70 */         if (data.length != 3) {
/*  71 */           logger.warn(new StringBuilder().append("Invalid half_extents text: ").append(halfExtentsText).toString());
/*  72 */           return null;
/*     */         }
/*  74 */         AOVector halfExtents = new AOVector(UNITS_PER_METER * Float.valueOf(data[0]).floatValue(), UNITS_PER_METER * Float.valueOf(data[1]).floatValue(), UNITS_PER_METER * Float.valueOf(data[2]).floatValue());
/*     */ 
/*  78 */         Box box = new Box(halfExtents);
/*  79 */         if (logger.isDebugEnabled()) {
/*  80 */           StringBuilder sb = new StringBuilder();
/*  81 */           sb.append("Got box:");
/*  82 */           sb.append(box);
/*  83 */           sb.append("\n");
/*  84 */           sb.append("Transform Chain: ");
/*  85 */           for (int j = 0; j < transformChain.size(); j++) {
/*  86 */             sb.append("  ");
/*  87 */             sb.append(transformChain.get(j));
/*     */           }
/*  89 */           logger.debug(sb.toString());
/*     */         }
/*  91 */         Shape shape = new Shape();
/*  92 */         shape.setGeometry(box);
/*  93 */         rv = shape;
/*  94 */         for (int j = 0; j < transformChain.size(); j++) {
/*  95 */           rv.addTransform((Transform)transformChain.get(j));
/*     */         }
/*  97 */         logger.debug(rv);
/*     */       } else {
/*  99 */         logger.warn(new StringBuilder().append("Unsupported node type: ").append(nodeName).toString());
/*     */       }
/*     */     }
/* 102 */     return rv;
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv) {
/* 106 */     String filename = "water_trim_corner_sqr.physics";
/* 107 */     if (argv.length != 0) {
/* 108 */       filename = argv[0];
/*     */     }
/* 110 */     File f = new File(filename);
/* 111 */     parsePhysics(f);
/*     */   }
/*     */ 
/*     */   public static List<Shape<? extends Geometry>> parsePhysics(String physicsData) {
/* 115 */     return parsePhysics(new ByteArrayInputStream(physicsData.getBytes()));
/*     */   }
/*     */ 
/*     */   public static List<Shape<? extends Geometry>> parsePhysics(File f) {
/*     */     try {
/* 120 */       FileReader reader = new FileReader(f);
/* 121 */       StringBuilder sb = new StringBuilder();
/* 122 */       char[] buf = new char[4096];
/*     */       while (true) {
/* 124 */         int bytes_read = reader.read(buf, 0, buf.length);
/* 125 */         if (bytes_read > 0) {
/* 126 */           sb.append(buf, 0, bytes_read); } else {
/* 127 */           if (bytes_read != 0) break;
/* 128 */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 133 */       return parsePhysics(sb.toString());
/*     */     } catch (IOException e) {
/* 135 */       logger.error(new StringBuilder().append("IOException: ").append(e).toString());
/*     */     }
/* 137 */     return null;
/*     */   }
/*     */ 
/*     */   public static List<Shape<? extends Geometry>> parsePhysics(InputStream physicsData) {
/*     */     try {
/* 142 */       List rv = new LinkedList();
/* 143 */       DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
/* 144 */       DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
/*     */ 
/* 146 */       Document doc = docBuilder.parse(physicsData);
/*     */ 
/* 149 */       NodeList physicsModelList = doc.getElementsByTagName("physics_model");
/* 150 */       for (int i = 0; i < physicsModelList.getLength(); i++) {
/* 151 */         Node physicsModelNode = physicsModelList.item(i);
/* 152 */         if (physicsModelNode.getNodeType() != 1) {
/*     */           continue;
/*     */         }
/* 155 */         NodeList rigidBodyList = ((Element)physicsModelNode).getElementsByTagName("rigid_body");
/* 156 */         for (int j = 0; j < rigidBodyList.getLength(); j++) {
/* 157 */           Node rigidBodyNode = rigidBodyList.item(j);
/* 158 */           if (rigidBodyNode.getNodeType() != 1) {
/*     */             continue;
/*     */           }
/* 161 */           Element rigidBodyElement = (Element)rigidBodyNode;
/* 162 */           String rigidBodySID = rigidBodyElement.getAttribute("sid");
/* 163 */           if (rigidBodySID != null) {
/* 164 */             logger.debug(new StringBuilder().append("Got rigidBody for sid: ").append(rigidBodySID).toString());
/*     */           }
/* 166 */           NodeList techniqueCommonList = rigidBodyElement.getChildNodes();
/* 167 */           for (int k = 0; k < techniqueCommonList.getLength(); k++) {
/* 168 */             Node techniqueCommonNode = techniqueCommonList.item(k);
/* 169 */             if (techniqueCommonNode.getNodeType() != 1) {
/*     */               continue;
/*     */             }
/* 172 */             NodeList shapeList = ((Element)rigidBodyNode).getElementsByTagName("shape");
/* 173 */             for (int l = 0; l < shapeList.getLength(); l++) {
/* 174 */               Node shapeNode = shapeList.item(l);
/* 175 */               if (shapeNode.getNodeType() != 1) {
/*     */                 continue;
/*     */               }
/* 178 */               rv.add(processShape((Element)shapeNode));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 183 */       return rv;
/*     */     } catch (SAXParseException err) {
/* 185 */       logger.error(new StringBuilder().append("Parsing error, line ").append(err.getLineNumber()).append(", uri ").append(err.getSystemId()).toString());
/* 186 */       logger.error(new StringBuilder().append(" ").append(err.getMessage()).toString());
/*     */     }
/*     */     catch (SAXException e) {
/* 189 */       Exception x = e.getException();
/* 190 */       (x == null ? e : x).printStackTrace();
/*     */     } catch (Throwable t) {
/* 192 */       t.printStackTrace();
/*     */     }
/* 194 */     return null;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.physics.ColladaPhysicsParser
 * JD-Core Version:    0.6.0
 */