/*    */ package atavism.server.physics;
/*    */ 
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.math.Matrix4;
/*    */ 
/*    */ public class TranslateTransform extends AOVector
/*    */   implements Transform
/*    */ {
/*    */   public TranslateTransform()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TranslateTransform(AOVector other)
/*    */   {
/* 10 */     super(other);
/*    */   }
/*    */ 
/*    */   public Matrix4 getTransform() {
/* 14 */     return Matrix4.fromTranslation(this);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.physics.TranslateTransform
 * JD-Core Version:    0.6.0
 */