/*    */ package atavism.server.physics;
/*    */ 
/*    */ import atavism.server.math.Matrix4;
/*    */ import atavism.server.math.Quaternion;
/*    */ 
/*    */ public class RotateTransform extends Quaternion
/*    */   implements Transform
/*    */ {
/*    */   public RotateTransform()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RotateTransform(Quaternion other)
/*    */   {
/* 10 */     super(other);
/*    */   }
/*    */   public Matrix4 getTransform() {
/* 13 */     return Matrix4.fromRotation(this);
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.physics.RotateTransform
 * JD-Core Version:    0.6.0
 */