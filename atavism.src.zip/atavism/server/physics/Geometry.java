package atavism.server.physics;

import atavism.server.math.AOVector;
import atavism.server.math.Plane;
import java.util.List;

public abstract interface Geometry
{
  public abstract List<AOVector> computeIntersection(Plane paramPlane);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.physics.Geometry
 * JD-Core Version:    0.6.0
 */