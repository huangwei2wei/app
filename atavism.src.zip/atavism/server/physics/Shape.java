/*    */ package atavism.server.physics;
/*    */ 
/*    */ import atavism.server.math.AOVector;
/*    */ import atavism.server.math.Matrix4;
/*    */ import atavism.server.math.Plane;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class Shape<T extends Geometry>
/*    */ {
/* 10 */   private static Logger logger = Logger.getLogger(Shape.class);
/*    */   private T geometry;
/*    */   private Matrix4 transform;
/* 17 */   private List<Transform> transformChain = new LinkedList();
/* 18 */   private boolean transformDirty = false;
/*    */ 
/*    */   public void setGeometry(T geom) {
/* 21 */     this.geometry = geom;
/*    */   }
/*    */ 
/*    */   public T getGeometry() {
/* 25 */     return this.geometry;
/*    */   }
/*    */ 
/*    */   public void addTransform(Transform t)
/*    */   {
/* 35 */     this.transformChain.add(t);
/* 36 */     this.transformDirty = true;
/*    */   }
/*    */ 
/*    */   public Matrix4 getTransform() {
/* 40 */     if (this.transformDirty) {
/* 41 */       updateTransform();
/*    */     }
/* 43 */     return this.transform;
/*    */   }
/*    */ 
/*    */   public List<AOVector> computeIntersection(Plane objectSpacePlane) {
/* 47 */     Matrix4 geometryTransform = getTransform();
/* 48 */     Plane geometrySpacePlane = Matrix4.multiply(geometryTransform.getInverse(), objectSpacePlane);
/* 49 */     List points = this.geometry.computeIntersection(geometrySpacePlane);
/* 50 */     List rv = new LinkedList();
/* 51 */     if (logger.isDebugEnabled()) {
/* 52 */       logger.debug(new StringBuilder().append("geometry transform: ").append(geometryTransform.toString()).toString());
/* 53 */       logger.debug(new StringBuilder().append("geometryTransform.getInverse(): ").append(geometryTransform.getInverse().toString()).toString());
/* 54 */       logger.debug(new StringBuilder().append("geometrySpacePlane: ").append(geometrySpacePlane.toString()).toString());
/* 55 */       logger.debug(new StringBuilder().append("objectSpacePlane: ").append(objectSpacePlane.toString()).toString());
/* 56 */       for (int i = 0; i < points.size(); i++) {
/* 57 */         logger.debug(new StringBuilder().append("added geometry transformed point: ").append(Matrix4.multiply(geometryTransform, (AOVector)points.get(i))).toString());
/*    */       }
/*    */     }
/* 60 */     for (int i = 0; i < points.size(); i++) {
/* 61 */       rv.add(Matrix4.multiply(geometryTransform, (AOVector)points.get(i)));
/*    */     }
/* 63 */     return rv;
/*    */   }
/*    */ 
/*    */   private void updateTransform() {
/* 67 */     this.transform = new Matrix4();
/* 68 */     for (int i = 0; i < this.transformChain.size(); i++) {
/* 69 */       Matrix4 entryMatrix = ((Transform)this.transformChain.get(i)).getTransform();
/* 70 */       this.transform = Matrix4.multiply(entryMatrix, this.transform);
/*    */     }
/* 72 */     this.transformDirty = false;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 76 */     StringBuilder sb = new StringBuilder();
/* 77 */     Matrix4 tmp = getTransform();
/* 78 */     sb.append("Transform Chain: ");
/* 79 */     for (int i = 0; i < this.transformChain.size(); i++) {
/* 80 */       Transform t = (Transform)this.transformChain.get(i);
/* 81 */       sb.append("  ");
/* 82 */       sb.append(t);
/*    */     }
/* 84 */     sb.append("Transform: ");
/* 85 */     sb.append(tmp.toString());
/* 86 */     sb.append("\n");
/* 87 */     sb.append("Geometry: ");
/* 88 */     sb.append(this.geometry.toString());
/* 89 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.physics.Shape
 * JD-Core Version:    0.6.0
 */