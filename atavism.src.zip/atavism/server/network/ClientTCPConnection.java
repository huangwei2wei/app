/*     */ package atavism.server.network;
/*     */ 
/*     */ import atavism.msgsys.AgentInfo;
/*     */ import atavism.server.util.DebugUtils;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class ClientTCPConnection extends ClientConnection
/*     */ {
/* 163 */   private ClientConnection.MessageCallback messageCallback = null;
/*     */   private AgentInfo agentInfo;
/* 165 */   private ClientTCPMessageIO clientTCPMessageIO = null;
/* 166 */   private boolean connectionResetCalled = false;
/*     */ 
/*     */   public ClientTCPConnection(ClientTCPMessageIO clientTCPMessageIO)
/*     */   {
/*  12 */     this.clientTCPMessageIO = clientTCPMessageIO;
/*  13 */     this.agentInfo = new AgentInfo();
/*  14 */     this.agentInfo.association = this;
/*     */   }
/*     */ 
/*     */   public ClientTCPConnection(SocketChannel socketChannel) {
/*  18 */     this.agentInfo = new AgentInfo();
/*  19 */     this.agentInfo.association = this;
/*  20 */     initializeFromSocketChannel(socketChannel);
/*     */   }
/*     */ 
/*     */   public ClientTCPConnection(ClientTCPMessageIO clientTCPMessageIO, SocketChannel socketChannel, ClientConnection.MessageCallback messageCallback) {
/*  24 */     this.clientTCPMessageIO = clientTCPMessageIO;
/*  25 */     this.agentInfo = new AgentInfo();
/*  26 */     this.agentInfo.association = this;
/*  27 */     this.messageCallback = messageCallback;
/*  28 */     initializeFromSocketChannel(socketChannel);
/*     */   }
/*     */ 
/*     */   protected void initializeFromSocketChannel(SocketChannel socketChannel) {
/*  32 */     this.agentInfo.socket = socketChannel;
/*  33 */     this.agentInfo.agentId = -1;
/*  34 */     this.agentInfo.agentName = null;
/*  35 */     this.agentInfo.agentIP = null;
/*  36 */     this.agentInfo.agentPort = -1;
/*  37 */     this.agentInfo.outputBuf = new AOByteBuffer(8192);
/*  38 */     this.agentInfo.inputBuf = new AOByteBuffer(8192);
/*     */   }
/*     */ 
/*     */   public String IPAndPort()
/*     */   {
/*  43 */     if (this.agentInfo.socket != null) {
/*  44 */       return "TCP(" + this.agentInfo.socket.socket().getRemoteSocketAddress() + ")";
/*     */     }
/*  46 */     return "TCP(null)";
/*     */   }
/*     */ 
/*     */   public void registerMessageCallback(ClientConnection.MessageCallback messageCallback) {
/*  50 */     this.messageCallback = messageCallback;
/*     */   }
/*     */ 
/*     */   public ClientConnection.MessageCallback getMessageCallback()
/*     */   {
/*  55 */     return this.messageCallback;
/*     */   }
/*     */ 
/*     */   public void send(AOByteBuffer buf) {
/*  59 */     if ((logMessageContents) && (Log.loggingNet)) {
/*  60 */       Log.net("ClientTCPConnection.send: length " + buf.limit() + ", packet " + DebugUtils.byteArrayToHexString(buf));
/*     */     }
/*  62 */     this.lock.lock();
/*     */     try {
/*  64 */       if (PacketAggregator.usePacketAggregators) {
/*  65 */         if ((!this.packetAggregator.addMessage(buf)) && 
/*  66 */           (isOpen())) {
/*  67 */           Log.error("ClientTCPConnection.send: for con " + this + ", PacketAggregator.addMessage returned false!");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  72 */         this.unaggregatedSends += 1L;
/*  73 */         PacketAggregator.allUnaggregatedSends += 1L;
/*  74 */         sendInternal(buf);
/*     */       }
/*     */     }
/*     */     finally {
/*  78 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean sendInternal(AOByteBuffer buf) {
/*  83 */     this.clientTCPMessageIO.addToOutputWithLength(buf, this.agentInfo);
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean sendIfPossible(AOByteBuffer buf) {
/*  88 */     send(buf);
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */   public int sendMultibuf(List<AOByteBuffer> subMessages, int currentSize) {
/*  93 */     AOByteBuffer multiBuf = new AOByteBuffer(currentSize);
/*  94 */     int size = subMessages.size();
/*  95 */     for (AOByteBuffer buf : subMessages)
/*  96 */       multiBuf.putByteBuffer(buf);
/*  97 */     subMessages.clear();
/*  98 */     multiBuf.rewind();
/*  99 */     this.clientTCPMessageIO.addToOutput(multiBuf, this.agentInfo);
/* 100 */     this.aggregatedSends += 1L;
/* 101 */     PacketAggregator.allAggregatedSends += 1L;
/* 102 */     this.sentMessagesAggregated += size;
/* 103 */     PacketAggregator.allSentMessagesAggregated += size;
/* 104 */     if (Log.loggingNet)
/* 105 */       Log.net("ClientTCPConnection.sendMultiBuf: multiBuf size is " + multiBuf.limit());
/* 106 */     return 0;
/*     */   }
/*     */ 
/*     */   public void open(String hostname, int remotePort) {
/*     */     try {
/* 111 */       SocketChannel socket = SocketChannel.open(new InetSocketAddress(hostname, remotePort));
/* 112 */       socket.configureBlocking(false);
/* 113 */       socket.socket().setTcpNoDelay(true);
/* 114 */       initializeFromSocketChannel(socket);
/*     */     }
/*     */     catch (Exception ex) {
/* 117 */       Log.info("Could not connect to host " + hostname + ":" + remotePort + " " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void connectionReset()
/*     */   {
/* 123 */     boolean call = false;
/* 124 */     synchronized (this) {
/* 125 */       if (!this.connectionResetCalled) {
/* 126 */         call = true;
/* 127 */         this.connectionResetCalled = true;
/*     */       }
/*     */     }
/* 130 */     if ((call) && (this.messageCallback != null))
/* 131 */       this.messageCallback.connectionReset(this);
/*     */   }
/*     */ 
/*     */   public void close() {
/* 135 */     if (this.agentInfo.socket != null)
/*     */       try {
/* 137 */         this.agentInfo.socket.close();
/* 138 */         this.clientTCPMessageIO.outputReady();
/* 139 */         connectionReset();
/*     */       } catch (IOException ex) {
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean isOpen() {
/* 145 */     return this.agentInfo.socket != null;
/*     */   }
/*     */ 
/*     */   public boolean canSend() {
/* 149 */     return isOpen();
/*     */   }
/*     */ 
/*     */   public boolean canSendInternal() {
/* 153 */     return true;
/*     */   }
/*     */   public int connectionKind() {
/* 156 */     return 2;
/*     */   }
/*     */ 
/*     */   public AgentInfo getAgentInfo() {
/* 160 */     return this.agentInfo;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.ClientTCPConnection
 * JD-Core Version:    0.6.0
 */