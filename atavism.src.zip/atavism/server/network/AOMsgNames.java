/*    */ package atavism.server.network;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AOMsgNames
/*    */ {
/* 99 */   protected static Map<Integer, String> msgNames = initializeMsgNames();
/*    */ 
/*    */   public static String msgName(int msgType)
/*    */   {
/*  7 */     String s = (String)msgNames.get(Integer.valueOf(msgType));
/*  8 */     if (s == null) {
/*  9 */       return "Unknown Message";
/*    */     }
/* 11 */     return s;
/*    */   }
/*    */ 
/*    */   public static Map<Integer, String> initializeMsgNames() {
/* 15 */     Map names = new HashMap();
/* 16 */     names.put(Integer.valueOf(1), "Login");
/* 17 */     names.put(Integer.valueOf(2), "Direction");
/* 18 */     names.put(Integer.valueOf(3), "Comm");
/* 19 */     names.put(Integer.valueOf(4), "LoginResponse");
/* 20 */     names.put(Integer.valueOf(5), "Logout");
/* 21 */     names.put(Integer.valueOf(6), "OldTerrainConfig");
/* 22 */     names.put(Integer.valueOf(7), "SkyboxMaterial");
/* 23 */     names.put(Integer.valueOf(8), "NewObject");
/* 24 */     names.put(Integer.valueOf(9), "Orientation");
/* 25 */     names.put(Integer.valueOf(10), "FreeObject");
/* 26 */     names.put(Integer.valueOf(11), "Acquire");
/* 27 */     names.put(Integer.valueOf(12), "AcquireResponse");
/* 28 */     names.put(Integer.valueOf(13), "Command");
/* 29 */     names.put(Integer.valueOf(14), "Equip");
/* 30 */     names.put(Integer.valueOf(15), "EquipResponse");
/* 31 */     names.put(Integer.valueOf(16), "Unequip");
/* 32 */     names.put(Integer.valueOf(17), "UnequipResponse");
/* 33 */     names.put(Integer.valueOf(18), "Attach");
/* 34 */     names.put(Integer.valueOf(19), "Detach");
/* 35 */     names.put(Integer.valueOf(20), "Combat");
/* 36 */     names.put(Integer.valueOf(21), "AutoAttack");
/* 37 */     names.put(Integer.valueOf(22), "StatUpdate");
/* 38 */     names.put(Integer.valueOf(23), "Damage");
/* 39 */     names.put(Integer.valueOf(24), "Drop");
/* 40 */     names.put(Integer.valueOf(25), "DropResponse");
/* 41 */     names.put(Integer.valueOf(26), "Animation");
/* 42 */     names.put(Integer.valueOf(27), "Sound");
/* 43 */     names.put(Integer.valueOf(28), "AmbientSound");
/* 44 */     names.put(Integer.valueOf(29), "FollowTerrain");
/* 45 */     names.put(Integer.valueOf(30), "Portal");
/* 46 */     names.put(Integer.valueOf(31), "AmbientLight");
/* 47 */     names.put(Integer.valueOf(32), "NewLight");
/* 48 */     names.put(Integer.valueOf(33), "TradeRequest");
/* 49 */     names.put(Integer.valueOf(34), "TradeEstablished");
/* 50 */     names.put(Integer.valueOf(35), "TradeAccepted");
/* 51 */     names.put(Integer.valueOf(36), "TradeEnded");
/* 52 */     names.put(Integer.valueOf(37), "TradeItem");
/* 53 */     names.put(Integer.valueOf(38), "StateMessage");
/* 54 */     names.put(Integer.valueOf(39), "QuestInfoRequest");
/* 55 */     names.put(Integer.valueOf(40), "QuestInfoResponse");
/* 56 */     names.put(Integer.valueOf(41), "QuestResponse");
/* 57 */     names.put(Integer.valueOf(42), "RegionConfig");
/* 58 */     names.put(Integer.valueOf(43), "InventoryUpdate");
/* 59 */     names.put(Integer.valueOf(44), "QuestLogInfo");
/* 60 */     names.put(Integer.valueOf(45), "QuestStateInfo");
/* 61 */     names.put(Integer.valueOf(46), "RemoveQuestRequest");
/* 62 */     names.put(Integer.valueOf(47), "RemoveQuestResponse");
/* 63 */     names.put(Integer.valueOf(48), "GroupInfo");
/* 64 */     names.put(Integer.valueOf(49), "QuestConcludeRequest");
/* 65 */     names.put(Integer.valueOf(50), "UiTheme");
/* 66 */     names.put(Integer.valueOf(51), "LootAll");
/* 67 */     names.put(Integer.valueOf(52), "OldModelInfo");
/* 68 */     names.put(Integer.valueOf(53), "FragmentMessage");
/* 69 */     names.put(Integer.valueOf(54), "RoadInfo");
/* 70 */     names.put(Integer.valueOf(55), "Fog");
/* 71 */     names.put(Integer.valueOf(56), "AbilityUpdate");
/* 72 */     names.put(Integer.valueOf(57), "AbilityInfo");
/* 73 */     names.put(Integer.valueOf(61), "OldObjectProperty");
/* 74 */     names.put(Integer.valueOf(62), "ObjectProperty");
/* 75 */     names.put(Integer.valueOf(63), "AddParticleEffect");
/* 76 */     names.put(Integer.valueOf(64), "RemoveParticleEffect");
/* 77 */     names.put(Integer.valueOf(65), "ClientParameter");
/* 78 */     names.put(Integer.valueOf(66), "TerrainConfig");
/* 79 */     names.put(Integer.valueOf(67), "TrackObjectInterpolation");
/* 80 */     names.put(Integer.valueOf(68), "TrackLocationInterpolation");
/* 81 */     names.put(Integer.valueOf(69), "FreeRoad");
/* 82 */     names.put(Integer.valueOf(70), "Extension");
/* 83 */     names.put(Integer.valueOf(71), "InvokeEffect");
/* 84 */     names.put(Integer.valueOf(72), "ActivateItem");
/* 85 */     names.put(Integer.valueOf(73), "MobPath");
/* 86 */     names.put(Integer.valueOf(74), "AggregatedRDP");
/* 87 */     names.put(Integer.valueOf(75), "NewDecal");
/* 88 */     names.put(Integer.valueOf(76), "FreeDecal");
/* 89 */     names.put(Integer.valueOf(77), "ModelInfo");
/* 90 */     names.put(Integer.valueOf(78), "SoundControl");
/* 91 */     names.put(Integer.valueOf(79), "DirLocOrient");
/* 92 */     names.put(Integer.valueOf(80), "AuthorizedLogin");
/* 93 */     names.put(Integer.valueOf(81), "AuthorizedLoginResponse");
/* 94 */     names.put(Integer.valueOf(85), "WorldFileName");
/* 95 */     names.put(Integer.valueOf(86), "IslandManifest");
/* 96 */     return names;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.AOMsgNames
 * JD-Core Version:    0.6.0
 */