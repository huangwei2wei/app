package atavism.server.network;

public abstract interface ClientSerializable
{
  public abstract void encodeObject(AOByteBuffer paramAOByteBuffer);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.ClientSerializable
 * JD-Core Version:    0.6.0
 */