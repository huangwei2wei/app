/*     */ package atavism.server.network;
/*     */ 
/*     */ import atavism.server.engine.Engine;
/*     */ import atavism.server.network.rdp.RDPConnection;
/*     */ import atavism.server.plugins.ProxyPlugin;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class PacketAggregator
/*     */ {
/* 184 */   static Thread sendAggregatorThread = new Thread(new SendAggregatorThread(), "Aggregator");
/* 185 */   static boolean sendAggregatorThreadStarted = false;
/*     */ 
/* 191 */   static ClientConnection[] aggregatedConnections = null;
/* 192 */   static ClientConnection[] tempAggregatedConnections = null;
/* 193 */   static ClientConnection[] failedAggregatedConnections = null;
/* 194 */   static int aggregatedConnectionsSize = 0;
/* 195 */   static int aggregatedConnectionsUsed = 0;
/*     */   static final int agggregatedConnectionsIncrement = 25;
/* 197 */   static Lock aggregatedConnectionsLock = LockFactory.makeLock("StaticPacketAggregatedConnectionLock");
/*     */ 
/* 203 */   public static int packetAggregationInterval = 0;
/*     */ 
/* 366 */   public static long allAggregatedSends = 0L;
/* 367 */   public static long allSentMessagesAggregated = 0L;
/* 368 */   public static long allUnaggregatedSends = 0L;
/*     */ 
/* 370 */   public static long allAggregatedReceives = 0L;
/* 371 */   public static long allReceivedMessagesAggregated = 0L;
/* 372 */   public static long allUnaggregatedReceives = 0L;
/*     */   protected ClientConnection con;
/*     */   protected int currentSize;
/*     */   protected List<AOByteBuffer> subMessages;
/* 377 */   protected Long earliestAddTime = null;
/*     */ 
/* 380 */   public static boolean usePacketAggregators = false;
/*     */ 
/* 383 */   public static long packetAggregatorSleeps = 0L;
/* 384 */   public static long packetAggregatorNoSleeps = 0L;
/*     */ 
/*     */   public PacketAggregator(ClientConnection con)
/*     */   {
/*  28 */     this.con = con;
/*  29 */     this.currentSize = 0;
/*  30 */     this.subMessages = new LinkedList();
/*     */   }
/*     */ 
/*     */   public static void initializeAggregation(Properties properties) {
/*  34 */     String intervalString = properties.getProperty("atavism.packet_aggregation_interval");
/*  35 */     int interval = 10;
/*  36 */     if (intervalString != null)
/*     */       try {
/*  38 */         interval = Integer.parseInt(intervalString.trim());
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*  43 */     packetAggregationInterval = interval;
/*  44 */     if (packetAggregationInterval > 0) {
/*  45 */       Log.info("Starting Packet Aggregator thread with an aggregation interval of " + packetAggregationInterval);
/*  46 */       sendAggregatorThread.start();
/*  47 */       sendAggregatorThreadStarted = true;
/*  48 */       usePacketAggregators = true;
/*     */     }
/*     */     else {
/*  51 */       Log.info("Packet aggregator will not run, because atavism.packet_aggregation_interval is 0");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean addMessage(AOByteBuffer msg)
/*     */   {
/*  61 */     int msgSize = msg.limit();
/*     */ 
/*  63 */     if ((this.currentSize + msgSize > ProxyPlugin.maxByteCountBeforeConnectionReset) || (this.subMessages.size() + 1 > ProxyPlugin.maxMessagesBeforeConnectionReset))
/*     */     {
/*  65 */       Log.error("PacketAggregator: Resetting client connection " + this.con + " because there are " + (this.currentSize + msgSize) + " message bytes and " + (this.subMessages.size() + 1) + " messages queued to send");
/*     */ 
/*  67 */       this.con.connectionReset();
/*  68 */       this.subMessages.clear();
/*  69 */       this.currentSize = 0;
/*  70 */       return true;
/*     */     }
/*  72 */     if (Log.loggingNet) {
/*  73 */       Log.net("PacketAggregator.addMessage: adding buf of size " + (msgSize + 4) + ", frag " + RDPConnection.fragmentedBuffer(msg) + ", subMsg cnt " + this.subMessages.size() + ", currentSize " + this.currentSize);
/*     */     }
/*     */ 
/*  76 */     if (this.currentSize + msgSize + 4 + 16 >= Engine.MAX_NETWORK_BUF_SIZE) {
/*  77 */       if (!send()) {
/*  78 */         this.subMessages.add(msg);
/*  79 */         int addend = msg.limit() + 4;
/*  80 */         this.currentSize += addend;
/*  81 */         if (Log.loggingNet) {
/*  82 */           Log.net("PacketAggregator.addMessage: added buf of size " + addend + ", subMsg cnt " + this.subMessages.size() + ", currentSize " + this.currentSize);
/*     */         }
/*  84 */         return false;
/*     */       }
/*  86 */       if (msgSize >= Engine.MAX_NETWORK_BUF_SIZE) {
/*  87 */         this.con.unaggregatedSends += 1L;
/*  88 */         allUnaggregatedSends += 1L;
/*  89 */         return this.con.sendInternal(msg);
/*     */       }
/*     */     }
/*  92 */     if (this.subMessages.size() == 0)
/*  93 */       this.earliestAddTime = Long.valueOf(System.currentTimeMillis());
/*  94 */     int oldCurrentSize = this.currentSize;
/*  95 */     int addend = msgSize + 4;
/*  96 */     this.currentSize += addend;
/*  97 */     this.subMessages.add(msg);
/*  98 */     if (Log.loggingNet) {
/*  99 */       Log.net("PacketAggregator.addMessage: added buf of size " + addend + ", frag " + RDPConnection.fragmentedBuffer(msg) + ", subMsg cnt " + this.subMessages.size() + ", currentSize " + this.currentSize);
/*     */     }
/*     */ 
/* 102 */     if (oldCurrentSize == 0) {
/* 103 */       addAggregatedConnection(this.con);
/*     */     }
/*     */ 
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean addMessageList(List<AOByteBuffer> bufs)
/*     */   {
/* 116 */     boolean rv = true;
/* 117 */     for (AOByteBuffer buf : bufs) {
/* 118 */       if ((!addMessage(buf)) && (rv))
/* 119 */         rv = false;
/*     */     }
/* 121 */     return rv;
/*     */   }
/*     */ 
/*     */   public boolean sendContentsIfOld() {
/* 125 */     if (this.earliestAddTime == null)
/*     */     {
/* 127 */       return true;
/* 128 */     }if (System.currentTimeMillis() - this.earliestAddTime.longValue() >= packetAggregationInterval)
/*     */     {
/* 130 */       if (Log.loggingNet)
/* 131 */         Log.net("PacketAggregator.sendContentsIfOld: sending " + this.subMessages.size() + " messages");
/* 132 */       return send();
/*     */     }
/*     */ 
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean send()
/*     */   {
/* 143 */     this.con.getLock().lock();
/*     */     try {
/* 145 */       int cnt = this.subMessages.size();
/* 146 */       boolean rv = false;
/* 147 */       if (Log.loggingNet)
/* 148 */         Log.net("PacketAggregator.send: count of subMessages is " + cnt + ", total bytes " + this.currentSize);
/* 149 */       if (cnt == 0) {
/* 150 */         bool1 = true;
/*     */         return bool1;
/*     */       }
/* 151 */       if (cnt == 1) {
/* 152 */         rv = this.con.sendInternal((AOByteBuffer)this.subMessages.get(0));
/* 153 */         if (rv) {
/* 154 */           this.con.unaggregatedSends += 1L;
/* 155 */           allUnaggregatedSends += 1L;
/* 156 */           this.currentSize = 0;
/* 157 */           this.subMessages.clear();
/*     */         }
/*     */       }
/*     */       else {
/* 161 */         while ((this.con.canSend()) && (this.currentSize > 0))
/* 162 */           this.currentSize = this.con.sendMultibuf(this.subMessages, this.currentSize);
/* 163 */         rv = this.currentSize == 0;
/*     */       }
/* 165 */       if (rv) {
/* 166 */         this.earliestAddTime = null;
/*     */       }
/* 168 */       else if (Log.loggingNet)
/* 169 */         Log.net("PacketAggregator.send: rv is false; currentSize " + this.currentSize + ", subbuf cnt " + cnt);
/* 170 */       boolean bool1 = rv;
/*     */       return bool1; } finally { this.con.getLock().unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public Long getEarliestAddTime()
/*     */   {
/* 178 */     return this.earliestAddTime;
/*     */   }
/*     */ 
/*     */   public static void addAggregatedConnection(ClientConnection con)
/*     */   {
/* 209 */     aggregatedConnectionsLock.lock();
/*     */     try {
/* 211 */       addAggregatedConnectionInternal(con);
/*     */     }
/*     */     finally {
/* 214 */       aggregatedConnectionsLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void addAggregatedConnectionInternal(ClientConnection con)
/*     */   {
/* 222 */     if (aggregatedConnections == null) {
/* 223 */       aggregatedConnections = new ClientConnection[25];
/* 224 */       tempAggregatedConnections = new ClientConnection[25];
/* 225 */       failedAggregatedConnections = new ClientConnection[25];
/* 226 */       aggregatedConnectionsUsed = 0;
/* 227 */       aggregatedConnectionsSize = 25;
/*     */     }
/* 229 */     else if (aggregatedConnectionsUsed == aggregatedConnectionsSize) {
/* 230 */       aggregatedConnectionsSize += 25;
/* 231 */       ClientConnection[] newAggregatedConnections = new ClientConnection[aggregatedConnectionsSize];
/* 232 */       for (int i = 0; i < aggregatedConnectionsUsed; i++)
/* 233 */         newAggregatedConnections[i] = aggregatedConnections[i];
/* 234 */       aggregatedConnections = newAggregatedConnections;
/* 235 */       tempAggregatedConnections = new ClientConnection[aggregatedConnectionsSize];
/* 236 */       failedAggregatedConnections = new ClientConnection[aggregatedConnectionsSize];
/*     */     }
/* 238 */     aggregatedConnections[(aggregatedConnectionsUsed++)] = con;
/*     */   }
/*     */ 
/*     */   static class AggregatorStatsThread
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/* 323 */       long lastAggregatedSends = 0L;
/* 324 */       long lastUnaggregatedSends = 0L;
/* 325 */       long lastSentMessagesAggregated = 0L;
/* 326 */       long lastAggregatedReceives = 0L;
/* 327 */       long lastUnaggregatedReceives = 0L;
/* 328 */       long lastReceivedMessagesAggregated = 0L;
/* 329 */       long lastCounterTime = System.currentTimeMillis();
/*     */       while (true) {
/* 331 */         long startTime = System.currentTimeMillis();
/* 332 */         long interval = startTime - lastCounterTime;
/* 333 */         if (interval > 1000L) {
/* 334 */           long newAggregatedSends = PacketAggregator.allAggregatedSends - lastAggregatedSends;
/* 335 */           long newUnaggregatedSends = PacketAggregator.allUnaggregatedSends - lastUnaggregatedSends;
/* 336 */           long newSentMessagesAggregated = PacketAggregator.allSentMessagesAggregated - lastSentMessagesAggregated;
/* 337 */           long newAggregatedReceives = PacketAggregator.allAggregatedReceives - lastAggregatedReceives;
/* 338 */           long newUnaggregatedReceives = PacketAggregator.allUnaggregatedReceives - lastUnaggregatedReceives;
/* 339 */           long newReceivedMessagesAggregated = PacketAggregator.allReceivedMessagesAggregated - lastReceivedMessagesAggregated;
/*     */ 
/* 341 */           if (Log.loggingDebug) {
/* 342 */             Log.debug("PacketAggregator counters: unaggregatedSends " + newUnaggregatedSends + ", aggregatedSends " + newAggregatedSends + ", sentMessagesAggregated " + newSentMessagesAggregated);
/*     */ 
/* 344 */             Log.debug("PacketAggregator counters: unaggregatedReceives " + newUnaggregatedReceives + ", aggregatedReceives " + newAggregatedReceives + ", receivedMessagesAggregated " + newReceivedMessagesAggregated);
/*     */           }
/*     */ 
/* 349 */           lastAggregatedSends = PacketAggregator.allAggregatedSends;
/* 350 */           lastUnaggregatedSends = PacketAggregator.allUnaggregatedSends;
/* 351 */           lastSentMessagesAggregated = PacketAggregator.allSentMessagesAggregated;
/* 352 */           lastAggregatedReceives = PacketAggregator.allAggregatedReceives;
/* 353 */           lastUnaggregatedReceives = PacketAggregator.allUnaggregatedReceives;
/* 354 */           lastReceivedMessagesAggregated = PacketAggregator.allReceivedMessagesAggregated;
/* 355 */           lastCounterTime = startTime;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class SendAggregatorThread
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/*     */       while (true)
/*     */         try
/*     */         {
/* 253 */           long startTime = System.currentTimeMillis();
/* 254 */           int tempCount = 0;
/* 255 */           ClientConnection[] currentTempAggregatedConnections = null;
/* 256 */           PacketAggregator.aggregatedConnectionsLock.lock();
/*     */           try {
/* 258 */             currentTempAggregatedConnections = PacketAggregator.tempAggregatedConnections;
/* 259 */             tempCount = PacketAggregator.aggregatedConnectionsUsed;
/* 260 */             int i = 0; if (i < tempCount) {
/* 261 */               currentTempAggregatedConnections[i] = PacketAggregator.aggregatedConnections[i];
/* 262 */               PacketAggregator.aggregatedConnections[i] = null;
/*     */ 
/* 260 */               i++; continue;
/*     */             }
/*     */ 
/* 264 */             PacketAggregator.aggregatedConnectionsUsed = 0;
/*     */           }
/*     */           finally {
/* 267 */             PacketAggregator.aggregatedConnectionsLock.unlock();
/*     */           }
/*     */ 
/* 270 */           int failedCount = 0;
/* 271 */           ClientConnection[] currentFailedAggregatedConnections = PacketAggregator.failedAggregatedConnections;
/* 272 */           int i = 0; if (i < tempCount) {
/* 273 */             ClientConnection con = currentTempAggregatedConnections[i];
/* 274 */             currentTempAggregatedConnections[i] = null;
/* 275 */             if ((con == null) || (con.getLock() == null))
/*     */               continue;
/* 277 */             con.getLock().lock();
/*     */             try
/*     */             {
/* 280 */               if ((con.isOpen()) && (con.canSendInternal()))
/*     */               {
/*     */                 continue;
/*     */               }
/*     */ 
/* 286 */               con.getLock().unlock(); continue;
/*     */ 
/* 282 */               if (!con.packetAggregator.sendContentsIfOld())
/* 283 */                 currentFailedAggregatedConnections[(failedCount++)] = con;
/*     */             }
/*     */             finally {
/* 286 */               con.getLock().unlock();
/*     */             }
/* 272 */             i++; continue;
/*     */           }
/*     */ 
/* 289 */           if (failedCount != 0) {
/* 290 */             PacketAggregator.aggregatedConnectionsLock.lock();
/*     */             try {
/* 292 */               int i = 0; if (i < failedCount) {
/* 293 */                 ClientConnection con = currentFailedAggregatedConnections[i];
/* 294 */                 PacketAggregator.addAggregatedConnectionInternal(con);
/* 295 */                 currentFailedAggregatedConnections[i] = null;
/*     */ 
/* 292 */                 i++; continue;
/*     */               }
/*     */ 
/*     */             }
/*     */             finally
/*     */             {
/* 299 */               PacketAggregator.aggregatedConnectionsLock.unlock();
/*     */             }
/*     */           }
/* 302 */           long now = System.currentTimeMillis();
/* 303 */           long sleepTime = Math.max(0L, PacketAggregator.packetAggregationInterval - Math.max(0L, now - startTime));
/*     */ 
/* 305 */           if (sleepTime > 0L) {
/* 306 */             PacketAggregator.packetAggregatorSleeps += 1L;
/* 307 */             Thread.sleep(sleepTime);
/*     */           }
/*     */           else {
/* 310 */             PacketAggregator.packetAggregatorNoSleeps += 1L;
/*     */           }
/*     */ 
/* 313 */           continue;
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 312 */           Log.exception("PacketAggregator.SendAggregatorThread.run caught exception", e);
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.PacketAggregator
 * JD-Core Version:    0.6.0
 */