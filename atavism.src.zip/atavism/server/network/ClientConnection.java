/*     */ package atavism.server.network;
/*     */ 
/*     */ import atavism.server.util.LockFactory;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public abstract class ClientConnection
/*     */ {
/*     */   private Object association;
/*  88 */   protected PacketAggregator packetAggregator = null;
/*     */ 
/*  93 */   public long aggregatedSends = 0L;
/*  94 */   public long sentMessagesAggregated = 0L;
/*  95 */   public long unaggregatedSends = 0L;
/*     */ 
/*  97 */   public long aggregatedReceives = 0L;
/*  98 */   public long receivedMessagesAggregated = 0L;
/*  99 */   public long unaggregatedReceives = 0L;
/*     */   public static final int connectionTypeRDP = 1;
/*     */   public static final int connectionTypeTCP = 2;
/*     */   public static final int connectionTypeUDP = 2;
/* 108 */   protected static boolean logMessageContents = false;
/*     */ 
/* 110 */   protected transient Lock lock = LockFactory.makeLock("BasicConnectionLock");
/*     */ 
/*     */   public ClientConnection()
/*     */   {
/*  10 */     if (PacketAggregator.usePacketAggregators)
/*  11 */       this.packetAggregator = new PacketAggregator(this);  } 
/*     */   public abstract void registerMessageCallback(MessageCallback paramMessageCallback);
/*     */ 
/*     */   public abstract void connectionReset();
/*     */ 
/*     */   public abstract void send(AOByteBuffer paramAOByteBuffer);
/*     */ 
/*     */   public abstract boolean sendInternal(AOByteBuffer paramAOByteBuffer);
/*     */ 
/*     */   public abstract boolean sendIfPossible(AOByteBuffer paramAOByteBuffer);
/*     */ 
/*     */   public abstract int sendMultibuf(List<AOByteBuffer> paramList, int paramInt);
/*     */ 
/*     */   public abstract void open(String paramString, int paramInt);
/*     */ 
/*     */   public abstract void close();
/*     */ 
/*     */   public abstract int connectionKind();
/*     */ 
/*     */   public abstract boolean isOpen();
/*     */ 
/*     */   public abstract boolean canSend();
/*     */ 
/*     */   public abstract boolean canSendInternal();
/*     */ 
/*     */   public abstract String IPAndPort();
/*     */ 
/*  47 */   public Object getAssociation() { return this.association;
/*     */   }
/*     */ 
/*     */   public void setAssociation(Object object)
/*     */   {
/*  52 */     this.association = object;
/*     */   }
/*     */ 
/*     */   public Lock getLock() {
/*  56 */     return this.lock;
/*     */   }
/*     */ 
/*     */   public PacketAggregator getAggregator() {
/*  60 */     return this.packetAggregator;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  76 */     return IPAndPort();
/*     */   }
/*     */ 
/*     */   public static boolean getLogMessageContents() {
/*  80 */     return logMessageContents;
/*     */   }
/*     */ 
/*     */   public static void setLogMessageContents(boolean logMessageContents) {
/*  84 */     logMessageContents = logMessageContents;
/*     */   }
/*     */ 
/*     */   public static abstract interface AcceptCallback
/*     */   {
/*     */     public abstract void acceptConnection(ClientConnection paramClientConnection);
/*     */   }
/*     */ 
/*     */   public static abstract interface MessageCallback
/*     */   {
/*     */     public abstract void processPacket(ClientConnection paramClientConnection, AOByteBuffer paramAOByteBuffer);
/*     */ 
/*     */     public abstract void connectionReset(ClientConnection paramClientConnection);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.ClientConnection
 * JD-Core Version:    0.6.0
 */