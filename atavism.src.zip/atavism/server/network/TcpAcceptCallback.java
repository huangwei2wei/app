package atavism.server.network;

import java.nio.channels.SocketChannel;

public abstract interface TcpAcceptCallback
{
  public abstract void onTcpAccept(SocketChannel paramSocketChannel);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.TcpAcceptCallback
 * JD-Core Version:    0.6.0
 */