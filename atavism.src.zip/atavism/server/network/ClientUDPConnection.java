/*     */ package atavism.server.network;
/*     */ 
/*     */ import atavism.server.util.AORuntimeException;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.channels.DatagramChannel;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class ClientUDPConnection extends ClientConnection
/*     */ {
/* 144 */   public static byte opcodeAggregatedVoicePacket = 7;
/*     */ 
/* 146 */   protected ClientConnection.MessageCallback messageCallback = null;
/* 147 */   protected static Map<Integer, DatagramChannel> channelMap = new HashMap();
/*     */   protected String remoteAddr;
/*     */   protected Integer remotePort;
/* 150 */   protected DatagramChannel socket = null;
/*     */ 
/*     */   public ClientUDPConnection(DatagramChannel datagramChannel)
/*     */   {
/*  11 */     initializeFromDatagramChannel(datagramChannel);
/*     */   }
/*     */ 
/*     */   public ClientUDPConnection(DatagramChannel dc, ClientConnection.MessageCallback messageCallback) {
/*  15 */     this.messageCallback = messageCallback;
/*  16 */     initializeFromDatagramChannel(dc);
/*     */   }
/*     */ 
/*     */   protected void initializeFromDatagramChannel(DatagramChannel datagramChannel) {
/*  20 */     this.socket = datagramChannel;
/*     */   }
/*     */ 
/*     */   public String IPAndPort()
/*     */   {
/*  25 */     return "UDP(" + this.remoteAddr + ":" + this.remotePort + ")";
/*     */   }
/*     */ 
/*     */   public void registerMessageCallback(ClientConnection.MessageCallback messageCallback) {
/*  29 */     this.messageCallback = messageCallback;
/*     */   }
/*     */ 
/*     */   public void send(AOByteBuffer buf) {
/*  33 */     this.lock.lock();
/*     */     try {
/*  35 */       if (PacketAggregator.usePacketAggregators) {
/*  36 */         if ((!this.packetAggregator.addMessage(buf)) && 
/*  37 */           (isOpen())) {
/*  38 */           Log.error("ClientUDPConnection.send: for con " + this + ", PacketAggregator.addMessage returned false!");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  43 */         this.unaggregatedSends += 1L;
/*  44 */         PacketAggregator.allUnaggregatedSends += 1L;
/*  45 */         sendInternal(buf);
/*     */       }
/*     */     }
/*     */     finally {
/*  49 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean sendInternal(AOByteBuffer buf) {
/*  54 */     DatagramChannel dc = (DatagramChannel)channelMap.get(this.remotePort);
/*  55 */     if (dc != null)
/*  56 */       Log.error("ClientUDPConnection.sendInternal: Could not find DatagramChannel for remote port " + this.remotePort);
/*     */     try
/*     */     {
/*  59 */       int bytes = dc.send(buf.getNioBuf(), new InetSocketAddress(this.remoteAddr, this.remotePort.intValue()));
/*     */ 
/*  62 */       if (Log.loggingNet)
/*  63 */         Log.net("ClientUDPConnection.sendPacket: remoteAddr=" + this.remoteAddr + ", remotePort=" + this.remotePort + ", numbytes sent=" + bytes);
/*     */     } catch (IOException e) {
/*  65 */       Log.exception("ClientUDPConnection.sendPacket: remoteAddr=" + this.remoteAddr + ", remotePort=" + this.remotePort + ", got exception", e);
/*  66 */       throw new AORuntimeException("ClientUDPConnection.sendPacket", e);
/*     */     }
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean sendIfPossible(AOByteBuffer buf) {
/*  72 */     send(buf);
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */   public int sendMultibuf(List<AOByteBuffer> subMessages, int currentSize) {
/*  77 */     int byteCount = 1;
/*  78 */     for (AOByteBuffer buf : subMessages) {
/*  79 */       int bufSize = buf.limit();
/*  80 */       if (bufSize > 255)
/*     */       {
/*  82 */         Log.error("ClientUDPConnection.sendMultibuf: Buf size is " + bufSize);
/*     */       }
/*     */       else
/*  85 */         byteCount += 1 + bufSize;
/*     */     }
/*  87 */     AOByteBuffer multiBuf = new AOByteBuffer(byteCount);
/*  88 */     multiBuf.putByte(opcodeAggregatedVoicePacket);
/*  89 */     for (AOByteBuffer buf : subMessages) {
/*  90 */       int bufSize = buf.limit();
/*  91 */       if (bufSize <= 255) {
/*  92 */         multiBuf.putByte((byte)bufSize);
/*  93 */         multiBuf.putBytes(buf.array(), 0, bufSize);
/*     */       }
/*     */     }
/*  96 */     subMessages.clear();
/*  97 */     multiBuf.rewind();
/*  98 */     this.aggregatedSends += 1L;
/*  99 */     PacketAggregator.allAggregatedSends += 1L;
/* 100 */     this.sentMessagesAggregated += byteCount;
/* 101 */     PacketAggregator.allSentMessagesAggregated += byteCount;
/* 102 */     if (Log.loggingNet)
/* 103 */       Log.net("ClientUDPConnection.sendMultiBuf: multiBuf size is " + multiBuf.limit());
/* 104 */     return 0;
/*     */   }
/*     */ 
/*     */   public void open(String hostname, int remotePort) {
/* 108 */     Log.error("ClientUDPConnection: open(" + hostname + ":" + remotePort + " called; should never happen");
/*     */   }
/*     */ 
/*     */   public void connectionReset()
/*     */   {
/* 113 */     if (this.messageCallback != null) {
/* 114 */       this.messageCallback.connectionReset(this);
/* 115 */       this.socket = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close() {
/* 120 */     if (this.socket != null)
/*     */       try {
/* 122 */         this.socket.close();
/* 123 */         this.socket = null;
/*     */       } catch (IOException ex) {
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean isOpen() {
/* 129 */     return this.socket != null;
/*     */   }
/*     */ 
/*     */   public boolean canSend() {
/* 133 */     return isOpen();
/*     */   }
/*     */ 
/*     */   public boolean canSendInternal() {
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   public int connectionKind() {
/* 141 */     return 2;
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.ClientUDPConnection
 * JD-Core Version:    0.6.0
 */