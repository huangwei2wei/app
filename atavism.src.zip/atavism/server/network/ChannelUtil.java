/*    */ package atavism.server.network;
/*    */ 
/*    */ import atavism.server.util.Log;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.Selector;
/*    */ import java.nio.channels.SocketChannel;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class ChannelUtil
/*    */ {
/*    */   public static final int TIMEOUT = 30000;
/*    */ 
/*    */   public static int fillBuffer(ByteBuffer buffer, SocketChannel socket)
/*    */     throws IOException
/*    */   {
/* 15 */     Selector selector = null;
/*    */     try {
/* 17 */       selector = Selector.open();
/* 18 */       socket.register(selector, 1);
/* 19 */       while (buffer.remaining() > 0) {
/* 20 */         int nReady = selector.select(30000L);
/* 21 */         if (nReady == 1) {
/* 22 */           selector.selectedKeys().clear();
/* 23 */           int nBytes = socket.read(buffer);
/* 24 */           if (nBytes == -1)
/*    */             break;
/*    */         }
/*    */         else {
/* 28 */           Log.debug("Connection timeout while reading");
/* 29 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */     finally {
/* 34 */       selector.close();
/*    */     }
/* 36 */     buffer.flip();
/* 37 */     return buffer.limit();
/*    */   }
/*    */ 
/*    */   public static boolean writeBuffer(AOByteBuffer buffer, SocketChannel socket)
/*    */     throws IOException
/*    */   {
/* 43 */     Selector selector = null;
/*    */     try {
/* 45 */       selector = Selector.open();
/* 46 */       socket.register(selector, 4);
/* 47 */       while (buffer.hasRemaining()) {
/* 48 */         int nReady = selector.select(30000L);
/* 49 */         if (nReady == 1) {
/* 50 */           selector.selectedKeys().clear();
/* 51 */           if (socket.write(buffer.getNioBuf()) == 0)
/* 52 */             break;
/*    */         }
/*    */         else {
/* 55 */           Log.debug("Connection timeout while writing");
/* 56 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */     finally {
/* 61 */       selector.close();
/*    */     }
/* 63 */     return !buffer.hasRemaining();
/*    */   }
/*    */ 
/*    */   public static void patchLengthAndFlip(AOByteBuffer messageBuf)
/*    */   {
/* 68 */     int len = messageBuf.position();
/* 69 */     messageBuf.getNioBuf().rewind();
/* 70 */     messageBuf.putInt(len - 4);
/* 71 */     messageBuf.position(len);
/* 72 */     messageBuf.getNioBuf().flip();
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.ChannelUtil
 * JD-Core Version:    0.6.0
 */