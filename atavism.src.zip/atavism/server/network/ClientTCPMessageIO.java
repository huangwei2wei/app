/*     */ package atavism.server.network;
/*     */ 
/*     */ import atavism.msgsys.AgentInfo;
/*     */ import atavism.msgsys.MessageIO;
/*     */ import atavism.msgsys.MessageIO.Callback;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.nio.channels.SocketChannel;
/*     */ 
/*     */ public class ClientTCPMessageIO extends MessageIO
/*     */   implements TcpAcceptCallback, MessageIO.Callback
/*     */ {
/*     */   private ClientConnection.MessageCallback messageCallback;
/*     */   private ClientConnection.AcceptCallback acceptCallback;
/* 146 */   private TcpServer listener = null;
/*     */ 
/*     */   protected ClientTCPMessageIO()
/*     */   {
/*  14 */     initialize(this);
/*     */   }
/*     */ 
/*     */   protected ClientTCPMessageIO(int messageLengthByteCount)
/*     */   {
/*  19 */     super(messageLengthByteCount);
/*  20 */     initialize(this);
/*     */   }
/*     */ 
/*     */   protected ClientTCPMessageIO(InetSocketAddress bindAddress, ClientConnection.MessageCallback messageCallback, ClientConnection.AcceptCallback acceptCallback)
/*     */   {
/*  26 */     this.messageCallback = messageCallback;
/*  27 */     this.acceptCallback = acceptCallback;
/*  28 */     initialize(this);
/*  29 */     if (bindAddress != null)
/*  30 */       startListener(bindAddress);
/*     */   }
/*     */ 
/*     */   protected ClientTCPMessageIO(int messageLengthByteCount, InetSocketAddress bindAddress, ClientConnection.MessageCallback messageCallback, ClientConnection.AcceptCallback acceptCallback)
/*     */   {
/*  36 */     super(messageLengthByteCount);
/*  37 */     this.messageCallback = messageCallback;
/*  38 */     this.acceptCallback = acceptCallback;
/*  39 */     initialize(this);
/*  40 */     if (bindAddress != null)
/*  41 */       startListener(bindAddress);
/*     */   }
/*     */ 
/*     */   public static ClientTCPMessageIO setup() {
/*  45 */     return new ClientTCPMessageIO();
/*     */   }
/*     */ 
/*     */   public static ClientTCPMessageIO setup(InetSocketAddress bindAddress, ClientConnection.MessageCallback messageCallback, ClientConnection.AcceptCallback acceptCallback)
/*     */   {
/*  52 */     return new ClientTCPMessageIO(bindAddress, messageCallback, acceptCallback);
/*     */   }
/*     */ 
/*     */   public static ClientTCPMessageIO setup(int messageLengthByteCount, InetSocketAddress bindAddress, ClientConnection.MessageCallback messageCallback, ClientConnection.AcceptCallback acceptCallback)
/*     */   {
/*  60 */     return new ClientTCPMessageIO(messageLengthByteCount, bindAddress, messageCallback, acceptCallback);
/*     */   }
/*     */ 
/*     */   public static ClientTCPMessageIO setup(Integer port, ClientConnection.MessageCallback messageCallback)
/*     */   {
/*  65 */     return setup(new InetSocketAddress(port.intValue()), messageCallback, null);
/*     */   }
/*     */ 
/*     */   public static ClientTCPMessageIO setup(Integer port, ClientConnection.MessageCallback messageCallback, ClientConnection.AcceptCallback acceptCallback)
/*     */   {
/*  72 */     return setup(new InetSocketAddress(port.intValue()), messageCallback, acceptCallback);
/*     */   }
/*     */ 
/*     */   public static ClientTCPMessageIO setup(int messageLengthByteCount, Integer port, ClientConnection.MessageCallback messageCallback, ClientConnection.AcceptCallback acceptCallback)
/*     */   {
/*  80 */     return setup(messageLengthByteCount, new InetSocketAddress(port.intValue()), messageCallback, acceptCallback);
/*     */   }
/*     */ 
/*     */   public void handleMessageData(int length, AOByteBuffer buf, AgentInfo agentInfo) {
/*  84 */     ClientTCPConnection con = (ClientTCPConnection)(ClientTCPConnection)agentInfo.association;
/*  85 */     if ((length == -1) || (buf == null)) {
/*  86 */       con.connectionReset();
/*  87 */       return;
/*     */     }
/*     */ 
/*  91 */     AOByteBuffer packet = buf.cloneAtOffset(0, length);
/*     */ 
/*  94 */     if (con.getMessageCallback() != null)
/*  95 */       con.getMessageCallback().processPacket(con, packet);
/*     */   }
/*     */ 
/*     */   protected void startListener(InetSocketAddress bindAddress)
/*     */   {
/*     */     try {
/* 101 */       openListener(bindAddress);
/* 102 */       this.listener.start();
/*     */     }
/*     */     catch (Exception e) {
/* 105 */       Log.exception("Could not bind ClientTCPMessageIO to: " + bindAddress, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getListenerPort() {
/* 110 */     return this.listener.getPort();
/*     */   }
/*     */ 
/*     */   public void openListener(InetSocketAddress bindAddress) throws IOException {
/* 114 */     if (this.listener != null) {
/* 115 */       return;
/*     */     }
/* 117 */     this.listener = new TcpServer();
/* 118 */     this.listener.bind(bindAddress);
/* 119 */     this.listener.registerAcceptCallback(this);
/*     */   }
/*     */ 
/*     */   public void onTcpAccept(SocketChannel agentSocket)
/*     */   {
/*     */     try
/*     */     {
/* 127 */       agentSocket.socket().setTcpNoDelay(true);
/* 128 */       agentSocket.configureBlocking(false);
/* 129 */       ClientTCPConnection con = new ClientTCPConnection(this, agentSocket, this.messageCallback);
/* 130 */       if (this.acceptCallback != null)
/* 131 */         this.acceptCallback.acceptConnection(con);
/* 132 */       addAgent(con.getAgentInfo());
/*     */     } catch (IOException ex) {
/* 134 */       Log.exception("Agent listener", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void acceptConnection(ClientConnection con)
/*     */   {
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.ClientTCPMessageIO
 * JD-Core Version:    0.6.0
 */