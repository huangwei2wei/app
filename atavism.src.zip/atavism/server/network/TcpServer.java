/*     */ package atavism.server.network;
/*     */ 
/*     */ import atavism.server.util.Log;
/*     */ import atavism.server.util.Logger;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ 
/*     */ public class TcpServer
/*     */ {
/* 110 */   protected TcpAcceptCallback acceptCallback = null;
/* 111 */   protected ServerSocketChannel ssChannel = null;
/*     */   protected Thread thread;
/* 113 */   protected static final Logger log = new Logger("TcpServer");
/*     */ 
/*     */   public TcpServer()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TcpServer(int port)
/*     */   {
/*     */     try
/*     */     {
/*  19 */       bind(port);
/*     */     }
/*     */     catch (IOException e) {
/*  22 */       throw new RuntimeException("TcpServer contructor bind failed", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void bind()
/*     */     throws IOException
/*     */   {
/*  30 */     bind(0);
/*     */   }
/*     */ 
/*     */   public void bind(int port)
/*     */     throws IOException
/*     */   {
/*  38 */     bind(new InetSocketAddress(port));
/*     */   }
/*     */ 
/*     */   public void bind(String hostname, int port)
/*     */     throws IOException
/*     */   {
/*  46 */     bind(new InetSocketAddress(hostname, port));
/*     */   }
/*     */ 
/*     */   public void bind(InetAddress address, int port)
/*     */     throws IOException
/*     */   {
/*  54 */     bind(new InetSocketAddress(address, port));
/*     */   }
/*     */ 
/*     */   public void bind(InetSocketAddress address) throws IOException {
/*  58 */     this.ssChannel = ServerSocketChannel.open();
/*  59 */     this.ssChannel.socket().bind(address);
/*  60 */     if (Log.loggingDebug)
/*  61 */       log.debug("bound to " + getAddress() + ":" + getPort());
/*     */   }
/*     */ 
/*     */   public int getPort() {
/*  65 */     return this.ssChannel.socket().getLocalPort();
/*     */   }
/*     */ 
/*     */   public InetAddress getAddress() {
/*  69 */     return this.ssChannel.socket().getInetAddress();
/*     */   }
/*     */ 
/*     */   public void registerAcceptCallback(TcpAcceptCallback cb) {
/*  73 */     this.acceptCallback = cb;
/*     */   }
/*     */ 
/*     */   public Thread getThread()
/*     */   {
/*  78 */     return this.thread;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*  86 */     if (this.acceptCallback == null) {
/*  87 */       throw new RuntimeException("no registered accept callback");
/*     */     }
/*     */ 
/*  91 */     Runnable run = new Runnable() {
/*     */       public void run() {
/*     */         try {
/*     */           while (true) {
/*  95 */             SocketChannel sc = TcpServer.this.ssChannel.accept();
/*  96 */             sc.configureBlocking(false);
/*  97 */             TcpServer.this.acceptCallback.onTcpAccept(sc);
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 101 */           TcpServer.log.exception("TcpServer.run caught exception", e);
/*     */         }
/*     */       }
/*     */     };
/* 105 */     this.thread = new Thread(run, "TcpAccept");
/* 106 */     this.thread.setDaemon(true);
/* 107 */     this.thread.start();
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.TcpServer
 * JD-Core Version:    0.6.0
 */