/*      */ package atavism.server.network.rdp;
/*      */ 
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.network.ClientConnection;
/*      */ import atavism.server.network.ClientConnection.AcceptCallback;
/*      */ import atavism.server.network.ClientConnection.MessageCallback;
/*      */ import atavism.server.network.PacketAggregator;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.CountMeter;
/*      */ import atavism.server.util.LockFactory;
/*      */ import atavism.server.util.Log;
/*      */ import java.io.IOException;
/*      */ import java.net.BindException;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.nio.channels.ClosedChannelException;
/*      */ import java.nio.channels.DatagramChannel;
/*      */ import java.nio.channels.SelectionKey;
/*      */ import java.nio.channels.Selector;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.concurrent.locks.Condition;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ public class RDPServer
/*      */   implements Runnable
/*      */ {
/*  461 */   static CountMeter packetCounter = new CountMeter("RDPPacketReceiveCounter");
/*  462 */   static CountMeter dataCounter = new CountMeter("RDPPacketReceiveDATA");
/*      */ 
/*  808 */   private static AOByteBuffer staticAOBuff = new AOByteBuffer(RDPConnection.DefaultMaxReceiveSegmentSize);
/*      */ 
/*  815 */   static CountMeter sendMeter = new CountMeter("RDPSendPacketMeter");
/*  816 */   static CountMeter sendDataMeter = new CountMeter("RDPSendDataPacketMeter");
/*      */ 
/*  865 */   static RDPServer rdpServer = new RDPServer();
/*      */ 
/*  868 */   private static Map<Integer, DatagramChannel> channelMap = new HashMap();
/*      */ 
/*  873 */   private static Map<DatagramChannel, RDPServerSocket> socketMap = new HashMap();
/*      */ 
/*  882 */   private static Map<DatagramChannel, Map<ConnectionInfo, RDPConnection>> allConMap = new HashMap();
/*      */ 
/*  884 */   private static Lock unsentPacketsLock = LockFactory.makeLock("unsentPacketsLock");
/*  885 */   static Condition unsentPacketsNotEmpty = unsentPacketsLock.newCondition();
/*      */ 
/*  890 */   static Set<DatagramChannel> newChannelSet = new HashSet();
/*      */ 
/*  893 */   static Thread rdpServerThread = null;
/*  894 */   static Thread retryThread = null;
/*  895 */   static Thread packetCallbackThread = null;
/*      */ 
/*  904 */   static Selector selector = null;
/*      */ 
/*  906 */   private static boolean rdpServerStarted = false;
/*      */ 
/* 1106 */   static Lock lock = LockFactory.makeLock("StaticRDPServerLock");
/*      */ 
/* 1112 */   static Condition channelMapNotEmpty = lock.newCondition();
/*      */ 
/* 1120 */   public static int resendTimeoutMS = 30000;
/*      */ 
/* 1125 */   public static int resendTimerMS = 500;
/*      */ 
/* 1139 */   public static int activeChannelCalls = 0;
/* 1140 */   public static int selectCalls = 0;
/* 1141 */   public static int transmits = 0;
/* 1142 */   public static int retransmits = 0;
/*      */ 
/* 1198 */   static LinkedList<PacketCallbackStruct> queuedPacketCallbacks = new LinkedList();
/* 1199 */   static Lock queuedPacketCallbacksLock = LockFactory.makeLock("queuedPacketCallbacksLock");
/* 1200 */   static Condition queuedPacketCallbacksNotEmpty = queuedPacketCallbacksLock.newCondition();
/*      */ 
/*      */   static DatagramChannel bind(Integer port, int receiveBufferSize)
/*      */     throws BindException, IOException, SocketException
/*      */   {
/*   21 */     lock.lock();
/*      */     try
/*      */     {
/*   24 */       DatagramChannel dc = (DatagramChannel)channelMap.get(port);
/*   25 */       if (dc != null) {
/*   26 */         throw new BindException("RDPServer.bind: port is already used");
/*      */       }
/*      */ 
/*   31 */       Log.debug("BIND: about to open datagram channel");
/*   32 */       dc = DatagramChannel.open();
/*   33 */       dc.configureBlocking(false);
/*   34 */       Log.debug("BIND: about to set buffer size for datagram channel: " + receiveBufferSize);
/*   35 */       dc.socket().setReceiveBufferSize(receiveBufferSize);
/*   36 */       if (port == null) {
/*   37 */         if (Log.loggingNet)
/*   38 */           Log.net("RDPServer.bind: binding to a random system port");
/*   39 */         dc.socket().bind(null);
/*      */       } else {
/*   41 */         if (Log.loggingNet)
/*   42 */           Log.net("RDPServer.bind: binding to port " + port);
/*   43 */         Log.debug("BIND: about to bind to dc socket with port: " + port);
/*   44 */         InetSocketAddress addr = new InetSocketAddress(port.intValue());
/*   45 */         Log.debug("BIND: created addr: " + addr.toString());
/*   46 */         sckt = dc.socket();
/*   47 */         Log.debug("BIND: got socket: " + sckt.toString());
/*   48 */         sckt.bind(addr);
/*   49 */         Log.debug("BIND: bound socket: ");
/*      */       }
/*      */ 
/*   52 */       Log.debug("BIND: getting resulting port: ");
/*   53 */       int resultingPort = dc.socket().getLocalPort();
/*   54 */       if (Log.loggingNet) {
/*   55 */         Log.net("RDPServer.bind: resulting port=" + resultingPort);
/*      */       }
/*      */ 
/*   58 */       channelMap.put(Integer.valueOf(resultingPort), dc);
/*   59 */       if (Log.loggingNet) {
/*   60 */         Log.net("RDPServer.bind: added dc to channel map");
/*      */       }
/*      */ 
/*   66 */       newChannelSet.add(dc);
/*   67 */       if (Log.loggingNet) {
/*   68 */         Log.net("RDPServer.bind: added dc to newChannelSet");
/*      */       }
/*      */ 
/*   72 */       Log.debug("BIND: about to signal channelMapNotEmpty: ");
/*   73 */       channelMapNotEmpty.signal();
/*   74 */       Log.net("RDPServer.bind: signalled channel map not empty condition");
/*      */ 
/*   78 */       Log.debug("BIND: about to wake up selector: ");
/*   79 */       selector.wakeup();
/*      */ 
/*   81 */       if (Log.loggingNet)
/*   82 */         Log.net("RDPServer.bind: woke up selector");
/*   83 */       DatagramSocket sckt = dc;
/*      */       return sckt; } finally { lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   static void registerSocket(RDPServerSocket rdpSocket, DatagramChannel dc)
/*      */   {
/*   97 */     lock.lock();
/*      */     try {
/*   99 */       socketMap.put(dc, rdpSocket);
/*      */     } finally {
/*  101 */       lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   static void registerConnection(RDPConnection con, DatagramChannel dc)
/*      */   {
/*  109 */     lock.lock();
/*      */     try {
/*  111 */       if (Log.loggingNet) {
/*  112 */         Log.net("RDPServer.registerConnection: registering con " + con);
/*      */       }
/*      */ 
/*  115 */       Map dcConMap = (Map)allConMap.get(dc);
/*  116 */       if (dcConMap == null) {
/*  117 */         dcConMap = new HashMap();
/*      */       }
/*      */ 
/*  121 */       int localPort = con.getLocalPort();
/*  122 */       int remotePort = con.getRemotePort();
/*  123 */       InetAddress remoteAddr = con.getRemoteAddr();
/*  124 */       ConnectionInfo conInfo = new ConnectionInfo(remoteAddr, remotePort, localPort);
/*      */ 
/*  126 */       dcConMap.put(conInfo, con);
/*  127 */       allConMap.put(dc, dcConMap);
/*      */     } finally {
/*  129 */       lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   static void removeConnection(RDPConnection con)
/*      */   {
/*  138 */     lock.lock();
/*      */     try {
/*  140 */       if (Log.loggingNet)
/*  141 */         Log.net("RDPServer.removeConnection: removing con " + con);
/*  142 */       con.setState(3);
/*      */ 
/*  144 */       DatagramChannel dc = con.getDatagramChannel();
/*      */ 
/*  147 */       Map dcConMap = (Map)allConMap.get(dc);
/*  148 */       if (dcConMap == null) {
/*  149 */         throw new AORuntimeException("RDPServer.removeConnection: cannot find dc");
/*      */       }
/*      */ 
/*  153 */       int localPort = con.getLocalPort();
/*  154 */       int remotePort = con.getRemotePort();
/*  155 */       InetAddress remoteAddr = con.getRemoteAddr();
/*  156 */       ConnectionInfo conInfo = new ConnectionInfo(remoteAddr, remotePort, localPort);
/*      */ 
/*  158 */       Object rv = dcConMap.remove(conInfo);
/*  159 */       if (rv == null) {
/*  160 */         throw new AORuntimeException("RDPServer.removeConnection: could not find the connection");
/*      */       }
/*      */ 
/*  167 */       if (dcConMap.isEmpty()) {
/*  168 */         Log.net("RDPServer.removeConnection: no other connections for this datagramchannel (port)");
/*      */ 
/*  172 */         if (getRDPSocket(dc) == null) {
/*  173 */           Log.net("RDPServer.removeConnection: no socket listening on this port - closing");
/*      */ 
/*  176 */           dc.socket().close();
/*  177 */           channelMap.remove(Integer.valueOf(localPort));
/*  178 */           Log.net("RDPServer.removeConnection: closed and removed datagramchannel/socket");
/*      */         }
/*      */         else {
/*  181 */           Log.net("RDPServer.removeConnection: there is a socket listening on this port");
/*      */         }
/*      */       }
/*      */       else {
/*  185 */         Log.net("RDPServer.removeConnection: there are other connections on this port");
/*      */       }
/*      */     }
/*      */     finally {
/*  189 */       lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void run()
/*      */   {
/*      */     try
/*      */     {
/*      */       while (true)
/*      */       {
/*  205 */         if (Log.loggingNet)
/*  206 */           Log.net("In RDPServer.run: starting new iteration");
/*      */         try {
/*  208 */           Set activeChannels = getActiveChannels();
/*  209 */           activeChannelCalls += 1;
/*  210 */           Iterator iter = activeChannels.iterator();
/*  211 */           while (iter.hasNext()) {
/*  212 */             DatagramChannel dc = (DatagramChannel)iter.next();
/*  213 */             if (Log.loggingNet)
/*  214 */               Log.net("In RDPServer.run: about to call processActiveChannel");
/*  215 */             processActiveChannel(dc);
/*  216 */             if (Log.loggingNet)
/*  217 */               Log.net("In RDPServer.run: returned from processActiveChannel");
/*      */           }
/*      */         } catch (ClosedChannelException ex) {
/*      */         }
/*      */         catch (Exception e) {
/*  222 */           Log.exception("RDPServer.run caught exception", e);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally {
/*  227 */       Log.warn("RDPServer.run: thread exiting");
/*      */     }
/*      */   }
/*      */ 
/*      */   void processActiveChannel(DatagramChannel dc)
/*      */     throws ClosedChannelException
/*      */   {
/*  240 */     int count = 0;
/*      */     try { Set needsAckConnections = new HashSet();
/*      */       RDPPacket packet;
/*      */       while (true) { if ((packet = receivePacket(dc)) == null) break label257; if (Log.loggingNet) {
/*  246 */           Log.net("RDPServer.processActiveChannel: Starting iteration with count of " + count + " packets");
/*      */         }
/*  248 */         InetAddress remoteAddr = packet.getInetAddress();
/*  249 */         int remotePort = packet.getPort();
/*  250 */         int localPort = dc.socket().getLocalPort();
/*  251 */         ConnectionInfo conInfo = new ConnectionInfo(remoteAddr, remotePort, localPort);
/*      */ 
/*  253 */         RDPConnection con = getConnection(dc, conInfo);
/*  254 */         if (con == null) break;
/*  255 */         if (Log.loggingNet)
/*  256 */           Log.net("RDPServer.processActiveChannel: found an existing connection: " + con);
/*  257 */         count++;
/*  258 */         if (processExistingConnection(con, packet)) {
/*  259 */           needsAckConnections.add(con);
/*      */         }
/*      */ 
/*  263 */         if (count >= 20) {
/*  264 */           break label257;
/*      */         }
/*      */       }
/*  267 */       Log.net("RDPServer.processActiveChannel: did not find an existing connection");
/*      */ 
/*  271 */       RDPServerSocket rdpSocket = getRDPSocket(dc);
/*  272 */       if (rdpSocket != null) {
/*  273 */         count++;
/*  274 */         processNewConnection(rdpSocket, packet);
/*      */         return;
/*      */       }
/*      */       return;
/*  280 */       label257: for (RDPConnection con : needsAckConnections) {
/*  281 */         RDPPacket replyPacket = new RDPPacket(con);
/*  282 */         con.sendPacketImmediate(replyPacket, false);
/*      */       }
/*      */     } catch (ClosedChannelException ex)
/*      */     {
/*  286 */       Log.error("RDPServer.processActiveChannel: ClosedChannel " + dc.socket());
/*  287 */       throw ex;
/*      */     }
/*      */     finally {
/*  290 */       if (Log.loggingNet)
/*  291 */         Log.net("RDPServer.processActiveChannel: Returning after processing " + count + " packets");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void processNewConnection(RDPServerSocket serverSocket, RDPPacket packet)
/*      */   {
/*  302 */     if (Log.loggingNet) {
/*  303 */       Log.net("processNewConnection: RDPPACKET (localport=" + serverSocket.getPort() + "): " + packet);
/*      */     }
/*      */ 
/*  307 */     InetAddress remoteAddr = packet.getInetAddress();
/*  308 */     int remotePort = packet.getPort();
/*  309 */     if (!packet.isSyn())
/*      */     {
/*  312 */       Log.debug("socket got non-syn packet, replying with reset: packet=" + packet);
/*      */ 
/*  314 */       RDPPacket rstPacket = RDPPacket.makeRstPacket();
/*  315 */       rstPacket.setPort(remotePort);
/*  316 */       rstPacket.setInetAddress(remoteAddr);
/*  317 */       sendPacket(serverSocket.getDatagramChannel(), rstPacket);
/*  318 */       return;
/*      */     }
/*      */ 
/*  322 */     RDPConnection con = new RDPConnection();
/*  323 */     DatagramChannel dc = serverSocket.getDatagramChannel();
/*  324 */     con.initConnection(dc, packet);
/*      */ 
/*  327 */     registerConnection(con, dc);
/*      */ 
/*  330 */     RDPPacket synPacket = RDPPacket.makeSynPacket(con);
/*  331 */     con.sendPacketImmediate(synPacket, false);
/*      */   }
/*      */ 
/*      */   Set<DatagramChannel> getActiveChannels()
/*      */     throws InterruptedException, IOException
/*      */   {
/*  338 */     lock.lock();
/*      */     try {
/*  340 */       while (channelMap.isEmpty())
/*  341 */         channelMapNotEmpty.await();
/*      */     }
/*      */     finally {
/*  344 */       lock.unlock();
/*      */     }
/*      */ 
/*  347 */     Set readyKeys = null;
/*      */     do {
/*  349 */       lock.lock();
/*      */       try {
/*  351 */         if (!newChannelSet.isEmpty()) {
/*  352 */           if (Log.loggingNet)
/*  353 */             Log.net("RDPServer.getActiveChannels: newChannelSet is not null");
/*  354 */           Iterator iter = newChannelSet.iterator();
/*  355 */           while (iter.hasNext()) {
/*  356 */             DatagramChannel newDC = (DatagramChannel)iter.next();
/*  357 */             iter.remove();
/*  358 */             newDC.register(selector, 1);
/*      */           }
/*      */         }
/*      */       } finally {
/*  362 */         lock.unlock();
/*      */       }
/*  364 */       int numReady = selector.select();
/*  365 */       selectCalls += 1;
/*  366 */       if (numReady == 0) {
/*  367 */         if (Log.loggingNet)
/*  368 */           Log.net("RDPServer.getActiveChannels: selector returned 0");
/*      */       }
/*      */       else {
/*  371 */         readyKeys = selector.selectedKeys();
/*  372 */         if (Log.loggingNet)
/*  373 */           Log.net("RDPServer.getActiveChannels: called select - # of ready keys = " + readyKeys.size() + " == " + numReady); 
/*      */       }
/*      */     }
/*  375 */     while ((readyKeys == null) || (readyKeys.isEmpty()));
/*      */ 
/*  377 */     lock.lock();
/*      */     try
/*      */     {
/*  380 */       Set activeChannels = new HashSet();
/*      */ 
/*  382 */       Iterator iter = readyKeys.iterator();
/*  383 */       while (iter.hasNext()) {
/*  384 */         key = (SelectionKey)iter.next();
/*  385 */         if (Log.loggingNet) {
/*  386 */           Log.net("RDPServer.getActiveChannels: matched selectionkey: " + key + ", isAcceptable=" + ((SelectionKey)key).isAcceptable() + ", isReadable=" + ((SelectionKey)key).isReadable() + ", isValid=" + ((SelectionKey)key).isValid() + ", isWritable=" + ((SelectionKey)key).isWritable());
/*      */         }
/*      */ 
/*  391 */         iter.remove();
/*      */ 
/*  393 */         if ((!((SelectionKey)key).isReadable()) || (!((SelectionKey)key).isValid())) {
/*  394 */           Log.error("RDPServer.getActiveChannels: Throwing exception: RDPServer: not readable or invalid");
/*  395 */           throw new AORuntimeException("RDPServer: not readable or invalid");
/*      */         }
/*      */ 
/*  398 */         DatagramChannel dc = (DatagramChannel)((SelectionKey)key).channel();
/*  399 */         activeChannels.add(dc);
/*      */       }
/*  401 */       if (Log.loggingNet)
/*  402 */         Log.net("RDPServer.getActiveChannels: returning " + activeChannels.size() + " active channels");
/*  403 */       Object key = activeChannels;
/*      */       return key; } finally { lock.unlock(); } throw localObject3;
/*      */   }
/*      */ 
/*      */   static RDPConnection getConnection(DatagramChannel dc, ConnectionInfo conInfo)
/*      */   {
/*  416 */     lock.lock();
/*      */     try {
/*  418 */       Map dcConMap = (Map)allConMap.get(dc);
/*      */ 
/*  420 */       if (dcConMap == null)
/*      */       {
/*  422 */         if (Log.loggingNet)
/*  423 */           Log.net("RDPServer.getConnection: could not find datagram");
/*  424 */         localRDPConnection = null;
/*      */         return localRDPConnection;
/*      */       }
/*  426 */       RDPConnection localRDPConnection = (RDPConnection)dcConMap.get(conInfo);
/*      */       return localRDPConnection; } finally { lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   static Set<RDPConnection> getAllConnections()
/*      */   {
/*  433 */     lock.lock();
/*      */     try {
/*  435 */       Set allCon = new HashSet();
/*  436 */       Iterator iter = allConMap.values().iterator();
/*      */ 
/*  438 */       while (iter.hasNext()) {
/*  439 */         dcMap = (Map)iter.next();
/*  440 */         allCon.addAll(dcMap.values());
/*      */       }
/*  442 */       Map dcMap = allCon;
/*      */       return dcMap; } finally { lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   static RDPServerSocket getRDPSocket(DatagramChannel dc)
/*      */   {
/*  453 */     lock.lock();
/*      */     try {
/*  455 */       RDPServerSocket localRDPServerSocket = (RDPServerSocket)socketMap.get(dc);
/*      */       return localRDPServerSocket; } finally { lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   boolean processExistingConnection(RDPConnection con, RDPPacket packet)
/*      */   {
/*  472 */     if (Log.loggingNet) {
/*  473 */       Log.net("RDPServer.processExistingConnection: con state=" + con + ", packet=" + packet);
/*      */     }
/*  475 */     packetCounter.add();
/*      */ 
/*  477 */     int state = con.getState();
/*  478 */     if (state == 2)
/*      */     {
/*  483 */       Log.error("RDPServer.processExistingConnection: connection shouldnt be in LISTEN state");
/*      */ 
/*  485 */       return false;
/*      */     }
/*  487 */     if (state == 4) {
/*  488 */       if (!packet.isAck()) {
/*  489 */         Log.warn("got a non-ack packet when we're in SYN_SENT");
/*  490 */         return false;
/*      */       }
/*  492 */       if (!packet.isSyn()) {
/*  493 */         Log.warn("got a non-syn packet when we're in SYN_SENT");
/*  494 */         return false;
/*      */       }
/*  496 */       if (Log.loggingNet) {
/*  497 */         Log.net("good: got syn-ack packet in syn_sent");
/*      */       }
/*      */ 
/*  500 */       if (packet.getAckNum() != con.getInitialSendSeqNum()) {
/*  501 */         if (Log.loggingNet)
/*  502 */           Log.net("syn's ack number does not match initial seq #");
/*  503 */         return false;
/*      */       }
/*      */ 
/*  506 */       con.setRcvCur(packet.getSeqNum());
/*  507 */       con.setRcvIrs(packet.getSeqNum());
/*  508 */       con.setMaxSendUnacks(packet.getSendUnacks());
/*  509 */       con.setMaxReceiveSegmentSize(packet.getMaxRcvSegmentSize());
/*  510 */       con.setSendUnackd(packet.getAckNum() + 1L);
/*      */ 
/*  515 */       if (Log.loggingNet)
/*  516 */         Log.net("new connection state: " + con);
/*  517 */       RDPPacket replyPacket = new RDPPacket(con);
/*  518 */       con.sendPacketImmediate(replyPacket, false);
/*  519 */       con.setState(1);
/*  520 */       return false;
/*      */     }
/*  522 */     if (state == 5) {
/*  523 */       if (packet.getSeqNum() <= con.getRcvIrs()) {
/*  524 */         Log.error("seqnum is not above rcv initial seq num");
/*  525 */         return false;
/*      */       }
/*  527 */       if (packet.getSeqNum() > con.getRcvCur() + con.getRcvMax() * 2L) {
/*  528 */         Log.error("seqnum is too big");
/*  529 */         return false;
/*      */       }
/*  531 */       if ((packet.isAck()) && 
/*  532 */         (packet.getAckNum() == con.getInitialSendSeqNum())) {
/*  533 */         if (Log.loggingNet)
/*  534 */           Log.net("got ack for our syn - setting state to open");
/*  535 */         con.setState(1);
/*      */ 
/*  539 */         DatagramChannel dc = con.getDatagramChannel();
/*  540 */         if (dc == null) {
/*  541 */           throw new AORuntimeException("RDPServer.processExistingConnection: no datagramchannel for connection that just turned OPEN");
/*      */         }
/*      */ 
/*  544 */         RDPServerSocket rdpSocket = getRDPSocket(dc);
/*  545 */         if (rdpSocket == null) {
/*  546 */           throw new AORuntimeException("RDPServer.processExistingConnection: no socket for connection that just turned OPEN");
/*      */         }
/*      */ 
/*  549 */         ClientConnection.AcceptCallback acceptCB = rdpSocket.getAcceptCallback();
/*  550 */         if (acceptCB != null)
/*  551 */           acceptCB.acceptConnection(con);
/*      */         else {
/*  553 */           Log.warn("serversocket has no accept callback");
/*      */         }
/*  555 */         if (Log.loggingNet) {
/*  556 */           Log.net("RDPServer.processExistingConnection: got ACK, removing from unack list: " + packet.getSeqNum());
/*      */         }
/*  558 */         con.removeUnackPacket(packet.getSeqNum());
/*      */       }
/*      */     }
/*      */ 
/*  562 */     if (state == 6)
/*      */     {
/*  564 */       if (!packet.isRst()) {
/*  565 */         RDPPacket rstPacket = RDPPacket.makeRstPacket();
/*  566 */         con.sendPacketImmediate(rstPacket, false);
/*      */       }
/*      */     }
/*  569 */     if (state == 1) {
/*  570 */       if (packet.isRst())
/*      */       {
/*  574 */         if (Log.loggingDebug)
/*  575 */           Log.debug("RDPServer.processExistingConnection: got reset packet for con " + con);
/*  576 */         if (con.getState() != 6) {
/*  577 */           con.setState(6);
/*  578 */           con.setCloseWaitTimer();
/*      */ 
/*  581 */           Log.net("RDPServer.processExistingConnection: calling reset callback");
/*  582 */           ClientConnection.MessageCallback pcb = con.getCallback();
/*  583 */           pcb.connectionReset(con);
/*      */         }
/*      */ 
/*  586 */         return false;
/*      */       }
/*  588 */       if (packet.isSyn())
/*      */       {
/*  591 */         Log.error("RDPServer.processExistingConnection: closing connection because we got a syn packet, con=" + con);
/*      */ 
/*  594 */         con.close();
/*  595 */         return false;
/*      */       }
/*      */ 
/*  600 */       long rcvCur = con.getRcvCur();
/*      */       RDPPacket replyPacket;
/*  601 */       if (packet.getSeqNum() <= rcvCur) {
/*  602 */         if (Log.loggingNet)
/*  603 */           Log.net("RDPServer.processExistingConnection: seqnum too small - acking/not process");
/*  604 */         if (packet.getData() != null) {
/*  605 */           if (Log.loggingNet)
/*  606 */             Log.net("RDPServer.processExistingConnection: sending ack even though seqnum out of range");
/*  607 */           replyPacket = new RDPPacket(con);
/*  608 */           con.sendPacketImmediate(replyPacket, false);
/*      */         }
/*  610 */         return false;
/*      */       }
/*  612 */       if (packet.getSeqNum() > rcvCur + con.getRcvMax() * 2L) {
/*  613 */         Log.error("RDPServer.processExistingConnection: seqnum too big - discarding");
/*  614 */         return false;
/*      */       }
/*  616 */       if (packet.isAck()) {
/*  617 */         if (Log.loggingNet) {
/*  618 */           Log.net("RDPServer.processExistingConnection: processing ack " + packet.getAckNum());
/*      */         }
/*  620 */         con.getLock().lock();
/*      */         try {
/*  622 */           if (packet.getAckNum() >= con.getSendNextSeqNum())
/*      */           {
/*  624 */             Log.error("RDPServer.processExistingConnection: discarding -- got ack #" + packet.getAckNum() + ", but our next send seqnum is " + con.getSendNextSeqNum() + " -- " + con);
/*      */ 
/*  628 */             replyPacket = 0;
/*      */             return replyPacket;
/*      */           }
/*  630 */           if (con.getSendUnackd() <= packet.getAckNum()) {
/*  631 */             con.setSendUnackd(packet.getAckNum() + 1L);
/*  632 */             if (Log.loggingNet) {
/*  633 */               Log.net("RDPServer.processExistingConnection: updated send_unackd num to " + con.getSendUnackd() + " (one greater than packet ack) - " + con);
/*      */             }
/*      */ 
/*  636 */             con.removeUnackPacketUpTo(packet.getAckNum());
/*      */           }
/*  638 */           if (packet.isEak()) {
/*  639 */             List eackList = packet.getEackList();
/*  640 */             Iterator iter = eackList.iterator();
/*  641 */             while (iter.hasNext()) {
/*  642 */               Long seqNum = (Long)iter.next();
/*  643 */               if (Log.loggingNet)
/*  644 */                 Log.net("RDPServer.processExistingConnection: got EACK: " + seqNum);
/*  645 */               con.removeUnackPacket(seqNum.longValue());
/*      */             }
/*      */           }
/*      */         } finally {
/*  649 */           con.getLock().unlock();
/*  650 */           if (Log.loggingNet) {
/*  651 */             Log.net("RDPServer.processExistingConnection: processed ack " + packet.getAckNum());
/*      */           }
/*      */         }
/*      */       }
/*  655 */       byte[] data = packet.getData();
/*  656 */       if ((data != null) || (packet.isNul())) {
/*  657 */         dataCounter.add();
/*      */ 
/*  660 */         con.getLock().lock();
/*      */         try {
/*  662 */           rcvCur = con.getRcvCur();
/*  663 */           if (Log.loggingNet) {
/*  664 */             Log.net("RDPServer.processExistingConnection: rcvcur is " + rcvCur);
/*      */           }
/*  666 */           ClientConnection.MessageCallback pcb = con.getCallback();
/*  667 */           if (pcb == null) {
/*  668 */             Log.warn("RDPServer.processExistingConnection: no packet callback registered");
/*      */           }
/*      */ 
/*  672 */           if (!con.hasEack(packet.getSeqNum())) {
/*  673 */             if (con.isSequenced())
/*      */             {
/*  677 */               if (packet.getSeqNum() == rcvCur + 1L)
/*      */               {
/*  679 */                 if (Log.loggingNet) {
/*  680 */                   Log.net("RDPServer.processExistingConnection: conn is sequenced and received next packet, rcvCur=" + rcvCur + ", packet=" + packet);
/*      */                 }
/*  682 */                 if ((pcb != null) && (data != null))
/*  683 */                   queueForCallbackProcessing(pcb, con, packet);
/*      */               }
/*      */               else
/*      */               {
/*  687 */                 if (Log.loggingNet) {
/*  688 */                   Log.net("RDPServer.processExistingConnection: conn is sequenced, BUT PACKET is OUT OF ORDER: rcvcur=" + rcvCur + ", packet=" + packet);
/*      */                 }
/*  690 */                 con.addSequencePacket(packet);
/*      */               }
/*      */             }
/*  693 */             else if ((pcb != null) && (data != null))
/*      */             {
/*  695 */               queueForCallbackProcessing(pcb, con, packet);
/*      */             }
/*      */ 
/*      */           }
/*  699 */           else if (Log.loggingNet) {
/*  700 */             Log.net(con.toString() + " already seen this packet");
/*      */           }
/*      */ 
/*  704 */           if (packet.getSeqNum() == rcvCur + 1L) {
/*  705 */             con.setRcvCur(rcvCur + 1L);
/*  706 */             if (Log.loggingNet) {
/*  707 */               Log.net("RDPServer.processExistingConnection RCVD: incremented last sequenced rcvd: " + (rcvCur + 1L));
/*      */             }
/*      */ 
/*  712 */             long seqNum = rcvCur + 2L;
/*  713 */             while (con.removeEack(seqNum)) {
/*  714 */               if (Log.loggingNet)
/*  715 */                 Log.net("RDPServer.processExistingConnection: removing/collapsing eack: " + seqNum);
/*  716 */               con.setRcvCur(seqNum++);
/*      */             }
/*      */ 
/*  719 */             if (con.isSequenced()) {
/*  720 */               rcvCur += 1L;
/*  721 */               Log.net("RDPServer.processExistingConnection: connection is sequenced, processing collapsed packets.");
/*      */ 
/*  724 */               Iterator iter = con.getSequencePackets().iterator();
/*  725 */               while (iter.hasNext()) {
/*  726 */                 RDPPacket p = (RDPPacket)iter.next();
/*  727 */                 if (Log.loggingNet) {
/*  728 */                   Log.net("rdpserver: stored packet seqnum=" + p.getSeqNum() + ", if equal to (rcvcur + 1)=" + (rcvCur + 1L));
/*      */                 }
/*      */ 
/*  732 */                 if (p.getSeqNum() == rcvCur + 1L) {
/*  733 */                   Log.net("RDPServer.processExistingConnection: this is the next packet, processing");
/*      */ 
/*  736 */                   rcvCur += 1L;
/*      */ 
/*  739 */                   Log.net("RDPServer.processExistingConnection: processing stored sequential packet " + p);
/*      */ 
/*  742 */                   byte[] storedData = p.getData();
/*  743 */                   if ((pcb != null) && (storedData != null)) {
/*  744 */                     queueForCallbackProcessing(pcb, con, packet);
/*      */                   }
/*  746 */                   iter.remove();
/*      */                 }
/*      */               }
/*      */             }
/*  750 */             else if (Log.loggingNet) {
/*  751 */               Log.net("RDPServer.processExistingConnection: connection is not sequenced");
/*      */             }
/*      */           } else {
/*  754 */             if (Log.loggingNet) {
/*  755 */               Log.net("RDPServer.processExistingConnection: RCVD OUT OF ORDER: packet seq#: " + packet.getSeqNum() + ", but last sequential rcvd packet was: " + con.getRcvCur() + " -- not incrementing counter");
/*      */             }
/*      */ 
/*  760 */             if (packet.getSeqNum() > rcvCur)
/*      */             {
/*  762 */               if (Log.loggingNet)
/*  763 */                 Log.net("adding to eack list " + packet);
/*  764 */               con.addEack(packet);
/*      */             }
/*      */           }
/*      */         } finally {
/*  768 */           con.getLock().unlock();
/*      */         }
/*  770 */         return true;
/*      */       }
/*      */     }
/*  773 */     return false;
/*      */   }
/*      */ 
/*      */   static RDPPacket receivePacket(DatagramChannel dc)
/*      */     throws ClosedChannelException
/*      */   {
/*      */     try
/*      */     {
/*  783 */       if (dc == null) {
/*  784 */         throw new AORuntimeException("RDPServer.receivePacket: datagramChannel is null");
/*      */       }
/*      */ 
/*  789 */       staticAOBuff.rewind();
/*  790 */       InetSocketAddress addr = (InetSocketAddress)dc.receive(staticAOBuff.getNioBuf());
/*  791 */       if (addr == null) {
/*  792 */         return null;
/*      */       }
/*      */ 
/*  795 */       RDPPacket packet = new RDPPacket();
/*  796 */       packet.setPort(addr.getPort());
/*  797 */       packet.setInetAddress(addr.getAddress());
/*  798 */       packet.parse(staticAOBuff);
/*  799 */       return packet;
/*      */     } catch (ClosedChannelException ex) {
/*  801 */       throw ex; } catch (Exception e) {
/*      */     }
/*  803 */     throw new AORuntimeException("error", e);
/*      */   }
/*      */ 
/*      */   static String printSocket(DatagramSocket socket)
/*      */   {
/*  812 */     return "[Socket: localPort=" + socket.getLocalPort() + ", remoteAddr=" + socket.getInetAddress() + ", localAddr=" + socket.getLocalAddress() + "]";
/*      */   }
/*      */ 
/*      */   static void sendPacket(DatagramChannel dc, RDPPacket packet)
/*      */   {
/*  823 */     sendMeter.add();
/*      */ 
/*  826 */     int bufSize = 100 + packet.numEacks() * 4;
/*  827 */     if (packet.getData() != null) {
/*  828 */       bufSize += packet.getData().length;
/*  829 */       sendDataMeter.add();
/*      */     }
/*  831 */     AOByteBuffer buf = new AOByteBuffer(bufSize);
/*  832 */     packet.toByteBuffer(buf);
/*      */ 
/*  834 */     int remotePort = packet.getPort();
/*  835 */     InetAddress remoteAddr = packet.getInetAddress();
/*      */ 
/*  837 */     if ((remotePort < 0) || (remoteAddr == null)) {
/*  838 */       throw new AORuntimeException("RDPServer.sendPacket: remotePort or addr is null");
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  843 */       int bytes = dc.send(buf.getNioBuf(), new InetSocketAddress(remoteAddr, remotePort));
/*      */ 
/*  845 */       if (bytes == 0) {
/*  846 */         Log.error("RDPServer.sendPacket: could not send packet, size=" + bufSize);
/*      */       }
/*      */ 
/*  850 */       if (Log.loggingNet)
/*  851 */         Log.net("RDPServer.sendPacket: remoteAddr=" + remoteAddr + ", remotePort=" + remotePort + ", numbytes sent=" + bytes);
/*      */     } catch (IOException e) {
/*  853 */       Log.exception("RDPServer.sendPacket: remoteAddr=" + remoteAddr + ", remotePort=" + remotePort + ", got exception", e);
/*  854 */       throw new AORuntimeException("RDPServer.sendPacket", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void startRDPServer()
/*      */   {
/*  909 */     if (rdpServerStarted)
/*  910 */       return;
/*  911 */     rdpServerStarted = true;
/*  912 */     rdpServerThread = new Thread(rdpServer, "RDPServer");
/*  913 */     rdpServerThread.setDaemon(true);
/*  914 */     retryThread = new Thread(new RetryThread(), "RDPRetry");
/*  915 */     retryThread.setDaemon(true);
/*  916 */     packetCallbackThread = new Thread(new PacketCallbackThread(), "RDPCallback");
/*  917 */     packetCallbackThread.setDaemon(true);
/*  918 */     if (Log.loggingNet)
/*  919 */       Log.net("static - starting rdpserver thread");
/*      */     try {
/*  921 */       selector = Selector.open();
/*      */     } catch (Exception e) {
/*  923 */       Log.exception("RDPServer caught exception opening selector", e);
/*  924 */       System.exit(1);
/*      */     }
/*  926 */     rdpServerThread.setPriority(rdpServerThread.getPriority() + 2);
/*  927 */     if (Log.loggingDebug) {
/*  928 */       Log.debug("RDPServer: starting rdpServerThread with priority " + rdpServerThread.getPriority());
/*      */     }
/*  930 */     rdpServerThread.start();
/*  931 */     retryThread.start();
/*  932 */     packetCallbackThread.start();
/*      */   }
/*      */ 
/*      */   public static void setCounterLogging(boolean enable)
/*      */   {
/* 1129 */     packetCounter.setLogging(enable);
/* 1130 */     dataCounter.setLogging(enable);
/* 1131 */     sendMeter.setLogging(enable);
/* 1132 */     sendDataMeter.setLogging(enable);
/* 1133 */     RDPConnection.resendMeter.setLogging(enable);
/*      */   }
/*      */ 
/*      */   static void queueForCallbackProcessing(ClientConnection.MessageCallback pcb, ClientConnection con, RDPPacket packet)
/*      */   {
/* 1188 */     queuedPacketCallbacksLock.lock();
/*      */     try {
/* 1190 */       queuedPacketCallbacks.addLast(new PacketCallbackStruct(pcb, con, packet));
/* 1191 */       queuedPacketCallbacksNotEmpty.signal();
/*      */     }
/*      */     finally {
/* 1194 */       queuedPacketCallbacksLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   static void callbackProcessPacket(ClientConnection.MessageCallback pcb, ClientConnection clientCon, RDPPacket packet)
/*      */   {
/* 1241 */     if (packet.isNul()) {
/* 1242 */       return;
/*      */     }
/* 1244 */     byte[] data = packet.getData();
/* 1245 */     AOByteBuffer buf = new AOByteBuffer(data);
/* 1246 */     RDPConnection con = (RDPConnection)clientCon;
/*      */ 
/* 1248 */     if ((buf.getOID() == null) && (buf.getInt() == 74)) {
/* 1249 */       con.aggregatedReceives += 1L;
/* 1250 */       PacketAggregator.allAggregatedReceives += 1L;
/*      */ 
/* 1252 */       int size = buf.getInt();
/* 1253 */       con.receivedMessagesAggregated += size;
/* 1254 */       PacketAggregator.allReceivedMessagesAggregated += size;
/* 1255 */       if (Log.loggingNet)
/* 1256 */         Log.net("RDPServer.callbackProcessPacket: processing aggregated message with " + size + " submessages");
/* 1257 */       AOByteBuffer subBuf = null;
/* 1258 */       for (int i = 0; i < size; i++) {
/*      */         try {
/* 1260 */           subBuf = buf.getByteBuffer();
/*      */         }
/*      */         catch (Exception e) {
/* 1263 */           Log.error("In CallbackThread, error getting aggregated subbuffer: " + e.getMessage());
/*      */         }
/* 1265 */         if (subBuf != null)
/* 1266 */           pcb.processPacket(con, subBuf);
/*      */       }
/*      */     }
/*      */     else {
/* 1270 */       con.unaggregatedReceives += 1L;
/* 1271 */       PacketAggregator.allUnaggregatedReceives += 1L;
/* 1272 */       buf.rewind();
/* 1273 */       pcb.processPacket(con, buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class PacketCallbackThread
/*      */     implements Runnable
/*      */   {
/*      */     public void run()
/*      */     {
/*      */       while (true)
/*      */       {
/* 1211 */         LinkedList list = null;
/*      */         try {
/* 1213 */           RDPServer.queuedPacketCallbacksLock.lock();
/*      */           try {
/* 1215 */             RDPServer.queuedPacketCallbacksNotEmpty.await();
/*      */           }
/*      */           catch (Exception e) {
/* 1218 */             Log.error("RDPServer.PacketCallbackThread: queuedPacketCallbacksNotEmpty.await() caught exception " + e.getMessage());
/*      */           }
/* 1220 */           list = RDPServer.queuedPacketCallbacks;
/* 1221 */           RDPServer.queuedPacketCallbacks = new LinkedList();
/*      */         }
/*      */         finally {
/* 1224 */           RDPServer.queuedPacketCallbacksLock.unlock();
/*      */         }
/* 1226 */         if (Log.loggingNet)
/* 1227 */           Log.net("RDPServer.PacketCallbackThread: Got " + list.size() + " queued packets");
/* 1228 */         for (RDPServer.PacketCallbackStruct pcs : list)
/*      */           try {
/* 1230 */             RDPServer.callbackProcessPacket(pcs.cb, pcs.con, pcs.packet);
/*      */           }
/*      */           catch (Exception e) {
/* 1233 */             Log.exception("RDPServer.PacketCallbackThread: ", e);
/*      */           }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class PacketCallbackStruct
/*      */   {
/* 1180 */     ClientConnection con = null;
/*      */ 
/* 1182 */     ClientConnection.MessageCallback cb = null;
/*      */ 
/* 1184 */     RDPPacket packet = null;
/*      */ 
/*      */     PacketCallbackStruct(ClientConnection.MessageCallback cb, ClientConnection con, RDPPacket packet)
/*      */     {
/* 1175 */       this.cb = cb;
/* 1176 */       this.con = con;
/* 1177 */       this.packet = packet;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class CallbackThread
/*      */     implements Runnable
/*      */   {
/* 1159 */     RDPConnection con = null;
/*      */ 
/* 1161 */     RDPPacketCallback cb = null;
/*      */ 
/* 1163 */     RDPPacket packet = null;
/*      */ 
/* 1165 */     AOByteBuffer buf = null;
/*      */ 
/*      */     CallbackThread(RDPPacketCallback cb, RDPConnection con, RDPPacket packet, AOByteBuffer buf)
/*      */     {
/* 1149 */       this.cb = cb;
/* 1150 */       this.con = con;
/* 1151 */       this.packet = packet;
/* 1152 */       this.buf = buf;
/*      */     }
/*      */ 
/*      */     public void run() {
/* 1156 */       this.cb.processPacket(this.con, this.buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class RetryThread
/*      */     implements Runnable
/*      */   {
/*      */     public void run()
/*      */     {
/*  997 */       List conList = new LinkedList();
/*  998 */       long lastCounterTime = System.currentTimeMillis();
/*      */       while (true)
/*      */         try {
/* 1001 */           long startTime = System.currentTimeMillis();
/* 1002 */           long interval = startTime - lastCounterTime;
/* 1003 */           if (interval <= 1000L)
/*      */             continue;
/* 1005 */           if (Log.loggingNet) {
/* 1006 */             Log.net("RDPServer counters: activeChannelCalls " + RDPServer.activeChannelCalls + ", selectCalls " + RDPServer.selectCalls + ", transmits " + RDPServer.transmits + ", retransmits " + RDPServer.retransmits + " in " + interval + "ms");
/*      */           }
/*      */ 
/* 1010 */           RDPServer.activeChannelCalls = 0;
/* 1011 */           RDPServer.selectCalls = 0;
/* 1012 */           RDPServer.transmits = 0;
/* 1013 */           RDPServer.retransmits = 0;
/* 1014 */           lastCounterTime = startTime;
/*      */ 
/* 1016 */           if (Log.loggingNet) {
/* 1017 */             Log.net("RDPServer.RETRY: startTime=" + startTime);
/*      */           }
/*      */ 
/* 1021 */           conList.clear();
/*      */ 
/* 1023 */           RDPServer.lock.lock();
/*      */           try
/*      */           {
/* 1027 */             Set conCol = RDPServer.getAllConnections();
/*      */ 
/* 1029 */             if (conCol == null) {
/* 1030 */               throw new AORuntimeException("values() returned null");
/*      */             }
/* 1032 */             conList.addAll(conCol);
/*      */           } finally {
/* 1034 */             RDPServer.lock.unlock();
/*      */           }
/*      */ 
/* 1037 */           Iterator iter = conList.iterator();
/* 1038 */           if (iter.hasNext()) {
/* 1039 */             RDPConnection con = (RDPConnection)iter.next();
/* 1040 */             long currentTime = System.currentTimeMillis();
/*      */ 
/* 1043 */             if (con.getState() == 6) {
/* 1044 */               long closeTime = con.getCloseWaitTimer();
/* 1045 */               long elapsedTime = currentTime - closeTime;
/* 1046 */               Log.net("RDPRetryThread: con is in CLOSE_WAIT: elapsed close timer(ms)=" + elapsedTime + ", waiting for 30seconds to elapse. con=" + con);
/*      */ 
/* 1051 */               if (elapsedTime <= 30000L)
/*      */                 continue;
/* 1053 */               Log.net("RDPRetryThread: removing CLOSE_WAIT connection. con=" + con);
/*      */ 
/* 1056 */               RDPServer.removeConnection(con); continue;
/*      */ 
/* 1058 */               Log.net("RDPRetryThread: time left on CLOSE_WAIT timer: " + (30000L - (currentTime - closeTime)));
/*      */ 
/* 1063 */               continue;
/*      */             }
/* 1065 */             if (Log.loggingNet) {
/* 1066 */               Log.net("RDPServer.RETRY: resending expired packets " + con + " - current list size = " + con.unackListSize());
/*      */             }
/*      */ 
/* 1071 */             if ((con.getState() == 1) && (currentTime - con.getLastNullPacketTime() > 30000L)) {
/* 1072 */               con.getLock().lock();
/*      */               try {
/* 1074 */                 RDPPacket nulPacket = RDPPacket.makeNulPacket();
/*      */ 
/* 1076 */                 con.sendPacketImmediate(nulPacket, false);
/* 1077 */                 con.setLastNullPacketTime();
/* 1078 */                 if (Log.loggingNet)
/* 1079 */                   Log.net("RDPServer.retry: sent nul packet: " + nulPacket);
/*      */               }
/*      */               finally {
/* 1082 */                 con.getLock().unlock();
/*      */               }
/*      */             }
/* 1085 */             else if (Log.loggingNet) {
/* 1086 */               Log.net("RDPServer.retry: sending nul packet in " + (30000L - (currentTime - con.getLastNullPacketTime())));
/*      */             }
/*      */ 
/* 1090 */             con.resend(currentTime - RDPServer.resendTimerMS, currentTime - RDPServer.resendTimeoutMS);
/*      */ 
/* 1092 */             continue;
/*      */           }
/* 1094 */           long endTime = System.currentTimeMillis();
/* 1095 */           if (Log.loggingNet) {
/* 1096 */             Log.net("RDPServer.RETRY: endTime=" + endTime + ", elapse(ms)=" + (endTime - startTime));
/*      */           }
/* 1098 */           Thread.sleep(250L);
/*      */ 
/* 1101 */           continue;
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1100 */           Log.exception("RDPServer.RetryThread.run caught exception", e);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class RDPConnectionData
/*      */     implements Comparable
/*      */   {
/*      */     public RDPConnection con;
/*      */     public long readyTime;
/*      */ 
/*      */     public int compareTo(Object arg0)
/*      */     {
/*  944 */       RDPConnectionData other = (RDPConnectionData)arg0;
/*      */ 
/*  946 */       if (this.readyTime < other.readyTime) {
/*  947 */         if (Log.loggingNet)
/*  948 */           Log.net("RDPServer.RDPConnectionData.compareTo: readyTime compare -1: thiscon=" + this.con + ", othercon=" + other.con + ", thisready=" + this.readyTime + ", otherReady=" + other.readyTime);
/*  949 */         return -1;
/*      */       }
/*  951 */       if (this.readyTime > other.readyTime) {
/*  952 */         if (Log.loggingNet)
/*  953 */           Log.net("RDPServer.RDPConnectionData.compareTo: readyTime compare 1: thiscon=" + this.con + ", othercon=" + other.con + ", thisready=" + this.readyTime + ", otherReady=" + other.readyTime);
/*  954 */         return 1;
/*      */       }
/*      */ 
/*  957 */       if (this.con == other.con) {
/*  958 */         if (Log.loggingNet)
/*  959 */           Log.net("RDPServer.RDPConnectionData.compareTo: conRef compare 0: thiscon=" + this.con + ", othercon=" + other.con);
/*  960 */         return 0;
/*      */       }
/*  962 */       if (this.con.hashCode() < other.con.hashCode()) {
/*  963 */         if (Log.loggingNet)
/*  964 */           Log.net("RDPServer.RDPConnectionData.compareTo: hashCode compare -1: thiscon=" + this.con + ", othercon=" + other.con);
/*  965 */         return -1;
/*      */       }
/*  967 */       if (this.con.hashCode() > other.con.hashCode()) {
/*  968 */         if (Log.loggingNet)
/*  969 */           Log.net("RDPServer.RDPConnectionData.compareTo: hashCode compare 1: thiscon=" + this.con + ", othercon=" + other.con);
/*  970 */         return 1;
/*      */       }
/*      */ 
/*  973 */       throw new RuntimeException("error");
/*      */     }
/*      */ 
/*      */     public boolean equals(Object obj) {
/*  977 */       int rv = compareTo(obj);
/*  978 */       if (Log.loggingNet) {
/*  979 */         Log.net("RDPServer.RDPConnectionData.equals: thisObj=" + toString() + ", other=" + obj.toString() + ", result=" + rv);
/*      */       }
/*  981 */       return rv == 0;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.RDPServer
 * JD-Core Version:    0.6.0
 */