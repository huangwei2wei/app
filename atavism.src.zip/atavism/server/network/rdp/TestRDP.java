/*    */ package atavism.server.network.rdp;
/*    */ 
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.network.ClientConnection.MessageCallback;
/*    */ import atavism.server.util.Log;
/*    */ import java.io.PrintStream;
/*    */ import java.net.InetAddress;
/*    */ 
/*    */ public class TestRDP
/*    */   implements ClientConnection.MessageCallback, Runnable
/*    */ {
/* 71 */   public int localPort = -1;
/*    */ 
/* 73 */   public static TestRDP trdp = new TestRDP();
/* 74 */   public static String remoteHostname = null;
/* 75 */   public static int remotePort = -1;
/* 76 */   public static int sLocalPort = -1;
/*    */ 
/*    */   public void connectionReset(ClientConnection con)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void processPacket(ClientConnection con, AOByteBuffer buf)
/*    */   {
/*    */     try
/*    */     {
/* 14 */       Log.info("TestRDP.processPacket: GOT MESSAGE '" + buf.getString() + "'");
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 18 */       Log.error("got error: " + e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void run() {
/* 23 */     InetAddress addr = null;
/*    */     try {
/* 25 */       RDPConnection con = new RDPConnection();
/* 26 */       con.registerMessageCallback(this);
/*    */ 
/* 28 */       addr = InetAddress.getByName(remoteHostname);
/* 29 */       if (addr == null) {
/* 30 */         Log.error("TestRDP: addr is null - exiting");
/* 31 */         return;
/*    */       }
/* 33 */       con.open(addr, Integer.valueOf(remotePort), Integer.valueOf(this.localPort), true);
/* 34 */       int i = 0;
/*    */       while (true) {
/* 36 */         AOByteBuffer buf = new AOByteBuffer(200);
/* 37 */         buf.putString("Hello World from CLIENT! - MSG " + i++);
/* 38 */         buf.flip();
/* 39 */         con.send(buf);
/* 40 */         con.close();
/* 41 */         Thread.sleep(100000L);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 45 */       System.err.println("exception: " + e);
/* 46 */       e.printStackTrace();
/* 47 */       System.exit(1);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 52 */     if (args.length != 4) {
/* 53 */       System.err.println("usage: java TestRDP hostname remotePort localPort loglevel");
/* 54 */       System.exit(1);
/*    */     }
/*    */ 
/* 57 */     remoteHostname = args[0];
/* 58 */     remotePort = Integer.valueOf(args[1]).intValue();
/* 59 */     sLocalPort = Integer.valueOf(args[2]).intValue();
/* 60 */     int logLevel = Integer.valueOf(args[3]).intValue();
/* 61 */     Log.setLogLevel(logLevel);
/*    */ 
/* 63 */     for (int i = 0; i < 1; i++) {
/* 64 */       TestRDP trdp = new TestRDP();
/* 65 */       trdp.localPort = (sLocalPort + i);
/* 66 */       Thread thread = new Thread(trdp);
/* 67 */       thread.start();
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.TestRDP
 * JD-Core Version:    0.6.0
 */