/*    */ package atavism.server.network.rdp;
/*    */ 
/*    */ import atavism.server.network.ClientConnection.AcceptCallback;
/*    */ import atavism.server.util.Log;
/*    */ import java.io.IOException;
/*    */ import java.net.BindException;
/*    */ import java.net.DatagramSocket;
/*    */ import java.nio.channels.DatagramChannel;
/*    */ 
/*    */ public class RDPServerSocket
/*    */ {
/* 70 */   protected int port = -1;
/* 71 */   ClientConnection.AcceptCallback acceptCallback = null;
/* 72 */   DatagramChannel dc = null;
/* 73 */   protected static int defaultReceiveBufferSize = 65536;
/*    */ 
/*    */   public void bind()
/*    */     throws BindException, IOException
/*    */   {
/* 17 */     this.port = -1;
/* 18 */     bind(null);
/*    */   }
/*    */ 
/*    */   public void bind(int port)
/*    */     throws BindException, IOException
/*    */   {
/* 26 */     bind(new Integer(port), defaultReceiveBufferSize);
/*    */   }
/*    */ 
/*    */   public void bind(Integer port) throws BindException, IOException {
/* 30 */     bind(port, defaultReceiveBufferSize);
/*    */   }
/*    */ 
/*    */   public void bind(Integer port, int receiveBufferSize) throws BindException, IOException {
/* 34 */     Log.debug("BIND: in Bind with port: " + port);
/* 35 */     if (port.intValue() < 0) {
/* 36 */       throw new BindException("RDPServerSocket: port is < 0");
/*    */     }
/* 38 */     Log.debug("BIND: about to bind RDPServer");
/* 39 */     DatagramChannel dc = RDPServer.bind(port, receiveBufferSize);
/* 40 */     this.dc = dc;
/* 41 */     this.port = dc.socket().getLocalPort();
/* 42 */     Log.debug("BIND: about to register RDPServer socket");
/* 43 */     RDPServer.registerSocket(this, dc);
/* 44 */     Log.debug("BIND: registered RDPServer socket");
/*    */   }
/*    */ 
/*    */   public void registerAcceptCallback(ClientConnection.AcceptCallback cb) {
/* 48 */     this.acceptCallback = cb;
/*    */   }
/*    */ 
/*    */   ClientConnection.AcceptCallback getAcceptCallback() {
/* 52 */     return this.acceptCallback;
/*    */   }
/*    */ 
/*    */   public int getPort()
/*    */   {
/* 60 */     return this.port;
/*    */   }
/*    */ 
/*    */   public DatagramChannel getDatagramChannel() {
/* 64 */     return this.dc;
/*    */   }
/*    */   void setDatagramChannel(DatagramChannel dc) {
/* 67 */     this.dc = dc;
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.RDPServerSocket
 * JD-Core Version:    0.6.0
 */