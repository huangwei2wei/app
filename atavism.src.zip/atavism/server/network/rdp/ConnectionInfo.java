/*    */ package atavism.server.network.rdp;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.net.InetAddress;
/*    */ 
/*    */ public class ConnectionInfo
/*    */   implements Serializable
/*    */ {
/*    */   public InetAddress remoteAddress;
/*    */   public int remotePort;
/*    */   public int localPort;
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   ConnectionInfo(InetAddress remoteAddress, int remotePort, int localPort)
/*    */   {
/* 13 */     this.remoteAddress = remoteAddress;
/* 14 */     this.remotePort = remotePort;
/* 15 */     this.localPort = localPort;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o) {
/* 19 */     ConnectionInfo other = (ConnectionInfo)o;
/* 20 */     return (this.remoteAddress.equals(other.remoteAddress)) && (this.remotePort == other.remotePort) && (this.localPort == other.localPort);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 26 */     return this.remoteAddress.hashCode() ^ this.remotePort ^ this.localPort;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 30 */     return "[ConnectionInfo: remoteAddress=" + this.remoteAddress + ", remotePort=" + this.remotePort + ", localPort=" + this.localPort + "]";
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.ConnectionInfo
 * JD-Core Version:    0.6.0
 */