/*    */ package atavism.server.network.rdp;
/*    */ 
/*    */ import atavism.server.network.AOByteBuffer;
/*    */ import atavism.server.network.ClientConnection;
/*    */ import atavism.server.network.ClientConnection.AcceptCallback;
/*    */ import atavism.server.network.ClientConnection.MessageCallback;
/*    */ import atavism.server.util.Log;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class TestRDPServer
/*    */   implements ClientConnection.AcceptCallback, ClientConnection.MessageCallback
/*    */ {
/* 72 */   public static TestRDPServer testServer = new TestRDPServer();
/*    */ 
/*    */   public void connectionReset(ClientConnection con)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void acceptConnection(ClientConnection con)
/*    */   {
/* 13 */     con.registerMessageCallback(testServer);
/*    */   }
/*    */ 
/*    */   public void processPacket(ClientConnection con, AOByteBuffer buf)
/*    */   {
/*    */     try
/*    */     {
/* 21 */       buf.rewind();
/*    */ 
/* 23 */       con.send(buf);
/*    */     }
/*    */     catch (Exception e) {
/* 26 */       Log.error("got error: " + e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 31 */     if (args.length != 2) {
/* 32 */       System.err.println("usage: java TestRDPServer localPort loglevel");
/* 33 */       System.exit(1);
/*    */     }
/*    */ 
/* 36 */     int port = Integer.valueOf(args[0]).intValue();
/* 37 */     int logLevel = Integer.valueOf(args[1]).intValue();
/* 38 */     Log.setLogLevel(logLevel);
/*    */     try
/*    */     {
/* 41 */       System.out.println("starting server socket");
/* 42 */       RDPServerSocket serverSocket = new RDPServerSocket();
/* 43 */       serverSocket.registerAcceptCallback(testServer);
/* 44 */       serverSocket.bind(port);
/*    */       while (true)
/*    */       {
/* 63 */         Thread.sleep(5000L);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 67 */       System.err.println("exception: " + e);
/* 68 */       e.printStackTrace();
/* 69 */       System.exit(1);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.TestRDPServer
 * JD-Core Version:    0.6.0
 */