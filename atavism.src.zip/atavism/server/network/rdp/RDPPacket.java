/*     */ package atavism.server.network.rdp;
/*     */ 
/*     */ import atavism.server.network.AOByteBuffer;
/*     */ import atavism.server.util.LockFactory;
/*     */ import atavism.server.util.Log;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public class RDPPacket
/*     */   implements Comparable
/*     */ {
/* 517 */   private long mSendUnacks = 0L;
/*     */ 
/* 540 */   private long mMaxReceiveSegmentSize = 0L;
/*     */ 
/* 542 */   private int port = -1;
/* 543 */   private InetAddress inetAddress = null;
/*     */ 
/* 545 */   private boolean mIsSyn = false;
/* 546 */   private boolean isAck = false;
/* 547 */   private boolean mIsEak = false;
/* 548 */   private boolean isRst = false;
/* 549 */   private boolean isNul = false;
/* 550 */   private long seqNum = 0L;
/* 551 */   private long ackNum = 0L;
/* 552 */   private int headerLength = 6;
/* 553 */   private byte[] dataBuf = null;
/* 554 */   private boolean mIsSequenced = false;
/*     */ 
/* 557 */   private List<Long> eackList = new LinkedList();
/*     */   protected static final byte SYNF = -128;
/*     */   protected static final byte ACKF = 64;
/*     */   protected static final byte EAKF = 32;
/*     */   protected static final byte RSTF = 16;
/*     */   protected static final byte NULF = 8;
/*     */   protected static final byte VERSION = 2;
/*     */   protected static final long LONGM = 4294967295L;
/* 567 */   private long transmitTime = -1L;
/*     */   private static final int SEQUENCEFLAG = -32768;
/* 572 */   private static transient Lock StaticLock = LockFactory.makeLock("StaticRDPPacketLock");
/*     */ 
/*     */   public RDPPacket()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RDPPacket(RDPConnection con)
/*     */   {
/*  24 */     con.getLock().lock();
/*     */     try {
/*  26 */       setSeqNum(con.getSendNextSeqNum());
/*  27 */       setPort(con.getRemotePort());
/*  28 */       setInetAddress(con.getRemoteAddr());
/*  29 */       isSequenced(con.isSequenced());
/*     */     }
/*     */     finally {
/*  32 */       con.getLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  40 */     RDPPacket other = (RDPPacket)o;
/*  41 */     return other.getSeqNum() == getSeqNum();
/*     */   }
/*     */ 
/*     */   public int compareTo(Object o) {
/*  45 */     if (!(o instanceof RDPPacket)) {
/*  46 */       throw new ClassCastException("expected RDPPacket");
/*     */     }
/*  48 */     RDPPacket other = (RDPPacket)o;
/*  49 */     long mySeq = getSeqNum();
/*  50 */     long otherSeq = other.getSeqNum();
/*  51 */     if (mySeq < otherSeq) {
/*  52 */       return -1;
/*     */     }
/*  54 */     if (mySeq > otherSeq) {
/*  55 */       return 1;
/*     */     }
/*  57 */     return 0;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  61 */     String s = new String(new StringBuilder().append("RDPPacket[seqNum=").append(getSeqNum()).append(",port=").append(getPort()).append(",remoteAddress=").append(getInetAddress()).append(",isSyn=").append(isSyn()).append(",isEak=").append(isEak()).append(",ackNum=").append(getAckNum()).append(",isAck=").append(isAck()).append(",isRst=").append(isRst()).append(",isNul=").append(isNul()).append(",age(ms)=").append(System.currentTimeMillis() - getTransmitTime()).toString());
/*     */ 
/*  83 */     if (isSyn()) {
/*  84 */       s = new StringBuilder().append(s).append(",isSequenced=").append(isSequenced()).append(",maxSendUnacks=").append(this.mSendUnacks).append(",maxReceiveSegSize=").append(this.mMaxReceiveSegmentSize).toString();
/*     */     }
/*     */ 
/*  91 */     s = new StringBuilder().append(s).append(",hasData=").append(getData() != null).toString();
/*  92 */     if (getData() != null) {
/*  93 */       s = new StringBuilder().append(s).append(",dataLen=").append(getData().length).toString();
/*     */     }
/*  95 */     s = new StringBuilder().append(s).append("]").toString();
/*  96 */     return s;
/*     */   }
/*     */ 
/*     */   public static RDPPacket makeSynPacket(RDPConnection con) {
/* 100 */     con.getLock().lock();
/*     */     try {
/* 102 */       RDPPacket p = new RDPPacket();
/* 103 */       p.isSyn(true);
/* 104 */       p.setSeqNum(con.getInitialSendSeqNum());
/* 105 */       p.setMaxSendUnacks(con.getRcvMax());
/* 106 */       p.setMaxRcvSegmentSize(con.getMaxReceiveSegmentSize());
/*     */ 
/* 108 */       p.isSequenced(con.isSequenced());
/* 109 */       p.setPort(con.getRemotePort());
/* 110 */       p.setInetAddress(con.getRemoteAddr());
/* 111 */       RDPPacket localRDPPacket1 = p;
/*     */       return localRDPPacket1; } finally { con.getLock().unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public static RDPPacket makeNulPacket()
/*     */   {
/* 121 */     RDPPacket p = new RDPPacket();
/*     */ 
/* 124 */     p.isNul(true);
/* 125 */     return p;
/*     */   }
/*     */ 
/*     */   public static RDPPacket makeRstPacket()
/*     */   {
/* 133 */     RDPPacket p = new RDPPacket();
/* 134 */     p.setRstFlag(true);
/*     */ 
/* 137 */     return p;
/*     */   }
/*     */ 
/*     */   public int getPort() {
/* 141 */     return this.port;
/*     */   }
/*     */   public void setPort(int p) {
/* 144 */     this.port = p;
/*     */   }
/*     */   public void setInetAddress(InetAddress addr) {
/* 147 */     this.inetAddress = addr;
/*     */   }
/*     */   public InetAddress getInetAddress() {
/* 150 */     return this.inetAddress;
/*     */   }
/*     */ 
/*     */   public boolean isSequenced() {
/* 154 */     return this.mIsSequenced;
/*     */   }
/*     */   public void isSequenced(boolean val) {
/* 157 */     this.mIsSequenced = val;
/*     */   }
/*     */ 
/*     */   public void setSeqNum(long num) {
/* 161 */     this.seqNum = num;
/*     */   }
/*     */   public long getSeqNum() {
/* 164 */     return this.seqNum;
/*     */   }
/*     */ 
/*     */   public void setAckNum(long num) {
/* 168 */     this.ackNum = num;
/*     */   }
/*     */   public long getAckNum() {
/*     */     try {
/* 172 */       StaticLock.lock();
/* 173 */       long l = this.ackNum;
/*     */       return l; } finally { StaticLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setEackList(List<RDPPacket> inList)
/*     */   {
/*     */     try
/*     */     {
/* 185 */       StaticLock.lock();
/* 186 */       if (inList == null) { Log.error("eacklist is null");
/*     */         return; }
/* 190 */       this.eackList.clear();
/* 191 */       Iterator iter = inList.iterator();
/* 192 */       while (iter.hasNext()) {
/* 193 */         RDPPacket p = (RDPPacket)iter.next();
/* 194 */         this.eackList.add(new Long(p.getSeqNum()));
/*     */       }
/* 196 */       if (!this.eackList.isEmpty())
/* 197 */         this.mIsEak = true;
/*     */     }
/*     */     finally
/*     */     {
/* 201 */       StaticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Long> getEackList()
/*     */   {
/*     */     try {
/* 208 */       StaticLock.lock();
/* 209 */       LinkedList list = new LinkedList(this.eackList);
/* 210 */       LinkedList localLinkedList1 = list;
/*     */       return localLinkedList1; } finally { StaticLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public int numEacks()
/*     */   {
/*     */     try {
/* 219 */       StaticLock.lock();
/* 220 */       int i = this.eackList.size();
/*     */       return i; } finally { StaticLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void isSyn(boolean val)
/*     */   {
/* 228 */     this.mIsSyn = val;
/*     */   }
/*     */   public boolean isSyn() {
/* 231 */     return this.mIsSyn;
/*     */   }
/*     */ 
/*     */   public void isAck(boolean val) {
/* 235 */     this.isAck = val;
/*     */   }
/*     */   public boolean isAck() {
/* 238 */     return this.isAck;
/*     */   }
/*     */ 
/*     */   public boolean isNul() {
/* 242 */     return this.isNul;
/*     */   }
/*     */   public void isNul(boolean val) {
/* 245 */     this.isNul = val;
/*     */   }
/*     */ 
/*     */   public boolean isEak() {
/* 249 */     return this.mIsEak;
/*     */   }
/*     */   public void setEakFlag(boolean val) {
/* 252 */     this.mIsEak = val;
/*     */   }
/*     */ 
/*     */   public boolean isRst() {
/* 256 */     return this.isRst;
/*     */   }
/*     */   public void setRstFlag(boolean val) {
/* 259 */     this.isRst = val;
/*     */   }
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 266 */     return this.dataBuf;
/*     */   }
/*     */ 
/*     */   public void setData(byte[] buf)
/*     */   {
/* 273 */     this.dataBuf = buf;
/*     */   }
/*     */ 
/*     */   public void wrapData(byte[] buf)
/*     */   {
/* 280 */     this.dataBuf = buf;
/*     */   }
/*     */ 
/*     */   public void setMaxSendUnacks(long num) {
/*     */     try {
/* 285 */       StaticLock.lock();
/* 286 */       this.mSendUnacks = num;
/*     */     }
/*     */     finally {
/* 289 */       StaticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setTransmitTime(long time) {
/*     */     try {
/* 295 */       StaticLock.lock();
/* 296 */       this.transmitTime = time;
/*     */     }
/*     */     finally {
/* 299 */       StaticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getTransmitTime() {
/*     */     try {
/* 305 */       StaticLock.lock();
/* 306 */       long l = this.transmitTime;
/*     */       return l; } finally { StaticLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void parse(AOByteBuffer buf)
/*     */   {
/*     */     try {
/* 315 */       StaticLock.lock();
/* 316 */       buf.rewind();
/* 317 */       byte flagsByte = buf.getByte();
/*     */ 
/* 319 */       if ((flagsByte & 0xFFFFFF80) != 0) {
/* 320 */         this.mIsSyn = true;
/*     */       }
/*     */ 
/* 323 */       if ((flagsByte & 0x40) != 0) {
/* 324 */         this.isAck = true;
/*     */       }
/*     */ 
/* 327 */       if ((flagsByte & 0x20) != 0) {
/* 328 */         this.mIsEak = true;
/*     */       }
/*     */ 
/* 331 */       if ((flagsByte & 0x10) != 0) {
/* 332 */         this.isRst = true;
/*     */       }
/* 334 */       if ((flagsByte & 0x8) != 0) {
/* 335 */         this.isNul = true;
/*     */       }
/*     */ 
/* 338 */       this.headerLength = (buf.getByte() & 0xFF);
/*     */ 
/* 340 */       int dataLength = buf.getShort() & 0xFFFFFFFF;
/*     */ 
/* 342 */       this.seqNum = (buf.getInt() & 0xFFFFFFFF);
/* 343 */       this.ackNum = (buf.getInt() & 0xFFFFFFFF);
/*     */ 
/* 345 */       if (this.mIsSyn) {
/* 346 */         this.mSendUnacks = (buf.getShort() & 0xFFFF);
/* 347 */         this.mMaxReceiveSegmentSize = (buf.getShort() & 0xFFFF);
/* 348 */         this.mIsSequenced = ((buf.getByte() & 0x80) != 0);
/*     */       }
/* 350 */       else if (this.mIsEak)
/*     */       {
/* 352 */         if (this.headerLength % 2 != 0) {
/* 353 */           Log.error("headerlength boundary is incorrect");
/*     */         }
/* 355 */         int numEacks = (this.headerLength - 6) / 2;
/*     */ 
/* 357 */         if (!this.eackList.isEmpty()) {
/* 358 */           Log.error("eack list not empty");
/* 359 */           this.eackList.clear();
/*     */         }
/* 361 */         if (Log.loggingNet)
/* 362 */           Log.net(new StringBuilder().append("RDPPacket: packet has ").append(numEacks).append(" eacks").toString());
/* 363 */         String s = "";
/* 364 */         int firstEack = -1;
/* 365 */         int lastEack = -1;
/* 366 */         for (int i = 0; i < numEacks; i++) {
/* 367 */           int eackSeqNum = buf.getInt();
/* 368 */           this.eackList.add(new Long(eackSeqNum));
/* 369 */           if (Log.loggingNet) {
/* 370 */             if (firstEack == -1) {
/* 371 */               firstEack = eackSeqNum;
/* 372 */               lastEack = eackSeqNum;
/*     */             }
/* 374 */             else if (eackSeqNum == lastEack + 1) {
/* 375 */               lastEack = eackSeqNum;
/*     */             } else {
/* 377 */               if (s != "")
/* 378 */                 s = new StringBuilder().append(s).append(",").toString();
/* 379 */               if (firstEack == lastEack)
/* 380 */                 s = new StringBuilder().append(s).append(firstEack).toString();
/*     */               else
/* 382 */                 s = new StringBuilder().append(s).append(firstEack).append("-").append(lastEack).toString();
/* 383 */               firstEack = eackSeqNum;
/* 384 */               lastEack = eackSeqNum;
/*     */             }
/*     */           }
/*     */         }
/* 388 */         if (Log.loggingNet) {
/* 389 */           Log.net(new StringBuilder().append("RDPPacket.parse: packet#").append(getSeqNum()).append(": adding eack nums ").append(s).toString());
/*     */         }
/*     */       }
/* 392 */       else if (this.headerLength != 6) {
/* 393 */         Log.error(new StringBuilder().append("large header len (packet not syn/eak) len=").append(this.headerLength).toString());
/*     */       }
/*     */ 
/* 398 */       if (dataLength > 0) {
/* 399 */         byte[] tmpBuf = new byte[dataLength];
/* 400 */         buf.getBytes(tmpBuf, 0, dataLength);
/* 401 */         setData(tmpBuf);
/*     */       }
/*     */       else {
/* 404 */         setData(null);
/*     */       }
/*     */     }
/*     */     finally {
/* 408 */       StaticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void toByteBuffer(AOByteBuffer buf)
/*     */   {
/*     */     try
/*     */     {
/* 416 */       StaticLock.lock();
/* 417 */       buf.clear();
/*     */ 
/* 419 */       byte flagsByte = 0;
/* 420 */       int numEacks = 0;
/*     */ 
/* 422 */       if (this.mIsSyn) {
/* 423 */         flagsByte = (byte)(flagsByte | 0xFFFFFF80);
/*     */       }
/* 425 */       if (this.isAck) {
/* 426 */         flagsByte = (byte)(flagsByte | 0x40);
/*     */       }
/* 428 */       if (this.mIsEak) {
/* 429 */         flagsByte = (byte)(flagsByte | 0x20);
/*     */       }
/* 431 */       if (this.isRst) {
/* 432 */         flagsByte = (byte)(flagsByte | 0x10);
/*     */       }
/* 434 */       if (this.isNul) {
/* 435 */         flagsByte = (byte)(flagsByte | 0x8);
/*     */       }
/* 437 */       flagsByte = (byte)(flagsByte | 0x2);
/*     */ 
/* 439 */       buf.putByte(flagsByte);
/*     */ 
/* 442 */       if (this.mIsSyn) {
/* 443 */         buf.putByte(9);
/*     */       }
/* 445 */       else if (this.mIsEak) {
/* 446 */         numEacks = this.eackList.size();
/* 447 */         buf.putByte((byte)(6 + numEacks * 2));
/*     */       }
/*     */       else {
/* 450 */         buf.putByte(6);
/*     */       }
/*     */ 
/* 454 */       if (this.dataBuf == null) {
/* 455 */         buf.putShort(0);
/*     */       }
/*     */       else {
/* 458 */         buf.putShort((short)this.dataBuf.length);
/*     */       }
/*     */ 
/* 462 */       buf.putInt((int)this.seqNum);
/*     */ 
/* 465 */       buf.putInt((int)this.ackNum);
/*     */ 
/* 467 */       if (this.mIsSyn) {
/* 468 */         buf.putShort((short)(int)this.mSendUnacks);
/* 469 */         buf.putShort((short)(int)this.mMaxReceiveSegmentSize);
/* 470 */         if (this.mIsSequenced) {
/* 471 */           buf.putShort(-32768);
/*     */         }
/*     */         else {
/* 474 */           buf.putShort(0);
/*     */         }
/*     */       }
/* 477 */       else if (this.mIsEak) {
/* 478 */         Iterator iter = this.eackList.iterator();
/* 479 */         while (iter.hasNext()) {
/* 480 */           Long seqNum = (Long)iter.next();
/* 481 */           buf.putInt((int)seqNum.longValue());
/* 482 */           if (Log.loggingNet) {
/* 483 */             Log.net(new StringBuilder().append("rdppacket: tobytebuffer: adding eack# ").append(seqNum).toString());
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 488 */       if (this.dataBuf != null) {
/* 489 */         buf.putBytes(this.dataBuf, 0, this.dataBuf.length);
/*     */       }
/* 491 */       buf.flip();
/*     */     }
/*     */     finally {
/* 494 */       StaticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getSendUnacks() {
/*     */     try {
/* 500 */       StaticLock.lock();
/* 501 */       long l = this.mSendUnacks;
/*     */       return l; } finally { StaticLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setSendUnacks(long num)
/*     */   {
/*     */     try {
/* 510 */       StaticLock.lock();
/* 511 */       this.mSendUnacks = num;
/*     */     }
/*     */     finally {
/* 514 */       StaticLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getMaxRcvSegmentSize()
/*     */   {
/*     */     try
/*     */     {
/* 523 */       StaticLock.lock();
/* 524 */       long l = this.mMaxReceiveSegmentSize;
/*     */       return l; } finally { StaticLock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setMaxRcvSegmentSize(long num)
/*     */   {
/*     */     try {
/* 533 */       StaticLock.lock();
/* 534 */       this.mMaxReceiveSegmentSize = num;
/*     */     }
/*     */     finally {
/* 537 */       StaticLock.unlock();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.RDPPacket
 * JD-Core Version:    0.6.0
 */