package atavism.server.network.rdp;

public abstract interface RDPAcceptCallback
{
  public abstract void acceptRDPCon(RDPConnection paramRDPConnection);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.RDPAcceptCallback
 * JD-Core Version:    0.6.0
 */