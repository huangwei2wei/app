package atavism.server.network.rdp;

import atavism.server.network.AOByteBuffer;

public abstract interface RDPPacketCallback
{
  public abstract void processPacket(RDPConnection paramRDPConnection, AOByteBuffer paramAOByteBuffer);

  public abstract void connectionReset(RDPConnection paramRDPConnection);
}

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.RDPPacketCallback
 * JD-Core Version:    0.6.0
 */