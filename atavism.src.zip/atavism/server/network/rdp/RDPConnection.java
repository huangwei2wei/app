/*      */ package atavism.server.network.rdp;
/*      */ 
/*      */ import atavism.server.engine.Engine;
/*      */ import atavism.server.events.FragmentedMessage;
/*      */ import atavism.server.network.AOByteBuffer;
/*      */ import atavism.server.network.AOMsgNames;
/*      */ import atavism.server.network.ClientConnection;
/*      */ import atavism.server.network.ClientConnection.MessageCallback;
/*      */ import atavism.server.network.PacketAggregator;
/*      */ import atavism.server.util.AORuntimeException;
/*      */ import atavism.server.util.CountMeter;
/*      */ import atavism.server.util.DebugUtils;
/*      */ import atavism.server.util.Log;
/*      */ import atavism.server.util.Logger;
/*      */ import java.io.IOException;
/*      */ import java.net.BindException;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.channels.DatagramChannel;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.locks.Condition;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ public class RDPConnection extends ClientConnection
/*      */   implements Cloneable
/*      */ {
/*  548 */   long nullPacketTime = 0L;
/*      */ 
/*  572 */   long closeWaitTime = -1L;
/*      */ 
/*  697 */   private DatagramChannel dc = null;
/*      */ 
/*  699 */   private int mLocalPort = -1;
/*      */ 
/*  701 */   private int mRemotePort = -1;
/*      */ 
/*  703 */   private InetAddress mRemoteAddr = null;
/*      */ 
/*  705 */   private int mState = 3;
/*      */ 
/*  710 */   private AOByteBuffer receiveBuffer = new AOByteBuffer(4000);
/*      */ 
/*  721 */   private ClientConnection.MessageCallback packetCallback = null;
/*      */ 
/*  753 */   private long mMaxSendUnacks = -1L;
/*      */ 
/*  775 */   private long mInitialSendSeqNum = 1L;
/*      */ 
/*  797 */   private long mSendNextSeqNum = 1L;
/*      */ 
/*  819 */   private long mSendUnackd = -1L;
/*      */ 
/*  841 */   private long mRcvCur = -1L;
/*      */ 
/*  864 */   private long mRcvMax = 250L;
/*      */ 
/*  887 */   private long mRcvIrs = -1L;
/*      */ 
/*  917 */   private long mSBufMax = -1L;
/*      */ 
/*  942 */   private long mMaxReceiveSegmentSize = 4000L;
/*  943 */   static int DefaultMaxReceiveSegmentSize = 4000;
/*      */ 
/*  946 */   private boolean mIsSequenced = false;
/*      */   public static final int OPEN = 1;
/*      */   public static final int LISTEN = 2;
/*      */   public static final int CLOSED = 3;
/*      */   public static final int SYN_SENT = 4;
/*      */   public static final int SYN_RCVD = 5;
/*      */   public static final int CLOSE_WAIT = 6;
/* 1127 */   static CountMeter resendMeter = new CountMeter("RDPResendMeter");
/*      */ 
/* 1188 */   private TreeSet<RDPPacket> unackPacketSet = new TreeSet();
/*      */ 
/* 1194 */   private TreeSet<RDPPacket> eackSet = new TreeSet();
/*      */ 
/* 1217 */   private SortedSet<RDPPacket> sequencePackets = new TreeSet();
/*      */ 
/* 1226 */   private static int overrideMaxSendUnacks = -1;
/*      */ 
/* 1228 */   protected static int defaultReceiveBufferSize = 65536;
/*      */ 
/* 1235 */   Condition stateChanged = this.lock.newCondition();
/*      */ 
/* 1259 */   long lastSentMessage = 0L;
/*      */   public static final int aggregatedMsgId = 74;
/*      */   public static final int fragmentMsgId = 53;
/* 1263 */   private static final Logger log = new Logger("RDPConnection");
/*      */ 
/*      */   public void registerMessageCallback(ClientConnection.MessageCallback pcallback)
/*      */   {
/*   26 */     this.packetCallback = pcallback;
/*      */   }
/*      */ 
/*      */   public int connectionKind() {
/*   30 */     return 1;
/*      */   }
/*      */ 
/*      */   public boolean isOpen() {
/*   34 */     return getState() == 1;
/*      */   }
/*      */ 
/*      */   public boolean isClosed() {
/*   38 */     return getState() == 3;
/*      */   }
/*      */ 
/*      */   public boolean isClosing() {
/*   42 */     return getState() == 6;
/*      */   }
/*      */ 
/*      */   public void open(String hostname, int remotePort) {
/*      */     try {
/*   47 */       open(hostname, remotePort, true);
/*      */     }
/*      */     catch (Exception e) {
/*   50 */       Log.exception(new StringBuilder().append("RDPConnection.open for host ").append(hostname).append(", port ").append(remotePort).toString(), e);
/*   51 */       throw new AORuntimeException(e.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void open(String hostname, int remotePort, int localPort, boolean isSequenced, int receiveBufferSize)
/*      */     throws UnknownHostException, BindException, AORuntimeException, InterruptedException, IOException
/*      */   {
/*   61 */     InetAddress addr = InetAddress.getByName(hostname);
/*   62 */     open(addr, Integer.valueOf(remotePort), Integer.valueOf(localPort), isSequenced, receiveBufferSize);
/*      */   }
/*      */ 
/*      */   public void open(String hostname, int remotePort, boolean isSequenced)
/*      */     throws UnknownHostException, BindException, AORuntimeException, InterruptedException, IOException
/*      */   {
/*   68 */     InetAddress addr = InetAddress.getByName(hostname);
/*   69 */     open(addr, Integer.valueOf(remotePort), null, isSequenced, defaultReceiveBufferSize);
/*      */   }
/*      */ 
/*      */   public void open(String hostname, int remotePort, boolean isSequenced, int receiveBufferSize)
/*      */     throws UnknownHostException, BindException, AORuntimeException, InterruptedException, IOException
/*      */   {
/*   75 */     InetAddress addr = InetAddress.getByName(hostname);
/*   76 */     open(addr, Integer.valueOf(remotePort), null, isSequenced, receiveBufferSize);
/*      */   }
/*      */ 
/*      */   public void open(InetAddress address, int remotePort, boolean isSequenced)
/*      */     throws UnknownHostException, BindException, AORuntimeException, InterruptedException, IOException
/*      */   {
/*   82 */     open(address, Integer.valueOf(remotePort), null, isSequenced, defaultReceiveBufferSize);
/*      */   }
/*      */ 
/*      */   public void open(InetAddress address, int remotePort, boolean isSequenced, int receiveBufferSize)
/*      */     throws UnknownHostException, BindException, AORuntimeException, InterruptedException, IOException
/*      */   {
/*   88 */     open(address, Integer.valueOf(remotePort), null, isSequenced, receiveBufferSize);
/*      */   }
/*      */ 
/*      */   public void open(InetAddress address, Integer remotePort, Integer localPort, boolean isSequenced)
/*      */     throws BindException, AORuntimeException, InterruptedException, IOException
/*      */   {
/*   94 */     open(address, remotePort, localPort, isSequenced, defaultReceiveBufferSize);
/*      */   }
/*      */ 
/*      */   public void open(InetAddress address, Integer remotePort, Integer localPort, boolean isSequenced, int receiveBufferSize)
/*      */     throws BindException, AORuntimeException, InterruptedException, IOException
/*      */   {
/*  100 */     this.lock.lock();
/*      */     try {
/*  102 */       if (Log.loggingNet) {
/*  103 */         Log.net(new StringBuilder().append("RDPConnection.open: remoteaddr=").append(address).append(", remotePort=").append(remotePort).append(", localPort=").append(localPort).append(", isSequenced=").append(isSequenced).toString());
/*      */       }
/*      */ 
/*  107 */       DatagramChannel dc = RDPServer.bind(localPort, receiveBufferSize);
/*  108 */       if (dc == null) {
/*  109 */         throw new BindException("RDPConnection.open: RDPServer.bind returned null datagram channel");
/*      */       }
/*      */ 
/*  112 */       if (Log.loggingNet)
/*  113 */         Log.net("RDPConnection.open: RDPServer.bind succeeded");
/*  114 */       this.mIsSequenced = isSequenced;
/*  115 */       this.mRemoteAddr = address;
/*  116 */       this.mRemotePort = remotePort.intValue();
/*  117 */       this.mLocalPort = dc.socket().getLocalPort();
/*      */ 
/*  119 */       RDPServer.registerConnection(this, dc);
/*  120 */       if (Log.loggingNet)
/*  121 */         Log.net("RDPConnection.open: registered connection");
/*  122 */       if (this.mState != 3) {
/*  123 */         throw new BindException("Error - incorrect state");
/*      */       }
/*  125 */       if (Log.loggingNet) {
/*  126 */         Log.net(new StringBuilder().append("RDPConnection: setting localport to ").append(this.mLocalPort).append(", dynamicLocalPort=").append(localPort == null).toString());
/*      */       }
/*  128 */       setDatagramChannel(dc);
/*      */ 
/*  133 */       setState(4);
/*      */ 
/*  136 */       RDPPacket synpacket = RDPPacket.makeSynPacket(this);
/*  137 */       sendPacketImmediate(synpacket, false);
/*      */ 
/*  139 */       while (getState() != 1) {
/*  140 */         if (Log.loggingNet) {
/*  141 */           Log.net(new StringBuilder().append("RDPConnection: waiting for OPEN state, current=").append(toStringState(getState())).toString());
/*      */         }
/*  143 */         this.stateChanged.await();
/*      */       }
/*      */     } finally {
/*  146 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   void initConnection(DatagramChannel dc, RDPPacket synPacket)
/*      */   {
/*  154 */     setDatagramChannel(dc);
/*  155 */     setLocalPort(dc.socket().getLocalPort());
/*  156 */     setRemotePort(synPacket.getPort());
/*  157 */     setRemoteAddr(synPacket.getInetAddress());
/*      */ 
/*  159 */     setRcvIrs(synPacket.getSeqNum());
/*  160 */     setRcvCur(synPacket.getSeqNum());
/*  161 */     setMaxSendUnacks(synPacket.getSendUnacks());
/*  162 */     setSBufMax(synPacket.getMaxRcvSegmentSize());
/*  163 */     isSequenced(synPacket.isSequenced());
/*  164 */     setState(5);
/*      */   }
/*      */ 
/*      */   public String IPAndPort()
/*      */   {
/*  170 */     return new StringBuilder().append("RDP(").append(this.dc.socket().getInetAddress()).append(":").append(getLocalPort()).append(")").toString();
/*      */   }
/*      */ 
/*      */   public void connectionReset() {
/*  174 */     if (this.packetCallback != null)
/*  175 */       this.packetCallback.connectionReset(this);
/*      */   }
/*      */ 
/*      */   public void send(AOByteBuffer buf)
/*      */   {
/*  183 */     if ((logMessageContents) && (Log.loggingNet)) {
/*  184 */       Log.net(new StringBuilder().append("RDPConnection.send: length ").append(buf.limit()).append(", packet ").append(DebugUtils.byteArrayToHexString(buf)).toString());
/*      */     }
/*      */ 
/*  187 */     boolean rv = sendIfPossible(buf);
/*  188 */     if ((!rv) && (!PacketAggregator.usePacketAggregators))
/*  189 */       Log.error(new StringBuilder().append("RDPConnection.send for con ").append(this).append(", not aggregating ").append(", packet lost!").toString());
/*      */   }
/*      */ 
/*      */   public boolean sendIfPossible(AOByteBuffer buf)
/*      */   {
/*  197 */     int fragmentCount = FragmentedMessage.fragmentCount(buf.limit(), Engine.MAX_NETWORK_BUF_SIZE);
/*  198 */     List bufList = null;
/*      */     byte[] data;
/*      */     List fragList;
/*      */     int i;
/*  199 */     if (fragmentCount > 1) {
/*  200 */       data = buf.copyBytesFromZeroToLimit();
/*  201 */       fragList = FragmentedMessage.fragment(data, Engine.MAX_NETWORK_BUF_SIZE);
/*  202 */       bufList = new LinkedList();
/*  203 */       i = 0;
/*  204 */       for (FragmentedMessage frag : fragList) {
/*  205 */         AOByteBuffer fragBuf = frag.toBytes();
/*  206 */         fragBuf.rewind();
/*  207 */         i++;
/*  208 */         if (Log.loggingNet)
/*  209 */           Log.net(new StringBuilder().append("RDPConnection.sendIfPossible: adding frag buf ").append(i).append(" of ").append(fragList.size()).append(", frag ").append(fragmentedBuffer(fragBuf)).toString());
/*  210 */         bufList.add(fragBuf);
/*      */       }
/*      */     }
/*  213 */     this.lock.lock();
/*      */     try {
/*  215 */       if (PacketAggregator.usePacketAggregators) {
/*  216 */         if (fragmentCount > 1) {
/*  217 */           data = this.packetAggregator.addMessageList(bufList);
/*      */           return data;
/*      */         }
/*  219 */         data = this.packetAggregator.addMessage(buf);
/*      */         return data;
/*      */       }
/*  222 */       this.unaggregatedSends += 1L;
/*  223 */       PacketAggregator.allUnaggregatedSends += 1L;
/*  224 */       if (fragmentCount > 1) {
/*  225 */         for (AOByteBuffer fragBuf : bufList)
/*  226 */           if (!sendFragmentedPacket(fragBuf.copyBytes())) {
/*  227 */             i = 0;
/*      */             return i;
/*      */           }
/*  229 */         ??? = 1;
/*      */         return ???;
/*      */       }
/*  232 */       ??? = sendInternal(buf);
/*      */       return ???; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean sendInternal(AOByteBuffer buf)
/*      */   {
/*  249 */     long timer = 0L;
/*  250 */     if (Log.loggingDebug)
/*  251 */       timer = System.currentTimeMillis();
/*  252 */     byte[] tmp = buf.copyBytesFromZeroToLimit();
/*  253 */     boolean rv = sendFragmentedPacket(tmp);
/*  254 */     long t = System.currentTimeMillis() - timer;
/*  255 */     if ((t != 0L) && (Log.loggingDebug))
/*  256 */       Log.debug(new StringBuilder().append("RDPConnection.send: time in ms=").append(t).toString());
/*  257 */     return rv;
/*      */   }
/*      */ 
/*      */   public static boolean fragmentedBuffer(AOByteBuffer buf) {
/*  261 */     if (buf.limit() < 12)
/*  262 */       return false;
/*  263 */     byte[] array = buf.array();
/*  264 */     int msgId = 0;
/*  265 */     int index = 8;
/*  266 */     for (int i = 3; i >= 0; i--)
/*  267 */       msgId |= array[(index++)] << 8 * i;
/*  268 */     boolean frag = msgId == 53;
/*  269 */     return frag;
/*      */   }
/*      */ 
/*      */   public int sendMultibuf(List<AOByteBuffer> subMessages, int currentSize)
/*      */   {
/*  284 */     int sentSize = currentSize;
/*  285 */     int n = 0;
/*  286 */     boolean fragmentedBuffer = false;
/*      */ 
/*  288 */     sentSize = 0;
/*  289 */     for (AOByteBuffer buf : subMessages) {
/*  290 */       int sentBufSize = buf.limit() + 4;
/*  291 */       boolean frag = fragmentedBuffer(buf);
/*  292 */       if (frag) {
/*  293 */         if (n > 0) {
/*  294 */           fragmentedBuffer = false;
/*  295 */           break;
/*      */         }
/*      */ 
/*  298 */         n = 1;
/*  299 */         sentSize = sentBufSize;
/*  300 */         fragmentedBuffer = true;
/*  301 */         break;
/*      */       }
/*      */ 
/*  304 */       if (sentSize + sentBufSize + 16 >= Engine.MAX_NETWORK_BUF_SIZE)
/*      */         break;
/*  306 */       sentSize += sentBufSize;
/*  307 */       n++;
/*      */     }
/*  309 */     boolean rv = false;
/*  310 */     if (fragmentedBuffer) {
/*  311 */       sendInternal((AOByteBuffer)subMessages.get(0));
/*  312 */       subMessages.remove(0);
/*      */     }
/*      */     else {
/*  315 */       AOByteBuffer multiBuf = new AOByteBuffer(sentSize + 16);
/*  316 */       multiBuf.putOID(null);
/*  317 */       multiBuf.putInt(74);
/*  318 */       multiBuf.putInt(n);
/*  319 */       for (int i = 0; i < n; i++) {
/*  320 */         AOByteBuffer buf = (AOByteBuffer)subMessages.get(0);
/*  321 */         subMessages.remove(0);
/*  322 */         multiBuf.putByteBuffer(buf);
/*      */       }
/*  324 */       multiBuf.flip();
/*  325 */       rv = sendInternal(multiBuf);
/*      */     }
/*  327 */     if (rv) {
/*  328 */       this.aggregatedSends += 1L;
/*  329 */       PacketAggregator.allAggregatedSends += 1L;
/*  330 */       this.sentMessagesAggregated += n;
/*  331 */       PacketAggregator.allSentMessagesAggregated += n;
/*      */     }
/*  333 */     if (Log.loggingNet) {
/*  334 */       Log.net(new StringBuilder().append("RDPConnection.sendMultiBuf: sent ").append(n).append(" bufs, ").append(sentSize).append(" bytes, bufs left ").append(subMessages.size()).append(", bytes left ").append(currentSize - sentSize).append(", rv is ").append(rv).toString());
/*      */     }
/*  336 */     return currentSize - sentSize;
/*      */   }
/*      */ 
/*      */   public boolean canSend()
/*      */   {
/*  342 */     this.lock.lock();
/*      */     try {
/*  344 */       boolean bool = canSendInternal();
/*      */       return bool; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public boolean canSendInternal()
/*      */   {
/*  355 */     return (getState() == 1) && (this.mSendNextSeqNum < this.mSendUnackd + this.mMaxSendUnacks);
/*      */   }
/*      */ 
/*      */   boolean sendFragmentedPacket(byte[] data)
/*      */   {
/*  363 */     this.lock.lock();
/*      */     try {
/*  365 */       if (getState() != 1) {
/*  366 */         if ((getState() == 6) || (getState() == 3)) {
/*  367 */           Log.error("Trying to send on a closed connection");
/*  368 */           int i = 0;
/*      */           return i;
/*      */         }
/*  370 */         throw new AORuntimeException(new StringBuilder().append("Connection is not OPEN: state=").append(toStringState(getState())).toString());
/*      */       }
/*      */ 
/*  374 */       RDPPacket p = new RDPPacket();
/*  375 */       p.setData(data);
/*      */ 
/*  378 */       if (!canSendInternal())
/*      */       {
/*  381 */         Log.error(new StringBuilder().append("RDPConnection.sendFragmentedPacket: Too many unacked packets: mSendNextSeqNum ").append(this.mSendNextSeqNum).append(" >= mSendUnackd ").append(this.mSendUnackd).append(" + mMaxSendUnacks").append(this.mMaxSendUnacks).append("; packet is ").append(p).toString());
/*      */ 
/*  383 */         throw new AORuntimeException("Too many unacked packets");
/*      */       }
/*      */ 
/*  386 */       sendPacketImmediate(p, false);
/*      */     }
/*      */     finally {
/*  389 */       this.lock.unlock();
/*      */     }
/*  391 */     return true;
/*      */   }
/*      */ 
/*      */   public long unackBufferRemaining()
/*      */   {
/*  399 */     this.lock.lock();
/*      */     try
/*      */     {
/*  402 */       long l = 70 - unackLength();
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public int unackLength()
/*      */   {
/*  409 */     this.lock.lock();
/*      */     try {
/*  411 */       if (Log.loggingNet) {
/*  412 */         Log.net(new StringBuilder().append("RDPConnection.unackLength: con=").append(toStringVerbose()).append(", sendNextSeqNum=").append(this.mSendNextSeqNum).append(", sendUnackd=").append(this.mSendUnackd).toString());
/*      */       }
/*      */ 
/*  415 */       int i = (int)(this.mSendNextSeqNum - this.mSendUnackd);
/*      */       return i; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*  427 */     this.lock.lock();
/*      */     try
/*      */     {
/*  430 */       if ((getState() == 6) || (getState() == 3))
/*      */       {
/*      */         return;
/*      */       }
/*  435 */       setState(6);
/*  436 */       setCloseWaitTimer();
/*      */ 
/*  439 */       if (Log.loggingNet)
/*  440 */         Log.net("RDPConnection.close: sending reset packet to other side");
/*      */       try {
/*  442 */         RDPPacket rstPacket = RDPPacket.makeRstPacket();
/*  443 */         sendPacketImmediate(rstPacket, false);
/*      */       } catch (Exception e) {
/*  445 */         Log.error(new StringBuilder().append("got exception while sending reset: ").append(e).toString());
/*      */       }
/*      */ 
/*  449 */       if (Log.loggingDebug)
/*  450 */         log.debug(new StringBuilder().append("RDPConnection.close: calling connectionReset callback, con=").append(toStringVerbose()).toString());
/*  451 */       ClientConnection.MessageCallback pcb = getCallback();
/*  452 */       pcb.connectionReset(this);
/*      */     } finally {
/*  454 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setMaxReceiveSegmentSize(int size)
/*      */   {
/*  463 */     this.mMaxReceiveSegmentSize = size;
/*      */   }
/*      */ 
/*      */   public boolean isSequenced() {
/*  467 */     return this.mIsSequenced;
/*      */   }
/*      */ 
/*      */   public void isSequenced(boolean isSequenced) {
/*  471 */     this.mIsSequenced = isSequenced;
/*      */   }
/*      */ 
/*      */   public void setState(int state) {
/*  475 */     this.lock.lock();
/*      */     try {
/*  477 */       this.mState = state;
/*      */ 
/*  480 */       this.stateChanged.signal();
/*      */     } finally {
/*  482 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getState() {
/*  487 */     return this.mState;
/*      */   }
/*      */ 
/*      */   public DatagramChannel getDatagramChannel() {
/*  491 */     return this.dc;
/*      */   }
/*      */ 
/*      */   public void setDatagramChannel(DatagramChannel dc) {
/*  495 */     this.dc = dc;
/*      */   }
/*      */ 
/*      */   public int getRemotePort() {
/*  499 */     return this.mRemotePort;
/*      */   }
/*      */ 
/*      */   public void setRemotePort(int port) {
/*  503 */     this.mRemotePort = port;
/*      */   }
/*      */ 
/*      */   public int getLocalPort() {
/*  507 */     return this.mLocalPort;
/*      */   }
/*      */ 
/*      */   public void setLocalPort(int port) {
/*  511 */     this.mLocalPort = port;
/*      */   }
/*      */ 
/*      */   public InetAddress getRemoteAddr() {
/*  515 */     return this.mRemoteAddr;
/*      */   }
/*      */ 
/*      */   public void setRemoteAddr(InetAddress remoteAddr) {
/*  519 */     this.mRemoteAddr = remoteAddr;
/*      */   }
/*      */ 
/*      */   void setLastNullPacketTime()
/*      */   {
/*  528 */     this.lock.lock();
/*      */     try {
/*  530 */       this.nullPacketTime = System.currentTimeMillis();
/*      */     } finally {
/*  532 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   long getLastNullPacketTime()
/*      */   {
/*  540 */     this.lock.lock();
/*      */     try {
/*  542 */       long l = this.nullPacketTime;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   void setCloseWaitTimer()
/*      */   {
/*  555 */     this.lock.lock();
/*      */     try {
/*  557 */       this.closeWaitTime = System.currentTimeMillis();
/*      */     } finally {
/*  559 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   long getCloseWaitTimer() {
/*  564 */     this.lock.lock();
/*      */     try {
/*  566 */       long l = this.closeWaitTime;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  575 */     return new StringBuilder().append("RDP(").append(this.mRemoteAddr).append(":").append(this.mRemotePort).append(")").toString();
/*      */   }
/*      */ 
/*      */   public String toStringVerbose() {
/*  579 */     return new StringBuilder().append("RDPConnection[state=").append(toStringState(this.mState)).append(",localport=").append(this.mLocalPort).append(",remoteport=").append(this.mRemotePort).append(",remoteaddr=").append(this.mRemoteAddr).append(",isSeq=").append(isSequenced()).append(",RCV.CUR=").append(this.mRcvCur).append(",RCV.IRS=").append(this.mRcvIrs).append(",SND.MAX=").append(this.mMaxSendUnacks).append(",RBUF.MAX=").append(this.mMaxReceiveSegmentSize).append(",SND.UNA=").append(this.mSendUnackd).append("]").toString();
/*      */   }
/*      */ 
/*      */   protected void sendPacketImmediate(RDPPacket packet, boolean retransmit)
/*      */   {
/*  595 */     this.lock.lock();
/*      */     try {
/*  597 */       packet.setPort(getRemotePort());
/*  598 */       packet.setInetAddress(getRemoteAddr());
/*  599 */       packet.isSequenced(isSequenced());
/*  600 */       packet.isAck(true);
/*  601 */       packet.setAckNum(this.mRcvCur);
/*  602 */       packet.setEackList(getEackList());
/*      */ 
/*  604 */       if (!retransmit) {
/*  605 */         packet.setSeqNum(getSendNextSeqNum());
/*      */       }
/*  607 */       if (Log.loggingNet) {
/*  608 */         Log.net(new StringBuilder().append("RDPConnection: SENDING PACKET (localport=").append(this.mLocalPort).append("): ").append(packet).append(", retransmit=").append(retransmit).toString());
/*      */       }
/*  610 */       RDPServer.sendPacket(getDatagramChannel(), packet);
/*  611 */       RDPServer.transmits += 1;
/*  612 */       if (retransmit) {
/*  613 */         RDPServer.retransmits += 1;
/*      */       }
/*  615 */       if (Log.loggingDebug)
/*      */       {
/*  618 */         byte[] packetData = packet.getData();
/*  619 */         if (packetData != null) {
/*  620 */           AOByteBuffer tmpBuf = new AOByteBuffer(packetData);
/*  621 */           tmpBuf.getOID();
/*  622 */           int msgTypeNum = tmpBuf.getInt();
/*  623 */           if (Log.loggingNet) {
/*  624 */             Log.net(new StringBuilder().append("RDPServer.sendPacket: msgType='").append(AOMsgNames.msgName(msgTypeNum)).append("', addr=").append(getRemoteAddr()).append(", port=").append(getRemotePort()).append(", retransmit=").append(retransmit).toString());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  632 */       if ((!retransmit) && ((packet.isSyn()) || (packet.isNul()) || (packet.getData() != null)))
/*      */       {
/*  635 */         packet.setTransmitTime(System.currentTimeMillis());
/*  636 */         this.mSendNextSeqNum += 1L;
/*  637 */         if (Log.loggingNet)
/*  638 */           log.net(new StringBuilder().append("incremented seq# to ").append(this.mSendNextSeqNum).toString());
/*      */       } else {
/*  640 */         log.net("not incrementing packet seqNum since no data or is retransmit");
/*      */       }
/*      */ 
/*  647 */       if (!packet.isSyn())
/*      */       {
/*  649 */         if ((packet.getData() != null) || (packet.isNul()))
/*      */         {
/*  652 */           if (!retransmit) {
/*  653 */             if (Log.loggingNet)
/*  654 */               Log.net("adding to unacklist");
/*  655 */             addUnackPacket(packet);
/*      */           }
/*  658 */           else if (Log.loggingNet) {
/*  659 */             Log.net("not adding to unacklist - is a retransmit");
/*      */           }
/*      */         }
/*  662 */         else if (Log.loggingNet)
/*  663 */           Log.net("not adding to unacklist - has no data");
/*      */       }
/*      */     } catch (Exception e) {
/*  666 */       throw new AORuntimeException(e.toString());
/*      */     } finally {
/*  668 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected RDPPacket receivePacket() {
/*      */     try {
/*  674 */       this.lock.lock();
/*      */ 
/*  678 */       InetSocketAddress sockAddr = (InetSocketAddress)getDatagramChannel().receive(this.receiveBuffer.getNioBuf());
/*      */ 
/*  680 */       this.receiveBuffer.flip();
/*      */ 
/*  682 */       RDPPacket packet = new RDPPacket();
/*  683 */       packet.setPort(sockAddr.getPort());
/*  684 */       packet.setInetAddress(sockAddr.getAddress());
/*  685 */       packet.parse(this.receiveBuffer);
/*  686 */       RDPPacket localRDPPacket1 = packet;
/*      */       return localRDPPacket1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  688 */       throw new AORuntimeException(e.toString());
/*      */     } finally {
/*  690 */       this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public ClientConnection.MessageCallback getCallback()
/*      */   {
/*  713 */     return this.packetCallback;
/*      */   }
/*      */ 
/*      */   public void setCallback(ClientConnection.MessageCallback cb) {
/*  717 */     this.packetCallback = cb;
/*      */   }
/*      */ 
/*      */   public long getMaxSendUnacks()
/*      */   {
/*      */     try
/*      */     {
/*  729 */       this.lock.lock();
/*  730 */       long l = this.mMaxSendUnacks;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setMaxSendUnacks(long max)
/*      */   {
/*      */     try {
/*  738 */       this.lock.lock();
/*  739 */       if (overrideMaxSendUnacks == -1) {
/*  740 */         if (Log.loggingNet)
/*  741 */           Log.net(new StringBuilder().append("RDPConnection: setting max send unacks to ").append(max).toString());
/*  742 */         this.mMaxSendUnacks = max;
/*      */       } else {
/*  744 */         if (Log.loggingNet)
/*  745 */           Log.net("RDPConnection: using override max sendunacks instead");
/*  746 */         this.mMaxSendUnacks = overrideMaxSendUnacks;
/*      */       }
/*      */     } finally {
/*  749 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getInitialSendSeqNum()
/*      */   {
/*      */     try
/*      */     {
/*  759 */       this.lock.lock();
/*  760 */       long l = this.mInitialSendSeqNum;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setInitialSendSeqNum(long seqNum)
/*      */   {
/*      */     try {
/*  768 */       this.lock.lock();
/*  769 */       this.mInitialSendSeqNum = seqNum;
/*      */     } finally {
/*  771 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getSendNextSeqNum()
/*      */   {
/*      */     try
/*      */     {
/*  781 */       this.lock.lock();
/*  782 */       long l = this.mSendNextSeqNum;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setSendNextSeqNum(long num)
/*      */   {
/*      */     try {
/*  790 */       this.lock.lock();
/*  791 */       this.mSendNextSeqNum = num;
/*      */     } finally {
/*  793 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getSendUnackd()
/*      */   {
/*      */     try
/*      */     {
/*  803 */       this.lock.lock();
/*  804 */       long l = this.mSendUnackd;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setSendUnackd(long num)
/*      */   {
/*      */     try {
/*  812 */       this.lock.lock();
/*  813 */       this.mSendUnackd = num;
/*      */     } finally {
/*  815 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getRcvCur()
/*      */   {
/*      */     try
/*      */     {
/*  825 */       this.lock.lock();
/*  826 */       long l = this.mRcvCur;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setRcvCur(long rcvCur)
/*      */   {
/*      */     try {
/*  834 */       this.lock.lock();
/*  835 */       this.mRcvCur = rcvCur;
/*      */     } finally {
/*  837 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getRcvMax()
/*      */   {
/*      */     try
/*      */     {
/*  848 */       this.lock.lock();
/*  849 */       long l = this.mRcvMax;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setRcvMax(long max)
/*      */   {
/*      */     try {
/*  857 */       this.lock.lock();
/*  858 */       this.mRcvMax = max;
/*      */     } finally {
/*  860 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getRcvIrs()
/*      */   {
/*      */     try
/*      */     {
/*  871 */       this.lock.lock();
/*  872 */       long l = this.mRcvIrs;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setRcvIrs(long rcvIrs)
/*      */   {
/*      */     try {
/*  880 */       this.lock.lock();
/*  881 */       this.mRcvIrs = rcvIrs;
/*      */     } finally {
/*  883 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getSBufMax()
/*      */   {
/*      */     try
/*      */     {
/*  901 */       this.lock.lock();
/*  902 */       long l = this.mSBufMax;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setSBufMax(long max)
/*      */   {
/*      */     try {
/*  910 */       this.lock.lock();
/*  911 */       this.mSBufMax = max;
/*      */     } finally {
/*  913 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setMaxReceiveSegmentSize(long max)
/*      */   {
/*      */     try
/*      */     {
/*  926 */       this.lock.lock();
/*  927 */       this.mMaxReceiveSegmentSize = max;
/*      */     } finally {
/*  929 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public long getMaxReceiveSegmentSize() {
/*      */     try {
/*  935 */       this.lock.lock();
/*  936 */       long l = this.mMaxReceiveSegmentSize;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static String toStringState(int i)
/*      */   {
/*  961 */     if (i == 1)
/*  962 */       return "OPEN";
/*  963 */     if (i == 2)
/*  964 */       return "LISTEN";
/*  965 */     if (i == 3)
/*  966 */       return "CLOSED";
/*  967 */     if (i == 4)
/*  968 */       return "SYN_SENT";
/*  969 */     if (i == 5)
/*  970 */       return "SYN_RCVD";
/*  971 */     if (i == 6)
/*  972 */       return "CLOSE_WAIT";
/*  973 */     return "UNKNOWN";
/*      */   }
/*      */ 
/*      */   void addUnackPacket(RDPPacket p)
/*      */   {
/*      */     try {
/*  979 */       this.lock.lock();
/*  980 */       this.unackPacketSet.add(p);
/*  981 */       if (Log.loggingNet)
/*  982 */         Log.net(new StringBuilder().append("RDPCon: added to unacked list - ").append(p).append(", list size=").append(this.unackPacketSet.size()).append(",unacklist=").append(unackListToShortString()).toString());
/*      */     }
/*      */     finally
/*      */     {
/*  986 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   void removeUnackPacketUpTo(long seqNum)
/*      */   {
/*      */     try {
/*  993 */       this.lock.lock();
/*  994 */       if (Log.loggingNet)
/*  995 */         Log.net(new StringBuilder().append("removingunackpacketupto: ").append(seqNum).toString());
/*  996 */       Iterator iter = this.unackPacketSet.iterator();
/*  997 */       while (iter.hasNext()) {
/*  998 */         RDPPacket p = (RDPPacket)iter.next();
/*  999 */         if (p.getSeqNum() > seqNum) break;
/* 1000 */         if (Log.loggingNet) {
/* 1001 */           Log.net(new StringBuilder().append("removing packet # ").append(p.getSeqNum()).append(" from unacklist for con ").append(this).toString());
/*      */         }
/* 1003 */         iter.remove();
/*      */       }
/*      */ 
/* 1008 */       if (Log.loggingNet)
/* 1009 */         Log.net(new StringBuilder().append("removed all unack packets up to: ").append(seqNum).append(" unacked left: ").append(this.unackPacketSet.size()).append(" - unlist list = ").append(unackListToShortString()).toString());
/*      */     }
/*      */     finally
/*      */     {
/* 1013 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   int unackListSize() {
/* 1018 */     this.lock.lock();
/*      */     try {
/* 1020 */       int i = this.unackPacketSet.size();
/*      */       return i; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   String unackListToShortString()
/*      */   {
/*      */     try {
/* 1028 */       this.lock.lock();
/* 1029 */       int count = 0;
/* 1030 */       int size = this.unackPacketSet.size();
/* 1031 */       String s = "seq nums =";
/* 1032 */       Iterator iter = this.unackPacketSet.iterator();
/* 1033 */       while ((iter.hasNext()) && (count++ < 6)) {
/* 1034 */         p = (RDPPacket)iter.next();
/* 1035 */         s = new StringBuilder().append(s).append(" ").append(p.getSeqNum()).toString();
/*      */       }
/* 1037 */       if (count < size)
/* 1038 */         s = new StringBuilder().append(s).append(" ... ").append(this.unackPacketSet.last()).toString();
/* 1039 */       RDPPacket p = s;
/*      */       return p; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   void removeUnackPacket(long seqNum)
/*      */   {
/*      */     try
/*      */     {
/* 1052 */       this.lock.lock();
/* 1053 */       Iterator iter = this.unackPacketSet.iterator();
/* 1054 */       while (iter.hasNext()) {
/* 1055 */         RDPPacket p = (RDPPacket)iter.next();
/* 1056 */         if (p.getSeqNum() < seqNum) {
/*      */           continue;
/*      */         }
/* 1059 */         if (p.getSeqNum() != seqNum) break;
/* 1060 */         iter.remove();
/* 1061 */         if (!Log.loggingNet) break;
/* 1062 */         Log.net(new StringBuilder().append("number of unackpackets left: ").append(this.unackPacketSet.size()).toString());
/*      */       }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 1072 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   void resend(long cutOffTime, long resendTimeout)
/*      */   {
/*      */     try
/*      */     {
/* 1082 */       long currentTime = System.currentTimeMillis();
/* 1083 */       this.lock.lock();
/* 1084 */       Iterator iter = this.unackPacketSet.iterator();
/* 1085 */       while (iter.hasNext()) {
/* 1086 */         RDPPacket p = (RDPPacket)iter.next();
/* 1087 */         long transmitTime = p.getTransmitTime();
/* 1088 */         if (Log.loggingNet) {
/* 1089 */           Log.net(new StringBuilder().append("RDPConnection.resend: packetTransmit: ").append(transmitTime).append(", age=").append(currentTime - transmitTime).append(", resendTimeout=").append(resendTimeout).append(", currentTime=").append(currentTime).append(", timeout reached in ").append(transmitTime - resendTimeout).append(" millis").append(", packet=").append(p).toString());
/*      */         }
/*      */ 
/* 1096 */         if (transmitTime < resendTimeout)
/*      */         {
/* 1097 */           Log.warn(new StringBuilder().append("RDPConnection: closing connect because resendTimeout reached.  con=").append(toStringVerbose()).append(", packetTransmitTime ").append(transmitTime).append(", age=").append(currentTime - transmitTime).append(", currentTime=").append(currentTime).append(", resendTimeout=").append(resendTimeout).append(", cutOffTime=").append(cutOffTime).append(", packet=").append(p).toString());
/*      */ 
/* 1105 */           close();
/*      */           return;
/*      */         }
/*      */ 
/* 1109 */         if (transmitTime < cutOffTime) {
/* 1110 */           if (Log.loggingNet) {
/* 1111 */             Log.net(new StringBuilder().append("resending expired packet: ").append(p).append(" - using connection ").append(toStringVerbose()).toString());
/*      */           }
/* 1113 */           sendPacketImmediate(p, true);
/* 1114 */           resendMeter.add();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 1124 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   void addEack(RDPPacket packet)
/*      */   {
/*      */     try
/*      */     {
/* 1133 */       this.lock.lock();
/* 1134 */       this.eackSet.add(packet);
/*      */     } finally {
/* 1136 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean removeEack(long seqNum)
/*      */   {
/*      */     try {
/* 1143 */       this.lock.lock();
/* 1144 */       Iterator iter = this.eackSet.iterator();
/* 1145 */       while (iter.hasNext()) {
/* 1146 */         p = (RDPPacket)iter.next();
/* 1147 */         if (p.getSeqNum() == seqNum) {
/* 1148 */           iter.remove();
/* 1149 */           int i = 1;
/*      */           return i;
/*      */         }
/*      */       }
/* 1152 */       RDPPacket p = 0;
/*      */       return p; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   List getEackList()
/*      */   {
/*      */     try
/*      */     {
/* 1162 */       this.lock.lock();
/* 1163 */       LinkedList list = new LinkedList(this.eackSet);
/* 1164 */       LinkedList localLinkedList1 = list;
/*      */       return localLinkedList1; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   boolean hasEack(long seqNum)
/*      */   {
/*      */     try
/*      */     {
/* 1173 */       this.lock.lock();
/* 1174 */       Iterator iter = this.eackSet.iterator();
/* 1175 */       while (iter.hasNext()) {
/* 1176 */         p = (RDPPacket)iter.next();
/* 1177 */         if (p.getSeqNum() == seqNum) {
/* 1178 */           int i = 1;
/*      */           return i;
/*      */         }
/*      */       }
/* 1181 */       RDPPacket p = 0;
/*      */       return p; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   void addSequencePacket(RDPPacket packet)
/*      */   {
/*      */     try
/*      */     {
/* 1198 */       this.lock.lock();
/* 1199 */       this.sequencePackets.add(packet);
/*      */     } finally {
/* 1201 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   SortedSet getSequencePackets()
/*      */   {
/* 1210 */     return this.sequencePackets;
/*      */   }
/*      */ 
/*      */   public static void setOverrideMaxSendUnacks(int max)
/*      */   {
/* 1223 */     overrideMaxSendUnacks = max;
/*      */   }
/*      */ 
/*      */   public long getLastSentMessage()
/*      */   {
/* 1242 */     this.lock.lock();
/*      */     try {
/* 1244 */       long l = this.lastSentMessage;
/*      */       return l; } finally { this.lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public void setLastSentMessage(long time)
/*      */   {
/* 1251 */     this.lock.lock();
/*      */     try {
/* 1253 */       this.lastSentMessage = time;
/*      */     } finally {
/* 1255 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.rdp.RDPConnection
 * JD-Core Version:    0.6.0
 */