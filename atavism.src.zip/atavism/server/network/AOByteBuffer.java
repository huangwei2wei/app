/*     */ package atavism.server.network;
/*     */ 
/*     */ import atavism.msgsys.MessageType;
/*     */ import atavism.server.engine.OID;
/*     */ import atavism.server.math.AOVector;
/*     */ import atavism.server.math.Point;
/*     */ import atavism.server.math.Quaternion;
/*     */ import atavism.server.objects.Color;
/*     */ import atavism.server.util.Log;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class AOByteBuffer
/*     */   implements Cloneable, Comparable<AOByteBuffer>
/*     */ {
/*     */   private static final byte valueTypeNull = 0;
/*     */   private static final byte valueTypeString = 1;
/*     */   private static final byte valueTypeLong = 2;
/*     */   private static final byte valueTypeInteger = 3;
/*     */   private static final byte valueTypeBoolean = 4;
/*     */   private static final byte valueTypeBooleanFalse = 4;
/*     */   private static final byte valueTypeBooleanTrue = 5;
/*     */   private static final byte valueTypeFloat = 6;
/*     */   private static final byte valueTypeDouble = 7;
/*     */   private static final byte valueTypePoint = 8;
/*     */   private static final byte valueTypeAOVector = 9;
/*     */   private static final byte valueTypeQuaternion = 10;
/*     */   private static final byte valueTypeColor = 11;
/*     */   private static final byte valueTypeByte = 12;
/*     */   private static final byte valueTypeShort = 13;
/*     */   private static final byte valueTypeOID = 14;
/*     */   private static final byte valueTypeLinkedList = 20;
/*     */   private static final byte valueTypeHashSet = 21;
/*     */   private static final byte valueTypeHashMap = 22;
/*     */   private static final byte valueTypeByteArray = 23;
/*     */   private static final byte valueTypeTreeMap = 24;
/* 481 */   private static Map<Class, Byte> classToValueTypeMap = null;
/*     */   private ByteBuffer mBB;
/*     */ 
/*     */   public AOByteBuffer(int size)
/*     */   {
/*  21 */     byte[] backingArray = new byte[size];
/*  22 */     this.mBB = ByteBuffer.wrap(backingArray);
/*  23 */     if (!this.mBB.hasArray()) {
/*  24 */       System.err.println("does not have backing array");
/*  25 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public AOByteBuffer(byte[] data)
/*     */   {
/*  35 */     this(data.length);
/*  36 */     this.mBB.put(data, 0, data.length);
/*  37 */     flip();
/*     */   }
/*     */ 
/*     */   public AOByteBuffer(ByteBuffer data) {
/*  41 */     this.mBB = data;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  48 */     byte[] data = this.mBB.array();
/*  49 */     AOByteBuffer newBuf = new AOByteBuffer(data.length);
/*  50 */     newBuf.putBytes(data, 0, data.length);
/*  51 */     return newBuf;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer cloneAtOffset(int offset, int length)
/*     */   {
/*  59 */     byte[] data = this.mBB.array();
/*  60 */     AOByteBuffer newBuf = new AOByteBuffer(length);
/*  61 */     newBuf.putBytes(data, offset + this.mBB.position(), length);
/*  62 */     newBuf.rewind();
/*  63 */     return newBuf;
/*     */   }
/*     */ 
/*     */   public byte[] array()
/*     */   {
/*  73 */     return this.mBB.array();
/*     */   }
/*     */ 
/*     */   public int capacity()
/*     */   {
/*  78 */     return this.mBB.capacity();
/*     */   }
/*     */ 
/*     */   public AOByteBuffer clear() {
/*  82 */     this.mBB.clear();
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer flip() {
/*  87 */     this.mBB.flip();
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean hasRemaining() {
/*  92 */     return this.mBB.hasRemaining();
/*     */   }
/*     */ 
/*     */   public int limit() {
/*  96 */     return this.mBB.limit();
/*     */   }
/*     */ 
/*     */   public AOByteBuffer limit(int newLimit) {
/* 100 */     this.mBB.limit(newLimit);
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   public int position() {
/* 105 */     return this.mBB.position();
/*     */   }
/*     */ 
/*     */   public AOByteBuffer position(int newPos) {
/* 109 */     this.mBB.position(newPos);
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */   public int remaining() {
/* 114 */     return this.mBB.remaining();
/*     */   }
/*     */ 
/*     */   public AOByteBuffer rewind() {
/* 118 */     this.mBB.rewind();
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */   public byte getByte() {
/* 123 */     return this.mBB.get();
/*     */   }
/*     */ 
/*     */   public AOByteBuffer getBytes(byte[] dst, int offset, int length)
/*     */   {
/* 128 */     this.mBB.get(dst, offset, length);
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */   public byte[] copyBytes()
/*     */   {
/* 139 */     rewind();
/* 140 */     byte[] copyBuf = new byte[this.mBB.limit()];
/* 141 */     getBytes(copyBuf, 0, this.mBB.limit());
/* 142 */     return copyBuf;
/*     */   }
/*     */ 
/*     */   public byte[] copyBytesFromZeroToLimit()
/*     */   {
/* 151 */     int len = this.mBB.limit();
/* 152 */     byte[] buf = new byte[len];
/* 153 */     byte[] arr = this.mBB.array();
/* 154 */     for (int i = 0; i < len; i++)
/* 155 */       buf[i] = arr[i];
/* 156 */     return buf;
/*     */   }
/*     */ 
/*     */   public boolean getBoolean()
/*     */   {
/* 161 */     return getInt() == 1;
/*     */   }
/*     */   public double getDouble() {
/* 164 */     return this.mBB.getDouble();
/*     */   }
/*     */ 
/*     */   public float getFloat() {
/* 168 */     return this.mBB.getFloat();
/*     */   }
/*     */ 
/*     */   public short getShort() {
/* 172 */     return this.mBB.getShort();
/*     */   }
/*     */ 
/*     */   public int getInt() {
/* 176 */     return this.mBB.getInt();
/*     */   }
/*     */ 
/*     */   public long getLong() {
/* 180 */     return this.mBB.getLong();
/*     */   }
/*     */ 
/*     */   public String getString() {
/* 184 */     int len = this.mBB.getInt();
/* 185 */     if (len > 64000) {
/* 186 */       throw new RuntimeException("AOByteBuffer.getString: over 64k string len=" + len);
/*     */     }
/* 188 */     byte[] buf = new byte[len];
/* 189 */     getBytes(buf, 0, len);
/*     */     try {
/* 191 */       return new String(buf, "UTF8");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/* 194 */     return new String(buf);
/*     */   }
/*     */ 
/*     */   public OID getOID()
/*     */   {
/* 199 */     long l = getLong();
/* 200 */     if (l == 0L)
/* 201 */       return null;
/* 202 */     return OID.fromLong(l);
/*     */   }
/*     */ 
/*     */   public Point getPoint() {
/* 206 */     return new Point(getFloat(), getFloat(), getFloat());
/*     */   }
/*     */ 
/*     */   public Quaternion getQuaternion() {
/* 210 */     return new Quaternion(getFloat(), getFloat(), getFloat(), getFloat());
/*     */   }
/*     */ 
/*     */   public AOVector getAOVector() {
/* 214 */     return new AOVector(getFloat(), getFloat(), getFloat());
/*     */   }
/*     */ 
/*     */   public Color getColor() {
/* 218 */     int alpha = getByte() & 0xFF;
/* 219 */     int blue = getByte() & 0xFF;
/* 220 */     int green = getByte() & 0xFF;
/* 221 */     int red = getByte() & 0xFF;
/* 222 */     return new Color(red, green, blue, alpha);
/*     */   }
/*     */ 
/*     */   public AOByteBuffer getByteBuffer() {
/* 226 */     int length = getInt();
/* 227 */     byte[] data = new byte[length];
/* 228 */     getBytes(data, 0, length);
/*     */ 
/* 230 */     AOByteBuffer newBuf = new AOByteBuffer(length);
/* 231 */     newBuf.putBytes(data, 0, length);
/* 232 */     newBuf.flip();
/* 233 */     return newBuf;
/*     */   }
/*     */ 
/*     */   public byte[] getByteArray() {
/* 237 */     int length = getInt();
/* 238 */     byte[] data = new byte[length];
/* 239 */     getBytes(data, 0, length);
/* 240 */     return data;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putByte(byte b) {
/* 244 */     if (remaining() <= 0) {
/* 245 */       reallocate();
/*     */     }
/* 247 */     this.mBB.put(b);
/* 248 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putBytes(byte[] src, int offset, int length) {
/* 252 */     if (remaining() < length) {
/* 253 */       reallocate(position() + length);
/*     */     }
/* 255 */     this.mBB.put(src, offset, length);
/* 256 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putBoolean(boolean b) {
/* 260 */     if (remaining() < 4) {
/* 261 */       reallocate();
/*     */     }
/*     */ 
/* 264 */     this.mBB.putInt(b ? 1 : 0);
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putDouble(double d) {
/* 269 */     if (remaining() < 8) {
/* 270 */       reallocate();
/*     */     }
/* 272 */     this.mBB.putDouble(d);
/* 273 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putFloat(float f) {
/* 277 */     if (remaining() < 4) {
/* 278 */       reallocate();
/*     */     }
/* 280 */     this.mBB.putFloat(f);
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putShort(short s) {
/* 285 */     if (remaining() < 2) {
/* 286 */       reallocate();
/*     */     }
/* 288 */     this.mBB.putShort(s);
/* 289 */     return this;
/*     */   }
/*     */   public AOByteBuffer putInt(int i) {
/* 292 */     if (remaining() < 4) {
/* 293 */       reallocate();
/*     */     }
/* 295 */     this.mBB.putInt(i);
/* 296 */     return this;
/*     */   }
/*     */   public AOByteBuffer putLong(long l) {
/* 299 */     return putLong(new Long(l));
/*     */   }
/*     */   public AOByteBuffer putLong(Long l) {
/* 302 */     if (l == null) {
/* 303 */       l = Long.valueOf(0L);
/*     */     }
/* 305 */     if (remaining() < 8) {
/* 306 */       reallocate();
/*     */     }
/* 308 */     this.mBB.putLong(l.longValue());
/* 309 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putString(String s)
/*     */   {
/* 314 */     if (s == null) {
/* 315 */       putInt(0);
/* 316 */       return this;
/*     */     }byte[] data;
/*     */     try {
/* 320 */       data = s.getBytes("UTF8");
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 324 */       data = s.getBytes();
/*     */     }
/* 326 */     int len = data.length;
/*     */ 
/* 328 */     if (remaining() < len + 4) {
/* 329 */       reallocate(position() + len + 4);
/*     */     }
/*     */ 
/* 332 */     this.mBB.putInt(len);
/* 333 */     this.mBB.put(data, 0, len);
/* 334 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putMsgTypeString(MessageType msgType) {
/* 338 */     return putString(msgType.getMsgTypeString());
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putOID(OID oid) {
/* 342 */     if (oid == null)
/* 343 */       return putLong(0L);
/* 344 */     return putLong(oid.toLong());
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putPoint(Point p) {
/* 348 */     if (remaining() < 24) {
/* 349 */       reallocate();
/*     */     }
/* 351 */     this.mBB.putFloat(p.getX());
/* 352 */     this.mBB.putFloat(p.getY());
/* 353 */     this.mBB.putFloat(p.getZ());
/* 354 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putQuaternion(Quaternion q) {
/* 358 */     if (remaining() < 32) {
/* 359 */       reallocate();
/*     */     }
/* 361 */     this.mBB.putFloat(q.getX());
/* 362 */     this.mBB.putFloat(q.getY());
/* 363 */     this.mBB.putFloat(q.getZ());
/* 364 */     this.mBB.putFloat(q.getW());
/* 365 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putAOVector(AOVector v) {
/* 369 */     if (remaining() < 24) {
/* 370 */       reallocate();
/*     */     }
/* 372 */     this.mBB.putFloat(v.getX());
/* 373 */     this.mBB.putFloat(v.getY());
/* 374 */     this.mBB.putFloat(v.getZ());
/* 375 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putColor(Color c) {
/* 379 */     if (remaining() < 4) {
/* 380 */       reallocate();
/*     */     }
/* 382 */     this.mBB.put((byte)c.getAlpha());
/* 383 */     this.mBB.put((byte)c.getBlue());
/* 384 */     this.mBB.put((byte)c.getGreen());
/* 385 */     this.mBB.put((byte)c.getRed());
/* 386 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putByteBuffer(AOByteBuffer other) {
/* 390 */     byte[] data = other.array();
/* 391 */     int dataLen = other.limit();
/*     */ 
/* 394 */     if (remaining() < dataLen + 4) {
/* 395 */       reallocate(position() + dataLen + 4);
/*     */     }
/*     */ 
/* 398 */     this.mBB.putInt(dataLen);
/*     */ 
/* 400 */     this.mBB.put(data, 0, dataLen);
/*     */ 
/* 402 */     return this;
/*     */   }
/*     */ 
/*     */   public AOByteBuffer putByteArray(byte[] byteArray) {
/* 406 */     this.mBB.putInt(byteArray.length);
/* 407 */     this.mBB.put(byteArray, 0, byteArray.length);
/* 408 */     return this;
/*     */   }
/*     */ 
/*     */   public ByteBuffer getNioBuf() {
/* 412 */     return this.mBB;
/*     */   }
/*     */ 
/*     */   private void reallocate()
/*     */   {
/* 418 */     reallocate(capacity() * 2);
/*     */   }
/*     */ 
/*     */   private void reallocate(int minSize)
/*     */   {
/* 424 */     int newSize = capacity();
/* 425 */     while (newSize < minSize) {
/* 426 */       newSize *= 2;
/*     */     }
/* 428 */     if (Log.loggingDebug) {
/* 429 */       Log.debug("AOByteBuffer.reallocate: size=" + capacity() + " requested=" + minSize + " newSize=" + newSize);
/*     */     }
/*     */ 
/* 433 */     int pos = position();
/*     */ 
/* 436 */     byte[] data = this.mBB.array();
/* 437 */     int dataLen = this.mBB.position();
/*     */ 
/* 440 */     byte[] backingArray = new byte[newSize];
/* 441 */     this.mBB = ByteBuffer.wrap(backingArray);
/*     */ 
/* 444 */     this.mBB.put(data, 0, dataLen);
/*     */ 
/* 447 */     this.mBB.position(pos);
/*     */   }
/*     */ 
/*     */   private static void initializeClassToValueTypeMap()
/*     */   {
/* 484 */     classToValueTypeMap = new HashMap();
/* 485 */     classToValueTypeMap.put(String.class, Byte.valueOf(1));
/* 486 */     classToValueTypeMap.put(Long.class, Byte.valueOf(2));
/* 487 */     classToValueTypeMap.put(Integer.class, Byte.valueOf(3));
/* 488 */     classToValueTypeMap.put(Boolean.class, Byte.valueOf(4));
/* 489 */     classToValueTypeMap.put(Float.class, Byte.valueOf(6));
/* 490 */     classToValueTypeMap.put(Double.class, Byte.valueOf(7));
/* 491 */     classToValueTypeMap.put(Byte.class, Byte.valueOf(12));
/* 492 */     classToValueTypeMap.put(Short.class, Byte.valueOf(13));
/* 493 */     classToValueTypeMap.put(Point.class, Byte.valueOf(8));
/* 494 */     classToValueTypeMap.put(AOVector.class, Byte.valueOf(9));
/* 495 */     classToValueTypeMap.put(Quaternion.class, Byte.valueOf(10));
/* 496 */     classToValueTypeMap.put(Color.class, Byte.valueOf(11));
/* 497 */     classToValueTypeMap.put(OID.class, Byte.valueOf(14));
/* 498 */     classToValueTypeMap.put(LinkedList.class, Byte.valueOf(20));
/* 499 */     classToValueTypeMap.put(ArrayList.class, Byte.valueOf(20));
/* 500 */     classToValueTypeMap.put(HashSet.class, Byte.valueOf(21));
/* 501 */     classToValueTypeMap.put(LinkedHashSet.class, Byte.valueOf(21));
/* 502 */     classToValueTypeMap.put(TreeSet.class, Byte.valueOf(21));
/* 503 */     classToValueTypeMap.put(HashMap.class, Byte.valueOf(22));
/* 504 */     classToValueTypeMap.put(LinkedHashMap.class, Byte.valueOf(22));
/* 505 */     classToValueTypeMap.put([B.class, Byte.valueOf(23));
/* 506 */     classToValueTypeMap.put(TreeMap.class, Byte.valueOf(24));
/*     */   }
/*     */ 
/*     */   public void putEncodedObject(Serializable val) {
/* 510 */     if (classToValueTypeMap == null)
/* 511 */       initializeClassToValueTypeMap();
/* 512 */     if (val == null) {
/* 513 */       putByte(0);
/* 514 */     } else if ((val instanceof ClientSerializable)) {
/* 515 */       ((ClientSerializable)val).encodeObject(this);
/*     */     } else {
/* 517 */       Class c = val.getClass();
/* 518 */       Byte index = (Byte)classToValueTypeMap.get(c);
/* 519 */       if (index == null) {
/* 520 */         Log.error("AOByteBuffer.putEncodedObject: no support for object of " + c);
/* 521 */         return;
/*     */       }
/* 523 */       switch (index.byteValue()) {
/*     */       case 1:
/* 525 */         putByte(1);
/* 526 */         putString((String)val);
/* 527 */         break;
/*     */       case 2:
/* 529 */         putByte(2);
/* 530 */         putLong((Long)val);
/* 531 */         break;
/*     */       case 12:
/* 533 */         putByte(12);
/* 534 */         putByte(((Byte)val).byteValue());
/* 535 */         break;
/*     */       case 13:
/* 537 */         putByte(13);
/* 538 */         putShort(((Short)val).shortValue());
/* 539 */         break;
/*     */       case 3:
/* 541 */         putByte(3);
/* 542 */         putInt(((Integer)val).intValue());
/* 543 */         break;
/*     */       case 4:
/* 545 */         putByte(((Boolean)val).booleanValue() ? 5 : 4);
/* 546 */         break;
/*     */       case 6:
/* 548 */         putByte(6);
/* 549 */         putFloat(((Float)val).floatValue());
/* 550 */         break;
/*     */       case 7:
/* 552 */         putByte(7);
/* 553 */         putDouble(((Double)val).doubleValue());
/* 554 */         break;
/*     */       case 8:
/* 556 */         putByte(8);
/* 557 */         putPoint((Point)val);
/* 558 */         break;
/*     */       case 9:
/* 560 */         putByte(9);
/* 561 */         putAOVector((AOVector)val);
/* 562 */         break;
/*     */       case 10:
/* 564 */         putByte(10);
/* 565 */         putQuaternion((Quaternion)val);
/* 566 */         break;
/*     */       case 11:
/* 568 */         putByte(11);
/* 569 */         putColor((Color)val);
/* 570 */         break;
/*     */       case 14:
/* 572 */         putByte(14);
/* 573 */         putOID((OID)val);
/* 574 */         break;
/*     */       case 20:
/* 576 */         putByte(20);
/* 577 */         putCollection((Collection)val);
/* 578 */         break;
/*     */       case 21:
/* 580 */         putByte(21);
/* 581 */         putCollection((Collection)val);
/* 582 */         break;
/*     */       case 22:
/* 584 */         putByte(22);
/* 585 */         putPropertyMap((HashMap)val);
/* 586 */         break;
/*     */       case 23:
/* 588 */         putByte(23);
/* 589 */         putByteArray((byte[])(byte[])val);
/* 590 */         break;
/*     */       case 24:
/* 592 */         putByte(24);
/* 593 */         putPropertyMap((TreeMap)val);
/* 594 */         break;
/*     */       case 5:
/*     */       case 15:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/*     */       default:
/* 596 */         Log.error("WorldManagerClient.putEncodedObject: index " + index + " out of bounds; class " + c.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Serializable getEncodedObject()
/*     */   {
/* 603 */     byte typecode = getByte();
/* 604 */     switch (typecode) {
/*     */     case 0:
/* 606 */       return null;
/*     */     case 1:
/* 608 */       return getString();
/*     */     case 12:
/* 610 */       return Byte.valueOf(getByte());
/*     */     case 13:
/* 612 */       return Short.valueOf(getShort());
/*     */     case 2:
/* 614 */       return Long.valueOf(getLong());
/*     */     case 3:
/* 616 */       return Integer.valueOf(getInt());
/*     */     case 4:
/* 618 */       return Boolean.valueOf(false);
/*     */     case 5:
/* 620 */       return Boolean.valueOf(true);
/*     */     case 6:
/* 622 */       return Float.valueOf(getFloat());
/*     */     case 7:
/* 624 */       return Double.valueOf(getDouble());
/*     */     case 8:
/* 626 */       return getPoint();
/*     */     case 9:
/* 628 */       return getAOVector();
/*     */     case 10:
/* 630 */       return getQuaternion();
/*     */     case 11:
/* 632 */       return getColor();
/*     */     case 14:
/* 634 */       return getOID();
/*     */     case 20:
/* 636 */       return (Serializable)getCollection();
/*     */     case 21:
/* 638 */       int count = getInt();
/* 639 */       HashSet set = new HashSet();
/* 640 */       for (int i = 0; i < count; i++)
/* 641 */         set.add(getEncodedObject());
/* 642 */       return set;
/*     */     case 22:
/* 644 */       return (Serializable)getPropertyMap();
/*     */     case 23:
/* 646 */       return getByteArray();
/*     */     case 24:
/* 648 */       return (Serializable)getTreeMap();
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/* 650 */     case 19: } Log.error("WorldManagerClient.getObjectUtility: Illegal value type code " + typecode);
/* 651 */     return null;
/*     */   }
/*     */ 
/*     */   public void putCollection(Collection<Serializable> collection)
/*     */   {
/* 661 */     putInt(collection == null ? 0 : collection.size());
/* 662 */     if (collection != null)
/* 663 */       for (Serializable entry : collection)
/* 664 */         putEncodedObject(entry);
/*     */   }
/*     */ 
/*     */   public void putPropertyMap(Map<String, Serializable> propertyMap)
/*     */   {
/* 676 */     if (Log.loggingDebug)
/* 677 */       logPropertyMap("putPropertyMap", propertyMap, null);
/* 678 */     putInt(propertyMap == null ? 0 : propertyMap.size());
/* 679 */     if (propertyMap != null)
/* 680 */       for (Map.Entry entry : propertyMap.entrySet()) {
/* 681 */         String key = (String)entry.getKey();
/* 682 */         Serializable val = (Serializable)entry.getValue();
/* 683 */         putString(key);
/* 684 */         putEncodedObject(val);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void putFilteredPropertyMap(Map<String, Serializable> propertyMap, Set<String> filteredProps)
/*     */   {
/* 696 */     if ((filteredProps == null) || (filteredProps.size() == 0))
/* 697 */       putPropertyMap(propertyMap);
/* 698 */     if (propertyMap == null) {
/* 699 */       putInt(0);
/* 700 */       return;
/*     */     }
/* 702 */     int count = 0;
/* 703 */     for (String key : propertyMap.keySet()) {
/* 704 */       if ((filteredProps == null) || (!filteredProps.contains(key)))
/* 705 */         count++;
/*     */     }
/* 707 */     putInt(count);
/* 708 */     if (Log.loggingDebug)
/* 709 */       logPropertyMap("putFilteredPropertyMap", propertyMap, filteredProps);
/* 710 */     for (Map.Entry entry : propertyMap.entrySet()) {
/* 711 */       String key = (String)entry.getKey();
/* 712 */       Serializable val = (Serializable)entry.getValue();
/* 713 */       if ((filteredProps == null) || (!filteredProps.contains(key))) {
/* 714 */         putString(key);
/* 715 */         putEncodedObject(val);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void logPropertyMap(String prefix, Map<String, Serializable> propertyMap, Set<String> filteredProps) {
/* 721 */     String s = "";
/* 722 */     for (Map.Entry entry : propertyMap.entrySet()) {
/* 723 */       String key = (String)entry.getKey();
/* 724 */       Serializable val = (Serializable)entry.getValue();
/* 725 */       if ((filteredProps == null) || (!filteredProps.contains(key))) {
/* 726 */         if (s != "")
/* 727 */           s = s + ", ";
/* 728 */         s = s + key + "=" + val;
/*     */       }
/*     */     }
/* 731 */     Log.debug(prefix + ": " + s);
/*     */   }
/*     */ 
/*     */   public void putFilteredPropertyCollection(Collection<String> properties, Set<String> filteredProps)
/*     */   {
/* 741 */     LinkedList collection = new LinkedList(properties);
/* 742 */     if (filteredProps != null)
/* 743 */       collection.removeAll(filteredProps);
/* 744 */     putCollection(collection);
/*     */   }
/*     */ 
/*     */   public Collection<Serializable> getCollection() {
/* 748 */     int count = getInt();
/* 749 */     Collection collection = new LinkedList();
/* 750 */     for (int i = 0; i < count; i++)
/* 751 */       collection.add(getEncodedObject());
/* 752 */     return collection;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getPropertyMap() {
/* 756 */     int count = getInt();
/* 757 */     HashMap map = new HashMap();
/* 758 */     for (int i = 0; i < count; i++) {
/* 759 */       String key = getString();
/* 760 */       Serializable value = getEncodedObject();
/* 761 */       map.put(key, value);
/*     */     }
/* 763 */     return map;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getTreeMap() {
/* 767 */     int count = getInt();
/* 768 */     TreeMap map = new TreeMap();
/* 769 */     for (int i = 0; i < count; i++) {
/* 770 */       String key = getString();
/* 771 */       Serializable value = getEncodedObject();
/* 772 */       map.put(key, value);
/*     */     }
/* 774 */     return map;
/*     */   }
/*     */ 
/*     */   public int compareTo(AOByteBuffer buffer) {
/* 778 */     return this.mBB.compareTo(buffer.mBB);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 786 */       AOByteBuffer b = new AOByteBuffer(10);
/* 787 */       b.putString("012345678910101010HELLO");
/* 788 */       b.flip();
/* 789 */       String foo = b.getString();
/* 790 */       System.out.println("printing out: '" + foo + "'");
/*     */     }
/*     */     catch (Exception e) {
/* 793 */       Log.exception("AOByteBuffer.main caught exception", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static AOByteBuffer putInt(AOByteBuffer buffer, int i)
/*     */   {
/* 800 */     buffer.putByte(3);
/* 801 */     return buffer.putInt(i);
/*     */   }
/*     */   public static AOByteBuffer putString(AOByteBuffer buffer, String str) {
/* 804 */     buffer.putByte(1);
/* 805 */     return buffer.putString(str);
/*     */   }
/*     */ }

/* Location:           F:\app\atavism_server_v2\dist\lib\atavism.jar
 * Qualified Name:     atavism.server.network.AOByteBuffer
 * JD-Core Version:    0.6.0
 */